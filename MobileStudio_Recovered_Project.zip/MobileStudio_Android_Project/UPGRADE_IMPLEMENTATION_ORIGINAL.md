# Mobile Studio upgrade implementation

This archive contains the recovered application source with a first focused upgrade pass applied.

## Changes applied

### Studio dark theme
- Replaced the old low-contrast charcoal palette with a neutral Studio-style dark palette.
- Added clearer panel separation, readable text, muted secondary text, and a restrained blue selection/accent color.
- Kept the existing `Dark` theme identifier so existing settings that select the dark theme remain compatible.

### Dock layout
- Reduced the default side-panel widths on phones so the viewport keeps more usable space.
- Added subtle alternating row backgrounds in Explorer and Properties for easier scanning.
- Increased Explorer and Properties row touch targets slightly for mobile use.
- Slightly tightened the default bottom panel height.
- Reduced the minimum dock width and capped side-panel width at 52% of the display width to prevent a single dock from swallowing the viewport.
- Reduced the maximum bottom panel height to 58% of the display height.

### Renderer safety and baseline
- Raised the initial ambient fill and increased the lighting-derived ambient contribution while retaining scene-provided Ambient and OutdoorAmbient values.
- Fixed shadow-map allocation so the chosen resolution never exceeds the reported `GL_MAX_TEXTURE_SIZE`; it uses the largest power-of-two resolution up to 2048.
- Slightly widened the existing five-tap shadow filter without adding extra texture samples, preserving its current GPU sample count.

## Important scope and limitations

These are source-level changes in the recovered JADX Java tree. The original APK's DEX files are not rebuilt by this archive. The matching Smali files are retained as unmodified forensic references, not represented as synchronized build inputs.

This is not an installable APK and has not been device-tested. The recovered ZIP does not contain the original Gradle project, dependency lock/configuration, Kotlin source, or signing key. The current execution environment also has no Android SDK, Gradle, APK assembler, `zipalign`, or `apksigner`, and outbound downloads are unavailable. Therefore, claiming that an installable APK was produced would be misleading.

## Next build requirements

A compatible Android build environment is required to:
1. Reconstruct the Gradle project and dependency versions from the APK/decompiler metadata.
2. Resolve all JADX reconstruction failures against the original DEX/Smali.
3. Compile and package the changed source.
4. Sign the APK with a new test key (the original developer signing key is not present).
5. Install and test on Android hardware, including a lower-end GPU.

Do not install this source archive as an APK. It is intended for source review and the next build stage.
