# Mobile Studio source audit and upgrade plan

## What was recovered

This workspace was assembled from the supplied JADX decompiler ZIP. It contains the app-specific Java reconstruction, app-specific Smali disassembly, Android resources, material textures, the manifest, and the JADX reconstruction report.

- Android package: `com.exampletest.mobilestudiotest`
- Version shown in the manifest: `1.1` (versionCode `2`)
- Compile SDK: `37`
- Target SDK: `37`
- Minimum SDK: `24`
- Rendering requirement: OpenGL ES 2.0
- App-specific Java source files: 168
- App-specific Smali files: 168
- Android resource files: 1158
- Material texture files: 134

## Confirmed architecture from the recovered source

### UI
The app has dedicated implementations for:
- `ui/DockLayout.java`
- `ui/ExplorerPanel.java`
- `ui/PropertiesPanel.java`
- `ui/ViewportView.java`
- `ui/ToolboxPanel.java`
- `ui/OutputPanel.java`
- `ui/ScriptEditor.java`
- `ui/StartScreen.java`
- `ui/SettingsDialog.java`
- `core/Theme.java`

This means the upgrade should improve the existing panels and layout system rather than replace the app with a separate UI.

### Rendering
The app has a custom OpenGL ES renderer in `render/SceneRenderer.java`. The recovered source confirms:
- a shadow-map setup path;
- a shadow texture whose resolution is selected from the device's maximum texture size (1024 or 2048);
- sun direction and sun color handling;
- separate ambient and outdoor-ambient inputs;
- exposure and fog uniforms;
- mesh and decal shader programs;
- existing batch and frustum-related classes (`StaticBatches`, `BatchSpec`, `Frustum`).

This is a useful base. The rendering work should focus on correctness, cache invalidation, and device-aware quality scaling rather than blindly increasing shadow resolution.

## Important reconstruction limitation

The JADX report records **33 failed method reconstructions inside the app package**. The full archive also reports 116 failed reconstructions overall. The Smali files are included as a fallback reference.

A decompiled Java file is not guaranteed to be equivalent to the original Kotlin/Java implementation. Some generated method bodies can be incomplete or incorrect. For that reason, this workspace is a source-recovery workspace, not a verified Android Studio project.

## Upgrade plan

### Phase A: UI fidelity
1. Keep the existing dark/light theme support and refine the dark palette into a neutral Studio-like palette.
2. Standardize panel headers, separators, row heights, selection states, and input fields.
3. Improve the Explorer hierarchy: indentation, disclosure controls, class icons, selection/hover states, and search behavior.
4. Improve Properties grouping and filtering, with compact vector editing for values such as Vector3 and Color3.
5. Use a mobile-adaptive ribbon: compact tabs and horizontally scrollable tools, with the viewport retaining the largest practical area.
6. Keep Output and Script Editor accessible without permanently consuming viewport space.

### Phase B: renderer fidelity
1. Establish a stable baseline for directional sun, ambient fill, outdoor ambient, fog, and exposure.
2. Implement soft, voxel-inspired lighting as a deliberate rendering mode, not as a claim that the renderer is Roblox's proprietary lighting implementation.
3. Use a coarse lighting grid or voxel occupancy representation for blocky indirect/shadow behavior, while retaining the existing shadow map for directional contact shadows where practical.
4. Add bias and normal-bias controls to reduce shadow acne and detached shadows.
5. Cache shadow maps and only refresh when relevant scene state changes; use a throttled update cadence on lower-end devices.
6. Use cascaded or camera-focused shadow regions only if the device budget supports them.
7. Keep material response consistent across opaque, transparent, and decal passes.

### Phase C: performance
1. Profile CPU and GPU time separately before changing quality defaults.
2. Avoid rebuilding static batches when only camera state changes.
3. Keep frustum culling and add distance/size-aware detail reduction where safe.
4. Reuse buffers and temporary arrays in render loops.
5. Scale shadow resolution and update cadence by device capability and measured frame time.
6. Avoid per-frame allocations and repeated shader/uniform lookups.

### Phase D: validation
1. Compile from a genuine Android project structure.
2. Test startup, project loading, Explorer selection, Properties editing, script editing, save/export, and play mode.
3. Test multiple Android screen sizes and at least one lower-end GPU.
4. Compare viewport output across the supported lighting modes.
5. Confirm no regressions in RBXL/RBXM handling and Luau execution.

## Roblox reference notes

Current Roblox Studio documentation describes the core workspace as a Viewport plus Explorer, Properties, Toolbox, Output, and related panels. The toolbar uses tabs such as Home, Model, Avatar, UI, Script, and Plugins.

Roblox's current lighting controls emphasize `LightingStyle` and `PrioritizeLightingQuality`. The older `Technology` enum includes `Voxel` (a 4×4×4-stud voxel map) but is deprecated/superseded in current workflows. Therefore, the target should be a voxel-inspired look that resembles Roblox's Soft lighting behavior, not a false claim of exact engine parity.

## What this workspace does not contain

- The original Gradle project files and dependency declarations.
- The original Kotlin source files.
- The original signed APK.
- A verified build configuration or signing key.

Consequently, this workspace cannot yet produce a trustworthy installable APK by itself. It is intended to make source inspection and patch development easier while preserving Smali as a fallback for methods JADX could not reconstruct.
