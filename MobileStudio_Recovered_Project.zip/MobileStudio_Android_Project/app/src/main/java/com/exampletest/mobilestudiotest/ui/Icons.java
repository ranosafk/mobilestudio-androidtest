package com.exampletest.mobilestudiotest.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import com.exampletest.mobilestudiotest.model.ClassDb;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.collections.SetsKt;
import kotlin.io.ByteStreamsKt;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: Icons.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001:\u00011B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u0013J\u001a\u0010\u0018\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0019\u001a\u00020\b2\u0006\u0010\u001a\u001a\u00020\bH\u0002J\u0010\u0010\u001b\u001a\u0004\u0018\u00010\t2\u0006\u0010\u001c\u001a\u00020\bJ\u0010\u0010\u001d\u001a\u0004\u0018\u00010\t2\u0006\u0010\u001a\u001a\u00020\bJ\u0010\u0010\u001e\u001a\u0004\u0018\u00010\t2\u0006\u0010\u001a\u001a\u00020\bJ\u0016\u0010\u001f\u001a\u00020 2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001c\u001a\u00020\bJ \u0010!\u001a\u00020 2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\b2\b\b\u0002\u0010\"\u001a\u00020\bJ\u001e\u0010%\u001a\u00020 2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\b2\u0006\u0010\"\u001a\u00020\bJ\u0018\u0010&\u001a\u00020'2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010(\u001a\u00020\tH\u0002J\u0010\u0010)\u001a\u00020\b2\u0006\u0010*\u001a\u00020\bH\u0002J\u0010\u0010+\u001a\u00020,2\u0006\u0010\u001c\u001a\u00020\bH\u0002J\u0016\u0010-\u001a\u00020,2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010.\u001a\u00020/J\u000e\u00100\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u0013R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R.\u0010\u0006\u001a\"\u0012\u0004\u0012\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0007j\u0010\u0012\u0004\u0012\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\t`\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u000b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0\r0\f¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0014\u001a\u00020\u00158F¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R\u0014\u0010#\u001a\b\u0012\u0004\u0012\u00020\b0$X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00062"}, d2 = {"Lcom/exampletest/mobilestudiotest/ui/Icons;", "", "<init>", "()V", "dir", "Ljava/io/File;", "cache", "Ljava/util/HashMap;", "", "Landroid/graphics/Bitmap;", "Lkotlin/collections/HashMap;", "listeners", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lkotlin/Function0;", "", "getListeners", "()Ljava/util/concurrent/CopyOnWriteArrayList;", "init", "ctx", "Landroid/content/Context;", "installed", "", "getInstalled", "()Z", "load", "kind", "name", "instanceBitmap", "cls", "generalBitmap", "uiBitmap", "instance", "Landroid/graphics/drawable/Drawable;", "general", "fallback", "knownClassIcons", "", "ui", "pixelated", "Landroid/graphics/drawable/BitmapDrawable;", "b", "abbrev", "s", "categoryColor", "", "importZip", "input", "Ljava/io/InputStream;", "remove", "Badge", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Icons {
    private static File dir;
    public static final Icons INSTANCE = new Icons();
    private static final HashMap<String, Bitmap> cache = new HashMap<>();
    private static final CopyOnWriteArrayList<Function0<Unit>> listeners = new CopyOnWriteArrayList<>();
    private static final Set<String> knownClassIcons = SetsKt.setOf((Object[]) new String[]{"Script", "LocalScript", "ModuleScript", "Model", "Folder", "Plugin", "Humanoid", "Sound", "Decal"});

    private Icons() {
    }

    public final CopyOnWriteArrayList<Function0<Unit>> getListeners() {
        return listeners;
    }

    public final void init(Context ctx) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        if (dir == null) {
            dir = new File(ctx.getFilesDir(), "iconpack");
        }
    }

    public final boolean getInstalled() {
        File file = dir;
        if (file != null) {
            return new File(file, "general").isDirectory() || new File(file, "instance").isDirectory();
        }
        return false;
    }

    private final Bitmap load(String kind, String name) {
        boolean light = Ui.INSTANCE.getLIGHT();
        String key = (light ? "light/" : "") + kind + "/" + name;
        synchronized (cache) {
            if (cache.containsKey(key)) {
                return cache.get(key);
            }
            File file = dir;
            Bitmap bitmapDecodeFile = null;
            File file2 = file != null ? new File(file, key + ".png") : null;
            if (file2 != null && file2.isFile()) {
                try {
                    bitmapDecodeFile = BitmapFactory.decodeFile(file2.getPath());
                } catch (Throwable th) {
                }
            }
            cache.put(key, bitmapDecodeFile);
            return bitmapDecodeFile;
        }
    }

    public final Bitmap instanceBitmap(String cls) {
        Intrinsics.checkNotNullParameter(cls, "cls");
        String c = cls;
        int guard = 0;
        while (c != null) {
            int guard2 = guard + 1;
            if (guard < 12) {
                Bitmap bitmapLoad = load("instance", c);
                if (bitmapLoad != null) {
                    return bitmapLoad;
                }
                if (!Intrinsics.areEqual(c, "Instance")) {
                    c = ClassDb.INSTANCE.superclass(c);
                    guard = guard2;
                }
            }
            return null;
        }
        return null;
    }

    public final Bitmap generalBitmap(String name) {
        Intrinsics.checkNotNullParameter(name, "name");
        return load("general", name);
    }

    public final Bitmap uiBitmap(String name) {
        Intrinsics.checkNotNullParameter(name, "name");
        return load("ui", name);
    }

    public final Drawable instance(Context ctx, String cls) {
        BitmapDrawable bitmapDrawablePixelated;
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(cls, "cls");
        Bitmap bitmapInstanceBitmap = instanceBitmap(cls);
        if (bitmapInstanceBitmap != null && (bitmapDrawablePixelated = INSTANCE.pixelated(ctx, bitmapInstanceBitmap)) != null) {
            return bitmapDrawablePixelated;
        }
        Drawable drawableInstance = BuiltinIcons.INSTANCE.instance(cls);
        return drawableInstance == null ? new Badge(abbrev(cls), categoryColor(cls), false, 4, null) : drawableInstance;
    }

    public static /* synthetic */ Drawable general$default(Icons icons, Context context, String str, String str2, int i, Object obj) {
        if ((i & 4) != 0) {
            str2 = str;
        }
        return icons.general(context, str, str2);
    }

    public final Drawable general(Context ctx, String name, String fallback) {
        BitmapDrawable bitmapDrawablePixelated;
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(fallback, "fallback");
        Bitmap bitmapGeneralBitmap = generalBitmap(name);
        if (bitmapGeneralBitmap != null && (bitmapDrawablePixelated = INSTANCE.pixelated(ctx, bitmapGeneralBitmap)) != null) {
            return bitmapDrawablePixelated;
        }
        Drawable drawableGeneral = BuiltinIcons.INSTANCE.general(name);
        if (drawableGeneral != null) {
            return drawableGeneral;
        }
        Drawable drawableInstance = (ClassDb.INSTANCE.isServiceName(name) || knownClassIcons.contains(name)) ? BuiltinIcons.INSTANCE.instance(name) : null;
        return drawableInstance == null ? new Badge(abbrev(fallback), -10851459, false, 4, null) : drawableInstance;
    }

    public final Drawable ui(Context ctx, String name, String fallback) {
        Drawable badge;
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(fallback, "fallback");
        Bitmap bitmapUiBitmap = uiBitmap(name);
        if (bitmapUiBitmap == null || (badge = INSTANCE.pixelated(ctx, bitmapUiBitmap)) == null) {
            Drawable drawableUi = BuiltinIcons.INSTANCE.ui(name);
            if (drawableUi != null) {
                return drawableUi;
            }
            badge = new Badge(fallback, 0, true);
        }
        return badge;
    }

    private final BitmapDrawable pixelated(Context ctx, Bitmap b) {
        BitmapDrawable bitmapDrawable = new BitmapDrawable(ctx.getResources(), b);
        bitmapDrawable.setFilterBitmap(true);
        return bitmapDrawable;
    }

    private final String abbrev(String s) throws IOException {
        String str = s;
        Appendable sb = new StringBuilder();
        int i = 0;
        int length = str.length();
        while (true) {
            if (i >= length) {
                break;
            }
            char cCharAt = str.charAt(i);
            if (Character.isUpperCase(cCharAt) || Character.isDigit(cCharAt)) {
                sb.append(cCharAt);
            }
            i++;
        }
        String string = ((StringBuilder) sb).toString();
        if (string.length() >= 2) {
            return StringsKt.take(string, 2);
        }
        if (!(s.length() > 0)) {
            return "?";
        }
        String strTake = StringsKt.take(s, 2);
        if (!(strTake.length() > 0)) {
            return strTake;
        }
        StringBuilder sb2 = new StringBuilder();
        String strValueOf = String.valueOf(strTake.charAt(0));
        Intrinsics.checkNotNull(strValueOf, "null cannot be cast to non-null type java.lang.String");
        String upperCase = strValueOf.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        StringBuilder sbAppend = sb2.append((Object) upperCase);
        String strSubstring = strTake.substring(1);
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        return sbAppend.append(strSubstring).toString();
    }

    private final int categoryColor(String cls) {
        if (ClassDb.INSTANCE.isA(cls, "LuaSourceContainer")) {
            return -12944427;
        }
        if (ClassDb.INSTANCE.isA(cls, "BasePart")) {
            return -7566196;
        }
        if (ClassDb.INSTANCE.isA(cls, "GuiBase2d") || ClassDb.INSTANCE.isA(cls, "UIBase")) {
            return IconPainter.GUI;
        }
        if (Intrinsics.areEqual(cls, "Model") || Intrinsics.areEqual(cls, "Folder")) {
            return -3562969;
        }
        if (ClassDb.INSTANCE.isA(cls, "ValueBase")) {
            return -7443257;
        }
        return ClassDb.INSTANCE.isServiceName(cls) ? -11637624 : -9737365;
    }

    /* JADX INFO: compiled from: Icons.kt */
    @Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\u0010\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u0005H\u0016J\u0012\u0010\u0013\u001a\u00020\u000e2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0016J\b\u0010\u0016\u001a\u00020\u0005H\u0017J\b\u0010\u0017\u001a\u00020\u0005H\u0016J\b\u0010\u0018\u001a\u00020\u0005H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0019"}, d2 = {"Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;", "Landroid/graphics/drawable/Drawable;", "label", "", TypedValues.Custom.S_COLOR, "", "plain", "", "<init>", "(Ljava/lang/String;IZ)V", "bg", "Landroid/graphics/Paint;", "tp", "draw", "", "c", "Landroid/graphics/Canvas;", "setAlpha", "alpha", "setColorFilter", "cf", "Landroid/graphics/ColorFilter;", "getOpacity", "getIntrinsicWidth", "getIntrinsicHeight", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Badge extends Drawable {
        private final Paint bg;
        private final int color;
        private final String label;
        private final boolean plain;
        private final Paint tp;

        public Badge(String label, int color, boolean plain) {
            Intrinsics.checkNotNullParameter(label, "label");
            this.label = label;
            this.color = color;
            this.plain = plain;
            this.bg = new Paint(1);
            Paint paint = new Paint(1);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            this.tp = paint;
        }

        public /* synthetic */ Badge(String str, int i, boolean z, int i2, DefaultConstructorMarker defaultConstructorMarker) {
            this(str, i, (i2 & 4) != 0 ? false : z);
        }

        @Override // android.graphics.drawable.Drawable
        public void draw(Canvas c) {
            Intrinsics.checkNotNullParameter(c, "c");
            Rect b = getBounds();
            Intrinsics.checkNotNullExpressionValue(b, "getBounds(...)");
            RectF r = new RectF(b);
            float s = Math.min(r.width(), r.height());
            r.inset(((r.width() - s) / 2.0f) + (s * 0.06f), ((r.height() - s) / 2.0f) + (0.06f * s));
            if (!this.plain) {
                this.bg.setColor(this.color);
                c.drawRoundRect(r, s * 0.2f, 0.2f * s, this.bg);
            }
            this.tp.setColor(this.plain ? Ui.INSTANCE.getTEXT() : -1);
            this.tp.setTextSize((this.label.length() > 1 ? 0.42f : 0.6f) * s);
            c.drawText(this.label, r.centerX(), r.centerY() - ((this.tp.descent() + this.tp.ascent()) / 2.0f), this.tp);
        }

        @Override // android.graphics.drawable.Drawable
        public void setAlpha(int alpha) {
            this.bg.setAlpha(alpha);
            this.tp.setAlpha(alpha);
        }

        @Override // android.graphics.drawable.Drawable
        public void setColorFilter(ColorFilter cf) {
        }

        @Override // android.graphics.drawable.Drawable
        @Deprecated(message = "Deprecated in Java")
        public int getOpacity() {
            return -3;
        }

        @Override // android.graphics.drawable.Drawable
        public int getIntrinsicWidth() {
            return 32;
        }

        @Override // android.graphics.drawable.Drawable
        public int getIntrinsicHeight() {
            return 32;
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 4 */
    public final int importZip(Context ctx, InputStream input) throws IOException {
        Throwable th;
        List list;
        Object next;
        int count;
        Throwable th2;
        Throwable th3;
        Map map;
        Regex loose;
        Object next2;
        Object obj;
        Collection collection;
        Iterator it;
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(input, "input");
        init(ctx);
        File tmp = new File(ctx.getCacheDir(), "iconpack_import.zip");
        FileOutputStream fileOutputStream = new FileOutputStream(tmp);
        try {
            int i = 2;
            int i2 = 0;
            Object obj2 = null;
            ByteStreamsKt.copyTo$default(input, fileOutputStream, 0, 2, null);
            CloseableKt.closeFinally(fileOutputStream, null);
            Regex rx = new Regex("(?:^|/)(?:([^/]+)/)?(Dark|Light)/RobloxCustom/(instance|general|ui)/(16x|32x)/200/([^/]+)\\.png$", RegexOption.IGNORE_CASE);
            Regex loose2 = new Regex("(?:^|/)(instance|general|ui)/(16x|32x)/200/([^/]+)\\.png$", RegexOption.IGNORE_CASE);
            int count2 = 0;
            ZipFile zipFile = new ZipFile(tmp);
            try {
                ZipFile zipFile2 = zipFile;
                ArrayList arrayList = new ArrayList();
                Enumeration<? extends ZipEntry> enumerationEntries = zipFile2.entries();
                Intrinsics.checkNotNullExpressionValue(enumerationEntries, "entries(...)");
                Iterator it2 = CollectionsKt.iterator(enumerationEntries);
                while (it2.hasNext()) {
                    try {
                        final ZipEntry zipEntry = (ZipEntry) it2.next();
                        if (zipEntry.isDirectory()) {
                            i = 2;
                            i2 = 0;
                            obj2 = null;
                        } else {
                            String name = zipEntry.getName();
                            Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                            String strReplace$default = StringsKt.replace$default(name, '\\', '/', false, 4, (Object) null);
                            MatchResult matchResultFind$default = Regex.find$default(rx, strReplace$default, i2, i, obj2);
                            if (matchResultFind$default != null) {
                                final String str = matchResultFind$default.getGroupValues().get(1);
                                final String str2 = matchResultFind$default.getGroupValues().get(i);
                                final String lowerCase = matchResultFind$default.getGroupValues().get(3).toLowerCase(Locale.ROOT);
                                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                final String lowerCase2 = matchResultFind$default.getGroupValues().get(4).toLowerCase(Locale.ROOT);
                                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                                it = it2;
                                final String str3 = matchResultFind$default.getGroupValues().get(5);
                                Intrinsics.checkNotNull(zipEntry);
                                Boolean.valueOf(arrayList.add(new Object(str, str2, lowerCase, lowerCase2, str3, zipEntry) { // from class: com.exampletest.mobilestudiotest.ui.Icons$importZip$2$E
                                    private final ZipEntry entry;
                                    private final String kind;
                                    private final String name;
                                    private final String palette;
                                    private final String res;
                                    private final String theme;

                                    {
                                        Intrinsics.checkNotNullParameter(str, "palette");
                                        Intrinsics.checkNotNullParameter(str2, "theme");
                                        Intrinsics.checkNotNullParameter(lowerCase, "kind");
                                        Intrinsics.checkNotNullParameter(lowerCase2, "res");
                                        Intrinsics.checkNotNullParameter(str3, "name");
                                        Intrinsics.checkNotNullParameter(zipEntry, "entry");
                                        this.palette = str;
                                        this.theme = str2;
                                        this.kind = lowerCase;
                                        this.res = lowerCase2;
                                        this.name = str3;
                                        this.entry = zipEntry;
                                    }

                                    public final ZipEntry getEntry() {
                                        return this.entry;
                                    }

                                    public final String getKind() {
                                        return this.kind;
                                    }

                                    public final String getName() {
                                        return this.name;
                                    }

                                    public final String getPalette() {
                                        return this.palette;
                                    }

                                    public final String getRes() {
                                        return this.res;
                                    }

                                    public final String getTheme() {
                                        return this.theme;
                                    }
                                }));
                            } else {
                                it = it2;
                                MatchResult matchResultFind$default2 = Regex.find$default(loose2, strReplace$default, 0, 2, null);
                                if (matchResultFind$default2 != null) {
                                    final String str4 = "";
                                    final String str5 = "Dark";
                                    final String lowerCase3 = matchResultFind$default2.getGroupValues().get(1).toLowerCase(Locale.ROOT);
                                    Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                                    final String lowerCase4 = matchResultFind$default2.getGroupValues().get(2).toLowerCase(Locale.ROOT);
                                    Intrinsics.checkNotNullExpressionValue(lowerCase4, "toLowerCase(...)");
                                    final String str6 = matchResultFind$default2.getGroupValues().get(3);
                                    Intrinsics.checkNotNull(zipEntry);
                                    Boolean.valueOf(arrayList.add(new Object(str4, str5, lowerCase3, lowerCase4, str6, zipEntry) { // from class: com.exampletest.mobilestudiotest.ui.Icons$importZip$2$E
                                        private final ZipEntry entry;
                                        private final String kind;
                                        private final String name;
                                        private final String palette;
                                        private final String res;
                                        private final String theme;

                                        {
                                            Intrinsics.checkNotNullParameter(str4, "palette");
                                            Intrinsics.checkNotNullParameter(str5, "theme");
                                            Intrinsics.checkNotNullParameter(lowerCase3, "kind");
                                            Intrinsics.checkNotNullParameter(lowerCase4, "res");
                                            Intrinsics.checkNotNullParameter(str6, "name");
                                            Intrinsics.checkNotNullParameter(zipEntry, "entry");
                                            this.palette = str4;
                                            this.theme = str5;
                                            this.kind = lowerCase3;
                                            this.res = lowerCase4;
                                            this.name = str6;
                                            this.entry = zipEntry;
                                        }

                                        public final ZipEntry getEntry() {
                                            return this.entry;
                                        }

                                        public final String getKind() {
                                            return this.kind;
                                        }

                                        public final String getName() {
                                            return this.name;
                                        }

                                        public final String getPalette() {
                                            return this.palette;
                                        }

                                        public final String getRes() {
                                            return this.res;
                                        }

                                        public final String getTheme() {
                                            return this.theme;
                                        }
                                    }));
                                }
                            }
                            it2 = it;
                            i = 2;
                            i2 = 0;
                            obj2 = null;
                        }
                    } catch (Throwable th4) {
                        th = th4;
                    }
                }
                try {
                    if (arrayList.isEmpty()) {
                        throw new IllegalArgumentException("No Vanilla icons found in this zip. Pick the \"Vanilla 3 for Roblox Studio\" zip from itch.io.");
                    }
                    ArrayList arrayList2 = arrayList;
                    Collection arrayList3 = new ArrayList();
                    for (Object obj3 : arrayList2) {
                        Iterable iterable = arrayList2;
                        if (StringsKt.equals(((Icons$importZip$2$E) obj3).getTheme(), "Dark", true)) {
                            arrayList3.add(obj3);
                        }
                        arrayList2 = iterable;
                    }
                    List list2 = (List) arrayList3;
                    if (list2.isEmpty()) {
                        list2 = arrayList;
                    }
                    List list3 = list2;
                    List list4 = list3;
                    Collection arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list4, 10));
                    Iterator it3 = list4.iterator();
                    while (it3.hasNext()) {
                        Iterable iterable2 = list4;
                        arrayList4.add(((Icons$importZip$2$E) it3.next()).getPalette());
                        list4 = iterable2;
                    }
                    List listDistinct = CollectionsKt.distinct((List) arrayList4);
                    List list5 = listDistinct;
                    Iterator it4 = list5.iterator();
                    while (true) {
                        if (!it4.hasNext()) {
                            list = list3;
                            next = null;
                            break;
                        }
                        next = it4.next();
                        Iterable iterable3 = list5;
                        list = list3;
                        if (StringsKt.equals((String) next, "Colourful", true)) {
                            break;
                        }
                        list5 = iterable3;
                        list3 = list;
                    }
                    String str7 = (String) next;
                    if (str7 == null) {
                        str7 = (String) CollectionsKt.first(listDistinct);
                    }
                    File file = new File(ctx.getFilesDir(), "iconpack.new");
                    FilesKt.deleteRecursively(file);
                    Pair[] pairArr = new Pair[2];
                    Collection arrayList5 = new ArrayList();
                    for (Object obj4 : list) {
                        List list6 = listDistinct;
                        if (Intrinsics.areEqual(((Icons$importZip$2$E) obj4).getPalette(), str7)) {
                            arrayList5.add(obj4);
                        }
                        listDistinct = list6;
                    }
                    pairArr[0] = TuplesKt.to("", (List) arrayList5);
                    ArrayList arrayList6 = arrayList;
                    Collection arrayList7 = new ArrayList();
                    for (Object obj5 : arrayList6) {
                        try {
                            Icons$importZip$2$E icons$importZip$2$E = (Icons$importZip$2$E) obj5;
                            Iterable iterable4 = arrayList6;
                            File tmp2 = tmp;
                            Regex rx2 = rx;
                            try {
                                if (StringsKt.equals(icons$importZip$2$E.getTheme(), "Light", true) && Intrinsics.areEqual(icons$importZip$2$E.getPalette(), str7)) {
                                    arrayList7.add(obj5);
                                }
                                arrayList6 = iterable4;
                                tmp = tmp2;
                                rx = rx2;
                            } catch (Throwable th5) {
                                th = th5;
                            }
                        } catch (Throwable th6) {
                            th = th6;
                        }
                    }
                    File tmp3 = tmp;
                    try {
                        pairArr[1] = TuplesKt.to("light/", (List) arrayList7);
                        List listListOf = CollectionsKt.listOf((Object[]) pairArr);
                        Iterator it5 = listListOf.iterator();
                        while (it5.hasNext()) {
                            Pair pair = (Pair) it5.next();
                            String str8 = (String) pair.component1();
                            List list7 = (List) pair.component2();
                            for (String str9 : CollectionsKt.listOf((Object[]) new String[]{"instance", "general", "ui"})) {
                                Collection arrayList8 = new ArrayList();
                                for (Object obj6 : list7) {
                                    if (Intrinsics.areEqual(((Icons$importZip$2$E) obj6).getKind(), str9)) {
                                        collection = arrayList8;
                                        collection.add(obj6);
                                    } else {
                                        collection = arrayList8;
                                    }
                                    it5 = it5;
                                    arrayList8 = collection;
                                }
                                Collection collection2 = arrayList8;
                                it5 = it5;
                                List list8 = (List) collection2;
                                if (list8.isEmpty()) {
                                    loose2 = loose2;
                                } else {
                                    List list9 = list8;
                                    Map linkedHashMap = new LinkedHashMap();
                                    for (Object obj7 : list9) {
                                        String name2 = ((Icons$importZip$2$E) obj7).getName();
                                        Iterable iterable5 = list9;
                                        List list10 = listListOf;
                                        Object obj8 = linkedHashMap.get(name2);
                                        if (obj8 == null) {
                                            ArrayList arrayList9 = new ArrayList();
                                            linkedHashMap.put(name2, arrayList9);
                                            obj = arrayList9;
                                        } else {
                                            obj = obj8;
                                        }
                                        ((List) obj).add(obj7);
                                        listListOf = list10;
                                        list9 = iterable5;
                                        list7 = list7;
                                    }
                                    List list11 = listListOf;
                                    List list12 = list7;
                                    int i3 = 0;
                                    Map linkedHashMap2 = new LinkedHashMap(MapsKt.mapCapacity(linkedHashMap.size()));
                                    Map map2 = linkedHashMap;
                                    for (Object obj9 : map2.entrySet()) {
                                        int i4 = i3;
                                        Object key = ((Map.Entry) obj9).getKey();
                                        List list13 = (List) ((Map.Entry) obj9).getValue();
                                        Iterator it6 = list13.iterator();
                                        while (true) {
                                            if (!it6.hasNext()) {
                                                map = map2;
                                                loose = loose2;
                                                next2 = null;
                                                break;
                                            }
                                            next2 = it6.next();
                                            map = map2;
                                            loose = loose2;
                                            if (Intrinsics.areEqual(((Icons$importZip$2$E) next2).getRes(), "32x")) {
                                                break;
                                            }
                                            map2 = map;
                                            loose2 = loose;
                                        }
                                        Icons$importZip$2$E icons$importZip$2$E2 = (Icons$importZip$2$E) next2;
                                        if (icons$importZip$2$E2 == null) {
                                            icons$importZip$2$E2 = (Icons$importZip$2$E) CollectionsKt.first(list13);
                                        }
                                        linkedHashMap2.put(key, icons$importZip$2$E2);
                                        i3 = i4;
                                        map2 = map;
                                        loose2 = loose;
                                    }
                                    Regex loose3 = loose2;
                                    File file2 = new File(file, str8 + str9);
                                    file2.mkdirs();
                                    File file3 = file2;
                                    Iterator it7 = linkedHashMap2.entrySet().iterator();
                                    while (it7.hasNext()) {
                                        try {
                                            Map.Entry entry = (Map.Entry) it7.next();
                                            String str10 = (String) entry.getKey();
                                            it7 = it7;
                                            linkedHashMap2 = linkedHashMap2;
                                            InputStream inputStream = zipFile2.getInputStream(((Icons$importZip$2$E) entry.getValue()).getEntry());
                                            try {
                                                InputStream inputStream2 = inputStream;
                                                str8 = str8;
                                                try {
                                                    try {
                                                        count = count2;
                                                        try {
                                                            FileOutputStream fileOutputStream2 = new FileOutputStream(new File(file3, str10 + ".png"));
                                                            try {
                                                                Intrinsics.checkNotNull(inputStream2);
                                                                file3 = file3;
                                                                list8 = list8;
                                                                try {
                                                                    ByteStreamsKt.copyTo$default(inputStream2, fileOutputStream2, 0, 2, null);
                                                                    try {
                                                                        CloseableKt.closeFinally(fileOutputStream2, null);
                                                                        try {
                                                                            CloseableKt.closeFinally(inputStream, null);
                                                                            count2 = str8.length() == 0 ? count + 1 : count;
                                                                        } catch (Throwable th7) {
                                                                            th = th7;
                                                                        }
                                                                    } catch (Throwable th8) {
                                                                        th2 = th8;
                                                                        try {
                                                                            throw th2;
                                                                        } catch (Throwable th9) {
                                                                            CloseableKt.closeFinally(inputStream, th2);
                                                                            throw th9;
                                                                        }
                                                                    }
                                                                } catch (Throwable th10) {
                                                                    th3 = th10;
                                                                    try {
                                                                        throw th3;
                                                                    } catch (Throwable th11) {
                                                                        CloseableKt.closeFinally(fileOutputStream2, th3);
                                                                        throw th11;
                                                                    }
                                                                }
                                                            } catch (Throwable th12) {
                                                                th3 = th12;
                                                            }
                                                        } catch (Throwable th13) {
                                                            th2 = th13;
                                                        }
                                                    } catch (Throwable th14) {
                                                        count = count2;
                                                        th2 = th14;
                                                    }
                                                } catch (Throwable th15) {
                                                    count = count2;
                                                    th2 = th15;
                                                }
                                            } catch (Throwable th16) {
                                                count = count2;
                                                th2 = th16;
                                            }
                                        } catch (Throwable th17) {
                                            th = th17;
                                        }
                                    }
                                    listListOf = list11;
                                    list7 = list12;
                                    loose2 = loose3;
                                }
                            }
                            it5 = it5;
                            loose2 = loose2;
                        }
                        File file4 = new File(ctx.getFilesDir(), "iconpack");
                        FilesKt.deleteRecursively(file4);
                        file.renameTo(file4);
                        Icons icons = INSTANCE;
                        dir = file4;
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(zipFile, null);
                        tmp3.delete();
                        synchronized (cache) {
                            cache.clear();
                            Unit unit2 = Unit.INSTANCE;
                        }
                        Iterator it8 = listeners.iterator();
                        while (it8.hasNext()) {
                            ((Function0) it8.next()).invoke();
                        }
                        return count2;
                    } catch (Throwable th18) {
                        th = th18;
                    }
                } catch (Throwable th19) {
                    th = th19;
                }
            } catch (Throwable th20) {
                th = th20;
            }
            try {
                throw th;
            } catch (Throwable th21) {
                CloseableKt.closeFinally(zipFile, th);
                throw th21;
            }
        } catch (Throwable th22) {
            try {
                throw th22;
            } catch (Throwable th23) {
                CloseableKt.closeFinally(fileOutputStream, th22);
                throw th23;
            }
        }
    }

    public final void remove(Context ctx) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        FilesKt.deleteRecursively(new File(ctx.getFilesDir(), "iconpack"));
        synchronized (cache) {
            cache.clear();
            Unit unit = Unit.INSTANCE;
        }
        Iterator it = listeners.iterator();
        while (it.hasNext()) {
            ((Function0) it.next()).invoke();
        }
    }
}
