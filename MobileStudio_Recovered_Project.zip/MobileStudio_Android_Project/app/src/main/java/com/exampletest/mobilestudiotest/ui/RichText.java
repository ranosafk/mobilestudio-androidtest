package com.exampletest.mobilestudiotest.ui;

import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import androidx.core.view.ViewCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: GuiOverlay.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000'\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\b\u0003\n\u0002\u0010\r\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006*\u0001\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ\u0017\u0010\u000b\u001a\u0004\u0018\u00010\f2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0002\u0010\u000eJ\u0010\u0010\u000f\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002J\u0010\u0010\u0010\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\nH\u0002R\u0010\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0006¨\u0006\u0012"}, d2 = {"Lcom/exampletest/mobilestudiotest/ui/RichText;", "", "<init>", "()V", "cache", "com/exampletest/mobilestudiotest/ui/RichText$cache$1", "Lcom/exampletest/mobilestudiotest/ui/RichText$cache$1;", "parse", "", "src", "", "parseColor", "", "v", "(Ljava/lang/String;)Ljava/lang/Integer;", "build", "decode", "s", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class RichText {
    public static final RichText INSTANCE = new RichText();
    private static final RichText$cache$1 cache = new LinkedHashMap<String, CharSequence>() { // from class: com.exampletest.mobilestudiotest.ui.RichText$cache$1
        @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ boolean containsKey(Object key) {
            if (key instanceof String) {
                return containsKey((String) key);
            }
            return false;
        }

        public /* bridge */ boolean containsKey(String p0) {
            return super.containsKey((Object) p0);
        }

        public /* bridge */ boolean containsValue(CharSequence p0) {
            return super.containsValue((Object) p0);
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ boolean containsValue(Object value) {
            if (value instanceof CharSequence) {
                return containsValue((CharSequence) value);
            }
            return false;
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ Set<Map.Entry<String, CharSequence>> entrySet() {
            return getEntries();
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ CharSequence get(Object key) {
            if (key instanceof String) {
                return get((String) key);
            }
            return null;
        }

        public /* bridge */ CharSequence get(String p0) {
            return (CharSequence) super.get((Object) p0);
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ /* synthetic */ Object get(Object key) {
            if (key instanceof String) {
                return get((String) key);
            }
            return null;
        }

        public /* bridge */ Set<Map.Entry<String, CharSequence>> getEntries() {
            return super.entrySet();
        }

        public /* bridge */ Set<String> getKeys() {
            return super.keySet();
        }

        public final /* bridge */ CharSequence getOrDefault(Object key, CharSequence defaultValue) {
            return !(key instanceof String) ? defaultValue : getOrDefault((String) key, defaultValue);
        }

        public /* bridge */ CharSequence getOrDefault(String p0, CharSequence p1) {
            return (CharSequence) super.getOrDefault((Object) p0, p1);
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.Map
        public final /* bridge */ /* synthetic */ Object getOrDefault(Object key, Object defaultValue) {
            return !(key instanceof String) ? defaultValue : getOrDefault((String) key, (CharSequence) defaultValue);
        }

        public /* bridge */ int getSize() {
            return super.size();
        }

        public /* bridge */ Collection<CharSequence> getValues() {
            return super.values();
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ Set<String> keySet() {
            return getKeys();
        }

        @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ CharSequence remove(Object key) {
            if (key instanceof String) {
                return remove((String) key);
            }
            return null;
        }

        public /* bridge */ CharSequence remove(String p0) {
            return (CharSequence) super.remove((Object) p0);
        }

        @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ /* synthetic */ Object remove(Object key) {
            if (key instanceof String) {
                return remove((String) key);
            }
            return null;
        }

        @Override // java.util.HashMap, java.util.Map
        public final /* bridge */ boolean remove(Object key, Object value) {
            if ((key instanceof String) && (value instanceof CharSequence)) {
                return remove((String) key, (CharSequence) value);
            }
            return false;
        }

        public /* bridge */ boolean remove(String p0, CharSequence p1) {
            return super.remove((Object) p0, (Object) p1);
        }

        @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ int size() {
            return getSize();
        }

        @Override // java.util.LinkedHashMap, java.util.HashMap, java.util.AbstractMap, java.util.Map
        public final /* bridge */ Collection<CharSequence> values() {
            return getValues();
        }

        @Override // java.util.LinkedHashMap
        protected boolean removeEldestEntry(Map.Entry<String, CharSequence> eldest) {
            return size() > 200;
        }
    };

    private RichText() {
    }

    public final CharSequence parse(String src) {
        CharSequence charSequenceBuild;
        CharSequence charSequence;
        Intrinsics.checkNotNullParameter(src, "src");
        synchronized (cache) {
            Map map = cache;
            CharSequence charSequence2 = map.get(src);
            if (charSequence2 == null) {
                charSequenceBuild = INSTANCE.build(src);
                map.put(src, charSequenceBuild);
            } else {
                charSequenceBuild = charSequence2;
            }
            charSequence = charSequenceBuild;
        }
        return charSequence;
    }

    private final Integer parseColor(String v) {
        String s = StringsKt.trim((CharSequence) v).toString();
        if (StringsKt.startsWith$default(s, "#", false, 2, (Object) null)) {
            Long longOrNull = StringsKt.toLongOrNull(StringsKt.removePrefix(s, (CharSequence) "#"), 16);
            if (longOrNull != null) {
                return Integer.valueOf((int) (4278190080L | longOrNull.longValue()));
            }
            return null;
        }
        MatchResult matchResultFind$default = Regex.find$default(new Regex("rgb\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)\\s*\\)"), s, 0, 2, null);
        if (matchResultFind$default == null) {
            return null;
        }
        MatchResult.Destructured destructured = matchResultFind$default.getDestructured();
        return Integer.valueOf((RangesKt.coerceIn(Integer.parseInt(destructured.getMatch().getGroupValues().get(1)), 0, 255) << 16) | ViewCompat.MEASURED_STATE_MASK | (RangesKt.coerceIn(Integer.parseInt(destructured.getMatch().getGroupValues().get(2)), 0, 255) << 8) | RangesKt.coerceIn(Integer.parseInt(destructured.getMatch().getGroupValues().get(3)), 0, 255));
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:35:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:49:0x0124  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final CharSequence build(String src) {
        int idx;
        Object span;
        MatchResult matchResultFind$default;
        Integer color;
        IntRange range;
        SpannableStringBuilder out = new SpannableStringBuilder();
        ArrayList stack = new ArrayList();
        int i = 0;
        Regex tag = new Regex("<\\s*(/?)\\s*([a-zA-Z]+)([^>]*)>");
        while (i < src.length()) {
            MatchResult m = tag.find(src, i);
            int end = (m == null || (range = m.getRange()) == null) ? src.length() : range.getFirst();
            if (end > i) {
                String strSubstring = src.substring(i, end);
                Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                out.append((CharSequence) decode(strSubstring));
            }
            if (m == null) {
                break;
            }
            boolean closing = Intrinsics.areEqual(m.getGroupValues().get(1), "/");
            String name = m.getGroupValues().get(2).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(name, "toLowerCase(...)");
            String attrs = m.getGroupValues().get(3);
            if (Intrinsics.areEqual(name, "br")) {
                out.append('\n');
            } else if (closing) {
                List list = stack;
                ListIterator listIterator = list.listIterator(list.size());
                while (true) {
                    if (!listIterator.hasPrevious()) {
                        idx = -1;
                        break;
                    }
                    if (Intrinsics.areEqual(((Pair) listIterator.previous()).getFirst(), name)) {
                        idx = listIterator.nextIndex();
                        break;
                    }
                }
                if (idx >= 0) {
                    Object objRemove = stack.remove(idx);
                    Intrinsics.checkNotNullExpressionValue(objRemove, "removeAt(...)");
                    Pair info = (Pair) ((Pair) objRemove).component2();
                    Object second = info.getSecond();
                    if (second != null) {
                        out.setSpan(second, ((Number) info.getFirst()).intValue(), out.length(), 33);
                    }
                }
            } else {
                switch (name.hashCode()) {
                    case 98:
                        if (name.equals("b")) {
                            span = new StyleSpan(1);
                        }
                        break;
                    case 105:
                        if (name.equals("i")) {
                            span = new StyleSpan(2);
                        }
                        break;
                    case 115:
                        if (name.equals("s")) {
                            span = new StrikethroughSpan();
                        }
                        break;
                    case 117:
                        if (name.equals("u")) {
                            span = new UnderlineSpan();
                        }
                        break;
                    case 3726:
                        if (name.equals("uc")) {
                            span = null;
                        }
                        break;
                    case 3148879:
                        span = (name.equals("font") && (matchResultFind$default = Regex.find$default(new Regex("color\\s*=\\s*[\"']([^\"']+)[\"']"), attrs, 0, 2, null)) != null && (color = INSTANCE.parseColor(matchResultFind$default.getGroupValues().get(1))) != null) ? new ForegroundColorSpan(color.intValue()) : null;
                        break;
                    case 223523538:
                        if (name.equals("uppercase")) {
                            span = null;
                        }
                        break;
                    default:
                        span = null;
                        break;
                }
                stack.add(TuplesKt.to(name, TuplesKt.to(Integer.valueOf(out.length()), span)));
            }
            i = m.getRange().getLast() + 1;
            stack = stack;
        }
        Iterator it = stack.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (it.hasNext()) {
            Object next = it.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            Pair info2 = (Pair) ((Pair) next).component2();
            Object second2 = info2.getSecond();
            if (second2 != null) {
                out.setSpan(second2, ((Number) info2.getFirst()).intValue(), out.length(), 33);
            }
        }
        return out;
    }

    private final String decode(String s) {
        return StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(s, "&lt;", "<", false, 4, (Object) null), "&gt;", ">", false, 4, (Object) null), "&quot;", "\"", false, 4, (Object) null), "&apos;", "'", false, 4, (Object) null), "&amp;", "&", false, 4, (Object) null);
    }
}
