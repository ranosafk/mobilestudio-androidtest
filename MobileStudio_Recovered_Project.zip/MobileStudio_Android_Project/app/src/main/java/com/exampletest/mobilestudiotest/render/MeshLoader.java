package com.exampletest.mobilestudiotest.render;

import com.exampletest.mobilestudiotest.core.OutputLog;
import com.exampletest.mobilestudiotest.format.RbxDocument;
import com.exampletest.mobilestudiotest.format.RbxFile;
import com.exampletest.mobilestudiotest.model.Instance;
import com.exampletest.mobilestudiotest.model.PartData;
import com.exampletest.mobilestudiotest.net.AssetFetcher;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: RbxMesh.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u0012\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u001b\u001a\u00020\u0006J\u000e\u0010\u001d\u001a\u00020\u000b2\u0006\u0010\u001b\u001a\u00020\u0006J\u001a\u0010\u001e\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u001b\u001a\u00020\u00062\u0006\u0010\u001f\u001a\u00020 H\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010\b\u001aB\u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\f\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b \n* \u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\f\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b\u0018\u00010\t0\tX\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010\f\u001aB\u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\f\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b \n* \u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\f\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b\u0018\u00010\t0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\r\u001a\n \n*\u0004\u0018\u00010\u000e0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R#\u0010\u000f\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00120\u00110\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u001e\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0015\u001a\u00020\u0016@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u000e\u0010\u001c\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006!"}, d2 = {"Lcom/exampletest/mobilestudiotest/render/MeshLoader;", "", "<init>", "()V", "ready", "Ljava/util/concurrent/ConcurrentHashMap;", "", "Lcom/exampletest/mobilestudiotest/render/MeshData;", "bad", "Ljava/util/concurrent/ConcurrentHashMap$KeySetView;", "kotlin.jvm.PlatformType", "", "pending", "pool", "Ljava/util/concurrent/ExecutorService;", "listeners", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lkotlin/Function1;", "", "getListeners", "()Ljava/util/concurrent/CopyOnWriteArrayList;", "value", "", "epoch", "getEpoch", "()I", "get", "id", "waiting", "isBad", "meshInsideModel", "bytes", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class MeshLoader {
    private static volatile int epoch;
    private static volatile boolean waiting;
    public static final MeshLoader INSTANCE = new MeshLoader();
    private static final ConcurrentHashMap<Long, MeshData> ready = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap.KeySetView<Long, Boolean> bad = ConcurrentHashMap.newKeySet();
    private static final ConcurrentHashMap.KeySetView<Long, Boolean> pending = ConcurrentHashMap.newKeySet();
    private static final ExecutorService pool = Executors.newSingleThreadExecutor();
    private static final CopyOnWriteArrayList<Function1<Long, Unit>> listeners = new CopyOnWriteArrayList<>();

    private MeshLoader() {
    }

    public final CopyOnWriteArrayList<Function1<Long, Unit>> getListeners() {
        return listeners;
    }

    public final int getEpoch() {
        return epoch;
    }

    public final MeshData get(final long id) {
        MeshData meshData = ready.get(Long.valueOf(id));
        if (meshData != null) {
            return meshData;
        }
        if (bad.contains(Long.valueOf(id)) || !pending.add(Long.valueOf(id))) {
            return null;
        }
        final byte[] bytes = AssetFetcher.INSTANCE.request(id);
        if (bytes == null) {
            pending.remove(Long.valueOf(id));
            if (!waiting) {
                waiting = true;
                AssetFetcher.INSTANCE.getListeners().add(new Function1() { // from class: com.exampletest.mobilestudiotest.render.MeshLoader$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return MeshLoader.get$lambda$1(((Long) obj).longValue());
                    }
                });
            }
            return null;
        }
        pool.execute(new Runnable() { // from class: com.exampletest.mobilestudiotest.render.MeshLoader$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                MeshLoader.get$lambda$3(id, bytes);
            }
        });
        return null;
    }

    static final Unit get$lambda$1(long done) {
        if (!ready.containsKey(Long.valueOf(done)) && !bad.contains(Long.valueOf(done))) {
            MeshLoader meshLoader = INSTANCE;
            int i = epoch;
            MeshLoader meshLoader2 = INSTANCE;
            epoch = i + 1;
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:25:0x0077 A[Catch: all -> 0x00de, TryCatch #2 {all -> 0x00de, blocks: (B:2:0x0001, B:3:0x0009, B:9:0x001a, B:6:0x0011, B:16:0x0055, B:18:0x0057, B:20:0x0064, B:23:0x006c, B:25:0x0077, B:27:0x007f, B:29:0x0085, B:28:0x0082), top: B:46:0x0001, inners: #1 }] */
    /* JADX WARN: Code duplicated, block: B:27:0x007f A[Catch: all -> 0x00de, TryCatch #2 {all -> 0x00de, blocks: (B:2:0x0001, B:3:0x0009, B:9:0x001a, B:6:0x0011, B:16:0x0055, B:18:0x0057, B:20:0x0064, B:23:0x006c, B:25:0x0077, B:27:0x007f, B:29:0x0085, B:28:0x0082), top: B:46:0x0001, inners: #1 }] */
    /* JADX WARN: Code duplicated, block: B:28:0x0082 A[Catch: all -> 0x00de, TryCatch #2 {all -> 0x00de, blocks: (B:2:0x0001, B:3:0x0009, B:9:0x001a, B:6:0x0011, B:16:0x0055, B:18:0x0057, B:20:0x0064, B:23:0x006c, B:25:0x0077, B:27:0x007f, B:29:0x0085, B:28:0x0082), top: B:46:0x0001, inners: #1 }] */
    static final void get$lambda$3(long $id, byte[] $bytes) {
        String message;
        Exception exc;
        MeshData meshData;
        try {
            try {
                ConcurrentHashMap<Long, MeshData> concurrentHashMap = ready;
                Long lValueOf = Long.valueOf($id);
                try {
                    meshData = RbxMesh.INSTANCE.parse($bytes);
                } catch (Exception e) {
                    MeshData meshDataMeshInsideModel = INSTANCE.meshInsideModel($id, $bytes);
                    if (meshDataMeshInsideModel == null) {
                        throw e;
                    }
                    meshData = meshDataMeshInsideModel;
                }
                concurrentHashMap.put(lValueOf, meshData);
                pending.remove(Long.valueOf($id));
                MeshLoader meshLoader = INSTANCE;
                int i = epoch;
                MeshLoader meshLoader2 = INSTANCE;
                epoch = i + 1;
                MeshLoader meshLoader3 = INSTANCE;
                Iterator it = listeners.iterator();
                while (it.hasNext()) {
                    ((Function1) it.next()).invoke(Long.valueOf($id));
                }
            } catch (Exception e2) {
                bad.add(Long.valueOf($id));
                if (e2 instanceof RbxMesh.UnsupportedMesh) {
                    String message2 = e2.getMessage();
                    if (message2 == null) {
                        message2 = "";
                    }
                    if (!StringsKt.startsWith$default(message2, "not a", false, 2, (Object) null)) {
                        OutputLog outputLog = OutputLog.INSTANCE;
                        message = e2.getMessage();
                        if (message != null) {
                            exc = message;
                        } else {
                            exc = e2;
                        }
                        outputLog.warn("Mesh " + $id + ": " + exc);
                    }
                } else {
                    OutputLog outputLog2 = OutputLog.INSTANCE;
                    message = e2.getMessage();
                    if (message != null) {
                        exc = message;
                    } else {
                        exc = e2;
                    }
                    outputLog2.warn("Mesh " + $id + ": " + exc);
                }
                pending.remove(Long.valueOf($id));
                MeshLoader meshLoader4 = INSTANCE;
                int i2 = epoch;
                MeshLoader meshLoader5 = INSTANCE;
                epoch = i2 + 1;
                MeshLoader meshLoader6 = INSTANCE;
                Iterator it2 = listeners.iterator();
                while (it2.hasNext()) {
                    ((Function1) it2.next()).invoke(Long.valueOf($id));
                }
            }
        } catch (Throwable th) {
            pending.remove(Long.valueOf($id));
            MeshLoader meshLoader7 = INSTANCE;
            int i3 = epoch;
            MeshLoader meshLoader8 = INSTANCE;
            epoch = i3 + 1;
            MeshLoader meshLoader9 = INSTANCE;
            Iterator it3 = listeners.iterator();
            while (it3.hasNext()) {
                ((Function1) it3.next()).invoke(Long.valueOf($id));
            }
            throw th;
        }
    }

    public final boolean isBad(long id) {
        return bad.contains(Long.valueOf(id));
    }

    private final MeshData meshInsideModel(long id, byte[] bytes) {
        try {
            RbxDocument doc = RbxFile.INSTANCE.read(bytes);
            for (Instance r : doc.getRoots()) {
                for (Instance i : CollectionsKt.plus((Collection) CollectionsKt.listOf(r), (Iterable) Instance.descendants$default(r, null, 1, null))) {
                    Long lIdOf = AssetFetcher.INSTANCE.idOf(PartData.INSTANCE.meshContent(i));
                    if (lIdOf != null) {
                        long inner = lIdOf.longValue();
                        if (inner != id) {
                            try {
                                return RbxMesh.INSTANCE.parse(AssetFetcher.INSTANCE.load(inner));
                            } catch (Exception e) {
                                return null;
                            }
                        }
                    }
                }
            }
            return null;
        } catch (Exception e2) {
            return null;
        }
    }
}
