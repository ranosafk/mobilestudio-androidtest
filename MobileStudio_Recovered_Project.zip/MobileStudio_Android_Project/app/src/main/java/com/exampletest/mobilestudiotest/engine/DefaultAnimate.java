package com.exampletest.mobilestudiotest.engine;

import com.exampletest.mobilestudiotest.core.OutputLog;
import com.exampletest.mobilestudiotest.model.CFrame;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: KeyframeAnim.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001:\u0001.B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0012\u0010\u001d\u001a\u0004\u0018\u00010\u001e2\u0006\u0010\u001f\u001a\u00020\nH\u0002J\u0018\u0010 \u001a\u00020!2\u0006\u0010\u001f\u001a\u00020\n2\u0006\u0010\"\u001a\u00020#H\u0002J8\u0010$\u001a\u00020!2\u0006\u0010%\u001a\u00020#2\u0006\u0010&\u001a\u00020\n2\u0006\u0010'\u001a\u00020#2\u0006\u0010(\u001a\u00020\u00032\b\u0010)\u001a\u0004\u0018\u00010\n2\u0006\u0010*\u001a\u00020#J\u0010\u0010+\u001a\u0004\u0018\u00010,2\u0006\u0010-\u001a\u00020\nR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u000b0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0010\u001a\u0012\u0012\u0004\u0012\u00020\u00120\u0011j\b\u0012\u0004\u0012\u00020\u0012`\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u001a\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\u001b\u0010\u001c¨\u0006/"}, d2 = {"Lcom/exampletest/mobilestudiotest/engine/DefaultAnimate;", "", "r15", "", "<init>", "(Z)V", "player", "Lcom/exampletest/mobilestudiotest/engine/AnimPlayer;", "sets", "", "", "", "Lcom/exampletest/mobilestudiotest/engine/DefaultAnimate$Entry;", "rnd", "Ljava/util/Random;", "current", "currentTracks", "Ljava/util/ArrayList;", "Lcom/exampletest/mobilestudiotest/engine/AnimPlayer$Track;", "Lkotlin/collections/ArrayList;", "toolTrack", "emoteTrack", "emoteName", "idleLoops", "", "reported", "ready", "getReady", "()Z", "pick", "Lcom/exampletest/mobilestudiotest/engine/AnimClip;", "name", "playCore", "", "fade", "", "step", "dt", "pose", "speed", "tool", "emote", "jumpAnimTime", "transform", "Lcom/exampletest/mobilestudiotest/model/CFrame;", "part1Name", "Entry", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class DefaultAnimate {
    private String current;
    private ArrayList<AnimPlayer.Track> currentTracks;
    private String emoteName;
    private AnimPlayer.Track emoteTrack;
    private int idleLoops;
    private final AnimPlayer player = new AnimPlayer();
    private final boolean r15;
    private boolean reported;
    private final Random rnd;
    private final Map<String, List<Entry>> sets;
    private AnimPlayer.Track toolTrack;

    public DefaultAnimate(boolean r15) {
        this.r15 = r15;
        this.sets = this.r15 ? MapsKt.mapOf(TuplesKt.to("idle", CollectionsKt.listOf((Object[]) new Entry[]{new Entry(507766666L, 9), new Entry(507766951L, 1)})), TuplesKt.to("walk", CollectionsKt.listOf(new Entry(913402848L, 10))), TuplesKt.to("run", CollectionsKt.listOf(new Entry(913376220L, 10))), TuplesKt.to("jump", CollectionsKt.listOf(new Entry(507765000L, 10))), TuplesKt.to("fall", CollectionsKt.listOf(new Entry(507767968L, 10))), TuplesKt.to("climb", CollectionsKt.listOf(new Entry(507765644L, 10))), TuplesKt.to("sit", CollectionsKt.listOf(new Entry(2506281703L, 10))), TuplesKt.to("toolnone", CollectionsKt.listOf(new Entry(507768375L, 10))), TuplesKt.to("wave", CollectionsKt.listOf(new Entry(507770239L, 10))), TuplesKt.to("point", CollectionsKt.listOf(new Entry(507770453L, 10))), TuplesKt.to("dance", CollectionsKt.listOf((Object[]) new Entry[]{new Entry(507771019L, 10), new Entry(507771955L, 10), new Entry(507772104L, 10)})), TuplesKt.to("dance2", CollectionsKt.listOf((Object[]) new Entry[]{new Entry(507776043L, 10), new Entry(507776720L, 10), new Entry(507776879L, 10)})), TuplesKt.to("dance3", CollectionsKt.listOf((Object[]) new Entry[]{new Entry(507777268L, 10), new Entry(507777451L, 10), new Entry(507777623L, 10)})), TuplesKt.to("laugh", CollectionsKt.listOf(new Entry(507770818L, 10))), TuplesKt.to("cheer", CollectionsKt.listOf(new Entry(507770677L, 10)))) : MapsKt.mapOf(TuplesKt.to("idle", CollectionsKt.listOf((Object[]) new Entry[]{new Entry(180435571L, 9), new Entry(180435792L, 1)})), TuplesKt.to("walk", CollectionsKt.listOf(new Entry(180426354L, 10))), TuplesKt.to("run", CollectionsKt.listOf(new Entry(180426354L, 10))), TuplesKt.to("jump", CollectionsKt.listOf(new Entry(125750702L, 10))), TuplesKt.to("fall", CollectionsKt.listOf(new Entry(180436148L, 10))), TuplesKt.to("climb", CollectionsKt.listOf(new Entry(180436334L, 10))), TuplesKt.to("sit", CollectionsKt.listOf(new Entry(178130996L, 10))), TuplesKt.to("toolnone", CollectionsKt.listOf(new Entry(182393478L, 10))), TuplesKt.to("wave", CollectionsKt.listOf(new Entry(128777973L, 10))), TuplesKt.to("point", CollectionsKt.listOf(new Entry(128853357L, 10))), TuplesKt.to("dance", CollectionsKt.listOf((Object[]) new Entry[]{new Entry(182435998L, 10), new Entry(182491037L, 10), new Entry(182491065L, 10)})), TuplesKt.to("dance2", CollectionsKt.listOf((Object[]) new Entry[]{new Entry(182436842L, 10), new Entry(182491248L, 10), new Entry(182491277L, 10)})), TuplesKt.to("dance3", CollectionsKt.listOf((Object[]) new Entry[]{new Entry(182436935L, 10), new Entry(182491368L, 10), new Entry(182491423L, 10)})), TuplesKt.to("laugh", CollectionsKt.listOf(new Entry(129423131L, 10))), TuplesKt.to("cheer", CollectionsKt.listOf(new Entry(129423030L, 10))));
        this.rnd = new Random();
        this.current = "";
        this.currentTracks = new ArrayList<>();
        Iterator<List<Entry>> it = this.sets.values().iterator();
        while (it.hasNext()) {
            for (Entry e : it.next()) {
                AnimLibrary.INSTANCE.get(e.getId());
            }
        }
    }

    /* JADX INFO: compiled from: KeyframeAnim.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0015"}, d2 = {"Lcom/exampletest/mobilestudiotest/engine/DefaultAnimate$Entry;", "", "id", "", "weight", "", "<init>", "(JI)V", "getId", "()J", "getWeight", "()I", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final /* data */ class Entry {
        private final long id;
        private final int weight;

        public static /* synthetic */ Entry copy$default(Entry entry, long j, int i, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                j = entry.id;
            }
            if ((i2 & 2) != 0) {
                i = entry.weight;
            }
            return entry.copy(j, i);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final long getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final int getWeight() {
            return this.weight;
        }

        public final Entry copy(long id, int weight) {
            return new Entry(id, weight);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Entry)) {
                return false;
            }
            Entry entry = (Entry) other;
            return this.id == entry.id && this.weight == entry.weight;
        }

        public int hashCode() {
            return (Long.hashCode(this.id) * 31) + Integer.hashCode(this.weight);
        }

        public String toString() {
            return "Entry(id=" + this.id + ", weight=" + this.weight + ")";
        }

        public Entry(long id, int weight) {
            this.id = id;
            this.weight = weight;
        }

        public final long getId() {
            return this.id;
        }

        public final int getWeight() {
            return this.weight;
        }
    }

    public final boolean getReady() {
        boolean z = true;
        Iterable iterableListOf = CollectionsKt.listOf((Object[]) new String[]{"idle", "walk", "jump", "fall"});
        if ((iterableListOf instanceof Collection) && ((Collection) iterableListOf).isEmpty()) {
            return true;
        }
        Iterator it = iterableListOf.iterator();
        while (it.hasNext()) {
            Iterable iterable = this.sets.get((String) it.next());
            Intrinsics.checkNotNull(iterable);
            Iterable iterable2 = iterable;
            if (!(iterable2 instanceof Collection) || !((Collection) iterable2).isEmpty()) {
                Iterator it2 = iterable2.iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        z = true;
                        break;
                    }
                    if (!(AnimLibrary.INSTANCE.get(((Entry) it2.next()).getId()) != null)) {
                        z = false;
                        break;
                    }
                }
            }
            if (!z) {
                return false;
            }
            z = true;
        }
        return true;
    }

    private final AnimClip pick(String name) {
        List<Entry> list = this.sets.get(name);
        if (list == null) {
            return null;
        }
        Iterator<T> it = list.iterator();
        int total = 0;
        while (it.hasNext()) {
            total += ((Entry) it.next()).getWeight();
        }
        int r = this.rnd.nextInt(RangesKt.coerceAtLeast(total, 1));
        for (Entry e : list) {
            r -= e.getWeight();
            if (r < 0) {
                return AnimLibrary.INSTANCE.get(e.getId());
            }
        }
        return AnimLibrary.INSTANCE.get(((Entry) CollectionsKt.first((List) list)).getId());
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00b7  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final void playCore(String name, float fade) {
        if (Intrinsics.areEqual(name, this.current)) {
            return;
        }
        Iterator<AnimPlayer.Track> it = this.currentTracks.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (it.hasNext()) {
            AnimPlayer.Track next = it.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            AnimPlayer.Track t = next;
            this.player.stop(t, fade);
        }
        this.currentTracks = new ArrayList<>();
        this.current = name;
        if (this.r15 && Intrinsics.areEqual(name, "walk")) {
            AnimClip animClipPick = pick("walk");
            if (animClipPick != null) {
                this.currentTracks.add(AnimPlayer.play$default(this.player, animClipPick, "walk", fade, 0.0f, 0.0f, 0, 24, null));
            }
            AnimClip animClipPick2 = pick("run");
            if (animClipPick2 != null) {
                this.currentTracks.add(AnimPlayer.play$default(this.player, animClipPick2, "run", fade, 1.0E-4f, 0.0f, 0, 16, null));
                return;
            }
            return;
        }
        AnimClip clip = pick(name);
        if (clip == null) {
            return;
        }
        ArrayList<AnimPlayer.Track> arrayList = this.currentTracks;
        AnimPlayer.Track trackPlay$default = AnimPlayer.play$default(this.player, clip, name, fade, 0.0f, 0.0f, 0, 24, null);
        switch (name.hashCode()) {
            case 113886:
                if (name.equals("sit")) {
                    trackPlay$default.setLooped(!Intrinsics.areEqual(name, "jump"));
                }
                break;
            case 3135355:
                if (name.equals("fall")) {
                    trackPlay$default.setLooped(!Intrinsics.areEqual(name, "jump"));
                }
                break;
            case 3273774:
                if (name.equals("jump")) {
                    trackPlay$default.setLooped(!Intrinsics.areEqual(name, "jump"));
                }
                break;
        }
        arrayList.add(trackPlay$default);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:40:0x00b1  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public final void step(float dt, String pose, float speed, boolean tool, String emote, float jumpAnimTime) {
        AnimClip animClipPick;
        AnimPlayer.Track t;
        Object next;
        Object next2;
        Intrinsics.checkNotNullParameter(pose, "pose");
        if (getReady()) {
            if (!this.reported) {
                this.reported = true;
                OutputLog.INSTANCE.info("Character animations: using Roblox's default " + (this.r15 ? "R15" : "R6") + " animations");
            }
            switch (pose.hashCode()) {
                case -1822467708:
                    if (pose.equals("Seated")) {
                        playCore("sit", 0.5f);
                    }
                    break;
                case -1474121689:
                    if (pose.equals("FreeFall")) {
                        if (jumpAnimTime <= 0.0f) {
                            playCore("fall", this.r15 ? 0.2f : 0.3f);
                        }
                    }
                    break;
                case -1079530081:
                    if (pose.equals("Running") && speed > 0.75f) {
                        playCore("walk", 0.2f);
                    } else {
                        playCore("idle", 0.2f);
                    }
                    break;
                case 409511124:
                    if (pose.equals("Jumping")) {
                        playCore("jump", 0.1f);
                    }
                    break;
                case 980073773:
                    if (pose.equals("Climbing")) {
                        playCore("climb", 0.1f);
                    }
                    break;
                default:
                    playCore("idle", 0.2f);
                    break;
            }
            String str = this.current;
            AnimPlayer.Track trackPlay$default = null;
            switch (str.hashCode()) {
                case 3227604:
                    if (str.equals("idle") && (t = (AnimPlayer.Track) CollectionsKt.firstOrNull((List) this.currentTracks)) != null && t.getLoops() > this.idleLoops) {
                        this.idleLoops = t.getLoops();
                        AnimClip next3 = pick("idle");
                        if (next3 != null && next3 != t.getClip()) {
                            this.player.stop(t, 0.2f);
                            this.currentTracks = CollectionsKt.arrayListOf(AnimPlayer.play$default(this.player, next3, "idle", 0.2f, 0.0f, 0.0f, 0, 24, null));
                            this.idleLoops = 0;
                        }
                    }
                    break;
                case 3641801:
                    if (str.equals("walk")) {
                        if (!this.r15) {
                            Iterator it = this.currentTracks.iterator();
                            while (it.hasNext()) {
                                ((AnimPlayer.Track) it.next()).setSpeed(speed / 14.5f);
                            }
                        } else {
                            float run = (speed / 16.0f) * 1.25f;
                            Iterator it2 = this.currentTracks.iterator();
                            do {
                                if (!it2.hasNext()) {
                                    next = null;
                                    break;
                                }
                                next = it2.next();
                            } while (!Intrinsics.areEqual(((AnimPlayer.Track) next).getTag(), "walk"));
                            AnimPlayer.Track walkT = (AnimPlayer.Track) next;
                            Iterator it3 = this.currentTracks.iterator();
                            do {
                                if (!it3.hasNext()) {
                                    next2 = null;
                                    break;
                                }
                                next2 = it3.next();
                            } while (!Intrinsics.areEqual(((AnimPlayer.Track) next2).getTag(), "run"));
                            AnimPlayer.Track runT = (AnimPlayer.Track) next2;
                            float ww = 1.0E-4f;
                            float rw = 1.0E-4f;
                            if (run <= 0.5f) {
                                ww = 1.0f;
                            } else if (run < 1.0f) {
                                float f = (run - 0.5f) / 0.5f;
                                ww = 1.0f - f;
                                rw = f;
                            } else {
                                rw = 1.0f;
                            }
                            if (walkT != null) {
                                walkT.setTargetWeight(ww);
                                walkT.setSpeed(run / 0.5f);
                            }
                            if (runT != null) {
                                runT.setTargetWeight(rw);
                                runT.setSpeed(run / 1.0f);
                            }
                        }
                    }
                    break;
                case 94750389:
                    if (str.equals("climb")) {
                        Iterator it4 = this.currentTracks.iterator();
                        while (it4.hasNext()) {
                            ((AnimPlayer.Track) it4.next()).setSpeed(speed / (this.r15 ? 5.0f : 12.0f));
                        }
                    }
                    break;
            }
            if (tool && this.toolTrack == null) {
                AnimClip animClipPick2 = pick("toolnone");
                this.toolTrack = animClipPick2 != null ? AnimPlayer.play$default(this.player, animClipPick2, "toolnone", 0.1f, 0.0f, 0.0f, 1, 24, null) : null;
            } else if (!tool && this.toolTrack != null) {
                AnimPlayer animPlayer = this.player;
                AnimPlayer.Track track = this.toolTrack;
                Intrinsics.checkNotNull(track);
                animPlayer.stop(track, 0.1f);
                this.toolTrack = null;
            }
            if (!Intrinsics.areEqual(emote, this.emoteName)) {
                AnimPlayer.Track track2 = this.emoteTrack;
                if (track2 != null) {
                    this.player.stop(track2, 0.1f);
                }
                if (emote != null && (animClipPick = pick(emote)) != null) {
                    trackPlay$default = AnimPlayer.play$default(this.player, animClipPick, emote, 0.1f, 0.0f, 0.0f, 2, 24, null);
                }
                this.emoteTrack = trackPlay$default;
                this.emoteName = emote;
            }
            this.player.step(dt);
        }
    }

    public final CFrame transform(String part1Name) {
        Intrinsics.checkNotNullParameter(part1Name, "part1Name");
        if (!getReady()) {
            return null;
        }
        CFrame cFrameTransform = this.player.transform(part1Name);
        return cFrameTransform == null ? CFrame.INSTANCE.getIDENTITY() : cFrameTransform;
    }
}
