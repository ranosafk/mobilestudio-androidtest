package com.exampletest.mobilestudiotest.render;

import androidx.core.view.ViewCompat;
import com.exampletest.mobilestudiotest.core.OutputLog;
import com.exampletest.mobilestudiotest.format.CsgMesh;
import com.exampletest.mobilestudiotest.format.RbxDocument;
import com.exampletest.mobilestudiotest.format.RbxFile;
import com.exampletest.mobilestudiotest.format.RbxFormatException;
import com.exampletest.mobilestudiotest.model.BinaryString;
import com.exampletest.mobilestudiotest.model.Instance;
import com.exampletest.mobilestudiotest.model.SharedStr;
import com.exampletest.mobilestudiotest.model.Vector3;
import com.exampletest.mobilestudiotest.net.AssetFetcher;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: UnionMeshes.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0010$\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001*B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\u0018\u001a\u0004\u0018\u00010\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001H\u0002J\u000e\u0010\u001b\u001a\u00020\u000b2\u0006\u0010\u001c\u001a\u00020\u001dJ\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u001c\u001a\u00020\u001dJ\u0010\u0010\u001f\u001a\u00020\u00192\u0006\u0010 \u001a\u00020\u0019H\u0002J&\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u00062\u0006\u0010$\u001a\u00020\u00062\f\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00190&H\u0002J\u0018\u0010'\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u00062\u0006\u0010(\u001a\u00020)H\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010\b\u001aB\u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\f\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b \n* \u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\f\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b\u0018\u00010\t0\tX\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010\f\u001aB\u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\f\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b \n* \u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\f\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b\u0018\u00010\t0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\r\u001a\n \n*\u0004\u0018\u00010\u000e0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010\u000f\u001aB\u0012\f\u0012\n \n*\u0004\u0018\u00010\u00010\u0001\u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006 \n* \u0012\f\u0012\n \n*\u0004\u0018\u00010\u00010\u0001\u0012\f\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0018\u00010\u00110\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0013@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u000e\u0010\u0017\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006+"}, d2 = {"Lcom/exampletest/mobilestudiotest/render/UnionMeshes;", "", "<init>", "()V", "ready", "Ljava/util/concurrent/ConcurrentHashMap;", "", "Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;", "bad", "Ljava/util/concurrent/ConcurrentHashMap$KeySetView;", "kotlin.jvm.PlatformType", "", "pending", "pool", "Ljava/util/concurrent/ExecutorService;", "inlineKeys", "", "", "value", "", "epoch", "getEpoch", "()I", "listening", "bytesOf", "", "v", "isStored", "p", "Lcom/exampletest/mobilestudiotest/model/Instance;", "get", "meshDataFromAsset", "bytes", "build", "", "key", "name", "source", "Lkotlin/Function0;", "toData", "m", "Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;", "Data", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class UnionMeshes {
    private static volatile int epoch;
    private static volatile boolean listening;
    public static final UnionMeshes INSTANCE = new UnionMeshes();
    private static final ConcurrentHashMap<String, Data> ready = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap.KeySetView<String, Boolean> bad = ConcurrentHashMap.newKeySet();
    private static final ConcurrentHashMap.KeySetView<String, Boolean> pending = ConcurrentHashMap.newKeySet();
    private static final ExecutorService pool = Executors.newSingleThreadExecutor();
    private static final Map<Object, String> inlineKeys = Collections.synchronizedMap(new WeakHashMap());

    private UnionMeshes() {
    }

    /* JADX INFO: compiled from: UnionMeshes.kt */
    @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\u0018\u00002\u00020\u0001BG\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0018\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u00060\u0005\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\b0\u0005¢\u0006\u0004\b\r\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R#\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u000b\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\b0\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0012¨\u0006\u0017"}, d2 = {"Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;", "", "key", "", "groups", "", "Lkotlin/Pair;", "", "", "center", "Lcom/exampletest/mobilestudiotest/model/Vector3;", "size", "triangles", "<init>", "(Ljava/lang/String;Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Ljava/util/List;)V", "getKey", "()Ljava/lang/String;", "getGroups", "()Ljava/util/List;", "getCenter", "()Lcom/exampletest/mobilestudiotest/model/Vector3;", "getSize", "getTriangles", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Data {
        private final Vector3 center;
        private final List<Pair<Integer, float[]>> groups;
        private final String key;
        private final Vector3 size;
        private final List<float[]> triangles;

        public Data(String key, List<Pair<Integer, float[]>> groups, Vector3 center, Vector3 size, List<float[]> triangles) {
            Intrinsics.checkNotNullParameter(key, "key");
            Intrinsics.checkNotNullParameter(groups, "groups");
            Intrinsics.checkNotNullParameter(center, "center");
            Intrinsics.checkNotNullParameter(size, "size");
            Intrinsics.checkNotNullParameter(triangles, "triangles");
            this.key = key;
            this.groups = groups;
            this.center = center;
            this.size = size;
            this.triangles = triangles;
        }

        public final Vector3 getCenter() {
            return this.center;
        }

        public final List<Pair<Integer, float[]>> getGroups() {
            return this.groups;
        }

        public final String getKey() {
            return this.key;
        }

        public final Vector3 getSize() {
            return this.size;
        }

        public final List<float[]> getTriangles() {
            return this.triangles;
        }
    }

    public final int getEpoch() {
        return epoch;
    }

    private final byte[] bytesOf(Object v) {
        byte[] bytes;
        if (v instanceof BinaryString) {
            bytes = ((BinaryString) v).getBytes();
        } else if (v instanceof SharedStr) {
            bytes = ((SharedStr) v).getBytes();
        } else if (!(v instanceof String) || ((String) v).length() <= 16) {
            bytes = null;
        } else {
            bytes = ((String) v).getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        }
        if (bytes == null) {
            return null;
        }
        if (bytes.length > 16) {
            return bytes;
        }
        return null;
    }

    public final boolean isStored(Instance p) {
        boolean z;
        Intrinsics.checkNotNullParameter(p, "p");
        if (!p.isA("PartOperation") || Intrinsics.areEqual(p.getClassName(), "NegateOperation")) {
            return false;
        }
        Iterable children = p.getChildren();
        if (!(children instanceof Collection) || !((Collection) children).isEmpty()) {
            Iterator it = children.iterator();
            while (true) {
                if (it.hasNext()) {
                    if (((Instance) it.next()).isA("BasePart")) {
                        z = false;
                        break;
                    }
                } else {
                    z = true;
                    break;
                }
            }
        } else {
            z = true;
        }
        return z;
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0026  */
    /* JADX WARN: Code duplicated, block: B:13:0x0032  */
    /* JADX WARN: Code duplicated, block: B:15:0x003c  */
    /* JADX WARN: Code duplicated, block: B:18:0x0040  */
    public final Data get(final Instance p) {
        Intrinsics.checkNotNullParameter(p, "p");
        Object inlineVal = p.getProps().get("MeshData2");
        if (inlineVal == null) {
            inlineVal = p.getProps().get("MeshData");
            if (inlineVal == null) {
                inlineVal = null;
            } else {
                if (!(INSTANCE.bytesOf(inlineVal) != null)) {
                    inlineVal = null;
                }
            }
        } else {
            if (!(INSTANCE.bytesOf(inlineVal) != null)) {
                inlineVal = null;
            }
            if (inlineVal == null) {
                inlineVal = p.getProps().get("MeshData");
                if (inlineVal == null) {
                    inlineVal = null;
                } else {
                    if (!(INSTANCE.bytesOf(inlineVal) != null)) {
                        inlineVal = null;
                    }
                }
            }
        }
        if (inlineVal != null) {
            final String key = inlineKeys.get(inlineVal);
            if (key == null) {
                byte[] bArrBytesOf = bytesOf(inlineVal);
                Intrinsics.checkNotNull(bArrBytesOf);
                String str = "inline:" + bArrBytesOf.length + ":" + Arrays.hashCode(bArrBytesOf);
                Map<Object, String> inlineKeys2 = inlineKeys;
                Intrinsics.checkNotNullExpressionValue(inlineKeys2, "inlineKeys");
                inlineKeys2.put(inlineVal, str);
                key = str;
            }
            Data data = ready.get(key);
            if (data != null) {
                return data;
            }
            if (bad.contains(key) || !pending.add(key)) {
                return null;
            }
            final byte[] b = bytesOf(inlineVal);
            Intrinsics.checkNotNull(b);
            pool.execute(new Runnable() { // from class: com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    UnionMeshes.INSTANCE.build(key, p.getName(), new Function0() { // from class: com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return UnionMeshes.get$lambda$8$lambda$7(bArr);
                        }
                    });
                }
            });
            return null;
        }
        Long lIdOf = AssetFetcher.INSTANCE.idOf(p.getProps().get("AssetId"));
        if (lIdOf == null) {
            return null;
        }
        long id = lIdOf.longValue();
        final String key2 = "asset:" + id;
        Data data2 = ready.get(key2);
        if (data2 != null) {
            return data2;
        }
        if (bad.contains(key2) || pending.contains(key2)) {
            return null;
        }
        final byte[] bytes = AssetFetcher.INSTANCE.request(id);
        if (bytes == null) {
            if (!listening) {
                listening = true;
                AssetFetcher.INSTANCE.getListeners().add(new Function1() { // from class: com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return UnionMeshes.get$lambda$10(((Long) obj).longValue());
                    }
                });
            }
            return null;
        }
        if (!pending.add(key2)) {
            return null;
        }
        pool.execute(new Runnable() { // from class: com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                UnionMeshes.INSTANCE.build(key2, p.getName(), new Function0() { // from class: com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return UnionMeshes.INSTANCE.meshDataFromAsset(bArr);
                    }
                });
            }
        });
        return null;
    }

    static final byte[] get$lambda$8$lambda$7(byte[] $b) {
        return $b;
    }

    static final Unit get$lambda$10(long done) {
        if (!ready.containsKey("asset:" + done)) {
            UnionMeshes unionMeshes = INSTANCE;
            int i = epoch;
            UnionMeshes unionMeshes2 = INSTANCE;
            epoch = i + 1;
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final byte[] meshDataFromAsset(byte[] bytes) throws RbxFormatException, XmlPullParserException, CsgMesh.CsgException, IOException {
        if (CsgMesh.INSTANCE.isCsgMesh(bytes)) {
            return bytes;
        }
        RbxDocument doc = RbxFile.INSTANCE.read(bytes);
        for (Instance r : doc.getRoots()) {
            for (Instance i : CollectionsKt.plus((Collection) CollectionsKt.listOf(r), (Iterable) Instance.descendants$default(r, null, 1, null))) {
                byte[] bArrBytesOf = bytesOf(i.getProps().get("MeshData"));
                if (bArrBytesOf != null) {
                    return bArrBytesOf;
                }
                byte[] bArrBytesOf2 = bytesOf(i.getProps().get("MeshData2"));
                if (bArrBytesOf2 != null) {
                    return bArrBytesOf2;
                }
            }
        }
        throw new CsgMesh.CsgException("the union asset has no mesh");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void build(String key, String name, Function0<byte[]> source) {
        try {
            try {
                CsgMesh.Decoded m = CsgMesh.INSTANCE.decode(source.invoke());
                ready.put(key, toData(key, m));
            } catch (Exception e) {
                bad.add(key);
                OutputLog outputLog = OutputLog.INSTANCE;
                String message = e.getMessage();
                outputLog.warn("Union '" + name + "' can't be shown (" + (message != null ? message : e) + "); it is drawn as a box.");
            }
        } finally {
            pending.remove(key);
            epoch++;
        }
    }

    private final Data toData(String key, CsgMesh.Decoded m) {
        float[] mx;
        Object arrayList;
        float nx;
        float ny;
        float nz;
        float[] p = m.getPos();
        float[] n = m.getNrm();
        int k = 3;
        float[] mn = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE};
        float[] mx2 = {-3.4028235E38f, -3.4028235E38f, -3.4028235E38f};
        int i = 0;
        for (int i2 : m.getIndices()) {
            for (int c = 0; c < 3; c++) {
                float v = p[(i2 * 3) + c];
                if (v < mn[c]) {
                    mn[c] = v;
                }
                if (v > mx2[c]) {
                    mx2[c] = v;
                }
            }
        }
        if (mn[0] > mx2[0]) {
            ArraysKt.fill$default(mn, 0.0f, 0, 0, 6, (Object) null);
            mx = mx2;
            ArraysKt.fill$default(mx, 0.0f, 0, 0, 6, (Object) null);
        } else {
            mx = mx2;
        }
        Map groups = new LinkedHashMap();
        ArrayList all = new ArrayList();
        int t = 0;
        while (t + 2 < m.getIndices().length) {
            int a = m.getIndices()[t];
            int b = m.getIndices()[t + 1];
            int c2 = m.getIndices()[t + 2];
            t += 3;
            int color = m.getColors()[a] | ViewCompat.MEASURED_STATE_MASK;
            Map map = groups;
            Integer numValueOf = Integer.valueOf(color);
            Object obj = map.get(numValueOf);
            if (obj == null) {
                arrayList = new ArrayList();
                map.put(numValueOf, arrayList);
            } else {
                arrayList = obj;
            }
            ArrayList list = (ArrayList) arrayList;
            float[] tri = new float[9];
            int k2 = 0;
            int[] iArr = {a, b, c2};
            int i3 = i;
            while (i3 < k) {
                int v2 = iArr[i3];
                float[] p2 = p;
                int q = 0;
                while (q < k) {
                    list.add(Float.valueOf(p2[(v2 * 3) + q]));
                    tri[k2] = p2[(v2 * 3) + q];
                    q++;
                    k2++;
                    k = 3;
                }
                int q2 = v2 * 3;
                float nx2 = n[q2];
                float ny2 = n[(v2 * 3) + 1];
                float nz2 = n[(v2 * 3) + 2];
                float[] n2 = n;
                float l = (float) Math.sqrt((nx2 * nx2) + (ny2 * ny2) + (nz2 * nz2));
                if (l > 1.0E-6f) {
                    nx = nx2 / l;
                    ny = ny2 / l;
                    nz = nz2 / l;
                } else {
                    nx = 0.0f;
                    ny = 1.0f;
                    nz = 0.0f;
                }
                list.add(Float.valueOf(nx));
                list.add(Float.valueOf(ny));
                list.add(Float.valueOf(nz));
                list.add(Float.valueOf(0.0f));
                list.add(Float.valueOf(0.0f));
                i3++;
                p = p2;
                n = n2;
                k = 3;
            }
            all.add(tri);
            i = i;
            k = 3;
        }
        int i4 = i;
        Map map2 = groups;
        Collection arrayList2 = new ArrayList(map2.size());
        for (Map.Entry entry : map2.entrySet()) {
            arrayList2.add(TuplesKt.to(Integer.valueOf(((Number) entry.getKey()).intValue()), CollectionsKt.toFloatArray((ArrayList) entry.getValue())));
            map2 = map2;
        }
        return new Data(key, (List) arrayList2, new Vector3((mn[i4] + mx[i4]) / 2.0f, (mn[1] + mx[1]) / 2.0f, (mn[2] + mx[2]) / 2.0f), new Vector3(mx[i4] - mn[i4], mx[1] - mn[1], mx[2] - mn[2]), all);
    }
}
