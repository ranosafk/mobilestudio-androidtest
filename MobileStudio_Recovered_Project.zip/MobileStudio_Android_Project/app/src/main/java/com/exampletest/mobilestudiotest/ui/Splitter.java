package com.exampletest.mobilestudiotest.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Splitter.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B;\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007\u0012\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u000b¢\u0006\u0004\b\f\u0010\rJ\u0010\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u001bH\u0014J\u0010\u0010\u001c\u001a\u00020\u00052\u0006\u0010\u001d\u001a\u00020\u001eH\u0017R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0015\u001a\u00020\u00168F¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0018¨\u0006\u001f"}, d2 = {"Lcom/exampletest/mobilestudiotest/ui/Splitter;", "Landroid/view/View;", "ctx", "Landroid/content/Context;", "vertical", "", "onDrag", "Lkotlin/Function1;", "", "", "onEnd", "Lkotlin/Function0;", "<init>", "(Landroid/content/Context;ZLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V", "getVertical", "()Z", "paint", "Landroid/graphics/Paint;", "dragging", "last", "d", "thickness", "", "getThickness", "()I", "onDraw", "canvas", "Landroid/graphics/Canvas;", "onTouchEvent", "e", "Landroid/view/MotionEvent;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Splitter extends View {
    private final float d;
    private boolean dragging;
    private float last;
    private final Function1<Float, Unit> onDrag;
    private final Function0<Unit> onEnd;
    private final Paint paint;
    private final boolean vertical;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public Splitter(Context ctx, boolean vertical, Function1<? super Float, Unit> onDrag, Function0<Unit> onEnd) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(onDrag, "onDrag");
        Intrinsics.checkNotNullParameter(onEnd, "onEnd");
        this.vertical = vertical;
        this.onDrag = onDrag;
        this.onEnd = onEnd;
        this.paint = new Paint();
        this.d = getResources().getDisplayMetrics().density;
        setBackgroundColor(Ui.INSTANCE.getBORDER());
    }

    public /* synthetic */ Splitter(Context context, boolean z, Function1 function1, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, z, function1, (i & 8) != 0 ? new Function0() { // from class: com.exampletest.mobilestudiotest.ui.Splitter$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Unit.INSTANCE;
            }
        } : function0);
    }

    public final boolean getVertical() {
        return this.vertical;
    }

    public final int getThickness() {
        return (int) (this.d * 12.0f);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        this.paint.setColor(this.dragging ? Ui.INSTANCE.getACCENT() : -10855846);
        if (this.dragging) {
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.paint);
            return;
        }
        float cx = getWidth() / 2.0f;
        float cy = getHeight() / 2.0f;
        for (int i = -2; i < 3; i++) {
            if (this.vertical) {
                canvas.drawCircle(cx, (i * 5.0f * this.d) + cy, this.d * 1.3f, this.paint);
            } else {
                canvas.drawCircle((i * 5.0f * this.d) + cx, cy, this.d * 1.3f, this.paint);
            }
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent e) {
        Intrinsics.checkNotNullParameter(e, "e");
        float pos = this.vertical ? e.getRawX() : e.getRawY();
        switch (e.getActionMasked()) {
            case 0:
                this.dragging = true;
                this.last = pos;
                ViewParent parent = getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                }
                invalidate();
                return true;
            case 1:
            case 3:
                this.dragging = false;
                invalidate();
                this.onEnd.invoke();
                return true;
            case 2:
                if (this.dragging) {
                    float dlt = pos - this.last;
                    this.last = pos;
                    if (!(dlt == 0.0f)) {
                        this.onDrag.invoke(Float.valueOf(dlt));
                    }
                }
                return true;
            default:
                return true;
        }
    }
}
