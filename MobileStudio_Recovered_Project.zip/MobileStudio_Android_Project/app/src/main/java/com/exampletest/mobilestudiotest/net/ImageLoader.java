package com.exampletest.mobilestudiotest.net;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: ImageLoader.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000m\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\b\n\u0002\b\u0007*\u0001\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u001c\u001a\u00020\u001dJ\u0017\u0010\"\u001a\u0004\u0018\u00010\u00102\b\u0010#\u001a\u0004\u0018\u00010\u000b¢\u0006\u0002\u0010$J\u0017\u0010%\u001a\u0004\u0018\u00010\u00102\u0006\u0010#\u001a\u00020\u000bH\u0002¢\u0006\u0002\u0010$J\u0012\u0010'\u001a\u0004\u0018\u00010\u000b2\b\u0010#\u001a\u0004\u0018\u00010\u000bJ\u0012\u0010(\u001a\u0004\u0018\u00010)2\b\u0010#\u001a\u0004\u0018\u00010\u000bJ\u0010\u0010*\u001a\u0004\u0018\u00010)2\u0006\u0010+\u001a\u00020\u000bJ\u0010\u0010,\u001a\u0004\u0018\u00010)2\u0006\u0010+\u001a\u00020\u000bJ\u0012\u0010-\u001a\u0004\u0018\u00010\u00052\u0006\u0010+\u001a\u00020\u000bH\u0002J\u0010\u0010.\u001a\u00020\u00182\u0006\u0010+\u001a\u00020\u000bH\u0002J\b\u0010/\u001a\u00020\u0018H\u0002J\u0018\u00100\u001a\u00020\u00182\u0006\u0010+\u001a\u00020\u000b2\u0006\u00101\u001a\u00020\u000bH\u0002J\u0018\u00107\u001a\u00020\u00182\u0006\u0010+\u001a\u00020\u000b2\u0006\u00108\u001a\u00020)H\u0002J\u0010\u00109\u001a\u00020\u00182\u0006\u0010+\u001a\u00020\u000bH\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\bRN\u0010\t\u001aB\u0012\f\u0012\n \f*\u0004\u0018\u00010\u000b0\u000b\u0012\f\u0012\n \f*\u0004\u0018\u00010\r0\r \f* \u0012\f\u0012\n \f*\u0004\u0018\u00010\u000b0\u000b\u0012\f\u0012\n \f*\u0004\u0018\u00010\r0\r\u0018\u00010\n0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0011\u001a\n \f*\u0004\u0018\u00010\u00120\u0012X\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010\u0013\u001aB\u0012\f\u0012\n \f*\u0004\u0018\u00010\u00100\u0010\u0012\f\u0012\n \f*\u0004\u0018\u00010\r0\r \f* \u0012\f\u0012\n \f*\u0004\u0018\u00010\u00100\u0010\u0012\f\u0012\n \f*\u0004\u0018\u00010\r0\r\u0018\u00010\n0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R#\u0010\u0015\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00180\u00170\u0016¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0014\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010!\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010&\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u000b0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u00104\u001a\u0002032\u0006\u00102\u001a\u000203@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b5\u00106¨\u0006:"}, d2 = {"Lcom/exampletest/mobilestudiotest/net/ImageLoader;", "", "<init>", "()V", "cacheDir", "Ljava/io/File;", "mem", "com/exampletest/mobilestudiotest/net/ImageLoader$mem$1", "Lcom/exampletest/mobilestudiotest/net/ImageLoader$mem$1;", "pending", "Ljava/util/concurrent/ConcurrentHashMap$KeySetView;", "", "kotlin.jvm.PlatformType", "", "failed", "Ljava/util/concurrent/ConcurrentHashMap;", "", "pool", "Ljava/util/concurrent/ExecutorService;", "idQueue", "batchScheduled", "listeners", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lkotlin/Function1;", "", "getListeners", "()Ljava/util/concurrent/CopyOnWriteArrayList;", "init", "ctx", "Landroid/content/Context;", "idRx", "", "Lkotlin/text/Regex;", "idMemo", "assetId", "content", "(Ljava/lang/String;)Ljava/lang/Long;", "parseId", "keyMemo", "keyFor", "get", "Landroid/graphics/Bitmap;", "getKey", "key", "peekKey", "diskFile", "loadFromDisk", "scheduleBatch", "fetchUrl", "url", "value", "", "epoch", "getEpoch", "()I", "done", "b", "fail", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ImageLoader {
    public static final ImageLoader INSTANCE = new ImageLoader();
    private static volatile boolean batchScheduled;
    private static File cacheDir;
    private static volatile int epoch;
    private static final ConcurrentHashMap<String, Long> failed;
    private static final ConcurrentHashMap<String, Long> idMemo;
    private static final ConcurrentHashMap.KeySetView<Long, Boolean> idQueue;
    private static final List<Regex> idRx;
    private static final ConcurrentHashMap<Long, String> keyMemo;
    private static final CopyOnWriteArrayList<Function1<String, Unit>> listeners;
    private static final ImageLoader$mem$1 mem;
    private static final ConcurrentHashMap.KeySetView<String, Boolean> pending;
    private static final ExecutorService pool;

    private ImageLoader() {
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [com.exampletest.mobilestudiotest.net.ImageLoader$mem$1] */
    static {
        final int iMin = (int) Math.min(41943040L, Runtime.getRuntime().maxMemory() / 10);
        mem = new LruCache<String, Bitmap>(iMin) { // from class: com.exampletest.mobilestudiotest.net.ImageLoader$mem$1
            /* JADX INFO: Access modifiers changed from: protected */
            @Override // android.util.LruCache
            public int sizeOf(String key, Bitmap value) {
                Intrinsics.checkNotNullParameter(key, "key");
                Intrinsics.checkNotNullParameter(value, "value");
                return value.getByteCount();
            }
        };
        pending = ConcurrentHashMap.newKeySet();
        failed = new ConcurrentHashMap<>();
        pool = Executors.newFixedThreadPool(4);
        idQueue = ConcurrentHashMap.newKeySet();
        listeners = new CopyOnWriteArrayList<>();
        idRx = CollectionsKt.listOf((Object[]) new Regex[]{new Regex("rbxassetid://(\\d+)", RegexOption.IGNORE_CASE), new Regex("[?&]id=(\\d+)", RegexOption.IGNORE_CASE), new Regex("^\\s*(\\d+)\\s*$"), new Regex("rbxthumb://.*id=(\\d+)", RegexOption.IGNORE_CASE)});
        idMemo = new ConcurrentHashMap<>();
        keyMemo = new ConcurrentHashMap<>();
    }

    public final CopyOnWriteArrayList<Function1<String, Unit>> getListeners() {
        return listeners;
    }

    public final void init(Context ctx) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        if (cacheDir == null) {
            File file = new File(ctx.getCacheDir(), "img");
            file.mkdirs();
            cacheDir = file;
        }
    }

    public final Long assetId(String content) {
        String str = content;
        if (str == null || StringsKt.isBlank(str)) {
            return null;
        }
        Long l = idMemo.get(content);
        if (l != null) {
            long jLongValue = l.longValue();
            if (jLongValue >= 0) {
                return Long.valueOf(jLongValue);
            }
            return null;
        }
        Long id = parseId(content);
        if (idMemo.size() > 50000) {
            idMemo.clear();
        }
        idMemo.put(content, Long.valueOf(id != null ? id.longValue() : -1L));
        return id;
    }

    private final Long parseId(String content) {
        if (StringsKt.startsWith(content, "rbxasset://", true) && !StringsKt.startsWith(content, "rbxassetid://", true)) {
            return null;
        }
        for (Regex r : idRx) {
            MatchResult matchResultFind$default = Regex.find$default(r, content, 0, 2, null);
            if (matchResultFind$default != null) {
                return StringsKt.toLongOrNull(matchResultFind$default.getGroupValues().get(1));
            }
        }
        return null;
    }

    public final String keyFor(String content) {
        String strPutIfAbsent;
        String str = content;
        if (str == null || StringsKt.isBlank(str)) {
            return null;
        }
        Long lAssetId = assetId(content);
        if (lAssetId == null) {
            if (StringsKt.startsWith(content, "http://", true) || StringsKt.startsWith(content, "https://", true)) {
                return "url:" + content;
            }
            return null;
        }
        long jLongValue = lAssetId.longValue();
        ConcurrentMap concurrentMap = keyMemo;
        Long lValueOf = Long.valueOf(jLongValue);
        String str2 = concurrentMap.get(lValueOf);
        if (str2 == null && (strPutIfAbsent = concurrentMap.putIfAbsent(lValueOf, (str2 = "asset:" + jLongValue))) != null) {
            str2 = strPutIfAbsent;
        }
        return str2;
    }

    public final Bitmap get(String content) {
        String key = keyFor(content);
        if (key == null) {
            return null;
        }
        return getKey(key);
    }

    public final Bitmap getKey(final String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        Bitmap bitmap = mem.get(key);
        if (bitmap != null) {
            return bitmap;
        }
        Long f = failed.get(key);
        if ((f != null && System.currentTimeMillis() - f.longValue() < 60000) || !pending.add(key)) {
            return null;
        }
        pool.execute(new Runnable() { // from class: com.exampletest.mobilestudiotest.net.ImageLoader$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() throws NoSuchAlgorithmException {
                ImageLoader.INSTANCE.loadFromDisk(key);
            }
        });
        return null;
    }

    public final Bitmap peekKey(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        return mem.get(key);
    }

    private final File diskFile(String key) throws NoSuchAlgorithmException {
        File dir = cacheDir;
        if (dir == null) {
            return null;
        }
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
        byte[] bytes = key.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        byte[] bArrDigest = messageDigest.digest(bytes);
        Intrinsics.checkNotNullExpressionValue(bArrDigest, "digest(...)");
        String h = ArraysKt.joinToString$default(bArrDigest, (CharSequence) "", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, new Function1() { // from class: com.exampletest.mobilestudiotest.net.ImageLoader$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return ImageLoader.diskFile$lambda$7(((Byte) obj).byteValue());
            }
        }, 30, (Object) null);
        return new File(dir, h + ".png");
    }

    static final CharSequence diskFile$lambda$7(byte it) {
        String str = String.format("%02x", Arrays.copyOf(new Object[]{Byte.valueOf(it)}, 1));
        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
        return str;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void loadFromDisk(String key) throws NoSuchAlgorithmException {
        Bitmap b;
        File f = diskFile(key);
        if (f != null && f.isFile()) {
            try {
                b = BitmapFactory.decodeFile(f.getPath());
            } catch (Throwable th) {
                b = null;
            }
            if (b != null) {
                done(key, b);
                return;
            }
        }
        if (!StringsKt.startsWith$default(key, "url:", false, 2, (Object) null)) {
            if (StringsKt.startsWith$default(key, "asset:", false, 2, (Object) null)) {
                idQueue.add(Long.valueOf(Long.parseLong(StringsKt.removePrefix(key, (CharSequence) "asset:"))));
                scheduleBatch();
                return;
            } else {
                fail(key);
                return;
            }
        }
        fetchUrl(key, StringsKt.removePrefix(key, (CharSequence) "url:"));
    }

    private final void scheduleBatch() {
        if (batchScheduled) {
            return;
        }
        batchScheduled = true;
        pool.execute(new Runnable() { // from class: com.exampletest.mobilestudiotest.net.ImageLoader$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() throws InterruptedException {
                ImageLoader.scheduleBatch$lambda$9();
            }
        });
    }

    static final void scheduleBatch$lambda$9() throws InterruptedException {
        Thread.sleep(80L);
        ImageLoader imageLoader = INSTANCE;
        batchScheduled = false;
        ConcurrentHashMap.KeySetView<Long, Boolean> idQueue2 = idQueue;
        Intrinsics.checkNotNullExpressionValue(idQueue2, "idQueue");
        List<Long> listTake = CollectionsKt.take(CollectionsKt.toList(idQueue2), 100);
        idQueue.removeAll(CollectionsKt.toSet(listTake));
        ConcurrentHashMap.KeySetView<Long, Boolean> idQueue3 = idQueue;
        Intrinsics.checkNotNullExpressionValue(idQueue3, "idQueue");
        if (!idQueue3.isEmpty()) {
            INSTANCE.scheduleBatch();
        }
        if (listTake.isEmpty()) {
            return;
        }
        try {
            Map<Long, String> mapThumbnailUrls = RobloxApi.INSTANCE.thumbnailUrls(listTake, "420x420");
            for (final Long id : listTake) {
                final String u = mapThumbnailUrls.get(id);
                if (u == null) {
                    INSTANCE.fail("asset:" + id);
                } else if (u.length() == 0) {
                    pending.remove("asset:" + id);
                    failed.put("asset:" + id, Long.valueOf(System.currentTimeMillis() - 55000));
                } else {
                    pool.execute(new Runnable() { // from class: com.exampletest.mobilestudiotest.net.ImageLoader$$ExternalSyntheticLambda1
                        @Override // java.lang.Runnable
                        public final void run() {
                            ImageLoader.INSTANCE.fetchUrl("asset:" + id, u);
                        }
                    });
                }
            }
        } catch (Exception e) {
            Iterator<Long> it = listTake.iterator();
            while (it.hasNext()) {
                INSTANCE.fail("asset:" + it.next());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void fetchUrl(String key, String url) {
        String lowerCase;
        try {
            String host = new URL(url).getHost();
            Intrinsics.checkNotNullExpressionValue(host, "getHost(...)");
            lowerCase = host.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        } catch (Exception e) {
            lowerCase = "";
        }
        try {
            String host2 = lowerCase;
            try {
                if (!WebPermissions.INSTANCE.isRobloxHost(host2)) {
                    throw new IOException("not a Roblox image");
                }
                byte[] bytes = Http.get$default(Http.INSTANCE, url, null, 8388608, 2, null);
                Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (b == null) {
                    throw new Exception("bad image");
                }
                File fileDiskFile = diskFile(key);
                if (fileDiskFile != null) {
                    try {
                        FilesKt.writeBytes(fileDiskFile, bytes);
                    } catch (Exception e2) {
                    }
                }
                done(key, b);
                return;
            } catch (Exception e3) {
            }
        } catch (Exception e4) {
        }
        fail(key);
    }

    public final int getEpoch() {
        return epoch;
    }

    private final void done(String key, Bitmap b) {
        mem.put(key, b);
        epoch++;
        pending.remove(key);
        Iterator it = listeners.iterator();
        while (it.hasNext()) {
            ((Function1) it.next()).invoke(key);
        }
    }

    private final void fail(String key) {
        pending.remove(key);
        failed.put(key, Long.valueOf(System.currentTimeMillis()));
    }
}
