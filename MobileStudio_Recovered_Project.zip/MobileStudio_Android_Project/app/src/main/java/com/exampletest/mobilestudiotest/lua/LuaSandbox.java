package com.exampletest.mobilestudiotest.lua;

import androidx.constraintlayout.core.motion.utils.TypedValues;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaString;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;

/* JADX INFO: compiled from: LuaSandbox.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eR\u0016\u0010\u0004\u001a\n \u0006*\u0004\u0018\u00010\u00050\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Lcom/exampletest/mobilestudiotest/lua/LuaSandbox;", "", "<init>", "()V", "ESC", "Lorg/luaj/vm2/LuaString;", "kotlin.jvm.PlatformType", "lockDown", "", "g", "Lorg/luaj/vm2/Globals;", "isBytecode", "", "v", "Lorg/luaj/vm2/LuaValue;", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class LuaSandbox {
    public static final LuaSandbox INSTANCE = new LuaSandbox();
    private static final LuaString ESC = LuaString.valueOf("\u001bLua");

    private LuaSandbox() {
    }

    public final void lockDown(Globals g) {
        Intrinsics.checkNotNullParameter(g, "g");
        for (String name : CollectionsKt.listOf((Object[]) new String[]{"package", "require", "luajava", "io", "dofile", "loadfile", "module"})) {
            g.set(name, LuaValue.NIL);
        }
        LuaValue realOs = g.get("os");
        LuaTable os = new LuaTable();
        if (realOs.istable()) {
            for (String k : CollectionsKt.listOf((Object[]) new String[]{"time", "clock", "date", "difftime"})) {
                os.set(k, realOs.get(k));
            }
        }
        g.set("os", os);
        LuaValue str = g.get(TypedValues.Custom.S_STRING);
        if (str.istable()) {
            str.set("dump", LuaValue.NIL);
        }
        LuaValue luaValue = LuaString.s_metatable;
        LuaValue shared = luaValue != null ? luaValue.get(LuaValue.INDEX) : null;
        if (shared != null && shared.istable()) {
            shared.set("dump", LuaValue.NIL);
        }
        final LuaValue realLoad = g.get("load");
        g.set("load", new VarArgFunction() { // from class: com.exampletest.mobilestudiotest.lua.LuaSandbox.lockDown.1
            @Override // org.luaj.vm2.lib.VarArgFunction, org.luaj.vm2.lib.LibFunction, org.luaj.vm2.LuaValue
            public Varargs invoke(Varargs a) {
                Intrinsics.checkNotNullParameter(a, "a");
                LuaValue chunk = a.arg1();
                if (chunk.isfunction()) {
                    StringBuilder sb = new StringBuilder();
                    int guard = 0;
                    while (true) {
                        int guard2 = guard + 1;
                        if (guard >= 100000) {
                            break;
                        }
                        LuaValue piece = chunk.call();
                        if (piece.isnil()) {
                            break;
                        }
                        if (piece.isstring()) {
                            String str2 = piece.tojstring();
                            Intrinsics.checkNotNullExpressionValue(str2, "tojstring(...)");
                            if (str2.length() == 0) {
                                break;
                            }
                        }
                        sb.append(piece.checkjstring());
                        if (sb.length() > 50000000) {
                            Varargs varargsVarargsOf = LuaValue.varargsOf(LuaValue.NIL, LuaValue.valueOf("chunk too large"));
                            Intrinsics.checkNotNullExpressionValue(varargsVarargsOf, "varargsOf(...)");
                            return varargsVarargsOf;
                        }
                        guard = guard2;
                    }
                    chunk = LuaValue.valueOf(sb.toString());
                }
                LuaSandbox luaSandbox = LuaSandbox.INSTANCE;
                Intrinsics.checkNotNull(chunk);
                if (luaSandbox.isBytecode(chunk)) {
                    Varargs varargsVarargsOf2 = LuaValue.varargsOf(LuaValue.NIL, LuaValue.valueOf("bytecode is not allowed"));
                    Intrinsics.checkNotNullExpressionValue(varargsVarargsOf2, "varargsOf(...)");
                    return varargsVarargsOf2;
                }
                Varargs varargsInvoke = realLoad.invoke(LuaValue.varargsOf(new LuaValue[]{chunk, a.arg(2), LuaValue.valueOf("t"), a.arg(4)}));
                Intrinsics.checkNotNullExpressionValue(varargsInvoke, "invoke(...)");
                return varargsInvoke;
            }
        });
    }

    public final boolean isBytecode(LuaValue v) {
        Intrinsics.checkNotNullParameter(v, "v");
        if (!v.isstring()) {
            return false;
        }
        LuaString s = v.checkstring();
        return (s.length() >= 1 && s.luaByte(0) == 27) || (s.length() >= ESC.length() && s.substring(0, ESC.length()).raweq(ESC));
    }
}
