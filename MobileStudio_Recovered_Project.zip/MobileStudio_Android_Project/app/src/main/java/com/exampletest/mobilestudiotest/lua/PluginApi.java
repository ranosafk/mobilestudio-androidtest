package com.exampletest.mobilestudiotest.lua;

import androidx.core.app.NotificationCompat;
import com.exampletest.mobilestudiotest.core.Studio;
import com.exampletest.mobilestudiotest.model.CFrame;
import com.exampletest.mobilestudiotest.model.Instance;
import com.exampletest.mobilestudiotest.model.Ray;
import com.exampletest.mobilestudiotest.model.Vector3;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import org.luaj.vm2.LuaBoolean;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaThread;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

/* JADX INFO: compiled from: RobloxGlobals.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J&\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u0005J\u0010\u0010\r\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\tH\u0002J\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0006\u001a\u00020\u0007J(\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u000b2\u0006\u0010\u0013\u001a\u00020\u000b2\u0006\u0010\u0014\u001a\u00020\u000bH\u0002J(\u0010\u0015\u001a\u00020\u00102\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0012\u001a\u00020\u000b2\u0006\u0010\u0018\u001a\u00020\u000bH\u0002¨\u0006\u0019"}, d2 = {"Lcom/exampletest/mobilestudiotest/lua/PluginApi;", "", "<init>", "()V", NotificationCompat.CATEGORY_CALL, "Lorg/luaj/vm2/Varargs;", "rt", "Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;", "inst", "Lcom/exampletest/mobilestudiotest/model/Instance;", "name", "", "a", "pluginId", "i", "pluginMouse", "Lorg/luaj/vm2/LuaTable;", "action", "id", "text", "tip", "menu", "studio", "Lcom/exampletest/mobilestudiotest/core/Studio;", "title", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class PluginApi {
    public static final PluginApi INSTANCE = new PluginApi();

    private PluginApi() {
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:150:0x0501  */
    /* JADX WARN: Code duplicated, block: B:152:0x0523  */
    /* JADX WARN: Code duplicated, block: B:153:0x052e  */
    /* JADX WARN: Code duplicated, block: B:156:0x0538  */
    /* JADX WARN: Code duplicated, block: B:159:0x053f  */
    /* JADX WARN: Code duplicated, block: B:163:0x0572  */
    /* JADX WARN: Code duplicated, block: B:164:0x0578  */
    /* JADX WARN: Code duplicated, block: B:166:0x057e  */
    /* JADX WARN: Code duplicated, block: B:167:0x0585  */
    /* JADX WARN: Code duplicated, block: B:170:0x05ae  */
    /* JADX WARN: Code duplicated, block: B:183:0x0608  */
    /* JADX WARN: Code duplicated, block: B:203:0x0543 A[SYNTHETIC] */
    /* JADX WARN: Code restructure failed: missing block: B:101:0x0334, code lost:
    
        if (r5.get("InitialEnabled").toboolean() == false) goto L103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x0336, code lost:
    
        r6 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:103:0x0339, code lost:
    
        r6 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x033a, code lost:
    
        r2.set("Enabled", java.lang.Boolean.valueOf(r6), false);
        r2.set("Title", r2.getName(), false);
        r2.set("ZIndexBehavior", new com.exampletest.mobilestudiotest.model.EnumValue(1), false);
     */
    /* JADX WARN: Code restructure failed: missing block: B:105:0x035a, code lost:
    
        if (r5.istable() == false) goto L107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:106:0x035c, code lost:
    
        r2.getAttributes().put("__w", java.lang.Integer.valueOf(r5.get("FloatingXSize").optint(com.google.android.material.card.MaterialCardViewHelper.DEFAULT_FADE_ANIM_DURATION)));
        r2.getAttributes().put("__h", java.lang.Integer.valueOf(r5.get("FloatingYSize").optint(com.google.android.material.card.MaterialCardViewHelper.DEFAULT_FADE_ANIM_DURATION)));
     */
    /* JADX WARN: Code restructure failed: missing block: B:107:0x0390, code lost:
    
        r10.addPluginWidget(r2, r29);
     */
    /* JADX WARN: Code restructure failed: missing block: B:115:0x03d5, code lost:
    
        if (r31.equals("PromptImportFile") != false) goto L116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:121:0x040d, code lost:
    
        if (r31.equals("SaveSelectedToRoblox") != false) goto L122;
     */
    /* JADX WARN: Code restructure failed: missing block: B:122:0x040f, code lost:
    
        r2 = org.luaj.vm2.LuaValue.NONE;
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, "NONE");
     */
    /* JADX WARN: Code restructure failed: missing block: B:146:0x04da, code lost:
    
        if (r31.equals(r4) != false) goto L147;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e4, code lost:
    
        if (r31.equals("CreateDockWidgetPluginGui") == false) goto L199;
     */
    /* JADX WARN: Code restructure failed: missing block: B:217:?, code lost:
    
        return r29.wrap(r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:222:?, code lost:
    
        return r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00fd, code lost:
    
        if (r31.equals("SetReady") == false) goto L199;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0109, code lost:
    
        if (r31.equals("OpenWikiPage") != false) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0116, code lost:
    
        if (r31.equals("CreateQWidgetPluginGui") != false) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x027e, code lost:
    
        if (r31.equals("Union") != false) goto L79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x02e1, code lost:
    
        if (r31.equals("StartDrag") == false) goto L199;
     */
    /* JADX WARN: Code restructure failed: missing block: B:97:0x0309, code lost:
    
        if (r31.equals("CreateDockWidgetPluginGuiAsync") != false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x030b, code lost:
    
        r2 = com.exampletest.mobilestudiotest.model.InstanceFactory.INSTANCE.create("DockWidgetPluginGui");
        r5 = r11.optjstring("Widget");
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, "optjstring(...)");
        r2.setName(r5);
        r5 = r32.arg(3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x0328, code lost:
    
        if (r5.istable() == false) goto L103;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final org.luaj.vm2.Varargs call(com.exampletest.mobilestudiotest.lua.LuaRuntime r29, com.exampletest.mobilestudiotest.model.Instance r30, java.lang.String r31, org.luaj.vm2.Varargs r32) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1760
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.exampletest.mobilestudiotest.lua.PluginApi.call(com.exampletest.mobilestudiotest.lua.LuaRuntime, com.exampletest.mobilestudiotest.model.Instance, java.lang.String, org.luaj.vm2.Varargs):org.luaj.vm2.Varargs");
    }

    private final String pluginId(Instance i) {
        return i.getName();
    }

    public final LuaTable pluginMouse(final LuaRuntime rt) {
        Intrinsics.checkNotNullParameter(rt, "rt");
        final LuaTable m = new LuaTable();
        m.set("Hit", LuaTypes.INSTANCE.wrap(CFrame.INSTANCE.getIDENTITY()));
        m.set("Target", LuaValue.NIL);
        m.set("X", 0);
        m.set("Y", 0);
        m.set("Icon", "");
        m.set("TargetFilter", LuaValue.NIL);
        m.set("Origin", LuaTypes.INSTANCE.wrap(CFrame.INSTANCE.getIDENTITY()));
        m.set("UnitRay", LuaTypes.INSTANCE.wrap(new Ray(Vector3.INSTANCE.getZERO(), new Vector3(0.0f, 0.0f, -1.0f))));
        m.set("ViewSizeX", 0);
        m.set("ViewSizeY", 0);
        m.set("ClassName", "PluginMouse");
        m.set("Name", "Instance");
        LuaTable mt = new LuaTable();
        mt.set("__type", "Instance");
        mt.set(LuaValue.INDEX, LuaTypesKt.fn2(new Function2() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda12
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return PluginApi.pluginMouse$lambda$10(rt, m, (LuaValue) obj, (LuaValue) obj2);
            }
        }));
        m.setmetatable(mt);
        return m;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0029, code lost:
    
        if (r4.equals("Button1Up") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0033, code lost:
    
        if (r4.equals("DragEnter") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x003d, code lost:
    
        if (r4.equals("WheelBackward") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0047, code lost:
    
        if (r4.equals("KeyDown") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0051, code lost:
    
        if (r4.equals("WheelForward") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x005b, code lost:
    
        if (r4.equals("KeyUp") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0064, code lost:
    
        if (r4.equals("Move") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x006d, code lost:
    
        if (r4.equals("Idle") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x008a, code lost:
    
        if (r4.equals("Button2Down") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0093, code lost:
    
        if (r4.equals("Button1Down") == false) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00b0, code lost:
    
        if (r4.equals("Changed") != false) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x001f, code lost:
    
        if (r4.equals("Button2Up") != false) goto L48;
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static final org.luaj.vm2.LuaValue pluginMouse$lambda$10(final com.exampletest.mobilestudiotest.lua.LuaRuntime r2, final org.luaj.vm2.LuaTable r3, org.luaj.vm2.LuaValue r4, org.luaj.vm2.LuaValue r5) {
        /*
            Method dump skipped, instruction units count: 254
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.exampletest.mobilestudiotest.lua.PluginApi.pluginMouse$lambda$10(com.exampletest.mobilestudiotest.lua.LuaRuntime, org.luaj.vm2.LuaTable, org.luaj.vm2.LuaValue, org.luaj.vm2.LuaValue):org.luaj.vm2.LuaValue");
    }

    static final Varargs pluginMouse$lambda$10$lambda$8(Varargs a) {
        Intrinsics.checkNotNullParameter(a, "a");
        LuaBoolean luaBooleanValueOf = LuaValue.valueOf(SetsKt.setOf((Object[]) new String[]{"Mouse", "PluginMouse", "Instance"}).contains(a.arg(2).tojstring()));
        Intrinsics.checkNotNullExpressionValue(luaBooleanValueOf, "valueOf(...)");
        return luaBooleanValueOf;
    }

    static final Varargs pluginMouse$lambda$10$lambda$9(LuaRuntime $rt, LuaTable $m, Varargs a) {
        Intrinsics.checkNotNullParameter(a, "a");
        return $rt.getApi().signal($m, "Changed:" + a.arg(2).tojstring());
    }

    private final LuaTable action(final LuaRuntime rt, String id, String text, String tip) {
        final LuaTable t = new LuaTable();
        t.set("ActionId", id);
        t.set("Text", text);
        t.set("StatusTip", tip);
        t.set("Enabled", LuaValue.TRUE);
        t.set("Checked", LuaValue.FALSE);
        String str = text;
        if (str.length() == 0) {
            str = id;
        }
        t.set("Name", str);
        LuaTable mt = new LuaTable();
        mt.set("__type", "Instance");
        mt.set(LuaValue.INDEX, LuaTypesKt.fn2(new Function2() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return PluginApi.action$lambda$12(rt, t, (LuaValue) obj, (LuaValue) obj2);
            }
        }));
        t.setmetatable(mt);
        return t;
    }

    static final LuaValue action$lambda$12(LuaRuntime $rt, LuaTable $t, LuaValue luaValue, LuaValue k) {
        Intrinsics.checkNotNullParameter(luaValue, "<unused var>");
        Intrinsics.checkNotNullParameter(k, "k");
        if (Intrinsics.areEqual(k.tojstring(), "Triggered")) {
            return $rt.getApi().signal($t, "Triggered");
        }
        LuaValue NIL = LuaValue.NIL;
        Intrinsics.checkNotNullExpressionValue(NIL, "NIL");
        return NIL;
    }

    private final LuaTable menu(final LuaRuntime rt, final Studio studio, String id, final String title) {
        LuaTable t = new LuaTable();
        final ArrayList items = new ArrayList();
        t.set("Title", title);
        t.set("Name", id);
        t.set("AddAction", LuaTypesKt.fnv(new Function1() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PluginApi.menu$lambda$13(items, (Varargs) obj);
            }
        }));
        t.set("AddNewAction", LuaTypesKt.fnv(new Function1() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PluginApi.menu$lambda$14(rt, items, (Varargs) obj);
            }
        }));
        t.set("AddSeparator", LuaTypesKt.fnv(new Function1() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PluginApi.menu$lambda$15(items, (Varargs) obj);
            }
        }));
        t.set("AddMenu", LuaTypesKt.fnv(new Function1() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PluginApi.menu$lambda$16(items, (Varargs) obj);
            }
        }));
        t.set("Clear", LuaTypesKt.fnv(new Function1() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PluginApi.menu$lambda$17(items, (Varargs) obj);
            }
        }));
        t.set("Destroy", LuaTypesKt.fnv(new Function1() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda7
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PluginApi.menu$lambda$18(items, (Varargs) obj);
            }
        }));
        t.set("ShowAsync", LuaTypesKt.fnv(new Function1() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda8
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PluginApi.menu$lambda$26(rt, items, studio, title, (Varargs) obj);
            }
        }));
        LuaTable mt = new LuaTable();
        mt.set("__type", "Instance");
        t.setmetatable(mt);
        return t;
    }

    static final Varargs menu$lambda$13(ArrayList $items, Varargs a) {
        Intrinsics.checkNotNullParameter(a, "a");
        $items.add(a.arg(2));
        LuaValue NONE = LuaValue.NONE;
        Intrinsics.checkNotNullExpressionValue(NONE, "NONE");
        return NONE;
    }

    static final Varargs menu$lambda$14(LuaRuntime $rt, ArrayList $items, Varargs a) {
        Intrinsics.checkNotNullParameter(a, "a");
        PluginApi pluginApi = INSTANCE;
        String strOptjstring = a.arg(2).optjstring("");
        Intrinsics.checkNotNullExpressionValue(strOptjstring, "optjstring(...)");
        String strOptjstring2 = a.arg(3).optjstring("");
        Intrinsics.checkNotNullExpressionValue(strOptjstring2, "optjstring(...)");
        LuaTable act = pluginApi.action($rt, strOptjstring, strOptjstring2, "");
        $items.add(act);
        return act;
    }

    static final Varargs menu$lambda$15(ArrayList $items, Varargs it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $items.add(LuaValue.NIL);
        LuaValue NONE = LuaValue.NONE;
        Intrinsics.checkNotNullExpressionValue(NONE, "NONE");
        return NONE;
    }

    static final Varargs menu$lambda$16(ArrayList $items, Varargs a) {
        Intrinsics.checkNotNullParameter(a, "a");
        $items.add(a.arg(2));
        LuaValue NONE = LuaValue.NONE;
        Intrinsics.checkNotNullExpressionValue(NONE, "NONE");
        return NONE;
    }

    static final Varargs menu$lambda$17(ArrayList $items, Varargs it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $items.clear();
        LuaValue NONE = LuaValue.NONE;
        Intrinsics.checkNotNullExpressionValue(NONE, "NONE");
        return NONE;
    }

    static final Varargs menu$lambda$18(ArrayList $items, Varargs it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $items.clear();
        LuaValue NONE = LuaValue.NONE;
        Intrinsics.checkNotNullExpressionValue(NONE, "NONE");
        return NONE;
    }

    static final Varargs menu$lambda$26(final LuaRuntime $rt, ArrayList $items, final Studio $studio, final String $title, Varargs varargs) {
        Intrinsics.checkNotNullParameter(varargs, "<unused var>");
        final LuaThread co = $rt.currentCoroutine();
        if (co == null) {
            LuaValue NIL = LuaValue.NIL;
            Intrinsics.checkNotNullExpressionValue(NIL, "NIL");
            return NIL;
        }
        Collection arrayList = new ArrayList();
        Iterator it = $items.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            LuaValue luaValue = (LuaValue) next;
            if (luaValue.istable() && !luaValue.get("ActionId").isnil()) {
                arrayList.add(next);
            }
        }
        final List acts = (List) arrayList;
        List<LuaValue> list = acts;
        Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        for (LuaValue luaValue2 : list) {
            String strOptjstring = luaValue2.get("Text").optjstring("");
            if (strOptjstring.length() == 0) {
                strOptjstring = luaValue2.get("ActionId").tojstring();
            }
            arrayList2.add(strOptjstring);
        }
        final List labels = (List) arrayList2;
        $studio.getMain().post(new Runnable() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                PluginApi.menu$lambda$26$lambda$25($studio, $title, labels, $rt, co, acts);
            }
        });
        Varargs varargsYield = $rt.getGlobals().yield(LuaValue.NONE);
        Intrinsics.checkNotNullExpressionValue(varargsYield, "yield(...)");
        return varargsYield;
    }

    static final void menu$lambda$26$lambda$25(final Studio $studio, String $title, List $labels, final LuaRuntime $rt, final LuaThread $co, final List $acts) {
        Function3<String, List<String>, Function1<? super Integer, Unit>, Unit> pluginMenuHandler = $studio.getPluginMenuHandler();
        if (pluginMenuHandler == null) {
            synchronized ($studio.getLock()) {
                LuaValue NIL = LuaValue.NIL;
                Intrinsics.checkNotNullExpressionValue(NIL, "NIL");
                $rt.resume($co, NIL);
                Unit unit = Unit.INSTANCE;
            }
            return;
        }
        pluginMenuHandler.invoke($title, $labels, new Function1() { // from class: com.exampletest.mobilestudiotest.lua.PluginApi$$ExternalSyntheticLambda13
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return PluginApi.menu$lambda$26$lambda$25$lambda$24($studio, $acts, $rt, $co, ((Integer) obj).intValue());
            }
        });
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0017 A[Catch: all -> 0x0040, TryCatch #0 {, blocks: (B:6:0x0009, B:11:0x0017, B:13:0x0020, B:15:0x0026, B:16:0x0030, B:12:0x001e), top: B:23:0x0009 }] */
    /* JADX WARN: Code duplicated, block: B:12:0x001e A[Catch: all -> 0x0040, TryCatch #0 {, blocks: (B:6:0x0009, B:11:0x0017, B:13:0x0020, B:15:0x0026, B:16:0x0030, B:12:0x001e), top: B:23:0x0009 }] */
    /* JADX WARN: Code duplicated, block: B:15:0x0026 A[Catch: all -> 0x0040, TryCatch #0 {, blocks: (B:6:0x0009, B:11:0x0017, B:13:0x0020, B:15:0x0026, B:16:0x0030, B:12:0x001e), top: B:23:0x0009 }] */
    /* JADX WARN: Code duplicated, block: B:9:0x0014  */
    static final Unit menu$lambda$26$lambda$25$lambda$24(Studio $studio, List $acts, LuaRuntime $rt, LuaThread $co, int idx) {
        boolean z;
        LuaValue luaValue;
        synchronized ($studio.getLock()) {
            if (idx < 0) {
                z = false;
                if (z) {
                    luaValue = (LuaValue) $acts.get(idx);
                } else {
                    luaValue = LuaValue.NIL;
                }
                if (!luaValue.isnil()) {
                    Intrinsics.checkNotNull(luaValue);
                    $rt.fire(luaValue, "Triggered", new LuaValue[0]);
                }
                Intrinsics.checkNotNull(luaValue);
                $rt.resume($co, luaValue);
                Unit unit = Unit.INSTANCE;
            } else {
                if (idx < $acts.size()) {
                    z = true;
                } else {
                    z = false;
                }
                if (z) {
                    luaValue = (LuaValue) $acts.get(idx);
                } else {
                    luaValue = LuaValue.NIL;
                }
                if (!luaValue.isnil()) {
                    Intrinsics.checkNotNull(luaValue);
                    $rt.fire(luaValue, "Triggered", new LuaValue[0]);
                }
                Intrinsics.checkNotNull(luaValue);
                $rt.resume($co, luaValue);
                Unit unit2 = Unit.INSTANCE;
            }
            throw th;
        }
        return Unit.INSTANCE;
    }
}
