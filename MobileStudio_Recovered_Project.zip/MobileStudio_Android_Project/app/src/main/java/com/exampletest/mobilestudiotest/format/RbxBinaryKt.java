package com.exampletest.mobilestudiotest.format;

import com.exampletest.mobilestudiotest.model.BinaryString;
import com.exampletest.mobilestudiotest.model.CFrame;
import com.exampletest.mobilestudiotest.model.Vector3;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

/* JADX INFO: compiled from: RbxBinary.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\u001a\u0010\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0002\u001a\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0002\"\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0007¨\u0006\f"}, d2 = {"bytesToStringValue", "", "b", "", "NORMALS", "", "Lcom/exampletest/mobilestudiotest/model/Vector3;", "[Lcom/exampletest/mobilestudiotest/model/Vector3;", "rotationFromId", "Lcom/exampletest/mobilestudiotest/model/CFrame;", "id", "", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class RbxBinaryKt {
    private static final Vector3[] NORMALS = {Vector3.INSTANCE.getX(), Vector3.INSTANCE.getY(), Vector3.INSTANCE.getZ(), Vector3.INSTANCE.getX().unaryMinus(), Vector3.INSTANCE.getY().unaryMinus(), Vector3.INSTANCE.getZ().unaryMinus()};

    /* JADX INFO: Access modifiers changed from: private */
    public static final Object bytesToStringValue(byte[] b) {
        try {
            CharsetDecoder dec = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
            String string = dec.decode(ByteBuffer.wrap(b)).toString();
            Intrinsics.checkNotNull(string);
            return string;
        } catch (CharacterCodingException e) {
            return new BinaryString(b);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final CFrame rotationFromId(int id) {
        int v = id - 1;
        Vector3 r = NORMALS[v / 6];
        Vector3 u = NORMALS[v % 6];
        return CFrame.INSTANCE.fromColumns(Vector3.INSTANCE.getZERO(), r, u, r.cross(u));
    }
}
