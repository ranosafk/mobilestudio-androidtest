package com.exampletest.mobilestudiotest.format;

import androidx.savedstate.serialization.ClassDiscriminatorModeKt;
import com.exampletest.mobilestudiotest.model.Axes;
import com.exampletest.mobilestudiotest.model.BrickColorV;
import com.exampletest.mobilestudiotest.model.CFrame;
import com.exampletest.mobilestudiotest.model.Color3;
import com.exampletest.mobilestudiotest.model.ColorKey;
import com.exampletest.mobilestudiotest.model.ColorSequence;
import com.exampletest.mobilestudiotest.model.ContentValue;
import com.exampletest.mobilestudiotest.model.EnumValue;
import com.exampletest.mobilestudiotest.model.Faces;
import com.exampletest.mobilestudiotest.model.FontValue;
import com.exampletest.mobilestudiotest.model.Instance;
import com.exampletest.mobilestudiotest.model.NumberKey;
import com.exampletest.mobilestudiotest.model.NumberRange;
import com.exampletest.mobilestudiotest.model.NumberSequence;
import com.exampletest.mobilestudiotest.model.OptionalCFrame;
import com.exampletest.mobilestudiotest.model.PhysicalProps;
import com.exampletest.mobilestudiotest.model.RawPropValue;
import com.exampletest.mobilestudiotest.model.Ray;
import com.exampletest.mobilestudiotest.model.Rect;
import com.exampletest.mobilestudiotest.model.SecurityCaps;
import com.exampletest.mobilestudiotest.model.SharedStr;
import com.exampletest.mobilestudiotest.model.UDim;
import com.exampletest.mobilestudiotest.model.UDim2;
import com.exampletest.mobilestudiotest.model.UniqueId;
import com.exampletest.mobilestudiotest.model.Vector2;
import com.exampletest.mobilestudiotest.model.Vector3;
import com.exampletest.mobilestudiotest.model.Vector3int16;
import com.github.luben.zstd.Zstd;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.UByte;
import kotlin.collections.ArraysKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlinx.coroutines.DebugKt;

/* JADX INFO: compiled from: RbxBinary.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001:\u000212B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010\u0017\u001a\u00020\u0018J(\u0010\u0019\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u00032\u0006\u0010\u001b\u001a\u00020\f2\u0006\u0010\u001c\u001a\u00020\f2\u0006\u0010\u001d\u001a\u00020\fH\u0002J\u0010\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0003H\u0002J\u0010\u0010!\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0003H\u0002J\u0010\u0010\"\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0003H\u0002J\u001e\u0010#\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u00032\f\u0010$\u001a\b\u0012\u0004\u0012\u00020\r0%H\u0002J\u0010\u0010&\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0003H\u0002J\u001e\u0010'\u001a\b\u0012\u0004\u0012\u00020)0(2\u0006\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020\fH\u0002J>\u0010-\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00010(2\u0006\u0010*\u001a\u00020+2\u0006\u0010.\u001a\u00020\f2\u0006\u0010,\u001a\u00020\f2\f\u0010/\u001a\b\u0012\u0004\u0012\u00020\r0(2\u0006\u00100\u001a\u00020\bH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0006\u001a\u0012\u0012\u0004\u0012\u00020\b0\u0007j\b\u0012\u0004\u0012\u00020\b`\tX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\n\u001a\u001e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r0\u000bj\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r`\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\u000f\u001a\u001e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00100\u000bj\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u0010`\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0011\u001a\u0012\u0012\u0004\u0012\u00020\u00030\u0007j\b\u0012\u0004\u0012\u00020\u0003`\tX\u0082\u0004¢\u0006\u0002\n\u0000RB\u0010\u0012\u001a6\u0012\u0016\u0012\u0014\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\f0\u00130\u0007j\u001a\u0012\u0016\u0012\u0014\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\f0\u0013`\tX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\u0014\u001a\u001e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0015j\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b`\u0016X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00063"}, d2 = {"Lcom/exampletest/mobilestudiotest/format/RbxBinaryReader;", "", "data", "", "<init>", "([B)V", "warnings", "Ljava/util/ArrayList;", "", "Lkotlin/collections/ArrayList;", "instances", "Ljava/util/HashMap;", "", "Lcom/exampletest/mobilestudiotest/model/Instance;", "Lkotlin/collections/HashMap;", "classes", "Lcom/exampletest/mobilestudiotest/format/RbxBinaryReader$ClassInfo;", "sharedStrings", "pendingRefs", "Lkotlin/Triple;", "meta", "Ljava/util/LinkedHashMap;", "Lkotlin/collections/LinkedHashMap;", "read", "Lcom/exampletest/mobilestudiotest/format/RbxDocument;", "decompress", "src", DebugKt.DEBUG_PROPERTY_VALUE_OFF, "len", "out", "readMeta", "", "d", "readSstr", "readInst", "readPrnt", "roots", "", "readProp", "readCFrames", "", "Lcom/exampletest/mobilestudiotest/model/CFrame;", "r", "Lcom/exampletest/mobilestudiotest/format/ByteReader;", "n", "readValues", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "insts", "name", "Chunk", "ClassInfo", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class RbxBinaryReader {
    private final HashMap<Integer, ClassInfo> classes;
    private final byte[] data;
    private final HashMap<Integer, Instance> instances;
    private final LinkedHashMap<String, String> meta;
    private final ArrayList<Triple<Instance, String, Integer>> pendingRefs;
    private final ArrayList<byte[]> sharedStrings;
    private final ArrayList<String> warnings;

    /* JADX INFO: compiled from: RbxBinary.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0007\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"Lcom/exampletest/mobilestudiotest/format/RbxBinaryReader$Chunk;", "", "name", "", "data", "", "<init>", "(Ljava/lang/String;[B)V", "getName", "()Ljava/lang/String;", "getData", "()[B", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final class Chunk {
        private final byte[] data;
        private final String name;

        public Chunk(String name, byte[] data) {
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(data, "data");
            this.name = name;
            this.data = data;
        }

        public final byte[] getData() {
            return this.data;
        }

        public final String getName() {
            return this.name;
        }
    }

    public RbxBinaryReader(byte[] data) {
        Intrinsics.checkNotNullParameter(data, "data");
        this.data = data;
        this.warnings = new ArrayList<>();
        this.instances = new HashMap<>();
        this.classes = new HashMap<>();
        this.sharedStrings = new ArrayList<>();
        this.pendingRefs = new ArrayList<>();
        this.meta = new LinkedHashMap<>();
    }

    /* JADX INFO: compiled from: RbxBinary.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0007\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"Lcom/exampletest/mobilestudiotest/format/RbxBinaryReader$ClassInfo;", "", "name", "", "refs", "", "<init>", "(Ljava/lang/String;[I)V", "getName", "()Ljava/lang/String;", "getRefs", "()[I", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final class ClassInfo {
        private final String name;
        private final int[] refs;

        public ClassInfo(String name, int[] refs) {
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(refs, "refs");
            this.name = name;
            this.refs = refs;
        }

        public final String getName() {
            return this.name;
        }

        public final int[] getRefs() {
            return this.refs;
        }
    }

    public final RbxDocument read() throws RbxFormatException {
        boolean z;
        char c;
        boolean z2;
        String strTrimEnd;
        byte[] bArrDecompress;
        ByteReader byteReader = new ByteReader(this.data, 0, 0, 6, null);
        byteReader.setPos(14);
        int iU16 = byteReader.u16();
        if (iU16 != 0) {
            this.warnings.add("Unknown file version " + iU16);
        }
        byteReader.i32();
        byteReader.i32();
        byteReader.bytes(8);
        ArrayList arrayList = new ArrayList();
        do {
            z = true;
            c = 4;
            z2 = false;
            if (byteReader.remaining() < 16) {
                break;
            }
            strTrimEnd = StringsKt.trimEnd(new String(byteReader.bytes(4), Charsets.ISO_8859_1), 0);
            int iI32 = byteReader.i32();
            int iI33 = byteReader.i32();
            byteReader.i32();
            if (iI32 == 0) {
                bArrDecompress = byteReader.bytes(iI33);
            } else {
                int pos = byteReader.getPos();
                byteReader.bytes(iI32);
                bArrDecompress = decompress(this.data, pos, iI32, iI33);
            }
            arrayList.add(new Chunk(strTrimEnd, bArrDecompress));
        } while (!Intrinsics.areEqual(strTrimEnd, "END"));
        Iterator it = arrayList.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (it.hasNext()) {
            Object next = it.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            Chunk chunk = (Chunk) next;
            if (Intrinsics.areEqual(chunk.getName(), "META")) {
                readMeta(chunk.getData());
            }
        }
        Iterator it2 = arrayList.iterator();
        Intrinsics.checkNotNullExpressionValue(it2, "iterator(...)");
        while (it2.hasNext()) {
            Object next2 = it2.next();
            Intrinsics.checkNotNullExpressionValue(next2, "next(...)");
            Chunk chunk2 = (Chunk) next2;
            if (Intrinsics.areEqual(chunk2.getName(), "SSTR")) {
                readSstr(chunk2.getData());
            }
        }
        Iterator it3 = arrayList.iterator();
        Intrinsics.checkNotNullExpressionValue(it3, "iterator(...)");
        while (it3.hasNext()) {
            Object next3 = it3.next();
            Intrinsics.checkNotNullExpressionValue(next3, "next(...)");
            Chunk chunk3 = (Chunk) next3;
            if (Intrinsics.areEqual(chunk3.getName(), "INST")) {
                readInst(chunk3.getData());
            }
        }
        Iterator it4 = arrayList.iterator();
        Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
        while (it4.hasNext()) {
            Object next4 = it4.next();
            Intrinsics.checkNotNullExpressionValue(next4, "next(...)");
            Chunk chunk4 = (Chunk) next4;
            if (Intrinsics.areEqual(chunk4.getName(), "PROP")) {
                try {
                    readProp(chunk4.getData());
                } catch (Exception e) {
                    this.warnings.add("Skipped a property: " + e.getMessage());
                    z = z;
                    c = c;
                    z2 = z2;
                }
            }
        }
        boolean z3 = z;
        char c2 = c;
        boolean z4 = z2;
        Iterator<Triple<Instance, String, Integer>> it5 = this.pendingRefs.iterator();
        Intrinsics.checkNotNullExpressionValue(it5, "iterator(...)");
        while (it5.hasNext()) {
            Triple<Instance, String, Integer> next5 = it5.next();
            Intrinsics.checkNotNullExpressionValue(next5, "next(...)");
            Triple<Instance, String, Integer> triple = next5;
            Instance instanceComponent1 = triple.component1();
            String strComponent2 = triple.component2();
            int iIntValue = triple.component3().intValue();
            instanceComponent1.getProps().put(strComponent2, iIntValue < 0 ? null : this.instances.get(Integer.valueOf(iIntValue)));
            it5 = it5;
            byteReader = byteReader;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it6 = arrayList.iterator();
        Intrinsics.checkNotNullExpressionValue(it6, "iterator(...)");
        while (it6.hasNext()) {
            Object next6 = it6.next();
            Intrinsics.checkNotNullExpressionValue(next6, "next(...)");
            Chunk chunk5 = (Chunk) next6;
            if (Intrinsics.areEqual(chunk5.getName(), "PRNT")) {
                readPrnt(chunk5.getData(), arrayList2);
            }
        }
        Iterator it7 = arrayList.iterator();
        Intrinsics.checkNotNullExpressionValue(it7, "iterator(...)");
        while (it7.hasNext()) {
            Object next7 = it7.next();
            Intrinsics.checkNotNullExpressionValue(next7, "next(...)");
            Chunk chunk6 = (Chunk) next7;
            String[] strArr = new String[7];
            strArr[z4 ? 1 : 0] = "META";
            strArr[z3 ? 1 : 0] = "SSTR";
            strArr[2] = "INST";
            strArr[3] = "PROP";
            strArr[c2] = "PRNT";
            strArr[5] = "END";
            strArr[6] = "SIGN";
            if (!SetsKt.setOf((Object[]) strArr).contains(chunk6.getName())) {
                this.warnings.add("Ignored unknown chunk " + chunk6.getName());
                arrayList2 = arrayList2;
            }
        }
        return new RbxDocument(arrayList2, this.meta, this.warnings);
    }

    private final byte[] decompress(byte[] src, int off, int len, int out) throws RbxFormatException {
        boolean isZstd = len >= 4 && src[off] == 40 && src[off + 1] == -75 && src[off + 2] == 47 && src[off + 3] == -3;
        if (isZstd) {
            try {
                byte[] bArrDecompress = Zstd.decompress(ArraysKt.copyOfRange(src, off, off + len), out);
                Intrinsics.checkNotNull(bArrDecompress);
                return bArrDecompress;
            } catch (Throwable e) {
                throw new RbxFormatException("Could not decompress ZSTD chunk: " + e.getMessage());
            }
        }
        return Lz4.INSTANCE.decompress(src, off, len, out);
    }

    private final void readMeta(byte[] d) throws RbxFormatException {
        ByteReader r = new ByteReader(d, 0, 0, 6, null);
        int n = r.i32();
        for (int i = 0; i < n; i++) {
            this.meta.put(r.string(), r.string());
        }
    }

    private final void readSstr(byte[] d) throws RbxFormatException {
        ByteReader r = new ByteReader(d, 0, 0, 6, null);
        r.i32();
        int n = r.i32();
        for (int i = 0; i < n; i++) {
            r.bytes(16);
            this.sharedStrings.add(r.stringBytes());
        }
    }

    private final void readInst(byte[] d) throws RbxFormatException {
        ByteReader r = new ByteReader(d, 0, 0, 6, null);
        int classId = r.i32();
        String cls = r.string();
        int format = r.u8();
        int n = r.i32();
        int[] refs = r.refArray(n);
        boolean isService = format == 1;
        if (isService) {
            r.bytes(n);
        }
        this.classes.put(Integer.valueOf(classId), new ClassInfo(cls, refs));
        for (int ref : refs) {
            Instance inst = new Instance(cls);
            inst.setService(isService);
            inst.setLoadedRef(ref);
            this.instances.put(Integer.valueOf(ref), inst);
        }
    }

    private final void readPrnt(byte[] d, List<Instance> roots) throws RbxFormatException {
        ByteReader r = new ByteReader(d, 0, 0, 6, null);
        r.u8();
        int n = r.i32();
        int[] kids = r.refArray(n);
        int[] parents = r.refArray(n);
        for (int i = 0; i < n; i++) {
            Instance c = this.instances.get(Integer.valueOf(kids[i]));
            if (c != null) {
                Instance p = parents[i] < 0 ? null : this.instances.get(Integer.valueOf(parents[i]));
                if (p == null) {
                    roots.add(c);
                } else {
                    c.attachRaw(p);
                }
            }
        }
    }

    private final void readProp(byte[] d) throws RbxFormatException {
        RbxBinaryReader rbxBinaryReader = this;
        ByteReader r = new ByteReader(d, 0, 0, 6, null);
        int classId = r.i32();
        String name = r.string();
        int type = r.u8();
        ClassInfo ci = rbxBinaryReader.classes.get(Integer.valueOf(classId));
        if (ci == null) {
            return;
        }
        int[] refs = ci.getRefs();
        Collection arrayList = new ArrayList(refs.length);
        int length = refs.length;
        int i = 0;
        while (i < length) {
            int[] iArr = refs;
            Instance instance = rbxBinaryReader.instances.get(Integer.valueOf(refs[i]));
            Intrinsics.checkNotNull(instance);
            arrayList.add(instance);
            i++;
            rbxBinaryReader = this;
            refs = iArr;
        }
        List insts = (List) arrayList;
        int n = insts.size();
        int payloadStart = r.getPos();
        try {
            List<Object> values = readValues(r, type, n, insts, name);
            for (int i2 = 0; i2 < n; i2++) {
                if (type != 19) {
                    ((Instance) insts.get(i2)).getProps().put(name, values.get(i2));
                }
                ((Instance) insts.get(i2)).getPropTypes().put(name, Integer.valueOf(type));
            }
        } catch (Exception e) {
            byte[] payload = ArraysKt.copyOfRange(d, payloadStart, d.length);
            this.warnings.add("Preserved " + ci.getName() + "." + name + " (unsupported type 0x" + Integer.toHexString(type) + ")");
            for (int i3 = 0; i3 < n; i3++) {
                ((Instance) insts.get(i3)).getProps().put(name, new RawPropValue(type, payload, i3, n));
                ((Instance) insts.get(i3)).getPropTypes().put(name, Integer.valueOf(type));
            }
        }
    }

    private final List<CFrame> readCFrames(ByteReader r, int n) throws RbxFormatException {
        ArrayList rots = new ArrayList(n);
        for (int i = 0; i < n; i++) {
            int iU8 = r.u8();
            if (iU8 != 0) {
                rots.add(RbxBinaryKt.rotationFromId(iU8));
            } else {
                float[] fArr = new float[9];
                for (int i2 = 0; i2 < 9; i2++) {
                    fArr[i2] = r.f32();
                }
                rots.add(new CFrame(0.0f, 0.0f, 0.0f, fArr[0], fArr[1], fArr[2], fArr[3], fArr[4], fArr[5], fArr[6], fArr[7], fArr[8]));
            }
        }
        float[] xs = r.f32Array(n);
        float[] ys = r.f32Array(n);
        float[] zs = r.f32Array(n);
        ArrayList arrayList = new ArrayList(n);
        for (int i3 = 0; i3 < n; i3++) {
            int i4 = i3;
            arrayList.add(((CFrame) rots.get(i4)).withPosition(new Vector3(xs[i4], ys[i4], zs[i4])));
        }
        return arrayList;
    }

    private final List<Object> readValues(ByteReader r, int type, int n, List<? extends Instance> insts, String name) throws RbxFormatException {
        PhysicalProps physicalProps;
        int oi;
        ContentValue contentValue;
        switch (type) {
            case 1:
                ArrayList arrayList = new ArrayList(n);
                for (int i = 0; i < n; i++) {
                    arrayList.add(RbxBinaryKt.bytesToStringValue(r.stringBytes()));
                }
                return arrayList;
            case 2:
                ArrayList arrayList2 = new ArrayList(n);
                for (int i2 = 0; i2 < n; i2++) {
                    arrayList2.add(Boolean.valueOf(r.u8() != 0));
                }
                return arrayList2;
            case 3:
                return ArraysKt.toList(r.i32Array(n));
            case 4:
                return ArraysKt.toList(r.f32Array(n));
            case 5:
                ArrayList arrayList3 = new ArrayList(n);
                for (int i3 = 0; i3 < n; i3++) {
                    arrayList3.add(Double.valueOf(r.f64()));
                }
                return arrayList3;
            case 6:
                float[] s = r.f32Array(n);
                int[] o = r.i32Array(n);
                ArrayList arrayList4 = new ArrayList(n);
                for (int i4 = 0; i4 < n; i4++) {
                    int i5 = i4;
                    arrayList4.add(new UDim(s[i5], o[i5]));
                }
                return arrayList4;
            case 7:
                float[] xs = r.f32Array(n);
                float[] ys = r.f32Array(n);
                int[] xo = r.i32Array(n);
                int[] yo = r.i32Array(n);
                ArrayList arrayList5 = new ArrayList(n);
                int i6 = 0;
                while (i6 < n) {
                    int i7 = i6;
                    arrayList5.add(new UDim2(xs[i7], xo[i7], ys[i7], yo[i7]));
                    i6++;
                    xs = xs;
                }
                return arrayList5;
            case 8:
                ArrayList arrayList6 = new ArrayList(n);
                for (int i8 = 0; i8 < n; i8++) {
                    arrayList6.add(new Ray(new Vector3(r.f32(), r.f32(), r.f32()), new Vector3(r.f32(), r.f32(), r.f32())));
                }
                return arrayList6;
            case 9:
                ArrayList arrayList7 = new ArrayList(n);
                for (int i9 = 0; i9 < n; i9++) {
                    arrayList7.add(new Faces(r.u8()));
                }
                return arrayList7;
            case 10:
                ArrayList arrayList8 = new ArrayList(n);
                for (int i10 = 0; i10 < n; i10++) {
                    arrayList8.add(new Axes(r.u8()));
                }
                return arrayList8;
            case 11:
                int[] iArrU32Array = r.u32Array(n);
                Collection arrayList9 = new ArrayList(iArrU32Array.length);
                for (int i11 : iArrU32Array) {
                    arrayList9.add(new BrickColorV(i11));
                }
                return (List) arrayList9;
            case 12:
                float[] a = r.f32Array(n);
                float[] b = r.f32Array(n);
                float[] c = r.f32Array(n);
                ArrayList arrayList10 = new ArrayList(n);
                for (int i12 = 0; i12 < n; i12++) {
                    int i13 = i12;
                    arrayList10.add(new Color3(a[i13], b[i13], c[i13]));
                }
                return arrayList10;
            case 13:
                float[] a2 = r.f32Array(n);
                float[] b2 = r.f32Array(n);
                ArrayList arrayList11 = new ArrayList(n);
                for (int i14 = 0; i14 < n; i14++) {
                    int i15 = i14;
                    arrayList11.add(new Vector2(a2[i15], b2[i15]));
                }
                return arrayList11;
            case 14:
                float[] a3 = r.f32Array(n);
                float[] b3 = r.f32Array(n);
                float[] c2 = r.f32Array(n);
                ArrayList arrayList12 = new ArrayList(n);
                for (int i16 = 0; i16 < n; i16++) {
                    int i17 = i16;
                    arrayList12.add(new Vector3(a3[i17], b3[i17], c2[i17]));
                }
                return arrayList12;
            case 15:
            case 17:
            case 29:
            default:
                throw new RbxFormatException("unsupported type 0x" + Integer.toHexString(type) + " for '" + name + "'");
            case 16:
                return readCFrames(r, n);
            case 18:
                int[] iArrU32Array2 = r.u32Array(n);
                Collection arrayList13 = new ArrayList(iArrU32Array2.length);
                for (int i18 : iArrU32Array2) {
                    arrayList13.add(new EnumValue(i18));
                }
                return (List) arrayList13;
            case 19:
                int[] refs = r.refArray(n);
                for (int i19 = 0; i19 < n; i19++) {
                    this.pendingRefs.add(new Triple<>(insts.get(i19), name, Integer.valueOf(refs[i19])));
                }
                ArrayList arrayList14 = new ArrayList(n);
                for (int i20 = 0; i20 < n; i20++) {
                    arrayList14.add(null);
                }
                return arrayList14;
            case 20:
                ArrayList arrayList15 = new ArrayList(n);
                for (int i21 = 0; i21 < n; i21++) {
                    arrayList15.add(new Vector3int16(readValues$lambda$19$s16(r), readValues$lambda$19$s16(r), readValues$lambda$19$s16(r)));
                }
                return arrayList15;
            case 21:
                ArrayList arrayList16 = new ArrayList(n);
                int i22 = 0;
                while (i22 < n) {
                    int iI32 = r.i32();
                    ArrayList arrayList17 = new ArrayList(iI32);
                    int i23 = 0;
                    while (i23 < iI32) {
                        arrayList17.add(new NumberKey(r.f32(), r.f32(), r.f32()));
                        i23++;
                        i22 = i22;
                    }
                    arrayList16.add(new NumberSequence(arrayList17));
                    i22++;
                }
                return arrayList16;
            case 22:
                int i24 = 0;
                ArrayList arrayList18 = new ArrayList(n);
                int i25 = 0;
                while (i25 < n) {
                    int i26 = i25;
                    int iI33 = r.i32();
                    ArrayList arrayList19 = new ArrayList(iI33);
                    int i27 = i24;
                    while (i27 < iI33) {
                        arrayList19.add(new ColorKey(r.f32(), new Color3(r.f32(), r.f32(), r.f32()), r.f32()));
                        i27++;
                        i25 = i25;
                        i26 = i26;
                    }
                    arrayList18.add(new ColorSequence(arrayList19));
                    i25++;
                    i24 = 0;
                }
                return arrayList18;
            case 23:
                ArrayList arrayList20 = new ArrayList(n);
                for (int i28 = 0; i28 < n; i28++) {
                    arrayList20.add(new NumberRange(r.f32(), r.f32()));
                }
                return arrayList20;
            case 24:
                float[] a4 = r.f32Array(n);
                float[] b4 = r.f32Array(n);
                float[] c3 = r.f32Array(n);
                float[] e = r.f32Array(n);
                ArrayList arrayList21 = new ArrayList(n);
                for (int i29 = 0; i29 < n; i29++) {
                    int i30 = i29;
                    arrayList21.add(new Rect(a4[i30], b4[i30], c3[i30], e[i30]));
                }
                return arrayList21;
            case 25:
                ArrayList arrayList22 = new ArrayList(n);
                for (int i31 = 0; i31 < n; i31++) {
                    int iU8 = r.u8();
                    if ((iU8 & 1) != 0) {
                        physicalProps = new PhysicalProps(iU8, r.f32(), r.f32(), r.f32(), r.f32(), r.f32(), 0.0f, 64, null);
                        if ((iU8 & 2) != 0) {
                            physicalProps = PhysicalProps.copy$default(physicalProps, 0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, r.f32(), 63, null);
                        }
                    } else {
                        physicalProps = new PhysicalProps(iU8, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 126, null);
                    }
                    arrayList22.add(physicalProps);
                }
                return arrayList22;
            case 26:
                byte[] a5 = r.bytes(n);
                byte[] b5 = r.bytes(n);
                byte[] c4 = r.bytes(n);
                ArrayList arrayList23 = new ArrayList(n);
                for (int i32 = 0; i32 < n; i32++) {
                    int i33 = i32;
                    arrayList23.add(Color3.INSTANCE.fromRGB(a5[i33] & UByte.MAX_VALUE, b5[i33] & UByte.MAX_VALUE, c4[i33] & UByte.MAX_VALUE));
                }
                return arrayList23;
            case 27:
                return ArraysKt.toList(r.i64Array(n));
            case 28:
                int[] iArrU32Array3 = r.u32Array(n);
                Collection arrayList24 = new ArrayList(iArrU32Array3.length);
                int length = iArrU32Array3.length;
                int i34 = 0;
                while (i34 < length) {
                    int i35 = iArrU32Array3[i34];
                    ArrayList<byte[]> arrayList25 = this.sharedStrings;
                    arrayList24.add(new SharedStr(i35 >= 0 && i35 < arrayList25.size() ? arrayList25.get(i35) : new byte[0]));
                    i34++;
                    iArrU32Array3 = iArrU32Array3;
                }
                return (List) arrayList24;
            case 30:
                r.u8();
                List<CFrame> cFrames = readCFrames(r, n);
                r.u8();
                ArrayList arrayList26 = new ArrayList(n);
                for (int i36 = 0; i36 < n; i36++) {
                    arrayList26.add(Boolean.valueOf(r.u8() != 0));
                }
                ArrayList has = arrayList26;
                ArrayList arrayList27 = new ArrayList(n);
                for (int i37 = 0; i37 < n; i37++) {
                    int i38 = i37;
                    arrayList27.add(new OptionalCFrame(((Boolean) has.get(i38)).booleanValue() ? cFrames.get(i38) : null));
                }
                return arrayList27;
            case 31:
                byte[] d = r.interleaved(n, 16);
                ArrayList arrayList28 = new ArrayList(n);
                for (int i39 = 0; i39 < n; i39++) {
                    int i40 = i39;
                    arrayList28.add(new UniqueId(ArraysKt.copyOfRange(d, i40 * 16, (i40 * 16) + 16)));
                }
                return arrayList28;
            case 32:
                ArrayList arrayList29 = new ArrayList(n);
                for (int i41 = 0; i41 < n; i41++) {
                    arrayList29.add(new FontValue(r.string(), r.u16(), r.u8(), r.string()));
                }
                return arrayList29;
            case 33:
                int i42 = 8;
                byte[] d2 = r.interleaved(n, 8);
                ArrayList arrayList30 = new ArrayList(n);
                int i43 = 0;
                while (i43 < n) {
                    int i44 = i43;
                    long j = 0;
                    int i45 = 0;
                    while (i45 < i42) {
                        j = (j << i42) | (((long) d2[(i44 * 8) + i45]) & 255);
                        i45++;
                        d2 = d2;
                        i42 = 8;
                    }
                    arrayList30.add(new SecurityCaps(j));
                    i43++;
                    i42 = 8;
                }
                return arrayList30;
            case 34:
                int[] types = r.i32Array(n);
                int iI34 = r.i32();
                ArrayList arrayList31 = new ArrayList(iI34);
                for (int i46 = 0; i46 < iI34; i46++) {
                    arrayList31.add(r.string());
                }
                ArrayList uris = arrayList31;
                int objCount = r.i32();
                int[] objs = r.refArray(objCount);
                int ext = r.i32();
                if (ext != 0) {
                    r.refArray(ext);
                }
                int ui = 0;
                int oi2 = 0;
                ArrayList arrayList32 = new ArrayList(n);
                int i47 = 0;
                while (i47 < n) {
                    Object obj = "";
                    switch (types[i47]) {
                        case 1:
                            int ui2 = ui + 1;
                            if (ui >= 0 && ui < uris.size()) {
                                obj = uris.get(ui);
                            }
                            ui = ui2;
                            oi = oi2;
                            contentValue = new ContentValue(1, (String) obj, null, 4, null);
                            break;
                        case 2:
                            oi = oi2 + 1;
                            int i48 = oi2 >= 0 && oi2 < objs.length ? objs[oi2] : -1;
                            contentValue = new ContentValue(2, "", i48 < 0 ? null : this.instances.get(Integer.valueOf(i48)));
                            break;
                        default:
                            oi = oi2;
                            contentValue = new ContentValue(0, null, null, 6, null);
                            break;
                    }
                    arrayList32.add(contentValue);
                    i47++;
                    oi2 = oi;
                }
                return arrayList32;
        }
    }

    private static final int readValues$lambda$19$s16(ByteReader $r) throws RbxFormatException {
        int v = $r.u16();
        return v >= 32768 ? v - 65536 : v;
    }
}
