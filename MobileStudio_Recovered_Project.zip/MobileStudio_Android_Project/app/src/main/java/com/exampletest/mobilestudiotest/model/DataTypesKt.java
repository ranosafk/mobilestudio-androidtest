package com.exampletest.mobilestudiotest.model;

import kotlin.Metadata;
import org.luaj.vm2.LuaDouble;

/* JADX INFO: compiled from: DataTypes.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0006\n\u0002\u0010\u0007\n\u0000\u001a\u000e\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003\u001a\u000e\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0004¨\u0006\u0005"}, d2 = {"fmtNum", "", "f", "", "", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class DataTypesKt {
    public static final String fmtNum(double f) {
        if (Double.isNaN(f)) {
            return LuaDouble.JSTR_NAN;
        }
        if (Double.isInfinite(f)) {
            return f > 0.0d ? LuaDouble.JSTR_POSINF : LuaDouble.JSTR_NEGINF;
        }
        double r = Math.round(f * 1000.0d) / 1000.0d;
        return (!((r > Math.rint(r) ? 1 : (r == Math.rint(r) ? 0 : -1)) == 0) || Math.abs(r) >= 1.0E15d) ? String.valueOf(r) : String.valueOf((long) r);
    }

    public static final String fmtNum(float f) {
        return fmtNum(f);
    }
}
