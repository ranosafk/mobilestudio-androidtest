package com.exampletest.mobilestudiotest.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;

/* JADX INFO: compiled from: DataTypes.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\b\u001a\u00020\tH\u0016J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\u000b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0010"}, d2 = {"Lcom/exampletest/mobilestudiotest/model/Faces;", "", "mask", "", "<init>", "(I)V", "getMask", "()I", "toString", "", "component1", "copy", "equals", "", "other", "hashCode", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class Faces {
    private final int mask;

    public static /* synthetic */ Faces copy$default(Faces faces, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = faces.mask;
        }
        return faces.copy(i);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getMask() {
        return this.mask;
    }

    public final Faces copy(int mask) {
        return new Faces(mask);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        return (other instanceof Faces) && this.mask == ((Faces) other).mask;
    }

    public int hashCode() {
        return Integer.hashCode(this.mask);
    }

    public Faces(int mask) {
        this.mask = mask;
    }

    public final int getMask() {
        return this.mask;
    }

    public String toString() {
        int i = 1;
        Iterable n = CollectionsKt.listOf((Object[]) new String[]{"Right", "Top", "Back", "Left", "Bottom", "Front"});
        Collection arrayList = new ArrayList();
        int i2 = 0;
        for (Object obj : n) {
            int i3 = i2 + 1;
            if (i2 < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            int i4 = i;
            if (((this.mask & (i4 << i2)) != 0 ? i4 : 0) != 0) {
                arrayList.add(obj);
            }
            i2 = i3;
            i = i4;
        }
        return CollectionsKt.joinToString$default((List) arrayList, ", ", null, null, 0, null, null, 62, null);
    }
}
