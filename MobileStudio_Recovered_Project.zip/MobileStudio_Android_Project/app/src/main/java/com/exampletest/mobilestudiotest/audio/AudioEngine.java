package com.exampletest.mobilestudiotest.audio;

import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.HandlerThread;
import com.exampletest.mobilestudiotest.core.OutputLog;
import com.exampletest.mobilestudiotest.core.Settings;
import com.exampletest.mobilestudiotest.core.Studio;
import com.exampletest.mobilestudiotest.engine.PlaySession;
import com.exampletest.mobilestudiotest.model.CFrame;
import com.exampletest.mobilestudiotest.model.EnumValue;
import com.exampletest.mobilestudiotest.model.Instance;
import com.exampletest.mobilestudiotest.model.PartData;
import com.exampletest.mobilestudiotest.model.Vector3;
import com.exampletest.mobilestudiotest.net.AssetFetcher;
import com.exampletest.mobilestudiotest.render.FlyCamera;
import com.github.luben.zstd.BuildConfig;
import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: AudioEngine.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\u0082\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u000b\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\bÆ\u0002\u0018\u00002\u00020\u0001:\u0003LMNB\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u001c\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u001d\u001a\u00020\fH\u0002¢\u0006\u0002\u0010\u001eJ\"\u0010\u001f\u001a\u00020 2\b\u0010!\u001a\u0004\u0018\u00010\f2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020 H\u0002J\u000e\u0010%\u001a\u00020\u00142\u0006\u0010&\u001a\u00020'J\u0010\u0010(\u001a\u00020\u00142\u0006\u0010)\u001a\u00020\rH\u0002J\u0018\u0010*\u001a\u00020\u00142\u0006\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020 H\u0002J8\u0010.\u001a\u00020\u00142\u0006\u0010)\u001a\u00020\r2\u0006\u0010/\u001a\u00020 2\u0006\u00100\u001a\u00020 2\u0006\u0010-\u001a\u00020 2\u0006\u00101\u001a\u0002022\u0006\u00103\u001a\u000202H\u0002J\u0010\u00104\u001a\u00020\u00142\u0006\u0010)\u001a\u00020\rH\u0002J\u0010\u00105\u001a\u00020\u00142\u0006\u0010)\u001a\u00020\rH\u0002J\u0006\u00106\u001a\u00020\u0014J\b\u0010B\u001a\u00020\u0014H\u0002J\u0018\u0010C\u001a\u00020\u00142\u0006\u0010D\u001a\u00020\u00102\b\b\u0002\u0010E\u001a\u00020 J\u0018\u00104\u001a\u00020\u00142\u0006\u0010F\u001a\u0002082\u0006\u0010+\u001a\u00020,H\u0002J\u0006\u0010G\u001a\u00020\u0014J\u0006\u0010H\u001a\u00020\u0014J\u0016\u0010I\u001a\u00020\u00142\u0006\u0010D\u001a\u00020\u00102\u0006\u0010J\u001a\u00020 J\u0006\u0010K\u001a\u00020\u0014R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u000e\u001a\u0012\u0012\u0004\u0012\u00020\u00100\u000fj\b\u0012\u0004\u0012\u00020\u0010`\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R(\u0010\u0012\u001a\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R(\u0010\u0019\u001a\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0016\"\u0004\b\u001b\u0010\u0018R\"\u00109\u001a\u0004\u0018\u0001082\b\u00107\u001a\u0004\u0018\u000108@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b:\u0010;R\u0010\u0010<\u001a\u0004\u0018\u00010,X\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010=\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00140?0>¢\u0006\b\n\u0000\u001a\u0004\b@\u0010A¨\u0006O"}, d2 = {"Lcom/exampletest/mobilestudiotest/audio/AudioEngine;", "", "<init>", "()V", "thread", "Landroid/os/HandlerThread;", "h", "Landroid/os/Handler;", "MAX_VOICES", "", "voices", "Ljava/util/IdentityHashMap;", "Lcom/exampletest/mobilestudiotest/model/Instance;", "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;", "missing", "Ljava/util/HashSet;", "", "Lkotlin/collections/HashSet;", "onLoaded", "Lkotlin/Function1;", "", "getOnLoaded", "()Lkotlin/jvm/functions/Function1;", "setOnLoaded", "(Lkotlin/jvm/functions/Function1;)V", "onEnded", "getOnEnded", "setOnEnded", "soundId", "s", "(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/Long;", "num", "", "i", "k", "", "d", "update", "studio", "Lcom/exampletest/mobilestudiotest/core/Studio;", "create", "v", "setSpeed", "mp", "Landroid/media/MediaPlayer;", "speed", "apply", "l", "r", "loop", "", "restart", "tick", BuildConfig.BUILD_TYPE, "stopAll", "value", "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;", "preview", "getPreview", "()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;", "previewPlayer", "previewListeners", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lkotlin/Function0;", "getPreviewListeners", "()Ljava/util/concurrent/CopyOnWriteArrayList;", "notifyPreview", "togglePreview", "id", "volume", "p", "pausePreview", "resumePreview", "seekPreview", "seconds", "stopPreview", "Voice", "PreviewState", "Preview", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AudioEngine {
    public static final AudioEngine INSTANCE = new AudioEngine();
    private static final int MAX_VOICES = 28;
    private static final Handler h;
    private static final HashSet<Long> missing;
    private static Function1<? super Instance, Unit> onEnded;
    private static Function1<? super Instance, Unit> onLoaded;
    private static volatile Preview preview;
    private static final CopyOnWriteArrayList<Function0<Unit>> previewListeners;
    private static MediaPlayer previewPlayer;
    private static final HandlerThread thread;
    private static final IdentityHashMap<Instance, Voice> voices;

    /* JADX INFO: compiled from: AudioEngine.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\b\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\b¨\u0006\t"}, d2 = {"Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;", "", "<init>", "(Ljava/lang/String;I)V", "LOADING", "PLAYING", "PAUSED", "STOPPED", "ERROR", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public enum PreviewState {
        LOADING,
        PLAYING,
        PAUSED,
        STOPPED,
        ERROR;

        private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

        public static EnumEntries<PreviewState> getEntries() {
            return $ENTRIES;
        }
    }

    /* JADX INFO: compiled from: AudioEngine.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[PreviewState.values().length];
            try {
                iArr[PreviewState.PLAYING.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[PreviewState.PAUSED.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[PreviewState.STOPPED.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[PreviewState.LOADING.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[PreviewState.ERROR.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    private AudioEngine() {
    }

    static {
        HandlerThread handlerThread = new HandlerThread("audio");
        handlerThread.start();
        thread = handlerThread;
        h = new Handler(thread.getLooper());
        voices = new IdentityHashMap<>();
        missing = new HashSet<>();
        previewListeners = new CopyOnWriteArrayList<>();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: AudioEngine.kt */
    @Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\u0014\n\u0002\u0010\u0006\n\u0002\b\u0017\n\u0002\u0010\b\n\u0002\b\u0005\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u001c\u0010\f\u001a\u0004\u0018\u00010\rX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u001a\u0010\u0018\u001a\u00020\u0019X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u001b\"\u0004\b\u001c\u0010\u001dR\u001a\u0010\u001e\u001a\u00020\u0019X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u001b\"\u0004\b \u0010\u001dR\u001a\u0010!\u001a\u00020\u0019X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010\u001b\"\u0004\b#\u0010\u001dR\u001e\u0010$\u001a\u0004\u0018\u00010\u0013X\u0086\u000e¢\u0006\u0010\n\u0002\u0010)\u001a\u0004\b%\u0010&\"\u0004\b'\u0010(R\u001a\u0010*\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b+\u0010\u0015\"\u0004\b,\u0010\u0017R\u001a\u0010-\u001a\u00020.X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b/\u00100\"\u0004\b1\u00102R\u001a\u00103\u001a\u00020.X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b4\u00100\"\u0004\b5\u00102R\u001a\u00106\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b7\u0010\u0015\"\u0004\b8\u0010\u0017R\u001a\u00109\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b:\u0010\u0015\"\u0004\b;\u0010\u0017R\u001a\u0010<\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b=\u0010\u0015\"\u0004\b>\u0010\u0017R\u001a\u0010?\u001a\u00020.X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b@\u00100\"\u0004\bA\u00102R\u001a\u0010B\u001a\u00020.X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bC\u00100\"\u0004\bD\u00102R\u001a\u0010E\u001a\u00020FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bG\u0010H\"\u0004\bI\u0010J¨\u0006K"}, d2 = {"Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;", "", "sound", "Lcom/exampletest/mobilestudiotest/model/Instance;", "id", "", "<init>", "(Lcom/exampletest/mobilestudiotest/model/Instance;J)V", "getSound", "()Lcom/exampletest/mobilestudiotest/model/Instance;", "getId", "()J", "mp", "Landroid/media/MediaPlayer;", "getMp", "()Landroid/media/MediaPlayer;", "setMp", "(Landroid/media/MediaPlayer;)V", "prepared", "", "getPrepared", "()Z", "setPrepared", "(Z)V", "lastL", "", "getLastL", "()F", "setLastL", "(F)V", "lastR", "getLastR", "setLastR", "lastSpeed", "getLastSpeed", "setLastSpeed", "lastLoop", "getLastLoop", "()Ljava/lang/Boolean;", "setLastLoop", "(Ljava/lang/Boolean;)V", "Ljava/lang/Boolean;", "wantPlay", "getWantPlay", "setWantPlay", "position", "", "getPosition", "()D", "setPosition", "(D)V", "length", "getLength", "setLength", "ended", "getEnded", "setEnded", "loadedNotified", "getLoadedNotified", "setLoadedNotified", "failed", "getFailed", "setFailed", "lastPushedPos", "getLastPushedPos", "setLastPushedPos", "seek", "getSeek", "setSeek", "seq", "", "getSeq", "()I", "setSeq", "(I)V", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    static final class Voice {
        private volatile boolean ended;
        private volatile boolean failed;
        private final long id;
        private float lastL;
        private Boolean lastLoop;
        private double lastPushedPos;
        private float lastR;
        private float lastSpeed;
        private volatile double length;
        private volatile boolean loadedNotified;
        private MediaPlayer mp;
        private volatile double position;
        private boolean prepared;
        private double seek;
        private int seq;
        private final Instance sound;
        private boolean wantPlay;

        public Voice(Instance sound, long id) {
            Intrinsics.checkNotNullParameter(sound, "sound");
            this.sound = sound;
            this.id = id;
            this.lastL = -1.0f;
            this.lastR = -1.0f;
            this.lastSpeed = -1.0f;
            this.seek = -1.0d;
            Object obj = this.sound.getAttributes().get("__playSeq");
            Integer num = obj instanceof Integer ? (Integer) obj : null;
            this.seq = num != null ? num.intValue() : 0;
        }

        public final long getId() {
            return this.id;
        }

        public final Instance getSound() {
            return this.sound;
        }

        public final MediaPlayer getMp() {
            return this.mp;
        }

        public final void setMp(MediaPlayer mediaPlayer) {
            this.mp = mediaPlayer;
        }

        public final boolean getPrepared() {
            return this.prepared;
        }

        public final void setPrepared(boolean z) {
            this.prepared = z;
        }

        public final float getLastL() {
            return this.lastL;
        }

        public final Boolean getLastLoop() {
            return this.lastLoop;
        }

        public final float getLastR() {
            return this.lastR;
        }

        public final float getLastSpeed() {
            return this.lastSpeed;
        }

        public final boolean getWantPlay() {
            return this.wantPlay;
        }

        public final void setLastL(float f) {
            this.lastL = f;
        }

        public final void setLastLoop(Boolean bool) {
            this.lastLoop = bool;
        }

        public final void setLastR(float f) {
            this.lastR = f;
        }

        public final void setLastSpeed(float f) {
            this.lastSpeed = f;
        }

        public final void setWantPlay(boolean z) {
            this.wantPlay = z;
        }

        public final double getPosition() {
            return this.position;
        }

        public final void setPosition(double d) {
            this.position = d;
        }

        public final double getLength() {
            return this.length;
        }

        public final void setLength(double d) {
            this.length = d;
        }

        public final boolean getEnded() {
            return this.ended;
        }

        public final void setEnded(boolean z) {
            this.ended = z;
        }

        public final boolean getLoadedNotified() {
            return this.loadedNotified;
        }

        public final void setLoadedNotified(boolean z) {
            this.loadedNotified = z;
        }

        public final boolean getFailed() {
            return this.failed;
        }

        public final void setFailed(boolean z) {
            this.failed = z;
        }

        public final double getLastPushedPos() {
            return this.lastPushedPos;
        }

        public final void setLastPushedPos(double d) {
            this.lastPushedPos = d;
        }

        public final double getSeek() {
            return this.seek;
        }

        public final void setSeek(double d) {
            this.seek = d;
        }

        public final int getSeq() {
            return this.seq;
        }

        public final void setSeq(int i) {
            this.seq = i;
        }
    }

    public final Function1<Instance, Unit> getOnLoaded() {
        return onLoaded;
    }

    public final void setOnLoaded(Function1<? super Instance, Unit> function1) {
        onLoaded = function1;
    }

    public final Function1<Instance, Unit> getOnEnded() {
        return onEnded;
    }

    public final void setOnEnded(Function1<? super Instance, Unit> function1) {
        onEnded = function1;
    }

    private final Long soundId(Instance s) {
        return AssetFetcher.INSTANCE.idOf(s.get("SoundId"));
    }

    private final float num(Instance i, String k, float d) {
        Object obj = i != null ? i.get(k) : null;
        Number number = obj instanceof Number ? (Number) obj : null;
        return number != null ? number.floatValue() : d;
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0274  */
    /* JADX WARN: Code duplicated, block: B:103:0x02b4  */
    /* JADX WARN: Code duplicated, block: B:104:0x02b7  */
    /* JADX WARN: Code duplicated, block: B:106:0x02ba  */
    /* JADX WARN: Code duplicated, block: B:107:0x02bf  */
    /* JADX WARN: Code duplicated, block: B:110:0x02c5  */
    /* JADX WARN: Code duplicated, block: B:111:0x02c8  */
    /* JADX WARN: Code duplicated, block: B:113:0x02cc  */
    /* JADX WARN: Code duplicated, block: B:114:0x02ce  */
    /* JADX WARN: Code duplicated, block: B:119:0x02d7  */
    /* JADX WARN: Code duplicated, block: B:122:0x02f0  */
    /* JADX WARN: Code duplicated, block: B:123:0x031e  */
    /* JADX WARN: Code duplicated, block: B:124:0x0328  */
    /* JADX WARN: Code duplicated, block: B:127:0x0370  */
    /* JADX WARN: Code duplicated, block: B:128:0x0374  */
    /* JADX WARN: Code duplicated, block: B:130:0x0377  */
    /* JADX WARN: Code duplicated, block: B:131:0x037c  */
    /* JADX WARN: Code duplicated, block: B:134:0x0383  */
    /* JADX WARN: Code duplicated, block: B:136:0x038c  */
    /* JADX WARN: Code duplicated, block: B:137:0x0399  */
    /* JADX WARN: Code duplicated, block: B:138:0x039c  */
    /* JADX WARN: Code duplicated, block: B:153:0x03e6  */
    /* JADX WARN: Code duplicated, block: B:160:0x0445  */
    /* JADX WARN: Code duplicated, block: B:163:0x045f  */
    /* JADX WARN: Code duplicated, block: B:164:0x0473  */
    /* JADX WARN: Code duplicated, block: B:169:0x049a  */
    /* JADX WARN: Code duplicated, block: B:208:0x04a9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:209:0x047a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:72:0x01ef  */
    /* JADX WARN: Code duplicated, block: B:73:0x0206  */
    /* JADX WARN: Code duplicated, block: B:75:0x020c  */
    /* JADX WARN: Code duplicated, block: B:76:0x0211  */
    /* JADX WARN: Code duplicated, block: B:97:0x0266  */
    public final void update(Studio studio) {
        Voice v;
        float f;
        boolean z;
        Instance parent;
        String className;
        Vector3 emitter;
        Instance parent2;
        Instance parent3;
        Vector3 zero;
        float left;
        float left2;
        float mn;
        final float l;
        final float r;
        final float speed;
        final boolean loop;
        final Voice vv;
        Object obj;
        Integer num;
        int seq;
        Voice vv2;
        boolean z2;
        Function1<? super Instance, Unit> function1;
        Function1<? super Instance, Unit> function2;
        float d;
        float mn2;
        float mx;
        Object obj2;
        EnumValue enumValue;
        int mode;
        float gain;
        Vector3 dir;
        List<Instance> list;
        Intrinsics.checkNotNullParameter(studio, "studio");
        PlaySession play = studio.getPlay();
        if (play == null) {
            if (voices.isEmpty()) {
                return;
            }
            stopAll();
            return;
        }
        List<Instance> listAudibleSounds = studio.audibleSounds();
        Set alive = Collections.newSetFromMap(new IdentityHashMap());
        FlyCamera cam = studio.getCamera();
        float master = Settings.INSTANCE.getVolume() / 10.0f;
        for (Instance s : listAudibleSounds) {
            if (s.getParent() != null) {
                alive.add(s);
                boolean playing = Intrinsics.areEqual(s.get("Playing"), (Object) true) || Intrinsics.areEqual(s.get("IsPlaying"), (Object) true);
                Voice v2 = voices.get(s);
                Long id = soundId(s);
                if (v2 != null) {
                    long id2 = v2.getId();
                    if (id == null || id2 != id.longValue()) {
                        release(v2);
                        voices.remove(s);
                        v2 = null;
                    }
                }
                if (!playing) {
                    if (v2 != null && v2.getWantPlay()) {
                        v2.setWantPlay(false);
                        final boolean stopped = num(s, "TimePosition", 0.0f) == 0.0f;
                        final Voice vv3 = v2;
                        h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda4
                            @Override // java.lang.Runnable
                            public final void run() {
                                AudioEngine.update$lambda$2(vv3, stopped);
                            }
                        });
                    }
                } else if (id != null) {
                    if (v2 != null) {
                        v = v2;
                    } else if (voices.size() < 28) {
                        boolean bytes = AssetFetcher.INSTANCE.isCached(id.longValue());
                        if (!bytes) {
                            PlaySession play2 = play;
                            AssetFetcher.INSTANCE.request(id.longValue());
                            if (missing.contains(id)) {
                                list = listAudibleSounds;
                            } else {
                                list = listAudibleSounds;
                                if (AssetFetcher.INSTANCE.lastError(id.longValue()) != null) {
                                    missing.add(id);
                                    OutputLog.INSTANCE.warn("Couldn't load sound " + s.fullName() + " (rbxassetid://" + id + "): " + AssetFetcher.INSTANCE.lastError(id.longValue()));
                                }
                            }
                            listAudibleSounds = list;
                            play = play2;
                            cam = cam;
                            master = master;
                        } else {
                            Voice v3 = new Voice(s, id.longValue());
                            voices.put(s, v3);
                            double start = num(s, "TimePosition", 0.0f);
                            v3.setSeek(start);
                            create(v3);
                            v = v3;
                        }
                    }
                    if (v.getFailed()) {
                        listAudibleSounds = listAudibleSounds;
                        play = play;
                        cam = cam;
                        master = master;
                    } else {
                        float vol = RangesKt.coerceIn(num(s, "Volume", 0.5f), 0.0f, 10.0f);
                        Object obj3 = s.get("SoundGroup");
                        Instance instance = obj3 instanceof Instance ? (Instance) obj3 : null;
                        if (instance != null) {
                            vol *= RangesKt.coerceIn(INSTANCE.num(instance, "Volume", 1.0f), 0.0f, 10.0f);
                        }
                        float vol2 = vol * master;
                        float right = 1.0f;
                        Instance parent4 = s.getParent();
                        if (parent4 != null) {
                            f = 1.0f;
                            z = parent4.isA("BasePart");
                            if (z) {
                                PartData partData = PartData.INSTANCE;
                                Instance parent5 = s.getParent();
                                Intrinsics.checkNotNull(parent5);
                                emitter = partData.cframe(parent5).getPosition();
                            } else {
                                parent = s.getParent();
                                if (parent != null) {
                                    className = parent.getClassName();
                                } else {
                                    className = null;
                                }
                                if (Intrinsics.areEqual(className, "Attachment") || (parent2 = s.getParent()) == null || (parent3 = parent2.getParent()) == null) {
                                    emitter = null;
                                } else {
                                    if (!parent3.isA("BasePart")) {
                                        parent3 = null;
                                    }
                                    if (parent3 != null) {
                                        CFrame cframe = PartData.INSTANCE.cframe(parent3);
                                        Instance parent6 = s.getParent();
                                        Intrinsics.checkNotNull(parent6);
                                        Object obj4 = parent6.get("CFrame");
                                        CFrame cFrame = obj4 instanceof CFrame ? (CFrame) obj4 : null;
                                        if (cFrame == null || (zero = cFrame.getPosition()) == null) {
                                            zero = Vector3.INSTANCE.getZERO();
                                        }
                                        emitter = cframe.times(zero);
                                    } else {
                                        emitter = null;
                                    }
                                }
                            }
                            if (emitter != null) {
                                left = 1.0f;
                                left2 = f;
                                mn = 0.0f;
                            } else {
                                d = emitter.minus(cam.getPos()).getMagnitude();
                                mn2 = RangesKt.coerceAtLeast(num(s, "RollOffMinDistance", num(s, "xmlRead_MinDistance_3", 10.0f)), 0.1f);
                                mx = RangesKt.coerceAtLeast(num(s, "RollOffMaxDistance", num(s, "xmlRead_MaxDistance_3", 10000.0f)), mn2);
                                obj2 = s.get("RollOffMode");
                                if (obj2 instanceof EnumValue) {
                                    enumValue = (EnumValue) obj2;
                                } else {
                                    enumValue = null;
                                }
                                if (enumValue != null) {
                                    mode = enumValue.getValue();
                                } else {
                                    mode = 0;
                                }
                                if (d <= mn2) {
                                    gain = f;
                                } else if (d >= mx) {
                                    gain = 0.0f;
                                } else if (mode != 1 || mode == 3) {
                                    gain = f - ((d - mn2) / (mx - mn2));
                                } else {
                                    gain = mn2 / d;
                                }
                                vol2 *= gain;
                                dir = emitter.minus(cam.getPos());
                                if (d > 1056964608) {
                                    left = 1.0f;
                                    left2 = f;
                                    mn = 0.0f;
                                } else {
                                    left2 = f;
                                    float pan = RangesKt.coerceIn(dir.getUnit().dot(cam.getRight()), -1.0f, left2) * 0.7f;
                                    mn = 0.0f;
                                    float left3 = left2 - Math.max(0.0f, pan);
                                    right = Math.min(0.0f, pan) + left2;
                                    left = left3;
                                }
                            }
                            l = RangesKt.coerceIn(vol2 * left, mn, left2);
                            r = RangesKt.coerceIn(vol2 * right, mn, left2);
                            speed = RangesKt.coerceIn(num(s, "PlaybackSpeed", num(s, "Pitch", left2)), 0.05f, 8.0f);
                            loop = Intrinsics.areEqual(s.get("Looped"), (Object) true);
                            vv = v;
                            obj = s.getAttributes().get("__playSeq");
                            if (obj instanceof Integer) {
                                num = (Integer) obj;
                            } else {
                                num = null;
                            }
                            if (num != null) {
                                seq = num.intValue();
                            } else {
                                seq = 0;
                            }
                            if (seq != vv.getSeq()) {
                                vv.setSeq(seq);
                                if (vv.getWantPlay()) {
                                    h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda5
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            AudioEngine.update$lambda$6(vv);
                                        }
                                    });
                                }
                            }
                            if (vv.getWantPlay() || Math.abs(l - vv.getLastL()) > 0.01f || Math.abs(r - vv.getLastR()) > 0.01f) {
                                final boolean restart = !vv.getWantPlay();
                                vv.setWantPlay(true);
                                vv.setLastL(l);
                                vv.setLastR(r);
                                vv.setLastSpeed(speed);
                                vv.setLastLoop(Boolean.valueOf(loop));
                                Handler handler = h;
                                Runnable runnable = new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda6
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        AudioEngine.INSTANCE.apply(vv, l, r, speed, loop, restart);
                                    }
                                };
                                vv2 = vv;
                                handler.post(runnable);
                            } else if ((speed == vv.getLastSpeed()) && Intrinsics.areEqual(Boolean.valueOf(loop), vv.getLastLoop())) {
                                vv2 = vv;
                            } else {
                                final boolean restart2 = !vv.getWantPlay();
                                vv.setWantPlay(true);
                                vv.setLastL(l);
                                vv.setLastR(r);
                                vv.setLastSpeed(speed);
                                vv.setLastLoop(Boolean.valueOf(loop));
                                Handler handler2 = h;
                                Runnable runnable2 = new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda6
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        AudioEngine.INSTANCE.apply(vv, l, r, speed, loop, restart2);
                                    }
                                };
                                vv2 = vv;
                                handler2.post(runnable2);
                            }
                            if (vv2.getLength() > 0.0d && !vv2.getLoadedNotified()) {
                                vv2.setLoadedNotified(true);
                                s.set("TimeLength", Double.valueOf(vv2.getLength()), false);
                                s.set("IsLoaded", true, false);
                                function2 = onLoaded;
                                if (function2 != null) {
                                    function2.invoke(s);
                                }
                            }
                            if (Math.abs(vv2.getPosition() - vv2.getLastPushedPos()) > 0.2d) {
                                vv2.setLastPushedPos(vv2.getPosition());
                                z2 = false;
                                s.set("TimePosition", Double.valueOf(vv2.getPosition()), false);
                            } else {
                                z2 = false;
                            }
                            if (vv2.getEnded()) {
                                vv2.setEnded(z2);
                                vv2.setWantPlay(z2);
                                s.set("TimePosition", Double.valueOf(0.0d), z2);
                                Instance.set$default(s, "Playing", Boolean.valueOf(z2), false, 4, null);
                                function1 = onEnded;
                                if (function1 != null) {
                                    function1.invoke(s);
                                }
                                listAudibleSounds = listAudibleSounds;
                                play = play;
                                cam = cam;
                                master = master;
                            } else {
                                listAudibleSounds = listAudibleSounds;
                                play = play;
                                cam = cam;
                                master = master;
                            }
                        } else {
                            f = 1.0f;
                        }
                        if (z) {
                            PartData partData2 = PartData.INSTANCE;
                            Instance parent7 = s.getParent();
                            Intrinsics.checkNotNull(parent7);
                            emitter = partData2.cframe(parent7).getPosition();
                        } else {
                            parent = s.getParent();
                            if (parent != null) {
                                className = parent.getClassName();
                            } else {
                                className = null;
                            }
                            if (Intrinsics.areEqual(className, "Attachment")) {
                                emitter = null;
                            } else {
                                emitter = null;
                            }
                        }
                        if (emitter != null) {
                            left = 1.0f;
                            left2 = f;
                            mn = 0.0f;
                        } else {
                            d = emitter.minus(cam.getPos()).getMagnitude();
                            mn2 = RangesKt.coerceAtLeast(num(s, "RollOffMinDistance", num(s, "xmlRead_MinDistance_3", 10.0f)), 0.1f);
                            mx = RangesKt.coerceAtLeast(num(s, "RollOffMaxDistance", num(s, "xmlRead_MaxDistance_3", 10000.0f)), mn2);
                            obj2 = s.get("RollOffMode");
                            if (obj2 instanceof EnumValue) {
                                enumValue = (EnumValue) obj2;
                            } else {
                                enumValue = null;
                            }
                            if (enumValue != null) {
                                mode = enumValue.getValue();
                            } else {
                                mode = 0;
                            }
                            if (d <= mn2) {
                                gain = f;
                            } else if (d >= mx) {
                                gain = 0.0f;
                            } else if (mode != 1) {
                                gain = f - ((d - mn2) / (mx - mn2));
                            } else {
                                gain = f - ((d - mn2) / (mx - mn2));
                            }
                            vol2 *= gain;
                            dir = emitter.minus(cam.getPos());
                            if (d > 1056964608) {
                                left = 1.0f;
                                left2 = f;
                                mn = 0.0f;
                            } else {
                                left2 = f;
                                float pan2 = RangesKt.coerceIn(dir.getUnit().dot(cam.getRight()), -1.0f, left2) * 0.7f;
                                mn = 0.0f;
                                float left4 = left2 - Math.max(0.0f, pan2);
                                right = Math.min(0.0f, pan2) + left2;
                                left = left4;
                            }
                        }
                        l = RangesKt.coerceIn(vol2 * left, mn, left2);
                        r = RangesKt.coerceIn(vol2 * right, mn, left2);
                        speed = RangesKt.coerceIn(num(s, "PlaybackSpeed", num(s, "Pitch", left2)), 0.05f, 8.0f);
                        loop = Intrinsics.areEqual(s.get("Looped"), (Object) true);
                        vv = v;
                        obj = s.getAttributes().get("__playSeq");
                        if (obj instanceof Integer) {
                            num = (Integer) obj;
                        } else {
                            num = null;
                        }
                        if (num != null) {
                            seq = num.intValue();
                        } else {
                            seq = 0;
                        }
                        if (seq != vv.getSeq()) {
                            vv.setSeq(seq);
                            if (vv.getWantPlay()) {
                                h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda5
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        AudioEngine.update$lambda$6(vv);
                                    }
                                });
                            }
                        }
                        if (vv.getWantPlay()) {
                            final boolean restart3 = !vv.getWantPlay();
                            vv.setWantPlay(true);
                            vv.setLastL(l);
                            vv.setLastR(r);
                            vv.setLastSpeed(speed);
                            vv.setLastLoop(Boolean.valueOf(loop));
                            Handler handler3 = h;
                            Runnable runnable3 = new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda6
                                @Override // java.lang.Runnable
                                public final void run() {
                                    AudioEngine.INSTANCE.apply(vv, l, r, speed, loop, restart3);
                                }
                            };
                            vv2 = vv;
                            handler3.post(runnable3);
                        } else {
                            final boolean restart4 = !vv.getWantPlay();
                            vv.setWantPlay(true);
                            vv.setLastL(l);
                            vv.setLastR(r);
                            vv.setLastSpeed(speed);
                            vv.setLastLoop(Boolean.valueOf(loop));
                            Handler handler4 = h;
                            Runnable runnable4 = new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda6
                                @Override // java.lang.Runnable
                                public final void run() {
                                    AudioEngine.INSTANCE.apply(vv, l, r, speed, loop, restart4);
                                }
                            };
                            vv2 = vv;
                            handler4.post(runnable4);
                        }
                        if (vv2.getLength() > 0.0d) {
                            vv2.setLoadedNotified(true);
                            s.set("TimeLength", Double.valueOf(vv2.getLength()), false);
                            s.set("IsLoaded", true, false);
                            function2 = onLoaded;
                            if (function2 != null) {
                                function2.invoke(s);
                            }
                        }
                        if (Math.abs(vv2.getPosition() - vv2.getLastPushedPos()) > 0.2d) {
                            vv2.setLastPushedPos(vv2.getPosition());
                            z2 = false;
                            s.set("TimePosition", Double.valueOf(vv2.getPosition()), false);
                        } else {
                            z2 = false;
                        }
                        if (vv2.getEnded()) {
                            vv2.setEnded(z2);
                            vv2.setWantPlay(z2);
                            s.set("TimePosition", Double.valueOf(0.0d), z2);
                            Instance.set$default(s, "Playing", Boolean.valueOf(z2), false, 4, null);
                            function1 = onEnded;
                            if (function1 != null) {
                                function1.invoke(s);
                            }
                            listAudibleSounds = listAudibleSounds;
                            play = play;
                            cam = cam;
                            master = master;
                        } else {
                            listAudibleSounds = listAudibleSounds;
                            play = play;
                            cam = cam;
                            master = master;
                        }
                    }
                }
            }
        }
        boolean z3 = false;
        if (voices.size() <= alive.size()) {
            Iterable iterableKeySet = voices.keySet();
            Intrinsics.checkNotNullExpressionValue(iterableKeySet, "<get-keys>(...)");
            Iterable iterable = iterableKeySet;
            if (!(iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
                Iterator it = iterable.iterator();
                while (it.hasNext()) {
                    if (!alive.contains((Instance) it.next())) {
                        z3 = true;
                        break;
                    }
                }
            }
            if (!z3) {
                return;
            }
        }
        Iterator<Map.Entry<Instance, Voice>> it2 = voices.entrySet().iterator();
        while (it2.hasNext()) {
            Map.Entry<Instance, Voice> next = it2.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            Map.Entry<Instance, Voice> entry = next;
            if (!alive.contains(entry.getKey())) {
                Voice value = entry.getValue();
                Intrinsics.checkNotNullExpressionValue(value, "<get-value>(...)");
                release(value);
                it2.remove();
            }
        }
    }

    static final void update$lambda$2(Voice $vv, boolean $stopped) {
        try {
            MediaPlayer mp = $vv.getMp();
            if (mp != null) {
                if (mp.isPlaying()) {
                    mp.pause();
                }
                if ($stopped && $vv.getPrepared()) {
                    mp.seekTo(0);
                }
            }
        } catch (Exception e) {
        }
    }

    static final void update$lambda$6(Voice $vv) {
        MediaPlayer mp;
        try {
            if (!$vv.getPrepared() || (mp = $vv.getMp()) == null) {
                return;
            }
            mp.seekTo(0);
        } catch (Exception e) {
        }
    }

    private final void create(final Voice v) {
        h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                AudioEngine.create$lambda$12(v);
            }
        });
    }

    static final void create$lambda$12(final Voice $v) {
        try {
            String strCacheFile = AssetFetcher.INSTANCE.cacheFile($v.getId());
            if (strCacheFile == null) {
                return;
            }
            File f = new File(strCacheFile);
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(4).build());
            mp.setDataSource(f.getPath());
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda13
                @Override // android.media.MediaPlayer.OnPreparedListener
                public final void onPrepared(MediaPlayer mediaPlayer) {
                    AudioEngine.create$lambda$12$lambda$9($v, mediaPlayer);
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda14
                @Override // android.media.MediaPlayer.OnCompletionListener
                public final void onCompletion(MediaPlayer mediaPlayer) {
                    AudioEngine.create$lambda$12$lambda$10($v, mediaPlayer);
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda15
                @Override // android.media.MediaPlayer.OnErrorListener
                public final boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                    return AudioEngine.create$lambda$12$lambda$11($v, mediaPlayer, i, i2);
                }
            });
            $v.setMp(mp);
            mp.prepareAsync();
        } catch (Exception e) {
            $v.setFailed(true);
            OutputLog.INSTANCE.warn("Sound rbxassetid://" + $v.getId() + ": " + e.getMessage());
        }
    }

    static final void create$lambda$12$lambda$9(Voice $v, MediaPlayer it) {
        $v.setPrepared(true);
        $v.setLength(((double) it.getDuration()) / 1000.0d);
        if ($v.getSeek() > 0.0d) {
            try {
                it.seekTo((int) ($v.getSeek() * 1000.0d));
            } catch (Exception e) {
            }
        }
        if ($v.getWantPlay()) {
            it.setVolume(RangesKt.coerceAtLeast($v.getLastL(), 0.0f), RangesKt.coerceAtLeast($v.getLastR(), 0.0f));
            it.setLooping(Intrinsics.areEqual((Object) $v.getLastLoop(), (Object) true));
            AudioEngine audioEngine = INSTANCE;
            Intrinsics.checkNotNull(it);
            audioEngine.setSpeed(it, $v.getLastSpeed());
            it.start();
        }
        INSTANCE.tick($v);
    }

    static final void create$lambda$12$lambda$10(Voice $v, MediaPlayer it) {
        if (it.isLooping()) {
            return;
        }
        $v.setEnded(true);
        $v.setPosition(0.0d);
    }

    static final boolean create$lambda$12$lambda$11(Voice $v, MediaPlayer mediaPlayer, int what, int extra) {
        $v.setFailed(true);
        OutputLog.INSTANCE.warn("Sound rbxassetid://" + $v.getId() + " can't be played on this device (" + what + "/" + extra + ")");
        return true;
    }

    private final void setSpeed(MediaPlayer mp, float speed) {
        if (speed <= 0.0f || Math.abs(speed - 1.0f) < 0.001f) {
            return;
        }
        try {
            mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(speed).setPitch(speed));
        } catch (Exception e) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void apply(Voice v, float l, float r, float speed, boolean loop, boolean restart) {
        MediaPlayer mp = v.getMp();
        if (mp != null && v.getPrepared()) {
            try {
                mp.setVolume(l, r);
                mp.setLooping(loop);
                setSpeed(mp, speed);
                if (restart || !mp.isPlaying()) {
                    mp.start();
                    tick(v);
                }
            } catch (Exception e) {
            }
        }
    }

    private final void tick(final Voice v) {
        h.postDelayed(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine.tick.1
            @Override // java.lang.Runnable
            public void run() {
                MediaPlayer mp = v.getMp();
                if (mp == null) {
                    return;
                }
                try {
                    if (v.getPrepared()) {
                        v.setPosition(((double) mp.getCurrentPosition()) / 1000.0d);
                    }
                    if (v.getWantPlay()) {
                        AudioEngine.h.postDelayed(this, 200L);
                    }
                } catch (Exception e) {
                }
            }
        }, 200L);
    }

    private final void release(final Voice v) {
        v.setWantPlay(false);
        h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                AudioEngine.release$lambda$13(v);
            }
        });
    }

    static final void release$lambda$13(Voice $v) {
        try {
            MediaPlayer mp = $v.getMp();
            if (mp != null) {
                mp.release();
            }
        } catch (Exception e) {
        }
        $v.setMp(null);
    }

    public final void stopAll() {
        for (Voice v : voices.values()) {
            Intrinsics.checkNotNull(v);
            release(v);
        }
        voices.clear();
        missing.clear();
    }

    /* JADX INFO: compiled from: AudioEngine.kt */
    @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0010\u000e\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001a\u0010\b\u001a\u00020\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0011\"\u0004\b\u0016\u0010\u0013R\u001c\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001c¨\u0006\u001d"}, d2 = {"Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;", "", "id", "", "<init>", "(J)V", "getId", "()J", "state", "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;", "getState", "()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;", "setState", "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V", "position", "", "getPosition", "()F", "setPosition", "(F)V", "length", "getLength", "setLength", "error", "", "getError", "()Ljava/lang/String;", "setError", "(Ljava/lang/String;)V", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Preview {
        private volatile String error;
        private final long id;
        private volatile float length;
        private volatile float position;
        private volatile PreviewState state = PreviewState.LOADING;

        public Preview(long id) {
            this.id = id;
        }

        public final long getId() {
            return this.id;
        }

        public final PreviewState getState() {
            return this.state;
        }

        public final void setState(PreviewState previewState) {
            Intrinsics.checkNotNullParameter(previewState, "<set-?>");
            this.state = previewState;
        }

        public final float getPosition() {
            return this.position;
        }

        public final void setPosition(float f) {
            this.position = f;
        }

        public final float getLength() {
            return this.length;
        }

        public final void setLength(float f) {
            this.length = f;
        }

        public final String getError() {
            return this.error;
        }

        public final void setError(String str) {
            this.error = str;
        }
    }

    public final Preview getPreview() {
        return preview;
    }

    public final CopyOnWriteArrayList<Function0<Unit>> getPreviewListeners() {
        return previewListeners;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void notifyPreview() {
        Iterator it = previewListeners.iterator();
        while (it.hasNext()) {
            ((Function0) it.next()).invoke();
        }
    }

    public static /* synthetic */ void togglePreview$default(AudioEngine audioEngine, long j, float f, int i, Object obj) {
        if ((i & 2) != 0) {
            f = 0.5f;
        }
        audioEngine.togglePreview(j, f);
    }

    public final void togglePreview(final long id, final float volume) {
        Preview cur = preview;
        if (cur != null && cur.getId() == id) {
            switch (WhenMappings.$EnumSwitchMapping$0[cur.getState().ordinal()]) {
                case 1:
                    pausePreview();
                    return;
                case 2:
                    resumePreview();
                    return;
                case 3:
                    if (cur.getLength() > 0.0f) {
                        resumePreview();
                        return;
                    }
                    break;
                case 4:
                    stopPreview();
                    return;
                case 5:
                    break;
                default:
                    throw new NoWhenBranchMatchedException();
            }
        }
        stopPreview();
        final Preview p = new Preview(id);
        preview = p;
        notifyPreview();
        new Thread(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                AudioEngine.togglePreview$lambda$19(id, p, volume);
            }
        }).start();
    }

    static final void togglePreview$lambda$19(final long $id, final Preview $p, final float $volume) {
        try {
            AssetFetcher.INSTANCE.load($id);
            h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    AudioEngine.togglePreview$lambda$19$lambda$18($p, $id, $volume);
                }
            });
        } catch (Exception e) {
            $p.setState(PreviewState.ERROR);
            String message = e.getMessage();
            if (message == null) {
                message = "Couldn't download the audio";
            }
            $p.setError(message);
            INSTANCE.notifyPreview();
        }
    }

    static final void togglePreview$lambda$19$lambda$18(final Preview $p, long $id, final float $volume) {
        AudioEngine audioEngine = INSTANCE;
        if (preview != $p) {
            return;
        }
        try {
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(1).setContentType(2).build());
            String strCacheFile = AssetFetcher.INSTANCE.cacheFile($id);
            Intrinsics.checkNotNull(strCacheFile);
            mp.setDataSource(strCacheFile);
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda1
                @Override // android.media.MediaPlayer.OnPreparedListener
                public final void onPrepared(MediaPlayer mediaPlayer) {
                    AudioEngine.togglePreview$lambda$19$lambda$18$lambda$15($p, $volume, mediaPlayer);
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda2
                @Override // android.media.MediaPlayer.OnCompletionListener
                public final void onCompletion(MediaPlayer mediaPlayer) {
                    AudioEngine.togglePreview$lambda$19$lambda$18$lambda$16($p, mediaPlayer);
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda3
                @Override // android.media.MediaPlayer.OnErrorListener
                public final boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                    return AudioEngine.togglePreview$lambda$19$lambda$18$lambda$17($p, mediaPlayer, i, i2);
                }
            });
            AudioEngine audioEngine2 = INSTANCE;
            previewPlayer = mp;
            mp.prepareAsync();
        } catch (Exception e) {
            $p.setState(PreviewState.ERROR);
            $p.setError(e.getMessage());
            INSTANCE.notifyPreview();
        }
    }

    static final void togglePreview$lambda$19$lambda$18$lambda$15(Preview $p, float $volume, MediaPlayer it) {
        AudioEngine audioEngine = INSTANCE;
        if (preview != $p) {
            it.release();
            return;
        }
        $p.setLength(it.getDuration() / 1000.0f);
        float vol = RangesKt.coerceIn(2.0f * $volume, 0.05f, 1.0f);
        it.setVolume(vol, vol);
        it.start();
        $p.setState(PreviewState.PLAYING);
        INSTANCE.notifyPreview();
        AudioEngine audioEngine2 = INSTANCE;
        Intrinsics.checkNotNull(it);
        audioEngine2.tick($p, it);
    }

    static final void togglePreview$lambda$19$lambda$18$lambda$16(Preview $p, MediaPlayer it) {
        $p.setState(PreviewState.STOPPED);
        $p.setPosition(0.0f);
        INSTANCE.notifyPreview();
    }

    static final boolean togglePreview$lambda$19$lambda$18$lambda$17(Preview $p, MediaPlayer mediaPlayer, int i, int i2) {
        $p.setState(PreviewState.ERROR);
        $p.setError("This audio can't be played on this device");
        INSTANCE.notifyPreview();
        return true;
    }

    private final void tick(final Preview p, final MediaPlayer mp) {
        h.postDelayed(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine.tick.2
            @Override // java.lang.Runnable
            public void run() {
                if (AudioEngine.INSTANCE.getPreview() != p || AudioEngine.previewPlayer != mp || p.getState() != PreviewState.PLAYING) {
                    return;
                }
                try {
                    p.setPosition(mp.getCurrentPosition() / 1000.0f);
                    AudioEngine.INSTANCE.notifyPreview();
                    AudioEngine.h.postDelayed(this, 150L);
                } catch (Exception e) {
                }
            }
        }, 150L);
    }

    public final void pausePreview() {
        final Preview p = preview;
        if (p == null) {
            return;
        }
        h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda16
            @Override // java.lang.Runnable
            public final void run() {
                AudioEngine.pausePreview$lambda$20(p);
            }
        });
    }

    static final void pausePreview$lambda$20(Preview $p) {
        MediaPlayer mp = previewPlayer;
        if (mp == null) {
            return;
        }
        AudioEngine audioEngine = INSTANCE;
        if (preview != $p || $p.getState() != PreviewState.PLAYING) {
            return;
        }
        try {
            mp.pause();
            $p.setPosition(mp.getCurrentPosition() / 1000.0f);
        } catch (Exception e) {
        }
        $p.setState(PreviewState.PAUSED);
        INSTANCE.notifyPreview();
    }

    public final void resumePreview() {
        final Preview p = preview;
        if (p == null) {
            return;
        }
        h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                AudioEngine.resumePreview$lambda$21(p);
            }
        });
    }

    static final void resumePreview$lambda$21(Preview $p) {
        MediaPlayer mp = previewPlayer;
        if (mp == null) {
            return;
        }
        AudioEngine audioEngine = INSTANCE;
        if (preview != $p) {
            return;
        }
        try {
            if ($p.getState() == PreviewState.STOPPED) {
                mp.seekTo(0);
                $p.setPosition(0.0f);
            }
            mp.start();
            $p.setState(PreviewState.PLAYING);
            INSTANCE.notifyPreview();
            INSTANCE.tick($p, mp);
        } catch (Exception e) {
        }
    }

    public final void seekPreview(long id, final float seconds) {
        final Preview p = preview;
        if (p != null) {
            if (!(p.getId() == id)) {
                p = null;
            }
            if (p == null) {
                return;
            }
            h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    AudioEngine.seekPreview$lambda$23(p, seconds);
                }
            });
        }
    }

    static final void seekPreview$lambda$23(Preview $p, float $seconds) {
        MediaPlayer mp = previewPlayer;
        if (mp == null) {
            return;
        }
        AudioEngine audioEngine = INSTANCE;
        if (preview != $p || $p.getLength() <= 0.0f) {
            return;
        }
        float t = RangesKt.coerceIn($seconds, 0.0f, $p.getLength());
        try {
            mp.seekTo((int) (1000.0f * t));
            $p.setPosition(t);
            if ($p.getState() == PreviewState.STOPPED) {
                $p.setState(PreviewState.PAUSED);
            }
            INSTANCE.notifyPreview();
        } catch (Exception e) {
        }
    }

    public final void stopPreview() {
        Preview p = preview;
        preview = null;
        if (p != null) {
            p.setState(PreviewState.STOPPED);
        }
        h.post(new Runnable() { // from class: com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                AudioEngine.stopPreview$lambda$24();
            }
        });
        notifyPreview();
    }

    static final void stopPreview$lambda$24() {
        try {
            MediaPlayer mediaPlayer = previewPlayer;
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }
        } catch (Exception e) {
        }
        AudioEngine audioEngine = INSTANCE;
        previewPlayer = null;
    }
}
