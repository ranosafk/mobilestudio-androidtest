.method static final _init_$lambda$5(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 7
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "self"    # Lorg/luaj/vm2/LuaValue;
    .param p2, "key"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "self"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.lua.SignalRef"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    .line 143
    .local v0, "s":Lcom/exampletest/mobilestudiotest/lua/SignalRef;
    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_7a

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    sparse-switch v2, :sswitch_data_98

    goto :goto_7a

    :sswitch_23
    const-string v2, "connect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    goto :goto_6e

    :sswitch_2c
    const-string v2, "wait"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    goto :goto_3d

    :sswitch_35
    const-string v2, "Wait"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    .line 146
    :goto_3d
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_79

    .line 143
    :sswitch_49
    const-string v2, "Once"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    .line 145
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_79

    .line 143
    :sswitch_5d
    const-string v2, "ConnectParallel"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    goto :goto_6e

    :sswitch_66
    const-string v2, "Connect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    .line 144
    :goto_6e
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    .line 148
    :goto_79
    return-object v1

    .line 147
    :cond_7a
    :goto_7a
    new-instance v1, Lorg/luaj/vm2/LuaError;

    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " is not a valid member of RBXScriptSignal"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    nop

    :sswitch_data_98
    .sparse-switch
        -0x6412ef36 -> :sswitch_66
        -0x1276c70f -> :sswitch_5d
        0x2592a1 -> :sswitch_49
        0x290595 -> :sswitch_35
        0x379175 -> :sswitch_2c
        0x38b478ea -> :sswitch_23
    .end sparse-switch
.end method
