.method public final modelCall(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 16
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "a"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 889
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const-string v1, " expected, got "

    const-string v2, "__scale"

    const-string v3, "arg(...)"

    const/4 v4, 0x2

    const/4 v5, 0x0

    sparse-switch v0, :sswitch_data_2ea

    goto/16 :goto_2c3

    :sswitch_20
    const-string v0, "GetScale"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 915
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_37

    move-object v5, v0

    check-cast v5, Ljava/lang/Number;

    :cond_37
    if-eqz v5, :cond_3e

    invoke-virtual {v5}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    goto :goto_40

    :cond_3e
    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    :goto_40
    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 889
    :sswitch_4d
    const-string v0, "GetPivot"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2c4

    goto/16 :goto_2c3

    :sswitch_57
    const-string v0, "SetPrimaryPartCFrame"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_d0

    goto/16 :goto_2c3

    :sswitch_61
    const-string v0, "GetBoundingBox"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 900
    sget-object v0, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->boundsOf(Ljava/util/List;)Lkotlin/Pair;

    move-result-object v0

    if-nez v0, :cond_85

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    .line 901
    .local v0, "b":Lkotlin/Pair;
    :cond_85
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/high16 v4, 0x40000000    # 2.0f

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->at(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    invoke-static {v1, v2}, Lorg/luaj/vm2/LuaValue;->varargsOf(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    .line 899
    .end local v0    # "b":Lkotlin/Pair;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    goto/16 :goto_2e9

    .line 889
    :sswitch_c8
    const-string v0, "PivotTo"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 891
    :cond_d0
    invoke-virtual {p3, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 1087
    .local v3, "$i$f$ud\\1\\891":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_e5

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_e6

    :cond_e5
    move-object v4, v5

    :goto_e6
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_eb

    move-object v5, v4

    :cond_eb
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_fb

    .line 891
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\891":I
    invoke-virtual {p0, p1, v5}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 1087
    .restart local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\1":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\1\\891":I
    :cond_fb
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 889
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\891":I
    :sswitch_11c
    const-string v0, "TranslateBy"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 898
    invoke-virtual {p3, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\3":Ljava/lang/String;
    const/4 v3, 0x0

    .line 1089
    .local v3, "$i$f$ud\\3\\898":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_139

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_13a

    :cond_139
    move-object v4, v5

    :goto_13a
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_13f

    move-object v5, v4

    :cond_13f
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_158

    .line 898
    .end local v0    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\3":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\3\\898":I
    nop

    .local v5, "d":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {v0, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .end local v5    # "d":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 1089
    .restart local v0    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\3":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\3\\898":I
    :cond_158
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 889
    .end local v0    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\3":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\3\\898":I
    :sswitch_179
    const-string v0, "ScaleTo"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 905
    invoke-virtual {p3, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v0

    .local v0, "s":F
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    instance-of v3, v1, Ljava/lang/Number;

    if-eqz v3, :cond_19b

    move-object v5, v1

    check-cast v5, Ljava/lang/Number;

    :cond_19b
    if-eqz v5, :cond_1a2

    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    move-result v1

    goto :goto_1a4

    :cond_1a2
    const/high16 v1, 0x3f800000    # 1.0f

    .line 906
    .local v1, "old":F
    :goto_1a4
    div-float v3, v0, v1

    .local v3, "f":F
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    .line 907
    .local v4, "piv":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1b2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1f5

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 908
    .local v6, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v7, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v7, v6}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    .line 909
    .local v7, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    sget-object v8, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v9, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v9, v6}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v9, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v8, v6, v9}, Lcom/exampletest/mobilestudiotest/model/PartData;->setSize(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    .line 910
    sget-object v8, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-virtual {v10, v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v10, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v7, v9}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v9

    invoke-virtual {v8, v6, v9}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    .end local v6    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    goto :goto_1b2

    .line 912
    :cond_1f5
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v5

    check-cast v5, Ljava/util/Map;

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v6

    invoke-interface {v5, v2, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 913
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 904
    .end local v0    # "s":F
    .end local v1    # "old":F
    .end local v3    # "f":F
    .end local v4    # "piv":Lcom/exampletest/mobilestudiotest/model/CFrame;
    nop

    .line 905
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 889
    :sswitch_20c
    const-string v0, "GetModelCFrame"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2c4

    goto/16 :goto_2c3

    :sswitch_216
    const-string v0, "GetModelSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_228

    goto/16 :goto_2c3

    :sswitch_220
    const-string v0, "GetExtentsSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 903
    :cond_228
    sget-object v0, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->boundsOf(Ljava/util/List;)Lkotlin/Pair;

    move-result-object v0

    if-nez v0, :cond_244

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    .local v0, "b":Lkotlin/Pair;
    :cond_244
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "b":Lkotlin/Pair;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 889
    :sswitch_25e
    const-string v0, "MoveTo"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 893
    invoke-virtual {p3, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 1088
    .local v3, "$i$f$ud\\2\\893":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_27b

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_27c

    :cond_27b
    move-object v4, v5

    :goto_27c
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_281

    move-object v5, v4

    :cond_281
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_29a

    .line 893
    .end local v0    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\893":I
    nop

    .line 894
    .local v5, "target":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    .line 895
    .local v0, "piv":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {v0, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {p0, p1, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    .line 896
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 892
    .end local v0    # "piv":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v5    # "target":Lcom/exampletest/mobilestudiotest/model/Vector3;
    nop

    .line 893
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_2e9

    .line 1088
    .local v0, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\2\\893":I
    :cond_29a
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 889
    .end local v0    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\893":I
    :sswitch_2bb
    const-string v0, "GetPrimaryPartCFrame"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2c4

    :cond_2c3
    :goto_2c3
    goto :goto_2e0

    .line 890
    :cond_2c4
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "BasePart"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2d5

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    goto :goto_2d9

    :cond_2d5
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    :goto_2d9
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_2e9

    .line 916
    :goto_2e0
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NONE"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    .line 889
    :goto_2e9
    return-object v0

    :sswitch_data_2ea
    .sparse-switch
        -0x7a9aa857 -> :sswitch_2bb
        -0x76477db4 -> :sswitch_25e
        -0x6f06deec -> :sswitch_220
        -0x6e9fa7cc -> :sswitch_216
        -0x629349c3 -> :sswitch_20c
        -0x2ae17ebb -> :sswitch_179
        -0xa4c79db -> :sswitch_11c
        0x41d2663d -> :sswitch_c8
        0x52e38071 -> :sswitch_61
        0x60fb641d -> :sswitch_57
        0x78d3d6ac -> :sswitch_4d
        0x78fb13b4 -> :sswitch_20
    .end sparse-switch
.end method
