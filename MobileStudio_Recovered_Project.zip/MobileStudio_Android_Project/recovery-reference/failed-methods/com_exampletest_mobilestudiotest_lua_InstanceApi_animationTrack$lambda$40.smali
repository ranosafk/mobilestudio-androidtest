.method static final animationTrack$lambda$40(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/model/Instance;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 14
    .param p0, "$st"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .param p1, "$playing"    # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p2, "$speed"    # Lkotlin/jvm/internal/Ref$FloatRef;
    .param p3, "$looped"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p4, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p5, "$priority"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p6, "$anim"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p7, "$t"    # Lorg/luaj/vm2/LuaTable;
    .param p9, "k"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "<unused var>"

    invoke-static {p8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p8, "k"

    invoke-static {p9, p8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 683
    invoke-virtual {p9}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object p8

    .local p8, "ks":Ljava/lang/String;
    if-eqz p8, :cond_164

    invoke-virtual {p8}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v2, 0x0

    const-string v3, "valueOf(...)"

    sparse-switch v0, :sswitch_data_16c

    goto/16 :goto_164

    :sswitch_1e
    const-string v0, "WeightCurrent"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 690
    if-eqz p0, :cond_2d

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getWeightNow()F

    move-result v1

    goto :goto_32

    :cond_2d
    iget-boolean v0, p1, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-nez v0, :cond_32

    move v1, v2

    :cond_32
    :goto_32
    float-to-double v0, v1

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_3e
    const-string v0, "TimePosition"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 686
    if-eqz p0, :cond_4c

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getTime()F

    move-result v2

    :cond_4c
    float-to-double v0, v2

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_58
    const-string v0, "IsPlaying"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 684
    if-eqz p0, :cond_67

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->isPlaying()Z

    move-result v0

    goto :goto_69

    :cond_67
    iget-boolean v0, p1, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    :goto_69
    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_74
    const-string v0, "Speed"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 687
    iget v0, p2, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    float-to-double v0, v0

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_8a
    const-string v0, "Ended"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_120

    goto/16 :goto_164

    :sswitch_94
    const-string v0, "Name"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 692
    if-eqz p6, :cond_a5

    invoke-virtual {p6}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_a5

    goto :goto_a7

    :cond_a5
    const-string v0, "Animation"

    :goto_a7
    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_b2
    const-string v0, "WeightTarget"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 691
    if-eqz p0, :cond_c1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getWeightTarget()F

    move-result v1

    goto :goto_c6

    :cond_c1
    iget-boolean v0, p1, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-nez v0, :cond_c6

    move v1, v2

    :cond_c6
    :goto_c6
    float-to-double v0, v1

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_d2
    const-string v0, "Stopped"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_120

    goto/16 :goto_164

    :sswitch_dc
    const-string v0, "KeyframeReached"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_120

    goto/16 :goto_164

    :sswitch_e6
    const-string v0, "DidLoop"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_120

    goto/16 :goto_164

    :sswitch_f0
    const-string v0, "Priority"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 689
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    if-eqz p0, :cond_102

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getPriority()Ljava/lang/Integer;

    move-result-object v1

    if-nez v1, :cond_108

    :cond_102
    iget-object v1, p5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    if-eqz v1, :cond_10d

    :cond_108
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    goto :goto_10f

    :cond_10d
    const/16 v1, 0x3e8

    :goto_10f
    invoke-direct {p4, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->priorityItem(I)Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_16b

    .line 683
    :sswitch_118
    const-string v0, "Played"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 693
    :cond_120
    invoke-virtual {p4, p7, p8}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_16b

    .line 683
    :sswitch_125
    const-string v0, "Looped"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 688
    if-eqz p0, :cond_135

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getLooped()Ljava/lang/Boolean;

    move-result-object v0

    if-nez v0, :cond_13b

    :cond_135
    iget-object v0, p3, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    if-eqz v0, :cond_140

    :cond_13b
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    goto :goto_141

    :cond_140
    const/4 v0, 0x0

    :goto_141
    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto :goto_16b

    .line 683
    :sswitch_14b
    const-string v0, "Length"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 685
    if-eqz p0, :cond_159

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getLength()F

    move-result v2

    :cond_159
    float-to-double v0, v2

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto :goto_16b

    .line 694
    :cond_164
    :goto_164
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NIL"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 695
    .end local p8    # "ks":Ljava/lang/String;
    :goto_16b
    return-object v0

    :sswitch_data_16c
    .sparse-switch
        -0x788cd8fa -> :sswitch_14b
        -0x77ff599d -> :sswitch_125
        -0x715c790d -> :sswitch_118
        -0x419d223c -> :sswitch_f0
        -0x3a06005d -> :sswitch_e6
        -0x253e011c -> :sswitch_dc
        -0xd17d653 -> :sswitch_d2
        -0xa0dc5b7 -> :sswitch_b2
        0x24eeab -> :sswitch_94
        0x3ffda9a -> :sswitch_8a
        0x4c61027 -> :sswitch_74
        0x37783784 -> :sswitch_58
        0x4ac98736 -> :sswitch_3e
        0x67310bc1 -> :sswitch_1e
    .end sparse-switch
.end method
