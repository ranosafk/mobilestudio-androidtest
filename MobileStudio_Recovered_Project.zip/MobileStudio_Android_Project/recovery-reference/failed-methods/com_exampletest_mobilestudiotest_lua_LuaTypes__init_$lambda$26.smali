.method static final _init_$lambda$26(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 127
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    .line 128
    .local v0, "v":Lcom/exampletest/mobilestudiotest/model/Vector2;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_b0

    goto/16 :goto_a2

    :sswitch_16
    const-string v1, "unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_28

    goto/16 :goto_a2

    :sswitch_20
    const-string v1, "Unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 131
    :cond_28
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_af

    .line 128
    :sswitch_34
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 133
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda53;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda53;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_af

    .line 128
    :sswitch_49
    const-string v1, "Dot"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 132
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda52;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda52;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_af

    .line 128
    :sswitch_5d
    const-string v1, "y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_77

    goto :goto_a2

    :sswitch_66
    const-string v1, "x"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_86

    goto :goto_a2

    :sswitch_6f
    const-string v1, "Y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 129
    :cond_77
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getY()F

    move-result v2

    goto :goto_8c

    .line 128
    :sswitch_7e
    const-string v1, "X"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 129
    :cond_86
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getX()F

    move-result v2

    :goto_8c
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_af

    .line 128
    :sswitch_91
    const-string v1, "Magnitude"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a3

    goto :goto_a2

    :sswitch_9a
    const-string v1, "magnitude"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a3

    :cond_a2
    :goto_a2
    goto :goto_ae

    .line 130
    :cond_a3
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getMagnitude()F

    move-result v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_af

    .line 134
    :goto_ae
    const/4 v1, 0x0

    .line 135
    :goto_af
    return-object v1

    :sswitch_data_b0
    .sparse-switch
        -0x7835adf0 -> :sswitch_9a
        -0xc38e10 -> :sswitch_91
        0x58 -> :sswitch_7e
        0x59 -> :sswitch_6f
        0x78 -> :sswitch_66
        0x79 -> :sswitch_5d
        0x10d29 -> :sswitch_49
        0x241597 -> :sswitch_34
        0x284da4 -> :sswitch_20
        0x36d984 -> :sswitch_16
    .end sparse-switch
.end method
