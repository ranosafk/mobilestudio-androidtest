.method public final call(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 33
    .param p1, "rt"    # Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;
    .param p2, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p3, "name"    # Ljava/lang/String;
    .param p4, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v8, p3

    move-object/from16 v9, p4

    const-string v3, "rt"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "inst"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "name"

    invoke-static {v8, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "a"

    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 319
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v10

    .line 320
    .local v10, "studio":Lcom/exampletest/mobilestudiotest/core/Studio;
    const/4 v3, 0x2

    invoke-virtual {v9, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v11

    .line 321
    .local v11, "a2":Lorg/luaj/vm2/LuaValue;
    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v3

    const-string v4, "Enabled"

    const-string v5, "__plugin"

    const-string v7, "checkjstring(...)"

    const-string v12, "Separate"

    const-string v13, "Union"

    const-string v14, "Negate"

    const-string v15, "Intersect"

    const-string v6, "NONE"

    const-string v2, "valueOf(...)"

    move/from16 v17, v3

    const-string v3, ""

    move-object/from16 v18, v14

    const/16 v19, 0x0

    const/16 v21, 0x1

    const-string v14, "optjstring(...)"

    move-object/from16 v22, v15

    const/4 v15, 0x0

    sparse-switch v17, :sswitch_data_656

    goto/16 :goto_618

    :sswitch_51
    const-string v2, "SetActive"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 341
    invoke-virtual {v11}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "Active"

    const/4 v5, 0x0

    move-object/from16 v2, p2

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->notifyPluginButtons()Z

    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 321
    :sswitch_77
    move-object/from16 v2, p2

    const-string v3, "GetMouse"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_618

    .line 362
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPluginMice()Ljava/util/IdentityHashMap;

    move-result-object v3

    check-cast v3, Ljava/util/Map;

    .local v3, "$this$getOrPut\\4":Ljava/util/Map;
    move-object/from16 v4, p2

    .local v4, "key\\4":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 566
    .local v5, "$i$f$getOrPut\\4\\362":I
    invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    .line 567
    .local v6, "value\\4":Ljava/lang/Object;
    if-nez v6, :cond_9d

    .line 568
    const/4 v7, 0x0

    .line 362
    .local v7, "$i$a$-getOrPut-PluginApi$call$3\\5\\568\\0":I
    sget-object v12, Lcom/exampletest/mobilestudiotest/lua/PluginApi;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/PluginApi;

    invoke-virtual {v12, v1}, Lcom/exampletest/mobilestudiotest/lua/PluginApi;->pluginMouse(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;)Lorg/luaj/vm2/LuaTable;

    move-result-object v7

    .line 568
    .end local v7    # "$i$a$-getOrPut-PluginApi$call$3\\5\\568\\0":I
    nop

    .line 569
    .local v7, "answer\\4":Ljava/lang/Object;
    invoke-interface {v3, v4, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 570
    nop

    .end local v7    # "answer\\4":Ljava/lang/Object;
    goto :goto_9e

    .line 572
    :cond_9d
    move-object v7, v6

    .line 567
    :goto_9e
    nop

    .line 362
    .end local v3    # "$this$getOrPut\\4":Ljava/util/Map;
    .end local v4    # "key\\4":Ljava/lang/Object;
    .end local v5    # "$i$f$getOrPut\\4\\362":I
    .end local v6    # "value\\4":Ljava/lang/Object;
    const-string v3, "getOrPut(...)"

    invoke-static {v7, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v3, v7

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 321
    :sswitch_a9
    move-object/from16 v2, p2

    const-string v3, "CreateToolbar"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_618

    .line 323
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v4, "PluginToolbar"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    .line 324
    .local v3, "tb":Lcom/exampletest/mobilestudiotest/model/Instance;
    const-string v4, "Plugin"

    invoke-virtual {v11, v4}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->setName(Ljava/lang/String;)V

    .line 325
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v4

    check-cast v4, Ljava/util/Map;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 326
    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    .end local v3    # "tb":Lcom/exampletest/mobilestudiotest/model/Instance;
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 321
    :sswitch_dc
    move-object/from16 v2, p2

    const-string v3, "CreateDockWidgetPluginGui"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_118

    goto/16 :goto_618

    :sswitch_e8
    move-object/from16 v2, p2

    const-string v3, "PromptImportFiles"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_618

    move-object v3, v2

    goto/16 :goto_3d7

    :sswitch_f5
    move-object/from16 v2, p2

    const-string v3, "SetReady"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_10b

    goto/16 :goto_618

    :sswitch_101
    move-object/from16 v2, p2

    const-string v3, "OpenWikiPage"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_618

    :cond_10b
    move-object v3, v2

    goto/16 :goto_40f

    :sswitch_10e
    move-object/from16 v2, p2

    const-string v3, "CreateQWidgetPluginGui"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_618

    :cond_118
    move-object v3, v2

    goto/16 :goto_30b

    :sswitch_11b
    move-object/from16 v2, p2

    invoke-virtual {v8, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_618

    move-object v3, v2

    goto/16 :goto_280

    :sswitch_126
    move-object/from16 v2, p2

    const-string v7, "CreateButton"

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_618

    .line 329
    sget-object v6, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v7, "PluginToolbarButton"

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6

    .line 330
    .local v6, "b":Lcom/exampletest/mobilestudiotest/model/Instance;
    const-string v7, "Button"

    invoke-virtual {v11, v7}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->setName(Ljava/lang/String;)V

    .line 331
    invoke-virtual {v9}, Lorg/luaj/vm2/Varargs;->narg()I

    move-result v12

    const/4 v13, 0x5

    if-lt v12, v13, :cond_15e

    invoke-virtual {v9, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v12

    invoke-virtual {v12}, Lorg/luaj/vm2/LuaValue;->isstring()Z

    move-result v12

    if-eqz v12, :cond_15e

    invoke-virtual {v9, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v7

    invoke-virtual {v7}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v7

    goto :goto_162

    :cond_15e
    invoke-virtual {v11, v7}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 332
    .local v7, "text":Ljava/lang/String;
    :goto_162
    const-string v12, "Text"

    invoke-virtual {v6, v12, v7, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 333
    const/4 v12, 0x3

    invoke-virtual {v9, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v12

    invoke-virtual {v12, v3}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "Tooltip"

    invoke-virtual {v6, v13, v12, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 334
    const/4 v12, 0x4

    invoke-virtual {v9, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v12

    invoke-virtual {v12, v3}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v12, "Icon"

    invoke-virtual {v6, v12, v3, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 335
    invoke-static/range {v21 .. v21}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v6, v4, v3, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 336
    const-string v3, "ClickableWhenViewportHidden"

    invoke-static {v15}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-virtual {v6, v3, v4, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 338
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Ljava/lang/String;

    if-eqz v4, :cond_1a3

    move-object/from16 v19, v3

    check-cast v19, Ljava/lang/String;

    :cond_1a3
    if-nez v19, :cond_1a9

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v19

    :cond_1a9
    move-object/from16 v3, v19

    invoke-virtual {v10, v6, v3, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->addPluginButton(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;)V

    .line 339
    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    .end local v6    # "b":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "text":Ljava/lang/String;
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 321
    :sswitch_1b6
    move-object/from16 v2, p2

    const-string v3, "SelectRibbonTool"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_618

    .line 384
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 321
    :sswitch_1c9
    move-object/from16 v2, p2

    const-string v3, "GetSetting"

    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_618

    .line 342
    invoke-direct {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/PluginApi;->pluginId(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v11}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v10, v3, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->pluginSetting(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_1ee

    .line 564
    .local v3, "it\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 342
    .local v4, "$i$a$-let-PluginApi$call$1\\1\\342\\0":I
    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/Json;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Json;

    invoke-virtual {v5, v1, v3}, Lcom/exampletest/mobilestudiotest/lua/Json;->decode(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    .end local v3    # "it\\1":Ljava/lang/String;
    .end local v4    # "$i$a$-let-PluginApi$call$1\\1\\342\\0":I
    if-eqz v3, :cond_1ee

    goto :goto_1f0

    :cond_1ee
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    :goto_1f0
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 321
    :sswitch_1f7
    move-object/from16 v2, p2

    const-string v4, "CreatePluginAction"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_618

    .line 368
    const-string v4, "Action"

    invoke-virtual {v11, v4}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v12, 0x3

    invoke-virtual {v9, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-virtual {v5, v3}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v12, 0x4

    invoke-virtual {v9, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v6, v3}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1, v4, v5, v3}, Lcom/exampletest/mobilestudiotest/lua/PluginApi;->action(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/luaj/vm2/LuaTable;

    move-result-object v3

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 321
    :sswitch_22a
    move-object/from16 v2, p2

    const-string v4, "CreatePluginMenu"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_618

    .line 369
    const-string v4, "Menu"

    invoke-virtual {v11, v4}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v12, 0x3

    invoke-virtual {v9, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-virtual {v5, v3}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1, v10, v4, v3}, Lcom/exampletest/mobilestudiotest/lua/PluginApi;->menu(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lcom/exampletest/mobilestudiotest/core/Studio;Ljava/lang/String;Ljava/lang/String;)Lorg/luaj/vm2/LuaTable;

    move-result-object v3

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 321
    :sswitch_251
    move-object/from16 v3, p2

    const-string v4, "IsActivatedWithExclusiveMouse"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_618

    .line 366
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getActivePlugin()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    if-ne v4, v3, :cond_26a

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getActivePluginExclusive()Z

    move-result v4

    if-eqz v4, :cond_26a

    move/from16 v14, v21

    goto :goto_26b

    :cond_26a
    move v14, v15

    :goto_26b
    invoke-static {v14}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v4

    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v4

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_278
    move-object/from16 v3, p2

    invoke-virtual {v8, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    :goto_280
    move-object/from16 v4, v18

    move-object/from16 v2, v22

    goto/16 :goto_4dc

    :sswitch_286
    move-object/from16 v3, p2

    const-string v2, "Deactivate"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 364
    invoke-virtual {v10, v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->deactivatePlugin(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    sget-object v2, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_29d
    move-object/from16 v3, p2

    const-string v2, "BindToClose"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 389
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getCallbacks()Ljava/util/IdentityHashMap;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    .local v2, "$this$getOrPut\\16":Ljava/util/Map;
    move-object/from16 v4, p2

    .local v4, "key\\16":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 589
    .local v5, "$i$f$getOrPut\\16\\389":I
    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    .line 590
    .local v6, "value\\16":Ljava/lang/Object;
    if-nez v6, :cond_2c2

    .line 591
    const/4 v7, 0x0

    .line 389
    .local v7, "$i$a$-getOrPut-PluginApi$call$5\\17\\591\\0":I
    new-instance v12, Ljava/util/HashMap;

    invoke-direct {v12}, Ljava/util/HashMap;-><init>()V

    .line 591
    .end local v7    # "$i$a$-getOrPut-PluginApi$call$5\\17\\591\\0":I
    nop

    .line 592
    .local v12, "answer\\16":Ljava/lang/Object;
    invoke-interface {v2, v4, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 593
    nop

    .end local v12    # "answer\\16":Ljava/lang/Object;
    goto :goto_2c3

    .line 595
    :cond_2c2
    move-object v12, v6

    .line 590
    :goto_2c3
    nop

    .line 389
    .end local v2    # "$this$getOrPut\\16":Ljava/util/Map;
    .end local v4    # "key\\16":Ljava/lang/Object;
    .end local v5    # "$i$f$getOrPut\\16\\389":I
    .end local v6    # "value\\16":Ljava/lang/Object;
    check-cast v12, Ljava/util/Map;

    const-string v2, "__close"

    invoke-virtual {v11}, Lorg/luaj/vm2/LuaValue;->checkfunction()Lorg/luaj/vm2/LuaFunction;

    move-result-object v4

    invoke-interface {v12, v2, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v2, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_2d9
    move-object/from16 v3, p2

    const-string v2, "StartDrag"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_40f

    goto/16 :goto_618

    :sswitch_2e5
    move-object/from16 v3, p2

    const-string v4, "GetGridSize"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_618

    .line 344
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v4

    float-to-double v4, v4

    invoke-static {v4, v5}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v4

    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v4

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_301
    move-object/from16 v3, p2

    const-string v2, "CreateDockWidgetPluginGuiAsync"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 347
    :goto_30b
    sget-object v2, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v5, "DockWidgetPluginGui"

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    .line 348
    .local v2, "w":Lcom/exampletest/mobilestudiotest/model/Instance;
    const-string v5, "Widget"

    invoke-virtual {v11, v5}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->setName(Ljava/lang/String;)V

    .line 349
    const/4 v12, 0x3

    invoke-virtual {v9, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    .line 350
    .local v5, "info":Lorg/luaj/vm2/LuaValue;
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v6

    if-eqz v6, :cond_339

    const-string v6, "InitialEnabled"

    invoke-virtual {v5, v6}, Lorg/luaj/vm2/LuaValue;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v6

    if-eqz v6, :cond_339

    move/from16 v6, v21

    goto :goto_33a

    :cond_339
    move v6, v15

    .line 351
    .local v6, "enabled":Z
    :goto_33a
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    invoke-virtual {v2, v4, v7, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 352
    const-string v4, "Title"

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v4, v7, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 353
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    move/from16 v7, v21

    invoke-direct {v4, v7}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    const-string v7, "ZIndexBehavior"

    invoke-virtual {v2, v7, v4, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 354
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v4

    if-eqz v4, :cond_390

    .line 355
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v4

    check-cast v4, Ljava/util/Map;

    const-string v7, "FloatingXSize"

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/LuaValue;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v7

    const/16 v12, 0x12c

    invoke-virtual {v7, v12}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const-string v13, "__w"

    invoke-interface {v4, v13, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 356
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v4

    check-cast v4, Ljava/util/Map;

    const-string v7, "FloatingYSize"

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/LuaValue;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v7

    invoke-virtual {v7, v12}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const-string v12, "__h"

    invoke-interface {v4, v12, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 358
    :cond_390
    invoke-virtual {v10, v2, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->addPluginWidget(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;)V

    .line 359
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    .end local v2    # "w":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v5    # "info":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "enabled":Z
    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_39c
    move-object/from16 v3, p2

    const-string v2, "GetRelativeMousePosition"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 390
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const/4 v5, 0x0

    invoke-direct {v4, v5, v5}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_3b7
    move-object/from16 v3, p2

    const-string v2, "IsLoaded"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 345
    sget-object v2, Lorg/luaj/vm2/LuaValue;->TRUE:Lorg/luaj/vm2/LuaBoolean;

    const-string v4, "TRUE"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_3cd
    move-object/from16 v3, p2

    const-string v2, "PromptImportFile"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 386
    :goto_3d7
    sget-object v2, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v4, "NIL"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_3e3
    move-object/from16 v3, p2

    const-string v4, "GetStudioUserId"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_618

    .line 367
    sget-object v4, Lcom/exampletest/mobilestudiotest/net/RobloxApi;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/RobloxApi;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getApp()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/net/RobloxApi;->userId(Landroid/content/Context;)J

    move-result-wide v4

    long-to-double v4, v4

    invoke-static {v4, v5}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v4

    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v4

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_405
    move-object/from16 v3, p2

    const-string v2, "SaveSelectedToRoblox"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 387
    :cond_40f
    :goto_40f
    sget-object v2, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_419
    move-object/from16 v3, p2

    const-string v4, "IsActivated"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_618

    .line 365
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getActivePlugin()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    if-ne v4, v3, :cond_42b

    const/4 v14, 0x1

    goto :goto_42c

    :cond_42b
    move v14, v15

    :goto_42c
    invoke-static {v14}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v4

    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v4

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_439
    move-object/from16 v3, p2

    const-string v2, "GetSelectedRibbonTool"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 385
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v4, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    const-string v5, "RibbonTool"

    const-string v6, "Select"

    const/4 v7, 0x1

    invoke-direct {v4, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_458
    move-object/from16 v3, p2

    const-string v2, "Activate"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 363
    invoke-virtual {v11}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v2

    invoke-virtual {v10, v3, v1, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->activatePlugin(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Z)V

    sget-object v2, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_473
    move-object/from16 v3, p2

    const-string v2, "SetSetting"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 343
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/PluginApi;->pluginId(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/Json;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Json;

    const/4 v12, 0x3

    invoke-virtual {v9, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    const-string v7, "arg(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/lua/Json;->encode(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v10, v2, v4, v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->setPluginSetting(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sget-object v2, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_4a5
    move-object/from16 v3, p2

    move-object/from16 v2, v22

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_618

    move-object/from16 v4, v18

    goto :goto_4dc

    :sswitch_4b2
    move-object/from16 v3, p2

    const-string v2, "GetJoinMode"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_618

    .line 388
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v4, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    const-string v5, "JointCreationMode"

    const-string v6, "All"

    invoke-direct {v4, v5, v6, v15}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    move-object v3, v2

    goto/16 :goto_655

    .line 321
    :sswitch_4d0
    move-object/from16 v3, p2

    move-object/from16 v2, v22

    move-object/from16 v4, v18

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_618

    .line 371
    :goto_4dc
    new-instance v5, Lkotlin/ranges/IntRange;

    invoke-virtual {v11}, Lorg/luaj/vm2/LuaValue;->length()I

    move-result v6

    const/4 v7, 0x1

    invoke-direct {v5, v7, v6}, Lkotlin/ranges/IntRange;-><init>(II)V

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$mapNotNull\\6":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 573
    .local v6, "$i$f$mapNotNull\\6\\371":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\7":Ljava/util/Collection;
    move-object v14, v5

    .local v14, "$this$mapNotNullTo\\7":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 581
    .local v16, "$i$f$mapNotNullTo\\7\\573":I
    move-object/from16 v17, v14

    .local v17, "$this$forEach\\8":Ljava/lang/Iterable;
    const/16 v18, 0x0

    .line 582
    .local v18, "$i$f$forEach\\8\\581":I
    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v20

    :goto_4fb
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_549

    move-object/from16 v21, v20

    check-cast v21, Lkotlin/collections/IntIterator;

    invoke-virtual/range {v21 .. v21}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v21

    .local v21, "element\\8":I
    move/from16 v22, v21

    .local v22, "element\\9":I
    const/16 v23, 0x0

    .line 581
    .local v23, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\9\\582\\7":I
    move/from16 v24, v22

    .local v24, "it\\11":I
    const/16 v25, 0x0

    .line 371
    .local v25, "$i$a$-mapNotNull-PluginApi$call$list$1\\11\\581\\0":I
    move/from16 v15, v24

    .end local v24    # "it\\11":I
    .local v15, "it\\11":I
    invoke-virtual {v11, v15}, Lorg/luaj/vm2/LuaValue;->get(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v3, "get(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v0, "$this$udOrNull\\12":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 583
    .local v3, "$i$f$udOrNull\\12\\371":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v24

    if-eqz v24, :cond_52e

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v24

    move-object/from16 v27, v24

    move-object/from16 v24, v0

    move-object/from16 v0, v27

    goto :goto_532

    :cond_52e
    move-object/from16 v24, v0

    move-object/from16 v0, v19

    .end local v0    # "$this$udOrNull\\12":Lorg/luaj/vm2/LuaValue;
    .local v24, "$this$udOrNull\\12":Lorg/luaj/vm2/LuaValue;
    :goto_532
    move/from16 v26, v3

    .end local v3    # "$i$f$udOrNull\\12\\371":I
    .local v26, "$i$f$udOrNull\\12\\371":I
    instance-of v3, v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v3, :cond_53a

    move-object/from16 v0, v19

    :cond_53a
    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 371
    .end local v24    # "$this$udOrNull\\12":Lorg/luaj/vm2/LuaValue;
    .end local v26    # "$i$f$udOrNull\\12\\371":I
    nop

    .line 581
    .end local v15    # "it\\11":I
    .end local v25    # "$i$a$-mapNotNull-PluginApi$call$list$1\\11\\581\\0":I
    if-eqz v0, :cond_543

    .line 584
    .local v0, "it\\9":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 581
    .local v3, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\10\\584\\9":I
    invoke-interface {v7, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 582
    .end local v0    # "it\\9":Ljava/lang/Object;
    .end local v3    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\10\\584\\9":I
    .end local v22    # "element\\9":I
    .end local v23    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\9\\582\\7":I
    :cond_543
    const/4 v15, 0x0

    move-object/from16 v0, p0

    move-object/from16 v3, p2

    .end local v21    # "element\\8":I
    goto :goto_4fb

    .line 585
    :cond_549
    nop

    .line 586
    .end local v17    # "$this$forEach\\8":Ljava/lang/Iterable;
    .end local v18    # "$i$f$forEach\\8\\581":I
    nop

    .end local v7    # "destination\\7":Ljava/util/Collection;
    .end local v14    # "$this$mapNotNullTo\\7":Ljava/lang/Iterable;
    .end local v16    # "$i$f$mapNotNullTo\\7\\573":I
    move-object v0, v7

    check-cast v0, Ljava/util/List;

    .line 573
    nop

    .line 371
    .end local v5    # "$this$mapNotNull\\6":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapNotNull\\6\\371":I
    nop

    .line 372
    .local v0, "list":Ljava/util/List;
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v3

    .line 373
    .local v3, "saved":Ljava/util/List;
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v5

    move-object v6, v0

    check-cast v6, Ljava/util/Collection;

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 374
    nop

    .line 375
    invoke-static {v8, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_578

    sget-object v4, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/SolidModeling;

    invoke-virtual {v4, v10}, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->negate(Lcom/exampletest/mobilestudiotest/core/Studio;)I

    goto :goto_58f

    .line 376
    :cond_578
    invoke-static {v8, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_585

    sget-object v4, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/SolidModeling;

    invoke-virtual {v4, v10}, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->separate(Lcom/exampletest/mobilestudiotest/core/Studio;)Ljava/lang/String;

    move-result-object v19

    goto :goto_58f

    .line 377
    :cond_585
    sget-object v4, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/SolidModeling;

    invoke-static {v8, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v4, v10, v5}, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->combine(Lcom/exampletest/mobilestudiotest/core/Studio;Z)Ljava/lang/String;

    move-result-object v19

    .line 374
    :goto_58f
    move-object/from16 v4, v19

    .line 379
    .local v4, "err":Ljava/lang/String;
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v5

    .line 380
    .local v5, "result":Ljava/util/List;
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v6

    move-object v7, v3

    check-cast v7, Ljava/util/Collection;

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 381
    if-nez v4, :cond_608

    .line 382
    invoke-static {v8, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5f8

    invoke-static {v8, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5bd

    move-object/from16 v16, v0

    goto :goto_5fa

    :cond_5bd
    new-instance v2, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v2}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v6, v2

    .line 564
    .local v6, "t\\13":Lorg/luaj/vm2/LuaTable;
    const/4 v7, 0x0

    .line 382
    .local v7, "$i$a$-also-PluginApi$call$4\\13\\382\\0":I
    move-object v12, v5

    check-cast v12, Ljava/lang/Iterable;

    .local v12, "$this$forEach\\14":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 587
    .local v13, "$i$f$forEach\\14\\382":I
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_5cc
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_5ee

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v16, v0

    .end local v0    # "list":Ljava/util/List;
    .local v15, "element\\14":Ljava/lang/Object;
    .local v16, "list":Ljava/util/List;
    move-object v0, v15

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v0, "it\\15":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v17, 0x0

    .line 382
    .local v17, "$i$a$-forEach-PluginApi$call$4$1\\15\\587\\13":I
    move-object/from16 v18, v2

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    move-object/from16 v19, v0

    const/4 v0, 0x0

    .end local v0    # "it\\15":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v19, "it\\15":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v6, v0, v2}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 587
    .end local v17    # "$i$a$-forEach-PluginApi$call$4$1\\15\\587\\13":I
    .end local v19    # "it\\15":Lcom/exampletest/mobilestudiotest/model/Instance;
    move-object/from16 v0, v16

    move-object/from16 v2, v18

    .end local v15    # "element\\14":Ljava/lang/Object;
    goto :goto_5cc

    .line 588
    .end local v16    # "list":Ljava/util/List;
    .local v0, "list":Ljava/util/List;
    :cond_5ee
    move-object/from16 v16, v0

    move-object/from16 v18, v2

    .line 382
    .end local v0    # "list":Ljava/util/List;
    .end local v12    # "$this$forEach\\14":Ljava/lang/Iterable;
    .end local v13    # "$i$f$forEach\\14\\382":I
    .restart local v16    # "list":Ljava/util/List;
    nop

    .end local v6    # "t\\13":Lorg/luaj/vm2/LuaTable;
    .end local v7    # "$i$a$-also-PluginApi$call$4\\13\\382\\0":I
    move-object/from16 v2, v18

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    goto :goto_604

    .end local v16    # "list":Ljava/util/List;
    .restart local v0    # "list":Ljava/util/List;
    :cond_5f8
    move-object/from16 v16, v0

    .end local v0    # "list":Ljava/util/List;
    .restart local v16    # "list":Ljava/util/List;
    :goto_5fa
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    .end local v3    # "saved":Ljava/util/List;
    .end local v4    # "err":Ljava/lang/String;
    .end local v5    # "result":Ljava/util/List;
    .end local v16    # "list":Ljava/util/List;
    :goto_604
    move-object v3, v2

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto :goto_655

    .line 381
    .restart local v0    # "list":Ljava/util/List;
    .restart local v3    # "saved":Ljava/util/List;
    .restart local v4    # "err":Ljava/lang/String;
    .restart local v5    # "result":Ljava/util/List;
    :cond_608
    move-object/from16 v16, v0

    .end local v0    # "list":Ljava/util/List;
    .restart local v16    # "list":Ljava/util/List;
    new-instance v0, Lorg/luaj/vm2/LuaError;

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 321
    .end local v3    # "saved":Ljava/util/List;
    .end local v4    # "err":Ljava/lang/String;
    .end local v5    # "result":Ljava/util/List;
    .end local v16    # "list":Ljava/util/List;
    :sswitch_610
    const-string v0, "OpenScript"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_619

    :cond_618
    :goto_618
    goto :goto_64d

    .line 361
    :cond_619
    invoke-static {v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v0, v11

    .local v0, "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 565
    .local v2, "$i$f$udOrNull\\2\\361":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    if-eqz v3, :cond_629

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_62b

    :cond_629
    move-object/from16 v3, v19

    :goto_62b
    instance-of v4, v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v4, :cond_631

    move-object/from16 v19, v3

    :cond_631
    check-cast v19, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 361
    .end local v0    # "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$udOrNull\\2\\361":I
    if-eqz v19, :cond_644

    move-object/from16 v0, v19

    .line 564
    .local v0, "s\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x0

    .line 361
    .local v2, "$i$a$-let-PluginApi$call$2\\3\\361\\0":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMain()Landroid/os/Handler;

    move-result-object v3

    new-instance v4, Lcom/exampletest/mobilestudiotest/lua/PluginApi$$ExternalSyntheticLambda11;

    invoke-direct {v4, v10, v0}, Lcom/exampletest/mobilestudiotest/lua/PluginApi$$ExternalSyntheticLambda11;-><init>(Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .end local v0    # "s\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "$i$a$-let-PluginApi$call$2\\3\\361\\0":I
    :cond_644
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v3, v0

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto :goto_655

    .line 391
    :goto_64d
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v3, v0

    check-cast v3, Lorg/luaj/vm2/Varargs;

    .line 321
    :goto_655
    return-object v3

    :sswitch_data_656
    .sparse-switch
        -0x7556a02b -> :sswitch_610
        -0x75266cde -> :sswitch_4d0
        -0x744c34bd -> :sswitch_4b2
        -0x6a927b01 -> :sswitch_4a5
        -0x61908c52 -> :sswitch_473
        -0x5ed9c6ed -> :sswitch_458
        -0x4bfd1da1 -> :sswitch_439
        -0x4a2a4c59 -> :sswitch_419
        -0x3ca00abd -> :sswitch_405
        -0x3b0129ee -> :sswitch_3e3
        -0x36ef709b -> :sswitch_3cd
        -0x15637a11 -> :sswitch_3b7
        -0x10972414 -> :sswitch_39c
        -0xdcec639 -> :sswitch_301
        -0xdc74e43 -> :sswitch_2e5
        -0x77f7b6a -> :sswitch_2d9
        -0x4b4fee0 -> :sswitch_29d
        -0x32536c -> :sswitch_286
        0x4e166af -> :sswitch_278
        0x18851f14 -> :sswitch_251
        0x237edd6e -> :sswitch_22a
        0x2aa97e85 -> :sswitch_1f7
        0x2afe263a -> :sswitch_1c9
        0x41fff1ca -> :sswitch_1b6
        0x48625b6e -> :sswitch_126
        0x5181e743 -> :sswitch_11b
        0x51d74baf -> :sswitch_10e
        0x56ba22e9 -> :sswitch_101
        0x577bfe81 -> :sswitch_f5
        0x59015dae -> :sswitch_e8
        0x69f2a1b5 -> :sswitch_dc
        0x7191debf -> :sswitch_a9
        0x78ac470f -> :sswitch_77
        0x7aedf5e8 -> :sswitch_51
    .end sparse-switch
.end method
