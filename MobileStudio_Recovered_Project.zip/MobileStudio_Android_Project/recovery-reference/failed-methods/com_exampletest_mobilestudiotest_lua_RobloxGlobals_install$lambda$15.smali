.method static final install$lambda$15(Lorg/luaj/vm2/Globals;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 9
    .param p0, "$g"    # Lorg/luaj/vm2/Globals;
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    invoke-virtual {p1}, Lorg/luaj/vm2/Varargs;->arg1()Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .line 77
    .local v0, "x":Lorg/luaj/vm2/LuaValue;
    nop

    .line 78
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isfunction()Z

    move-result v1

    if-eqz v1, :cond_11

    goto :goto_71

    .line 79
    :cond_11
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_51

    .line 80
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->getmetatable()Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    .line 81
    .local v1, "mt":Lorg/luaj/vm2/LuaValue;
    if-eqz v1, :cond_26

    const-string v4, "__iter"

    invoke-virtual {v1, v4}, Lorg/luaj/vm2/LuaValue;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    goto :goto_27

    :cond_26
    const/4 v4, 0x0

    .line 82
    .local v4, "it":Lorg/luaj/vm2/LuaValue;
    :goto_27
    if-eqz v4, :cond_37

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isfunction()Z

    move-result v5

    if-eqz v5, :cond_37

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    invoke-virtual {v4, v2}, Lorg/luaj/vm2/LuaValue;->invoke(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v2

    goto :goto_4d

    .line 83
    :cond_37
    const/4 v5, 0x3

    new-array v5, v5, [Lorg/luaj/vm2/LuaValue;

    const-string v6, "next"

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Globals;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    aput-object v6, v5, v3

    aput-object v0, v5, v2

    const/4 v2, 0x2

    sget-object v3, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    aput-object v3, v5, v2

    invoke-static {v5}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v2

    .line 79
    .end local v1    # "mt":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "it":Lorg/luaj/vm2/LuaValue;
    :goto_4d
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    goto :goto_72

    .line 85
    :cond_51
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v1

    if-eqz v1, :cond_73

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->getmetatable()Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    if-eqz v1, :cond_6e

    sget-object v4, Lorg/luaj/vm2/LuaValue;->CALL:Lorg/luaj/vm2/LuaString;

    check-cast v4, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v1, v4}, Lorg/luaj/vm2/LuaValue;->get(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    if-eqz v1, :cond_6e

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isfunction()Z

    move-result v1

    if-ne v1, v2, :cond_6e

    goto :goto_6f

    :cond_6e
    move v2, v3

    :goto_6f
    if-eqz v2, :cond_73

    .line 87
    :goto_71
    move-object v2, p1

    :goto_72
    return-object v2

    .line 86
    :cond_73
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "attempt to iterate over a "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " value"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1
.end method
