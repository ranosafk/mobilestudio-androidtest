.method private final member(Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;Lcom/exampletest/mobilestudiotest/core/Studio;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    .registers 16
    .param p1, "t"    # Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    .param p2, "s"    # Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;
    .param p3, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;

    .line 381
    nop

    .line 382
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$EnumRoot;

    if-eqz v0, :cond_11

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$EnumType;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$EnumType;-><init>(Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    return-object v0

    .line 383
    :cond_11
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$DataStatic;

    if-eqz v0, :cond_43

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "new"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_34

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getCall()Z

    move-result v0

    if-nez v0, :cond_34

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Data;

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$DataStatic;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$DataStatic;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Data;-><init>(Ljava/lang/String;)V

    goto :goto_40

    :cond_34
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Data;

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$DataStatic;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$DataStatic;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Data;-><init>(Ljava/lang/String;)V

    :goto_40
    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    return-object v0

    .line 384
    :cond_43
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Data;

    const/16 v1, 0x3a

    const/4 v2, 0x0

    if-eqz v0, :cond_a5

    .line 385
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->dataMembers:Ljava/util/Map;

    move-object v3, p1

    check-cast v3, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Data;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Data;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkotlin/Pair;

    .line 386
    .local v0, "dm":Lkotlin/Pair;
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getAcc()C

    move-result v3

    if-ne v3, v1, :cond_7b

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getCall()Z

    move-result v1

    if-eqz v1, :cond_7b

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->methodReturns:Ljava/util/Map;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-eqz v1, :cond_7a

    .line 583
    .local v1, "it\\1":Ljava/lang/String;
    const/4 v2, 0x0

    .line 386
    .local v2, "$i$a$-let-Autocomplete$member$1\\1\\386\\0":I
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete;

    invoke-direct {v3, v1, p3}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->typeFromHint(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/core/Studio;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    move-result-object v2

    .end local v1    # "it\\1":Ljava/lang/String;
    .end local v2    # "$i$a$-let-Autocomplete$member$1\\1\\386\\0":I
    :cond_7a
    return-object v2

    .line 387
    :cond_7b
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->propTypes:Ljava/util/Map;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-eqz v1, :cond_94

    .line 583
    .local v1, "it\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 387
    .local v3, "$i$a$-let-Autocomplete$member$2\\2\\387\\0":I
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete;

    invoke-direct {v4, v1, p3}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->typeFromHint(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/core/Studio;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    move-result-object v1

    .end local v1    # "it\\2":Ljava/lang/String;
    .end local v3    # "$i$a$-let-Autocomplete$member$2\\2\\387\\0":I
    if-eqz v1, :cond_94

    move-object v2, v1

    goto :goto_a4

    :cond_94
    if-eqz v0, :cond_a4

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    :cond_a4
    :goto_a4
    return-object v2

    .line 391
    .end local v0    # "dm":Lkotlin/Pair;
    :cond_a5
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->clsOf(Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_ac

    return-object v2

    .line 392
    .local v0, "cls":Ljava/lang/String;
    :cond_ac
    instance-of v3, p1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    if-eqz v3, :cond_b4

    move-object v3, p1

    check-cast v3, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    goto :goto_b5

    :cond_b4
    move-object v3, v2

    :goto_b5
    if-eqz v3, :cond_bc

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;->getI()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    goto :goto_bd

    :cond_bc
    move-object v3, v2

    .line 393
    .local v3, "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_bd
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getAcc()C

    move-result v4

    const-string v5, "Instance"

    if-eq v4, v1, :cond_175

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getCall()Z

    move-result v1

    if-nez v1, :cond_175

    .line 411
    if-eqz v3, :cond_105

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_105

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$firstOrNull\\8":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 584
    .local v4, "$i$f$firstOrNull\\8\\411":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_da
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_f7

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\8":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\9":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 411
    .local v9, "$i$a$-firstOrNull-Autocomplete$member$7\\9\\584\\0":I
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    .line 584
    .end local v8    # "it\\9":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-firstOrNull-Autocomplete$member$7\\9\\584\\0":I
    if-eqz v8, :cond_da

    goto :goto_f8

    .line 585
    .end local v7    # "element\\8":Ljava/lang/Object;
    :cond_f7
    move-object v7, v2

    .line 411
    .end local v1    # "$this$firstOrNull\\8":Ljava/lang/Iterable;
    .end local v4    # "$i$f$firstOrNull\\8\\411":I
    :goto_f8
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v7, :cond_105

    .line 583
    .local v7, "it\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v1, 0x0

    .line 411
    .local v1, "$i$a$-let-Autocomplete$member$8\\10\\411\\0":I
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-direct {v2, v7}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    check-cast v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    return-object v2

    .line 412
    .end local v1    # "$i$a$-let-Autocomplete$member$8\\10\\411\\0":I
    .end local v7    # "it\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_105
    instance-of v1, v3, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-eqz v1, :cond_11f

    move-object v1, v3

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/DataModel;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-eqz v1, :cond_11f

    .line 583
    .local v1, "it\\11":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x0

    .line 412
    .local v2, "$i$a$-let-Autocomplete$member$9\\11\\412\\0":I
    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-direct {v4, v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    check-cast v4, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    return-object v4

    .line 413
    .end local v1    # "it\\11":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "$i$a$-let-Autocomplete$member$9\\11\\412\\0":I
    :cond_11f
    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->membersFor(Ljava/lang/String;)Lkotlin/Triple;

    move-result-object v1

    invoke-virtual {v1}, Lkotlin/Triple;->component3()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Set;

    .line 414
    .local v1, "events":Ljava/util/Set;
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v1, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_138

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Signal;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Signal;

    check-cast v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    return-object v2

    .line 415
    :cond_138
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v4

    const-string v6, "Parent"

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_15e

    if-eqz v3, :cond_155

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    if-eqz v2, :cond_155

    .line 583
    .local v2, "it\\12":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v4, 0x0

    .line 415
    .local v4, "$i$a$-let-Autocomplete$member$10\\12\\415\\0":I
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-direct {v5, v2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v2    # "it\\12":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v4    # "$i$a$-let-Autocomplete$member$10\\12\\415\\0":I
    check-cast v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_15d

    :cond_155
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;

    invoke-direct {v2, v5}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;-><init>(Ljava/lang/String;)V

    move-object v5, v2

    check-cast v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    :goto_15d
    return-object v5

    .line 416
    :cond_15e
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->propTypes:Ljava/util/Map;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-eqz v4, :cond_174

    .line 583
    .local v4, "it\\13":Ljava/lang/String;
    const/4 v2, 0x0

    .line 416
    .local v2, "$i$a$-let-Autocomplete$member$11\\13\\416\\0":I
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete;

    invoke-direct {v5, v4, p3}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->typeFromHint(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/core/Studio;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    move-result-object v5

    return-object v5

    .line 417
    .end local v2    # "$i$a$-let-Autocomplete$member$11\\13\\416\\0":I
    .end local v4    # "it\\13":Ljava/lang/String;
    :cond_174
    return-object v2

    .line 394
    .end local v1    # "events":Ljava/util/Set;
    :cond_175
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v4

    const-string v6, "FindFirstDescendant"

    sparse-switch v4, :sswitch_data_24e

    goto :goto_1d4

    :sswitch_183
    const-string v4, "FindFirstChild"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d5

    goto :goto_1d4

    :sswitch_18c
    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d5

    goto :goto_1d4

    :sswitch_193
    const-string v4, "GetService"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1a4

    goto :goto_1d4

    :sswitch_19c
    const-string v4, "FindService"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d4

    .line 395
    :cond_1a4
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getArg()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_216

    .line 583
    .local v1, "n\\3":Ljava/lang/String;
    const/4 v2, 0x0

    .line 395
    .local v2, "$i$a$-let-Autocomplete$member$3\\3\\395\\0":I
    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v4

    const-string v5, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.DataModel"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    if-eqz v4, :cond_1c3

    .line 583
    .local v4, "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v5, 0x0

    .line 395
    .local v5, "$i$a$-let-Autocomplete$member$3$1\\4\\395\\3":I
    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-direct {v6, v4}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v4    # "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v5    # "$i$a$-let-Autocomplete$member$3$1\\4\\395\\3":I
    check-cast v6, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_1cb

    :cond_1c3
    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;

    invoke-direct {v4, v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;-><init>(Ljava/lang/String;)V

    move-object v6, v4

    check-cast v6, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    :goto_1cb
    return-object v6

    .line 394
    .end local v1    # "n\\3":Ljava/lang/String;
    .end local v2    # "$i$a$-let-Autocomplete$member$3\\3\\395\\0":I
    :sswitch_1cc
    const-string v4, "WaitForChild"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d5

    :cond_1d4
    :goto_1d4
    goto :goto_216

    .line 397
    :cond_1d5
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getArg()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1e3

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;

    invoke-direct {v1, v5}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;-><init>(Ljava/lang/String;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    return-object v1

    .line 398
    .local v1, "n":Ljava/lang/String;
    :cond_1e3
    if-eqz v3, :cond_1fc

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {v3, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    if-eqz v2, :cond_1fc

    .line 583
    .local v2, "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v4, 0x0

    .line 398
    .local v4, "$i$a$-let-Autocomplete$member$4\\5\\398\\0":I
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-direct {v5, v2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    check-cast v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    return-object v5

    .line 399
    .end local v2    # "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v4    # "$i$a$-let-Autocomplete$member$4\\5\\398\\0":I
    :cond_1fc
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->propTypes:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_20e

    .line 583
    .local v2, "it\\6":Ljava/lang/String;
    const/4 v4, 0x0

    .line 399
    .local v4, "$i$a$-let-Autocomplete$member$5\\6\\399\\0":I
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete;

    invoke-direct {v5, v2, p3}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->typeFromHint(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/core/Studio;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    move-result-object v5

    return-object v5

    .line 400
    .end local v2    # "it\\6":Ljava/lang/String;
    .end local v4    # "$i$a$-let-Autocomplete$member$5\\6\\399\\0":I
    :cond_20e
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;

    invoke-direct {v2, v5}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;-><init>(Ljava/lang/String;)V

    check-cast v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    return-object v2

    .line 403
    .end local v1    # "n":Ljava/lang/String;
    :cond_216
    :goto_216
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->methodReturns:Ljava/util/Map;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_225

    return-object v2

    .line 404
    .local v1, "r":Ljava/lang/String;
    :cond_225
    nop

    .line 405
    const-string v4, "@self"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_230

    move-object v2, p1

    goto :goto_24c

    .line 406
    :cond_230
    const-string v4, "@arg"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_248

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Step;->getArg()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_245

    .line 583
    .local v4, "it\\7":Ljava/lang/String;
    const/4 v2, 0x0

    .line 406
    .local v2, "$i$a$-let-Autocomplete$member$6\\7\\406\\0":I
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;

    invoke-direct {v5, v4}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;-><init>(Ljava/lang/String;)V

    move-object v2, v5

    .end local v2    # "$i$a$-let-Autocomplete$member$6\\7\\406\\0":I
    .end local v4    # "it\\7":Ljava/lang/String;
    :cond_245
    check-cast v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_24c

    .line 407
    :cond_248
    invoke-direct {p0, v1, p3}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->typeFromHint(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/core/Studio;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    move-result-object v2

    .line 404
    :goto_24c
    return-object v2

    nop

    :sswitch_data_24e
    .sparse-switch
        -0x7907ed78 -> :sswitch_1cc
        0xb81de9c -> :sswitch_19c
        0x2ae2de9f -> :sswitch_193
        0x2f6ae0b4 -> :sswitch_18c
        0x79b9eb05 -> :sswitch_183
    .end sparse-switch
.end method
