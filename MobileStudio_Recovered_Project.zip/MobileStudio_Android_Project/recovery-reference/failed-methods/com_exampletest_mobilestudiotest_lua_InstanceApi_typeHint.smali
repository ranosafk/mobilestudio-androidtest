.method private final typeHint(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Integer;
    .registers 20
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;

    .line 402
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, 0x2

    .line 405
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    .line 402
    const/4 v4, 0x1

    .line 403
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    .line 402
    const/16 v5, 0x13

    .line 404
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    .line 402
    sparse-switch v2, :sswitch_data_4d4

    goto :goto_3f

    :sswitch_1c
    const-string v2, "Archivable"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2d

    goto :goto_3f

    :sswitch_25
    const-string v2, "Enabled"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3f

    .line 405
    :cond_2d
    return-object v3

    .line 402
    :sswitch_2e
    const-string v2, "Name"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3f

    .line 403
    return-object v4

    .line 402
    :sswitch_37
    const-string v2, "Parent"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_40

    :cond_3f
    :goto_3f
    goto :goto_41

    .line 404
    :cond_40
    return-object v5

    .line 407
    :goto_41
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isPart(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v2

    const/16 v6, 0xc

    const-string v7, "Position"

    const-string v8, "Color"

    const-string v9, "Rotation"

    const/16 v10, 0x10

    const-string v11, "Size"

    if-eqz v2, :cond_cb

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    sparse-switch v2, :sswitch_data_4e6

    goto/16 :goto_cb

    :sswitch_5c
    const-string v2, "CFrame"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 411
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 407
    :sswitch_69
    const-string v2, "RotVelocity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_72
    const-string v2, "AssemblyLinearVelocity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_7b
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_82
    const-string v2, "Orientation"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_8b
    const-string v2, "AssemblyAngularVelocity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_94
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 409
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 407
    :sswitch_9f
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_a6
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_ad
    const-string v2, "BrickColor"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 410
    const/16 v2, 0xb

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 407
    :sswitch_bc
    const-string v2, "Velocity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 408
    :cond_c4
    const/16 v2, 0xe

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 413
    :cond_cb
    :goto_cb
    const-string v2, "WorldPivot"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d8

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 414
    :cond_d8
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    const-string v10, "Humanoid"

    invoke-static {v2, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v10, 0x4

    if-eqz v2, :cond_f2

    const-string v2, "Health"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_f2

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 415
    :cond_f2
    sget-object v2, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v2, v0, v1}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 416
    .local v2, "key":Ljava/lang/String;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v12

    invoke-virtual {v12, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    if-eqz v12, :cond_110

    check-cast v12, Ljava/lang/Number;

    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    move-result v3

    .line 1017
    .local v3, "it\\1":I
    const/4 v4, 0x0

    .line 416
    .local v4, "$i$a$-let-InstanceApi$typeHint$1\\1\\416\\0":I
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    return-object v5

    .line 418
    .end local v3    # "it\\1":I
    .end local v4    # "$i$a$-let-InstanceApi$typeHint$1\\1\\416\\0":I
    :cond_110
    move-object/from16 v12, p0

    iget-object v13, v12, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->sequenceClasses:Ljava/util/Set;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v14

    invoke-interface {v13, v14}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v13

    const/16 v14, 0xd

    const-string v15, "Transparency"

    if-eqz v13, :cond_16d

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v13

    sparse-switch v13, :sswitch_data_514

    goto :goto_16d

    :sswitch_12a
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_16d

    .line 420
    const/16 v3, 0x16

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    return-object v3

    .line 418
    :sswitch_137
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_14d

    goto :goto_16d

    :sswitch_13e
    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_14d

    goto :goto_16d

    :sswitch_145
    const-string v8, "Squash"

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_16d

    .line 419
    :cond_14d
    const/16 v3, 0x15

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    return-object v3

    .line 418
    :sswitch_154
    const-string v8, "Offset"

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_16d

    .line 421
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v8

    const-string v13, "UIGradient"

    invoke-static {v8, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_16d

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    return-object v3

    .line 423
    :cond_16d
    :goto_16d
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v8

    const-string v13, "Value"

    const/16 v16, 0x0

    sparse-switch v8, :sswitch_data_52a

    goto/16 :goto_4ca

    :sswitch_17a
    const-string v4, "Visible"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_184
    const-string v3, "FogEnd"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_18e
    const-string v3, "FillDirection"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_198
    const-string v3, "SortOrder"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_1a2
    const-string v4, "Active"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_1ac
    const-string v3, "CameraSubject"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_1b6
    const-string v3, "FieldOfView"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_1c0
    const-string v4, "AutoButtonColor"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_1ca
    const-string v3, "BorderSizePixel"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_475

    goto/16 :goto_4ca

    :sswitch_1d4
    const-string v3, "DisplayOrder"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_475

    goto/16 :goto_4ca

    :sswitch_1de
    const-string v4, "CanCollide"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_1e8
    const-string v4, "Playing"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_1f2
    const-string v3, "MaxHealth"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_1fc
    const-string v3, "BorderColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_206
    const-string v3, "JumpHeight"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_210
    const-string v3, "ClockTime"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_21a
    const-string v3, "Thickness"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_224
    const-string v3, "TextureID"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_22e
    const-string v4, "IgnoreGuiInset"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_238
    const-string v3, "TextStrokeColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_242
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_36b

    goto/16 :goto_4ca

    :sswitch_24a
    const-string v3, "PrimaryPart"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_254
    const-string v3, "Ambient"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_25e
    const-string v3, "PlaceholderText"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_268
    const-string v3, "TextXAlignment"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_272
    const-string v3, "Adornee"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_27c
    const-string v3, "BackgroundColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_286
    const-string v3, "TextYAlignment"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_290
    const-string v3, "Material"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_29a
    const-string v4, "Massless"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_2a4
    const-string v4, "Disabled"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_2ae
    const-string v3, "Texture"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_2b8
    const-string v3, "FogStart"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_2c2
    const-string v3, "FogColor"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_2cc
    const-string v3, "ScaleType"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_2d6
    const-string v3, "AnchorPoint"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 434
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_4d2

    .line 423
    :sswitch_2e4
    invoke-virtual {v1, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_2ec
    const-string v3, "Title"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_2f6
    const-string v3, "Shape"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_300
    const-string v3, "Range"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_30a
    const-string v3, "Part1"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_314
    const-string v3, "Part0"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 435
    :cond_31c
    invoke-static {v1, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_332

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "ObjectValue"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_332

    move-object/from16 v3, v16

    goto/16 :goto_4d2

    :cond_332
    move-object v3, v5

    goto/16 :goto_4d2

    .line 423
    :sswitch_335
    const-string v3, "Image"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_33f
    const-string v3, "Angle"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_349
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_351
    const-string v3, "OutdoorAmbient"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_35b
    const-string v3, "Text"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_365
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 433
    :cond_36b
    const-string v3, "GuiObject"

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_37a

    const/4 v3, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_4d2

    :cond_37a
    move-object/from16 v3, v16

    goto/16 :goto_4d2

    .line 423
    :sswitch_37e
    const-string v3, "Font"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_388
    const-string v3, "TextTransparency"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_392
    const-string v3, "CameraType"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_39c
    const-string v4, "CanTouch"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_3a6
    const-string v4, "CanQuery"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_3b0
    const-string v3, "PlaybackSpeed"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_3ba
    const-string v3, "HipHeight"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_3c4
    const-string v3, "SoundId"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_3ce
    const-string v4, "TextScaled"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_3d8
    const-string v3, "LayoutOrder"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_475

    goto/16 :goto_4ca

    :sswitch_3e2
    const-string v3, "WalkSpeed"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_3ec
    const-string v4, "Anchored"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_3f6
    const-string v3, "TextColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_400
    const-string v3, "ImageColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 432
    :cond_408
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_4d2

    .line 423
    :sswitch_40e
    const-string v3, "TextSize"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_418
    const-string v4, "ClipsDescendants"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_422
    const-string v3, "BackgroundTransparency"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_42c
    const-string v3, "TextStrokeTransparency"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_436
    const-string v3, "AnimationId"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_440
    const-string v4, "RichText"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_44a
    const-string v3, "ImageTransparency"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_454
    const-string v3, "AutomaticSize"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 431
    :cond_45c
    const/16 v3, 0x12

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_4d2

    .line 423
    :sswitch_464
    const-string v3, "JumpPower"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto :goto_4ca

    :sswitch_46d
    const-string v3, "ZIndex"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 429
    :cond_475
    const/4 v3, 0x3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_4d2

    .line 423
    :sswitch_47b
    const-string v3, "Brightness"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto :goto_4ca

    :sswitch_484
    const-string v3, "Volume"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto :goto_4ca

    :sswitch_48d
    const-string v4, "ResetOnSpawn"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto :goto_4ca

    :sswitch_496
    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto :goto_4ca

    :sswitch_49d
    const-string v4, "TextWrapped"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto :goto_4ca

    :sswitch_4a6
    const-string v3, "MeshId"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 430
    :cond_4ae
    move-object v3, v4

    goto :goto_4d2

    .line 423
    :sswitch_4b0
    const-string v4, "Looped"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto :goto_4ca

    :sswitch_4b9
    const-string v4, "Locked"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4ca

    .line 425
    :cond_4c1
    goto :goto_4d2

    .line 423
    :sswitch_4c2
    const-string v3, "Reflectance"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    :cond_4ca
    :goto_4ca
    goto :goto_4d0

    .line 428
    :cond_4cb
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_4d2

    .line 436
    :goto_4d0
    move-object/from16 v3, v16

    .line 423
    :goto_4d2
    return-object v3

    nop

    :sswitch_data_4d4
    .sparse-switch
        -0x71f00b36 -> :sswitch_37
        0x24eeab -> :sswitch_2e
        0x3482321 -> :sswitch_25
        0x7094d7fd -> :sswitch_1c
    .end sparse-switch

    :sswitch_data_4e6
    .sparse-switch
        -0x7cef5f03 -> :sswitch_bc
        -0x33b84c3e -> :sswitch_ad
        0x275421 -> :sswitch_a6
        0x173739e -> :sswitch_9f
        0x3e43f43 -> :sswitch_94
        0x9fe75f9 -> :sswitch_8b
        0xd9c9db0 -> :sswitch_82
        0x306cfd49 -> :sswitch_7b
        0x3f7ca6c8 -> :sswitch_72
        0x4f2c3bb4 -> :sswitch_69
        0x76646aea -> :sswitch_5c
    .end sparse-switch

    :sswitch_data_514
    .sparse-switch
        -0x7363af4d -> :sswitch_154
        -0x6beebaa1 -> :sswitch_145
        -0x6bc56088 -> :sswitch_13e
        0x275421 -> :sswitch_137
        0x3e43f43 -> :sswitch_12a
    .end sparse-switch

    :sswitch_data_52a
    .sparse-switch
        -0x792c6694 -> :sswitch_4c2
        -0x7804e0d6 -> :sswitch_4b9
        -0x77ff599d -> :sswitch_4b0
        -0x76d5bbf8 -> :sswitch_4a6
        -0x6f8d3d88 -> :sswitch_49d
        -0x6bc56088 -> :sswitch_496
        -0x69512f53 -> :sswitch_48d
        -0x66f02cc6 -> :sswitch_484
        -0x628bf78f -> :sswitch_47b
        -0x62339f68 -> :sswitch_46d
        -0x608ccea9 -> :sswitch_464
        -0x5a825754 -> :sswitch_454
        -0x5a28a7cd -> :sswitch_44a
        -0x58a047b7 -> :sswitch_440
        -0x58440461 -> :sswitch_436
        -0x57b8e223 -> :sswitch_42c
        -0x5330b43a -> :sswitch_422
        -0x47658bed -> :sswitch_418
        -0x37f86112 -> :sswitch_40e
        -0x3683b5b5 -> :sswitch_400
        -0x36638b23 -> :sswitch_3f6
        -0x3608a5cc -> :sswitch_3ec
        -0x33eeac22 -> :sswitch_3e2
        -0x259251dc -> :sswitch_3d8
        -0x1bc427f9 -> :sswitch_3ce
        -0x154c9d96 -> :sswitch_3c4
        -0xc0df68a -> :sswitch_3ba
        -0x7d3fd34 -> :sswitch_3b0
        -0x4739108 -> :sswitch_3a6
        -0x44bca91 -> :sswitch_39c
        -0x11c77e1 -> :sswitch_392
        -0x10232bb -> :sswitch_388
        0x21806f -> :sswitch_37e
        0x275421 -> :sswitch_365
        0x27b94d -> :sswitch_35b
        0xfda71c -> :sswitch_351
        0x173739e -> :sswitch_349
        0x3c788b3 -> :sswitch_33f
        0x437b93b -> :sswitch_335
        0x4952a7d -> :sswitch_314
        0x4952a7e -> :sswitch_30a
        0x4b1491d -> :sswitch_300
        0x4c25f81 -> :sswitch_2f6
        0x4d13238 -> :sswitch_2ec
        0x4e9a151 -> :sswitch_2e4
        0x688b3bb -> :sswitch_2d6
        0x7837784 -> :sswitch_2cc
        0xb0d5d65 -> :sswitch_2c2
        0xbf0f264 -> :sswitch_2b8
        0xeb66cfb -> :sswitch_2ae
        0x14009e9c -> :sswitch_2a4
        0x14bb72ad -> :sswitch_29a
        0x15adc947 -> :sswitch_290
        0x17b85297 -> :sswitch_286
        0x180b281e -> :sswitch_27c
        0x1f6b5668 -> :sswitch_272
        0x236ee178 -> :sswitch_268
        0x2ced0520 -> :sswitch_25e
        0x2e0b8a78 -> :sswitch_254
        0x2fb1bcf5 -> :sswitch_24a
        0x306cfd49 -> :sswitch_242
        0x35f41775 -> :sswitch_238
        0x383aa8b4 -> :sswitch_22e
        0x3acf2356 -> :sswitch_224
        0x3b641754 -> :sswitch_21a
        0x3fb70bdb -> :sswitch_210
        0x40b8f315 -> :sswitch_206
        0x4166a09c -> :sswitch_1fc
        0x416d18c0 -> :sswitch_1f2
        0x45cd680e -> :sswitch_1e8
        0x5bb7fa6e -> :sswitch_1de
        0x692ffbcc -> :sswitch_1d4
        0x6c9e3019 -> :sswitch_1ca
        0x6d773602 -> :sswitch_1c0
        0x712b0a96 -> :sswitch_1b6
        0x73a27627 -> :sswitch_1ac
        0x74946b26 -> :sswitch_1a2
        0x75d99430 -> :sswitch_198
        0x7d39e51c -> :sswitch_18e
        0x7dbf4f5d -> :sswitch_184
        0x7f0a8852 -> :sswitch_17a
    .end sparse-switch
.end method
