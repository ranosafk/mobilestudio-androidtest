.method public final humanoidCall(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 24
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    const-string v4, "inst"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "name"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "a"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 943
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v4

    .line 944
    .local v4, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v5

    const-string v6, " expected, got "

    const/16 v7, 0x8

    const-string v8, "Health"

    const-string v9, "NONE"

    const/4 v10, 0x1

    const-string v11, "arg(...)"

    const/4 v12, 0x2

    const/4 v13, 0x0

    sparse-switch v5, :sswitch_data_320

    goto/16 :goto_30e

    :sswitch_33
    const-string v5, "GetState"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 959
    if-eqz v4, :cond_41

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->isGrounded(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v10

    .line 960
    .local v10, "g":Z
    :cond_41
    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v6, "HumanoidStateType"

    new-instance v8, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v10, :cond_4f

    const-string v9, "Running"

    invoke-direct {v8, v6, v9, v7}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    goto :goto_55

    :cond_4f
    const-string v7, "Freefall"

    const/4 v9, 0x5

    invoke-direct {v8, v6, v7, v9}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    :goto_55
    invoke-virtual {v5, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    .end local v10    # "g":Z
    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_5d
    const-string v5, "GetAccessories"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 970
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    if-eqz v5, :cond_a0

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v5

    if-eqz v5, :cond_a0

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$filter\\11":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1099
    .local v6, "$i$f$filter\\11\\970":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\12":Ljava/util/Collection;
    move-object v8, v5

    .local v8, "$this$filterTo\\12":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1100
    .local v9, "$i$f$filterTo\\12\\1099":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_81
    :goto_81
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_9b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\12":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v12, "it\\13":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v13, 0x0

    .line 970
    .local v13, "$i$a$-filter-InstanceApi$humanoidCall$3\\13\\1100\\0":I
    const-string v14, "Accessory"

    invoke-virtual {v12, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v12

    .line 1100
    .end local v12    # "it\\13":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v13    # "$i$a$-filter-InstanceApi$humanoidCall$3\\13\\1100\\0":I
    if-eqz v12, :cond_81

    invoke-interface {v7, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_81

    .line 1101
    .end local v11    # "element\\12":Ljava/lang/Object;
    :cond_9b
    nop

    .end local v7    # "destination\\12":Ljava/util/Collection;
    .end local v8    # "$this$filterTo\\12":Ljava/lang/Iterable;
    .end local v9    # "$i$f$filterTo\\12\\1099":I
    check-cast v7, Ljava/util/List;

    .line 1099
    nop

    .line 970
    .end local v5    # "$this$filter\\11":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filter\\11\\970":I
    goto :goto_a4

    :cond_a0
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v7

    :goto_a4
    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v5

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_ac
    const-string v5, "GetPlayingAnimationTracks"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 963
    if-eqz v4, :cond_fd

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->playingTrackTables(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v5

    if-eqz v5, :cond_fd

    .line 1017
    .local v5, "l\\5":Ljava/util/List;
    const/4 v6, 0x0

    .line 963
    .local v6, "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    new-instance v7, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v7}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v8, v7

    .line 1017
    .local v8, "tb\\6":Lorg/luaj/vm2/LuaTable;
    const/4 v9, 0x0

    .line 963
    .local v9, "$i$a$-also-InstanceApi$humanoidCall$1$1\\6\\963\\5":I
    move-object v10, v5

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 1095
    .local v11, "$i$f$forEachIndexed\\7\\963":I
    const/4 v12, 0x0

    .line 1096
    .local v12, "index\\7":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_cd
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_f7

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "item\\7":Ljava/lang/Object;
    add-int/lit8 v15, v12, 0x1

    .end local v12    # "index\\7":I
    .local v15, "index\\7":I
    if-gez v12, :cond_de

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_de
    move-object/from16 v16, v14

    check-cast v16, Lorg/luaj/vm2/LuaTable;

    .local v12, "i\\8":I
    .local v16, "x\\8":Lorg/luaj/vm2/LuaTable;
    const/16 v17, 0x0

    .line 963
    .local v17, "$i$a$-forEachIndexed-InstanceApi$humanoidCall$1$1$1\\8\\1096\\6":I
    move-object/from16 v18, v5

    .end local v5    # "l\\5":Ljava/util/List;
    .local v18, "l\\5":Ljava/util/List;
    add-int/lit8 v5, v12, 0x1

    move/from16 v19, v6

    .end local v6    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    .local v19, "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    move-object/from16 v6, v16

    check-cast v6, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v8, v5, v6}, Lorg/luaj/vm2/LuaTable;->set(ILorg/luaj/vm2/LuaValue;)V

    .line 1096
    .end local v12    # "i\\8":I
    .end local v16    # "x\\8":Lorg/luaj/vm2/LuaTable;
    .end local v17    # "$i$a$-forEachIndexed-InstanceApi$humanoidCall$1$1$1\\8\\1096\\6":I
    move v12, v15

    move-object/from16 v5, v18

    move/from16 v6, v19

    .end local v14    # "item\\7":Ljava/lang/Object;
    goto :goto_cd

    .line 1097
    .end local v15    # "index\\7":I
    .end local v18    # "l\\5":Ljava/util/List;
    .end local v19    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    .restart local v5    # "l\\5":Ljava/util/List;
    .restart local v6    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    .local v12, "index\\7":I
    :cond_f7
    move-object/from16 v18, v5

    move/from16 v19, v6

    .line 963
    .end local v5    # "l\\5":Ljava/util/List;
    .end local v6    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    .end local v10    # "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    .end local v11    # "$i$f$forEachIndexed\\7\\963":I
    .end local v12    # "index\\7":I
    .restart local v18    # "l\\5":Ljava/util/List;
    .restart local v19    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    nop

    .end local v8    # "tb\\6":Lorg/luaj/vm2/LuaTable;
    .end local v9    # "$i$a$-also-InstanceApi$humanoidCall$1$1\\6\\963\\5":I
    .end local v18    # "l\\5":Ljava/util/List;
    .end local v19    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    goto :goto_102

    :cond_fd
    new-instance v7, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v7}, Lorg/luaj/vm2/LuaTable;-><init>()V

    :goto_102
    move-object v5, v7

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_107
    const-string v5, "UnequipTools"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 965
    if-eqz v4, :cond_114

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->unequip()V

    :cond_114
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_11d
    const-string v5, "TakeDamage"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 946
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    if-eqz v5, :cond_132

    const-string v6, "ForceField"

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    goto :goto_133

    :cond_132
    move-object v5, v13

    :goto_133
    if-nez v5, :cond_136

    const/4 v10, 0x0

    .line 947
    .local v10, "hasFF":Z
    :cond_136
    if-nez v10, :cond_15f

    invoke-virtual {v0, v1, v8}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->getK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Ljava/lang/Number;

    if-eqz v6, :cond_143

    move-object v13, v5

    check-cast v13, Ljava/lang/Number;

    :cond_143
    if-eqz v13, :cond_14a

    invoke-virtual {v13}, Ljava/lang/Number;->floatValue()F

    move-result v5

    goto :goto_14c

    :cond_14a
    const/high16 v5, 0x42c80000    # 100.0f

    :goto_14c
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v6

    sub-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-virtual {v0, v1, v8, v5}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .line 948
    :cond_15f
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 945
    .end local v10    # "hasFF":Z
    nop

    .line 947
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_169
    const-string v5, "SetStateEnabled"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 966
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_17a
    const-string v5, "Move"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 951
    if-eqz v4, :cond_1c8

    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Vector3"

    .local v5, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\2":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1092
    .local v8, "$i$f$ud\\2\\951":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_199

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_19a

    :cond_199
    move-object v9, v13

    :goto_19a
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v10, :cond_19f

    move-object v13, v9

    :cond_19f
    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v13, :cond_1a7

    .line 951
    .end local v5    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\2":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\2\\951":I
    invoke-virtual {v4, v1, v13}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->scriptMove(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    goto :goto_1c8

    .line 1092
    .restart local v5    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v7    # "what\\2":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\2\\951":I
    :cond_1a7
    new-instance v9, Lorg/luaj/vm2/LuaError;

    sget-object v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v10, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v9, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v9

    .line 951
    .end local v5    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\2":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\2\\951":I
    :cond_1c8
    :goto_1c8
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_1d1
    const-string v5, "ChangeState"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 953
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    .line 1093
    .local v6, "$i$f$udOrNull\\3\\953":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_1ec

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_1ed

    :cond_1ec
    move-object v9, v13

    :goto_1ed
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v10, :cond_1f2

    move-object v13, v9

    :cond_1f2
    check-cast v13, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 953
    .end local v5    # "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$udOrNull\\3\\953":I
    if-eqz v13, :cond_1fb

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v5

    goto :goto_203

    :cond_1fb
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v5

    .line 954
    .local v5, "st":I
    :goto_203
    const/4 v6, 0x3

    if-ne v5, v6, :cond_20b

    if-eqz v4, :cond_20b

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->jump(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 955
    :cond_20b
    const/16 v6, 0xf

    if-ne v5, v6, :cond_217

    const/4 v6, 0x0

    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v6

    invoke-virtual {v0, v1, v8, v6}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .line 956
    :cond_217
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 952
    .end local v5    # "st":I
    nop

    .line 954
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_221
    const-string v5, "GetStateEnabled"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 967
    sget-object v5, Lorg/luaj/vm2/LuaValue;->TRUE:Lorg/luaj/vm2/LuaBoolean;

    const-string v6, "TRUE"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_234
    const-string v5, "EquipTool"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 964
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\9":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    .line 1098
    .local v6, "$i$f$udOrNull\\9\\964":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_24f

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_250

    :cond_24f
    move-object v7, v13

    :goto_250
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v8, :cond_255

    move-object v13, v7

    :cond_255
    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 964
    .end local v5    # "$this$udOrNull\\9":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$udOrNull\\9\\964":I
    if-eqz v13, :cond_25f

    .line 1017
    .local v13, "it\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v5, 0x0

    .line 964
    .local v5, "$i$a$-let-InstanceApi$humanoidCall$2\\10\\964\\0":I
    if-eqz v4, :cond_25f

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->equip(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v5    # "$i$a$-let-InstanceApi$humanoidCall$2\\10\\964\\0":I
    .end local v13    # "it\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_25f
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_268
    const-string v5, "LoadAnimation"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 962
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    .line 1094
    .local v6, "$i$f$udOrNull\\4\\962":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_283

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_284

    :cond_283
    move-object v7, v13

    :goto_284
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v8, :cond_289

    move-object v13, v7

    :cond_289
    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 962
    .end local v5    # "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$udOrNull\\4\\962":I
    invoke-direct {v0, v1, v13}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaTable;

    move-result-object v5

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_293
    const-string v5, "ApplyDescription"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_30f

    goto/16 :goto_30e

    :sswitch_29d
    const-string v5, "GetAppliedDescription"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 969
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v6, "NIL"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_2b0
    const-string v5, "MoveTo"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 950
    if-eqz v4, :cond_2fe

    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Vector3"

    .local v5, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\1":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1091
    .local v8, "$i$f$ud\\1\\950":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_2cf

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_2d0

    :cond_2cf
    move-object v9, v13

    :goto_2d0
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v10, :cond_2d5

    move-object v13, v9

    :cond_2d5
    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v13, :cond_2dd

    .line 950
    .end local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\1":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\1\\950":I
    invoke-virtual {v4, v1, v13}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->moveTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    goto :goto_2fe

    .line 1091
    .restart local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v7    # "what\\1":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\1\\950":I
    :cond_2dd
    new-instance v9, Lorg/luaj/vm2/LuaError;

    sget-object v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v10, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v9, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v9

    .line 950
    .end local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\1":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\1\\950":I
    :cond_2fe
    :goto_2fe
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto :goto_31e

    .line 944
    :sswitch_306
    const-string v5, "AddAccessory"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_30f

    :cond_30e
    :goto_30e
    goto :goto_317

    .line 968
    :cond_30f
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto :goto_31e

    .line 971
    :goto_317
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    .line 944
    :goto_31e
    return-object v5

    nop

    :sswitch_data_320
    .sparse-switch
        -0x7c7d906f -> :sswitch_306
        -0x76477db4 -> :sswitch_2b0
        -0x661b92eb -> :sswitch_29d
        -0x5a12e432 -> :sswitch_293
        -0x499e36e2 -> :sswitch_268
        -0x48713238 -> :sswitch_234
        -0x30176c3a -> :sswitch_221
        0x2336a1 -> :sswitch_1d1
        0x24aff1 -> :sswitch_17a
        0x6318ed2 -> :sswitch_169
        0x198dc6f6 -> :sswitch_11d
        0x4bb9c704 -> :sswitch_107
        0x52eb29f4 -> :sswitch_ac
        0x6174b61a -> :sswitch_5d
        0x7902cefb -> :sswitch_33
    .end sparse-switch
.end method
