.method private final batchSpec(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;
    .registers 39
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ")",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/render/BatchSpec;",
            ">;"
        }
    .end annotation

    .line 252
    move-object/from16 v1, p1

    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->variantFor(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    const/4 v2, 0x0

    if-eqz v0, :cond_a

    return-object v2

    .line 253
    :cond_a
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->geometry(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;

    move-result-object v5

    .line 254
    .local v5, "g":Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->color(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v8

    .line 255
    .local v8, "color":Lcom/exampletest/mobilestudiotest/model/Color3;
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getKind()I

    move-result v0

    const-string v3, "MeshPart"

    const/4 v6, 0x1

    packed-switch v0, :pswitch_data_30e

    .line 288
    :pswitch_1e
    return-object v2

    .line 268
    :pswitch_1f
    const-string v0, "UsePartColor"

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    .line 269
    .local v9, "usePart":Z
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/SolidModeling;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->result(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;

    move-result-object v10

    .line 270
    .local v10, "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    if-eqz v10, :cond_dc

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;->getTris()Ljava/util/Map;

    move-result-object v0

    .local v0, "$this$filter\\4":Ljava/util/Map;
    const/4 v2, 0x0

    .line 2638
    .local v2, "$i$f$filter\\4\\270":I
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v3, Ljava/util/Map;

    .local v3, "destination\\5":Ljava/util/Map;
    move-object v7, v0

    .local v7, "$this$filterTo\\5":Ljava/util/Map;
    const/4 v11, 0x0

    .line 2639
    .local v11, "$i$f$filterTo\\5\\2638":I
    invoke-interface {v7}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v12

    invoke-interface {v12}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_4b
    :goto_4b
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_75

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/util/Map$Entry;

    .line 2640
    .local v13, "element\\5":Ljava/util/Map$Entry;
    move-object v14, v13

    .local v14, "it\\6":Ljava/util/Map$Entry;
    const/4 v15, 0x0

    .line 270
    .local v15, "$i$a$-filter-SceneRenderer$batchSpec$1\\6\\2640\\0":I
    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v4, v16

    check-cast v4, [F

    array-length v4, v4

    if-nez v4, :cond_66

    move v4, v6

    goto :goto_67

    :cond_66
    const/4 v4, 0x0

    .line 2640
    .end local v14    # "it\\6":Ljava/util/Map$Entry;
    .end local v15    # "$i$a$-filter-SceneRenderer$batchSpec$1\\6\\2640\\0":I
    :goto_67
    if-nez v4, :cond_4b

    .line 2641
    invoke-interface {v13}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    invoke-interface {v13}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v14

    invoke-interface {v3, v4, v14}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4b

    .line 2644
    .end local v13    # "element\\5":Ljava/util/Map$Entry;
    :cond_75
    nop

    .line 2638
    .end local v3    # "destination\\5":Ljava/util/Map;
    .end local v7    # "$this$filterTo\\5":Ljava/util/Map;
    .end local v11    # "$i$f$filterTo\\5\\2638":I
    nop

    .line 270
    .end local v0    # "$this$filter\\4":Ljava/util/Map;
    .end local v2    # "$i$f$filter\\4\\270":I
    move-object v11, v3

    .local v11, "$this$map\\7":Ljava/util/Map;
    const/4 v12, 0x0

    .line 2645
    .local v12, "$i$f$map\\7\\270":I
    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {v11}, Ljava/util/Map;->size()I

    move-result v2

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v0, Ljava/util/Collection;

    .local v0, "destination\\8":Ljava/util/Collection;
    move-object v13, v11

    .local v13, "$this$mapTo\\8":Ljava/util/Map;
    move-object v14, v0

    .end local v0    # "destination\\8":Ljava/util/Collection;
    .local v14, "destination\\8":Ljava/util/Collection;
    const/4 v15, 0x0

    .line 2646
    .local v15, "$i$f$mapTo\\8\\2645":I
    invoke-interface {v13}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_8f
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_d6

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Ljava/util/Map$Entry;

    .line 2647
    .local v17, "item\\8":Ljava/util/Map$Entry;
    const/16 v18, 0x0

    .local v18, "$i$a$-map-SceneRenderer$batchSpec$2\\9\\2647\\0":I
    invoke-interface/range {v17 .. v17}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .local v0, "style\\9":I
    invoke-interface/range {v17 .. v17}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [F

    .line 271
    .local v2, "arr\\9":[F
    if-nez v9, :cond_c5

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;->getStyles()Ljava/util/List;

    move-result-object v3

    invoke-static {v3, v0}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/core/SolidModeling$Style;

    if-eqz v3, :cond_c5

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/SolidModeling$Style;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v3

    if-eqz v3, :cond_c5

    move-object v6, v3

    goto :goto_c6

    :cond_c5
    move-object v6, v8

    :goto_c6
    const/4 v7, 0x0

    const/16 v3, 0x8

    const/4 v4, 0x0

    move/from16 v19, v0

    move-object/from16 v0, p0

    .end local v0    # "style\\9":I
    .local v19, "style\\9":I
    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->spec(Lcom/exampletest/mobilestudiotest/model/Instance;[FIZLcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;Lcom/exampletest/mobilestudiotest/model/Color3;Z)Lcom/exampletest/mobilestudiotest/render/BatchSpec;

    move-result-object v2

    .line 2647
    .end local v2    # "arr\\9":[F
    .end local v18    # "$i$a$-map-SceneRenderer$batchSpec$2\\9\\2647\\0":I
    .end local v19    # "style\\9":I
    invoke-interface {v14, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_8f

    .line 2648
    .end local v17    # "item\\8":Ljava/util/Map$Entry;
    :cond_d6
    nop

    .end local v13    # "$this$mapTo\\8":Ljava/util/Map;
    .end local v14    # "destination\\8":Ljava/util/Collection;
    .end local v15    # "$i$f$mapTo\\8\\2645":I
    move-object v0, v14

    check-cast v0, Ljava/util/List;

    .line 2645
    nop

    .line 270
    .end local v11    # "$this$map\\7":Ljava/util/Map;
    .end local v12    # "$i$f$map\\7\\270":I
    return-object v0

    .line 273
    :cond_dc
    sget-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->get(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;

    move-result-object v0

    if-nez v0, :cond_e5

    return-object v2

    :cond_e5
    move-object v11, v0

    .line 274
    .local v11, "d":Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->getGroups()Ljava/util/List;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Ljava/lang/Iterable;

    .local v12, "$this$map\\10":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 2649
    .local v13, "$i$f$map\\10\\274":I
    new-instance v0, Ljava/util/ArrayList;

    const/16 v2, 0xa

    invoke-static {v12, v2}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v0, Ljava/util/Collection;

    .local v0, "destination\\11":Ljava/util/Collection;
    move-object v14, v12

    .local v14, "$this$mapTo\\11":Ljava/lang/Iterable;
    move-object v15, v0

    .end local v0    # "destination\\11":Ljava/util/Collection;
    .local v15, "destination\\11":Ljava/util/Collection;
    const/16 v16, 0x0

    .line 2650
    .local v16, "$i$f$mapTo\\11\\2649":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_103
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_149

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    .line 2651
    .local v18, "item\\11":Ljava/lang/Object;
    move-object/from16 v0, v18

    check-cast v0, Lkotlin/Pair;

    const/16 v19, 0x0

    .local v19, "$i$a$-map-SceneRenderer$batchSpec$3\\12\\2651\\0":I
    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    .local v2, "argb\\12":I
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [F

    .line 274
    .local v0, "arr\\12":[F
    if-eqz v9, :cond_127

    move-object v6, v8

    goto :goto_138

    :cond_127
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    shr-int/lit8 v4, v2, 0x10

    and-int/lit16 v4, v4, 0xff

    shr-int/lit8 v6, v2, 0x8

    and-int/lit16 v6, v6, 0xff

    and-int/lit16 v7, v2, 0xff

    invoke-virtual {v3, v4, v6, v7}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v3

    move-object v6, v3

    :goto_138
    const/4 v7, 0x0

    const/16 v3, 0x8

    const/4 v4, 0x0

    move/from16 v20, v2

    move-object v2, v0

    move-object/from16 v0, p0

    .end local v0    # "arr\\12":[F
    .local v2, "arr\\12":[F
    .local v20, "argb\\12":I
    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->spec(Lcom/exampletest/mobilestudiotest/model/Instance;[FIZLcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;Lcom/exampletest/mobilestudiotest/model/Color3;Z)Lcom/exampletest/mobilestudiotest/render/BatchSpec;

    move-result-object v2

    .line 2651
    .end local v2    # "arr\\12":[F
    .end local v19    # "$i$a$-map-SceneRenderer$batchSpec$3\\12\\2651\\0":I
    .end local v20    # "argb\\12":I
    invoke-interface {v15, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_103

    .line 2652
    .end local v18    # "item\\11":Ljava/lang/Object;
    :cond_149
    move-object/from16 v0, p0

    .end local v14    # "$this$mapTo\\11":Ljava/lang/Iterable;
    .end local v15    # "destination\\11":Ljava/util/Collection;
    .end local v16    # "$i$f$mapTo\\11\\2649":I
    move-object v2, v15

    check-cast v2, Ljava/util/List;

    .line 2649
    nop

    .line 274
    .end local v12    # "$this$map\\10":Ljava/lang/Iterable;
    .end local v13    # "$i$f$map\\10\\274":I
    return-object v2

    .line 258
    .end local v9    # "usePart":Z
    .end local v10    # "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    .end local v11    # "d":Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    :pswitch_150
    move-object/from16 v0, p0

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getTint()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    if-eqz v4, :cond_18e

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getTint()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    const/high16 v7, 0x3f800000    # 1.0f

    cmpg-float v4, v4, v7

    if-nez v4, :cond_168

    move v4, v6

    goto :goto_169

    :cond_168
    const/4 v4, 0x0

    :goto_169
    if-eqz v4, :cond_18d

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getTint()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    cmpg-float v4, v4, v7

    if-nez v4, :cond_179

    move v4, v6

    goto :goto_17a

    :cond_179
    const/4 v4, 0x0

    :goto_17a
    if-eqz v4, :cond_18d

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getTint()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    cmpg-float v4, v4, v7

    if-nez v4, :cond_18a

    move v4, v6

    goto :goto_18b

    :cond_18a
    const/4 v4, 0x0

    :goto_18b
    if-nez v4, :cond_18e

    :cond_18d
    return-object v2

    .line 259
    :cond_18e
    sget-object v4, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1a1

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->meshContent(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;

    move-result-object v3

    goto :goto_1e5

    :cond_1a1
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 2636
    .local v7, "$i$f$firstOrNull\\1\\259":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_1ac
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_1d8

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\1":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v11, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v12, 0x0

    .line 259
    .local v12, "$i$a$-firstOrNull-SceneRenderer$batchSpec$id$1\\2\\2636\\0":I
    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v13

    const-string v14, "SpecialMesh"

    invoke-static {v13, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_1d4

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v13

    const-string v14, "FileMesh"

    invoke-static {v13, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_1d4

    const/4 v11, 0x0

    goto :goto_1d5

    :cond_1d4
    move v11, v6

    .line 2636
    .end local v11    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v12    # "$i$a$-firstOrNull-SceneRenderer$batchSpec$id$1\\2\\2636\\0":I
    :goto_1d5
    if-eqz v11, :cond_1ac

    goto :goto_1d9

    .line 2637
    .end local v10    # "element\\1":Ljava/lang/Object;
    :cond_1d8
    move-object v10, v2

    .line 259
    .end local v3    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v7    # "$i$f$firstOrNull\\1\\259":I
    :goto_1d9
    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v10, :cond_1e4

    const-string v3, "MeshId"

    invoke-virtual {v10, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    goto :goto_1e5

    :cond_1e4
    move-object v3, v2

    :goto_1e5
    invoke-virtual {v4, v3}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->idOf(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object v3

    if-eqz v3, :cond_261

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    .line 260
    .local v3, "id":J
    sget-object v7, Lcom/exampletest/mobilestudiotest/render/MeshLoader;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/MeshLoader;

    invoke-virtual {v7, v3, v4}, Lcom/exampletest/mobilestudiotest/render/MeshLoader;->get(J)Lcom/exampletest/mobilestudiotest/render/MeshData;

    move-result-object v7

    if-nez v7, :cond_1f8

    return-object v2

    .line 261
    .local v7, "data":Lcom/exampletest/mobilestudiotest/render/MeshData;
    :cond_1f8
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getTex()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_204

    .line 2635
    .local v2, "it\\3":Ljava/lang/String;
    const/4 v9, 0x0

    .line 261
    .local v9, "$i$a$-let-SceneRenderer$batchSpec$tex$1\\3\\261\\0":I
    invoke-direct {v0, v2, v6}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->assetTexture(Ljava/lang/String;Z)I

    move-result v2

    .end local v2    # "it\\3":Ljava/lang/String;
    .end local v9    # "$i$a$-let-SceneRenderer$batchSpec$tex$1\\3\\261\\0":I
    goto :goto_205

    :cond_204
    const/4 v2, 0x0

    .line 262
    .local v2, "tex":I
    :goto_205
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getTex()Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_20f

    if-nez v2, :cond_20f

    move v9, v6

    goto :goto_210

    :cond_20f
    const/4 v9, 0x0

    :goto_210
    move/from16 v32, v9

    .line 263
    .local v32, "pending":Z
    new-instance v18, Lcom/exampletest/mobilestudiotest/render/BatchSpec;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/render/MeshData;->getVerts()[F

    move-result-object v19

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v21

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getScale()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v22

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Color3;->getR()F

    move-result v23

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Color3;->getG()F

    move-result v24

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Color3;->getB()F

    move-result v25

    sget-object v9, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v9, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->material(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v9

    const/16 v10, 0x120

    if-ne v9, v10, :cond_239

    move/from16 v26, v6

    goto :goto_23b

    :cond_239
    const/16 v26, 0x0

    :goto_23b
    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->FLOAT4_ZERO:[F

    .line 264
    new-instance v9, Lcom/exampletest/mobilestudiotest/render/TexBind;

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct {v9, v2, v11, v10}, Lcom/exampletest/mobilestudiotest/render/TexBind;-><init>(IIF)V

    .line 263
    const v35, 0x8000

    const/16 v36, 0x0

    const/16 v20, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x3

    const/16 v33, 0x8

    const/16 v34, 0x0

    move-object/from16 v27, v6

    move-object/from16 v31, v9

    invoke-direct/range {v18 .. v36}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;-><init>([FZLcom/exampletest/mobilestudiotest/model/CFrame;Lcom/exampletest/mobilestudiotest/model/Vector3;FFFZ[FLcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;ILcom/exampletest/mobilestudiotest/render/TexBind;ZILcom/exampletest/mobilestudiotest/model/Vector3;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-static/range {v18 .. v18}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    return-object v6

    .line 259
    .end local v2    # "tex":I
    .end local v3    # "id":J
    .end local v7    # "data":Lcom/exampletest/mobilestudiotest/render/MeshData;
    .end local v32    # "pending":Z
    :cond_261
    return-object v2

    .line 277
    :pswitch_262
    const/4 v11, 0x0

    move-object/from16 v0, p0

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;->getMesh()Lcom/exampletest/mobilestudiotest/render/Mesh;

    move-result-object v9

    .line 278
    .local v9, "m":Lcom/exampletest/mobilestudiotest/render/Mesh;
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->cube:Lcom/exampletest/mobilestudiotest/render/Mesh;

    const-string v7, "cube"

    if-nez v4, :cond_273

    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v4, v2

    :cond_273
    if-eq v9, v4, :cond_2a6

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->wedge:Lcom/exampletest/mobilestudiotest/render/Mesh;

    if-nez v4, :cond_27f

    const-string v4, "wedge"

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v4, v2

    :cond_27f
    if-eq v9, v4, :cond_2a6

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->corner:Lcom/exampletest/mobilestudiotest/render/Mesh;

    if-nez v4, :cond_28b

    const-string v4, "corner"

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v4, v2

    :cond_28b
    if-eq v9, v4, :cond_2a6

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->cylinder:Lcom/exampletest/mobilestudiotest/render/Mesh;

    if-nez v4, :cond_297

    const-string v4, "cylinder"

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v4, v2

    :cond_297
    if-eq v9, v4, :cond_2a6

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->cylinderY:Lcom/exampletest/mobilestudiotest/render/Mesh;

    if-nez v4, :cond_2a3

    const-string v4, "cylinderY"

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v4, v2

    :cond_2a3
    if-eq v9, v4, :cond_2a6

    return-object v2

    .line 279
    :cond_2a6
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/Mesh;->getCpu()[F

    move-result-object v4

    if-nez v4, :cond_2ad

    return-object v2

    .line 281
    .local v4, "data":[F
    :cond_2ad
    nop

    .line 282
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    const-string v12, "PartOperation"

    if-eqz v10, :cond_2d9

    sget-object v10, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    sget-object v13, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v13, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->meshContent(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v13}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->idOf(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object v10

    if-eqz v10, :cond_2d7

    check-cast v10, Ljava/lang/Number;

    invoke-virtual {v10}, Ljava/lang/Number;->longValue()J

    move-result-wide v13

    .line 2635
    .local v13, "it\\13":J
    const/4 v10, 0x0

    .line 282
    .local v10, "$i$a$-let-SceneRenderer$batchSpec$loading$1\\13\\282\\0":I
    sget-object v15, Lcom/exampletest/mobilestudiotest/render/MeshLoader;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/MeshLoader;

    invoke-virtual {v15, v13, v14}, Lcom/exampletest/mobilestudiotest/render/MeshLoader;->isBad(J)Z

    move-result v15

    .end local v10    # "$i$a$-let-SceneRenderer$batchSpec$loading$1\\13\\282\\0":I
    .end local v13    # "it\\13":J
    xor-int/2addr v15, v6

    goto :goto_2e2

    :cond_2d7
    move v15, v11

    goto :goto_2e2

    .line 283
    :cond_2d9
    invoke-virtual {v1, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_2e1

    move v15, v6

    goto :goto_2e2

    .line 284
    :cond_2e1
    move v15, v11

    .line 281
    :goto_2e2
    nop

    .line 286
    .local v15, "loading":Z
    iget-object v10, v0, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->cube:Lcom/exampletest/mobilestudiotest/render/Mesh;

    if-nez v10, :cond_2eb

    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_2ec

    :cond_2eb
    move-object v2, v10

    :goto_2ec
    if-ne v9, v2, :cond_2ff

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2ff

    invoke-virtual {v1, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_2ff

    goto :goto_300

    :cond_2ff
    move v6, v11

    :goto_300
    const/4 v3, 0x6

    move-object v2, v4

    move v4, v6

    move-object v6, v8

    move v7, v15

    .end local v4    # "data":[F
    .end local v8    # "color":Lcom/exampletest/mobilestudiotest/model/Color3;
    .end local v15    # "loading":Z
    .local v2, "data":[F
    .local v6, "color":Lcom/exampletest/mobilestudiotest/model/Color3;
    .local v7, "loading":Z
    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->spec(Lcom/exampletest/mobilestudiotest/model/Instance;[FIZLcom/exampletest/mobilestudiotest/render/SceneRenderer$Geo;Lcom/exampletest/mobilestudiotest/model/Color3;Z)Lcom/exampletest/mobilestudiotest/render/BatchSpec;

    move-result-object v3

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0

    :pswitch_data_30e
    .packed-switch 0x0
        :pswitch_262
        :pswitch_1e
        :pswitch_150
        :pswitch_1f
    .end packed-switch
.end method
