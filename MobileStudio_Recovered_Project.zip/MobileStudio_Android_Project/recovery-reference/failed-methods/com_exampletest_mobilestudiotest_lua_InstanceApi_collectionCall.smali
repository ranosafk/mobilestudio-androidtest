.method public final collectionCall(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 16
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 779
    const/4 v0, 0x2

    invoke-virtual {p2, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    .line 780
    .local v1, "a2":Lorg/luaj/vm2/LuaValue;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, 0x0

    const-string v4, "CollectionService"

    const/4 v5, 0x1

    const/4 v6, 0x0

    sparse-switch v2, :sswitch_data_1ac

    goto/16 :goto_15f

    :sswitch_1d
    const-string v0, "GetAllTags"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15f

    .line 788
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .local v0, "s":Ljava/util/LinkedHashSet;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v2, v6, v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$forEach\\5":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1055
    .local v4, "$i$f$forEach\\5\\788":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3d
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_56

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\5":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 788
    .local v8, "$i$a$-forEach-InstanceApi$collectionCall$2\\6\\1055\\0":I
    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v9

    check-cast v9, Ljava/util/Collection;

    invoke-virtual {v0, v9}, Ljava/util/LinkedHashSet;->addAll(Ljava/util/Collection;)Z

    .line 1055
    .end local v7    # "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-forEach-InstanceApi$collectionCall$2\\6\\1055\\0":I
    nop

    .end local v6    # "element\\5":Ljava/lang/Object;
    goto :goto_3d

    .line 1056
    :cond_56
    nop

    .line 788
    .end local v2    # "$this$forEach\\5":Ljava/lang/Iterable;
    .end local v4    # "$i$f$forEach\\5\\788":I
    new-instance v2, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v2}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v4, v2

    .line 1017
    .local v4, "t\\7":Lorg/luaj/vm2/LuaTable;
    const/4 v5, 0x0

    .line 788
    .local v5, "$i$a$-also-InstanceApi$collectionCall$3\\7\\788\\0":I
    move-object v6, v0

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$forEach\\8":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1055
    .local v7, "$i$f$forEach\\8\\788":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_66
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_7f

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\8":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Ljava/lang/String;

    .local v10, "it\\9":Ljava/lang/String;
    const/4 v11, 0x0

    .line 788
    .local v11, "$i$a$-forEach-InstanceApi$collectionCall$3$1\\9\\1055\\7":I
    invoke-static {v10}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v12

    check-cast v12, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v4, v3, v12}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 1055
    .end local v10    # "it\\9":Ljava/lang/String;
    .end local v11    # "$i$a$-forEach-InstanceApi$collectionCall$3$1\\9\\1055\\7":I
    nop

    .end local v9    # "element\\8":Ljava/lang/Object;
    goto :goto_66

    .line 1056
    :cond_7f
    nop

    .line 788
    .end local v6    # "$this$forEach\\8":Ljava/lang/Iterable;
    .end local v7    # "$i$f$forEach\\8\\788":I
    nop

    .end local v0    # "s":Ljava/util/LinkedHashSet;
    .end local v4    # "t\\7":Lorg/luaj/vm2/LuaTable;
    .end local v5    # "$i$a$-also-InstanceApi$collectionCall$3\\7\\788\\0":I
    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1ab

    .line 780
    :sswitch_85
    const-string v2, "AddTag"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_160

    goto/16 :goto_15f

    :sswitch_8f
    const-string v2, "GetTags"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_160

    goto/16 :goto_15f

    :sswitch_99
    const-string v0, "GetInstanceRemovedSignal"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15f

    .line 787
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "TagRemoved:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v0, v2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1ab

    .line 780
    :sswitch_cb
    const-string v2, "RemoveTag"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_160

    goto/16 :goto_15f

    :sswitch_d5
    const-string v0, "GetTagged"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15f

    .line 781
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v6, v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1051
    .local v2, "$i$f$filter\\1\\781":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v4, v0

    .local v4, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1052
    .local v5, "$i$f$filterTo\\2\\1051":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_f9
    :goto_f9
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_119

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\2":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 781
    .local v9, "$i$a$-filter-InstanceApi$collectionCall$1\\3\\1052\\0":I
    invoke-direct {p0, v8}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v10

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v10, v11}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    .line 1052
    .end local v8    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-filter-InstanceApi$collectionCall$1\\3\\1052\\0":I
    if-eqz v8, :cond_f9

    invoke-interface {v3, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_f9

    .line 1053
    .end local v7    # "element\\2":Ljava/lang/Object;
    :cond_119
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v4    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filterTo\\2\\1051":I
    check-cast v3, Ljava/util/List;

    .line 1051
    nop

    .line 781
    .end local v0    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\1\\781":I
    invoke-direct {p0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1ab

    .line 780
    :sswitch_126
    const-string v0, "GetInstanceAddedSignal"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15f

    .line 786
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "TagAdded:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v0, v2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto :goto_1ab

    .line 780
    :sswitch_157
    const-string v2, "HasTag"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_160

    :cond_15f
    :goto_15f
    goto :goto_1a1

    .line 783
    :cond_160
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v2, v1

    .local v2, "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v4, 0x0

    .line 1054
    .local v4, "$i$f$udOrNull\\4\\783":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_170

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_171

    :cond_170
    move-object v7, v6

    :goto_171
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v8, :cond_176

    move-object v6, v7

    :cond_176
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 783
    .end local v2    # "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "$i$f$udOrNull\\4\\783":I
    if-eqz v6, :cond_199

    .line 784
    .local v6, "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    new-array v0, v0, [Lorg/luaj/vm2/LuaValue;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    aput-object v2, v0, v3

    const/4 v2, 0x3

    invoke-virtual {p2, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    aput-object v2, v0, v5

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    const-string v2, "varargsOf(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->callMethod(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v2

    .end local v6    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_1ab

    .line 783
    :cond_199
    new-instance v0, Lorg/luaj/vm2/LuaError;

    const-string v2, "Instance expected"

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 789
    :goto_1a1
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v2, "NONE"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    .line 780
    :goto_1ab
    return-object v2

    :sswitch_data_1ac
    .sparse-switch
        -0x7f969d40 -> :sswitch_157
        -0x76802723 -> :sswitch_126
        -0x57fd4bbe -> :sswitch_d5
        -0x3c1e8faa -> :sswitch_cb
        0x5dfc16fd -> :sswitch_99
        0x5ebe346f -> :sswitch_8f
        0x749aeb59 -> :sswitch_85
        0x7e408144 -> :sswitch_1d
    .end sparse-switch
.end method
