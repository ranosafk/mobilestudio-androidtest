.method static final _init_$lambda$17(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 89
    .local v0, "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_190

    goto/16 :goto_182

    :sswitch_16
    const-string v1, "FuzzyEq"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 103
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda152;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda152;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_2b
    const-string v1, "Floor"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 97
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda156;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda156;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_40
    const-string v1, "Cross"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 94
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda153;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda153;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_55
    const-string v1, "Angle"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 102
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda161;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda161;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_6a
    const-string v1, "unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_86

    goto/16 :goto_182

    :sswitch_74
    const-string v1, "lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_af

    goto/16 :goto_182

    :sswitch_7e
    const-string v1, "Unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 92
    :cond_86
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_92
    const-string v1, "Sign"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 99
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda158;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda158;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_a7
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 95
    :cond_af
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda154;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda154;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_bc
    const-string v1, "Ceil"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 98
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda157;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda157;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_d1
    const-string v1, "Min"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 100
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda159;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda159;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_e6
    const-string v1, "Max"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 101
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda160;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda160;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_fb
    const-string v1, "Dot"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 93
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda151;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda151;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_110
    const-string v1, "Abs"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 96
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda155;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda155;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_125
    const-string v1, "z"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_148

    goto :goto_182

    :sswitch_12e
    const-string v1, "y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_157

    goto :goto_182

    :sswitch_137
    const-string v1, "x"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_166

    goto :goto_182

    :sswitch_140
    const-string v1, "Z"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 90
    :cond_148
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v2

    goto :goto_16c

    .line 89
    :sswitch_14f
    const-string v1, "Y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 90
    :cond_157
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v2

    goto :goto_16c

    .line 89
    :sswitch_15e
    const-string v1, "X"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 90
    :cond_166
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    :goto_16c
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_18f

    .line 89
    :sswitch_171
    const-string v1, "Magnitude"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_183

    goto :goto_182

    :sswitch_17a
    const-string v1, "magnitude"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_183

    :cond_182
    :goto_182
    goto :goto_18e

    .line 91
    :cond_183
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_18f

    .line 104
    :goto_18e
    const/4 v1, 0x0

    .line 105
    :goto_18f
    return-object v1

    :sswitch_data_190
    .sparse-switch
        -0x7835adf0 -> :sswitch_17a
        -0xc38e10 -> :sswitch_171
        0x58 -> :sswitch_15e
        0x59 -> :sswitch_14f
        0x5a -> :sswitch_140
        0x78 -> :sswitch_137
        0x79 -> :sswitch_12e
        0x7a -> :sswitch_125
        0x10052 -> :sswitch_110
        0x10d29 -> :sswitch_fb
        0x12d44 -> :sswitch_e6
        0x12e32 -> :sswitch_d1
        0x1ffd25 -> :sswitch_bc
        0x241597 -> :sswitch_a7
        0x2751dd -> :sswitch_92
        0x284da4 -> :sswitch_7e
        0x32a177 -> :sswitch_74
        0x36d984 -> :sswitch_6a
        0x3c788b3 -> :sswitch_55
        0x3e5a820 -> :sswitch_40
        0x40d33ec -> :sswitch_2b
        0x458bac36 -> :sswitch_16
    .end sparse-switch
.end method
