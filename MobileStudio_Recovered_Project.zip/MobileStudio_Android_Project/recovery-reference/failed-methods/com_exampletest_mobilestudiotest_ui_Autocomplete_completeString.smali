.method private final completeString(Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;II)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;
    .registers 33
    .param p1, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;
    .param p2, "script"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p3, "text"    # Ljava/lang/String;
    .param p4, "cursor"    # I
    .param p5, "quoteAt"    # I

    .line 527
    move-object/from16 v1, p0

    move-object/from16 v6, p3

    move/from16 v9, p4

    add-int/lit8 v0, p5, 0x1

    invoke-virtual {v6, v0, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const-string v2, "substring(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v10, v0

    .line 528
    .local v10, "prefix":Ljava/lang/String;
    move-object v0, v10

    check-cast v0, Ljava/lang/CharSequence;

    const/16 v2, 0xa

    const/4 v11, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-static {v0, v2, v11, v12, v13}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    return-object v13

    .line 529
    :cond_21
    const/4 v0, 0x0

    .local v0, "i":I
    add-int/lit8 v0, p5, -0x1

    .line 530
    :goto_24
    const/16 v2, 0x20

    if-ltz v0, :cond_31

    invoke-virtual {v6, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    if-ne v3, v2, :cond_31

    add-int/lit8 v0, v0, -0x1

    goto :goto_24

    .line 531
    :cond_31
    if-ltz v0, :cond_45b

    invoke-virtual {v6, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x28

    if-eq v3, v4, :cond_3f

    move-object/from16 v19, v13

    goto/16 :goto_45d

    .line 535
    :cond_3f
    add-int/lit8 v0, v0, -0x1

    .line 536
    :goto_41
    if-ltz v0, :cond_4c

    invoke-virtual {v6, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    if-ne v3, v2, :cond_4c

    add-int/lit8 v0, v0, -0x1

    goto :goto_41

    .line 537
    :cond_4c
    add-int/lit8 v14, v0, 0x1

    move v7, v0

    .line 538
    .end local v0    # "i":I
    .local v7, "i":I
    .local v14, "e":I
    :goto_4f
    if-ltz v7, :cond_5e

    invoke-virtual {v6, v7}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-direct {v1, v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->isId(C)Z

    move-result v0

    if-eqz v0, :cond_5e

    add-int/lit8 v7, v7, -0x1

    goto :goto_4f

    .line 539
    :cond_5e
    add-int/lit8 v0, v7, 0x1

    invoke-virtual {v6, v0, v14}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const-string v3, "substring(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v15, v0

    .line 540
    .local v15, "fn":Ljava/lang/String;
    if-ltz v7, :cond_70

    invoke-virtual {v6, v7}, Ljava/lang/String;->charAt(I)C

    move-result v2

    .line 541
    .local v2, "acc":C
    :cond_70
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v3, v0

    .line 542
    .local v3, "items":Ljava/util/ArrayList;
    invoke-virtual {v15}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v4, 0x5

    const/16 v5, 0x3a

    const/16 v16, 0x3

    const/16 v17, 0x4

    const/4 v8, 0x1

    sparse-switch v0, :sswitch_data_45e

    move v13, v2

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .local v12, "items":Ljava/util/ArrayList;
    .local v13, "acc":C
    goto/16 :goto_458

    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .restart local v2    # "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_89
    const-string v0, "FindFirstChild"

    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a3

    goto :goto_f5

    :sswitch_92
    const-string v0, "SetAttribute"

    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f9

    goto :goto_f5

    :sswitch_9b
    const-string v0, "FindFirstDescendant"

    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f5

    :cond_a3
    move v13, v2

    move v0, v12

    move-object v12, v3

    goto/16 :goto_2c2

    :sswitch_a8
    const-string v0, "GetService"

    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b9

    goto :goto_f5

    :sswitch_b1
    const-string v0, "FindService"

    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f5

    .line 543
    :cond_b9
    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->getServiceList()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\1":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 659
    .local v4, "$i$f$forEach\\1\\543":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_c4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_e9

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\1":Ljava/lang/Object;
    move-object/from16 v17, v8

    check-cast v17, Ljava/lang/String;

    .local v17, "it\\2":Ljava/lang/String;
    const/4 v11, 0x0

    .line 543
    .local v11, "$i$a$-forEach-Autocomplete$completeString$1\\2\\659\\0":I
    new-instance v16, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    sget-object v18, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->SERVICE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    const-string v19, "service"

    const/16 v21, 0x8

    const/16 v22, 0x0

    const/16 v20, 0x0

    invoke-direct/range {v16 .. v22}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v12, v16

    invoke-virtual {v3, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 659
    .end local v11    # "$i$a$-forEach-Autocomplete$completeString$1\\2\\659\\0":I
    .end local v17    # "it\\2":Ljava/lang/String;
    nop

    .end local v8    # "element\\1":Ljava/lang/Object;
    goto :goto_c4

    .line 660
    :cond_e9
    move v13, v2

    move-object v12, v3

    .end local v0    # "$this$forEach\\1":Ljava/lang/Iterable;
    .end local v4    # "$i$f$forEach\\1\\543":I
    goto/16 :goto_43b

    .line 542
    :sswitch_ed
    const-string v0, "GetAttribute"

    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f9

    :cond_f5
    :goto_f5
    move v13, v2

    move-object v12, v3

    goto/16 :goto_458

    .line 568
    :cond_f9
    if-eq v2, v5, :cond_fc

    return-object v13

    .line 569
    :cond_fc
    invoke-direct {v1, v6, v7}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->chainBefore(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v0

    if-nez v0, :cond_103

    return-object v13

    :cond_103
    move-object v4, v0

    .line 570
    .local v4, "steps":Ljava/util/List;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v11

    monitor-enter v11

    .line 583
    const/4 v0, 0x0

    .line 570
    .local v0, "$i$a$-synchronized-Autocomplete$completeString$t$2\\15\\570\\0":I
    move v5, v2

    .end local v2    # "acc":C
    .local v5, "acc":C
    :try_start_10b
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete;
    :try_end_10d
    .catchall {:try_start_10b .. :try_end_10d} :catchall_17b

    const/4 v8, 0x0

    move-object v12, v3

    move-object v3, v4

    move/from16 v16, v5

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    .end local v4    # "steps":Ljava/util/List;
    .end local v5    # "acc":C
    .local v3, "steps":Ljava/util/List;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .local v16, "acc":C
    :try_start_116
    invoke-direct/range {v2 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->resolveSteps(Ljava/util/List;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;II)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    move-result-object v2
    :try_end_11a
    .catchall {:try_start_116 .. :try_end_11a} :catchall_179

    .end local v0    # "$i$a$-synchronized-Autocomplete$completeString$t$2\\15\\570\\0":I
    monitor-exit v11

    .line 571
    .local v2, "t":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    instance-of v0, v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    if-eqz v0, :cond_175

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v4

    monitor-enter v4

    .line 583
    const/4 v0, 0x0

    .line 571
    .local v0, "$i$a$-synchronized-Autocomplete$completeString$5\\16\\571\\0":I
    :try_start_125
    move-object v5, v2

    check-cast v5, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;->getI()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v5

    const-string v8, "<get-keys>(...)"

    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$forEach\\17":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 671
    .local v8, "$i$f$forEach\\17\\571":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_140
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_16c

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    .local v17, "element\\17":Ljava/lang/Object;
    move-object/from16 v18, v17

    check-cast v18, Ljava/lang/String;

    move-object/from16 v20, v18

    .local v20, "it\\18":Ljava/lang/String;
    const/16 v18, 0x0

    .line 571
    .local v18, "$i$a$-forEach-Autocomplete$completeString$5$1\\18\\671\\16":I
    new-instance v19, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    invoke-static/range {v20 .. v20}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    sget-object v21, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->PROPERTY:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    const-string v22, "attribute"

    const/16 v24, 0x8

    const/16 v25, 0x0

    const/16 v23, 0x0

    invoke-direct/range {v19 .. v25}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v19

    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 671
    nop

    .end local v18    # "$i$a$-forEach-Autocomplete$completeString$5$1\\18\\671\\16":I
    .end local v20    # "it\\18":Ljava/lang/String;
    const/4 v13, 0x0

    .end local v17    # "element\\17":Ljava/lang/Object;
    goto :goto_140

    .line 672
    :cond_16c
    nop

    .line 571
    .end local v5    # "$this$forEach\\17":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\17\\571":I
    nop

    .end local v0    # "$i$a$-synchronized-Autocomplete$completeString$5\\16\\571\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_170
    .catchall {:try_start_125 .. :try_end_170} :catchall_172

    monitor-exit v4

    goto :goto_175

    :catchall_172
    move-exception v0

    monitor-exit v4

    throw v0

    :cond_175
    :goto_175
    move/from16 v13, v16

    goto/16 :goto_43b

    .line 570
    .end local v2    # "t":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    :catchall_179
    move-exception v0

    goto :goto_180

    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v16    # "acc":C
    .local v3, "items":Ljava/util/ArrayList;
    .restart local v4    # "steps":Ljava/util/List;
    .local v5, "acc":C
    :catchall_17b
    move-exception v0

    move-object v12, v3

    move-object v3, v4

    move/from16 v16, v5

    .end local v4    # "steps":Ljava/util/List;
    .end local v5    # "acc":C
    .local v3, "steps":Ljava/util/List;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v16    # "acc":C
    :goto_180
    monitor-exit v11

    throw v0

    .line 542
    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v16    # "acc":C
    .local v2, "acc":C
    .local v3, "items":Ljava/util/ArrayList;
    :sswitch_182
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "FindFirstAncestorOfClass"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_237

    goto/16 :goto_2c0

    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .restart local v2    # "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_18f
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "new"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_458

    .line 544
    const/16 v2, 0x2e

    if-ne v13, v2, :cond_43b

    add-int/lit8 v2, v7, -0x8

    invoke-static {v11, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {v6, v2, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const-string v3, "substring(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "Instance"

    const/4 v4, 0x0

    invoke-static {v2, v3, v11, v0, v4}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_43b

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->getInsertable()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 661
    .local v2, "$i$f$forEach\\3\\544":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1c3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1e8

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\3":Ljava/lang/Object;
    move-object/from16 v21, v4

    check-cast v21, Ljava/lang/String;

    .local v21, "it\\4":Ljava/lang/String;
    const/4 v5, 0x0

    .line 544
    .local v5, "$i$a$-forEach-Autocomplete$completeString$2\\4\\661\\0":I
    new-instance v20, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    sget-object v22, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->CLASS:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    const-string v23, "class"

    const/16 v25, 0x8

    const/16 v26, 0x0

    const/16 v24, 0x0

    invoke-direct/range {v20 .. v26}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v8, v20

    invoke-virtual {v12, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 661
    .end local v5    # "$i$a$-forEach-Autocomplete$completeString$2\\4\\661\\0":I
    .end local v21    # "it\\4":Ljava/lang/String;
    nop

    .end local v4    # "element\\3":Ljava/lang/Object;
    goto :goto_1c3

    .line 662
    :cond_1e8
    nop

    .end local v0    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\3\\544":I
    goto/16 :goto_43b

    .line 542
    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .local v2, "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_1eb
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "IsA"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_237

    goto/16 :goto_2c0

    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .restart local v2    # "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_1f8
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "FindFirstChildWhichIsA"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_237

    goto/16 :goto_2c0

    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .restart local v2    # "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_205
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "FindFirstAncestor"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2c2

    goto/16 :goto_2c0

    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .restart local v2    # "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_212
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "GetTagged"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_237

    goto/16 :goto_2c0

    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .restart local v2    # "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_21f
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "FindFirstChildOfClass"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_237

    goto/16 :goto_2c0

    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .restart local v2    # "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_22c
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "FindFirstAncestorWhichIsA"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_458

    .line 546
    :cond_237
    const-string v2, "GetTagged"

    invoke-static {v15, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_242

    const/16 v19, 0x0

    return-object v19

    :cond_242
    sget-object v2, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->getInsertable()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    const/16 v3, 0x8

    new-array v3, v3, [Ljava/lang/String;

    const-string v5, "BasePart"

    aput-object v5, v3, v11

    const-string v5, "GuiObject"

    aput-object v5, v3, v8

    const-string v5, "LuaSourceContainer"

    aput-object v5, v3, v0

    const-string v0, "Player"

    aput-object v0, v3, v16

    const-string v0, "Humanoid"

    aput-object v0, v3, v17

    const-string v0, "ValueBase"

    aput-object v0, v3, v4

    const/4 v0, 0x6

    const-string v4, "GuiButton"

    aput-object v4, v3, v0

    const/4 v0, 0x7

    const-string v4, "Light"

    aput-object v4, v3, v0

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v2, v0}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\5":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 663
    .local v2, "$i$f$forEach\\5\\546":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_28d
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2b2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\5":Ljava/lang/Object;
    move-object/from16 v21, v4

    check-cast v21, Ljava/lang/String;

    .local v21, "it\\6":Ljava/lang/String;
    const/4 v5, 0x0

    .line 546
    .local v5, "$i$a$-forEach-Autocomplete$completeString$3\\6\\663\\0":I
    new-instance v20, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    sget-object v22, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->CLASS:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    const-string v23, "class"

    const/16 v25, 0x8

    const/16 v26, 0x0

    const/16 v24, 0x0

    invoke-direct/range {v20 .. v26}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v8, v20

    invoke-virtual {v12, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 663
    .end local v5    # "$i$a$-forEach-Autocomplete$completeString$3\\6\\663\\0":I
    .end local v21    # "it\\6":Ljava/lang/String;
    nop

    .end local v4    # "element\\5":Ljava/lang/Object;
    goto :goto_28d

    .line 664
    :cond_2b2
    nop

    .end local v0    # "$this$forEach\\5":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\5\\546":I
    goto/16 :goto_43b

    .line 542
    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .local v2, "acc":C
    .restart local v3    # "items":Ljava/util/ArrayList;
    :sswitch_2b5
    move v13, v2

    move v0, v12

    move-object v12, v3

    .end local v2    # "acc":C
    .end local v3    # "items":Ljava/util/ArrayList;
    .restart local v12    # "items":Ljava/util/ArrayList;
    .restart local v13    # "acc":C
    const-string v2, "WaitForChild"

    invoke-virtual {v15, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2c2

    :goto_2c0
    goto/16 :goto_458

    .line 548
    :cond_2c2
    :goto_2c2
    if-eq v13, v5, :cond_2c7

    const/16 v19, 0x0

    return-object v19

    .line 549
    :cond_2c7
    const/16 v19, 0x0

    invoke-direct {v1, v6, v7}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->chainBefore(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v3

    if-nez v3, :cond_2d0

    return-object v19

    .line 550
    .local v3, "steps":Ljava/util/List;
    :cond_2d0
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v18

    monitor-enter v18

    .line 583
    const/16 v20, 0x0

    .line 550
    .local v20, "$i$a$-synchronized-Autocomplete$completeString$t$1\\7\\550\\0":I
    :try_start_2d7
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete;

    move v5, v8

    const/4 v8, 0x0

    move/from16 v21, v0

    move v0, v4

    move/from16 v22, v17

    move-object/from16 v4, p1

    move/from16 v17, v11

    move v11, v5

    move-object/from16 v5, p2

    invoke-direct/range {v2 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->resolveSteps(Ljava/util/List;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;II)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    move-result-object v2
    :try_end_2eb
    .catchall {:try_start_2d7 .. :try_end_2eb} :catchall_455

    .end local v20    # "$i$a$-synchronized-Autocomplete$completeString$t$1\\7\\550\\0":I
    monitor-exit v18

    .line 551
    .local v2, "t":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v4

    monitor-enter v4

    const/4 v5, 0x0

    .line 552
    .local v5, "$i$a$-synchronized-Autocomplete$completeString$4\\8\\551\\0":I
    nop

    .line 553
    :try_start_2f3
    instance-of v6, v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    if-eqz v6, :cond_37f

    .line 554
    const-string v0, "FindFirstAncestor"

    invoke-static {v15, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_318

    move-object v0, v2

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;->getI()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$$ExternalSyntheticLambda5;

    invoke-direct {v6}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$$ExternalSyntheticLambda5;-><init>()V

    invoke-static {v0, v6}, Lkotlin/sequences/SequencesKt;->generateSequence(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object v0

    invoke-static {v0}, Lkotlin/sequences/SequencesKt;->toList(Lkotlin/sequences/Sequence;)Ljava/util/List;

    move-result-object v0

    goto :goto_342

    .line 555
    :cond_318
    const-string v0, "FindFirstDescendant"

    invoke-static {v15, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_335

    move-object v0, v2

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;->getI()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    const/4 v6, 0x0

    invoke-static {v0, v6, v11, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    const/16 v6, 0x190

    invoke-static {v0, v6}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v0

    goto :goto_342

    :cond_335
    move-object v0, v2

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;->getI()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    .line 554
    :goto_342
    nop

    .line 556
    .local v0, "list\\8":Ljava/util/List;
    move-object v6, v0

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$forEach\\9":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 665
    .local v8, "$i$f$forEach\\9\\556":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_34b
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_37b

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    .local v16, "element\\9":Ljava/lang/Object;
    move-object/from16 v17, v16

    check-cast v17, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v17, "it\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v18, 0x0

    .line 556
    .local v18, "$i$a$-forEach-Autocomplete$completeString$4$1\\10\\665\\8":I
    new-instance v20, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v21

    sget-object v22, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->CHILD:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v23

    const/16 v25, 0x8

    const/16 v26, 0x0

    const/16 v24, 0x0

    invoke-direct/range {v20 .. v26}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v21, v0

    move-object/from16 v0, v20

    .end local v0    # "list\\8":Ljava/util/List;
    .local v21, "list\\8":Ljava/util/List;
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 665
    nop

    .end local v17    # "it\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v18    # "$i$a$-forEach-Autocomplete$completeString$4$1\\10\\665\\8":I
    move-object/from16 v0, v21

    .end local v16    # "element\\9":Ljava/lang/Object;
    goto :goto_34b

    .line 666
    .end local v21    # "list\\8":Ljava/util/List;
    .restart local v0    # "list\\8":Ljava/util/List;
    :cond_37b
    move-object/from16 v21, v0

    .end local v0    # "list\\8":Ljava/util/List;
    .end local v6    # "$this$forEach\\9":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\9\\556":I
    goto/16 :goto_437

    .line 558
    :cond_37f
    instance-of v6, v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;

    if-eqz v6, :cond_437

    move-object v6, v2

    check-cast v6, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;->getName()Ljava/lang/String;

    move-result-object v6

    .line 559
    const-string v8, "Model"

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_3e2

    new-array v0, v0, [Ljava/lang/String;

    const-string v6, "Humanoid"

    aput-object v6, v0, v17

    const-string v6, "HumanoidRootPart"

    aput-object v6, v0, v11

    const-string v6, "Head"

    aput-object v6, v0, v21

    const-string v6, "Torso"

    aput-object v6, v0, v16

    const-string v6, "UpperTorso"

    aput-object v6, v0, v22

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\11":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 667
    .local v6, "$i$f$forEach\\11\\559":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_3b3
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_3df

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\11":Ljava/lang/Object;
    move-object/from16 v16, v11

    check-cast v16, Ljava/lang/String;

    move-object/from16 v21, v16

    .local v21, "it\\12":Ljava/lang/String;
    const/16 v16, 0x0

    .line 559
    .local v16, "$i$a$-forEach-Autocomplete$completeString$4$2\\12\\667\\8":I
    new-instance v20, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    sget-object v22, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->CHILD:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    const/16 v25, 0xc

    const/16 v26, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    invoke-direct/range {v20 .. v26}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v17, v0

    move-object/from16 v0, v20

    .end local v0    # "$this$forEach\\11":Ljava/lang/Iterable;
    .local v17, "$this$forEach\\11":Ljava/lang/Iterable;
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 667
    nop

    .end local v16    # "$i$a$-forEach-Autocomplete$completeString$4$2\\12\\667\\8":I
    .end local v21    # "it\\12":Ljava/lang/String;
    move-object/from16 v0, v17

    .end local v11    # "element\\11":Ljava/lang/Object;
    goto :goto_3b3

    .line 668
    .end local v17    # "$this$forEach\\11":Ljava/lang/Iterable;
    .restart local v0    # "$this$forEach\\11":Ljava/lang/Iterable;
    :cond_3df
    move-object/from16 v17, v0

    .end local v0    # "$this$forEach\\11":Ljava/lang/Iterable;
    .end local v6    # "$i$f$forEach\\11\\559":I
    goto :goto_437

    .line 560
    :cond_3e2
    const-string v0, "Player"

    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_437

    move/from16 v0, v22

    new-array v0, v0, [Ljava/lang/String;

    const-string v6, "PlayerGui"

    aput-object v6, v0, v17

    const-string v6, "Backpack"

    aput-object v6, v0, v11

    const-string v6, "PlayerScripts"

    aput-object v6, v0, v21

    const-string v6, "leaderstats"

    aput-object v6, v0, v16

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\13":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 669
    .local v6, "$i$f$forEach\\13\\560":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_409
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_435

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\13":Ljava/lang/Object;
    move-object/from16 v16, v11

    check-cast v16, Ljava/lang/String;

    move-object/from16 v21, v16

    .local v21, "it\\14":Ljava/lang/String;
    const/16 v16, 0x0

    .line 560
    .local v16, "$i$a$-forEach-Autocomplete$completeString$4$3\\14\\669\\8":I
    new-instance v20, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    sget-object v22, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->CHILD:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    const/16 v25, 0xc

    const/16 v26, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    invoke-direct/range {v20 .. v26}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v17, v0

    move-object/from16 v0, v20

    .end local v0    # "$this$forEach\\13":Ljava/lang/Iterable;
    .local v17, "$this$forEach\\13":Ljava/lang/Iterable;
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 669
    nop

    .end local v16    # "$i$a$-forEach-Autocomplete$completeString$4$3\\14\\669\\8":I
    .end local v21    # "it\\14":Ljava/lang/String;
    move-object/from16 v0, v17

    .end local v11    # "element\\13":Ljava/lang/Object;
    goto :goto_409

    .line 670
    .end local v17    # "$this$forEach\\13":Ljava/lang/Iterable;
    .restart local v0    # "$this$forEach\\13":Ljava/lang/Iterable;
    :cond_435
    move-object/from16 v17, v0

    .line 565
    .end local v0    # "$this$forEach\\13":Ljava/lang/Iterable;
    .end local v6    # "$i$f$forEach\\13\\560":I
    :cond_437
    :goto_437
    nop

    .end local v5    # "$i$a$-synchronized-Autocomplete$completeString$4\\8\\551\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_43a
    .catchall {:try_start_2f3 .. :try_end_43a} :catchall_452

    .line 551
    monitor-exit v4

    .line 575
    .end local v2    # "t":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    .end local v3    # "steps":Ljava/util/List;
    :cond_43b
    :goto_43b
    move-object v0, v12

    check-cast v0, Ljava/util/List;

    invoke-direct {v1, v0, v10}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->rank(Ljava/util/List;Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    .line 576
    .local v0, "ranked":Ljava/util/List;
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_44a

    const/4 v2, 0x0

    goto :goto_451

    :cond_44a
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    add-int/lit8 v3, p5, 0x1

    invoke-direct {v2, v3, v9, v10, v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;-><init>(IILjava/lang/String;Ljava/util/List;)V

    :goto_451
    return-object v2

    .line 551
    .end local v0    # "ranked":Ljava/util/List;
    .restart local v2    # "t":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    .restart local v3    # "steps":Ljava/util/List;
    :catchall_452
    move-exception v0

    monitor-exit v4

    throw v0

    .line 550
    .end local v2    # "t":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    :catchall_455
    move-exception v0

    monitor-exit v18

    throw v0

    .line 573
    .end local v3    # "steps":Ljava/util/List;
    :cond_458
    :goto_458
    const/16 v19, 0x0

    return-object v19

    .line 531
    .end local v7    # "i":I
    .end local v12    # "items":Ljava/util/ArrayList;
    .end local v13    # "acc":C
    .end local v14    # "e":I
    .end local v15    # "fn":Ljava/lang/String;
    .local v0, "i":I
    :cond_45b
    move-object/from16 v19, v13

    .line 533
    :goto_45d
    return-object v19

    :sswitch_data_45e
    .sparse-switch
        -0x7907ed78 -> :sswitch_2b5
        -0x759fe19c -> :sswitch_22c
        -0x6b4518e4 -> :sswitch_21f
        -0x57fd4bbe -> :sswitch_212
        -0x3277a0b6 -> :sswitch_205
        -0x142c40e1 -> :sswitch_1f8
        0x12037 -> :sswitch_1eb
        0x1a9a0 -> :sswitch_18f
        0x5330b37 -> :sswitch_182
        0xa007006 -> :sswitch_ed
        0xb81de9c -> :sswitch_b1
        0x2ae2de9f -> :sswitch_a8
        0x2f6ae0b4 -> :sswitch_9b
        0x6654307a -> :sswitch_92
        0x79b9eb05 -> :sswitch_89
    .end sparse-switch
.end method
