.method static final _init_$lambda$8(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "self"    # Lorg/luaj/vm2/LuaValue;
    .param p2, "key"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "self"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 154
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.lua.Connection"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/Connection;

    .line 155
    .local v0, "c":Lcom/exampletest/mobilestudiotest/lua/Connection;
    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_58

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    sparse-switch v2, :sswitch_data_60

    goto :goto_58

    :sswitch_23
    const-string v2, "Connected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_58

    .line 157
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/Connection;->getConnected()Z

    move-result v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v1

    const-string v2, "valueOf(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_5f

    .line 155
    :sswitch_3b
    const-string v2, "disconnect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto :goto_58

    :sswitch_44
    const-string v2, "Disconnect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_58

    .line 156
    :cond_4c
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/Connection;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_5f

    .line 158
    :cond_58
    :goto_58
    sget-object v1, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v2, "NIL"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 159
    :goto_5f
    return-object v1

    :sswitch_data_60
    .sparse-switch
        -0x6990cb44 -> :sswitch_44
        0x1f9d589c -> :sswitch_3b
        0x54ec12e9 -> :sswitch_23
    .end sparse-switch
.end method
