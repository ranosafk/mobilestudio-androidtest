.method static final mouseValue$lambda$151(Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .param p1, "$m"    # Lorg/luaj/vm2/LuaTable;
    .param p3, "k"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "<unused var>"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p2, "k"

    invoke-static {p3, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2063
    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object p2

    .local p2, "ks":Ljava/lang/String;
    if-eqz p2, :cond_be

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_c6

    goto/16 :goto_be

    :sswitch_19
    const-string v0, "Button2Up"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_be

    goto/16 :goto_8c

    :sswitch_23
    const-string v0, "Button1Up"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8c

    goto/16 :goto_be

    :sswitch_2d
    const-string v0, "WheelBackward"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8c

    goto/16 :goto_be

    :sswitch_37
    const-string v0, "KeyDown"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8c

    goto/16 :goto_be

    :sswitch_41
    const-string v0, "WheelForward"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8c

    goto/16 :goto_be

    :sswitch_4b
    const-string v0, "KeyUp"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8c

    goto/16 :goto_be

    :sswitch_55
    const-string v0, "Move"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8c

    goto :goto_be

    :sswitch_5e
    const-string v0, "Idle"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8c

    goto :goto_be

    :sswitch_67
    const-string v0, "IsA"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_be

    .line 2064
    new-instance v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession$$ExternalSyntheticLambda5;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$$ExternalSyntheticLambda5;-><init>()V

    .line 2065
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto :goto_c5

    .line 2063
    :sswitch_7b
    const-string v0, "Button2Down"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8c

    goto :goto_be

    :sswitch_84
    const-string v0, "Button1Down"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_be

    .line 2064
    :cond_8c
    :goto_8c
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getApi()Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_c5

    .line 2063
    :sswitch_97
    const-string v0, "GetPropertyChangedSignal"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_be

    .line 2066
    new-instance v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/LuaTable;)V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto :goto_c5

    .line 2063
    :sswitch_ab
    const-string v0, "Changed"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_be

    .line 2067
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getApi()Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    move-result-object v1

    invoke-virtual {v1, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_c5

    .line 2068
    :cond_be
    :goto_be
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NIL"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2069
    .end local p2    # "ks":Ljava/lang/String;
    :goto_c5
    return-object v0

    :sswitch_data_c6
    .sparse-switch
        -0x70bc056c -> :sswitch_ab
        -0x1006eeef -> :sswitch_97
        -0x812b79f -> :sswitch_84
        -0x804a01e -> :sswitch_7b
        0x12037 -> :sswitch_67
        0x22b3f4 -> :sswitch_5e
        0x24aff1 -> :sswitch_55
        0x4509d3a -> :sswitch_4b
        0x81c570a -> :sswitch_41
        0x32968781 -> :sswitch_37
        0x5d1a903e -> :sswitch_2d
        0x7822161a -> :sswitch_23
        0x782219db -> :sswitch_19
    .end sparse-switch
.end method
