.method private final convert(Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;)Lkotlin/Pair;
    .registers 28
    .param p1, "n"    # Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;",
            ")",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .line 105
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->getText()Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "toString(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .local v2, "txt":Ljava/lang/String;
    move-object v3, v2

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {v3}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    .line 107
    .local v3, "t":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v5

    const-string v7, "true"

    const-string v8, "CFrame"

    const-string v12, "\\s+"

    const/4 v13, 0x2

    const/16 v14, 0x10

    const-string v9, "Z"

    const/16 v19, 0x4

    const-string v6, "Y"

    const/16 v20, 0x3

    const-string v15, "X"

    const/16 v21, 0x0

    .line 135
    invoke-static/range {v21 .. v21}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v22

    .line 107
    const/16 v23, 0xa

    .line 110
    const/16 v24, 0x1

    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    .line 107
    const/4 v11, 0x0

    sparse-switch v5, :sswitch_data_814

    goto/16 :goto_77e

    :sswitch_4b
    const-string v5, "Color3"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 119
    const/16 v4, 0xc

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string v5, "R"

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->child(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;

    move-result-object v6

    if-eqz v6, :cond_77

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v5

    const-string v7, "G"

    invoke-virtual {v1, v7}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v7

    const-string v8, "B"

    invoke-virtual {v1, v8}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v8

    invoke-direct {v6, v5, v7, v8}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    goto :goto_8b

    .line 120
    :cond_77
    sget-object v5, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    invoke-static {v3}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v6

    if-eqz v6, :cond_84

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    goto :goto_86

    :cond_84
    const-wide/16 v13, 0x0

    :goto_86
    long-to-int v6, v13

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromArgb(I)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v6

    .line 119
    :goto_8b
    invoke-static {v4, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_91
    const-string v5, "Vector3"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 122
    const/16 v4, 0xe

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v1, v15}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v7

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v6

    invoke-virtual {v1, v9}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v8

    invoke-direct {v5, v7, v6, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_b6
    const-string v5, "Vector2"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 123
    const/16 v4, 0xd

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {v1, v15}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v7

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v6

    invoke-direct {v5, v7, v6}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_d7
    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_10f

    goto/16 :goto_77e

    :sswitch_df
    const-string v5, "Color3uint8"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 121
    const/16 v4, 0x1a

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    invoke-static {v3}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v6

    if-eqz v6, :cond_fa

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    goto :goto_fc

    :cond_fa
    const-wide/16 v13, 0x0

    :goto_fc
    long-to-int v6, v13

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromArgb(I)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_107
    const-string v5, "CoordinateFrame"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 125
    :cond_10f
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->cframe(Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_11d
    const-string v5, "ContentId"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_724

    goto/16 :goto_77e

    :sswitch_127
    const-string v5, "OptionalCoordinateFrame"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 126
    const/16 v4, 0x1e

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v8}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->child(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;

    move-result-object v5

    if-eqz v5, :cond_144

    .line 183
    nop

    .local v5, "it\\1":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    const/4 v6, 0x0

    .line 126
    .local v6, "$i$a$-let-RbxXmlReader$convert$1\\1\\126\\0":I
    sget-object v7, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->INSTANCE:Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;

    invoke-direct {v7, v5}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->cframe(Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v9

    .end local v5    # "it\\1":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    .end local v6    # "$i$a$-let-RbxXmlReader$convert$1\\1\\126\\0":I
    goto :goto_145

    :cond_144
    const/4 v9, 0x0

    :goto_145
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    invoke-direct {v5, v9}, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;-><init>(Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_150
    const-string v5, "SecurityCapabilities"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 166
    const/16 v4, 0x21

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;

    invoke-static {v3}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v6

    if-eqz v6, :cond_16b

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    goto :goto_16d

    :cond_16b
    const-wide/16 v13, 0x0

    :goto_16d
    invoke-direct {v5, v13, v14}, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;-><init>(J)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_176
    const-string v5, "ProtectedString"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 109
    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_184
    const-string v5, "BinaryString"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 111
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->decodeB64(Ljava/lang/String;)[B

    move-result-object v5

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/model/BinaryString;-><init>([B)V

    invoke-static {v10, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_19b
    const-string v5, "PhysicalProperties"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 146
    const-string v4, "CustomPhysics"

    invoke-virtual {v1, v4}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    .line 147
    .local v4, "custom":Z
    const/16 v5, 0x19

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    if-nez v4, :cond_1c5

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;

    const/16 v14, 0x7e

    const/4 v15, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-direct/range {v6 .. v15}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;-><init>(IFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    goto :goto_1ef

    :cond_1c5
    new-instance v7, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;

    .line 148
    const-string v6, "Density"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v9

    const-string v6, "Friction"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v10

    const-string v6, "Elasticity"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v11

    const-string v6, "FrictionWeight"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v12

    const-string v6, "ElasticityWeight"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v13

    .line 147
    const/16 v15, 0x40

    const/16 v16, 0x0

    const/4 v8, 0x1

    const/4 v14, 0x0

    invoke-direct/range {v7 .. v16}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;-><init>(IFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v6, v7

    :goto_1ef
    invoke-static {v5, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v4    # "custom":Z
    goto/16 :goto_813

    .line 107
    :sswitch_1f5
    const-string v5, "token"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 117
    const/16 v4, 0x12

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-static {v3}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v6

    if-eqz v6, :cond_210

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    long-to-int v11, v6

    :cond_210
    invoke-direct {v5, v11}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_219
    const-string v5, "int64"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 116
    const/16 v4, 0x1b

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_232

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    goto :goto_234

    :cond_232
    const-wide/16 v13, 0x0

    :goto_234
    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_23e
    const-string v5, "float"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 114
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3}, Lkotlin/text/StringsKt;->toFloatOrNull(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v5

    if-eqz v5, :cond_255

    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    move-result v5

    goto :goto_259

    :cond_255
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->parseSpecial(Ljava/lang/String;)F

    move-result v5

    :goto_259
    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_263
    const-string v5, "UDim2"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 128
    const/4 v4, 0x7

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/UDim2;

    const-string v6, "XS"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v6

    const-string v7, "XO"

    invoke-virtual {v1, v7}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v7

    float-to-int v7, v7

    const-string v8, "YS"

    invoke-virtual {v1, v8}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v8

    const-string v9, "YO"

    invoke-virtual {v1, v9}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v9

    float-to-int v9, v9

    invoke-direct {v5, v6, v7, v8, v9}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_295
    const-string v5, "Faces"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 151
    const/16 v4, 0x9

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Faces;

    const-string v6, "faces"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v6

    if-eqz v6, :cond_2b5

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v11

    :cond_2b5
    invoke-direct {v5, v11}, Lcom/exampletest/mobilestudiotest/model/Faces;-><init>(I)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_2be
    const-string v5, "bool"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 112
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_2d8
    const-string v5, "UDim"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 127
    const/4 v4, 0x6

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/UDim;

    const-string v6, "S"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v6

    const-string v7, "O"

    invoke-virtual {v1, v7}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v7

    float-to-int v7, v7

    invoke-direct {v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_2fd
    const-string v5, "Font"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 162
    const/16 v4, 0x20

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    .line 163
    const-string v5, "Family"

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->child(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;

    move-result-object v5

    const-string v6, ""

    if-eqz v5, :cond_320

    .line 183
    nop

    .local v5, "it\\36":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    const/4 v7, 0x0

    .line 163
    .local v7, "$i$a$-let-RbxXmlReader$convert$9\\36\\163\\0":I
    sget-object v8, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->INSTANCE:Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;

    invoke-direct {v8, v5}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->content(Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;)Ljava/lang/String;

    move-result-object v5

    .end local v5    # "it\\36":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    .end local v7    # "$i$a$-let-RbxXmlReader$convert$9\\36\\163\\0":I
    if-eqz v5, :cond_320

    goto :goto_321

    :cond_320
    move-object v5, v6

    :goto_321
    const-string v7, "Weight"

    invoke-virtual {v1, v7}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    if-eqz v7, :cond_332

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    goto :goto_334

    :cond_332
    const/16 v7, 0x190

    .line 164
    :goto_334
    const-string v8, "Style"

    invoke-virtual {v1, v8}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "Italic"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    const-string v9, "CachedFaceId"

    invoke-virtual {v1, v9}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->child(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;

    move-result-object v9

    if-eqz v9, :cond_353

    .line 183
    nop

    .local v9, "it\\37":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    const/4 v10, 0x0

    .line 164
    .local v10, "$i$a$-let-RbxXmlReader$convert$10\\37\\164\\0":I
    sget-object v11, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->INSTANCE:Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;

    invoke-direct {v11, v9}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->content(Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;)Ljava/lang/String;

    move-result-object v9

    .end local v9    # "it\\37":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    .end local v10    # "$i$a$-let-RbxXmlReader$convert$10\\37\\164\\0":I
    if-eqz v9, :cond_353

    move-object v6, v9

    .line 162
    :cond_353
    new-instance v9, Lcom/exampletest/mobilestudiotest/model/FontValue;

    invoke-direct {v9, v5, v7, v8, v6}, Lcom/exampletest/mobilestudiotest/model/FontValue;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    invoke-static {v4, v9}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_35e
    const-string v5, "Axes"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 152
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Axes;

    const-string v6, "axes"

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v6

    if-eqz v6, :cond_37c

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v11

    :cond_37c
    invoke-direct {v5, v11}, Lcom/exampletest/mobilestudiotest/model/Axes;-><init>(I)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_385
    const-string v5, "int"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 113
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_39c

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    long-to-int v11, v5

    :cond_39c
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_3a6
    const-string v5, "Ray"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 154
    const-string v4, "origin"

    invoke-virtual {v1, v4}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->child(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;

    move-result-object v4

    .local v4, "o":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    const-string v5, "direction"

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->child(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;

    move-result-object v5

    .line 155
    .local v5, "d":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    const/16 v7, 0x8

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    new-instance v8, Lcom/exampletest/mobilestudiotest/model/Ray;

    new-instance v10, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v4, :cond_3cb

    invoke-virtual {v4, v15}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v11

    goto :goto_3cd

    :cond_3cb
    move/from16 v11, v21

    :goto_3cd
    if-eqz v4, :cond_3d4

    invoke-virtual {v4, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v12

    goto :goto_3d6

    :cond_3d4
    move/from16 v12, v21

    :goto_3d6
    if-eqz v4, :cond_3dd

    invoke-virtual {v4, v9}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v13

    goto :goto_3df

    :cond_3dd
    move/from16 v13, v21

    :goto_3df
    invoke-direct {v10, v11, v12, v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    new-instance v11, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_3eb

    invoke-virtual {v5, v15}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v12

    goto :goto_3ed

    :cond_3eb
    move/from16 v12, v21

    :goto_3ed
    if-eqz v5, :cond_3f4

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v6

    goto :goto_3f6

    :cond_3f4
    move/from16 v6, v21

    :goto_3f6
    if-eqz v5, :cond_3fc

    invoke-virtual {v5, v9}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v21

    :cond_3fc
    move/from16 v9, v21

    invoke-direct {v11, v12, v6, v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-direct {v8, v10, v11}, Lcom/exampletest/mobilestudiotest/model/Ray;-><init>(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    invoke-static {v7, v8}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v4    # "o":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    .end local v5    # "d":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    goto/16 :goto_813

    .line 107
    :sswitch_40a
    const-string v5, "UniqueId"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 158
    new-array v4, v14, [B

    .line 159
    .local v4, "b":[B
    move-object v5, v3

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v5, v13}, Lkotlin/text/StringsKt;->chunked(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    invoke-static {v5, v14}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$forEachIndexed\\34":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 237
    .local v6, "$i$f$forEachIndexed\\34\\159":I
    const/4 v7, 0x0

    .line 238
    .local v7, "index\\34":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_429
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_44f

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "item\\34":Ljava/lang/Object;
    add-int/lit8 v10, v7, 0x1

    .end local v7    # "index\\34":I
    .local v10, "index\\34":I
    if-gez v7, :cond_43a

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_43a
    move-object v12, v9

    check-cast v12, Ljava/lang/String;

    .local v7, "i\\35":I
    .local v12, "h\\35":Ljava/lang/String;
    const/4 v13, 0x0

    .line 159
    .local v13, "$i$a$-forEachIndexed-RbxXmlReader$convert$8\\35\\238\\0":I
    invoke-static {v12, v14}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;I)Ljava/lang/Integer;

    move-result-object v15

    if-eqz v15, :cond_449

    invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I

    move-result v15

    goto :goto_44a

    :cond_449
    move v15, v11

    :goto_44a
    int-to-byte v15, v15

    aput-byte v15, v4, v7

    .line 238
    .end local v7    # "i\\35":I
    .end local v12    # "h\\35":Ljava/lang/String;
    .end local v13    # "$i$a$-forEachIndexed-RbxXmlReader$convert$8\\35\\238\\0":I
    move v7, v10

    .end local v9    # "item\\34":Ljava/lang/Object;
    goto :goto_429

    .line 239
    .end local v10    # "index\\34":I
    .local v7, "index\\34":I
    :cond_44f
    nop

    .line 160
    .end local v5    # "$this$forEachIndexed\\34":Ljava/lang/Iterable;
    .end local v6    # "$i$f$forEachIndexed\\34\\159":I
    .end local v7    # "index\\34":I
    const/16 v5, 0x1f

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/UniqueId;

    invoke-direct {v6, v4}, Lcom/exampletest/mobilestudiotest/model/UniqueId;-><init>([B)V

    invoke-static {v5, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v4    # "b":[B
    goto/16 :goto_813

    .line 107
    :sswitch_461
    const-string v5, "Vector3int16"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 124
    const/16 v4, 0x14

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    invoke-virtual {v1, v15}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v7

    float-to-int v7, v7

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v6

    float-to-int v6, v6

    invoke-virtual {v1, v9}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v8

    float-to-int v8, v8

    invoke-direct {v5, v7, v6, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3int16;-><init>(III)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_489
    const-string v5, "ColorSequence"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 142
    move-object v4, v3

    check-cast v4, Ljava/lang/CharSequence;

    new-instance v5, Lkotlin/text/Regex;

    invoke-direct {v5, v12}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v4, v11}, Lkotlin/text/Regex;->split(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$mapNotNull\\22":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 217
    .local v5, "$i$f$mapNotNull\\22\\142":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\23":Ljava/util/Collection;
    move-object v7, v4

    .local v7, "$this$mapNotNullTo\\23":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 225
    .local v8, "$i$f$mapNotNullTo\\23\\217":I
    move-object v9, v7

    .local v9, "$this$forEach\\24":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 226
    .local v10, "$i$f$forEach\\24\\225":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_4af
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_4d3

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element\\24":Ljava/lang/Object;
    move-object v15, v14

    .local v15, "element\\25":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 225
    .local v16, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\25\\226\\23":I
    move-object/from16 v17, v15

    check-cast v17, Ljava/lang/String;

    .local v17, "it\\27":Ljava/lang/String;
    const/16 v18, 0x0

    .line 142
    .local v18, "$i$a$-mapNotNull-RbxXmlReader$convert$p$3\\27\\225\\0":I
    invoke-static/range {v17 .. v17}, Lkotlin/text/StringsKt;->toFloatOrNull(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v17

    .line 225
    .end local v17    # "it\\27":Ljava/lang/String;
    .end local v18    # "$i$a$-mapNotNull-RbxXmlReader$convert$p$3\\27\\225\\0":I
    if-eqz v17, :cond_4d1

    move-object/from16 v18, v17

    .line 227
    .local v18, "it\\25":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 225
    .local v17, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\26\\227\\25":I
    move-object/from16 v13, v18

    .end local v18    # "it\\25":Ljava/lang/Object;
    .local v13, "it\\25":Ljava/lang/Object;
    invoke-interface {v6, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 226
    .end local v13    # "it\\25":Ljava/lang/Object;
    .end local v15    # "element\\25":Ljava/lang/Object;
    .end local v16    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\25\\226\\23":I
    .end local v17    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\26\\227\\25":I
    :cond_4d1
    const/4 v13, 0x2

    .end local v14    # "element\\24":Ljava/lang/Object;
    goto :goto_4af

    .line 228
    :cond_4d3
    nop

    .line 229
    .end local v9    # "$this$forEach\\24":Ljava/lang/Iterable;
    .end local v10    # "$i$f$forEach\\24\\225":I
    nop

    .end local v6    # "destination\\23":Ljava/util/Collection;
    .end local v7    # "$this$mapNotNullTo\\23":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapNotNullTo\\23\\217":I
    check-cast v6, Ljava/util/List;

    .line 217
    nop

    .line 142
    .end local v4    # "$this$mapNotNull\\22":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapNotNull\\22\\142":I
    nop

    .line 143
    .local v6, "p":Ljava/util/List;
    const/16 v4, 0x16

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object v5, v6

    check-cast v5, Ljava/lang/Iterable;

    const/4 v7, 0x5

    invoke-static {v5, v7}, Lkotlin/collections/CollectionsKt;->chunked(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$filter\\28":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 230
    .local v7, "$i$f$filter\\28\\143":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\29":Ljava/util/Collection;
    move-object v9, v5

    .local v9, "$this$filterTo\\29":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 231
    .local v10, "$i$f$filterTo\\29\\230":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_4f7
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_51b

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "element\\29":Ljava/lang/Object;
    move-object v14, v13

    check-cast v14, Ljava/util/List;

    .local v14, "it\\30":Ljava/util/List;
    const/4 v15, 0x0

    .line 143
    .local v15, "$i$a$-filter-RbxXmlReader$convert$6\\30\\231\\0":I
    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v11

    move-object/from16 v17, v5

    const/4 v5, 0x5

    .end local v5    # "$this$filter\\28":Ljava/lang/Iterable;
    .local v17, "$this$filter\\28":Ljava/lang/Iterable;
    if-ne v11, v5, :cond_511

    move/from16 v5, v24

    goto :goto_512

    :cond_511
    const/4 v5, 0x0

    .line 231
    .end local v14    # "it\\30":Ljava/util/List;
    .end local v15    # "$i$a$-filter-RbxXmlReader$convert$6\\30\\231\\0":I
    :goto_512
    if-eqz v5, :cond_517

    invoke-interface {v8, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_517
    move-object/from16 v5, v17

    const/4 v11, 0x0

    goto :goto_4f7

    .line 232
    .end local v13    # "element\\29":Ljava/lang/Object;
    .end local v17    # "$this$filter\\28":Ljava/lang/Iterable;
    .restart local v5    # "$this$filter\\28":Ljava/lang/Iterable;
    :cond_51b
    move-object/from16 v17, v5

    .end local v5    # "$this$filter\\28":Ljava/lang/Iterable;
    .end local v8    # "destination\\29":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\29":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\29\\230":I
    .restart local v17    # "$this$filter\\28":Ljava/lang/Iterable;
    move-object v5, v8

    check-cast v5, Ljava/util/List;

    .line 230
    nop

    .end local v7    # "$i$f$filter\\28\\143":I
    .end local v17    # "$this$filter\\28":Ljava/lang/Iterable;
    check-cast v5, Ljava/lang/Iterable;

    .line 143
    nop

    .local v5, "$this$map\\31":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 233
    .local v7, "$i$f$map\\31\\143":I
    new-instance v8, Ljava/util/ArrayList;

    move/from16 v9, v23

    invoke-static {v5, v9}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v9

    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\32":Ljava/util/Collection;
    move-object v9, v5

    .local v9, "$this$mapTo\\32":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 234
    .local v10, "$i$f$mapTo\\32\\233":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_538
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_5a6

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .line 235
    .local v12, "item\\32":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Ljava/util/List;

    .local v13, "it\\33":Ljava/util/List;
    const/4 v14, 0x0

    .line 143
    .local v14, "$i$a$-map-RbxXmlReader$convert$7\\33\\235\\0":I
    new-instance v15, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    move-object/from16 v17, v5

    const/4 v5, 0x0

    .end local v5    # "$this$map\\31":Ljava/lang/Iterable;
    .local v17, "$this$map\\31":Ljava/lang/Iterable;
    invoke-interface {v13, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/Number;

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Number;->floatValue()F

    move-result v5

    move-object/from16 v18, v6

    .end local v6    # "p":Ljava/util/List;
    .local v18, "p":Ljava/util/List;
    new-instance v6, Lcom/exampletest/mobilestudiotest/model/Color3;

    move/from16 v21, v7

    move/from16 v7, v24

    .end local v7    # "$i$f$map\\31\\143":I
    .local v21, "$i$f$map\\31\\143":I
    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v22

    check-cast v22, Ljava/lang/Number;

    invoke-virtual/range {v22 .. v22}, Ljava/lang/Number;->floatValue()F

    move-result v7

    move-object/from16 v22, v9

    const/4 v9, 0x2

    .end local v9    # "$this$mapTo\\32":Ljava/lang/Iterable;
    .local v22, "$this$mapTo\\32":Ljava/lang/Iterable;
    invoke-interface {v13, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v23

    check-cast v23, Ljava/lang/Number;

    invoke-virtual/range {v23 .. v23}, Ljava/lang/Number;->floatValue()F

    move-result v9

    move/from16 v23, v10

    move/from16 v10, v20

    .end local v10    # "$i$f$mapTo\\32\\233":I
    .local v23, "$i$f$mapTo\\32\\233":I
    invoke-interface {v13, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v25

    check-cast v25, Ljava/lang/Number;

    invoke-virtual/range {v25 .. v25}, Ljava/lang/Number;->floatValue()F

    move-result v10

    invoke-direct {v6, v7, v9, v10}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    move/from16 v7, v19

    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->floatValue()F

    move-result v9

    invoke-direct {v15, v5, v6, v9}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    .line 235
    .end local v13    # "it\\33":Ljava/util/List;
    .end local v14    # "$i$a$-map-RbxXmlReader$convert$7\\33\\235\\0":I
    invoke-interface {v8, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v5, v17

    move-object/from16 v6, v18

    move/from16 v7, v21

    move-object/from16 v9, v22

    move/from16 v10, v23

    const/16 v20, 0x3

    const/16 v24, 0x1

    goto :goto_538

    .line 236
    .end local v12    # "item\\32":Ljava/lang/Object;
    .end local v17    # "$this$map\\31":Ljava/lang/Iterable;
    .end local v18    # "p":Ljava/util/List;
    .end local v21    # "$i$f$map\\31\\143":I
    .end local v22    # "$this$mapTo\\32":Ljava/lang/Iterable;
    .end local v23    # "$i$f$mapTo\\32\\233":I
    .restart local v5    # "$this$map\\31":Ljava/lang/Iterable;
    .restart local v6    # "p":Ljava/util/List;
    .restart local v7    # "$i$f$map\\31\\143":I
    .restart local v9    # "$this$mapTo\\32":Ljava/lang/Iterable;
    .restart local v10    # "$i$f$mapTo\\32\\233":I
    :cond_5a6
    move-object/from16 v17, v5

    move-object/from16 v18, v6

    move/from16 v21, v7

    move-object/from16 v22, v9

    move/from16 v23, v10

    .end local v5    # "$this$map\\31":Ljava/lang/Iterable;
    .end local v6    # "p":Ljava/util/List;
    .end local v7    # "$i$f$map\\31\\143":I
    .end local v8    # "destination\\32":Ljava/util/Collection;
    .end local v9    # "$this$mapTo\\32":Ljava/lang/Iterable;
    .end local v10    # "$i$f$mapTo\\32\\233":I
    .restart local v17    # "$this$map\\31":Ljava/lang/Iterable;
    .restart local v18    # "p":Ljava/util/List;
    .restart local v21    # "$i$f$map\\31\\143":I
    move-object v5, v8

    check-cast v5, Ljava/util/List;

    .line 233
    nop

    .line 143
    .end local v17    # "$this$map\\31":Ljava/lang/Iterable;
    .end local v21    # "$i$f$map\\31\\143":I
    new-instance v6, Lcom/exampletest/mobilestudiotest/model/ColorSequence;

    invoke-direct {v6, v5}, Lcom/exampletest/mobilestudiotest/model/ColorSequence;-><init>(Ljava/util/List;)V

    invoke-static {v4, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v18    # "p":Ljava/util/List;
    goto/16 :goto_813

    .line 107
    :sswitch_5bf
    const-string v5, "NumberSequence"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 138
    move-object v4, v3

    check-cast v4, Ljava/lang/CharSequence;

    new-instance v5, Lkotlin/text/Regex;

    invoke-direct {v5, v12}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    invoke-virtual {v5, v4, v6}, Lkotlin/text/Regex;->split(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$mapNotNull\\10":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 197
    .local v5, "$i$f$mapNotNull\\10\\138":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\11":Ljava/util/Collection;
    move-object v7, v4

    .local v7, "$this$mapNotNullTo\\11":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 205
    .local v8, "$i$f$mapNotNullTo\\11\\197":I
    move-object v9, v7

    .local v9, "$this$forEach\\12":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 206
    .local v10, "$i$f$forEach\\12\\205":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_5e6
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_604

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\12":Ljava/lang/Object;
    move-object v13, v12

    .local v13, "element\\13":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 205
    .local v14, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\13\\206\\11":I
    move-object v15, v13

    check-cast v15, Ljava/lang/String;

    .local v15, "it\\15":Ljava/lang/String;
    const/16 v17, 0x0

    .line 138
    .local v17, "$i$a$-mapNotNull-RbxXmlReader$convert$p$2\\15\\205\\0":I
    invoke-static {v15}, Lkotlin/text/StringsKt;->toFloatOrNull(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v15

    .line 205
    .end local v15    # "it\\15":Ljava/lang/String;
    .end local v17    # "$i$a$-mapNotNull-RbxXmlReader$convert$p$2\\15\\205\\0":I
    if-eqz v15, :cond_602

    .line 207
    .local v15, "it\\13":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 205
    .local v17, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\14\\207\\13":I
    invoke-interface {v6, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 206
    .end local v13    # "element\\13":Ljava/lang/Object;
    .end local v14    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\13\\206\\11":I
    .end local v15    # "it\\13":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\14\\207\\13":I
    :cond_602
    nop

    .end local v12    # "element\\12":Ljava/lang/Object;
    goto :goto_5e6

    .line 208
    :cond_604
    nop

    .line 209
    .end local v9    # "$this$forEach\\12":Ljava/lang/Iterable;
    .end local v10    # "$i$f$forEach\\12\\205":I
    nop

    .end local v6    # "destination\\11":Ljava/util/Collection;
    .end local v7    # "$this$mapNotNullTo\\11":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapNotNullTo\\11\\197":I
    check-cast v6, Ljava/util/List;

    .line 197
    nop

    .line 138
    .end local v4    # "$this$mapNotNull\\10":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapNotNull\\10\\138":I
    nop

    .line 139
    .local v6, "p":Ljava/util/List;
    const/16 v4, 0x15

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object v5, v6

    check-cast v5, Ljava/lang/Iterable;

    const/4 v10, 0x3

    invoke-static {v5, v10}, Lkotlin/collections/CollectionsKt;->chunked(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$filter\\16":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 210
    .local v7, "$i$f$filter\\16\\139":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\17":Ljava/util/Collection;
    move-object v9, v5

    .local v9, "$this$filterTo\\17":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 211
    .local v10, "$i$f$filterTo\\17\\210":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_628
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_64a

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\17":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Ljava/util/List;

    .local v13, "it\\18":Ljava/util/List;
    const/4 v14, 0x0

    .line 139
    .local v14, "$i$a$-filter-RbxXmlReader$convert$4\\18\\211\\0":I
    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v15

    move-object/from16 v17, v5

    const/4 v5, 0x3

    .end local v5    # "$this$filter\\16":Ljava/lang/Iterable;
    .local v17, "$this$filter\\16":Ljava/lang/Iterable;
    if-ne v15, v5, :cond_641

    const/4 v13, 0x1

    goto :goto_642

    :cond_641
    const/4 v13, 0x0

    .line 211
    .end local v13    # "it\\18":Ljava/util/List;
    .end local v14    # "$i$a$-filter-RbxXmlReader$convert$4\\18\\211\\0":I
    :goto_642
    if-eqz v13, :cond_647

    invoke-interface {v8, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_647
    move-object/from16 v5, v17

    goto :goto_628

    .line 212
    .end local v12    # "element\\17":Ljava/lang/Object;
    .end local v17    # "$this$filter\\16":Ljava/lang/Iterable;
    .restart local v5    # "$this$filter\\16":Ljava/lang/Iterable;
    :cond_64a
    move-object/from16 v17, v5

    .end local v5    # "$this$filter\\16":Ljava/lang/Iterable;
    .end local v8    # "destination\\17":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\17":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\17\\210":I
    .restart local v17    # "$this$filter\\16":Ljava/lang/Iterable;
    move-object v5, v8

    check-cast v5, Ljava/util/List;

    .line 210
    nop

    .end local v7    # "$i$f$filter\\16\\139":I
    .end local v17    # "$this$filter\\16":Ljava/lang/Iterable;
    check-cast v5, Ljava/lang/Iterable;

    .line 139
    nop

    .local v5, "$this$map\\19":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 213
    .local v7, "$i$f$map\\19\\139":I
    new-instance v8, Ljava/util/ArrayList;

    const/16 v9, 0xa

    invoke-static {v5, v9}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v9

    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\20":Ljava/util/Collection;
    move-object v9, v5

    .local v9, "$this$mapTo\\20":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 214
    .local v10, "$i$f$mapTo\\20\\213":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_667
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_6ab

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .line 215
    .local v12, "item\\20":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Ljava/util/List;

    .local v13, "it\\21":Ljava/util/List;
    const/4 v14, 0x0

    .line 139
    .local v14, "$i$a$-map-RbxXmlReader$convert$5\\21\\215\\0":I
    new-instance v15, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    move-object/from16 v17, v5

    const/4 v5, 0x0

    .end local v5    # "$this$map\\19":Ljava/lang/Iterable;
    .local v17, "$this$map\\19":Ljava/lang/Iterable;
    invoke-interface {v13, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/Number;

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Number;->floatValue()F

    move-result v5

    move-object/from16 v18, v6

    const/4 v6, 0x1

    .end local v6    # "p":Ljava/util/List;
    .restart local v18    # "p":Ljava/util/List;
    invoke-interface {v13, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ljava/lang/Number;

    invoke-virtual/range {v19 .. v19}, Ljava/lang/Number;->floatValue()F

    move-result v6

    move/from16 v19, v7

    const/4 v7, 0x2

    .end local v7    # "$i$f$map\\19\\139":I
    .local v19, "$i$f$map\\19\\139":I
    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/Number;

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Number;->floatValue()F

    move-result v7

    invoke-direct {v15, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/NumberKey;-><init>(FFF)V

    .line 215
    .end local v13    # "it\\21":Ljava/util/List;
    .end local v14    # "$i$a$-map-RbxXmlReader$convert$5\\21\\215\\0":I
    invoke-interface {v8, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v5, v17

    move-object/from16 v6, v18

    move/from16 v7, v19

    goto :goto_667

    .line 216
    .end local v12    # "item\\20":Ljava/lang/Object;
    .end local v17    # "$this$map\\19":Ljava/lang/Iterable;
    .end local v18    # "p":Ljava/util/List;
    .end local v19    # "$i$f$map\\19\\139":I
    .restart local v5    # "$this$map\\19":Ljava/lang/Iterable;
    .restart local v6    # "p":Ljava/util/List;
    .restart local v7    # "$i$f$map\\19\\139":I
    :cond_6ab
    move-object/from16 v17, v5

    move-object/from16 v18, v6

    move/from16 v19, v7

    .end local v5    # "$this$map\\19":Ljava/lang/Iterable;
    .end local v6    # "p":Ljava/util/List;
    .end local v7    # "$i$f$map\\19\\139":I
    .end local v8    # "destination\\20":Ljava/util/Collection;
    .end local v9    # "$this$mapTo\\20":Ljava/lang/Iterable;
    .end local v10    # "$i$f$mapTo\\20\\213":I
    .restart local v17    # "$this$map\\19":Ljava/lang/Iterable;
    .restart local v18    # "p":Ljava/util/List;
    .restart local v19    # "$i$f$map\\19\\139":I
    move-object v5, v8

    check-cast v5, Ljava/util/List;

    .line 213
    nop

    .line 139
    .end local v17    # "$this$map\\19":Ljava/lang/Iterable;
    .end local v19    # "$i$f$map\\19\\139":I
    new-instance v6, Lcom/exampletest/mobilestudiotest/model/NumberSequence;

    invoke-direct {v6, v5}, Lcom/exampletest/mobilestudiotest/model/NumberSequence;-><init>(Ljava/util/List;)V

    invoke-static {v4, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v18    # "p":Ljava/util/List;
    goto/16 :goto_813

    .line 107
    :sswitch_6c0
    const-string v5, "BrickColor"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 118
    const/16 v4, 0xb

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    invoke-static {v3}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v6

    if-eqz v6, :cond_6db

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    goto :goto_6dd

    :cond_6db
    const/16 v6, 0xc2

    :goto_6dd
    invoke-direct {v5, v6}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_6e6
    const-string v5, "string"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 108
    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_6f4
    const-string v5, "double"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 115
    const/16 v25, 0x5

    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3}, Lkotlin/text/StringsKt;->toDoubleOrNull(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v5

    if-eqz v5, :cond_70d

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v5

    goto :goto_712

    :cond_70d
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->parseSpecial(Ljava/lang/String;)F

    move-result v5

    float-to-double v5, v5

    :goto_712
    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_71c
    const-string v5, "Content"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 110
    :cond_724
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader;->content(Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v10, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    goto/16 :goto_813

    .line 107
    :sswitch_72e
    const-string v5, "Rect2D"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_77e

    .line 130
    const-string v4, "min"

    invoke-virtual {v1, v4}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->child(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;

    move-result-object v4

    .local v4, "mn":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    const-string v5, "max"

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->child(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;

    move-result-object v5

    .line 131
    .local v5, "mx":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    const/16 v7, 0x18

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    new-instance v8, Lcom/exampletest/mobilestudiotest/model/Rect;

    if-eqz v4, :cond_751

    invoke-virtual {v4, v15}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v9

    goto :goto_753

    :cond_751
    move/from16 v9, v21

    :goto_753
    if-eqz v4, :cond_75a

    invoke-virtual {v4, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v10

    goto :goto_75c

    :cond_75a
    move/from16 v10, v21

    :goto_75c
    if-eqz v5, :cond_763

    invoke-virtual {v5, v15}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v11

    goto :goto_765

    :cond_763
    move/from16 v11, v21

    :goto_765
    if-eqz v5, :cond_76b

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;->f(Ljava/lang/String;)F

    move-result v21

    :cond_76b
    move/from16 v6, v21

    invoke-direct {v8, v9, v10, v11, v6}, Lcom/exampletest/mobilestudiotest/model/Rect;-><init>(FFFF)V

    invoke-static {v7, v8}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v4    # "mn":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    .end local v5    # "mx":Lcom/exampletest/mobilestudiotest/format/RbxXmlReader$XNode;
    goto/16 :goto_813

    .line 107
    :sswitch_776
    const-string v5, "NumberRange"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_780

    :cond_77e
    :goto_77e
    goto/16 :goto_809

    .line 134
    :cond_780
    move-object v4, v3

    check-cast v4, Ljava/lang/CharSequence;

    new-instance v5, Lkotlin/text/Regex;

    invoke-direct {v5, v12}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    invoke-virtual {v5, v4, v6}, Lkotlin/text/Regex;->split(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$mapNotNull\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 184
    .local v5, "$i$f$mapNotNull\\2\\134":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\3":Ljava/util/Collection;
    move-object v7, v4

    .local v7, "$this$mapNotNullTo\\3":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 192
    .local v8, "$i$f$mapNotNullTo\\3\\184":I
    move-object v9, v7

    .local v9, "$this$forEach\\4":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 193
    .local v10, "$i$f$forEach\\4\\192":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_79f
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_7bd

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\4":Ljava/lang/Object;
    move-object v13, v12

    .local v13, "element\\5":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 192
    .local v14, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\5\\193\\3":I
    move-object v15, v13

    check-cast v15, Ljava/lang/String;

    .local v15, "it\\7":Ljava/lang/String;
    const/16 v17, 0x0

    .line 134
    .local v17, "$i$a$-mapNotNull-RbxXmlReader$convert$p$1\\7\\192\\0":I
    invoke-static {v15}, Lkotlin/text/StringsKt;->toFloatOrNull(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v15

    .line 192
    .end local v15    # "it\\7":Ljava/lang/String;
    .end local v17    # "$i$a$-mapNotNull-RbxXmlReader$convert$p$1\\7\\192\\0":I
    if-eqz v15, :cond_7bb

    .line 194
    .local v15, "it\\5":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 192
    .local v17, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\6\\194\\5":I
    invoke-interface {v6, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 193
    .end local v13    # "element\\5":Ljava/lang/Object;
    .end local v14    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\5\\193\\3":I
    .end local v15    # "it\\5":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\6\\194\\5":I
    :cond_7bb
    nop

    .end local v12    # "element\\4":Ljava/lang/Object;
    goto :goto_79f

    .line 195
    :cond_7bd
    nop

    .line 196
    .end local v9    # "$this$forEach\\4":Ljava/lang/Iterable;
    .end local v10    # "$i$f$forEach\\4\\192":I
    nop

    .end local v6    # "destination\\3":Ljava/util/Collection;
    .end local v7    # "$this$mapNotNullTo\\3":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapNotNullTo\\3\\184":I
    check-cast v6, Ljava/util/List;

    .line 184
    nop

    .line 134
    .end local v4    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapNotNull\\2\\134":I
    nop

    .line 135
    .local v6, "p":Ljava/util/List;
    const/16 v4, 0x17

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v5

    if-lez v5, :cond_7d1

    const/4 v5, 0x1

    goto :goto_7d2

    :cond_7d1
    const/4 v5, 0x0

    :goto_7d2
    if-eqz v5, :cond_7da

    const/4 v5, 0x0

    invoke-interface {v6, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    goto :goto_7df

    .line 183
    :cond_7da
    const/4 v5, 0x0

    move v7, v5

    .local v7, "it\\8":I
    const/4 v8, 0x0

    .line 135
    .local v8, "$i$a$-getOrElse-RbxXmlReader$convert$2\\8\\135\\0":I
    move-object/from16 v7, v22

    .end local v7    # "it\\8":I
    .end local v8    # "$i$a$-getOrElse-RbxXmlReader$convert$2\\8\\135\\0":I
    :goto_7df
    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F

    move-result v7

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v8

    const/4 v9, 0x1

    if-ge v9, v8, :cond_7ee

    move v11, v9

    goto :goto_7ef

    :cond_7ee
    move v11, v5

    :goto_7ef
    if-eqz v11, :cond_7f6

    invoke-interface {v6, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v22

    goto :goto_7f9

    .line 183
    :cond_7f6
    nop

    .local v9, "it\\9":I
    const/4 v5, 0x0

    .line 135
    .local v5, "$i$a$-getOrElse-RbxXmlReader$convert$3\\9\\135\\0":I
    nop

    .end local v5    # "$i$a$-getOrElse-RbxXmlReader$convert$3\\9\\135\\0":I
    .end local v9    # "it\\9":I
    :goto_7f9
    check-cast v22, Ljava/lang/Number;

    invoke-virtual/range {v22 .. v22}, Ljava/lang/Number;->floatValue()F

    move-result v5

    new-instance v8, Lcom/exampletest/mobilestudiotest/model/NumberRange;

    invoke-direct {v8, v7, v5}, Lcom/exampletest/mobilestudiotest/model/NumberRange;-><init>(FF)V

    invoke-static {v4, v8}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v6    # "p":Ljava/util/List;
    goto :goto_813

    .line 167
    :goto_809
    const/4 v4, -0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v5, 0x0

    invoke-static {v4, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .line 107
    :goto_813
    return-object v4

    :sswitch_data_814
    .sparse-switch
        -0x715b44ac -> :sswitch_776
        -0x6e549caa -> :sswitch_72e
        -0x641033a7 -> :sswitch_71c
        -0x4f08842f -> :sswitch_6f4
        -0x352a9fef -> :sswitch_6e6
        -0x33b84c3e -> :sswitch_6c0
        -0x2a9cd5b6 -> :sswitch_5bf
        -0x2696d7dc -> :sswitch_489
        -0xe8382dc -> :sswitch_461
        -0xdb2b714 -> :sswitch_40a
        0x1400a -> :sswitch_3a6
        0x197ef -> :sswitch_385
        0x1f5b45 -> :sswitch_35e
        0x21806f -> :sswitch_2fd
        0x27aff3 -> :sswitch_2d8
        0x2e3aea -> :sswitch_2be
        0x4080596 -> :sswitch_295
        0x4ce4e9f -> :sswitch_263
        0x5d0225c -> :sswitch_23e
        0x5fb5eed -> :sswitch_219
        0x696b9f9 -> :sswitch_1f5
        0x929258a -> :sswitch_19b
        0xa68e792 -> :sswitch_184
        0x3047753f -> :sswitch_176
        0x333f2f36 -> :sswitch_150
        0x35640735 -> :sswitch_127
        0x5f2e2354 -> :sswitch_11d
        0x616da6b5 -> :sswitch_107
        0x6763ccce -> :sswitch_df
        0x76646aea -> :sswitch_d7
        0x775adf2f -> :sswitch_b6
        0x775adf30 -> :sswitch_91
        0x78a3a950 -> :sswitch_4b
    .end sparse-switch
.end method
