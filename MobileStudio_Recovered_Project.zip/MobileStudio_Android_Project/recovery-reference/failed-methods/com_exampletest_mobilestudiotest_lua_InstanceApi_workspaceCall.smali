.method public final workspaceCall(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 32
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-string v3, "name"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "a"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 794
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v3

    const-string v8, "Blockcast"

    const-string v9, "FindPartOnRayWithWhitelist"

    const-string v10, "FindPartsInRegion3WithWhiteList"

    const-string v11, "NONE"

    const-string v12, "valueOf(...)"

    const/4 v13, 0x4

    const-string v14, " expected, got "

    const-wide/high16 v16, 0x4000000000000000L    # 2.0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/16 v18, 0x1

    const/16 v19, 0x0

    const-string v15, "arg(...)"

    const/4 v6, 0x0

    sparse-switch v3, :sswitch_data_ab4

    goto/16 :goto_94c

    :sswitch_31
    const-string v3, "GetServerTimeNow"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 858
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    long-to-double v3, v3

    const-wide v5, 0x408f400000000000L    # 1000.0

    div-double/2addr v3, v5

    invoke-static {v3, v4}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_4f
    const-string v3, "GetRealPhysicsFPS"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 859
    const/16 v3, 0x3c

    invoke-static {v3}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_64
    const-string v3, "FindPartOnRayWithIgnoreList"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_80e

    goto/16 :goto_94c

    :sswitch_6e
    const-string v3, "GetPartBoundsInRadius"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 824
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v3, "$this$ud\\14":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\14":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1066
    .local v7, "$i$f$ud\\14\\824":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_8b

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_8c

    :cond_8b
    move-object v8, v6

    :goto_8c
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_91

    move-object v6, v8

    :cond_91
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_12c

    .line 824
    .end local v3    # "$this$ud\\14":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\14":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\14\\824":I
    nop

    .local v6, "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v3

    .line 825
    .local v3, "r":F
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v4

    .line 826
    .local v4, "f":Lkotlin/jvm/functions/Function1;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$filter\\15":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1067
    .local v7, "$i$f$filter\\15\\826":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\16":Ljava/util/Collection;
    move-object v9, v5

    .local v9, "$this$filterTo\\16":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1068
    .local v10, "$i$f$filterTo\\16\\1067":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_c0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_11c

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\16":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v13, "p\\17":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v14, 0x0

    .line 827
    .local v14, "$i$a$-filter-InstanceApi$workspaceCall$2\\17\\1068\\0":I
    invoke-interface {v4, v13}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/Boolean;

    invoke-virtual {v15}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v15

    if-nez v15, :cond_e1

    move/from16 v17, v3

    move-object/from16 v16, v4

    move/from16 v3, v19

    goto :goto_112

    .line 828
    :cond_e1
    sget-object v15, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v15, v13}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v15

    invoke-virtual {v15}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v16

    move/from16 v17, v3

    .end local v3    # "r":F
    .local v17, "r":F
    move-object/from16 v3, v16

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v3, "x0\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v15}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 829
    .local v15, "x1\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object/from16 v16, v4

    .end local v4    # "f":Lkotlin/jvm/functions/Function1;
    .local v16, "f":Lkotlin/jvm/functions/Function1;
    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->max(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4, v15}, Lcom/exampletest/mobilestudiotest/model/Vector3;->min(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    .line 830
    .local v4, "cl\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v4, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v20

    cmpg-float v20, v20, v17

    if-gtz v20, :cond_110

    move/from16 v3, v18

    goto :goto_112

    :cond_110
    move/from16 v3, v19

    .line 1068
    .end local v3    # "x0\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v4    # "cl\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v13    # "p\\17":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "$i$a$-filter-InstanceApi$workspaceCall$2\\17\\1068\\0":I
    .end local v15    # "x1\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :goto_112
    if-eqz v3, :cond_117

    invoke-interface {v8, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_117
    move-object/from16 v4, v16

    move/from16 v3, v17

    goto :goto_c0

    .line 1069
    .end local v12    # "element\\16":Ljava/lang/Object;
    .end local v16    # "f":Lkotlin/jvm/functions/Function1;
    .end local v17    # "r":F
    .local v3, "r":F
    .local v4, "f":Lkotlin/jvm/functions/Function1;
    :cond_11c
    move/from16 v17, v3

    move-object/from16 v16, v4

    .end local v3    # "r":F
    .end local v4    # "f":Lkotlin/jvm/functions/Function1;
    .end local v8    # "destination\\16":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\16":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\16\\1067":I
    .restart local v16    # "f":Lkotlin/jvm/functions/Function1;
    .restart local v17    # "r":F
    move-object v3, v8

    check-cast v3, Ljava/util/List;

    .line 1067
    nop

    .line 826
    .end local v5    # "$this$filter\\15":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filter\\15\\826":I
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v3

    .end local v6    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v16    # "f":Lkotlin/jvm/functions/Function1;
    .end local v17    # "r":F
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1066
    .local v3, "$this$ud\\14":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\14":Ljava/lang/String;
    .local v7, "$i$f$ud\\14\\824":I
    :cond_12c
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\14":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\14":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\14\\824":I
    :sswitch_14d
    const-string v3, "GetPhysicsThrottling"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 880
    const/16 v3, 0x64

    invoke-static {v3}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_162
    const-string v3, "BulkMoveTo"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 863
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v3

    .line 864
    .local v3, "parts":Ljava/util/List;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->checktable()Lorg/luaj/vm2/LuaTable;

    move-result-object v4

    .line 865
    .local v4, "cfs":Lorg/luaj/vm2/LuaTable;
    move-object v5, v3

    check-cast v5, Ljava/lang/Iterable;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    move/from16 v15, v19

    :cond_186
    :goto_186
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1c4

    move v7, v15

    .local v7, "i":I
    add-int/lit8 v15, v15, 0x1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 866
    .local v8, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    add-int/lit8 v9, v7, 0x1

    invoke-virtual {v4, v9}, Lorg/luaj/vm2/LuaTable;->get(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    const-string v10, "get(...)"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v9, "$this$udOrNull\\27":Lorg/luaj/vm2/LuaValue;
    const/4 v10, 0x0

    .line 1079
    .local v10, "$i$f$udOrNull\\27\\866":I
    invoke-virtual {v9}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v11

    if-eqz v11, :cond_1ac

    invoke-virtual {v9}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v11

    goto :goto_1ad

    :cond_1ac
    move-object v11, v6

    :goto_1ad
    instance-of v12, v11, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v12, :cond_1b2

    move-object v11, v6

    :cond_1b2
    check-cast v11, Lcom/exampletest/mobilestudiotest/model/CFrame;

    .line 866
    .end local v9    # "$this$udOrNull\\27":Lorg/luaj/vm2/LuaValue;
    .end local v10    # "$i$f$udOrNull\\27\\866":I
    if-eqz v11, :cond_186

    .line 867
    .local v11, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    const-string v9, "BasePart"

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_186

    const-string v9, "CFrame"

    invoke-virtual {v0, v8, v9, v11}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .end local v11    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    goto :goto_186

    .line 869
    .end local v7    # "i":I
    .end local v8    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_1c4
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 862
    .end local v3    # "parts":Ljava/util/List;
    .end local v4    # "cfs":Lorg/luaj/vm2/LuaTable;
    nop

    .line 866
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_1ce
    const-string v3, "IsRegion3EmptyWithIgnoreList"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    goto/16 :goto_94c

    :sswitch_1d8
    const-string v3, "SetInsertPoint"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7ff

    goto/16 :goto_94c

    :sswitch_1e2
    const-string v3, "CalculateJumpPower"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 881
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-wide v5, 0x4068866666666666L    # 196.2

    invoke-virtual {v3, v5, v6}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v5

    mul-double v5, v5, v16

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-wide v7, 0x401ccccccccccccdL    # 7.2

    invoke-virtual {v3, v7, v8}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v3

    mul-double/2addr v5, v3

    invoke-static {v5, v6}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v3

    invoke-static {v3, v4}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_216
    const-string v3, "Shapecast"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 883
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Instance"

    .local v5, "$this$ud\\37":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\37":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1086
    .local v8, "$i$f$ud\\37\\883":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_235

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_236

    :cond_235
    move-object v9, v6

    :goto_236
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v10, :cond_23b

    move-object v9, v6

    :cond_23b
    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v9, :cond_29a

    .line 883
    .end local v5    # "$this$ud\\37":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\37":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\37\\883":I
    invoke-virtual {v3, v9}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v4, "$this$ud\\38":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\38":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1086
    .local v7, "$i$f$ud\\38\\883":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_25c

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_25d

    :cond_25c
    move-object v8, v6

    :goto_25d
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_262

    move-object v6, v8

    :cond_262
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_279

    .line 883
    .end local v4    # "$this$ud\\38":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\38":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\38\\883":I
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v4

    invoke-direct {v0, v3, v6, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->raycastResult(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1086
    .restart local v4    # "$this$ud\\38":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "what\\38":Ljava/lang/String;
    .restart local v7    # "$i$f$ud\\38\\883":I
    :cond_279
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v3, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .end local v4    # "$this$ud\\38":Lorg/luaj/vm2/LuaValue;
    .local v5, "$this$ud\\37":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\37":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\37\\883":I
    :cond_29a
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .line 794
    .end local v5    # "$this$ud\\37":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\37":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\37\\883":I
    :sswitch_2bb
    const-string v3, "UnjoinFromOutsiders"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7ff

    goto/16 :goto_94c

    :sswitch_2c5
    const-string v3, "GetPartBoundsInBox"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 818
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "CFrame"

    .local v3, "$this$ud\\8":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\8":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1062
    .local v7, "$i$f$ud\\8\\818":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_2e2

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_2e3

    :cond_2e2
    move-object v8, v6

    :goto_2e3
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v9, :cond_2e8

    move-object v8, v6

    :cond_2e8
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v8, :cond_3ba

    .line 818
    .end local v3    # "$this$ud\\8":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\8":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\8\\818":I
    nop

    .local v8, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v3, "$this$ud\\9":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\9":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1062
    .local v5, "$i$f$ud\\9\\818":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_302

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_303

    :cond_302
    move-object v7, v6

    :goto_303
    instance-of v9, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_308

    move-object v6, v7

    :cond_308
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_399

    .line 818
    .end local v3    # "$this$ud\\9":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\9":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\9\\818":I
    nop

    .line 819
    .local v6, "size":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v3, v8, v6}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->worldAabb(Lcom/exampletest/mobilestudiotest/model/CFrame;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lkotlin/Pair;

    move-result-object v3

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v23, v4

    check-cast v23, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v23, "b0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v24, v3

    check-cast v24, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 820
    .local v24, "b1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v3

    .line 821
    .local v3, "f":Lkotlin/jvm/functions/Function1;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\10":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1063
    .local v5, "$i$f$filter\\10\\821":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\11":Ljava/util/Collection;
    move-object v9, v4

    .local v9, "$this$filterTo\\11":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1064
    .local v10, "$i$f$filterTo\\11\\1063":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_342
    :goto_342
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_38d

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\11":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v13, "it\\12":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v14, 0x0

    .line 821
    .local v14, "$i$a$-filter-InstanceApi$workspaceCall$1\\12\\1064\\0":I
    invoke-interface {v3, v13}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/Boolean;

    invoke-virtual {v15}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v15

    if-eqz v15, :cond_385

    sget-object v15, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v15, v13}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v15

    .line 1017
    const/16 v16, 0x0

    .local v16, "$i$a$-let-InstanceApi$workspaceCall$1$1\\13\\821\\12":I
    invoke-virtual {v15}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v21, v17

    check-cast v21, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v21, "x0\\13":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v15}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v22, v15

    check-cast v22, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 821
    .local v22, "x1\\13":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v20, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    const/16 v26, 0x10

    const/16 v27, 0x0

    const/16 v25, 0x0

    invoke-static/range {v20 .. v27}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap$default(Lcom/exampletest/mobilestudiotest/engine/Geometry;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FILjava/lang/Object;)Z

    move-result v15

    .end local v16    # "$i$a$-let-InstanceApi$workspaceCall$1$1\\13\\821\\12":I
    .end local v21    # "x0\\13":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v22    # "x1\\13":Lcom/exampletest/mobilestudiotest/model/Vector3;
    if-eqz v15, :cond_385

    move/from16 v13, v18

    goto :goto_387

    :cond_385
    move/from16 v13, v19

    .line 1064
    .end local v13    # "it\\12":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "$i$a$-filter-InstanceApi$workspaceCall$1\\12\\1064\\0":I
    :goto_387
    if-eqz v13, :cond_342

    invoke-interface {v7, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_342

    .line 1065
    .end local v12    # "element\\11":Ljava/lang/Object;
    :cond_38d
    nop

    .end local v7    # "destination\\11":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\11":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\11\\1063":I
    check-cast v7, Ljava/util/List;

    .line 1063
    nop

    .line 821
    .end local v4    # "$this$filter\\10":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\10\\821":I
    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v3

    .end local v3    # "f":Lkotlin/jvm/functions/Function1;
    .end local v6    # "size":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v23    # "b0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v24    # "b1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1062
    .local v3, "$this$ud\\9":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\9":Ljava/lang/String;
    .local v5, "$i$f$ud\\9\\818":I
    .restart local v8    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    :cond_399
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .end local v4    # "what\\9":Ljava/lang/String;
    .end local v8    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v3, "$this$ud\\8":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\8":Ljava/lang/String;
    .local v7, "$i$f$ud\\8\\818":I
    :cond_3ba
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\8":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\8":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\8\\818":I
    :sswitch_3db
    const-string v3, "GetNumAwakeParts"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 878
    invoke-static/range {v19 .. v19}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_3ee
    const-string v3, "FindPartsInRegion3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    goto/16 :goto_94c

    :sswitch_3f8
    const-string v3, "IsRegion3Empty"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    goto/16 :goto_94c

    :sswitch_402
    const-string v3, "FindPartsInRegion3WithIgnoreList"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    goto/16 :goto_94c

    :sswitch_40c
    const-string v3, "Spherecast"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_559

    goto/16 :goto_94c

    :sswitch_416
    const-string v3, "PGSIsEnabled"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 879
    sget-object v3, Lorg/luaj/vm2/LuaValue;->TRUE:Lorg/luaj/vm2/LuaBoolean;

    const-string v4, "TRUE"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_429
    const-string v3, "FindPartOnRay"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_80e

    goto/16 :goto_94c

    :sswitch_433
    const-string v3, "JoinToOutsiders"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7ff

    goto/16 :goto_94c

    :sswitch_43d
    const-string v3, "CalculateJumpHeight"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 882
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-wide v5, 0x4068866666666666L    # 196.2

    invoke-virtual {v3, v5, v6}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v5

    .local v5, "g":D
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-wide/high16 v7, 0x4049000000000000L    # 50.0

    invoke-virtual {v3, v7, v8}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v3

    .local v3, "jp":D
    mul-double v7, v3, v3

    mul-double v9, v5, v16

    div-double/2addr v7, v9

    invoke-static {v7, v8}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v3

    .end local v3    # "jp":D
    .end local v5    # "g":D
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_46c
    const-string v3, "GetPartsInPart"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 834
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Instance"

    .local v3, "$this$ud\\18":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\18":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1070
    .local v7, "$i$f$ud\\18\\834":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_489

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_48a

    :cond_489
    move-object v8, v6

    :goto_48a
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v9, :cond_48f

    move-object v6, v8

    :cond_48f
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v6, :cond_532

    .line 834
    .end local v3    # "$this$ud\\18":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\18":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\18\\834":I
    nop

    .line 835
    .local v6, "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v3, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v3

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v5

    move-object v10, v5

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v10, "b0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    move-object v11, v3

    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 836
    .local v11, "b1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v3

    .line 837
    .local v3, "f":Lkotlin/jvm/functions/Function1;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\19":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1071
    .local v5, "$i$f$filter\\19\\837":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    move-object v15, v7

    check-cast v15, Ljava/util/Collection;

    .local v15, "destination\\20":Ljava/util/Collection;
    move-object/from16 v16, v4

    .local v16, "$this$filterTo\\20":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 1072
    .local v17, "$i$f$filterTo\\20\\1071":I
    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v20

    :goto_4ca
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_524

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\20":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v21, 0x0

    .line 837
    .local v21, "$i$a$-filter-InstanceApi$workspaceCall$3\\21\\1072\\0":I
    if-eq v8, v6, :cond_515

    invoke-interface {v3, v8}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Boolean;

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-eqz v9, :cond_515

    sget-object v9, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v9, v8}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v9

    .line 1017
    const/16 v22, 0x0

    .local v22, "$i$a$-let-InstanceApi$workspaceCall$3$1\\22\\837\\21":I
    invoke-virtual {v9}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v12, "x0\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v9}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 837
    .local v9, "x1\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object v13, v7

    .end local v7    # "element\\20":Ljava/lang/Object;
    .local v13, "element\\20":Ljava/lang/Object;
    sget-object v7, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    move-object v14, v13

    .end local v13    # "element\\20":Ljava/lang/Object;
    .local v14, "element\\20":Ljava/lang/Object;
    const/16 v13, 0x10

    move-object/from16 v23, v14

    .end local v14    # "element\\20":Ljava/lang/Object;
    .local v23, "element\\20":Ljava/lang/Object;
    const/4 v14, 0x0

    move-object/from16 v24, v8

    move-object v8, v12

    .end local v12    # "x0\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v8, "x0\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v24, "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v12, 0x0

    move-object/from16 v25, v3

    move-object/from16 v3, v23

    .end local v23    # "element\\20":Ljava/lang/Object;
    .local v3, "element\\20":Ljava/lang/Object;
    .local v25, "f":Lkotlin/jvm/functions/Function1;
    invoke-static/range {v7 .. v14}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap$default(Lcom/exampletest/mobilestudiotest/engine/Geometry;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FILjava/lang/Object;)Z

    move-result v7

    .end local v8    # "x0\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "x1\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v22    # "$i$a$-let-InstanceApi$workspaceCall$3$1\\22\\837\\21":I
    if-eqz v7, :cond_51a

    move/from16 v7, v18

    goto :goto_51c

    .end local v24    # "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v25    # "f":Lkotlin/jvm/functions/Function1;
    .local v3, "f":Lkotlin/jvm/functions/Function1;
    .restart local v7    # "element\\20":Ljava/lang/Object;
    .local v8, "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_515
    move-object/from16 v25, v3

    move-object v3, v7

    move-object/from16 v24, v8

    .end local v7    # "element\\20":Ljava/lang/Object;
    .end local v8    # "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v3, "element\\20":Ljava/lang/Object;
    .restart local v24    # "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v25    # "f":Lkotlin/jvm/functions/Function1;
    :cond_51a
    move/from16 v7, v19

    .line 1072
    .end local v21    # "$i$a$-filter-InstanceApi$workspaceCall$3\\21\\1072\\0":I
    .end local v24    # "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_51c
    if-eqz v7, :cond_521

    invoke-interface {v15, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_521
    move-object/from16 v3, v25

    goto :goto_4ca

    .line 1073
    .end local v25    # "f":Lkotlin/jvm/functions/Function1;
    .local v3, "f":Lkotlin/jvm/functions/Function1;
    :cond_524
    move-object/from16 v25, v3

    .end local v3    # "f":Lkotlin/jvm/functions/Function1;
    .end local v15    # "destination\\20":Ljava/util/Collection;
    .end local v16    # "$this$filterTo\\20":Ljava/lang/Iterable;
    .end local v17    # "$i$f$filterTo\\20\\1071":I
    .restart local v25    # "f":Lkotlin/jvm/functions/Function1;
    move-object v3, v15

    check-cast v3, Ljava/util/List;

    .line 1071
    nop

    .line 837
    .end local v4    # "$this$filter\\19":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\19\\837":I
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v3

    .end local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v10    # "b0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "b1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v25    # "f":Lkotlin/jvm/functions/Function1;
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1070
    .local v3, "$this$ud\\18":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\18":Ljava/lang/String;
    .local v7, "$i$f$ud\\18\\834":I
    :cond_532
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\18":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\18":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\18\\834":I
    :sswitch_553
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 797
    :cond_559
    invoke-static {v1, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5a4

    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "CFrame"

    .local v3, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\3":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1058
    .local v5, "$i$f$ud\\3\\797":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_574

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_575

    :cond_574
    move-object v7, v6

    :goto_575
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v8, :cond_57a

    move-object v7, v6

    :cond_57a
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v7, :cond_583

    .line 797
    .end local v3    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\3":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\3\\797":I
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    goto :goto_5c4

    .line 1058
    .restart local v3    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .restart local v4    # "what\\3":Ljava/lang/String;
    .restart local v5    # "$i$f$ud\\3\\797":I
    :cond_583
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .line 797
    .end local v3    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\3":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\3\\797":I
    :cond_5a4
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v3, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\4":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1058
    .local v5, "$i$f$ud\\4\\797":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_5b9

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_5ba

    :cond_5b9
    move-object v7, v6

    :goto_5ba
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v8, :cond_5bf

    move-object v7, v6

    :cond_5bf
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v7, :cond_619

    move-object v3, v7

    .line 797
    .end local v3    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\4":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\4\\797":I
    :goto_5c4
    nop

    .line 798
    .local v3, "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v4, "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\5":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1059
    .local v7, "$i$f$ud\\5\\798":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_5da

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_5db

    :cond_5da
    move-object v8, v6

    :goto_5db
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_5e0

    move-object v6, v8

    :cond_5e0
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_5f8

    .line 798
    .end local v4    # "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\5":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\5\\798":I
    const/4 v4, 0x5

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v4

    invoke-direct {v0, v3, v6, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->raycastResult(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    .end local v3    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1059
    .restart local v3    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v4    # "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "what\\5":Ljava/lang/String;
    .restart local v7    # "$i$f$ud\\5\\798":I
    :cond_5f8
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v8, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v8, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v6, v8}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .line 1058
    .end local v7    # "$i$f$ud\\5\\798":I
    .local v3, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\4":Ljava/lang/String;
    .local v5, "$i$f$ud\\4\\797":I
    :cond_619
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .line 794
    .end local v3    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\4":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\4\\797":I
    :sswitch_63a
    const-string v3, "Raycast"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 795
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v3, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\1":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1057
    .local v7, "$i$f$ud\\1\\795":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_657

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_658

    :cond_657
    move-object v8, v6

    :goto_658
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v9, :cond_65d

    move-object v8, v6

    :cond_65d
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_6b4

    .line 795
    .end local v3    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\1":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\1\\795":I
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v3, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\2":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1057
    .local v5, "$i$f$ud\\2\\795":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_676

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_677

    :cond_676
    move-object v7, v6

    :goto_677
    instance-of v9, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_67c

    move-object v6, v7

    :cond_67c
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_693

    .line 795
    .end local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\2":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\2\\795":I
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v3

    invoke-direct {v0, v8, v6, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->raycastResult(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1057
    .restart local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v4    # "what\\2":Ljava/lang/String;
    .restart local v5    # "$i$f$ud\\2\\795":I
    :cond_693
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .end local v4    # "what\\2":Ljava/lang/String;
    .local v3, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\1":Ljava/lang/String;
    .restart local v7    # "$i$f$ud\\1\\795":I
    :cond_6b4
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\1":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\1\\795":I
    :sswitch_6d5
    const-string v3, "ArePartsTouchingOthers"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 872
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v3

    .line 873
    .local v3, "parts":Ljava/util/List;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    const-wide/16 v5, 0x0

    invoke-virtual {v4, v5, v6}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v4

    double-to-float v4, v4

    .line 874
    .local v4, "pad":F
    new-instance v5, Ljava/util/IdentityHashMap;

    invoke-direct {v5}, Ljava/util/IdentityHashMap;-><init>()V

    check-cast v5, Ljava/util/Map;

    invoke-static {v5}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v5

    move-object v6, v5

    .line 1017
    .local v6, "it\\28":Ljava/util/Set;
    const/4 v7, 0x0

    .line 874
    .local v7, "$i$a$-also-InstanceApi$workspaceCall$set$1\\28\\874\\0":I
    move-object v8, v3

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v6, v8}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 875
    .end local v6    # "it\\28":Ljava/util/Set;
    .end local v7    # "$i$a$-also-InstanceApi$workspaceCall$set$1\\28\\874\\0":I
    .local v5, "set":Ljava/util/Set;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$filter\\29":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1080
    .local v7, "$i$f$filter\\29\\875":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\30":Ljava/util/Collection;
    move-object v9, v6

    .local v9, "$this$filterTo\\30":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1081
    .local v10, "$i$f$filterTo\\30\\1080":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_71a
    :goto_71a
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_732

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\30":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v13, "it\\31":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v14, 0x0

    .line 875
    .local v14, "$i$a$-filter-InstanceApi$workspaceCall$others$1\\31\\1081\\0":I
    invoke-interface {v5, v13}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v15

    .line 1081
    .end local v13    # "it\\31":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "$i$a$-filter-InstanceApi$workspaceCall$others$1\\31\\1081\\0":I
    if-nez v15, :cond_71a

    invoke-interface {v8, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_71a

    .line 1082
    .end local v12    # "element\\30":Ljava/lang/Object;
    :cond_732
    nop

    .end local v8    # "destination\\30":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\30":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\30\\1080":I
    check-cast v8, Ljava/util/List;

    .line 1080
    nop

    .line 875
    .end local v6    # "$this$filter\\29":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filter\\29\\875":I
    nop

    .line 876
    .local v8, "others":Ljava/util/List;
    move-object v6, v3

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$any\\32":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1083
    .local v7, "$i$f$any\\32\\876":I
    instance-of v9, v6, Ljava/util/Collection;

    if-eqz v9, :cond_750

    move-object v9, v6

    check-cast v9, Ljava/util/Collection;

    invoke-interface {v9}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_750

    move-object/from16 v17, v3

    move-object/from16 v27, v5

    move/from16 v15, v19

    goto/16 :goto_7eb

    .line 1084
    :cond_750
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_754
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_7e5

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\32":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v11, "p\\33":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v12, 0x0

    .line 876
    .local v12, "$i$a$-any-InstanceApi$workspaceCall$4\\33\\1084\\0":I
    sget-object v13, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v13, v11}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v13

    invoke-virtual {v13}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v14

    move-object/from16 v21, v14

    check-cast v21, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v21, "a0\\33":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v13}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v13

    move-object/from16 v22, v13

    check-cast v22, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v22, "a1\\33":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object v13, v8

    check-cast v13, Ljava/lang/Iterable;

    .local v13, "$this$any\\34":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 1083
    .local v14, "$i$f$any\\34\\876":I
    instance-of v15, v13, Ljava/util/Collection;

    if-eqz v15, :cond_790

    move-object v15, v13

    check-cast v15, Ljava/util/Collection;

    invoke-interface {v15}, Ljava/util/Collection;->isEmpty()Z

    move-result v15

    if-eqz v15, :cond_790

    move-object/from16 v17, v3

    move-object/from16 v27, v5

    move/from16 v3, v19

    goto :goto_7d9

    .line 1084
    :cond_790
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_794
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_7d3

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v17, v3

    .end local v3    # "parts":Ljava/util/List;
    .local v16, "element\\34":Ljava/lang/Object;
    .local v17, "parts":Ljava/util/List;
    move-object/from16 v3, v16

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v3, "o\\35":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v26, 0x0

    .line 876
    .local v26, "$i$a$-any-InstanceApi$workspaceCall$4$1\\35\\1084\\33":I
    move-object/from16 v27, v5

    .end local v5    # "set":Ljava/util/Set;
    .local v27, "set":Ljava/util/Set;
    sget-object v5, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v5

    .line 1017
    const/16 v28, 0x0

    .local v28, "$i$a$-let-InstanceApi$workspaceCall$4$1$1\\36\\876\\35":I
    invoke-virtual {v5}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v20

    move-object/from16 v23, v20

    check-cast v23, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v23, "b0\\36":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v5}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v24, v5

    check-cast v24, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 876
    .local v24, "b1\\36":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v20, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    neg-float v5, v4

    move/from16 v25, v5

    invoke-virtual/range {v20 .. v25}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;F)Z

    move-result v5

    .line 1084
    .end local v3    # "o\\35":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v23    # "b0\\36":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v24    # "b1\\36":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v26    # "$i$a$-any-InstanceApi$workspaceCall$4$1\\35\\1084\\33":I
    .end local v28    # "$i$a$-let-InstanceApi$workspaceCall$4$1$1\\36\\876\\35":I
    if-eqz v5, :cond_7ce

    move/from16 v3, v18

    goto :goto_7d9

    :cond_7ce
    move-object/from16 v3, v17

    move-object/from16 v5, v27

    goto :goto_794

    .line 1085
    .end local v16    # "element\\34":Ljava/lang/Object;
    .end local v17    # "parts":Ljava/util/List;
    .end local v27    # "set":Ljava/util/Set;
    .local v3, "parts":Ljava/util/List;
    .restart local v5    # "set":Ljava/util/Set;
    :cond_7d3
    move-object/from16 v17, v3

    move-object/from16 v27, v5

    .end local v3    # "parts":Ljava/util/List;
    .end local v5    # "set":Ljava/util/Set;
    .restart local v17    # "parts":Ljava/util/List;
    .restart local v27    # "set":Ljava/util/Set;
    move/from16 v3, v19

    .line 876
    .end local v13    # "$this$any\\34":Ljava/lang/Iterable;
    .end local v14    # "$i$f$any\\34\\876":I
    :goto_7d9
    nop

    .line 1084
    .end local v11    # "p\\33":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v12    # "$i$a$-any-InstanceApi$workspaceCall$4\\33\\1084\\0":I
    .end local v21    # "a0\\33":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v22    # "a1\\33":Lcom/exampletest/mobilestudiotest/model/Vector3;
    if-eqz v3, :cond_7df

    move/from16 v15, v18

    goto :goto_7eb

    :cond_7df
    move-object/from16 v3, v17

    move-object/from16 v5, v27

    goto/16 :goto_754

    .line 1085
    .end local v10    # "element\\32":Ljava/lang/Object;
    .end local v17    # "parts":Ljava/util/List;
    .end local v27    # "set":Ljava/util/Set;
    .restart local v3    # "parts":Ljava/util/List;
    .restart local v5    # "set":Ljava/util/Set;
    :cond_7e5
    move-object/from16 v17, v3

    move-object/from16 v27, v5

    .end local v3    # "parts":Ljava/util/List;
    .end local v5    # "set":Ljava/util/Set;
    .restart local v17    # "parts":Ljava/util/List;
    .restart local v27    # "set":Ljava/util/Set;
    move/from16 v15, v19

    .line 876
    .end local v6    # "$this$any\\32":Ljava/lang/Iterable;
    .end local v7    # "$i$f$any\\32\\876":I
    :goto_7eb
    invoke-static {v15}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v3

    .line 871
    .end local v4    # "pad":F
    .end local v8    # "others":Ljava/util/List;
    .end local v17    # "parts":Ljava/util/List;
    .end local v27    # "set":Ljava/util/Set;
    nop

    .line 872
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_7f7
    const-string v3, "ZoomToExtents"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 861
    :cond_7ff
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v3, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_808
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 801
    :cond_80e
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Ray"

    .local v3, "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\6":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1060
    .local v8, "$i$f$ud\\6\\801":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v10

    if-eqz v10, :cond_823

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v10

    goto :goto_824

    :cond_823
    move-object v10, v6

    :goto_824
    instance-of v11, v10, Lcom/exampletest/mobilestudiotest/model/Ray;

    if-nez v11, :cond_829

    move-object v10, v6

    :cond_829
    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Ray;

    if-eqz v10, :cond_925

    .line 801
    .end local v3    # "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\6":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\6\\801":I
    nop

    .line 802
    .local v10, "ray":Lcom/exampletest/mobilestudiotest/model/Ray;
    nop

    .line 803
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v3

    if-eqz v3, :cond_845

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v3

    goto :goto_873

    .line 804
    :cond_845
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    if-eqz v3, :cond_86f

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v3, "$this$udOrNull\\7":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 1061
    .local v7, "$i$f$udOrNull\\7\\804":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_862

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_863

    :cond_862
    move-object v8, v6

    :goto_863
    instance-of v11, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v11, :cond_868

    move-object v8, v6

    :cond_868
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 804
    .end local v3    # "$this$udOrNull\\7":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\7\\804":I
    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOfNotNull(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    goto :goto_873

    .line 805
    :cond_86f
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v3

    .line 802
    :goto_873
    nop

    .line 807
    .local v3, "list":Ljava/util/List;
    invoke-static {v1, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    .line 808
    .local v7, "white":Z
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v8

    .line 809
    .local v8, "len":F
    const v9, 0x358637bd    # 1.0E-6f

    cmpg-float v9, v8, v9

    if-gez v9, :cond_88a

    move/from16 v24, v8

    goto :goto_8a9

    :cond_88a
    sget-object v20, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v21

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getOrigin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v22

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v23

    new-instance v6, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;

    invoke-direct {v6, v3, v7}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;-><init>(Ljava/util/List;Z)V

    move-object/from16 v25, v6

    move/from16 v24, v8

    .end local v8    # "len":F
    .local v24, "len":F
    invoke-virtual/range {v20 .. v25}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->raycast(Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FLkotlin/jvm/functions/Function1;)Lcom/exampletest/mobilestudiotest/engine/RayHit;

    move-result-object v6

    .line 813
    .local v6, "hit":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    :goto_8a9
    if-nez v6, :cond_8c7

    sget-object v4, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getOrigin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual {v5, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    check-cast v5, Lorg/luaj/vm2/Varargs;

    invoke-static {v4, v5}, Lorg/luaj/vm2/LuaValue;->varargsOf(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v4

    move-object v3, v4

    goto :goto_91f

    .line 814
    :cond_8c7
    new-array v8, v13, [Lorg/luaj/vm2/LuaValue;

    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    aput-object v9, v8, v19

    sget-object v9, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    aput-object v9, v8, v18

    sget-object v9, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getNormal()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    aput-object v9, v8, v5

    .line 815
    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v9, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    sget-object v11, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    sget-object v12, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v13

    invoke-virtual {v12, v13}, Lcom/exampletest/mobilestudiotest/model/PartData;->material(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v12

    const-string v13, "Material"

    invoke-virtual {v11, v13, v12}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_907

    const-string v11, "Plastic"

    :cond_907
    sget-object v12, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v14

    invoke-virtual {v12, v14}, Lcom/exampletest/mobilestudiotest/model/PartData;->material(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v12

    invoke-direct {v9, v13, v11, v12}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v5, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    aput-object v5, v8, v4

    .line 814
    invoke-static {v8}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v4

    move-object v3, v4

    .line 800
    .end local v3    # "list":Ljava/util/List;
    .end local v6    # "hit":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .end local v7    # "white":Z
    .end local v10    # "ray":Lcom/exampletest/mobilestudiotest/model/Ray;
    .end local v24    # "len":F
    :goto_91f
    nop

    .line 804
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    goto/16 :goto_ab2

    .line 1060
    .local v3, "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\6":Ljava/lang/String;
    .local v8, "$i$f$ud\\6\\801":I
    :cond_925
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\6":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\6\\801":I
    :sswitch_946
    invoke-virtual {v1, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    :cond_94c
    :goto_94c
    goto/16 :goto_aab

    .line 840
    :cond_94e
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Region3"

    .local v3, "$this$ud\\23":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\23":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1074
    .local v8, "$i$f$ud\\23\\840":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_963

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_964

    :cond_963
    move-object v9, v6

    :goto_964
    instance-of v11, v9, Lcom/exampletest/mobilestudiotest/lua/Region3V;

    if-nez v11, :cond_969

    move-object v9, v6

    :cond_969
    check-cast v9, Lcom/exampletest/mobilestudiotest/lua/Region3V;

    if-eqz v9, :cond_a8a

    .line 840
    .end local v3    # "$this$ud\\23":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\23":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\23\\840":I
    nop

    .line 841
    .local v9, "r":Lcom/exampletest/mobilestudiotest/lua/Region3V;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    .line 842
    .local v3, "listArg":Lorg/luaj/vm2/LuaValue;
    nop

    .line 843
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v4

    if-eqz v4, :cond_981

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v4

    goto :goto_9a8

    .line 844
    :cond_981
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_9a4

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v4, v3

    .local v4, "$this$udOrNull\\24":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 1075
    .local v7, "$i$f$udOrNull\\24\\844":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_997

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_998

    :cond_997
    move-object v8, v6

    :goto_998
    instance-of v11, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v11, :cond_99d

    move-object v8, v6

    :cond_99d
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 844
    .end local v4    # "$this$udOrNull\\24":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\24\\844":I
    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOfNotNull(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    goto :goto_9a8

    .line 845
    :cond_9a4
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v4

    .line 842
    :goto_9a8
    nop

    .line 847
    .local v4, "list":Ljava/util/List;
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    .line 848
    .local v7, "white":Z
    const-string v8, "Is"

    move/from16 v10, v19

    invoke-static {v1, v8, v10, v5, v6}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_9bb

    move/from16 v10, v18

    move v11, v10

    goto :goto_9cb

    :cond_9bb
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v10

    const/16 v11, 0x14

    invoke-virtual {v10, v11}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v10

    move/from16 v11, v18

    invoke-static {v10, v11}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v10

    .line 849
    .local v10, "max":I
    :goto_9cb
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 850
    .local v12, "out":Ljava/util/ArrayList;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v13

    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_9d8
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_a68

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 851
    .local v14, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    move-object v15, v4

    check-cast v15, Ljava/lang/Iterable;

    .local v15, "$this$any\\25":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 1076
    .local v16, "$i$f$any\\25\\851":I
    instance-of v11, v15, Ljava/util/Collection;

    if-eqz v11, :cond_9f8

    move-object v11, v15

    check-cast v11, Ljava/util/Collection;

    invoke-interface {v11}, Ljava/util/Collection;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_9f8

    const/4 v5, 0x0

    goto :goto_a1e

    .line 1077
    :cond_9f8
    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_9fc
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_a1d

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    .local v17, "element\\25":Ljava/lang/Object;
    move-object/from16 v5, v17

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v5, "f\\26":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v21, 0x0

    .line 851
    .local v21, "$i$a$-any-InstanceApi$workspaceCall$inList$1\\26\\1077\\0":I
    if-eq v14, v5, :cond_a16

    invoke-virtual {v14, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v22

    if-nez v22, :cond_a16

    const/4 v5, 0x0

    goto :goto_a17

    :cond_a16
    const/4 v5, 0x1

    .line 1077
    .end local v5    # "f\\26":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v21    # "$i$a$-any-InstanceApi$workspaceCall$inList$1\\26\\1077\\0":I
    :goto_a17
    if-eqz v5, :cond_a1b

    const/4 v5, 0x1

    goto :goto_a1e

    :cond_a1b
    const/4 v5, 0x2

    goto :goto_9fc

    .line 1078
    .end local v17    # "element\\25":Ljava/lang/Object;
    :cond_a1d
    const/4 v5, 0x0

    .line 851
    .end local v15    # "$this$any\\25":Ljava/lang/Iterable;
    .end local v16    # "$i$f$any\\25\\851":I
    :goto_a1e
    nop

    .line 852
    .local v5, "inList":Z
    if-eqz v7, :cond_a27

    if-nez v5, :cond_a25

    const/4 v11, 0x1

    goto :goto_a28

    :cond_a25
    const/4 v11, 0x0

    goto :goto_a28

    :cond_a27
    move v11, v5

    :goto_a28
    if-nez v11, :cond_a64

    .line 853
    sget-object v11, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v11, v14}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v11

    invoke-virtual {v11}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v22, v15

    check-cast v22, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v22, "x0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v11}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v11

    move-object/from16 v23, v11

    check-cast v23, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 854
    .local v23, "x1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v21, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v24

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v25

    const/16 v27, 0x10

    const/16 v28, 0x0

    const/16 v26, 0x0

    invoke-static/range {v21 .. v28}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap$default(Lcom/exampletest/mobilestudiotest/engine/Geometry;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FILjava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_a60

    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-lt v11, v10, :cond_a60

    goto :goto_a68

    :cond_a60
    const/4 v5, 0x2

    const/4 v11, 0x1

    goto/16 :goto_9d8

    .line 852
    .end local v22    # "x0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v23    # "x1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_a64
    const/4 v5, 0x2

    const/4 v11, 0x1

    goto/16 :goto_9d8

    .line 856
    .end local v5    # "inList":Z
    .end local v14    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_a68
    :goto_a68
    const/4 v5, 0x2

    const/4 v11, 0x0

    invoke-static {v1, v8, v11, v5, v6}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_a79

    invoke-virtual {v12}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    invoke-static {v5}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v5

    goto :goto_a80

    :cond_a79
    move-object v5, v12

    check-cast v5, Ljava/util/List;

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v5

    :goto_a80
    check-cast v5, Lorg/luaj/vm2/LuaValue;

    .line 839
    .end local v3    # "listArg":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "list":Ljava/util/List;
    .end local v7    # "white":Z
    .end local v9    # "r":Lcom/exampletest/mobilestudiotest/lua/Region3V;
    .end local v10    # "max":I
    .end local v12    # "out":Ljava/util/ArrayList;
    nop

    .line 854
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v3, v5

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto :goto_ab2

    .line 1074
    .local v3, "$this$ud\\23":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\23":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\23\\840":I
    :cond_a8a
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 884
    .end local v3    # "$this$ud\\23":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\23":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\23\\840":I
    :goto_aab
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v3, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    .line 794
    :goto_ab2
    return-object v3

    nop

    :sswitch_data_ab4
    .sparse-switch
        -0x7db55d12 -> :sswitch_946
        -0x7a472b5e -> :sswitch_808
        -0x76fdb725 -> :sswitch_7f7
        -0x725cc24e -> :sswitch_6d5
        -0x61e359b7 -> :sswitch_63a
        -0x5486aed4 -> :sswitch_553
        -0x4f4cc35e -> :sswitch_46c
        -0x381ec925 -> :sswitch_43d
        -0x30e4e13f -> :sswitch_433
        -0x2ea0a841 -> :sswitch_429
        -0x244c1f25 -> :sswitch_416
        -0x13a9ef54 -> :sswitch_40c
        -0x12d63417 -> :sswitch_402
        -0x38f64c8 -> :sswitch_3f8
        0xdbe613 -> :sswitch_3ee
        0xcf234eb -> :sswitch_3db
        0x113f98a8 -> :sswitch_2c5
        0x120e9b79 -> :sswitch_2bb
        0x15c33240 -> :sswitch_216
        0x27f05cd1 -> :sswitch_1e2
        0x2d86f4b5 -> :sswitch_1d8
        0x34941c4e -> :sswitch_1ce
        0x372819fe -> :sswitch_162
        0x4e981678 -> :sswitch_14d
        0x52468895 -> :sswitch_6e
        0x55bee095 -> :sswitch_64
        0x6b0d0636 -> :sswitch_4f
        0x76f51870 -> :sswitch_31
    .end sparse-switch
.end method
