.method public final forFamily(Ljava/lang/String;IZ)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    .registers 16
    .param p1, "familyRaw"    # Ljava/lang/String;
    .param p2, "weight"    # I
    .param p3, "italic"    # Z

    const-string v0, "familyRaw"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    const/16 v0, 0x2f

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0, v1, v2, v1}, Lkotlin/text/StringsKt;->substringAfterLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/16 v3, 0x2e

    invoke-static {v0, v3, v1, v2, v1}, Lkotlin/text/StringsKt;->substringBefore$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "toLowerCase(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .local v0, "fam":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v3, 0x384

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v6, "legacyarial"

    const/4 v7, 0x1

    const/16 v8, 0x190

    .line 44
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    .line 43
    const/16 v9, 0x2bc

    .line 44
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    .line 43
    const/4 v11, 0x0

    sparse-switch v1, :sswitch_data_3a6

    goto/16 :goto_393

    :sswitch_3b
    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_104

    goto/16 :goto_393

    :sswitch_43
    const-string v1, "sarpanch"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 67
    const-string v1, "Sarpanch"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_53
    const-string v1, "accanthisadfstd"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b2

    goto/16 :goto_393

    :sswitch_5d
    const-string v1, "gothamssm"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2dc

    goto/16 :goto_393

    :sswitch_67
    const-string v1, "notosans"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 75
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    goto/16 :goto_3a4

    .line 43
    :sswitch_7a
    const-string v1, "denkone"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 61
    const-string v1, "DenkOne"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_8a
    const-string v1, "balthazar"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b2

    goto/16 :goto_393

    :sswitch_94
    const-string v1, "highwaygothic"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f5

    goto/16 :goto_393

    :sswitch_9e
    const-string v1, "creepster"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 58
    const-string v1, "Creepster"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_ae
    const-string v1, "permanentmarker"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 52
    const-string v1, "PermanentMarker"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_be
    const-string v1, "indieflower"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 59
    const-string v1, "IndieFlower"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_ce
    const-string v1, "sourcesanspro"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_268

    goto/16 :goto_393

    :sswitch_d8
    const-string v1, "comicneueangular"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_32d

    goto/16 :goto_393

    :sswitch_e2
    const-string v1, "kalam"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 65
    const-string v1, "Kalam"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_f2
    const-string v1, "arimo"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_104

    goto/16 :goto_393

    :sswitch_fc
    const-string v1, "arial"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 47
    :cond_104
    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10b

    move v9, p2

    :cond_10b
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "Arimo-Regular"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "Arimo-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, v9, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_127
    const-string v1, "jura"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 66
    const-string v1, "Jura"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_137
    const-string v1, "guru"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_366

    goto/16 :goto_393

    :sswitch_141
    const-string v1, "josefinsans"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 70
    const-string v1, "JosefinSans"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_151
    const-string v1, "inconsolata"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 72
    const-string v1, "Inconsolata"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_161
    const-string v1, "titilliumweb"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 64
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "TitilliumWeb"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "TitilliumWeb-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_185
    const-string v1, "bangers"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 50
    const-string v1, "Bangers"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_195
    const-string v1, "pressstart2p"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 51
    const-string v1, "PressStart2P"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_1a5
    const-string v1, "zekton"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_357

    goto/16 :goto_393

    :sswitch_1af
    const-string v1, "ubuntu"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 55
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "Ubuntu"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "Ubuntu-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_1d3
    const-string v1, "grenzegotisch"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 68
    const-string v1, "GrenzeGotisch"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_1e3
    const-string v1, "roboto"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_31a

    goto/16 :goto_393

    :sswitch_1ed
    const-string v1, "robotocondensed"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 74
    :cond_1f5
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "RobotoCondensed"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "RobotoCondensed-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_211
    const-string v1, "fredokaone"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 48
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    const-string v2, "FredokaOne"

    invoke-direct {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->asset(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v2

    if-nez v2, :cond_227

    invoke-direct {p0, v9, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    :cond_227
    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    goto/16 :goto_3a4

    .line 43
    :sswitch_22c
    const-string v1, "oswald"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 53
    const-string v1, "Oswald"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_23c
    const-string v1, "nunito"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 54
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "Nunito"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "Nunito-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_260
    const-string v1, "sourcesans"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 45
    :cond_268
    if-eqz p3, :cond_272

    const-string v1, "SourceSans-Italic"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    :cond_272
    new-array v1, v5, [Lkotlin/Pair;

    const/16 v3, 0x12c

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v5, "SourceSans-Light"

    invoke-static {v3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v1, v11

    const-string v3, "SourceSans-Regular"

    invoke-static {v8, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v1, v7

    const/16 v3, 0x258

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v5, "SourceSans-Semibold"

    invoke-static {v3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v1, v2

    const-string v2, "SourceSans-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v4

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, v11, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_2aa
    const-string v1, "merriweather"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 56
    :cond_2b2
    const-string v1, "Merriweather"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_2ba
    const-string v1, "gotham"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2dc

    goto/16 :goto_393

    :sswitch_2c4
    const-string v1, "specialelite"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 63
    const-string v1, "SpecialElite"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_2d4
    const-string v1, "montserrat"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 44
    :cond_2dc
    new-array v1, v5, [Lkotlin/Pair;

    const-string v5, "Montserrat-Regular"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    aput-object v5, v1, v11

    const/16 v5, 0x1f4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v6, "Montserrat-Medium"

    invoke-static {v5, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    aput-object v5, v1, v7

    const-string v5, "Montserrat-Bold"

    invoke-static {v10, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    aput-object v5, v1, v2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "Montserrat-Black"

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v4

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_312
    const-string v1, "buildersans"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 46
    :cond_31a
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    goto/16 :goto_3a4

    .line 43
    :sswitch_325
    const-string v1, "comicneue"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 73
    :cond_32d
    const-string v1, "ComicNeue"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_335
    const-string v1, "luckiestguy"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 49
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    const-string v2, "LuckiestGuy"

    invoke-direct {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->asset(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v2

    if-nez v2, :cond_34b

    invoke-direct {p0, v3, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    :cond_34b
    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    goto :goto_3a4

    .line 43
    :sswitch_34f
    const-string v1, "michroma"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 57
    :cond_357
    const-string v1, "Michroma"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 43
    :sswitch_35e
    const-string v1, "fondamento"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 69
    :cond_366
    const-string v1, "Fondamento"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 43
    :sswitch_36d
    const-string v1, "robotomono"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 71
    const-string v1, "RobotoMono"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 43
    :sswitch_37c
    const-string v1, "amaticsc"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 60
    const-string v1, "AmaticSC"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 43
    :sswitch_38b
    const-string v1, "patrickhand"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_394

    :cond_393
    :goto_393
    goto :goto_39b

    .line 62
    :cond_394
    const-string v1, "PatrickHand"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 76
    :goto_39b
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    .line 43
    :goto_3a4
    return-object v1

    nop

    :sswitch_data_3a6
    .sparse-switch
        -0x7963008f -> :sswitch_38b
        -0x718ccd37 -> :sswitch_37c
        -0x6d570c58 -> :sswitch_36d
        -0x68aab3f1 -> :sswitch_35e
        -0x63d2c4ee -> :sswitch_34f
        -0x630c9523 -> :sswitch_335
        -0x600be89e -> :sswitch_325
        -0x5b0d9552 -> :sswitch_312
        -0x4df87353 -> :sswitch_2d4
        -0x4b0ebe86 -> :sswitch_2c4
        -0x49ea5978 -> :sswitch_2ba
        -0x47aca2bd -> :sswitch_2aa
        -0x42315cd2 -> :sswitch_260
        -0x3da69443 -> :sswitch_23c
        -0x3c09f25a -> :sswitch_22c
        -0x3b021f94 -> :sswitch_211
        -0x39098c7e -> :sswitch_1ed
        -0x372d1cbb -> :sswitch_1e3
        -0x35502044 -> :sswitch_1d3
        -0x32bd2519 -> :sswitch_1af
        -0x2a0f194d -> :sswitch_1a5
        -0x1fa62b43 -> :sswitch_195
        -0x1418c7d2 -> :sswitch_185
        -0x126a19e3 -> :sswitch_161
        -0x10112885 -> :sswitch_151
        -0x9b50f19 -> :sswitch_141
        0x3097b1 -> :sswitch_137
        0x31f4ba -> :sswitch_127
        0x58c5083 -> :sswitch_fc
        0x58c51fa -> :sswitch_f2
        0x6118c82 -> :sswitch_e2
        0x119b0440 -> :sswitch_d8
        0x11a118bf -> :sswitch_ce
        0x227c8b56 -> :sswitch_be
        0x25522e68 -> :sswitch_ae
        0x2a4c0f4f -> :sswitch_9e
        0x31fa9bc3 -> :sswitch_94
        0x3b7f20eb -> :sswitch_8a
        0x5c8907a8 -> :sswitch_7a
        0x5ed9128f -> :sswitch_67
        0x61802a85 -> :sswitch_5d
        0x7d3bf5ac -> :sswitch_53
        0x7e441c5e -> :sswitch_43
        0x7e5f525a -> :sswitch_3b
    .end sparse-switch
.end method
