.method private final layoutChildren(Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/graphics/RectF;F)Ljava/util/List;
    .registers 57
    .param p1, "parent"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "area"    # Landroid/graphics/RectF;
    .param p3, "scale"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Landroid/graphics/RectF;",
            "F)",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;",
            ">;"
        }
    .end annotation

    .line 634
    move-object/from16 v0, p0

    move-object/from16 v5, p2

    move/from16 v7, p3

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1391
    .local v2, "$i$f$filter\\1\\634":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1392
    .local v6, "$i$f$filterTo\\2\\1391":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_1a
    :goto_1a
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const/4 v10, 0x0

    if-eqz v9, :cond_48

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\2":Ljava/lang/Object;
    move-object v12, v9

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v12, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v13, 0x0

    .line 634
    .local v13, "$i$a$-filter-GuiOverlay$layoutChildren$kids$1\\3\\1392\\0":I
    const-string v14, "GuiObject"

    invoke-virtual {v12, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v14

    if-eqz v14, :cond_42

    const-string v14, "Visible"

    invoke-virtual {v12, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v15

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_42

    const/4 v10, 0x1

    .line 1392
    .end local v12    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v13    # "$i$a$-filter-GuiOverlay$layoutChildren$kids$1\\3\\1392\\0":I
    :cond_42
    if-eqz v10, :cond_1a

    invoke-interface {v3, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1a

    .line 1393
    .end local v9    # "element\\2":Ljava/lang/Object;
    :cond_48
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v4    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo\\2\\1391":I
    check-cast v3, Ljava/util/List;

    .line 1391
    nop

    .line 634
    .end local v1    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\1\\634":I
    move-object v8, v3

    .line 635
    .local v8, "kids":Ljava/util/List;
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_58

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v1

    return-object v1

    .line 636
    :cond_58
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$firstOrNull\\4":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1394
    .local v2, "$i$f$firstOrNull\\4\\636":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_63
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const-string v6, "UITableLayout"

    const-string v9, "UIGridLayout"

    const-string v12, "UIListLayout"

    const-string v13, "UIPageLayout"

    if-eqz v4, :cond_a8

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\4":Ljava/lang/Object;
    move-object v15, v4

    check-cast v15, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v15, "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v16, 0x0

    .line 636
    .local v16, "$i$a$-firstOrNull-GuiOverlay$layoutChildren$layout$1\\5\\1394\\0":I
    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v14

    invoke-static {v14, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_a4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v14

    invoke-static {v14, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_a4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v14

    invoke-static {v14, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_a4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v14

    invoke-static {v14, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_a4

    move v14, v10

    goto :goto_a5

    :cond_a4
    const/4 v14, 0x1

    .line 1394
    .end local v15    # "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v16    # "$i$a$-firstOrNull-GuiOverlay$layoutChildren$layout$1\\5\\1394\\0":I
    :goto_a5
    if-eqz v14, :cond_63

    goto :goto_a9

    .line 1395
    .end local v4    # "element\\4":Ljava/lang/Object;
    :cond_a8
    const/4 v4, 0x0

    .line 636
    .end local v1    # "$this$firstOrNull\\4":Ljava/lang/Iterable;
    .end local v2    # "$i$f$firstOrNull\\4\\636":I
    :goto_a9
    move-object v14, v4

    check-cast v14, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 637
    .local v14, "layout":Lcom/exampletest/mobilestudiotest/model/Instance;
    move-object/from16 v15, p1

    invoke-direct {v0, v15, v8, v14}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->sortKids(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v16

    .line 638
    .local v16, "sorted":Ljava/util/List;
    new-instance v1, Ljava/util/ArrayList;

    invoke-interface/range {v16 .. v16}, Ljava/util/List;->size()I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 639
    .local v1, "out":Ljava/util/ArrayList;
    invoke-virtual {v5}, Landroid/graphics/RectF;->width()F

    move-result v18

    .local v18, "aw":F
    invoke-virtual {v5}, Landroid/graphics/RectF;->height()F

    move-result v19

    .line 640
    .local v19, "ah":F
    if-eqz v14, :cond_ca

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    goto :goto_cb

    :cond_ca
    const/4 v2, 0x0

    :goto_cb
    const/4 v4, 0x0

    if-eqz v2, :cond_545

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v20

    const-string v3, "VerticalAlignment"

    const/16 v22, 0x1

    const-string v11, "HorizontalAlignment"

    move/from16 v23, v10

    const-string v10, "FillDirection"

    const/high16 v24, 0x40000000    # 2.0f

    sparse-switch v20, :sswitch_data_66a

    goto/16 :goto_545

    :sswitch_e3
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_f0

    goto :goto_fa

    :sswitch_ea
    invoke-virtual {v2, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_fa

    :cond_f0
    move-object/from16 v26, v8

    goto/16 :goto_2f3

    :sswitch_f4
    invoke-virtual {v2, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_fe

    :cond_fa
    :goto_fa
    move-object/from16 v26, v8

    goto/16 :goto_547

    .line 642
    :cond_fe
    const-string v2, "CellSize"

    invoke-virtual {v14, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_10d

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/UDim2;

    const/16 v6, 0x64

    invoke-direct {v2, v4, v6, v4, v6}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    :cond_10d
    invoke-direct {v0, v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->udim(Ljava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v2

    .line 643
    .local v2, "cs":Lcom/exampletest/mobilestudiotest/model/UDim2;
    const-string v6, "CellPadding"

    invoke-virtual {v14, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_11f

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/UDim2;

    const/4 v9, 0x5

    invoke-direct {v6, v4, v9, v4, v9}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    :cond_11f
    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->udim(Ljava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v4

    .line 644
    .local v4, "cp":Lcom/exampletest/mobilestudiotest/model/UDim2;
    const/4 v6, 0x0

    .local v6, "w":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v9

    mul-float v9, v9, v18

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v12

    int-to-float v12, v12

    iget v13, v0, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->d:F

    mul-float/2addr v12, v13

    mul-float/2addr v12, v7

    add-float/2addr v9, v12

    .end local v6    # "w":F
    .local v9, "w":F
    const/4 v6, 0x0

    .local v6, "h":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v12

    mul-float v12, v12, v19

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v13

    int-to-float v13, v13

    move-object/from16 v20, v2

    .end local v2    # "cs":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .local v20, "cs":Lcom/exampletest/mobilestudiotest/model/UDim2;
    iget v2, v0, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->d:F

    mul-float/2addr v13, v2

    mul-float/2addr v13, v7

    add-float/2addr v12, v13

    .line 645
    .end local v6    # "h":F
    .local v12, "h":F
    const-string v2, "UIAspectRatioConstraint"

    invoke-direct {v0, v14, v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->child(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    if-eqz v2, :cond_15c

    .line 1342
    .local v2, "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v6, 0x0

    .line 645
    .local v6, "$i$a$-let-GuiOverlay$layoutChildren$1\\6\\645\\0":I
    invoke-direct {v0, v14, v9, v12, v7}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->constrain(Lcom/exampletest/mobilestudiotest/model/Instance;FFF)[F

    move-result-object v13

    .local v13, "r\\6":[F
    aget v9, v13, v23

    aget v12, v13, v22

    .end local v2    # "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v6    # "$i$a$-let-GuiOverlay$layoutChildren$1\\6\\645\\0":I
    .end local v13    # "r\\6":[F
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 646
    :cond_15c
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v2

    mul-float v2, v2, v18

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v6

    int-to-float v6, v6

    iget v13, v0, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->d:F

    mul-float/2addr v6, v13

    mul-float/2addr v6, v7

    add-float/2addr v2, v6

    .local v2, "gx":F
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v6

    mul-float v6, v6, v19

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v13

    int-to-float v13, v13

    move/from16 v25, v2

    .end local v2    # "gx":F
    .local v25, "gx":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->d:F

    mul-float/2addr v13, v2

    mul-float/2addr v13, v7

    add-float/2addr v6, v13

    .line 647
    .local v6, "gy":F
    move/from16 v2, v23

    invoke-direct {v0, v14, v10, v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->enumOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)I

    move-result v10

    if-nez v10, :cond_189

    move/from16 v2, v22

    goto :goto_18a

    :cond_189
    const/4 v2, 0x0

    .line 648
    .local v2, "horizontal":Z
    :goto_18a
    const-string v10, "FillDirectionMaxCells"

    invoke-virtual {v14, v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    instance-of v13, v10, Ljava/lang/Number;

    if-eqz v13, :cond_199

    check-cast v10, Ljava/lang/Number;

    move-object/from16 v17, v10

    goto :goto_19b

    :cond_199
    const/16 v17, 0x0

    :goto_19b
    if-eqz v17, :cond_1a2

    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->intValue()I

    move-result v10

    goto :goto_1a3

    :cond_1a2
    const/4 v10, 0x0

    .line 649
    .local v10, "maxCells":I
    :goto_1a3
    invoke-interface/range {v16 .. v16}, Ljava/util/List;->size()I

    move-result v13

    .line 650
    .local v13, "n":I
    const/16 v17, 0x0

    .local v17, "perLine":I
    if-eqz v2, :cond_1b8

    add-float v26, v18, v25

    add-float v27, v9, v25

    move/from16 v28, v2

    .end local v2    # "horizontal":Z
    .local v28, "horizontal":Z
    div-float v2, v26, v27

    move-object/from16 v26, v8

    move/from16 v27, v9

    .end local v8    # "kids":Ljava/util/List;
    .end local v9    # "w":F
    .local v26, "kids":Ljava/util/List;
    .local v27, "w":F
    goto :goto_1c3

    .end local v26    # "kids":Ljava/util/List;
    .end local v27    # "w":F
    .end local v28    # "horizontal":Z
    .restart local v2    # "horizontal":Z
    .restart local v8    # "kids":Ljava/util/List;
    .restart local v9    # "w":F
    :cond_1b8
    move/from16 v28, v2

    move-object/from16 v26, v8

    move/from16 v27, v9

    .end local v2    # "horizontal":Z
    .end local v8    # "kids":Ljava/util/List;
    .end local v9    # "w":F
    .restart local v26    # "kids":Ljava/util/List;
    .restart local v27    # "w":F
    .restart local v28    # "horizontal":Z
    add-float v2, v19, v6

    add-float v8, v12, v6

    div-float/2addr v2, v8

    :goto_1c3
    float-to-double v8, v2

    invoke-static {v8, v9}, Ljava/lang/Math;->floor(D)D

    move-result-wide v8

    double-to-float v2, v8

    float-to-int v2, v2

    .line 651
    .end local v17    # "perLine":I
    .local v2, "perLine":I
    move/from16 v8, v22

    invoke-static {v2, v8}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v2

    .line 652
    if-lez v10, :cond_1d6

    invoke-static {v2, v10}, Ljava/lang/Math;->min(II)I

    move-result v2

    .line 653
    :cond_1d6
    int-to-float v8, v13

    int-to-float v9, v2

    div-float/2addr v8, v9

    float-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v8

    double-to-float v8, v8

    float-to-int v8, v8

    .line 654
    .local v8, "lines":I
    if-eqz v28, :cond_1e7

    invoke-static {v13, v2}, Ljava/lang/Math;->min(II)I

    move-result v9

    goto :goto_1e8

    :cond_1e7
    move v9, v8

    .line 655
    .local v9, "cols":I
    :goto_1e8
    if-eqz v28, :cond_1ed

    move/from16 v17, v8

    goto :goto_1f1

    :cond_1ed
    invoke-static {v13, v2}, Ljava/lang/Math;->min(II)I

    move-result v17

    :goto_1f1
    move/from16 v29, v17

    .line 656
    .local v29, "rows":I
    move/from16 v17, v2

    .end local v2    # "perLine":I
    .restart local v17    # "perLine":I
    int-to-float v2, v9

    mul-float v2, v2, v27

    move/from16 v30, v2

    add-int/lit8 v2, v9, -0x1

    move-object/from16 v31, v4

    const/4 v4, 0x0

    .end local v4    # "cp":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .local v31, "cp":Lcom/exampletest/mobilestudiotest/model/UDim2;
    invoke-static {v2, v4}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v2

    int-to-float v2, v2

    mul-float v2, v2, v25

    add-float v2, v30, v2

    .line 657
    .local v2, "bw":F
    move/from16 v4, v29

    move/from16 v29, v6

    .end local v6    # "gy":F
    .local v4, "rows":I
    .local v29, "gy":F
    int-to-float v6, v4

    mul-float/2addr v6, v12

    move/from16 v30, v4

    .end local v4    # "rows":I
    .local v30, "rows":I
    add-int/lit8 v4, v30, -0x1

    move/from16 v32, v6

    const/4 v6, 0x0

    invoke-static {v4, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v4

    int-to-float v4, v4

    mul-float v4, v4, v29

    add-float v6, v32, v4

    .line 658
    .local v6, "bh":F
    invoke-direct {v0, v14, v2, v6}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->setContentSize(Lcom/exampletest/mobilestudiotest/model/Instance;FF)V

    .line 659
    const/4 v4, 0x1

    invoke-direct {v0, v14, v11, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->enumOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)I

    move-result v11

    packed-switch v11, :pswitch_data_67c

    :pswitch_229
    iget v4, v5, Landroid/graphics/RectF;->left:F

    goto :goto_237

    :pswitch_22c
    iget v4, v5, Landroid/graphics/RectF;->right:F

    sub-float/2addr v4, v2

    goto :goto_237

    :pswitch_230
    iget v4, v5, Landroid/graphics/RectF;->left:F

    sub-float v11, v18, v2

    div-float v11, v11, v24

    add-float/2addr v4, v11

    .line 660
    .local v4, "x0":F
    :goto_237
    const/4 v11, 0x1

    invoke-direct {v0, v14, v3, v11}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->enumOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)I

    move-result v3

    packed-switch v3, :pswitch_data_686

    :pswitch_23f
    iget v3, v5, Landroid/graphics/RectF;->top:F

    goto :goto_24d

    :pswitch_242
    iget v3, v5, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr v3, v6

    goto :goto_24d

    :pswitch_246
    iget v3, v5, Landroid/graphics/RectF;->top:F

    sub-float v11, v19, v6

    div-float v11, v11, v24

    add-float/2addr v3, v11

    .line 661
    .local v3, "y0":F
    :goto_24d
    move-object/from16 v11, v16

    check-cast v11, Ljava/lang/Iterable;

    .local v11, "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    const/16 v24, 0x0

    .line 1396
    .local v24, "$i$f$forEachIndexed\\7\\661":I
    const/16 v32, 0x0

    .line 1397
    .local v32, "index\\7":I
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v33

    :goto_259
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->hasNext()Z

    move-result v34

    if-eqz v34, :cond_2d7

    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v34

    .local v34, "item\\7":Ljava/lang/Object;
    add-int/lit8 v35, v32, 0x1

    .end local v32    # "index\\7":I
    .local v35, "index\\7":I
    if-gez v32, :cond_26a

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_26a
    move/from16 v44, v2

    .end local v2    # "bw":F
    .local v44, "bw":F
    move-object/from16 v2, v34

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v2, "c\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v32, "i\\8":I
    const/16 v45, 0x0

    .line 662
    .local v45, "$i$a$-forEachIndexed-GuiOverlay$layoutChildren$2\\8\\1397\\0":I
    if-eqz v28, :cond_277

    rem-int v36, v32, v17

    goto :goto_279

    :cond_277
    div-int v36, v32, v17

    :goto_279
    move/from16 v46, v36

    .line 663
    .local v46, "col\\8":I
    if-eqz v28, :cond_280

    div-int v36, v32, v17

    goto :goto_282

    :cond_280
    rem-int v36, v32, v17

    :goto_282
    move/from16 v47, v36

    .line 664
    .local v47, "row\\8":I
    move/from16 v48, v3

    move/from16 v3, v46

    move/from16 v46, v4

    .end local v4    # "x0":F
    .local v3, "col\\8":I
    .local v46, "x0":F
    .local v48, "y0":F
    int-to-float v4, v3

    add-float v36, v27, v25

    mul-float v4, v4, v36

    add-float v4, v46, v4

    move/from16 v49, v3

    move/from16 v3, v47

    move/from16 v47, v6

    .end local v6    # "bh":F
    .local v3, "row\\8":I
    .local v4, "x\\8":F
    .local v47, "bh":F
    .local v49, "col\\8":I
    int-to-float v6, v3

    add-float v36, v12, v29

    mul-float v6, v6, v36

    add-float v6, v48, v6

    .line 665
    .local v6, "y\\8":F
    new-instance v36, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;

    move/from16 v50, v3

    .end local v3    # "row\\8":I
    .local v50, "row\\8":I
    new-instance v3, Landroid/graphics/RectF;

    move/from16 v51, v8

    .end local v8    # "lines":I
    .local v51, "lines":I
    add-float v8, v4, v27

    move/from16 v52, v9

    .end local v9    # "cols":I
    .local v52, "cols":I
    add-float v9, v6, v12

    invoke-direct {v3, v4, v6, v8, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-direct {v0, v2, v7}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scaleFor(Lcom/exampletest/mobilestudiotest/model/Instance;F)F

    move-result v39

    const/16 v42, 0x18

    const/16 v43, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    move-object/from16 v37, v2

    move-object/from16 v38, v3

    .end local v2    # "c\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v37, "c\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-direct/range {v36 .. v43}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/graphics/RectF;FLandroid/graphics/RectF;ZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v2, v36

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 666
    nop

    .line 1397
    .end local v4    # "x\\8":F
    .end local v6    # "y\\8":F
    .end local v32    # "i\\8":I
    .end local v37    # "c\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v45    # "$i$a$-forEachIndexed-GuiOverlay$layoutChildren$2\\8\\1397\\0":I
    .end local v49    # "col\\8":I
    .end local v50    # "row\\8":I
    move/from16 v32, v35

    move/from16 v2, v44

    move/from16 v4, v46

    move/from16 v6, v47

    move/from16 v3, v48

    move/from16 v8, v51

    move/from16 v9, v52

    .end local v34    # "item\\7":Ljava/lang/Object;
    goto :goto_259

    .line 1398
    .end local v35    # "index\\7":I
    .end local v44    # "bw":F
    .end local v46    # "x0":F
    .end local v47    # "bh":F
    .end local v48    # "y0":F
    .end local v51    # "lines":I
    .end local v52    # "cols":I
    .local v2, "bw":F
    .local v3, "y0":F
    .local v4, "x0":F
    .local v6, "bh":F
    .restart local v8    # "lines":I
    .restart local v9    # "cols":I
    .local v32, "index\\7":I
    :cond_2d7
    move/from16 v44, v2

    move/from16 v48, v3

    move/from16 v46, v4

    move/from16 v47, v6

    move/from16 v51, v8

    move/from16 v52, v9

    .end local v2    # "bw":F
    .end local v3    # "y0":F
    .end local v4    # "x0":F
    .end local v6    # "bh":F
    .end local v8    # "lines":I
    .end local v9    # "cols":I
    .end local v10    # "maxCells":I
    .end local v11    # "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    .end local v12    # "h":F
    .end local v13    # "n":I
    .end local v17    # "perLine":I
    .end local v20    # "cs":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .end local v24    # "$i$f$forEachIndexed\\7\\661":I
    .end local v25    # "gx":F
    .end local v27    # "w":F
    .end local v28    # "horizontal":Z
    .end local v29    # "gy":F
    .end local v30    # "rows":I
    .end local v31    # "cp":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .end local v32    # "index\\7":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    const/16 v22, 0x1

    const/16 v23, 0x0

    goto/16 :goto_607

    .line 640
    .end local v26    # "kids":Ljava/util/List;
    .local v8, "kids":Ljava/util/List;
    :sswitch_2eb
    move-object/from16 v26, v8

    .end local v8    # "kids":Ljava/util/List;
    .restart local v26    # "kids":Ljava/util/List;
    invoke-virtual {v2, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_547

    .line 669
    :goto_2f3
    const/4 v8, 0x1

    invoke-direct {v0, v14, v10, v8}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->enumOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)I

    move-result v2

    if-nez v2, :cond_2fc

    const/4 v2, 0x1

    goto :goto_2fd

    :cond_2fc
    const/4 v2, 0x0

    .line 670
    .local v2, "horizontal":Z
    :goto_2fd
    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_311

    move-object/from16 v6, v16

    check-cast v6, Ljava/lang/Iterable;

    const/4 v8, 0x1

    invoke-static {v6, v8}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v6

    goto :goto_313

    :cond_311
    move-object/from16 v6, v16

    .line 671
    .local v6, "list":Ljava/util/List;
    :goto_313
    const-string v8, "Padding"

    invoke-virtual {v14, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v9, :cond_320

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/UDim;

    goto :goto_321

    :cond_320
    const/4 v8, 0x0

    .line 672
    .local v8, "padU":Lcom/exampletest/mobilestudiotest/model/UDim;
    :goto_321
    if-eqz v8, :cond_33c

    move-object v9, v8

    .line 1342
    .local v9, "it\\9":Lcom/exampletest/mobilestudiotest/model/UDim;
    const/4 v10, 0x0

    .line 672
    .local v10, "$i$a$-let-GuiOverlay$layoutChildren$pad$1\\9\\672\\0":I
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v12

    if-eqz v2, :cond_32e

    move/from16 v13, v18

    goto :goto_330

    :cond_32e
    move/from16 v13, v19

    :goto_330
    mul-float/2addr v12, v13

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v13

    int-to-float v13, v13

    iget v4, v0, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->d:F

    mul-float/2addr v13, v4

    mul-float/2addr v13, v7

    add-float/2addr v12, v13

    .end local v9    # "it\\9":Lcom/exampletest/mobilestudiotest/model/UDim;
    .end local v10    # "$i$a$-let-GuiOverlay$layoutChildren$pad$1\\9\\672\\0":I
    goto :goto_33d

    :cond_33c
    const/4 v12, 0x0

    .line 673
    .local v12, "pad":F
    :goto_33d
    move-object v4, v6

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$map\\10":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1399
    .local v9, "$i$f$map\\10\\673":I
    new-instance v10, Ljava/util/ArrayList;

    move/from16 v25, v2

    const/16 v13, 0xa

    .end local v2    # "horizontal":Z
    .local v25, "horizontal":Z
    invoke-static {v4, v13}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-direct {v10, v2}, Ljava/util/ArrayList;-><init>(I)V

    move-object v2, v10

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\11":Ljava/util/Collection;
    move-object v10, v4

    .local v10, "$this$mapTo\\11":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 1400
    .local v13, "$i$f$mapTo\\11\\1399":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v27

    :goto_357
    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->hasNext()Z

    move-result v28

    if-eqz v28, :cond_373

    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v28

    .line 1401
    .local v28, "item\\11":Ljava/lang/Object;
    move-object/from16 v29, v4

    .end local v4    # "$this$map\\10":Ljava/lang/Iterable;
    .local v29, "$this$map\\10":Ljava/lang/Iterable;
    move-object/from16 v4, v28

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v4, "it\\12":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v30, 0x0

    .line 673
    .local v30, "$i$a$-map-GuiOverlay$layoutChildren$sizes$1\\12\\1401\\0":I
    invoke-direct {v0, v4, v5, v7}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->sizeOf(Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/graphics/RectF;F)[F

    move-result-object v4

    .line 1401
    .end local v4    # "it\\12":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v30    # "$i$a$-map-GuiOverlay$layoutChildren$sizes$1\\12\\1401\\0":I
    invoke-interface {v2, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v4, v29

    goto :goto_357

    .line 1402
    .end local v28    # "item\\11":Ljava/lang/Object;
    .end local v29    # "$this$map\\10":Ljava/lang/Iterable;
    .local v4, "$this$map\\10":Ljava/lang/Iterable;
    :cond_373
    move-object/from16 v29, v4

    .end local v2    # "destination\\11":Ljava/util/Collection;
    .end local v4    # "$this$map\\10":Ljava/lang/Iterable;
    .end local v10    # "$this$mapTo\\11":Ljava/lang/Iterable;
    .end local v13    # "$i$f$mapTo\\11\\1399":I
    .restart local v29    # "$this$map\\10":Ljava/lang/Iterable;
    check-cast v2, Ljava/util/List;

    .line 1399
    nop

    .line 673
    .end local v9    # "$i$f$map\\10\\673":I
    .end local v29    # "$this$map\\10":Ljava/lang/Iterable;
    nop

    .line 674
    .local v2, "sizes":Ljava/util/List;
    move-object v4, v2

    check-cast v4, Ljava/lang/Iterable;

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    const-wide/16 v9, 0x0

    :goto_382
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_3ab

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, [F

    .line 1342
    nop

    .local v13, "it\\13":[F
    const/16 v27, 0x0

    .line 674
    .local v27, "$i$a$-sumOfDouble-GuiOverlay$layoutChildren$total$1\\13\\674\\0":I
    if-eqz v25, :cond_39a

    const/16 v23, 0x0

    aget v28, v13, v23

    const/16 v22, 0x1

    goto :goto_39e

    :cond_39a
    const/16 v22, 0x1

    aget v28, v13, v22

    :goto_39e
    move-object/from16 v29, v4

    move/from16 v4, v28

    move/from16 v28, v12

    .end local v12    # "pad":F
    .local v28, "pad":F
    float-to-double v12, v4

    .end local v13    # "it\\13":[F
    .end local v27    # "$i$a$-sumOfDouble-GuiOverlay$layoutChildren$total$1\\13\\674\\0":I
    add-double/2addr v9, v12

    move/from16 v12, v28

    move-object/from16 v4, v29

    goto :goto_382

    .end local v28    # "pad":F
    .restart local v12    # "pad":F
    :cond_3ab
    move/from16 v28, v12

    const/16 v22, 0x1

    .end local v12    # "pad":F
    .restart local v28    # "pad":F
    double-to-float v4, v9

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v9

    add-int/lit8 v9, v9, -0x1

    const/4 v10, 0x0

    invoke-static {v9, v10}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v9

    int-to-float v9, v9

    mul-float v12, v28, v9

    add-float/2addr v4, v12

    .line 675
    .local v4, "total":F
    move-object v9, v2

    check-cast v9, Ljava/lang/Iterable;

    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-nez v10, :cond_3cf

    const/16 v17, 0x0

    goto :goto_406

    :cond_3cf
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, [F

    .line 1342
    .local v10, "it\\14":[F
    const/4 v12, 0x0

    .line 675
    .local v12, "$i$a$-maxOfOrNull-GuiOverlay$layoutChildren$cross$1\\14\\675\\0":I
    if-eqz v25, :cond_3dd

    const/16 v22, 0x1

    aget v13, v10, v22

    goto :goto_3e1

    :cond_3dd
    const/16 v23, 0x0

    aget v13, v10, v23

    .end local v10    # "it\\14":[F
    .end local v12    # "$i$a$-maxOfOrNull-GuiOverlay$layoutChildren$cross$1\\14\\675\\0":I
    :goto_3e1
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_400

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, [F

    .line 1342
    .local v10, "it\\15":[F
    const/4 v12, 0x0

    .line 675
    .local v12, "$i$a$-maxOfOrNull-GuiOverlay$layoutChildren$cross$1\\15\\675\\0":I
    if-eqz v25, :cond_3f5

    const/16 v22, 0x1

    aget v17, v10, v22

    goto :goto_3f9

    :cond_3f5
    const/16 v23, 0x0

    aget v17, v10, v23

    :goto_3f9
    move/from16 v10, v17

    .end local v10    # "it\\15":[F
    .end local v12    # "$i$a$-maxOfOrNull-GuiOverlay$layoutChildren$cross$1\\15\\675\\0":I
    invoke-static {v13, v10}, Ljava/lang/Math;->max(FF)F

    move-result v13

    goto :goto_3e1

    :cond_400
    invoke-static {v13}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v9

    move-object/from16 v17, v9

    :goto_406
    if-eqz v17, :cond_40f

    invoke-virtual/range {v17 .. v17}, Ljava/lang/Float;->floatValue()F

    move-result v9

    move/from16 v20, v9

    goto :goto_411

    :cond_40f
    const/16 v20, 0x0

    .line 676
    .local v20, "cross":F
    :goto_411
    if-eqz v25, :cond_415

    move v9, v4

    goto :goto_417

    :cond_415
    move/from16 v9, v20

    :goto_417
    if-eqz v25, :cond_41c

    move/from16 v10, v20

    goto :goto_41d

    :cond_41c
    move v10, v4

    :goto_41d
    invoke-direct {v0, v14, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->setContentSize(Lcom/exampletest/mobilestudiotest/model/Instance;FF)V

    .line 677
    const/4 v9, 0x1

    invoke-direct {v0, v14, v11, v9}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->enumOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)I

    move-result v10

    .line 678
    .local v10, "hA":I
    invoke-direct {v0, v14, v3, v9}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->enumOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)I

    move-result v3

    .line 679
    .local v3, "vA":I
    const/4 v9, 0x0

    .local v9, "cursor":F
    if-eqz v25, :cond_43e

    packed-switch v10, :pswitch_data_690

    :pswitch_42f
    iget v11, v5, Landroid/graphics/RectF;->left:F

    goto :goto_44f

    :pswitch_432
    iget v11, v5, Landroid/graphics/RectF;->right:F

    sub-float/2addr v11, v4

    goto :goto_44f

    :pswitch_436
    iget v11, v5, Landroid/graphics/RectF;->left:F

    sub-float v12, v18, v4

    div-float v12, v12, v24

    add-float/2addr v11, v12

    goto :goto_44f

    .line 680
    :cond_43e
    packed-switch v3, :pswitch_data_69a

    :pswitch_441
    iget v11, v5, Landroid/graphics/RectF;->top:F

    goto :goto_44f

    :pswitch_444
    iget v11, v5, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr v11, v4

    goto :goto_44f

    :pswitch_448
    iget v11, v5, Landroid/graphics/RectF;->top:F

    sub-float v12, v19, v4

    div-float v12, v12, v24

    add-float/2addr v11, v12

    .line 679
    :goto_44f
    nop

    .line 681
    .end local v9    # "cursor":F
    .local v11, "cursor":F
    move-object v9, v6

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$forEachIndexed\\16":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 1403
    .local v12, "$i$f$forEachIndexed\\16\\681":I
    const/4 v13, 0x0

    .line 1404
    .local v13, "index\\16":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_459
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v27

    if-eqz v27, :cond_531

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v27

    .local v27, "item\\16":Ljava/lang/Object;
    add-int/lit8 v29, v13, 0x1

    .end local v13    # "index\\16":I
    .local v29, "index\\16":I
    if-gez v13, :cond_46a

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_46a
    move/from16 v38, v3

    .end local v3    # "vA":I
    .local v38, "vA":I
    move-object/from16 v3, v27

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v3, "c\\17":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v13, "i\\17":I
    const/16 v39, 0x0

    .line 682
    .local v39, "$i$a$-forEachIndexed-GuiOverlay$layoutChildren$3\\17\\1404\\0":I
    invoke-interface {v2, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v30

    check-cast v30, [F

    .line 1342
    .local v30, "it\\18":[F
    const/16 v31, 0x0

    .line 682
    .local v31, "$i$a$-let-GuiOverlay$layoutChildren$3$1\\18\\682\\17":I
    const/16 v23, 0x0

    aget v32, v30, v23

    move-object/from16 v40, v2

    .end local v2    # "sizes":Ljava/util/List;
    .local v40, "sizes":Ljava/util/List;
    invoke-static/range {v32 .. v32}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    const/16 v22, 0x1

    aget v32, v30, v22

    move/from16 v41, v4

    .end local v4    # "total":F
    .local v41, "total":F
    invoke-static/range {v32 .. v32}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    .end local v30    # "it\\18":[F
    .end local v31    # "$i$a$-let-GuiOverlay$layoutChildren$3$1\\18\\682\\17":I
    invoke-virtual {v2}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    .local v4, "w\\17":F
    invoke-virtual {v2}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    move-result v2

    .line 683
    .local v2, "h\\17":F
    const/16 v30, 0x0

    .local v30, "x\\17":F
    const/16 v31, 0x0

    .line 684
    .local v31, "y\\17":F
    if-eqz v25, :cond_4d0

    .line 685
    move/from16 v30, v11

    add-float v32, v4, v28

    add-float v11, v11, v32

    .line 686
    packed-switch v38, :pswitch_data_6a4

    :pswitch_4b5
    move/from16 v42, v2

    .end local v2    # "h\\17":F
    .local v42, "h\\17":F
    iget v2, v5, Landroid/graphics/RectF;->top:F

    goto :goto_4cb

    .end local v42    # "h\\17":F
    .restart local v2    # "h\\17":F
    :pswitch_4ba
    move/from16 v42, v2

    .end local v2    # "h\\17":F
    .restart local v42    # "h\\17":F
    iget v2, v5, Landroid/graphics/RectF;->bottom:F

    sub-float v2, v2, v42

    goto :goto_4cb

    .end local v42    # "h\\17":F
    .restart local v2    # "h\\17":F
    :pswitch_4c1
    move/from16 v42, v2

    .end local v2    # "h\\17":F
    .restart local v42    # "h\\17":F
    iget v2, v5, Landroid/graphics/RectF;->top:F

    sub-float v32, v19, v42

    div-float v32, v32, v24

    add-float v2, v2, v32

    :goto_4cb
    move/from16 v43, v4

    move/from16 v4, v30

    .end local v31    # "y\\17":F
    .local v2, "y\\17":F
    goto :goto_4f7

    .line 688
    .end local v42    # "h\\17":F
    .local v2, "h\\17":F
    .restart local v31    # "y\\17":F
    :cond_4d0
    move/from16 v42, v2

    .end local v2    # "h\\17":F
    .restart local v42    # "h\\17":F
    move v2, v11

    .end local v31    # "y\\17":F
    .local v2, "y\\17":F
    add-float v31, v42, v28

    add-float v11, v11, v31

    .line 689
    packed-switch v10, :pswitch_data_6ae

    :pswitch_4da
    move/from16 v31, v2

    .end local v2    # "y\\17":F
    .restart local v31    # "y\\17":F
    iget v2, v5, Landroid/graphics/RectF;->left:F

    goto :goto_4ef

    .end local v31    # "y\\17":F
    .restart local v2    # "y\\17":F
    :pswitch_4df
    move/from16 v31, v2

    .end local v2    # "y\\17":F
    .restart local v31    # "y\\17":F
    iget v2, v5, Landroid/graphics/RectF;->right:F

    sub-float/2addr v2, v4

    goto :goto_4ef

    .end local v31    # "y\\17":F
    .restart local v2    # "y\\17":F
    :pswitch_4e5
    move/from16 v31, v2

    .end local v2    # "y\\17":F
    .restart local v31    # "y\\17":F
    iget v2, v5, Landroid/graphics/RectF;->left:F

    sub-float v32, v18, v4

    div-float v32, v32, v24

    add-float v2, v2, v32

    :goto_4ef
    move/from16 v30, v2

    move/from16 v2, v31

    move/from16 v43, v4

    move/from16 v4, v30

    .line 691
    .end local v30    # "x\\17":F
    .end local v31    # "y\\17":F
    .restart local v2    # "y\\17":F
    .local v4, "x\\17":F
    .local v43, "w\\17":F
    :goto_4f7
    new-instance v30, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;

    move-object/from16 v44, v6

    .end local v6    # "list":Ljava/util/List;
    .local v44, "list":Ljava/util/List;
    new-instance v6, Landroid/graphics/RectF;

    move-object/from16 v45, v8

    .end local v8    # "padU":Lcom/exampletest/mobilestudiotest/model/UDim;
    .local v45, "padU":Lcom/exampletest/mobilestudiotest/model/UDim;
    add-float v8, v4, v43

    move-object/from16 v46, v9

    .end local v9    # "$this$forEachIndexed\\16":Ljava/lang/Iterable;
    .local v46, "$this$forEachIndexed\\16":Ljava/lang/Iterable;
    add-float v9, v2, v42

    invoke-direct {v6, v4, v2, v8, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-direct {v0, v3, v7}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scaleFor(Lcom/exampletest/mobilestudiotest/model/Instance;F)F

    move-result v33

    const/16 v36, 0x18

    const/16 v37, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    move-object/from16 v31, v3

    move-object/from16 v32, v6

    .end local v3    # "c\\17":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v31, "c\\17":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-direct/range {v30 .. v37}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/graphics/RectF;FLandroid/graphics/RectF;ZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v3, v30

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 692
    nop

    .line 1404
    .end local v2    # "y\\17":F
    .end local v4    # "x\\17":F
    .end local v13    # "i\\17":I
    .end local v31    # "c\\17":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v39    # "$i$a$-forEachIndexed-GuiOverlay$layoutChildren$3\\17\\1404\\0":I
    .end local v42    # "h\\17":F
    .end local v43    # "w\\17":F
    move/from16 v13, v29

    move/from16 v3, v38

    move-object/from16 v2, v40

    move/from16 v4, v41

    move-object/from16 v6, v44

    move-object/from16 v8, v45

    move-object/from16 v9, v46

    .end local v27    # "item\\16":Ljava/lang/Object;
    goto/16 :goto_459

    .line 1405
    .end local v29    # "index\\16":I
    .end local v38    # "vA":I
    .end local v40    # "sizes":Ljava/util/List;
    .end local v41    # "total":F
    .end local v44    # "list":Ljava/util/List;
    .end local v45    # "padU":Lcom/exampletest/mobilestudiotest/model/UDim;
    .end local v46    # "$this$forEachIndexed\\16":Ljava/lang/Iterable;
    .local v2, "sizes":Ljava/util/List;
    .local v3, "vA":I
    .local v4, "total":F
    .restart local v6    # "list":Ljava/util/List;
    .restart local v8    # "padU":Lcom/exampletest/mobilestudiotest/model/UDim;
    .restart local v9    # "$this$forEachIndexed\\16":Ljava/lang/Iterable;
    .local v13, "index\\16":I
    :cond_531
    move-object/from16 v40, v2

    move/from16 v38, v3

    move/from16 v41, v4

    move-object/from16 v44, v6

    move-object/from16 v45, v8

    move-object/from16 v46, v9

    .end local v2    # "sizes":Ljava/util/List;
    .end local v3    # "vA":I
    .end local v4    # "total":F
    .end local v6    # "list":Ljava/util/List;
    .end local v8    # "padU":Lcom/exampletest/mobilestudiotest/model/UDim;
    .end local v9    # "$this$forEachIndexed\\16":Ljava/lang/Iterable;
    .end local v10    # "hA":I
    .end local v11    # "cursor":F
    .end local v12    # "$i$f$forEachIndexed\\16\\681":I
    .end local v13    # "index\\16":I
    .end local v20    # "cross":F
    .end local v25    # "horizontal":Z
    .end local v28    # "pad":F
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    const/16 v22, 0x1

    const/16 v23, 0x0

    goto/16 :goto_607

    .line 640
    .end local v26    # "kids":Ljava/util/List;
    .local v8, "kids":Ljava/util/List;
    :cond_545
    :goto_545
    move-object/from16 v26, v8

    .line 694
    .end local v8    # "kids":Ljava/util/List;
    .restart local v26    # "kids":Ljava/util/List;
    :cond_547
    :goto_547
    invoke-interface/range {v16 .. v16}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_54b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_601

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 695
    .local v3, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-direct {v0, v3, v5, v7}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->sizeOf(Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/graphics/RectF;F)[F

    move-result-object v4

    .line 1342
    .local v4, "it\\19":[F
    const/4 v6, 0x0

    .line 695
    .local v6, "$i$a$-let-GuiOverlay$layoutChildren$4\\19\\695\\0":I
    const/16 v23, 0x0

    aget v8, v4, v23

    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v8

    const/16 v22, 0x1

    aget v9, v4, v22

    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v9

    invoke-static {v8, v9}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v4    # "it\\19":[F
    .end local v6    # "$i$a$-let-GuiOverlay$layoutChildren$4\\19\\695\\0":I
    invoke-virtual {v4}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    move-result v6

    .local v6, "w":F
    invoke-virtual {v4}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    .line 696
    .local v4, "h":F
    const-string v8, "Position"

    invoke-virtual {v3, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->udim(Ljava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v8

    .line 697
    .local v8, "pos":Lcom/exampletest/mobilestudiotest/model/UDim2;
    const-string v9, "AnchorPoint"

    invoke-virtual {v3, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v10, :cond_59b

    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Vector2;

    goto :goto_59c

    :cond_59b
    const/4 v9, 0x0

    :goto_59c
    if-nez v9, :cond_5a5

    new-instance v9, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const/4 v10, 0x0

    invoke-direct {v9, v10, v10}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    goto :goto_5a6

    :cond_5a5
    const/4 v10, 0x0

    .line 698
    .local v9, "anchor":Lcom/exampletest/mobilestudiotest/model/Vector2;
    :goto_5a6
    iget v11, v5, Landroid/graphics/RectF;->left:F

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v12

    mul-float v12, v12, v18

    add-float/2addr v11, v12

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v12

    int-to-float v12, v12

    iget v13, v0, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->d:F

    mul-float/2addr v12, v13

    mul-float/2addr v12, v7

    add-float/2addr v11, v12

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getX()F

    move-result v12

    mul-float/2addr v12, v6

    sub-float/2addr v11, v12

    .line 699
    .local v11, "x":F
    iget v12, v5, Landroid/graphics/RectF;->top:F

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v13

    mul-float v13, v13, v19

    add-float/2addr v12, v13

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v13

    int-to-float v13, v13

    iget v10, v0, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->d:F

    mul-float/2addr v13, v10

    mul-float/2addr v13, v7

    add-float/2addr v12, v13

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getY()F

    move-result v10

    mul-float/2addr v10, v4

    sub-float/2addr v12, v10

    .line 700
    .local v12, "y":F
    new-instance v27, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;

    new-instance v10, Landroid/graphics/RectF;

    add-float v13, v11, v6

    move-object/from16 v24, v2

    add-float v2, v12, v4

    invoke-direct {v10, v11, v12, v13, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-direct {v0, v3, v7}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scaleFor(Lcom/exampletest/mobilestudiotest/model/Instance;F)F

    move-result v30

    const/16 v33, 0x18

    const/16 v34, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    move-object/from16 v28, v3

    move-object/from16 v29, v10

    .end local v3    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v28, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-direct/range {v27 .. v34}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/graphics/RectF;FLandroid/graphics/RectF;ZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v2, v27

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v2, v24

    .end local v4    # "h":F
    .end local v6    # "w":F
    .end local v8    # "pos":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .end local v9    # "anchor":Lcom/exampletest/mobilestudiotest/model/Vector2;
    .end local v11    # "x":F
    .end local v12    # "y":F
    goto/16 :goto_54b

    .end local v28    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_601
    const/16 v22, 0x1

    const/16 v23, 0x0

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 704
    :goto_607
    if-eqz v14, :cond_60c

    move/from16 v6, v22

    goto :goto_60e

    :cond_60c
    move/from16 v6, v23

    .line 705
    .local v6, "inLayout":Z
    :goto_60e
    move-object v8, v1

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$map\\20":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1406
    .local v9, "$i$f$map\\20\\705":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v13, 0xa

    invoke-static {v8, v13}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    move-object v10, v2

    check-cast v10, Ljava/util/Collection;

    .local v10, "destination\\21":Ljava/util/Collection;
    move-object v11, v8

    .local v11, "$this$mapTo\\21":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 1407
    .local v12, "$i$f$mapTo\\21\\1406":I
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_626
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_654

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    .line 1408
    .local v17, "item\\21":Ljava/lang/Object;
    move-object/from16 v20, v17

    check-cast v20, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;

    .local v20, "it\\22":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;
    const/16 v21, 0x0

    .line 705
    .local v21, "$i$a$-map-GuiOverlay$layoutChildren$5\\22\\1408\\0":I
    move-object v2, v1

    .end local v1    # "out":Ljava/util/ArrayList;
    .local v2, "out":Ljava/util/ArrayList;
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;

    move-object v3, v2

    .end local v2    # "out":Ljava/util/ArrayList;
    .local v3, "out":Ljava/util/ArrayList;
    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    move-object v4, v3

    .end local v3    # "out":Ljava/util/ArrayList;
    .local v4, "out":Ljava/util/ArrayList;
    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;->getRect()Landroid/graphics/RectF;

    move-result-object v3

    move-object/from16 v22, v4

    .end local v4    # "out":Ljava/util/ArrayList;
    .local v22, "out":Ljava/util/ArrayList;
    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;->getScale()F

    move-result v4

    invoke-direct/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/graphics/RectF;FLandroid/graphics/RectF;Z)V

    .line 1408
    .end local v20    # "it\\22":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Node;
    .end local v21    # "$i$a$-map-GuiOverlay$layoutChildren$5\\22\\1408\\0":I
    invoke-interface {v10, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v5, p2

    move-object/from16 v1, v22

    goto :goto_626

    .line 1409
    .end local v17    # "item\\21":Ljava/lang/Object;
    .end local v22    # "out":Ljava/util/ArrayList;
    .restart local v1    # "out":Ljava/util/ArrayList;
    :cond_654
    move-object/from16 v22, v1

    .end local v1    # "out":Ljava/util/ArrayList;
    .end local v10    # "destination\\21":Ljava/util/Collection;
    .end local v11    # "$this$mapTo\\21":Ljava/lang/Iterable;
    .end local v12    # "$i$f$mapTo\\21\\1406":I
    .restart local v22    # "out":Ljava/util/ArrayList;
    move-object v1, v10

    check-cast v1, Ljava/util/List;

    .line 1406
    nop

    .end local v8    # "$this$map\\20":Ljava/lang/Iterable;
    .end local v9    # "$i$f$map\\20\\705":I
    check-cast v1, Ljava/lang/Iterable;

    .line 705
    nop

    .local v1, "$this$sortedBy\\23":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1410
    .local v2, "$i$f$sortedBy\\23\\705":I
    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$layoutChildren$$inlined$sortedBy$1;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$layoutChildren$$inlined$sortedBy$1;-><init>()V

    check-cast v3, Ljava/util/Comparator;

    invoke-static {v1, v3}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v1

    .line 705
    .end local v1    # "$this$sortedBy\\23":Ljava/lang/Iterable;
    .end local v2    # "$i$f$sortedBy\\23\\705":I
    return-object v1

    :sswitch_data_66a
    .sparse-switch
        -0x7d3418e4 -> :sswitch_2eb
        -0x696adc3c -> :sswitch_f4
        -0x463d5fb3 -> :sswitch_ea
        -0x36b1769c -> :sswitch_e3
    .end sparse-switch

    :pswitch_data_67c
    .packed-switch 0x0
        :pswitch_230
        :pswitch_229
        :pswitch_22c
    .end packed-switch

    :pswitch_data_686
    .packed-switch 0x0
        :pswitch_246
        :pswitch_23f
        :pswitch_242
    .end packed-switch

    :pswitch_data_690
    .packed-switch 0x0
        :pswitch_436
        :pswitch_42f
        :pswitch_432
    .end packed-switch

    :pswitch_data_69a
    .packed-switch 0x0
        :pswitch_448
        :pswitch_441
        :pswitch_444
    .end packed-switch

    :pswitch_data_6a4
    .packed-switch 0x0
        :pswitch_4c1
        :pswitch_4b5
        :pswitch_4ba
    .end packed-switch

    :pswitch_data_6ae
    .packed-switch 0x0
        :pswitch_4e5
        :pswitch_4da
        :pswitch_4df
    .end packed-switch
.end method
