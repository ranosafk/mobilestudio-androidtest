.method static final pluginMouse$lambda$10(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 6
    .param p0, "$rt"    # Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;
    .param p1, "$m"    # Lorg/luaj/vm2/LuaTable;
    .param p3, "k"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "<unused var>"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p2, "k"

    invoke-static {p3, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 407
    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object p2

    .local p2, "ks":Ljava/lang/String;
    if-eqz p2, :cond_bb

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_c4

    goto/16 :goto_bb

    :sswitch_19
    const-string v0, "Button2Up"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    goto/16 :goto_b2

    :sswitch_23
    const-string v0, "Button1Up"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto/16 :goto_bb

    :sswitch_2d
    const-string v0, "DragEnter"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto/16 :goto_bb

    :sswitch_37
    const-string v0, "WheelBackward"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto/16 :goto_bb

    :sswitch_41
    const-string v0, "KeyDown"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto/16 :goto_bb

    :sswitch_4b
    const-string v0, "WheelForward"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto/16 :goto_bb

    :sswitch_55
    const-string v0, "KeyUp"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto :goto_bb

    :sswitch_5e
    const-string v0, "Move"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto :goto_bb

    :sswitch_67
    const-string v0, "Idle"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto :goto_bb

    :sswitch_70
    const-string v0, "IsA"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    .line 408
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/PluginApi$$ExternalSyntheticLambda9;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/PluginApi$$ExternalSyntheticLambda9;-><init>()V

    .line 409
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto :goto_c2

    .line 407
    :sswitch_84
    const-string v0, "Button2Down"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto :goto_bb

    :sswitch_8d
    const-string v0, "Button1Down"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b2

    goto :goto_bb

    :sswitch_96
    const-string v0, "GetPropertyChangedSignal"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    .line 410
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/PluginApi$$ExternalSyntheticLambda10;

    invoke-direct {v0, p0, p1}, Lcom/exampletest/mobilestudiotest/lua/PluginApi$$ExternalSyntheticLambda10;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lorg/luaj/vm2/LuaTable;)V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto :goto_c2

    .line 407
    :sswitch_aa
    const-string v0, "Changed"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_bb

    .line 408
    :cond_b2
    :goto_b2
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getApi()Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_c2

    .line 411
    :cond_bb
    :goto_bb
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NIL"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 412
    .end local p2    # "ks":Ljava/lang/String;
    :goto_c2
    return-object v0

    nop

    :sswitch_data_c4
    .sparse-switch
        -0x70bc056c -> :sswitch_aa
        -0x1006eeef -> :sswitch_96
        -0x812b79f -> :sswitch_8d
        -0x804a01e -> :sswitch_84
        0x12037 -> :sswitch_70
        0x22b3f4 -> :sswitch_67
        0x24aff1 -> :sswitch_5e
        0x4509d3a -> :sswitch_55
        0x81c570a -> :sswitch_4b
        0x32968781 -> :sswitch_41
        0x5d1a903e -> :sswitch_37
        0x637329e4 -> :sswitch_2d
        0x7822161a -> :sswitch_23
        0x782219db -> :sswitch_19
    .end sparse-switch
.end method
