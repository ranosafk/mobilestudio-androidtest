.method public final callMethod(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 22
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v1, p0

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    const-string v0, "name"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "a"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 718
    invoke-direct {v1, v5, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->self(Lorg/luaj/vm2/Varargs;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    .line 719
    .local v3, "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v0, 0x2

    invoke-virtual {v5, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    .line 720
    .local v6, "a2":Lorg/luaj/vm2/LuaValue;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    const-string v7, "CollectionService"

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const-string v8, "GetTags"

    const-string v9, "HasTag"

    const-string v10, "RemoveTag"

    const-string v11, "AddTag"

    const/4 v12, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x0

    if-eqz v2, :cond_4a

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/String;

    aput-object v11, v2, v14

    aput-object v10, v2, v13

    aput-object v9, v2, v0

    aput-object v8, v2, v12

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4a

    invoke-virtual/range {p0 .. p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->collectionCall(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    return-object v0

    .line 721
    :cond_4a
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v2

    const-string v15, "NIL"

    const-string v0, "Attr:"

    move/from16 v16, v14

    const-string v14, "FindService"

    const-string v13, "Destroy"

    const-string v12, "checkjstring(...)"

    move/from16 v17, v2

    const-string v2, "valueOf(...)"

    move-object/from16 v18, v6

    .end local v6    # "a2":Lorg/luaj/vm2/LuaValue;
    .local v18, "a2":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    sparse-switch v17, :sswitch_data_656

    goto/16 :goto_636

    :sswitch_66
    const-string v0, "FindFirstChild"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 722
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    invoke-virtual {v5, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v6

    invoke-virtual {v3, v2, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_8c
    const-string v0, "GetActor"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 744
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_9d
    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 772
    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0

    .local v0, "t":Ljava/util/List;
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    .local v2, "tg":Ljava/lang/String;
    invoke-interface {v0, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_e7

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-direct {v1, v3, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setTags(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;)V

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v8

    invoke-virtual {v8, v7}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "TagAdded:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x1

    new-array v9, v9, [Lorg/luaj/vm2/LuaValue;

    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v10, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v10

    aput-object v10, v9, v16

    invoke-virtual {v6, v7, v8, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    :cond_e7
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .end local v0    # "t":Ljava/util/List;
    .end local v2    # "tg":Ljava/lang/String;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_f0
    const-string v6, "SetAttribute"

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_636

    .line 753
    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/Attributes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 754
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v6

    .line 755
    .local v6, "k":Ljava/lang/String;
    const/4 v7, 0x3

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    .line 756
    .local v9, "v":Lorg/luaj/vm2/LuaValue;
    invoke-virtual {v9}, Lorg/luaj/vm2/LuaValue;->isnil()Z

    move-result v7

    if-eqz v7, :cond_114

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_12c

    :cond_114
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v7

    check-cast v7, Ljava/util/Map;

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v13, 0xc

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fromLua$default(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lorg/luaj/vm2/LuaValue;Ljava/lang/Integer;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v7, v6, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 757
    :goto_12c
    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    const/4 v8, 0x1

    new-array v8, v8, [Lorg/luaj/vm2/LuaValue;

    invoke-static {v6}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v10

    invoke-static {v10, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    aput-object v10, v8, v16

    const-string v2, "AttributeChanged"

    invoke-virtual {v7, v3, v2, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .line 758
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move/from16 v7, v16

    new-array v7, v7, [Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v2, v3, v0, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .line 759
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 752
    .end local v6    # "k":Ljava/lang/String;
    .end local v9    # "v":Lorg/luaj/vm2/LuaValue;
    nop

    .line 757
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_163
    const-string v0, "children"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1d0

    goto/16 :goto_636

    :sswitch_16d
    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 770
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .local v0, "t":Lorg/luaj/vm2/LuaTable;
    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$forEach\\10":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1049
    .local v6, "$i$f$forEach\\10\\770":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_183
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_19d

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\10":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Ljava/lang/String;

    .local v9, "it\\11":Ljava/lang/String;
    const/4 v10, 0x0

    .line 770
    .local v10, "$i$a$-forEach-InstanceApi$callMethod$6\\11\\1049\\0":I
    invoke-static {v9}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v11

    check-cast v11, Lorg/luaj/vm2/LuaValue;

    const/4 v12, 0x0

    invoke-virtual {v0, v12, v11}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 1049
    .end local v9    # "it\\11":Ljava/lang/String;
    .end local v10    # "$i$a$-forEach-InstanceApi$callMethod$6\\11\\1049\\0":I
    nop

    .end local v8    # "element\\10":Ljava/lang/Object;
    goto :goto_183

    .line 1050
    :cond_19d
    nop

    .line 770
    .end local v2    # "$this$forEach\\10":Ljava/lang/Iterable;
    .end local v6    # "$i$f$forEach\\10\\770":I
    nop

    .end local v0    # "t":Lorg/luaj/vm2/LuaTable;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_1a3
    const-string v2, "GetAttributeChangedSignal"

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_636

    .line 761
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v3, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_1c8
    const-string v0, "GetChildren"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 730
    :cond_1d0
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_1e2
    const-string v0, "GetAttributes"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 749
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/Attributes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 750
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .restart local v0    # "t":Lorg/luaj/vm2/LuaTable;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_202
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_226

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map$Entry;

    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .local v7, "k":Ljava/lang/String;
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "v":Ljava/lang/Object;
    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    const/4 v12, 0x6

    const/4 v13, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v8 .. v13}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->toLua$default(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Ljava/lang/Object;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ILjava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v0, v7, v6}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .end local v7    # "k":Ljava/lang/String;
    .end local v9    # "v":Ljava/lang/Object;
    goto :goto_202

    .end local v0    # "t":Lorg/luaj/vm2/LuaTable;
    :cond_226
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_22a
    const-string v0, "FindFirstDescendant"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 725
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x1

    invoke-virtual {v3, v2, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_248
    const-string v0, "GetFullName"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 742
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->fullName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_25f
    const-string v0, "GetService"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_29d

    goto/16 :goto_636

    :sswitch_269
    const-string v0, "GetDebugId"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 743
    invoke-static {v3}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_284
    const-string v0, "IsPropertyModified"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 745
    sget-object v0, Lorg/luaj/vm2/LuaValue;->FALSE:Lorg/luaj/vm2/LuaBoolean;

    const-string v2, "FALSE"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_297
    invoke-virtual {v4, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 764
    :cond_29d
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v0

    .line 765
    .local v0, "n":Ljava/lang/String;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    const-string v7, "UserSettings"

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2f8

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$firstOrNull\\6":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1047
    .local v7, "$i$f$firstOrNull\\6\\765":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_2b8
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_2e1

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\6":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v10, "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v11, 0x0

    .line 765
    .local v11, "$i$a$-firstOrNull-InstanceApi$callMethod$3\\7\\1047\\0":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_2dc

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_2dc

    const/4 v10, 0x0

    goto :goto_2dd

    :cond_2dc
    const/4 v10, 0x1

    .line 1047
    .end local v10    # "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v11    # "$i$a$-firstOrNull-InstanceApi$callMethod$3\\7\\1047\\0":I
    :goto_2dd
    if-eqz v10, :cond_2b8

    move-object v6, v9

    goto :goto_2e2

    .line 1048
    .end local v9    # "element\\6":Ljava/lang/Object;
    :cond_2e1
    nop

    .line 765
    .end local v2    # "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .end local v7    # "$i$f$firstOrNull\\6\\765":I
    :goto_2e2
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v6, :cond_2f0

    .line 1017
    .local v6, "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x0

    .line 765
    .local v2, "$i$a$-let-InstanceApi$callMethod$4\\8\\765\\0":I
    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v7, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    .end local v2    # "$i$a$-let-InstanceApi$callMethod$4\\8\\765\\0":I
    .end local v6    # "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    if-eqz v2, :cond_2f0

    goto :goto_2f5

    :cond_2f0
    sget-object v2, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    invoke-static {v2, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_2f5
    check-cast v2, Lorg/luaj/vm2/Varargs;

    return-object v2

    .line 766
    :cond_2f8
    instance-of v2, v3, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-eqz v2, :cond_2ff

    move-object v6, v3

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/DataModel;

    :cond_2ff
    if-nez v6, :cond_307

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v6

    .line 767
    .local v6, "dm":Lcom/exampletest/mobilestudiotest/model/DataModel;
    :cond_307
    invoke-static {v4, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_31b

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v6, v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    invoke-virtual {v2, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    goto :goto_340

    .line 768
    :cond_31b
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v6, v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    if-nez v7, :cond_33c

    invoke-virtual {v6, v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    .line 1017
    move-object v8, v7

    .local v8, "it\\9":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 768
    .local v9, "$i$a$-also-InstanceApi$callMethod$5\\9\\768\\0":I
    sget-object v10, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->getServiceNames()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_33c

    const/4 v12, 0x0

    invoke-virtual {v8, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->setArchivable(Z)V

    .end local v8    # "it\\9":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-also-InstanceApi$callMethod$5\\9\\768\\0":I
    :cond_33c
    invoke-virtual {v2, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    .end local v0    # "n":Ljava/lang/String;
    .end local v6    # "dm":Lcom/exampletest/mobilestudiotest/model/DataModel;
    :goto_340
    move-object v0, v2

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_345
    const-string v0, "GetAttribute"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 747
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/Attributes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v6 .. v11}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->toLua$default(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Ljava/lang/Object;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ILjava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_36c
    const-string v0, "FindFirstAncestorOfClass"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 727
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_378
    if-eqz v0, :cond_38d

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_38d

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    goto :goto_378

    :cond_38d
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_397
    const-string v0, "Clone"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 740
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getArchivable()Z

    move-result v0

    if-nez v0, :cond_3a8

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    goto :goto_3b2

    :cond_3a8
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->cloneTree()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    :goto_3b2
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_3b9
    const-string v0, "IsA"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 732
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_3d7
    const-string v0, "GetPropertyChangedSignal"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 762
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Changed:"

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v3, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_3fe
    const-string v0, "FindFirstChildWhichIsA"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 724
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    invoke-virtual {v5, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v6

    invoke-virtual {v3, v2, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildWhichIsA(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_424
    const-string v0, "IsDescendantOf"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 733
    invoke-static/range {v18 .. v18}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v0, v18

    .local v0, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 1043
    .local v7, "$i$f$udOrNull\\1\\733":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_43d

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_43e

    :cond_43d
    move-object v8, v6

    :goto_43e
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v9, :cond_443

    move-object v6, v8

    :cond_443
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 733
    .end local v0    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\1\\733":I
    if-eqz v6, :cond_44d

    .line 1017
    .local v6, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v0, 0x0

    .line 733
    .local v0, "$i$a$-let-InstanceApi$callMethod$1\\2\\733\\0":I
    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v14

    .end local v0    # "$i$a$-let-InstanceApi$callMethod$1\\2\\733\\0":I
    .end local v6    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_44e

    :cond_44d
    const/4 v14, 0x0

    :goto_44e
    invoke-static {v14}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_459
    const-string v0, "FindFirstAncestor"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 726
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_465
    if-eqz v0, :cond_47a

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_47a

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    goto :goto_465

    :cond_47a
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_484
    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 773
    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0

    .local v0, "t":Ljava/util/List;
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    .local v2, "tg":Ljava/lang/String;
    invoke-interface {v0, v2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4ca

    invoke-direct {v1, v3, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setTags(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;)V

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v8

    invoke-virtual {v8, v7}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "TagRemoved:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x1

    new-array v9, v9, [Lorg/luaj/vm2/LuaValue;

    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v10, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v10

    const/16 v16, 0x0

    aput-object v10, v9, v16

    invoke-virtual {v6, v7, v8, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    :cond_4ca
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .end local v0    # "t":Ljava/util/List;
    .end local v2    # "tg":Ljava/lang/String;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_4d3
    invoke-virtual {v4, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_583

    goto/16 :goto_636

    :sswitch_4db
    const-string v0, "ClearAllChildren"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 741
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\4":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1045
    .local v2, "$i$f$forEach\\4\\741":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_4f4
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_50d

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\4":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 741
    .local v9, "$i$a$-forEach-InstanceApi$callMethod$2\\5\\1045\\0":I
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v10

    if-nez v10, :cond_50b

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->destroy()V

    .line 1045
    .end local v8    # "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-forEach-InstanceApi$callMethod$2\\5\\1045\\0":I
    :cond_50b
    nop

    .end local v7    # "element\\4":Ljava/lang/Object;
    goto :goto_4f4

    .line 1046
    :cond_50d
    nop

    .line 741
    .end local v0    # "$this$forEach\\4":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\4\\741":I
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_517
    const-string v0, "ResetPropertyToDefault"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 746
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v2, "NONE"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_52a
    const-string v0, "IsAncestorOf"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 734
    invoke-static/range {v18 .. v18}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v0, v18

    .local v0, "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 1044
    .local v7, "$i$f$udOrNull\\3\\734":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_543

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_544

    :cond_543
    move-object v8, v6

    :goto_544
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v9, :cond_549

    move-object v6, v8

    :cond_549
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 734
    .end local v0    # "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\3\\734":I
    if-eqz v6, :cond_552

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v14

    goto :goto_553

    :cond_552
    const/4 v14, 0x0

    :goto_553
    invoke-static {v14}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_55e
    const-string v0, "FindFirstChildOfClass"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 723
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_57b
    const-string v0, "Remove"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 736
    :cond_583
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v0

    if-nez v0, :cond_5a6

    instance-of v0, v3, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-nez v0, :cond_5a6

    .line 737
    invoke-static {v4, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_597

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->destroy()V

    goto :goto_59c

    :cond_597
    const/4 v0, 0x2

    const/4 v12, 0x0

    invoke-static {v3, v6, v12, v0, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->setParent$default(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;IILjava/lang/Object;)V

    .line 738
    :goto_59c
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 735
    nop

    .line 736
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    :cond_5a6
    new-instance v0, Lorg/luaj/vm2/LuaError;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Cannot destroy "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 721
    :sswitch_5c3
    const-string v0, "GetDescendants"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 731
    const/4 v8, 0x1

    invoke-static {v3, v6, v8, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_5d8
    const-string v0, "FindFirstAncestorWhichIsA"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 728
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_5e4
    if-eqz v0, :cond_5fa

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    const-string v6, "tojstring(...)"

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_5fa

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    goto :goto_5e4

    :cond_5fa
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_655

    .line 721
    :sswitch_603
    const-string v0, "WaitForChild"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 729
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x3

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v8

    invoke-virtual {v8}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v8

    if-eqz v8, :cond_62b

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->todouble()D

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    :cond_62b
    invoke-virtual {v0, v3, v2, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->waitForChild(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Double;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    goto :goto_655

    .line 721
    :sswitch_630
    invoke-virtual {v4, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_637

    :cond_636
    :goto_636
    goto :goto_64d

    .line 771
    :cond_637
    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v0, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_655

    .line 774
    :goto_64d
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/RobloxServices;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/RobloxServices;

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/lua/RobloxServices;->call(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    .line 721
    :goto_655
    return-object v0

    :sswitch_data_656
    .sparse-switch
        -0x7f969d40 -> :sswitch_630
        -0x7907ed78 -> :sswitch_603
        -0x759fe19c -> :sswitch_5d8
        -0x7087da00 -> :sswitch_5c3
        -0x6e501b5c -> :sswitch_57b
        -0x6b4518e4 -> :sswitch_55e
        -0x59d0440c -> :sswitch_52a
        -0x580d987e -> :sswitch_517
        -0x544fc1ad -> :sswitch_4db
        -0x3ff3c826 -> :sswitch_4d3
        -0x3c1e8faa -> :sswitch_484
        -0x3277a0b6 -> :sswitch_459
        -0x2f12f5e2 -> :sswitch_424
        -0x142c40e1 -> :sswitch_3fe
        -0x1006eeef -> :sswitch_3d7
        0x12037 -> :sswitch_3b9
        0x3e2ed3d -> :sswitch_397
        0x5330b37 -> :sswitch_36c
        0xa007006 -> :sswitch_345
        0xb81de9c -> :sswitch_297
        0xf681928 -> :sswitch_284
        0x10836eb8 -> :sswitch_269
        0x2ae2de9f -> :sswitch_25f
        0x2e971710 -> :sswitch_248
        0x2f6ae0b4 -> :sswitch_22a
        0x360d912d -> :sswitch_1e2
        0x422e4355 -> :sswitch_1c8
        0x58fd6016 -> :sswitch_1a3
        0x5ebe346f -> :sswitch_16d
        0x62ea5dff -> :sswitch_163
        0x6654307a -> :sswitch_f0
        0x749aeb59 -> :sswitch_9d
        0x77fdb45f -> :sswitch_8c
        0x79b9eb05 -> :sswitch_66
    .end sparse-switch
.end method
