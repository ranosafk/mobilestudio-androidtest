.method private final animateR6(FLjava/lang/String;)V
    .registers 32
    .param p1, "dt"    # F
    .param p2, "pose"    # Ljava/lang/String;

    .line 687
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->vel:Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->vel:Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    mul-float/2addr v3, v4

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->vel:Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->vel:Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v3

    double-to-float v3, v3

    .line 688
    .local v3, "speed":F
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->humanoid:Lcom/exampletest/mobilestudiotest/model/Instance;

    const/4 v5, 0x0

    if-eqz v4, :cond_33

    const-string v6, "WalkSpeed"

    invoke-virtual {v4, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    goto :goto_34

    :cond_33
    move-object v4, v5

    :goto_34
    instance-of v6, v4, Ljava/lang/Number;

    if-eqz v6, :cond_3b

    move-object v5, v4

    check-cast v5, Ljava/lang/Number;

    :cond_3b
    if-eqz v5, :cond_42

    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    move-result v4

    goto :goto_44

    :cond_42
    const/high16 v4, 0x41800000    # 16.0f

    :goto_44
    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v4, v5}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v4

    .line 689
    .local v4, "walk":F
    const/4 v6, 0x0

    .local v6, "amplitude":F
    const/4 v7, 0x0

    .local v7, "frequency":F
    const/4 v8, 0x0

    .local v8, "climbFudge":F
    const/4 v9, 0x0

    .line 690
    .local v9, "maxVel":F
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v10

    const-string v13, "Neck"

    const-string v15, "Climbing"

    const/high16 v16, 0x41100000    # 9.0f

    const-string v12, "Left Hip"

    const-string v14, "Right Hip"

    const-string v11, "Left Shoulder"

    const-string v5, "Right Shoulder"

    move/from16 v20, v3

    .end local v3    # "speed":F
    .local v20, "speed":F
    const/high16 v3, 0x3f000000    # 0.5f

    sparse-switch v10, :sswitch_data_24e

    move/from16 v21, v4

    const/high16 v3, 0x3f800000    # 1.0f

    .end local v4    # "walk":F
    .local v21, "walk":F
    goto/16 :goto_104

    .end local v21    # "walk":F
    .restart local v4    # "walk":F
    :sswitch_6d
    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_95

    .line 703
    const/high16 v6, 0x3f800000    # 1.0f

    const/high16 v7, 0x41100000    # 9.0f

    const v8, 0x4048f5c3    # 3.14f

    const/high16 v9, 0x3f000000    # 0.5f

    move/from16 v21, v4

    const/high16 v3, 0x3f800000    # 1.0f

    goto/16 :goto_10c

    .line 690
    :sswitch_82
    const-string v10, "Jumping"

    invoke-virtual {v2, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_95

    move/from16 v21, v4

    goto :goto_c6

    :sswitch_8d
    const-string v10, "Running"

    invoke-virtual {v2, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_9a

    :cond_95
    move/from16 v21, v4

    const/high16 v3, 0x3f800000    # 1.0f

    goto :goto_104

    .line 702
    :cond_9a
    const/high16 v6, 0x3f800000    # 1.0f

    div-float v10, v20, v4

    move/from16 v21, v4

    .end local v4    # "walk":F
    .restart local v21    # "walk":F
    const v4, 0x3fcccccd    # 1.6f

    invoke-static {v10, v3, v4}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v4

    mul-float v7, v4, v16

    div-float v4, v20, v21

    const v10, 0x3fe66666    # 1.8f

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v4, v3, v10}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v4

    const v10, 0x3e19999a    # 0.15f

    mul-float v9, v4, v10

    goto :goto_10c

    .line 690
    .end local v21    # "walk":F
    .restart local v4    # "walk":F
    :sswitch_ba
    move/from16 v21, v4

    const/high16 v3, 0x3f800000    # 1.0f

    .end local v4    # "walk":F
    .restart local v21    # "walk":F
    const-string v4, "FreeFall"

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_104

    .line 692
    :goto_c6
    const v3, 0x4048f5c3    # 3.14f

    const/high16 v4, 0x3f000000    # 0.5f

    invoke-direct {v0, v5, v3, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    const v3, -0x3fb70a3d    # -3.14f

    invoke-direct {v0, v11, v3, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 693
    const/4 v3, 0x0

    invoke-direct {v0, v14, v3, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    invoke-direct {v0, v12, v3, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 694
    const v4, 0x3e99999a    # 0.3f

    invoke-direct {v0, v13, v3, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 695
    return-void

    .line 690
    .end local v21    # "walk":F
    .restart local v4    # "walk":F
    :sswitch_e2
    move/from16 v21, v4

    const/high16 v3, 0x3f800000    # 1.0f

    .end local v4    # "walk":F
    .restart local v21    # "walk":F
    const-string v4, "Seated"

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_ef

    goto :goto_104

    .line 698
    :cond_ef
    const v3, 0x3fc8f5c3    # 1.57f

    const/high16 v4, 0x3f000000    # 0.5f

    invoke-direct {v0, v5, v3, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    const v5, -0x40370a3d    # -1.57f

    invoke-direct {v0, v11, v5, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 699
    invoke-direct {v0, v14, v3, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    invoke-direct {v0, v12, v5, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 700
    return-void

    .line 704
    :cond_104
    :goto_104
    const v6, 0x3dcccccd    # 0.1f

    const/high16 v7, 0x3f800000    # 1.0f

    const v9, 0x3e19999a    # 0.15f

    .line 706
    :goto_10c
    invoke-static {v2, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_12a

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->vel:Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    const v4, 0x3f333333    # 0.7f

    mul-float v4, v4, v21

    div-float/2addr v3, v4

    const v4, 0x3f99999a    # 1.2f

    const/4 v10, 0x0

    invoke-static {v3, v10, v4}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v3

    .line 707
    .local v3, "climbSpeed":F
    :cond_12a
    iget v4, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->walkT:F

    mul-float v10, v1, v7

    mul-float/2addr v10, v3

    add-float/2addr v4, v10

    iput v4, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->walkT:F

    .line 708
    iget v4, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->walkT:F

    move v10, v3

    .end local v3    # "climbSpeed":F
    .local v10, "climbSpeed":F
    float-to-double v2, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v2

    double-to-float v2, v2

    mul-float/2addr v2, v6

    .line 709
    .local v2, "desired":F
    add-float v3, v2, v8

    .local v3, "rs":F
    sub-float v4, v2, v8

    .line 710
    .local v4, "ls":F
    neg-float v15, v2

    move/from16 v19, v3

    .end local v3    # "rs":F
    .local v15, "rh":F
    .local v19, "rs":F
    neg-float v3, v2

    .line 711
    .local v3, "lh":F
    move/from16 v23, v2

    .end local v2    # "desired":F
    .local v23, "desired":F
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emote:Ljava/lang/String;

    move/from16 v24, v4

    .end local v4    # "ls":F
    .local v24, "ls":F
    const-string v4, "dance"

    move/from16 v25, v6

    .end local v6    # "amplitude":F
    .local v25, "amplitude":F
    const-string v6, "cheer"

    if-eqz v2, :cond_208

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v26

    const v27, 0x40266666    # 2.6f

    sparse-switch v26, :sswitch_data_264

    goto/16 :goto_208

    :sswitch_15e
    move/from16 v26, v7

    .end local v7    # "frequency":F
    .local v26, "frequency":F
    const-string v7, "point"

    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_17b

    .line 713
    const v2, 0x3fc8f5c3    # 1.57f

    move/from16 v28, v8

    move/from16 v7, v24

    const/high16 v22, 0x3f000000    # 0.5f

    .end local v19    # "rs":F
    .local v2, "rs":F
    goto/16 :goto_212

    .line 711
    .end local v2    # "rs":F
    .end local v26    # "frequency":F
    .restart local v7    # "frequency":F
    .restart local v19    # "rs":F
    :sswitch_173
    move/from16 v26, v7

    .end local v7    # "frequency":F
    .restart local v26    # "frequency":F
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_181

    :cond_17b
    move/from16 v28, v8

    const/high16 v22, 0x3f000000    # 0.5f

    goto/16 :goto_20e

    .line 715
    :cond_181
    iget v2, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emoteTime:F

    const/high16 v7, 0x40a00000    # 5.0f

    mul-float/2addr v2, v7

    move/from16 v16, v7

    move/from16 v28, v8

    .end local v8    # "climbFudge":F
    .local v28, "climbFudge":F
    float-to-double v7, v2

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v2, v7

    const/high16 v22, 0x3f000000    # 0.5f

    mul-float v2, v2, v22

    add-float v2, v2, v22

    mul-float v2, v2, v27

    .end local v19    # "rs":F
    .restart local v2    # "rs":F
    iget v7, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emoteTime:F

    mul-float v7, v7, v16

    const v18, 0x4048f5c3    # 3.14f

    add-float v7, v7, v18

    float-to-double v7, v7

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v7, v7

    mul-float v7, v7, v22

    add-float v7, v7, v22

    const v8, -0x3fd9999a    # -2.6f

    mul-float/2addr v7, v8

    .end local v24    # "ls":F
    .local v7, "ls":F
    goto :goto_212

    .line 711
    .end local v2    # "rs":F
    .end local v26    # "frequency":F
    .end local v28    # "climbFudge":F
    .local v7, "frequency":F
    .restart local v8    # "climbFudge":F
    .restart local v19    # "rs":F
    .restart local v24    # "ls":F
    :sswitch_1b0
    move/from16 v26, v7

    move/from16 v28, v8

    const/high16 v22, 0x3f000000    # 0.5f

    .end local v7    # "frequency":F
    .end local v8    # "climbFudge":F
    .restart local v26    # "frequency":F
    .restart local v28    # "climbFudge":F
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_20e

    .line 714
    iget v2, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emoteTime:F

    const/high16 v7, 0x41400000    # 12.0f

    mul-float/2addr v2, v7

    move/from16 v16, v7

    float-to-double v7, v2

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v2, v7

    const v7, 0x3e4ccccd    # 0.2f

    mul-float/2addr v2, v7

    const v18, 0x4048f5c3    # 3.14f

    add-float v2, v2, v18

    .end local v19    # "rs":F
    .restart local v2    # "rs":F
    iget v8, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emoteTime:F

    mul-float v8, v8, v16

    move/from16 v16, v7

    float-to-double v7, v8

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v7, v7

    mul-float v7, v7, v16

    const v17, -0x3fb70a3d    # -3.14f

    add-float v7, v7, v17

    .end local v24    # "ls":F
    .local v7, "ls":F
    goto :goto_212

    .line 711
    .end local v2    # "rs":F
    .end local v26    # "frequency":F
    .end local v28    # "climbFudge":F
    .local v7, "frequency":F
    .restart local v8    # "climbFudge":F
    .restart local v19    # "rs":F
    .restart local v24    # "ls":F
    :sswitch_1e6
    move/from16 v26, v7

    move/from16 v28, v8

    const/high16 v22, 0x3f000000    # 0.5f

    .end local v7    # "frequency":F
    .end local v8    # "climbFudge":F
    .restart local v26    # "frequency":F
    .restart local v28    # "climbFudge":F
    const-string v7, "wave"

    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1f5

    goto :goto_20e

    .line 712
    :cond_1f5
    iget v2, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emoteTime:F

    mul-float v2, v2, v16

    float-to-double v7, v2

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v2, v7

    const v7, 0x3ee66666    # 0.45f

    mul-float/2addr v2, v7

    add-float v2, v2, v27

    move/from16 v7, v24

    .end local v19    # "rs":F
    .restart local v2    # "rs":F
    goto :goto_212

    .line 711
    .end local v2    # "rs":F
    .end local v26    # "frequency":F
    .end local v28    # "climbFudge":F
    .restart local v7    # "frequency":F
    .restart local v8    # "climbFudge":F
    .restart local v19    # "rs":F
    :cond_208
    :goto_208
    move/from16 v26, v7

    move/from16 v28, v8

    const/high16 v22, 0x3f000000    # 0.5f

    .line 717
    .end local v7    # "frequency":F
    .end local v8    # "climbFudge":F
    .restart local v26    # "frequency":F
    .restart local v28    # "climbFudge":F
    :cond_20e
    :goto_20e
    move/from16 v2, v19

    move/from16 v7, v24

    .end local v19    # "rs":F
    .end local v24    # "ls":F
    .restart local v2    # "rs":F
    .local v7, "ls":F
    :goto_212
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->equipped:Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v8, :cond_21d

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emote:Ljava/lang/String;

    if-nez v8, :cond_21d

    const v2, 0x3fc8f5c3    # 1.57f

    .line 718
    :cond_21d
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emote:Ljava/lang/String;

    if-eqz v8, :cond_224

    move/from16 v8, v22

    goto :goto_225

    :cond_224
    move v8, v9

    :goto_225
    invoke-direct {v0, v5, v2, v8, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 719
    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emote:Ljava/lang/String;

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_23a

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->emote:Ljava/lang/String;

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_23a

    move v4, v9

    goto :goto_23c

    :cond_23a
    move/from16 v4, v22

    :goto_23c
    invoke-direct {v0, v11, v7, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 720
    invoke-direct {v0, v14, v15, v9, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 721
    invoke-direct {v0, v12, v3, v9, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 722
    const v4, 0x3e99999a    # 0.3f

    const/4 v5, 0x0

    invoke-direct {v0, v13, v5, v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->motor(Ljava/lang/String;FFF)V

    .line 723
    return-void

    nop

    :sswitch_data_24e
    .sparse-switch
        -0x6ca0a67c -> :sswitch_e2
        -0x57dd4fd9 -> :sswitch_ba
        -0x40585261 -> :sswitch_8d
        0x1868a4d4 -> :sswitch_82
        0x3a6abd2d -> :sswitch_6d
    .end sparse-switch

    :sswitch_data_264
    .sparse-switch
        0x3792f9 -> :sswitch_1e6
        0x5a3e54d -> :sswitch_1b0
        0x5aeefb3 -> :sswitch_173
        0x65e5590 -> :sswitch_15e
    .end sparse-switch
.end method
