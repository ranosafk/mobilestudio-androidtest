.method static final _init_$lambda$55(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 196
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Color3;

    .line 197
    .local v0, "c":Lcom/exampletest/mobilestudiotest/model/Color3;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_ac

    goto/16 :goto_9e

    :sswitch_16
    const-string v1, "ToHex"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 201
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda138;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda138;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_ab

    .line 197
    :sswitch_2b
    const-string v1, "ToHSV"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 200
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda137;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda137;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_ab

    .line 197
    :sswitch_40
    const-string v1, "lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_51

    goto :goto_9e

    :sswitch_49
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 199
    :cond_51
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda136;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda136;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_ab

    .line 197
    :sswitch_5d
    const-string v1, "r"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_80

    goto :goto_9e

    :sswitch_66
    const-string v1, "g"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8f

    goto :goto_9e

    :sswitch_6f
    const-string v1, "b"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9f

    goto :goto_9e

    :sswitch_78
    const-string v1, "R"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 198
    :cond_80
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Color3;->getR()F

    move-result v2

    goto :goto_a5

    .line 197
    :sswitch_87
    const-string v1, "G"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 198
    :cond_8f
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Color3;->getG()F

    move-result v2

    goto :goto_a5

    .line 197
    :sswitch_96
    const-string v1, "B"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9f

    :cond_9e
    :goto_9e
    goto :goto_aa

    .line 198
    :cond_9f
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Color3;->getB()F

    move-result v2

    :goto_a5
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_ab

    .line 202
    :goto_aa
    const/4 v1, 0x0

    .line 203
    :goto_ab
    return-object v1

    :sswitch_data_ac
    .sparse-switch
        0x42 -> :sswitch_96
        0x47 -> :sswitch_87
        0x52 -> :sswitch_78
        0x62 -> :sswitch_6f
        0x67 -> :sswitch_66
        0x72 -> :sswitch_5d
        0x241597 -> :sswitch_49
        0x32a177 -> :sswitch_40
        0x4d34430 -> :sswitch_2b
        0x4d34680 -> :sswitch_16
    .end sparse-switch
.end method
