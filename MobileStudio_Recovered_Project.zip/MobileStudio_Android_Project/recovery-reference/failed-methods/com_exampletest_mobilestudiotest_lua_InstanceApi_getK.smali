.method public final getK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Object;
    .registers 13
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 177
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_8a0

    goto :goto_45

    :sswitch_12
    const-string v0, "ClassName"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_45

    .line 179
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 177
    :sswitch_1f
    const-string v0, "Archivable"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_45

    .line 181
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getArchivable()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 177
    :sswitch_30
    const-string v0, "Name"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_45

    .line 178
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 177
    :sswitch_3d
    const-string v0, "Parent"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_46

    :cond_45
    :goto_45
    goto :goto_4b

    .line 180
    :cond_46
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    return-object v0

    .line 183
    :goto_4b
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isPart(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    const-string v1, "CFrame"

    if-eqz v0, :cond_179

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v2, 0x42652ee1

    sparse-switch v0, :sswitch_data_8b2

    goto/16 :goto_179

    :sswitch_5f
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 190
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_6c
    const-string v0, "RotVelocity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_bc

    goto/16 :goto_179

    :sswitch_76
    const-string v0, "AssemblyMass"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_100

    goto/16 :goto_179

    :sswitch_80
    const-string v0, "AssemblyLinearVelocity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_163

    goto/16 :goto_179

    :sswitch_8a
    const-string v0, "Position"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 184
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_9d
    const-string v0, "Orientation"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 185
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toOrientation()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_b4
    const-string v0, "AssemblyAngularVelocity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 192
    :cond_bc
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_c3
    const-string v0, "Color"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 188
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->color(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_d2
    const-string v0, "Rotation"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 186
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toEulerXYZ()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_e9
    const-string v0, "Size"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 187
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_f8
    const-string v0, "Mass"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 193
    :cond_100
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "s":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v1

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v2

    mul-float/2addr v1, v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v2

    mul-float/2addr v1, v2

    const v2, 0x3f333333    # 0.7f

    mul-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    return-object v1

    .line 183
    .end local v0    # "s":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :sswitch_11d
    const-string v0, "BrickColor"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_179

    .line 189
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_13c

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v2, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->color(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->closest(Lcom/exampletest/mobilestudiotest/model/Color3;)I

    move-result v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    :cond_13c
    return-object v0

    .line 183
    :sswitch_13d
    const-string v0, "PivotOffset"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_179

    .line 194
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_151

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    :cond_151
    return-object v0

    .line 183
    :sswitch_152
    const-string v0, "AssemblyRootPart"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 195
    return-object p1

    .line 183
    :sswitch_15b
    const-string v0, "Velocity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 191
    :cond_163
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_172

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->velocityOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    if-eqz v0, :cond_172

    goto :goto_178

    :cond_172
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    :goto_178
    return-object v0

    .line 197
    :cond_179
    :goto_179
    const-string v0, "Model"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18e

    .line 198
    const-string v0, "WorldPivot"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_18e

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    return-object v0

    .line 200
    :cond_18e
    const-string v0, "GuiBase2d"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_1d8

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_8f0

    goto :goto_1d8

    :sswitch_19f
    const-string v0, "AbsolutePosition"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d8

    .line 201
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsX()F

    move-result v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsY()F

    move-result v2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    return-object v0

    .line 200
    :sswitch_1b5
    const-string v0, "AbsoluteRotation"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d8

    .line 203
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 200
    :sswitch_1c2
    const-string v0, "AbsoluteSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d8

    .line 202
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsW()F

    move-result v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsH()F

    move-result v2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    return-object v0

    .line 206
    :cond_1d8
    :goto_1d8
    const-string v0, "UIGridStyleLayout"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f6

    const-string v0, "AbsoluteContentSize"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1f6

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsW()F

    move-result v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsH()F

    move-result v2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    return-object v0

    .line 207
    :cond_1f6
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "UIGridLayout"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/high16 v3, 0x42c80000    # 100.0f

    const/4 v4, 0x0

    if-eqz v0, :cond_233

    const-string v0, "AbsoluteCellSize"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_233

    const-string v0, "CellSize"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v1, :cond_21a

    move-object v4, v0

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/UDim2;

    :cond_21a
    if-eqz v4, :cond_22d

    .line 1017
    .local v4, "it\\1":Lcom/exampletest/mobilestudiotest/model/UDim2;
    const/4 v0, 0x0

    .line 207
    .local v0, "$i$a$-let-InstanceApi$getK$1\\1\\207\\0":I
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v3

    int-to-float v3, v3

    invoke-direct {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    .end local v0    # "$i$a$-let-InstanceApi$getK$1\\1\\207\\0":I
    .end local v4    # "it\\1":Lcom/exampletest/mobilestudiotest/model/UDim2;
    goto :goto_232

    :cond_22d
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-direct {v1, v3, v3}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    :goto_232
    return-object v1

    .line 208
    :cond_233
    const-string v0, "BaseScript"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    if-eqz v0, :cond_258

    .line 209
    const-string v0, "Enabled"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_258

    const-string v0, "Disabled"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    xor-int/2addr v0, v5

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 211
    :cond_258
    const-string v0, "Constraint"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_296

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_8fe

    goto :goto_296

    :sswitch_268
    const-string v0, "CurrentPosition"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_28b

    goto :goto_296

    :sswitch_271
    const-string v0, "CurrentAngle"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_28b

    goto :goto_296

    :sswitch_27a
    const-string v0, "CurrentDistance"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_296

    goto :goto_28b

    :sswitch_283
    const-string v0, "CurrentLength"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_296

    .line 212
    :cond_28b
    :goto_28b
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_295

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    :cond_295
    return-object v0

    .line 214
    :cond_296
    :goto_296
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    const-string v7, "IsLoaded"

    const-string v8, "Camera"

    const/4 v9, 0x0

    sparse-switch v6, :sswitch_data_910

    goto/16 :goto_875

    :sswitch_2a8
    const-string v1, "RunService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 279
    const-string v0, "ClientGitHash"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_891

    const-string v0, "mobile"

    return-object v0

    .line 214
    :sswitch_2bb
    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 264
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_95a

    .line 268
    goto/16 :goto_891

    .line 264
    :sswitch_2ca
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_315

    .line 267
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-nez v0, :cond_2ed

    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isEditCamera(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    if-eqz v0, :cond_2ed

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCamera()Lcom/exampletest/mobilestudiotest/render/FlyCamera;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->cframe()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    goto :goto_2f9

    :cond_2ed
    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2f9

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    :cond_2f9
    :goto_2f9
    return-object v0

    .line 264
    :sswitch_2fa
    const-string v0, "ViewportSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_315

    .line 265
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->viewportSizeDp()Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v0

    return-object v0

    .line 264
    :sswitch_30d
    const-string v0, "Focus"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_317

    :cond_315
    goto/16 :goto_891

    .line 268
    :cond_317
    const-string v0, "Focus"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_325

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    :cond_325
    return-object v0

    .line 214
    :sswitch_326
    const-string v1, "DataModel"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 233
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const-wide/16 v1, 0x0

    sparse-switch v0, :sswitch_data_968

    .line 240
    goto/16 :goto_891

    .line 233
    :sswitch_339
    const-string v0, "GameId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 235
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCloud()Lcom/exampletest/mobilestudiotest/net/CloudPlace;

    move-result-object v0

    if-eqz v0, :cond_356

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->getUniverseId()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    goto :goto_35a

    :cond_356
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :goto_35a
    return-object v0

    .line 233
    :sswitch_35b
    const-string v0, "CreatorType"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 237
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    return-object v0

    .line 233
    :sswitch_369
    const-string v0, "PlaceId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 234
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCloud()Lcom/exampletest/mobilestudiotest/net/CloudPlace;

    move-result-object v0

    if-eqz v0, :cond_386

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->getPlaceId()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    goto :goto_38a

    :cond_386
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :goto_38a
    return-object v0

    .line 233
    :sswitch_38b
    const-string v0, "PrivateServerOwnerId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 240
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    return-object v0

    .line 233
    :sswitch_398
    const-string v0, "JobId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3a9

    goto :goto_3c1

    :sswitch_3a1
    const-string v0, "PrivateServerId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 239
    :cond_3a9
    const-string v0, ""

    return-object v0

    .line 233
    :sswitch_3ac
    const-string v0, "CreatorId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 236
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    return-object v0

    .line 233
    :sswitch_3b9
    const-string v0, "PlaceVersion"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3c3

    :cond_3c1
    :goto_3c1
    goto/16 :goto_891

    .line 238
    :cond_3c3
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_3c8
    const-string v1, "UserInputService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 273
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_98a

    .line 276
    goto/16 :goto_891

    .line 273
    :sswitch_3d9
    const-string v0, "TouchEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_438

    .line 274
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 273
    :sswitch_3e6
    const-string v0, "AccelerometerEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_3ef
    const-string v0, "MouseEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_3f8
    const-string v0, "VREnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_401
    const-string v0, "MouseIconEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_424

    goto :goto_438

    :sswitch_40a
    const-string v0, "KeyboardEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_413
    const-string v0, "GyroscopeEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_41c
    const-string v0, "MouseBehavior"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_438

    .line 276
    :cond_424
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_42f

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    :cond_42f
    return-object v0

    .line 273
    :sswitch_430
    const-string v0, "GamepadEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    :cond_438
    :goto_438
    goto/16 :goto_891

    .line 275
    :cond_43a
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_43f
    const-string v1, "Players"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 215
    nop

    .line 216
    const-string v0, "LocalPlayer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_45d

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_45c

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getPlayer()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    :cond_45c
    return-object v4

    .line 217
    :cond_45d
    const-string v0, "MaxPlayers"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_891

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_46a
    const-string v1, "Lighting"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 270
    nop

    .line 271
    const-string v0, "TimeOfDay"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_891

    const-string v0, "ClockTime"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_488

    move-object v4, v0

    check-cast v4, Ljava/lang/Number;

    :cond_488
    if-eqz v4, :cond_48f

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto :goto_491

    :cond_48f
    const/high16 v0, 0x41600000    # 14.0f

    .local v0, "ct":F
    :goto_491
    float-to-int v1, v0

    .local v1, "h":I
    int-to-float v2, v1

    sub-float v2, v0, v2

    const/high16 v3, 0x42700000    # 60.0f

    mul-float/2addr v2, v3

    float-to-int v2, v2

    .local v2, "m":I
    sget-object v3, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v3, v4}, [Ljava/lang/Object;

    move-result-object v3

    const/4 v4, 0x2

    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%02d:%02d:00"

    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "format(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v3

    .line 214
    .end local v0    # "ct":F
    .end local v1    # "h":I
    .end local v2    # "m":I
    :sswitch_4b8
    const-string v1, "TextLabel"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7aa

    goto/16 :goto_875

    :sswitch_4c2
    const-string v1, "Humanoid"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 219
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_9b0

    .line 225
    goto/16 :goto_891

    .line 219
    :sswitch_4d3
    const-string v0, "MoveDirection"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 222
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_4ea

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->moveDirection(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    if-eqz v0, :cond_4ea

    goto :goto_4f0

    :cond_4ea
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    :goto_4f0
    return-object v0

    .line 219
    :sswitch_4f1
    const-string v0, "SeatPart"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 225
    return-object v4

    .line 219
    :sswitch_4fa
    const-string v0, "FloorMaterial"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 223
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v1

    if-eqz v1, :cond_513

    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->isGrounded(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v1

    if-ne v1, v5, :cond_513

    goto :goto_514

    :cond_513
    move v5, v9

    :goto_514
    if-eqz v5, :cond_519

    const/16 v1, 0x100

    goto :goto_51b

    :cond_519
    const/16 v1, 0x700

    :goto_51b
    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    return-object v0

    .line 219
    :sswitch_51f
    const-string v0, "Jump"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 224
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 219
    :sswitch_52c
    const-string v0, "RootPart"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 221
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    if-eqz v0, :cond_541

    const-string v1, "HumanoidRootPart"

    const/4 v2, 0x2

    invoke-static {v0, v1, v9, v2, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ZILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    :cond_541
    return-object v4

    .line 219
    :sswitch_542
    const-string v0, "Health"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_54c

    :cond_54a
    goto/16 :goto_891

    .line 220
    :cond_54c
    const-string v1, "Health_XML"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_55e

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_55e

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    :cond_55e
    return-object v1

    .line 214
    :sswitch_55f
    const-string v1, "ImageLabel"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_815

    goto/16 :goto_875

    :sswitch_569
    const-string v1, "TextBox"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7aa

    goto/16 :goto_875

    :sswitch_573
    const-string v1, "HttpService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 278
    const-string v0, "HttpEnabled"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_891

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_58d

    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    :cond_58d
    return-object v0

    .line 214
    :sswitch_58e
    const-string v1, "Sound"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 280
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const-wide/16 v1, 0x0

    sparse-switch v0, :sswitch_data_9ca

    .line 286
    goto/16 :goto_891

    .line 280
    :sswitch_5a1
    const-string v0, "TimePosition"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_604

    .line 282
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_5b3

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    :cond_5b3
    return-object v0

    .line 280
    :sswitch_5b4
    const-string v0, "IsPlaying"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_604

    .line 283
    const-string v0, "Playing"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 280
    :sswitch_5cf
    const-string v0, "PlaybackLoudness"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_604

    .line 285
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    return-object v0

    .line 280
    :sswitch_5dc
    const-string v0, "PlaybackSpeed"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_604

    .line 286
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_5f0

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    :cond_5f0
    return-object v0

    .line 280
    :sswitch_5f1
    invoke-virtual {p2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_604

    .line 284
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 280
    :sswitch_5fc
    const-string v0, "TimeLength"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_606

    :cond_604
    goto/16 :goto_891

    .line 281
    :cond_606
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_610

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    :cond_610
    return-object v0

    .line 214
    :sswitch_611
    const-string v1, "StudioService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 243
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_9e4

    .line 250
    goto/16 :goto_891

    .line 243
    :sswitch_622
    const-string v0, "ShowConstraintDetails"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_63c

    goto :goto_68d

    :sswitch_62b
    const-string v0, "ActiveScript"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 248
    return-object v4

    .line 243
    :sswitch_634
    const-string v0, "DraggerSolveConstraints"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 247
    :cond_63c
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 243
    :sswitch_641
    const-string v0, "UseLocalSpace"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 246
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 243
    :sswitch_64e
    const-string v0, "GridSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 244
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSnapEnabled()Z

    move-result v0

    if-eqz v0, :cond_66c

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v2

    :cond_66c
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 243
    :sswitch_671
    const-string v0, "Theme"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 250
    return-object v4

    .line 243
    :sswitch_67a
    const-string v0, "StudioLocaleId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 249
    const-string v0, "en-us"

    return-object v0

    .line 243
    :sswitch_685
    const-string v0, "RotateIncrement"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_68f

    :cond_68d
    :goto_68d
    goto/16 :goto_891

    .line 245
    :cond_68f
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnapEnabled()Z

    move-result v0

    if-eqz v0, :cond_6a5

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnap()F

    move-result v2

    :cond_6a5
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_6aa
    const-string v1, "DraggerService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 252
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_a06

    .line 262
    goto/16 :goto_891

    .line 252
    :sswitch_6bb
    const-string v0, "AngleSnapIncrement"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 258
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnap()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_6d2
    const-string v0, "GeometrySnapColor"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 262
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/16 v1, 0xff

    const/16 v2, 0xa5

    invoke-virtual {v0, v1, v2, v9}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_6e5
    const-string v0, "AngleSnapEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 257
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnapEnabled()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_6fc
    const-string v0, "AnimateHover"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_78c

    goto/16 :goto_799

    :sswitch_706
    const-string v0, "PivotSnapToGeometry"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_78c

    goto/16 :goto_799

    :sswitch_710
    const-string v0, "HoverThickness"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 253
    const v0, 0x3d23d70a    # 0.04f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_720
    const-string v0, "JointsEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 255
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_72d
    const-string v0, "LinearSnapIncrement"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 260
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_744
    const-string v0, "ShowHover"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_78c

    goto :goto_799

    :sswitch_74d
    const-string v0, "AlignDraggedObjects"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_78c

    goto :goto_799

    :sswitch_756
    const-string v0, "LinearSnapEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 259
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSnapEnabled()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_76d
    const-string v0, "CollisionsEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 256
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCollisionsEnabled()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_784
    const-string v0, "ShowPivotIndicator"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 254
    :cond_78c
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_791
    const-string v0, "HoverAnimateFrequency"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_79b

    :cond_799
    :goto_799
    goto/16 :goto_891

    .line 261
    :cond_79b
    const/high16 v0, 0x3e800000    # 0.25f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_7a2
    const-string v1, "TextButton"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 292
    :cond_7aa
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_a40

    goto :goto_7d6

    :sswitch_7b2
    const-string v0, "ContentText"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7d6

    .line 294
    const-string v0, "Text"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 292
    :sswitch_7c1
    const-string v0, "TextFits"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7d6

    .line 295
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 292
    :sswitch_7ce
    const-string v0, "TextBounds"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7d8

    :cond_7d6
    :goto_7d6
    goto/16 :goto_891

    .line 293
    :cond_7d8
    const-string v0, "TextSize"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_7e5

    check-cast v0, Ljava/lang/Number;

    goto :goto_7e6

    :cond_7e5
    move-object v0, v4

    :goto_7e6
    if-eqz v0, :cond_7ed

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto :goto_7ef

    :cond_7ed
    const/high16 v0, 0x41600000    # 14.0f

    .local v0, "s":F
    :goto_7ef
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const-string v2, "Text"

    invoke-virtual {p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v3, v2, Ljava/lang/String;

    if-eqz v3, :cond_7fe

    move-object v4, v2

    check-cast v4, Ljava/lang/String;

    :cond_7fe
    if-eqz v4, :cond_804

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v9

    :cond_804
    int-to-float v2, v9

    mul-float/2addr v2, v0

    const/high16 v3, 0x3f000000    # 0.5f

    mul-float/2addr v2, v3

    invoke-direct {v1, v2, v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    return-object v1

    .line 214
    .end local v0    # "s":F
    :sswitch_80d
    const-string v1, "ImageButton"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 232
    :cond_815
    invoke-static {p2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_891

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_820
    const-string v1, "Workspace"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 227
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_a4e

    .line 230
    goto :goto_891

    .line 227
    :sswitch_830
    const-string v0, "Gravity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_861

    .line 230
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_845

    const v0, 0x43443333    # 196.2f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    :cond_845
    return-object v0

    .line 227
    :sswitch_846
    const-string v0, "CurrentCamera"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_861

    .line 229
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_858

    invoke-virtual {p1, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    :cond_858
    return-object v0

    .line 227
    :sswitch_859
    const-string v0, "DistributedGameTime"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_862

    :cond_861
    goto :goto_891

    .line 228
    :cond_862
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getTime()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_86d
    const-string v1, "Player"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_876

    :cond_875
    :goto_875
    goto :goto_891

    .line 288
    :cond_876
    nop

    .line 289
    const-string v0, "PlayerGui"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_884

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    return-object v0

    .line 290
    :cond_884
    const-string v0, "Backpack"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_891

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    return-object v0

    .line 298
    :cond_891
    :goto_891
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 299
    .local v0, "key":Ljava/lang/String;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    return-object v1

    :sswitch_data_8a0
    .sparse-switch
        -0x71f00b36 -> :sswitch_3d
        0x24eeab -> :sswitch_30
        0x7094d7fd -> :sswitch_1f
        0x76db3c03 -> :sswitch_12
    .end sparse-switch

    :sswitch_data_8b2
    .sparse-switch
        -0x7cef5f03 -> :sswitch_15b
        -0x68a847e5 -> :sswitch_152
        -0x5f4bf4ab -> :sswitch_13d
        -0x33b84c3e -> :sswitch_11d
        0x247b14 -> :sswitch_f8
        0x275421 -> :sswitch_e9
        0x173739e -> :sswitch_d2
        0x3e43f43 -> :sswitch_c3
        0x9fe75f9 -> :sswitch_b4
        0xd9c9db0 -> :sswitch_9d
        0x306cfd49 -> :sswitch_8a
        0x3f7ca6c8 -> :sswitch_80
        0x4cf0aa1a -> :sswitch_76
        0x4f2c3bb4 -> :sswitch_6c
        0x76646aea -> :sswitch_5f
    .end sparse-switch

    :sswitch_data_8f0
    .sparse-switch
        -0x39cdddc8 -> :sswitch_1c2
        0xaab5e35 -> :sswitch_1b5
        0x39a4e7e0 -> :sswitch_19f
    .end sparse-switch

    :sswitch_data_8fe
    .sparse-switch
        -0x5771aa61 -> :sswitch_283
        0x5c15dc6e -> :sswitch_27a
        0x5fafa2fa -> :sswitch_271
        0x7776e9a2 -> :sswitch_268
    .end sparse-switch

    :sswitch_data_910
    .sparse-switch
        -0x715c78ff -> :sswitch_86d
        -0x4675f38b -> :sswitch_820
        -0x37e04bb3 -> :sswitch_80d
        -0x37c02121 -> :sswitch_7a2
        -0x141b4eeb -> :sswitch_6aa
        -0x19fb821 -> :sswitch_611
        0x4c5d8ef -> :sswitch_58e
        0xc9bd4ed -> :sswitch_573
        0xeb5ad3e -> :sswitch_569
        0x1fbe6279 -> :sswitch_55f
        0x2418859d -> :sswitch_4c2
        0x38859da7 -> :sswitch_4b8
        0x3efaa72c -> :sswitch_46a
        0x45cd5992 -> :sswitch_43f
        0x50b2bb16 -> :sswitch_3c8
        0x60c9757f -> :sswitch_326
        0x77deaf45 -> :sswitch_2bb
        0x7f0a9dca -> :sswitch_2a8
    .end sparse-switch

    :sswitch_data_95a
    .sparse-switch
        0x40e64b8 -> :sswitch_30d
        0x1faddde7 -> :sswitch_2fa
        0x76646aea -> :sswitch_2ca
    .end sparse-switch

    :sswitch_data_968
    .sparse-switch
        -0x6db1b60f -> :sswitch_3b9
        -0x64deb1b9 -> :sswitch_3ac
        -0x60e7dbf -> :sswitch_3a1
        0x446b998 -> :sswitch_398
        0x3da9edc8 -> :sswitch_38b
        0x45c35462 -> :sswitch_369
        0x580c3566 -> :sswitch_35b
        0x7eb20ccd -> :sswitch_339
    .end sparse-switch

    :sswitch_data_98a
    .sparse-switch
        -0x51ac7740 -> :sswitch_430
        -0x4623f209 -> :sswitch_41c
        -0x261cc564 -> :sswitch_413
        -0x25937ac6 -> :sswitch_40a
        0x14a562c3 -> :sswitch_401
        0x1865cce5 -> :sswitch_3f8
        0x1f05a6fc -> :sswitch_3ef
        0x47cb8012 -> :sswitch_3e6
        0x483dc322 -> :sswitch_3d9
    .end sparse-switch

    :sswitch_data_9b0
    .sparse-switch
        -0x7f661184 -> :sswitch_542
        -0x61983eb -> :sswitch_52c
        0x23684e -> :sswitch_51f
        0xdee5133 -> :sswitch_4fa
        0x38e57fb8 -> :sswitch_4f1
        0x53e5d68e -> :sswitch_4d3
    .end sparse-switch

    :sswitch_data_9ca
    .sparse-switch
        -0x66acb7cd -> :sswitch_5fc
        -0x15637a11 -> :sswitch_5f1
        -0x7d3fd34 -> :sswitch_5dc
        0x18d08c04 -> :sswitch_5cf
        0x37783784 -> :sswitch_5b4
        0x4ac98736 -> :sswitch_5a1
    .end sparse-switch

    :sswitch_data_9e4
    .sparse-switch
        -0x4aaba3cc -> :sswitch_685
        -0x134072d5 -> :sswitch_67a
        0x4d085a9 -> :sswitch_671
        0x16cf3087 -> :sswitch_64e
        0x2864e122 -> :sswitch_641
        0x2cac1a17 -> :sswitch_634
        0x5dcfb391 -> :sswitch_62b
        0x5e680008 -> :sswitch_622
    .end sparse-switch

    :sswitch_data_a06
    .sparse-switch
        -0x75d07b49 -> :sswitch_791
        -0x6a125f96 -> :sswitch_784
        -0x3a227fa0 -> :sswitch_76d
        -0x21c6646e -> :sswitch_756
        -0x2299299 -> :sswitch_74d
        0x4b9741f -> :sswitch_744
        0xc0dcb80 -> :sswitch_72d
        0x2db419b8 -> :sswitch_720
        0x3f65bdb8 -> :sswitch_710
        0x4246ac39 -> :sswitch_706
        0x46cb9efb -> :sswitch_6fc
        0x4c587d64 -> :sswitch_6e5
        0x5d2a5547 -> :sswitch_6d2
        0x6dfb80d2 -> :sswitch_6bb
    .end sparse-switch

    :sswitch_data_a40
    .sparse-switch
        -0x3814519e -> :sswitch_7ce
        -0x37fe4a91 -> :sswitch_7c1
        0x4c37b126 -> :sswitch_7b2
    .end sparse-switch

    :sswitch_data_a4e
    .sparse-switch
        -0x74bdc67e -> :sswitch_859
        -0x67062222 -> :sswitch_846
        0x73f10a2e -> :sswitch_830
    .end sparse-switch
.end method
