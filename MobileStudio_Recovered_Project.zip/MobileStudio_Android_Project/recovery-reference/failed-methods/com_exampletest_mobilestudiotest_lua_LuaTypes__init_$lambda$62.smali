.method static final _init_$lambda$62(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 7
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 226
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/UDim2;

    .line 227
    .local v0, "u":Lcom/exampletest/mobilestudiotest/model/UDim2;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_76

    goto :goto_5f

    :sswitch_15
    const-string v1, "Width"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5f

    goto :goto_43

    :sswitch_1e
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5f

    .line 230
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda106;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda106;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_75

    .line 227
    :sswitch_32
    const-string v1, "Y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_60

    goto :goto_5f

    :sswitch_3b
    const-string v1, "X"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5f

    .line 228
    :goto_43
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v4

    invoke-direct {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_75

    .line 227
    :sswitch_57
    const-string v1, "Height"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_60

    :cond_5f
    :goto_5f
    goto :goto_74

    .line 229
    :cond_60
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v4

    invoke-direct {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_75

    .line 231
    :goto_74
    const/4 v1, 0x0

    .line 232
    :goto_75
    return-object v1

    :sswitch_data_76
    .sparse-switch
        -0x7f6282b9 -> :sswitch_57
        0x58 -> :sswitch_3b
        0x59 -> :sswitch_32
        0x241597 -> :sswitch_1e
        0x4fb3da6 -> :sswitch_15
    .end sparse-switch
.end method
