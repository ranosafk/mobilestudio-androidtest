.method private final categoryOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)Ljava/lang/String;
    .registers 10
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "disp"    # Ljava/lang/String;
    .param p3, "t"    # I

    .line 120
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "Data"

    const-string v2, "Appearance"

    if-eqz v0, :cond_91

    .local v0, "cat\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 122
    .local v3, "$i$a$-let-PropertiesPanel$categoryOf$1\\1\\120\\0":I
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v4

    sparse-switch v4, :sswitch_data_bc

    goto :goto_31

    :sswitch_17
    const-string v4, "Position"

    invoke-virtual {p2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_32

    goto :goto_31

    :sswitch_20
    const-string v4, "Rotation"

    invoke-virtual {p2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_31

    goto :goto_32

    :sswitch_29
    const-string v4, "Size"

    invoke-virtual {p2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_32

    :cond_31
    :goto_31
    goto :goto_46

    :cond_32
    :goto_32
    const-string v2, "GuiObject"

    invoke-virtual {p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_43

    const-string v2, "BasePart"

    invoke-virtual {p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_43

    goto :goto_45

    :cond_43
    const-string v1, "Transform"

    :goto_45
    return-object v1

    .line 123
    :goto_46
    const-string v1, "Brightness"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const-string v4, "Light"

    if-eqz v1, :cond_5d

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v1

    const-string v5, "Lighting"

    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5d

    return-object v4

    .line 124
    :cond_5d
    const-string v1, "Color"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6c

    invoke-virtual {p1, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6c

    return-object v2

    .line 125
    :cond_6c
    const-string v1, "Enabled"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7b

    invoke-virtual {p1, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_7b

    return-object v2

    .line 126
    :cond_7b
    const-string v1, "Texture"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_90

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v1

    const-string v4, "Decal"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_90

    return-object v2

    .line 127
    :cond_90
    return-object v0

    .line 129
    .end local v0    # "cat\\1":Ljava/lang/String;
    .end local v3    # "$i$a$-let-PropertiesPanel$categoryOf$1\\1\\120\\0":I
    :cond_91
    const-string v0, "ParticleEmitter"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_ba

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "Trail"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_ba

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "Beam"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_ba

    .line 130
    sparse-switch p3, :sswitch_data_ca

    .line 133
    goto :goto_b9

    .line 132
    :sswitch_b5
    const-string v1, "Behavior"

    goto :goto_b9

    .line 131
    :sswitch_b8
    nop

    .line 130
    :goto_b9
    return-object v1

    .line 129
    :cond_ba
    return-object v2

    nop

    :sswitch_data_bc
    .sparse-switch
        0x275421 -> :sswitch_29
        0x173739e -> :sswitch_20
        0x306cfd49 -> :sswitch_17
    .end sparse-switch

    :sswitch_data_ca
    .sparse-switch
        0x1 -> :sswitch_b8
        0x2 -> :sswitch_b5
        0x13 -> :sswitch_b8
        0x22 -> :sswitch_b8
    .end sparse-switch
.end method
