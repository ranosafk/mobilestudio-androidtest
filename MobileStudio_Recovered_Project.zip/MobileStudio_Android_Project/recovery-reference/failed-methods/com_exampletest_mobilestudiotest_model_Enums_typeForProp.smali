.method public final typeForProp(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 6
    .param p1, "cls"    # Ljava/lang/String;
    .param p2, "prop"    # Ljava/lang/String;

    const-string v0, "cls"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "prop"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const-string v1, "FormFactor"

    const-string v2, "Material"

    sparse-switch v0, :sswitch_data_1b2

    goto/16 :goto_1ad

    :sswitch_17
    const-string v0, "FillDirection"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 102
    const-string v1, "FillDirection"

    goto/16 :goto_1b0

    .line 93
    :sswitch_23
    const-string v0, "BottomSurface"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_187

    goto/16 :goto_1ad

    :sswitch_2d
    const-string v0, "SortOrder"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 105
    const-string v1, "SortOrder"

    goto/16 :goto_1b0

    .line 93
    :sswitch_39
    const-string v0, "MaterialPattern"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 95
    const-string v1, "MaterialPattern"

    goto/16 :goto_1b0

    .line 93
    :sswitch_45
    const-string v1, "FluidFidelity"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 125
    goto/16 :goto_1b0

    .line 93
    :sswitch_4f
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_149

    goto/16 :goto_1ad

    :sswitch_57
    const-string v0, "DepthMode"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 119
    const-string v1, "HighlightDepthMode"

    goto/16 :goto_1b0

    .line 93
    :sswitch_63
    const-string v1, "RunContext"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 101
    goto/16 :goto_1b0

    .line 93
    :sswitch_6d
    const-string v1, "TextXAlignment"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 98
    goto/16 :goto_1b0

    .line 93
    :sswitch_77
    const-string v1, "ZIndexBehavior"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 106
    goto/16 :goto_1b0

    .line 93
    :sswitch_81
    const-string v1, "RenderFidelity"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 124
    goto/16 :goto_1b0

    .line 93
    :sswitch_8b
    const-string v1, "TextYAlignment"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 99
    goto/16 :goto_1b0

    .line 93
    :sswitch_95
    invoke-virtual {p2, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15e

    goto/16 :goto_1ad

    :sswitch_9d
    const-string v0, "RightSurface"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_187

    goto/16 :goto_1ad

    :sswitch_a7
    const-string v1, "Technology"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 113
    goto/16 :goto_1b0

    .line 93
    :sswitch_b1
    const-string v0, "FrontSurface"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_187

    goto/16 :goto_1ad

    :sswitch_bb
    const-string v1, "ScaleType"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 107
    goto/16 :goto_1b0

    .line 93
    :sswitch_c5
    const-string v0, "shape"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_d7

    goto/16 :goto_1ad

    :sswitch_cf
    const-string v0, "Shape"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 96
    :cond_d7
    const-string v1, "PartType"

    goto/16 :goto_1b0

    .line 93
    :sswitch_db
    const-string v1, "Font"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 100
    goto/16 :goto_1b0

    .line 93
    :sswitch_e5
    const-string v0, "Face"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 109
    const-string v1, "NormalId"

    goto/16 :goto_1b0

    .line 93
    :sswitch_f1
    const-string v1, "CameraType"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 110
    goto/16 :goto_1b0

    .line 93
    :sswitch_fb
    const-string v1, "CameraMode"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 120
    goto/16 :goto_1b0

    .line 93
    :sswitch_105
    const-string v1, "ApplyStrokeMode"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 117
    goto/16 :goto_1b0

    .line 93
    :sswitch_10f
    const-string v1, "ScrollingDirection"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 118
    goto/16 :goto_1b0

    .line 93
    :sswitch_119
    const-string v1, "MeshType"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 111
    goto/16 :goto_1b0

    .line 93
    :sswitch_123
    const-string v1, "BorderMode"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 122
    goto/16 :goto_1b0

    .line 93
    :sswitch_12d
    const-string v1, "CollisionFidelity"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 123
    goto/16 :goto_1b0

    .line 93
    :sswitch_137
    const-string v0, "TopSurface"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_187

    goto/16 :goto_1ad

    :sswitch_141
    const-string v0, "formFactorRaw"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 112
    :cond_149
    goto/16 :goto_1b0

    .line 93
    :sswitch_14b
    const-string v0, "GameSettingsAvatar"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 115
    const-string v1, "GameAvatarType"

    goto :goto_1b0

    .line 93
    :sswitch_156
    const-string v0, "BaseMaterial"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 94
    :cond_15e
    move-object v1, v2

    goto :goto_1b0

    .line 93
    :sswitch_160
    const-string v0, "GameSettingsR15Collision"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 116
    const-string v1, "R15CollisionType"

    goto :goto_1b0

    .line 93
    :sswitch_16b
    const-string v0, "LeftSurface"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_187

    goto :goto_1ad

    :sswitch_174
    const-string v0, "RigType"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 114
    const-string v1, "HumanoidRigType"

    goto :goto_1b0

    .line 93
    :sswitch_17f
    const-string v0, "BackSurface"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 97
    :cond_187
    const-string v1, "SurfaceType"

    goto :goto_1b0

    .line 93
    :sswitch_18a
    const-string v1, "AutomaticSize"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 108
    goto :goto_1b0

    .line 93
    :sswitch_193
    const-string v1, "VerticalAlignment"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 104
    goto :goto_1b0

    .line 93
    :sswitch_19c
    const-string v1, "HorizontalAlignment"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1ad

    .line 103
    goto :goto_1b0

    .line 93
    :sswitch_1a5
    const-string v1, "ScreenInsets"

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1ae

    :cond_1ad
    :goto_1ad
    goto :goto_1af

    .line 121
    :cond_1ae
    goto :goto_1b0

    .line 126
    :goto_1af
    const/4 v1, 0x0

    .line 127
    :goto_1b0
    return-object v1

    nop

    :sswitch_data_1b2
    .sparse-switch
        -0x6ba83d5e -> :sswitch_1a5
        -0x675e9a01 -> :sswitch_19c
        -0x64486113 -> :sswitch_193
        -0x5a825754 -> :sswitch_18a
        -0x56deda5a -> :sswitch_17f
        -0x5540b3b6 -> :sswitch_174
        -0x5112397a -> :sswitch_16b
        -0x4aae274f -> :sswitch_160
        -0x47e03cc8 -> :sswitch_156
        -0x37a277f2 -> :sswitch_14b
        -0x2853400b -> :sswitch_141
        -0x26f49a48 -> :sswitch_137
        -0x1d2aa388 -> :sswitch_12d
        -0x1c6af7f1 -> :sswitch_123
        -0x18514119 -> :sswitch_119
        -0x1752dad6 -> :sswitch_10f
        -0x14ae9217 -> :sswitch_105
        -0x11fcd78 -> :sswitch_fb
        -0x11c77e1 -> :sswitch_f1
        0x214a7d -> :sswitch_e5
        0x21806f -> :sswitch_db
        0x4c25f81 -> :sswitch_cf
        0x6854fa1 -> :sswitch_c5
        0x7837784 -> :sswitch_bb
        0x10756a64 -> :sswitch_b1
        0x12b9612c -> :sswitch_a7
        0x14d8bf11 -> :sswitch_9d
        0x15adc947 -> :sswitch_95
        0x17b85297 -> :sswitch_8b
        0x1c413f1c -> :sswitch_81
        0x21f75f0a -> :sswitch_77
        0x236ee178 -> :sswitch_6d
        0x417e0cc4 -> :sswitch_63
        0x4e8e7ee6 -> :sswitch_57
        0x5b072b53 -> :sswitch_4f
        0x6a8d2710 -> :sswitch_45
        0x6d730c49 -> :sswitch_39
        0x75d99430 -> :sswitch_2d
        0x760563e2 -> :sswitch_23
        0x7d39e51c -> :sswitch_17
    .end sparse-switch
.end method
