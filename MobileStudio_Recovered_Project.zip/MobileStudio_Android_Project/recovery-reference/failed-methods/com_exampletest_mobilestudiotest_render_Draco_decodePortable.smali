.method private final decodePortable(Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;ILcom/exampletest/mobilestudiotest/render/Draco$Reader;)V
    .registers 30
    .param p1, "d"    # Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    .param p2, "n"    # I
    .param p3, "r"    # Lcom/exampletest/mobilestudiotest/render/Draco$Reader;

    .line 300
    move-object/from16 v0, p0

    move-object/from16 v1, p3

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getAtt()Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    move-result-object v2

    .line 301
    .local v2, "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v3

    if-nez v3, :cond_2b

    .line 302
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getComponents()I

    move-result v3

    mul-int v3, v3, p2

    new-array v3, v3, [F

    .line 303
    .local v3, "v":[F
    const/4 v4, 0x0

    .local v4, "i":I
    array-length v5, v3

    :goto_18
    if-ge v4, v5, :cond_27

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getDataType()I

    move-result v6

    invoke-direct {v0, v1, v6}, Lcom/exampletest/mobilestudiotest/render/Draco;->readTyped(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)F

    move-result v6

    aput v6, v3, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_18

    .line 304
    .end local v4    # "i":I
    :cond_27
    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->setValues([F)V

    .line 305
    return-void

    .line 307
    .end local v3    # "v":[F
    :cond_2b
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v3

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-ne v3, v5, :cond_35

    move v3, v4

    goto :goto_39

    :cond_35
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getComponents()I

    move-result v3

    .line 308
    .local v3, "comps":I
    :goto_39
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i8()I

    move-result v6

    .line 309
    .local v6, "method":I
    const/4 v7, -0x1

    .line 310
    .local v7, "transform":I
    const/4 v8, -0x2

    if-eq v6, v8, :cond_82

    .line 311
    if-lt v6, v8, :cond_69

    const/4 v9, 0x6

    if-gt v6, v9, :cond_69

    .line 312
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i8()I

    move-result v7

    .line 313
    const/4 v9, -0x1

    if-lt v7, v9, :cond_50

    if-gt v7, v5, :cond_50

    goto :goto_82

    :cond_50
    new-instance v4, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "bad prediction transform "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 311
    :cond_69
    new-instance v4, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "bad prediction method "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 317
    :cond_82
    :goto_82
    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eq v6, v8, :cond_9a

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v8

    if-ne v8, v5, :cond_91

    if-eq v7, v4, :cond_90

    if-ne v7, v5, :cond_95

    :cond_90
    goto :goto_93

    :cond_91
    if-ne v7, v10, :cond_95

    :goto_93
    move v8, v10

    goto :goto_96

    :cond_95
    move v8, v9

    :goto_96
    if-eqz v8, :cond_9a

    move v8, v10

    goto :goto_9b

    :cond_9a
    move v8, v9

    .line 318
    .local v8, "predicted":Z
    :goto_9b
    mul-int v11, p2, v3

    .line 319
    .local v11, "total":I
    const/4 v12, 0x0

    .line 320
    .local v12, "values":[I
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v13

    const/4 v14, 0x4

    if-lez v13, :cond_ac

    invoke-direct {v0, v11, v3, v1}, Lcom/exampletest/mobilestudiotest/render/Draco;->decodeSymbols(IILcom/exampletest/mobilestudiotest/render/Draco$Reader;)[I

    move-result-object v12

    move/from16 v17, v10

    goto :goto_e0

    .line 322
    :cond_ac
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v13

    .line 323
    .local v13, "nb":I
    if-lt v13, v10, :cond_27b

    if-gt v13, v14, :cond_27b

    .line 324
    mul-int v15, v13, v11

    invoke-virtual {v1, v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->need(I)V

    .line 325
    new-array v12, v11, [I

    .line 326
    const/4 v15, 0x0

    .local v15, "i":I
    :goto_bc
    if-ge v15, v11, :cond_de

    const/16 v16, 0x0

    .local v16, "v":I
    const/16 v17, 0x0

    move/from16 v25, v17

    move/from16 v17, v10

    move/from16 v10, v25

    .local v10, "k":I
    :goto_c8
    if-ge v10, v13, :cond_d7

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v18

    mul-int/lit8 v19, v10, 0x8

    shl-int v18, v18, v19

    or-int v16, v16, v18

    add-int/lit8 v10, v10, 0x1

    goto :goto_c8

    .end local v10    # "k":I
    :cond_d7
    aput v16, v12, v15

    .end local v16    # "v":I
    add-int/lit8 v15, v15, 0x1

    move/from16 v10, v17

    goto :goto_bc

    :cond_de
    move/from16 v17, v10

    .line 328
    .end local v13    # "nb":I
    .end local v15    # "i":I
    :goto_e0
    if-eqz v8, :cond_eb

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v10

    if-ne v10, v5, :cond_eb

    move/from16 v10, v17

    goto :goto_ec

    :cond_eb
    move v10, v9

    .line 329
    .local v10, "positive":Z
    :goto_ec
    if-nez v10, :cond_107

    const/4 v13, 0x0

    .local v13, "i":I
    array-length v15, v12

    :goto_f0
    if-ge v13, v15, :cond_104

    aget v16, v12, v13

    .local v16, "u":I
    ushr-int/lit8 v18, v16, 0x1

    move/from16 v19, v14

    and-int/lit8 v14, v16, 0x1

    neg-int v14, v14

    xor-int v18, v18, v14

    aput v18, v12, v13

    .end local v16    # "u":I
    add-int/lit8 v13, v13, 0x1

    move/from16 v14, v19

    goto :goto_f0

    :cond_104
    move/from16 v19, v14

    goto :goto_109

    .end local v13    # "i":I
    :cond_107
    move/from16 v19, v14

    .line 330
    :goto_109
    if-eqz v8, :cond_271

    .line 331
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v13

    if-ne v13, v5, :cond_223

    .line 332
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v13

    .line 333
    .local v13, "maxQ":I
    if-ne v7, v5, :cond_11a

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    .line 334
    :cond_11a
    rem-int/lit8 v14, v13, 0x2

    if-eqz v14, :cond_217

    if-lez v13, :cond_217

    .line 335
    invoke-static {v13}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    move-result v14

    rsub-int/lit8 v14, v14, 0x20

    .line 336
    .local v14, "bits":I
    new-instance v15, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;

    invoke-direct {v15, v14}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;-><init>(I)V

    .line 337
    .local v15, "oct":Lcom/exampletest/mobilestudiotest/render/Draco$Octa;
    new-array v5, v4, [I

    .line 338
    .local v5, "pred":[I
    new-array v1, v4, [I

    .line 339
    .local v1, "orig":[I
    invoke-static {v9, v11}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v18

    move/from16 v20, v9

    move-object/from16 v9, v18

    check-cast v9, Lkotlin/ranges/IntProgression;

    invoke-static {v9, v4}, Lkotlin/ranges/RangesKt;->step(Lkotlin/ranges/IntProgression;I)Lkotlin/ranges/IntProgression;

    move-result-object v4

    invoke-virtual {v4}, Lkotlin/ranges/IntProgression;->getFirst()I

    move-result v9

    move-object/from16 v18, v2

    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .local v9, "i":I
    .local v18, "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    invoke-virtual {v4}, Lkotlin/ranges/IntProgression;->getLast()I

    move-result v2

    invoke-virtual {v4}, Lkotlin/ranges/IntProgression;->getStep()I

    move-result v4

    if-lez v4, :cond_14f

    if-le v9, v2, :cond_153

    :cond_14f
    if-gez v4, :cond_214

    if-gt v2, v9, :cond_214

    .line 340
    :cond_153
    :goto_153
    if-nez v9, :cond_15a

    aput v20, v5, v20

    aput v20, v5, v17

    goto :goto_166

    :cond_15a
    add-int/lit8 v21, v9, -0x2

    aget v21, v12, v21

    aput v21, v5, v20

    add-int/lit8 v21, v9, -0x1

    aget v21, v12, v21

    aput v21, v5, v17

    .line 341
    :goto_166
    aget v21, v5, v20

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->getCenter()I

    move-result v22

    sub-int v21, v21, v22

    aput v21, v5, v20

    aget v21, v5, v17

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->getCenter()I

    move-result v22

    sub-int v21, v21, v22

    aput v21, v5, v17

    .line 342
    move/from16 v21, v4

    aget v4, v5, v20

    move/from16 v22, v6

    .end local v6    # "method":I
    .local v22, "method":I
    aget v6, v5, v17

    invoke-virtual {v15, v4, v6}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->isInDiamond(II)Z

    move-result v4

    .line 343
    .local v4, "inDiamond":Z
    if-nez v4, :cond_18b

    invoke-virtual {v15, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->invertDiamond([I)V

    .line 344
    :cond_18b
    const/4 v6, 0x3

    if-ne v7, v6, :cond_1d6

    .line 345
    aget v16, v5, v20

    if-nez v16, :cond_196

    aget v16, v5, v17

    if-eqz v16, :cond_19e

    :cond_196
    aget v16, v5, v20

    if-gez v16, :cond_1a1

    aget v16, v5, v17

    if-gtz v16, :cond_1a1

    :cond_19e
    move/from16 v16, v17

    goto :goto_1a3

    :cond_1a1
    move/from16 v16, v20

    .line 346
    .local v16, "bottomLeft":Z
    :goto_1a3
    aget v6, v5, v20

    move/from16 v23, v4

    .end local v4    # "inDiamond":Z
    .local v23, "inDiamond":Z
    aget v4, v5, v17

    invoke-direct {v0, v6, v4}, Lcom/exampletest/mobilestudiotest/render/Draco;->rotationCount(II)I

    move-result v4

    .line 347
    .local v4, "rot":I
    if-nez v16, :cond_1b2

    invoke-direct {v0, v5, v4}, Lcom/exampletest/mobilestudiotest/render/Draco;->rotate([II)V

    .line 348
    :cond_1b2
    aget v6, v5, v20

    aget v24, v12, v9

    add-int v6, v6, v24

    invoke-virtual {v15, v6}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->modMax(I)I

    move-result v6

    aput v6, v1, v20

    aget v6, v5, v17

    add-int/lit8 v24, v9, 0x1

    aget v24, v12, v24

    add-int v6, v6, v24

    invoke-virtual {v15, v6}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->modMax(I)I

    move-result v6

    aput v6, v1, v17

    .line 349
    if-nez v16, :cond_1f0

    rsub-int/lit8 v6, v4, 0x4

    rem-int/lit8 v6, v6, 0x4

    invoke-direct {v0, v1, v6}, Lcom/exampletest/mobilestudiotest/render/Draco;->rotate([II)V

    .end local v4    # "rot":I
    .end local v16    # "bottomLeft":Z
    goto :goto_1f0

    .line 351
    .end local v23    # "inDiamond":Z
    .local v4, "inDiamond":Z
    :cond_1d6
    move/from16 v23, v4

    .end local v4    # "inDiamond":Z
    .restart local v23    # "inDiamond":Z
    aget v4, v5, v20

    aget v6, v12, v9

    add-int/2addr v4, v6

    invoke-virtual {v15, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->modMax(I)I

    move-result v4

    aput v4, v1, v20

    aget v4, v5, v17

    add-int/lit8 v6, v9, 0x1

    aget v6, v12, v6

    add-int/2addr v4, v6

    invoke-virtual {v15, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->modMax(I)I

    move-result v4

    aput v4, v1, v17

    .line 353
    :cond_1f0
    :goto_1f0
    if-nez v23, :cond_1f5

    invoke-virtual {v15, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->invertDiamond([I)V

    .line 354
    :cond_1f5
    aget v4, v1, v20

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->getCenter()I

    move-result v6

    add-int/2addr v4, v6

    aput v4, v12, v9

    add-int/lit8 v4, v9, 0x1

    aget v6, v1, v17

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->getCenter()I

    move-result v16

    add-int v6, v6, v16

    aput v6, v12, v4

    .line 339
    .end local v23    # "inDiamond":Z
    if-eq v9, v2, :cond_275

    add-int v9, v9, v21

    move/from16 v4, v21

    move/from16 v6, v22

    goto/16 :goto_153

    .end local v22    # "method":I
    .restart local v6    # "method":I
    :cond_214
    move/from16 v22, v6

    .end local v6    # "method":I
    .restart local v22    # "method":I
    goto :goto_275

    .line 334
    .end local v1    # "orig":[I
    .end local v5    # "pred":[I
    .end local v9    # "i":I
    .end local v14    # "bits":I
    .end local v15    # "oct":Lcom/exampletest/mobilestudiotest/render/Draco$Octa;
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v22    # "method":I
    .restart local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v6    # "method":I
    :cond_217
    move-object/from16 v18, v2

    move/from16 v22, v6

    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v6    # "method":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v22    # "method":I
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "bad normal transform data"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 357
    .end local v13    # "maxQ":I
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v22    # "method":I
    .restart local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v6    # "method":I
    :cond_223
    move-object/from16 v18, v2

    move/from16 v22, v6

    move/from16 v20, v9

    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v6    # "method":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v22    # "method":I
    invoke-virtual/range {p3 .. p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v1

    .local v1, "mn":I
    invoke-virtual/range {p3 .. p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v2

    .line 358
    .local v2, "mx":I
    const-string v4, "bad wrap transform data"

    if-gt v1, v2, :cond_26b

    .line 359
    int-to-long v5, v2

    int-to-long v13, v1

    sub-long/2addr v5, v13

    .line 360
    .local v5, "dif":J
    const-wide/32 v13, 0x7fffffff

    cmp-long v9, v5, v13

    if-gez v9, :cond_265

    .line 361
    const-wide/16 v13, 0x1

    add-long/2addr v13, v5

    long-to-int v4, v13

    .line 362
    .local v4, "maxDif":I
    const/4 v9, 0x0

    .restart local v9    # "i":I
    :goto_244
    if-ge v9, v11, :cond_275

    .line 363
    if-ge v9, v3, :cond_24b

    move/from16 v13, v20

    goto :goto_24f

    :cond_24b
    sub-int v13, v9, v3

    aget v13, v12, v13

    .line 364
    .local v13, "p":I
    :goto_24f
    if-le v13, v2, :cond_253

    move v13, v2

    goto :goto_256

    :cond_253
    if-ge v13, v1, :cond_256

    move v13, v1

    .line 365
    :cond_256
    :goto_256
    aget v14, v12, v9

    add-int/2addr v14, v13

    .line 366
    .local v14, "o":I
    if-le v14, v2, :cond_25d

    sub-int/2addr v14, v4

    goto :goto_260

    :cond_25d
    if-ge v14, v1, :cond_260

    add-int/2addr v14, v4

    .line 367
    :cond_260
    :goto_260
    aput v14, v12, v9

    .line 362
    .end local v13    # "p":I
    .end local v14    # "o":I
    add-int/lit8 v9, v9, 0x1

    goto :goto_244

    .line 360
    .end local v4    # "maxDif":I
    .end local v9    # "i":I
    :cond_265
    new-instance v9, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v9, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v9

    .line 358
    .end local v5    # "dif":J
    :cond_26b
    new-instance v5, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v5, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 330
    .end local v1    # "mn":I
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v22    # "method":I
    .local v2, "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v6    # "method":I
    :cond_271
    move-object/from16 v18, v2

    move/from16 v22, v6

    .line 371
    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v6    # "method":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v22    # "method":I
    :cond_275
    :goto_275
    move-object/from16 v1, p1

    invoke-virtual {v1, v12}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->setPortable([I)V

    .line 372
    return-void

    .line 323
    .end local v10    # "positive":Z
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v22    # "method":I
    .restart local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v6    # "method":I
    .local v13, "nb":I
    :cond_27b
    move-object/from16 v1, p1

    move-object/from16 v18, v2

    move/from16 v22, v6

    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v6    # "method":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v22    # "method":I
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v4, "bad raw integer size"

    invoke-direct {v2, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v2
.end method
