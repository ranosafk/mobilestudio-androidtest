.method private final resolveRoot(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;II)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;
    .registers 10
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;
    .param p3, "script"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p4, "text"    # Ljava/lang/String;
    .param p5, "before"    # I
    .param p6, "depth"    # I

    .line 334
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    .line 335
    .local v0, "dm":Lcom/exampletest/mobilestudiotest/model/DataModel;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_94

    goto :goto_60

    :sswitch_c
    const-string v1, "workspace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_61

    goto :goto_60

    :sswitch_15
    const-string v1, "game"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_60

    .line 336
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    move-object v2, v0

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto/16 :goto_92

    .line 335
    :sswitch_29
    const-string v1, "Enum"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_60

    .line 339
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$EnumRoot;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$EnumRoot;

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_92

    .line 335
    :sswitch_36
    const-string v1, "script"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_60

    .line 338
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-direct {v1, p3}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_92

    .line 335
    :sswitch_46
    const-string v1, "plugin"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_60

    .line 340
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;

    const-string v2, "Plugin"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Cls;-><init>(Ljava/lang/String;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_92

    .line 335
    :sswitch_58
    const-string v1, "Workspace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_61

    :cond_60
    :goto_60
    goto :goto_6d

    .line 337
    :cond_61
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getWorkspace()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Inst;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_92

    .line 341
    :goto_6d
    nop

    .line 342
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->libs:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7e

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Lib;

    invoke-direct {v1, p1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$Lib;-><init>(Ljava/lang/String;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_92

    .line 343
    :cond_7e
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->dataStatics:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8e

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$DataStatic;

    invoke-direct {v1, p1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T$DataStatic;-><init>(Ljava/lang/String;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    goto :goto_92

    .line 344
    :cond_8e
    invoke-direct/range {p0 .. p6}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->resolveLocal(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;II)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$T;

    move-result-object v1

    .line 335
    :goto_92
    return-object v1

    nop

    :sswitch_data_94
    .sparse-switch
        -0x4675f38b -> :sswitch_58
        -0x3ab890cd -> :sswitch_46
        -0x361a2f35 -> :sswitch_36
        0x210921 -> :sswitch_29
        0x304bf2 -> :sswitch_15
        0x4217ec95 -> :sswitch_c
    .end sparse-switch
.end method
