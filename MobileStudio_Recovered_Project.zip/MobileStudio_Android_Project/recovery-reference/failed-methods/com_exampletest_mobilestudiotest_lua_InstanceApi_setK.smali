.method public final setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V
    .registers 22
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "value"    # Ljava/lang/Object;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v8, p2

    move-object/from16 v9, p3

    const-string v0, "inst"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 342
    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v11, 0x1

    .line 350
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    .line 342
    sparse-switch v0, :sswitch_data_488

    goto :goto_60

    :sswitch_21
    const-string v0, "ClassName"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_60

    .line 351
    new-instance v0, Lorg/luaj/vm2/LuaError;

    const-string v3, "Unable to assign property ClassName. Property is read only"

    invoke-direct {v0, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 342
    :sswitch_31
    const-string v0, "Archivable"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_60

    .line 350
    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->setArchivable(Z)V

    return-void

    .line 342
    :sswitch_41
    const-string v0, "Name"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_60

    .line 343
    if-eqz v9, :cond_52

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_52

    goto :goto_54

    :cond_52
    const-string v0, "nil"

    :goto_54
    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->setName(Ljava/lang/String;)V

    return-void

    .line 342
    :sswitch_58
    const-string v0, "Parent"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_62

    :cond_60
    :goto_60
    goto/16 :goto_dc

    .line 345
    :cond_62
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getDestroyed()Z

    move-result v0

    const-string v4, "The Parent property of "

    if-eqz v0, :cond_9e

    new-instance v0, Lorg/luaj/vm2/LuaError;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v5

    instance-of v6, v9, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v6, :cond_78

    move-object v6, v9

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_79

    :cond_78
    move-object v6, v3

    :goto_79
    if-eqz v6, :cond_7f

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v3

    :cond_7f
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " is locked, current parent: NULL, new parent "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 346
    :cond_9e
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v0

    if-nez v0, :cond_bb

    instance-of v0, v2, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-nez v0, :cond_bb

    .line 347
    :try_start_a8
    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    const/4 v4, 0x2

    invoke-static {v2, v0, v10, v4, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->setParent$default(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;IILjava/lang/Object;)V
    :try_end_af
    .catch Ljava/lang/IllegalArgumentException; {:try_start_a8 .. :try_end_af} :catch_b0

    .line 348
    return-void

    .line 347
    :catch_b0
    move-exception v0

    .local v0, "e":Ljava/lang/IllegalArgumentException;
    new-instance v3, Lorg/luaj/vm2/LuaError;

    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .line 346
    .end local v0    # "e":Ljava/lang/IllegalArgumentException;
    :cond_bb
    new-instance v0, Lorg/luaj/vm2/LuaError;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " is locked"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 353
    :goto_dc
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isPart(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    const-string v4, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.CFrame"

    const-string v5, "CFrame"

    if-eqz v0, :cond_241

    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v6, 0x3c8efa35

    const-string v7, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Vector3"

    sparse-switch v0, :sswitch_data_49a

    goto/16 :goto_241

    :sswitch_f4
    invoke-virtual {v8, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 367
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-static {v9, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v3, v9

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0, v2, v3}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 353
    :sswitch_106
    const-string v0, "RotVelocity"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_178

    goto/16 :goto_241

    :sswitch_110
    const-string v0, "AssemblyLinearVelocity"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_22f

    goto/16 :goto_241

    :sswitch_11a
    const-string v0, "Position"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 354
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v3, v2}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v4, v9

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 353
    :sswitch_138
    const-string v0, "Orientation"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 355
    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v6

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v7

    invoke-virtual {v4, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromOrientation(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v5, v2}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 353
    .end local v0    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :sswitch_170
    const-string v0, "AssemblyAngularVelocity"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 366
    :cond_178
    return-void

    .line 353
    :sswitch_179
    const-string v0, "Color"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 358
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    const-string v3, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Color3"

    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v3, v9

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v0, v2, v3}, Lcom/exampletest/mobilestudiotest/model/PartData;->setColor(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Color3;)V

    return-void

    .line 353
    :sswitch_18f
    const-string v0, "Rotation"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 356
    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .restart local v0    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v6

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v7

    invoke-virtual {v4, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->angles(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v5, v2}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 353
    .end local v0    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :sswitch_1c7
    const-string v0, "Size"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 357
    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v0, "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    const v6, 0x3a83126f    # 0.001f

    invoke-static {v5, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v7

    invoke-static {v7, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v7

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v10

    invoke-static {v10, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v6

    invoke-direct {v4, v5, v7, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v3, v2, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->setSize(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    return-void

    .line 353
    .end local v0    # "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :sswitch_1fb
    const-string v0, "BrickColor"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_241

    .line 360
    const-string v3, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.BrickColorV"

    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v4, v9

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    .line 361
    .local v4, "b":Lcom/exampletest/mobilestudiotest/model/BrickColorV;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v5

    invoke-virtual {v3, v2, v5}, Lcom/exampletest/mobilestudiotest/model/PartData;->setColor(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Color3;)V

    .line 362
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_226

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "BrickColor"

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 363
    :cond_226
    return-void

    .line 353
    .end local v4    # "b":Lcom/exampletest/mobilestudiotest/model/BrickColorV;
    :sswitch_227
    const-string v0, "Velocity"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 365
    :cond_22f
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_240

    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v3, v9

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0, v2, v3}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->setVelocity(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    :cond_240
    return-void

    .line 369
    :cond_241
    :goto_241
    const-string v0, "Model"

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_25b

    const-string v0, "WorldPivot"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_25b

    invoke-static {v9, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v1, v2, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 370
    :cond_25b
    const-string v0, "BaseScript"

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_27d

    const-string v0, "Enabled"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_27d

    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    xor-int/2addr v0, v11

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "Disabled"

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    return-void

    .line 371
    :cond_27d
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v4, "Humanoid"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    if-eqz v0, :cond_30d

    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_4c8

    goto/16 :goto_30d

    :sswitch_293
    const-string v0, "Jump"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_30d

    .line 377
    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2ac

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_2ac

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->jump(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    :cond_2ac
    return-void

    .line 371
    :sswitch_2ad
    const-string v0, "Sit"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_30d

    .line 378
    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "Sit"

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    return-void

    .line 371
    :sswitch_2c6
    const-string v0, "Health"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_30d

    .line 373
    const-string v5, "MaxHealth"

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Ljava/lang/Number;

    if-eqz v6, :cond_2db

    move-object v3, v5

    check-cast v3, Ljava/lang/Number;

    :cond_2db
    if-eqz v3, :cond_2e2

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v3

    goto :goto_2e4

    :cond_2e2
    const/high16 v3, 0x42c80000    # 100.0f

    :goto_2e4
    move v10, v3

    .line 374
    .local v10, "max":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2f1

    const-string v0, "Health_XML"

    :cond_2f1
    move-object v3, v0

    const-string v0, "null cannot be cast to non-null type kotlin.Number"

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    invoke-static {v0, v4, v10}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 375
    return-void

    .line 380
    .end local v10    # "max":F
    :cond_30d
    :goto_30d
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "Camera"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_34d

    invoke-static {v8, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_34d

    .line 381
    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "CFrame"

    const/4 v5, 0x0

    move-object/from16 v2, p1

    move-object v4, v9

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 383
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-nez v0, :cond_34c

    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isEditCamera(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    if-eqz v0, :cond_34c

    instance-of v0, v9, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v0, :cond_34c

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCamera()Lcom/exampletest/mobilestudiotest/render/FlyCamera;

    move-result-object v0

    move-object v2, v9

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->setFromCFrame(Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    .line 384
    :cond_34c
    return-void

    .line 386
    :cond_34d
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "Lighting"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3b5

    const-string v0, "TimeOfDay"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3b5

    .line 387
    invoke-static {v9}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Ljava/lang/CharSequence;

    new-array v13, v11, [Ljava/lang/String;

    const-string v0, ":"

    aput-object v0, v13, v10

    const/16 v16, 0x6

    const/16 v17, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static/range {v12 .. v17}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .local v0, "p":Ljava/util/List;
    invoke-static {v0, v10}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_38b

    invoke-static {v2}, Lkotlin/text/StringsKt;->toFloatOrNull(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v2

    if-eqz v2, :cond_38b

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    goto :goto_38d

    :cond_38b
    const/high16 v2, 0x41600000    # 14.0f

    :goto_38d
    move v10, v2

    .local v10, "h":F
    invoke-static {v0, v11}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_3a0

    invoke-static {v2}, Lkotlin/text/StringsKt;->toFloatOrNull(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v2

    if-eqz v2, :cond_3a0

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v4

    :cond_3a0
    move v11, v4

    .line 388
    .local v11, "m":F
    const/high16 v2, 0x42700000    # 60.0f

    div-float v2, v11, v2

    add-float/2addr v2, v10

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "ClockTime"

    const/4 v5, 0x0

    move-object/from16 v2, p1

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    return-void

    .line 390
    .end local v0    # "p":Ljava/util/List;
    .end local v10    # "h":F
    .end local v11    # "m":F
    :cond_3b5
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "Sound"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_407

    const-string v0, "Playing"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_407

    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "Playing"

    const/4 v5, 0x0

    move-object/from16 v2, p1

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_406

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    new-array v3, v11, [Lorg/luaj/vm2/LuaValue;

    const-string v4, "SoundId"

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_3f4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_3f4

    goto :goto_3f6

    :cond_3f4
    const-string v4, ""

    :goto_3f6
    invoke-static {v4}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v4

    const-string v5, "valueOf(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    aput-object v4, v3, v10

    const-string v4, "Played"

    invoke-virtual {v0, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    :cond_406
    return-void

    :cond_407
    move-object/from16 v2, p1

    .line 391
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v0, v2, v8}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 392
    .local v3, "key":Ljava/lang/String;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    .line 393
    .local v0, "type":Ljava/lang/Integer;
    if-eqz v0, :cond_432

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v5, 0x4

    if-ne v4, v5, :cond_432

    instance-of v4, v9, Ljava/lang/Number;

    if-eqz v4, :cond_432

    move-object v4, v9

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    goto :goto_47f

    .line 394
    :cond_432
    if-eqz v0, :cond_44b

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v5, 0x5

    if-ne v4, v5, :cond_44b

    instance-of v4, v9, Ljava/lang/Number;

    if-eqz v4, :cond_44b

    move-object v4, v9

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    goto :goto_47f

    .line 395
    :cond_44b
    if-eqz v0, :cond_464

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v5, 0x3

    if-ne v4, v5, :cond_464

    instance-of v4, v9, Ljava/lang/Number;

    if-eqz v4, :cond_464

    move-object v4, v9

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    goto :goto_47f

    .line 396
    :cond_464
    if-eqz v0, :cond_47e

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/16 v5, 0x1b

    if-ne v4, v5, :cond_47e

    instance-of v4, v9, Ljava/lang/Number;

    if-eqz v4, :cond_47e

    move-object v4, v9

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    goto :goto_47f

    .line 397
    :cond_47e
    move-object v4, v9

    .line 393
    :goto_47f
    nop

    .line 398
    .local v4, "v":Ljava/lang/Object;
    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 399
    return-void

    nop

    :sswitch_data_488
    .sparse-switch
        -0x71f00b36 -> :sswitch_58
        0x24eeab -> :sswitch_41
        0x7094d7fd -> :sswitch_31
        0x76db3c03 -> :sswitch_21
    .end sparse-switch

    :sswitch_data_49a
    .sparse-switch
        -0x7cef5f03 -> :sswitch_227
        -0x33b84c3e -> :sswitch_1fb
        0x275421 -> :sswitch_1c7
        0x173739e -> :sswitch_18f
        0x3e43f43 -> :sswitch_179
        0x9fe75f9 -> :sswitch_170
        0xd9c9db0 -> :sswitch_138
        0x306cfd49 -> :sswitch_11a
        0x3f7ca6c8 -> :sswitch_110
        0x4f2c3bb4 -> :sswitch_106
        0x76646aea -> :sswitch_f4
    .end sparse-switch

    :sswitch_data_4c8
    .sparse-switch
        -0x7f661184 -> :sswitch_2c6
        0x144be -> :sswitch_2ad
        0x23684e -> :sswitch_293
    .end sparse-switch
.end method
