.method static final _init_$lambda$47(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 151
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/CFrame;

    .line 152
    .local v0, "c":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_2d4

    goto/16 :goto_2c4

    :sswitch_16
    const-string v1, "inverse"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e3

    goto/16 :goto_2c4

    :sswitch_20
    const-string v1, "RightVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1a5

    goto/16 :goto_2c4

    :sswitch_2a
    const-string v1, "VectorToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_171

    goto/16 :goto_2c4

    :sswitch_34
    const-string v1, "UpVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_46

    goto/16 :goto_2c4

    :sswitch_3e
    const-string v1, "upVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 157
    :cond_46
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getUpVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_52
    const-string v1, "ZVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 158
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR02()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR12()F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR22()F

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    goto/16 :goto_20b

    .line 152
    :sswitch_6f
    const-string v1, "Position"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10e

    goto/16 :goto_2c4

    :sswitch_79
    const-string v1, "vectorToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_275

    goto/16 :goto_2c4

    :sswitch_83
    const-string v1, "toEulerAnglesYXZ"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_237

    goto/16 :goto_2c4

    :sswitch_8d
    const-string v1, "toEulerAnglesXYZ"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_190

    goto/16 :goto_2c4

    :sswitch_97
    const-string v1, "pointToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_29d

    goto/16 :goto_2c4

    :sswitch_a1
    const-string v1, "lookVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b1

    goto/16 :goto_2c4

    :sswitch_ab
    const-string v1, "GetComponents"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b9

    goto/16 :goto_2c4

    :sswitch_b5
    const-string v1, "Rotation"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 159
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->rotationOnly()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_c9
    const-string v1, "lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_db

    goto/16 :goto_2c4

    :sswitch_d3
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 161
    :cond_db
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda118;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda118;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_e8
    const-string v1, "z"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_122

    goto/16 :goto_2c4

    :sswitch_f2
    const-string v1, "y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_131

    goto/16 :goto_2c4

    :sswitch_fc
    const-string v1, "x"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_140

    goto/16 :goto_2c4

    :sswitch_106
    const-string v1, "p"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 153
    :cond_10e
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_11a
    const-string v1, "Z"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 154
    :cond_122
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getZ()F

    move-result v2

    goto :goto_146

    .line 152
    :sswitch_129
    const-string v1, "Y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 154
    :cond_131
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getY()F

    move-result v2

    goto :goto_146

    .line 152
    :sswitch_138
    const-string v1, "X"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 154
    :cond_140
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getX()F

    move-result v2

    :goto_146
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_14c
    const-string v1, "YVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 158
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR01()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR11()F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR21()F

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    goto/16 :goto_20b

    .line 152
    :sswitch_169
    const-string v1, "vectorToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 167
    :cond_171
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda124;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda124;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_17e
    const-string v1, "ToEulerAnglesYXZ"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_237

    goto/16 :goto_2c4

    :sswitch_188
    const-string v1, "ToEulerAnglesXYZ"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 168
    :cond_190
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda125;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda125;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_19d
    const-string v1, "rightVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 156
    :cond_1a5
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getRightVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_1b1
    const-string v1, "components"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 170
    :cond_1b9
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda115;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda115;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_1c6
    const-string v1, "Orthonormalize"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 171
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda116;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda116;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_1db
    const-string v1, "Inverse"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 160
    :cond_1e3
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda114;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda114;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_1f0
    const-string v1, "XVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 158
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR00()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR10()F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR20()F

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    :goto_20b
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_211
    const-string v1, "pointToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_24c

    goto/16 :goto_2c4

    :sswitch_21b
    const-string v1, "ToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2c5

    goto/16 :goto_2c4

    :sswitch_225
    const-string v1, "ToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_261

    goto/16 :goto_2c4

    :sswitch_22f
    const-string v1, "ToOrientation"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 169
    :cond_237
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda126;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda126;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_244
    const-string v1, "PointToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 164
    :cond_24c
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda121;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda121;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_259
    const-string v1, "toWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 162
    :cond_261
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda119;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda119;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_26d
    const-string v1, "VectorToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 166
    :cond_275
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda123;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda123;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_281
    const-string v1, "ToAxisAngle"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 172
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda117;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda117;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_295
    const-string v1, "PointToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 165
    :cond_29d
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda122;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda122;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_2a9
    const-string v1, "LookVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 155
    :cond_2b1
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getLookVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_2bc
    const-string v1, "toObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2c5

    :cond_2c4
    :goto_2c4
    goto :goto_2d1

    .line 163
    :cond_2c5
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda120;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda120;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 179
    :goto_2d1
    const/4 v1, 0x0

    .line 180
    :goto_2d2
    return-object v1

    nop

    :sswitch_data_2d4
    .sparse-switch
        -0x7ffc2474 -> :sswitch_2bc
        -0x712a431e -> :sswitch_2a9
        -0x6f840404 -> :sswitch_295
        -0x67bceea9 -> :sswitch_281
        -0x64ba3d8e -> :sswitch_26d
        -0x62e46291 -> :sswitch_259
        -0x5a1a5101 -> :sswitch_244
        -0x595e8bcb -> :sswitch_22f
        -0x59190e71 -> :sswitch_225
        -0x505cf494 -> :sswitch_21b
        -0x44de90e1 -> :sswitch_211
        -0x385cd445 -> :sswitch_1f0
        -0x27f58cf0 -> :sswitch_1db
        -0x22dbe98b -> :sswitch_1c6
        -0x1aab7cea -> :sswitch_1b1
        -0x14347581 -> :sswitch_19d
        -0xea29275 -> :sswitch_188
        -0xea28ed3 -> :sswitch_17e
        -0x39570f7 -> :sswitch_169
        -0x3769904 -> :sswitch_14c
        0x58 -> :sswitch_138
        0x59 -> :sswitch_129
        0x5a -> :sswitch_11a
        0x70 -> :sswitch_106
        0x78 -> :sswitch_fc
        0x79 -> :sswitch_f2
        0x7a -> :sswitch_e8
        0x241597 -> :sswitch_d3
        0x32a177 -> :sswitch_c9
        0x173739e -> :sswitch_b5
        0x3346aec -> :sswitch_ab
        0x1803e0c2 -> :sswitch_a1
        0x22b83fdc -> :sswitch_97
        0x2399296b -> :sswitch_8d
        0x23992d0d -> :sswitch_83
        0x2d820652 -> :sswitch_79
        0x306cfd49 -> :sswitch_6f
        0x316fa23d -> :sswitch_52
        0x37223bbe -> :sswitch_3e
        0x3afc9fde -> :sswitch_34
        0x471e56e9 -> :sswitch_2a
        0x4f35325f -> :sswitch_20
        0x74d1db30 -> :sswitch_16
    .end sparse-switch
.end method
