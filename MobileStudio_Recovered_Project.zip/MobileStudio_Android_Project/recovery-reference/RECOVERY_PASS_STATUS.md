# Recovery pass status

## What was recovered in this pass

- Re-opened the original APK (19,064,266 bytes), the original decompiler archive, and the recovered Android project.
- Verified the original APK contains 10 DEX files (`classes.dex` through `classes10.dex` with the normal multidex numbering pattern).
- Extracted the original application Smali tree (168 app-specific classes) and isolated the exact original Smali method bodies for all 33 JADX-failed app methods.
- Added per-method files, SHA-256 fingerprints, and a method index under `recovery-reference/`.
- Kept the prior source-level UI/render changes and all original project resources intact.

## Why this is not yet an APK

The execution container has Java 21 and ZIP tools, but no Android SDK, Android Gradle Plugin/Gradle runtime, D8/R8, `aapt2`, `zipalign`, `apksigner`, `apktool`, `smali` assembler, or Android emulator. Google Android SDK host DNS resolution also failed during this pass. Therefore no source compilation, DEX assembly, signing, or install test can honestly be reported.

## Recovery correctness

The extracted Smali bodies are exact instruction-level references from the decompiler archive. They have not been translated into Java or assembled into a replacement APK in this pass. Do not replace them with guessed stubs. The 33 failed methods span large parts of Luau/Roblox API behavior, RBX XML parsing, Draco decoding, rendering, autocomplete, and GUI layout.

## Device test handoff

Once a signed test APK is built, the user can install it on their Android device and provide: Android version, device model, steps to reproduce, screenshots, and `adb logcat` output (or a bug report exported from Android). The current APK is not ready for that test stage.
