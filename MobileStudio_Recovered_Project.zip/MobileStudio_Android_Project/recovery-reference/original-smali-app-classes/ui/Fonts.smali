###### Class com.exampletest.mobilestudiotest.ui.Fonts (com.exampletest.mobilestudiotest.ui.Fonts)
.class public final Lcom/exampletest/mobilestudiotest/ui/Fonts;
.super Ljava/lang/Object;
.source "Fonts.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nFonts.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Fonts.kt\ncom/exampletest/mobilestudiotest/ui/Fonts\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,118:1\n1#2:119\n2423#3,14:120\n*S KotlinDebug\n*F\n+ 1 Fonts.kt\ncom/exampletest/mobilestudiotest/ui/Fonts\n*L\n35#1:120,14\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000Z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0001#B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u0005J\u0012\u0010\u000e\u001a\u0004\u0018\u00010\t2\u0006\u0010\u000f\u001a\u00020\u0008H\u0002J\u0018\u0010\u0010\u001a\u00020\t2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J2\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0018\u0010\u0017\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u00080\u00190\u0018H\u0002J\u001e\u0010\u001a\u001a\u00020\u00162\u0006\u0010\u001b\u001a\u00020\u00082\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014J\"\u0010\u001c\u001a\u0014\u0012\u0004\u0012\u00020\u0008\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u00140\u001d2\u0006\u0010\u001e\u001a\u00020\u0012H\u0002J\u000e\u0010 \u001a\u00020\u00162\u0006\u0010!\u001a\u00020\"R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R*\u0010\u0006\u001a\u001e\u0012\u0004\u0012\u00020\u0008\u0012\u0004\u0012\u00020\t0\u0007j\u000e\u0012\u0004\u0012\u00020\u0008\u0012\u0004\u0012\u00020\t`\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R*\u0010\u001f\u001a\u001e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00160\u0007j\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u0016`\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006$"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/Fonts;",
        "",
        "<init>",
        "()V",
        "assets",
        "Landroid/content/res/AssetManager;",
        "cache",
        "Ljava/util/HashMap;",
        "",
        "Landroid/graphics/Typeface;",
        "Lkotlin/collections/HashMap;",
        "init",
        "",
        "a",
        "asset",
        "name",
        "system",
        "weight",
        "",
        "italic",
        "",
        "weighted",
        "Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;",
        "files",
        "",
        "Lkotlin/Pair;",
        "forFamily",
        "familyRaw",
        "fromEnum",
        "Lkotlin/Triple;",
        "v",
        "faceCache",
        "of",
        "c",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "Face",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

.field private static assets:Landroid/content/res/AssetManager;

.field private static final cache:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Landroid/graphics/Typeface;",
            ">;"
        }
    .end annotation
.end field

.field private static final faceCache:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Object;",
            "Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/ui/Fonts;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

    .line 16
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;->cache:Ljava/util/HashMap;

    .line 103
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;->faceCache:Ljava/util/HashMap;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final asset(Ljava/lang/String;)Landroid/graphics/Typeface;
    .registers 9
    .param p1, "name"    # Ljava/lang/String;

    .line 22
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;->cache:Ljava/util/HashMap;

    monitor-enter v0

    const/4 v1, 0x0

    .line 23
    .local v1, "$i$a$-synchronized-Fonts$asset$1\\1\\22\\0":I
    :try_start_4
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Fonts;->cache:Ljava/util/HashMap;

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/Typeface;
    :try_end_c
    .catchall {:try_start_4 .. :try_end_c} :catchall_48

    if-eqz v2, :cond_12

    .line 119
    .local v2, "it\\2":Landroid/graphics/Typeface;
    const/4 v3, 0x0

    .line 23
    .local v3, "$i$a$-let-Fonts$asset$1$1\\2\\23\\1":I
    nop

    .end local v1    # "$i$a$-synchronized-Fonts$asset$1\\1\\22\\0":I
    .end local v2    # "it\\2":Landroid/graphics/Typeface;
    .end local v3    # "$i$a$-let-Fonts$asset$1$1\\2\\23\\1":I
    monitor-exit v0

    return-object v2

    .line 24
    .restart local v1    # "$i$a$-synchronized-Fonts$asset$1\\1\\22\\0":I
    :cond_12
    const/4 v2, 0x0

    :try_start_13
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Fonts;->assets:Landroid/content/res/AssetManager;

    if-eqz v3, :cond_36

    .line 119
    .local v3, "it\\3":Landroid/content/res/AssetManager;
    const/4 v4, 0x0

    .line 24
    .local v4, "$i$a$-let-Fonts$asset$1$tf$1\\3\\24\\1":I
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "fonts/"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ".ttf"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v5
    :try_end_35
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_35} :catch_38
    .catchall {:try_start_13 .. :try_end_35} :catchall_48

    .end local v3    # "it\\3":Landroid/content/res/AssetManager;
    .end local v4    # "$i$a$-let-Fonts$asset$1$tf$1\\3\\24\\1":I
    goto :goto_3a

    :cond_36
    move-object v5, v2

    goto :goto_3a

    :catch_38
    move-exception v3

    move-object v5, v2

    :goto_3a
    if-nez v5, :cond_3e

    .end local v1    # "$i$a$-synchronized-Fonts$asset$1\\1\\22\\0":I
    monitor-exit v0

    return-object v2

    .line 25
    .restart local v1    # "$i$a$-synchronized-Fonts$asset$1\\1\\22\\0":I
    .local v5, "tf\\1":Landroid/graphics/Typeface;
    :cond_3e
    :try_start_3e
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Fonts;->cache:Ljava/util/HashMap;

    check-cast v2, Ljava/util/Map;

    invoke-interface {v2, p1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_45
    .catchall {:try_start_3e .. :try_end_45} :catchall_48

    .line 26
    nop

    .line 22
    .end local v1    # "$i$a$-synchronized-Fonts$asset$1\\1\\22\\0":I
    .end local v5    # "tf\\1":Landroid/graphics/Typeface;
    monitor-exit v0

    .line 27
    return-object v5

    .line 22
    :catchall_48
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private static final forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    .registers 8
    .param p0, "$weight"    # I
    .param p1, "$italic"    # Z
    .param p2, "file"    # Ljava/lang/String;

    .line 42
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

    invoke-direct {v0, p2}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->asset(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_15

    .line 119
    .local v0, "it\\1":Landroid/graphics/Typeface;
    const/4 v2, 0x0

    .line 42
    .local v2, "$i$a$-let-Fonts$forFamily$one$1\\1\\42\\0":I
    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    const/16 v4, 0x258

    if-lt p0, v4, :cond_11

    const/4 v1, 0x1

    :cond_11
    invoke-direct {v3, v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    .end local v0    # "it\\1":Landroid/graphics/Typeface;
    .end local v2    # "$i$a$-let-Fonts$forFamily$one$1\\1\\42\\0":I
    goto :goto_20

    :cond_15
    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

    invoke-direct {v0, p0, p1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-direct {v3, v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    :goto_20
    return-object v3
.end method

.method private final fromEnum(I)Lkotlin/Triple;
    .registers 12
    .param p1, "v"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lkotlin/Triple<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 81
    const-string v0, "Arimo"

    const/16 v1, 0x1f4

    .line 88
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    .line 81
    const-string v2, "Merriweather"

    const-string v3, "Arial"

    const-string v4, "BuilderSans"

    const-string v5, "GothamSSm"

    const-string v6, "SourceSansPro"

    const/16 v7, 0x2bc

    .line 82
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    .line 81
    const/16 v8, 0x190

    .line 82
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    .line 81
    const/4 v9, 0x0

    .line 82
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    .line 81
    packed-switch p1, :pswitch_data_1ec

    .line 100
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v6, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 99
    :pswitch_2d
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v0, v7, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 98
    :pswitch_34
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_3b
    new-instance v1, Lkotlin/Triple;

    const/16 v0, 0x320

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-direct {v1, v4, v0, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_48
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v4, v7, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 97
    :pswitch_4f
    new-instance v0, Lkotlin/Triple;

    invoke-direct {v0, v4, v1, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v1, v0

    goto/16 :goto_1eb

    :pswitch_57
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v4, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_5e
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Ubuntu"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 96
    :pswitch_67
    new-instance v1, Lkotlin/Triple;

    const-string v0, "TitilliumWeb"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_70
    new-instance v1, Lkotlin/Triple;

    const-string v0, "SpecialElite"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_79
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Sarpanch"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 95
    :pswitch_82
    new-instance v1, Lkotlin/Triple;

    const-string v0, "RobotoMono"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_8b
    new-instance v1, Lkotlin/Triple;

    const-string v0, "RobotoCondensed"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_94
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Roboto"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 94
    :pswitch_9d
    new-instance v1, Lkotlin/Triple;

    const-string v0, "PermanentMarker"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_a6
    new-instance v1, Lkotlin/Triple;

    const-string v0, "PatrickHand"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_af
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Oswald"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 93
    :pswitch_b8
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Nunito"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_c1
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Michroma"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_ca
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v2, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 92
    :pswitch_d1
    new-instance v1, Lkotlin/Triple;

    const-string v0, "LuckiestGuy"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_da
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Kalam"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_e3
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Jura"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 91
    :pswitch_ec
    new-instance v1, Lkotlin/Triple;

    const-string v0, "JosefinSans"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_f5
    new-instance v1, Lkotlin/Triple;

    const-string v0, "IndieFlower"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_fe
    new-instance v1, Lkotlin/Triple;

    const-string v0, "GrenzeGotisch"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 90
    :pswitch_107
    new-instance v1, Lkotlin/Triple;

    const-string v0, "FredokaOne"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_110
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Fondamento"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_119
    new-instance v1, Lkotlin/Triple;

    const-string v0, "DenkOne"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 89
    :pswitch_122
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Creepster"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_12b
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Bangers"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_134
    new-instance v1, Lkotlin/Triple;

    const-string v0, "AmaticSC"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 88
    :pswitch_13d
    new-instance v1, Lkotlin/Triple;

    const/16 v0, 0x384

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-direct {v1, v5, v0, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_14a
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v5, v7, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_151
    new-instance v0, Lkotlin/Triple;

    invoke-direct {v0, v5, v1, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v1, v0

    goto/16 :goto_1eb

    .line 87
    :pswitch_159
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v5, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_160
    new-instance v1, Lkotlin/Triple;

    const/16 v0, 0x258

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-direct {v1, v6, v0, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_16d
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Balthazar"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    .line 86
    :pswitch_176
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Guru"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1eb

    :pswitch_17f
    new-instance v1, Lkotlin/Triple;

    const-string v0, "PressStart2P"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_187
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Zekton"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    .line 85
    :pswitch_18f
    new-instance v1, Lkotlin/Triple;

    const-string v0, "HighwayGothic"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_197
    new-instance v1, Lkotlin/Triple;

    const-string v0, "Inconsolata"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_19f
    new-instance v1, Lkotlin/Triple;

    const-string v0, "ComicNeueAngular"

    invoke-direct {v1, v0, v7, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    .line 84
    :pswitch_1a7
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v2, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_1ad
    new-instance v1, Lkotlin/Triple;

    const-string v0, "AccanthisADFStd"

    invoke-direct {v1, v0, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_1b5
    new-instance v1, Lkotlin/Triple;

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-direct {v1, v6, v8, v0}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    .line 83
    :pswitch_1c0
    new-instance v1, Lkotlin/Triple;

    const/16 v0, 0x12c

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-direct {v1, v6, v0, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_1cc
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v6, v7, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_1d2
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v6, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    .line 82
    :pswitch_1d8
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v3, v7, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_1de
    new-instance v1, Lkotlin/Triple;

    invoke-direct {v1, v3, v8, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_1eb

    :pswitch_1e4
    new-instance v1, Lkotlin/Triple;

    const-string v0, "LegacyArial"

    invoke-direct {v1, v0, v7, v9}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 101
    :goto_1eb
    return-object v1

    :pswitch_data_1ec
    .packed-switch 0x0
        :pswitch_1e4
        :pswitch_1de
        :pswitch_1d8
        :pswitch_1d2
        :pswitch_1cc
        :pswitch_1c0
        :pswitch_1b5
        :pswitch_1ad
        :pswitch_1a7
        :pswitch_19f
        :pswitch_197
        :pswitch_18f
        :pswitch_187
        :pswitch_17f
        :pswitch_176
        :pswitch_16d
        :pswitch_160
        :pswitch_159
        :pswitch_151
        :pswitch_14a
        :pswitch_13d
        :pswitch_134
        :pswitch_12b
        :pswitch_122
        :pswitch_119
        :pswitch_110
        :pswitch_107
        :pswitch_fe
        :pswitch_f5
        :pswitch_ec
        :pswitch_e3
        :pswitch_da
        :pswitch_d1
        :pswitch_ca
        :pswitch_c1
        :pswitch_b8
        :pswitch_af
        :pswitch_a6
        :pswitch_9d
        :pswitch_94
        :pswitch_8b
        :pswitch_82
        :pswitch_79
        :pswitch_70
        :pswitch_67
        :pswitch_5e
        :pswitch_57
        :pswitch_4f
        :pswitch_48
        :pswitch_3b
        :pswitch_34
        :pswitch_2d
    .end packed-switch
.end method

.method private final system(IZ)Landroid/graphics/Typeface;
    .registers 7
    .param p1, "weight"    # I
    .param p2, "italic"    # Z

    .line 30
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    const-string v2, "create(...)"

    if-lt v0, v1, :cond_1a

    sget-object v0, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    const/16 v1, 0x64

    const/16 v3, 0x384

    invoke-static {p1, v1, v3}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v1

    invoke-static {v0, v1, p2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_2f

    .line 31
    :cond_1a
    sget-object v0, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    const/16 v1, 0x258

    const/4 v3, 0x0

    if-lt p1, v1, :cond_23

    const/4 v1, 0x1

    goto :goto_24

    :cond_23
    move v1, v3

    :goto_24
    if-eqz p2, :cond_27

    const/4 v3, 0x2

    :cond_27
    or-int/2addr v1, v3

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_2f
    return-object v0
.end method

.method private final weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    .registers 13
    .param p1, "weight"    # I
    .param p2, "italic"    # Z
    .param p3, "files"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ",
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/String;",
            ">;>;)",
            "Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;"
        }
    .end annotation

    .line 35
    move-object v0, p3

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$minByOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 120
    .local v1, "$i$f$minByOrNull\\1\\35":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .line 121
    .local v2, "iterator\\1":Ljava/util/Iterator;
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-nez v3, :cond_10

    const/4 v3, 0x0

    goto :goto_53

    .line 122
    :cond_10
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .line 123
    .local v3, "minElem\\1":Ljava/lang/Object;
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_1b

    goto :goto_53

    .line 124
    :cond_1b
    move-object v4, v3

    check-cast v4, Lkotlin/Pair;

    .local v4, "it\\2":Lkotlin/Pair;
    const/4 v5, 0x0

    .line 35
    .local v5, "$i$a$-minByOrNull-Fonts$weighted$best$1\\2\\124\\0":I
    invoke-virtual {v4}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    sub-int/2addr v6, p1

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v6

    .line 124
    .end local v4    # "it\\2":Lkotlin/Pair;
    .end local v5    # "$i$a$-minByOrNull-Fonts$weighted$best$1\\2\\124\\0":I
    nop

    .line 126
    .local v6, "minValue\\1":I
    :cond_2f
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .line 127
    .local v4, "e\\1":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Lkotlin/Pair;

    .local v5, "it\\3":Lkotlin/Pair;
    const/4 v7, 0x0

    .line 35
    .local v7, "$i$a$-minByOrNull-Fonts$weighted$best$1\\3\\127\\0":I
    invoke-virtual {v5}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v8

    sub-int/2addr v8, p1

    invoke-static {v8}, Ljava/lang/Math;->abs(I)I

    move-result v8

    .line 127
    .end local v5    # "it\\3":Lkotlin/Pair;
    .end local v7    # "$i$a$-minByOrNull-Fonts$weighted$best$1\\3\\127\\0":I
    nop

    .line 128
    .local v8, "v\\1":I
    if-le v6, v8, :cond_4c

    .line 129
    move-object v3, v4

    .line 130
    move v5, v8

    move v6, v5

    .line 132
    .end local v4    # "e\\1":Ljava/lang/Object;
    .end local v8    # "v\\1":I
    :cond_4c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_2f

    .line 133
    nop

    .line 35
    .end local v0    # "$this$minByOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$minByOrNull\\1\\35":I
    .end local v2    # "iterator\\1":Ljava/util/Iterator;
    .end local v3    # "minElem\\1":Ljava/lang/Object;
    .end local v6    # "minValue\\1":I
    :goto_53
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v0, v3

    check-cast v0, Lkotlin/Pair;

    .line 36
    .local v0, "best":Lkotlin/Pair;
    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->asset(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v1

    const/4 v2, 0x0

    if-nez v1, :cond_70

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v3

    invoke-direct {v1, v3, v2, p2}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    return-object v1

    .line 37
    .local v1, "tf":Landroid/graphics/Typeface;
    :cond_70
    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    const/16 v4, 0x258

    if-lt p1, v4, :cond_83

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    if-ge v5, v4, :cond_83

    const/4 v2, 0x1

    :cond_83
    invoke-direct {v3, v1, v2, p2}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    return-object v3
.end method


# virtual methods
.method public final forFamily(Ljava/lang/String;IZ)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    .registers 16
    .param p1, "familyRaw"    # Ljava/lang/String;
    .param p2, "weight"    # I
    .param p3, "italic"    # Z

    const-string v0, "familyRaw"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    const/16 v0, 0x2f

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0, v1, v2, v1}, Lkotlin/text/StringsKt;->substringAfterLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/16 v3, 0x2e

    invoke-static {v0, v3, v1, v2, v1}, Lkotlin/text/StringsKt;->substringBefore$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "toLowerCase(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .local v0, "fam":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/16 v3, 0x384

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v6, "legacyarial"

    const/4 v7, 0x1

    const/16 v8, 0x190

    .line 44
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    .line 43
    const/16 v9, 0x2bc

    .line 44
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    .line 43
    const/4 v11, 0x0

    sparse-switch v1, :sswitch_data_3a6

    goto/16 :goto_393

    :sswitch_3b
    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_104

    goto/16 :goto_393

    :sswitch_43
    const-string v1, "sarpanch"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 67
    const-string v1, "Sarpanch"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_53
    const-string v1, "accanthisadfstd"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b2

    goto/16 :goto_393

    :sswitch_5d
    const-string v1, "gothamssm"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2dc

    goto/16 :goto_393

    :sswitch_67
    const-string v1, "notosans"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 75
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    goto/16 :goto_3a4

    .line 43
    :sswitch_7a
    const-string v1, "denkone"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 61
    const-string v1, "DenkOne"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_8a
    const-string v1, "balthazar"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b2

    goto/16 :goto_393

    :sswitch_94
    const-string v1, "highwaygothic"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f5

    goto/16 :goto_393

    :sswitch_9e
    const-string v1, "creepster"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 58
    const-string v1, "Creepster"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_ae
    const-string v1, "permanentmarker"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 52
    const-string v1, "PermanentMarker"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_be
    const-string v1, "indieflower"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 59
    const-string v1, "IndieFlower"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_ce
    const-string v1, "sourcesanspro"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_268

    goto/16 :goto_393

    :sswitch_d8
    const-string v1, "comicneueangular"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_32d

    goto/16 :goto_393

    :sswitch_e2
    const-string v1, "kalam"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 65
    const-string v1, "Kalam"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_f2
    const-string v1, "arimo"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_104

    goto/16 :goto_393

    :sswitch_fc
    const-string v1, "arial"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 47
    :cond_104
    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10b

    move v9, p2

    :cond_10b
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "Arimo-Regular"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "Arimo-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, v9, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_127
    const-string v1, "jura"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 66
    const-string v1, "Jura"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_137
    const-string v1, "guru"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_366

    goto/16 :goto_393

    :sswitch_141
    const-string v1, "josefinsans"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 70
    const-string v1, "JosefinSans"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_151
    const-string v1, "inconsolata"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 72
    const-string v1, "Inconsolata"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_161
    const-string v1, "titilliumweb"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 64
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "TitilliumWeb"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "TitilliumWeb-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_185
    const-string v1, "bangers"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 50
    const-string v1, "Bangers"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_195
    const-string v1, "pressstart2p"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 51
    const-string v1, "PressStart2P"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_1a5
    const-string v1, "zekton"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_357

    goto/16 :goto_393

    :sswitch_1af
    const-string v1, "ubuntu"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 55
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "Ubuntu"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "Ubuntu-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_1d3
    const-string v1, "grenzegotisch"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 68
    const-string v1, "GrenzeGotisch"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_1e3
    const-string v1, "roboto"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_31a

    goto/16 :goto_393

    :sswitch_1ed
    const-string v1, "robotocondensed"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 74
    :cond_1f5
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "RobotoCondensed"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "RobotoCondensed-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_211
    const-string v1, "fredokaone"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 48
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    const-string v2, "FredokaOne"

    invoke-direct {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->asset(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v2

    if-nez v2, :cond_227

    invoke-direct {p0, v9, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    :cond_227
    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    goto/16 :goto_3a4

    .line 43
    :sswitch_22c
    const-string v1, "oswald"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 53
    const-string v1, "Oswald"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_23c
    const-string v1, "nunito"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 54
    new-array v1, v2, [Lkotlin/Pair;

    const-string v2, "Nunito"

    invoke-static {v8, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v11

    const-string v2, "Nunito-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_260
    const-string v1, "sourcesans"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 45
    :cond_268
    if-eqz p3, :cond_272

    const-string v1, "SourceSans-Italic"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    :cond_272
    new-array v1, v5, [Lkotlin/Pair;

    const/16 v3, 0x12c

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v5, "SourceSans-Light"

    invoke-static {v3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v1, v11

    const-string v3, "SourceSans-Regular"

    invoke-static {v8, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v1, v7

    const/16 v3, 0x258

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v5, "SourceSans-Semibold"

    invoke-static {v3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v1, v2

    const-string v2, "SourceSans-Bold"

    invoke-static {v10, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v4

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, v11, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_2aa
    const-string v1, "merriweather"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 56
    :cond_2b2
    const-string v1, "Merriweather"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_2ba
    const-string v1, "gotham"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2dc

    goto/16 :goto_393

    :sswitch_2c4
    const-string v1, "specialelite"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 63
    const-string v1, "SpecialElite"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_2d4
    const-string v1, "montserrat"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 44
    :cond_2dc
    new-array v1, v5, [Lkotlin/Pair;

    const-string v5, "Montserrat-Regular"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    aput-object v5, v1, v11

    const/16 v5, 0x1f4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v6, "Montserrat-Medium"

    invoke-static {v5, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    aput-object v5, v1, v7

    const-string v5, "Montserrat-Bold"

    invoke-static {v10, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    aput-object v5, v1, v2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "Montserrat-Black"

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v4

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {p0, p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->weighted(IZLjava/util/List;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_312
    const-string v1, "buildersans"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 46
    :cond_31a
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    goto/16 :goto_3a4

    .line 43
    :sswitch_325
    const-string v1, "comicneue"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 73
    :cond_32d
    const-string v1, "ComicNeue"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto/16 :goto_3a4

    .line 43
    :sswitch_335
    const-string v1, "luckiestguy"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 49
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    const-string v2, "LuckiestGuy"

    invoke-direct {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->asset(Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v2

    if-nez v2, :cond_34b

    invoke-direct {p0, v3, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    :cond_34b
    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    goto :goto_3a4

    .line 43
    :sswitch_34f
    const-string v1, "michroma"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 57
    :cond_357
    const-string v1, "Michroma"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 43
    :sswitch_35e
    const-string v1, "fondamento"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 69
    :cond_366
    const-string v1, "Fondamento"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 43
    :sswitch_36d
    const-string v1, "robotomono"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 71
    const-string v1, "RobotoMono"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 43
    :sswitch_37c
    const-string v1, "amaticsc"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_393

    .line 60
    const-string v1, "AmaticSC"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 43
    :sswitch_38b
    const-string v1, "patrickhand"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_394

    :cond_393
    :goto_393
    goto :goto_39b

    .line 62
    :cond_394
    const-string v1, "PatrickHand"

    invoke-static {p2, p3, v1}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily$one(IZLjava/lang/String;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v1

    goto :goto_3a4

    .line 76
    :goto_39b
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->system(IZ)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-direct {v1, v2, v11, p3}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;-><init>(Landroid/graphics/Typeface;ZZ)V

    .line 43
    :goto_3a4
    return-object v1

    nop

    :sswitch_data_3a6
    .sparse-switch
        -0x7963008f -> :sswitch_38b
        -0x718ccd37 -> :sswitch_37c
        -0x6d570c58 -> :sswitch_36d
        -0x68aab3f1 -> :sswitch_35e
        -0x63d2c4ee -> :sswitch_34f
        -0x630c9523 -> :sswitch_335
        -0x600be89e -> :sswitch_325
        -0x5b0d9552 -> :sswitch_312
        -0x4df87353 -> :sswitch_2d4
        -0x4b0ebe86 -> :sswitch_2c4
        -0x49ea5978 -> :sswitch_2ba
        -0x47aca2bd -> :sswitch_2aa
        -0x42315cd2 -> :sswitch_260
        -0x3da69443 -> :sswitch_23c
        -0x3c09f25a -> :sswitch_22c
        -0x3b021f94 -> :sswitch_211
        -0x39098c7e -> :sswitch_1ed
        -0x372d1cbb -> :sswitch_1e3
        -0x35502044 -> :sswitch_1d3
        -0x32bd2519 -> :sswitch_1af
        -0x2a0f194d -> :sswitch_1a5
        -0x1fa62b43 -> :sswitch_195
        -0x1418c7d2 -> :sswitch_185
        -0x126a19e3 -> :sswitch_161
        -0x10112885 -> :sswitch_151
        -0x9b50f19 -> :sswitch_141
        0x3097b1 -> :sswitch_137
        0x31f4ba -> :sswitch_127
        0x58c5083 -> :sswitch_fc
        0x58c51fa -> :sswitch_f2
        0x6118c82 -> :sswitch_e2
        0x119b0440 -> :sswitch_d8
        0x11a118bf -> :sswitch_ce
        0x227c8b56 -> :sswitch_be
        0x25522e68 -> :sswitch_ae
        0x2a4c0f4f -> :sswitch_9e
        0x31fa9bc3 -> :sswitch_94
        0x3b7f20eb -> :sswitch_8a
        0x5c8907a8 -> :sswitch_7a
        0x5ed9128f -> :sswitch_67
        0x61802a85 -> :sswitch_5d
        0x7d3bf5ac -> :sswitch_53
        0x7e441c5e -> :sswitch_43
        0x7e5f525a -> :sswitch_3b
    .end sparse-switch
.end method

.method public final init(Landroid/content/res/AssetManager;)V
    .registers 3
    .param p1, "a"    # Landroid/content/res/AssetManager;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    sput-object p1, Lcom/exampletest/mobilestudiotest/ui/Fonts;->assets:Landroid/content/res/AssetManager;

    return-void
.end method

.method public final of(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    .registers 12
    .param p1, "c"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 107
    const-string v0, "FontFace"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/FontValue;

    const/4 v2, 0x0

    if-eqz v1, :cond_13

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/FontValue;

    goto :goto_14

    :cond_13
    move-object v0, v2

    .line 108
    .local v0, "ff":Lcom/exampletest/mobilestudiotest/model/FontValue;
    :goto_14
    if-nez v0, :cond_30

    const-string v1, "Font"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v3, v1, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v3, :cond_23

    move-object v2, v1

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    :cond_23
    if-eqz v2, :cond_2a

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v1

    goto :goto_2b

    :cond_2a
    const/4 v1, 0x3

    :goto_2b
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    goto :goto_31

    :cond_30
    move-object v1, v0

    .line 109
    .local v1, "key":Ljava/lang/Object;
    :goto_31
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Fonts;->faceCache:Ljava/util/HashMap;

    monitor-enter v2

    const/4 v3, 0x0

    .line 110
    .local v3, "$i$a$-synchronized-Fonts$of$1\\1\\109\\0":I
    :try_start_35
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Fonts;->faceCache:Ljava/util/HashMap;

    invoke-virtual {v4, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    :try_end_3d
    .catchall {:try_start_35 .. :try_end_3d} :catchall_a7

    if-eqz v4, :cond_43

    .line 119
    .local v4, "it\\2":Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    const/4 v5, 0x0

    .line 110
    .local v5, "$i$a$-let-Fonts$of$1$1\\2\\110\\1":I
    nop

    .end local v3    # "$i$a$-synchronized-Fonts$of$1\\1\\109\\0":I
    .end local v4    # "it\\2":Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    .end local v5    # "$i$a$-let-Fonts$of$1$1\\2\\110\\1":I
    monitor-exit v2

    return-object v4

    .line 111
    .restart local v3    # "$i$a$-synchronized-Fonts$of$1\\1\\109\\0":I
    :cond_43
    if-eqz v0, :cond_6e

    :try_start_45
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getFamily()Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-lez v4, :cond_55

    move v4, v6

    goto :goto_56

    :cond_55
    move v4, v5

    :goto_56
    if-eqz v4, :cond_6e

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Fonts;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getFamily()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getWeight()I

    move-result v8

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getStyle()I

    move-result v9

    if-ne v9, v6, :cond_69

    move v5, v6

    :cond_69
    invoke-virtual {v4, v7, v8, v5}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily(Ljava/lang/String;IZ)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v4

    goto :goto_9c

    .line 112
    :cond_6e
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Fonts;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

    move-object v5, v1

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->fromEnum(I)Lkotlin/Triple;

    move-result-object v4

    invoke-virtual {v4}, Lkotlin/Triple;->component1()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .local v5, "f\\1":Ljava/lang/String;
    invoke-virtual {v4}, Lkotlin/Triple;->component2()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    .local v6, "w\\1":I
    invoke-virtual {v4}, Lkotlin/Triple;->component3()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    .local v4, "i\\1":Z
    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Fonts;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

    invoke-virtual {v7, v5, v6, v4}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily(Ljava/lang/String;IZ)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v7

    move-object v4, v7

    .line 111
    .end local v4    # "i\\1":Z
    .end local v5    # "f\\1":Ljava/lang/String;
    .end local v6    # "w\\1":I
    :goto_9c
    nop

    .line 113
    .local v4, "face\\1":Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Fonts;->faceCache:Ljava/util/HashMap;

    check-cast v5, Ljava/util/Map;

    invoke-interface {v5, v1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_a4
    .catchall {:try_start_45 .. :try_end_a4} :catchall_a7

    .line 114
    nop

    .end local v3    # "$i$a$-synchronized-Fonts$of$1\\1\\109\\0":I
    .end local v4    # "face\\1":Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
    monitor-exit v2

    return-object v4

    :catchall_a7
    move-exception v3

    monitor-exit v2

    throw v3
.end method

###### Class com.exampletest.mobilestudiotest.ui.Fonts.Face (com.exampletest.mobilestudiotest.ui.Fonts$Face)
.class public final Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;
.super Ljava/lang/Object;
.source "Fonts.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/Fonts;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Face"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\t\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0007\u0010\u0008R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000c\u00a8\u0006\u000e"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;",
        "",
        "typeface",
        "Landroid/graphics/Typeface;",
        "fakeBold",
        "",
        "italic",
        "<init>",
        "(Landroid/graphics/Typeface;ZZ)V",
        "getTypeface",
        "()Landroid/graphics/Typeface;",
        "getFakeBold",
        "()Z",
        "getItalic",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final fakeBold:Z

.field private final italic:Z

.field private final typeface:Landroid/graphics/Typeface;


# direct methods
.method public constructor <init>(Landroid/graphics/Typeface;ZZ)V
    .registers 5
    .param p1, "typeface"    # Landroid/graphics/Typeface;
    .param p2, "fakeBold"    # Z
    .param p3, "italic"    # Z

    const-string v0, "typeface"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;->typeface:Landroid/graphics/Typeface;

    iput-boolean p2, p0, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;->fakeBold:Z

    iput-boolean p3, p0, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;->italic:Z

    return-void
.end method


# virtual methods
.method public final getFakeBold()Z
    .registers 2

    .line 20
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;->fakeBold:Z

    return v0
.end method

.method public final getItalic()Z
    .registers 2

    .line 20
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;->italic:Z

    return v0
.end method

.method public final getTypeface()Landroid/graphics/Typeface;
    .registers 2

    .line 20
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;->typeface:Landroid/graphics/Typeface;

    return-object v0
.end method
