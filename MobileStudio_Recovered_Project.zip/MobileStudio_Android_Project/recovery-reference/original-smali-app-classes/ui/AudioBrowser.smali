###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser (com.exampletest.mobilestudiotest.ui.AudioBrowser)
.class public final Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
.super Landroid/widget/LinearLayout;
.source "AudioBrowser.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;,
        Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAudioBrowser.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AudioBrowser.kt\ncom/exampletest/mobilestudiotest/ui/AudioBrowser\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,408:1\n1#2:409\n230#3,2:410\n1878#3,3:412\n1563#3:415\n1634#3,3:416\n1563#3:419\n1634#3,3:420\n*S KotlinDebug\n*F\n+ 1 AudioBrowser.kt\ncom/exampletest/mobilestudiotest/ui/AudioBrowser\n*L\n163#1:410,2\n175#1:412,3\n164#1:415\n164#1:416,3\n166#1:419\n166#1:420,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0094\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u000b\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\t\n\u0002\u0008\u0006\n\u0002\u0010\u0007\n\u0002\u0008\u0012\n\u0002\u0018\u0002\n\u0002\u0008\u0007\u0008\u0007\u0018\u00002\u00020\u0001:\u0002VWB=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005\u0012\u0018\u0010\u0008\u001a\u0014\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00070\t\u0012\u0004\u0012\u00020\u00070\u0005\u00a2\u0006\u0004\u0008\n\u0010\u000bJ\u0008\u0010:\u001a\u00020\u0007H\u0014J\u0008\u0010;\u001a\u00020\u0007H\u0014J\u0010\u0010<\u001a\u00020\u001d2\u0006\u0010=\u001a\u00020>H\u0002J6\u0010?\u001a\u00020 2\u0006\u0010@\u001a\u00020\u00182\u0006\u0010A\u001a\u00020\u001a2\u0008\u0008\u0002\u0010B\u001a\u00020\u001a2\u0012\u0010C\u001a\u000e\u0012\u0004\u0012\u00020$\u0012\u0004\u0012\u00020\u00070\u0005H\u0002J\u0008\u0010D\u001a\u00020\u0007H\u0002J\u0010\u0010E\u001a\u00020\u00182\u0006\u0010F\u001a\u00020\u0018H\u0002J2\u0010G\u001a\u00020\u00072\u0006\u0010H\u001a\u00020$2\u000c\u0010I\u001a\u0008\u0012\u0004\u0012\u00020\u0018002\u0012\u0010J\u001a\u000e\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u00070\u0005H\u0002J\u000e\u0010K\u001a\u00020\u00072\u0006\u0010L\u001a\u00020\u0018J\u0008\u0010M\u001a\u00020\u0007H\u0002J\u0008\u0010N\u001a\u00020\u0007H\u0002J\u0008\u0010O\u001a\u00020$H\u0002J\u0008\u0010P\u001a\u00020QH\u0002J\u0008\u0010R\u001a\u00020\u0007H\u0002J\u0010\u0010S\u001a\u00020\u00182\u0006\u0010T\u001a\u00020\u001dH\u0002J\u0010\u0010U\u001a\u00020\u00182\u0006\u0010T\u001a\u00020>H\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010\u0008\u001a\u0014\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00070\t\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u000c\u001a\n \u000e*\u0004\u0018\u00010\r0\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0012\u001a\u0012\u0012\u0004\u0012\u00020\u00060\u0013j\u0008\u0012\u0004\u0012\u00020\u0006`\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0015\u001a\u00060\u0016R\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010#\u001a\u0004\u0018\u00010$X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001e\u0010&\u001a\u00020\u00182\u0006\u0010%\u001a\u00020\u0018@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\'\u0010(R\u0010\u0010)\u001a\u0004\u0018\u00010\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u001dX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010,\u001a\u0004\u0018\u00010\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R \u0010/\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u00180100X\u0082\u0004\u00a2\u0006\u0002\n\u0000R.\u00102\u001a\"\u0012\u001e\u0012\u001c\u0012\u0004\u0012\u00020\u0018\u0012\u0012\u0012\u0010\u0012\u0004\u0012\u00020\u001d\u0012\u0006\u0012\u0004\u0018\u00010\u001d010100X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u00103\u001a\u0008\u0012\u0004\u0012\u00020\u001800X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u00104\u001a\u0008\u0012\u0004\u0012\u00020\u001800X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u00105\u001a\u0008\u0012\u0004\u0012\u00020\u001800X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u00106\u001a\u0004\u0018\u000107X\u0082\u000e\u00a2\u0006\u0004\n\u0002\u00108R\u0014\u00109\u001a\u0008\u0012\u0004\u0012\u00020\u00070\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006X"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;",
        "Landroid/widget/LinearLayout;",
        "ctx",
        "Landroid/content/Context;",
        "onInsert",
        "Lkotlin/Function1;",
        "Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;",
        "",
        "needSignIn",
        "Lkotlin/Function0;",
        "<init>",
        "(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V",
        "net",
        "Ljava/util/concurrent/ExecutorService;",
        "kotlin.jvm.PlatformType",
        "content",
        "Landroid/widget/FrameLayout;",
        "filterBar",
        "items",
        "Ljava/util/ArrayList;",
        "Lkotlin/collections/ArrayList;",
        "adapter",
        "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;",
        "token",
        "",
        "loading",
        "",
        "ended",
        "gen",
        "",
        "useLegacy",
        "status",
        "Landroid/widget/TextView;",
        "progress",
        "Landroid/widget/ProgressBar;",
        "results",
        "Landroid/view/View;",
        "value",
        "keyword",
        "getKeyword",
        "()Ljava/lang/String;",
        "type",
        "sort",
        "lengthIdx",
        "tag",
        "chart",
        "discover",
        "sorts",
        "",
        "Lkotlin/Pair;",
        "lengths",
        "genres",
        "vibes",
        "sfx",
        "draggingId",
        "",
        "Ljava/lang/Long;",
        "previewListener",
        "onAttachedToWindow",
        "onDetachedFromWindow",
        "dp",
        "v",
        "",
        "chip",
        "label",
        "on",
        "dropdown",
        "onClick",
        "buildFilters",
        "chartLabel",
        "c",
        "menu",
        "anchor",
        "labels",
        "pick",
        "search",
        "q",
        "showDiscover",
        "showResults",
        "buildResults",
        "query",
        "Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;",
        "loadMore",
        "fmtTime",
        "sec",
        "fmtClock",
        "VH",
        "Adapter",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final adapter:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;

.field private chart:Ljava/lang/String;

.field private final content:Landroid/widget/FrameLayout;

.field private discover:Z

.field private draggingId:Ljava/lang/Long;

.field private ended:Z

.field private final filterBar:Landroid/widget/LinearLayout;

.field private gen:I

.field private final genres:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final items:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;",
            ">;"
        }
    .end annotation
.end field

.field private keyword:Ljava/lang/String;

.field private lengthIdx:I

.field private final lengths:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;>;>;"
        }
    .end annotation
.end field

.field private loading:Z

.field private final needSignIn:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final net:Ljava/util/concurrent/ExecutorService;

.field private final onInsert:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final previewListener:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private progress:Landroid/widget/ProgressBar;

.field private results:Landroid/view/View;

.field private final sfx:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private sort:Ljava/lang/String;

.field private final sorts:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private status:Landroid/widget/TextView;

.field private tag:Ljava/lang/String;

.field private token:Ljava/lang/String;

.field private type:Ljava/lang/String;

.field private useLegacy:Z

.field private final vibes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
    .registers 28
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "onInsert"    # Lkotlin/jvm/functions/Function1;
    .param p3, "needSignIn"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    const-string v4, "ctx"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "onInsert"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "needSignIn"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    invoke-direct/range {p0 .. p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->onInsert:Lkotlin/jvm/functions/Function1;

    iput-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->needSignIn:Lkotlin/jvm/functions/Function1;

    .line 97
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v4

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->net:Ljava/util/concurrent/ExecutorService;

    .line 98
    new-instance v4, Landroid/widget/FrameLayout;

    invoke-direct {v4, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->content:Landroid/widget/FrameLayout;

    .line 99
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 409
    move-object v5, v4

    .local v5, "$this$filterBar_u24lambda_u240\\1":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 99
    .local v6, "$i$a$-apply-AudioBrowser$filterBar$1\\1\\99\\0":I
    const/4 v7, 0x0

    .line 122
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    .line 99
    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v9, 0x10

    invoke-virtual {v5, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .end local v5    # "$this$filterBar_u24lambda_u240\\1":Landroid/widget/LinearLayout;
    .end local v6    # "$i$a$-apply-AudioBrowser$filterBar$1\\1\\99\\0":I
    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->filterBar:Landroid/widget/LinearLayout;

    .line 100
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->items:Ljava/util/ArrayList;

    .line 101
    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;

    invoke-direct {v4, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->adapter:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;

    .line 112
    const-string v4, ""

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->keyword:Ljava/lang/String;

    .line 115
    const-string v4, "Relevance"

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sort:Ljava/lang/String;

    .line 118
    const-string v5, "None"

    iput-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    .line 119
    const/4 v5, 0x1

    iput-boolean v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->discover:Z

    .line 121
    const/4 v6, 0x5

    new-array v10, v6, [Lkotlin/Pair;

    invoke-static {v4, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    aput-object v4, v10, v7

    const-string v4, "Trending"

    invoke-static {v4, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    aput-object v4, v10, v5

    const-string v4, "Top"

    const-string v11, "Top rated"

    invoke-static {v4, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    const/4 v11, 0x2

    aput-object v4, v10, v11

    const-string v4, "UpdatedTime"

    const-string v12, "Most recent"

    invoke-static {v4, v12}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    const/4 v12, 0x3

    aput-object v4, v10, v12

    const-string v4, "AudioDuration"

    const-string v13, "Length"

    invoke-static {v4, v13}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    const/4 v13, 0x4

    aput-object v4, v10, v13

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sorts:Ljava/util/List;

    .line 122
    new-array v4, v6, [Lkotlin/Pair;

    const/4 v10, 0x0

    invoke-static {v8, v10}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v14

    const-string v15, "Any length"

    invoke-static {v15, v14}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v14

    aput-object v14, v4, v7

    const/16 v14, 0xa

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-static {v8, v15}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v8

    move/from16 v16, v6

    const-string v6, "Under 10s"

    invoke-static {v6, v8}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    aput-object v6, v4, v5

    const/16 v6, 0x3c

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v15, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v8

    const-string v15, "10s \u2013 1 min"

    invoke-static {v15, v8}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v8

    aput-object v8, v4, v11

    const/16 v8, 0xb4

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v6, v8}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    const-string v15, "1 \u2013 3 min"

    invoke-static {v15, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    aput-object v6, v4, v12

    invoke-static {v8, v10}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    const-string v8, "Over 3 min"

    invoke-static {v8, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    aput-object v6, v4, v13

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengths:Ljava/util/List;

    .line 123
    const/16 v4, 0x11

    new-array v6, v4, [Ljava/lang/String;

    const-string v8, "Ambient"

    aput-object v8, v6, v7

    const-string v8, "Classical"

    aput-object v8, v6, v5

    const-string v8, "Country"

    aput-object v8, v6, v11

    const-string v8, "Electronic"

    aput-object v8, v6, v12

    const-string v8, "Funk"

    aput-object v8, v6, v13

    const-string v8, "Hip Hop"

    aput-object v8, v6, v16

    const-string v8, "Jazz"

    const/4 v10, 0x6

    aput-object v8, v6, v10

    const-string v8, "Latin"

    const/4 v15, 0x7

    aput-object v8, v6, v15

    const-string v8, "Lo-fi"

    const/16 v17, 0x8

    aput-object v8, v6, v17

    const-string v8, "Metal"

    const/16 v18, 0x9

    aput-object v8, v6, v18

    const-string v8, "Orchestral"

    aput-object v8, v6, v14

    const-string v8, "Pop"

    const/16 v19, 0xb

    aput-object v8, v6, v19

    const-string v8, "R&B"

    move/from16 v20, v4

    const/16 v4, 0xc

    aput-object v8, v6, v4

    const-string v8, "Reggae"

    const/16 v21, 0xd

    aput-object v8, v6, v21

    const-string v8, "Rock"

    const/16 v22, 0xe

    aput-object v8, v6, v22

    const/16 v8, 0xf

    const-string v23, "Synthwave"

    aput-object v23, v6, v8

    const-string v8, "World"

    aput-object v8, v6, v9

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    iput-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->genres:Ljava/util/List;

    .line 124
    new-array v6, v4, [Ljava/lang/String;

    const-string v8, "Calm"

    aput-object v8, v6, v7

    const-string v8, "Chill"

    aput-object v8, v6, v5

    const-string v8, "Dark"

    aput-object v8, v6, v11

    const-string v8, "Epic"

    aput-object v8, v6, v12

    const-string v8, "Funny"

    aput-object v8, v6, v13

    const-string v8, "Happy"

    aput-object v8, v6, v16

    const-string v8, "Intense"

    aput-object v8, v6, v10

    const-string v8, "Mysterious"

    aput-object v8, v6, v15

    const-string v8, "Romantic"

    aput-object v8, v6, v17

    const-string v8, "Sad"

    aput-object v8, v6, v18

    const-string v8, "Scary"

    aput-object v8, v6, v14

    const-string v8, "Upbeat"

    aput-object v8, v6, v19

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    iput-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->vibes:Ljava/util/List;

    .line 125
    const/16 v6, 0x14

    new-array v6, v6, [Ljava/lang/String;

    const-string v8, "UI"

    aput-object v8, v6, v7

    const-string v8, "Footsteps"

    aput-object v8, v6, v5

    const-string v8, "Explosions"

    aput-object v8, v6, v11

    const-string v8, "Weapons"

    aput-object v8, v6, v12

    const-string v8, "Impacts"

    aput-object v8, v6, v13

    const-string v8, "Whooshes"

    aput-object v8, v6, v16

    const-string v8, "Magic"

    aput-object v8, v6, v10

    const-string v8, "Nature"

    aput-object v8, v6, v15

    const-string v8, "Ambience"

    aput-object v8, v6, v17

    const-string v8, "Vehicles"

    aput-object v8, v6, v18

    const-string v8, "Animals"

    aput-object v8, v6, v14

    const-string v8, "Voices"

    aput-object v8, v6, v19

    const-string v8, "Sci-fi"

    aput-object v8, v6, v4

    const-string v4, "Horror"

    aput-object v4, v6, v21

    const-string v4, "Cartoon"

    aput-object v4, v6, v22

    const/16 v4, 0xf

    const-string v8, "Water"

    aput-object v8, v6, v4

    const-string v4, "Fire"

    aput-object v4, v6, v9

    const-string v4, "Doors"

    aput-object v4, v6, v20

    const/16 v4, 0x12

    const-string v8, "Coins"

    aput-object v8, v6, v4

    const/16 v4, 0x13

    const-string v8, "Alarms"

    aput-object v8, v6, v4

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sfx:Ljava/util/List;

    .line 129
    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda0;

    invoke-direct {v4, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->previewListener:Lkotlin/jvm/functions/Function0;

    .line 131
    nop

    .line 132
    invoke-virtual {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->setOrientation(I)V

    .line 133
    new-instance v4, Landroid/widget/HorizontalScrollView;

    invoke-direct {v4, v1}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    .line 409
    move-object v5, v4

    .local v5, "$this$_init__u24lambda_u243\\2":Landroid/widget/HorizontalScrollView;
    const/4 v6, 0x0

    .line 133
    .local v6, "$i$a$-apply-AudioBrowser$1\\2\\133\\0":I
    invoke-virtual {v5, v7}, Landroid/widget/HorizontalScrollView;->setHorizontalScrollBarEnabled(Z)V

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->filterBar:Landroid/widget/LinearLayout;

    check-cast v8, Landroid/view/View;

    invoke-virtual {v5, v8}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    .end local v5    # "$this$_init__u24lambda_u243\\2":Landroid/widget/HorizontalScrollView;
    .end local v6    # "$i$a$-apply-AudioBrowser$1\\2\\133\\0":I
    check-cast v4, Landroid/view/View;

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v12, 0x4

    const/4 v13, 0x0

    const/4 v9, -0x1

    const/4 v10, -0x2

    const/4 v11, 0x0

    invoke-static/range {v8 .. v13}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 134
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->content:Landroid/widget/FrameLayout;

    check-cast v4, Landroid/view/View;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v6, -0x1

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-virtual {v5, v6, v7, v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 135
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover()V

    .line 136
    nop

    .line 96
    return-void
.end method

.method public static final synthetic access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I
    .registers 3
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "v"    # F

    .line 95
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v0

    return v0
.end method

.method public static final synthetic access$fmtClock(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)Ljava/lang/String;
    .registers 3
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "sec"    # F

    .line 95
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->fmtClock(F)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$fmtTime(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Ljava/lang/String;
    .registers 3
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "sec"    # I

    .line 95
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->fmtTime(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getDraggingId$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Ljava/lang/Long;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 95
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->draggingId:Ljava/lang/Long;

    return-object v0
.end method

.method public static final synthetic access$getItems$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Ljava/util/ArrayList;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 95
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->items:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static final synthetic access$getNeedSignIn$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/jvm/functions/Function1;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 95
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->needSignIn:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public static final synthetic access$getOnInsert$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/jvm/functions/Function1;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 95
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->onInsert:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public static final synthetic access$loadMore(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 1
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 95
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loadMore()V

    return-void
.end method

.method public static final synthetic access$setDraggingId$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/Long;)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "<set-?>"    # Ljava/lang/Long;

    .line 95
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->draggingId:Ljava/lang/Long;

    return-void
.end method

.method private final buildFilters()V
    .registers 13

    .line 156
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->filterBar:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 157
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->filterBar:Landroid/widget/LinearLayout;

    const/high16 v1, 0x40c00000    # 6.0f

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v2

    const/high16 v3, 0x40800000    # 4.0f

    invoke-direct {p0, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v4

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v1

    invoke-direct {p0, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v3

    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 159
    iget-boolean v7, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->discover:Z

    new-instance v9, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda6;

    invoke-direct {v9, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    const/4 v10, 0x4

    const/4 v11, 0x0

    const-string v6, "Discover"

    const/4 v8, 0x0

    move-object v5, p0

    invoke-static/range {v5 .. v11}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip$default(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-static {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$add(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)V

    .line 160
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    const-string v1, "Music"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4b

    const-string v1, "SoundEffect"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_49

    const-string v1, "Sound Effects"

    goto :goto_4b

    :cond_49
    const-string v1, "Type"

    :cond_4b
    :goto_4b
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_53

    move v0, v3

    goto :goto_54

    :cond_53
    move v0, v2

    :goto_54
    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda7;

    invoke-direct {v4, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda7;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-direct {p0, v1, v0, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip(Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-static {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$add(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)V

    .line 163
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sorts:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$first\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 410
    .local v1, "$i$f$first\\1\\163":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_6b
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_13f

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\1":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Lkotlin/Pair;

    .local v6, "it\\2":Lkotlin/Pair;
    const/4 v7, 0x0

    .line 163
    .local v7, "$i$a$-first-AudioBrowser$buildFilters$3\\2\\410\\0":I
    invoke-virtual {v6}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v8

    iget-object v9, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sort:Ljava/lang/String;

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    .line 410
    .end local v6    # "it\\2":Lkotlin/Pair;
    .end local v7    # "$i$a$-first-AudioBrowser$buildFilters$3\\2\\410\\0":I
    if-eqz v6, :cond_6b

    .line 411
    .end local v0    # "$this$first\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$first\\1\\163":I
    .end local v5    # "element\\1":Ljava/lang/Object;
    move-object v0, v5

    check-cast v0, Lkotlin/Pair;

    .line 163
    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Sort: "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sort:Ljava/lang/String;

    const-string v4, "Relevance"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    xor-int/2addr v1, v3

    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda8;

    invoke-direct {v4, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda8;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-direct {p0, v0, v1, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip(Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-static {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$add(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)V

    .line 166
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengths:Ljava/util/List;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengthIdx:I

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkotlin/Pair;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengthIdx:I

    if-eqz v1, :cond_cb

    move v2, v3

    :cond_cb
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda9;

    invoke-direct {v1, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda9;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-direct {p0, v0, v2, v3, v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip(Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-static {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$add(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)V

    .line 167
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    const-string v8, "  \u2715"

    if-eqz v0, :cond_104

    .line 409
    .local v0, "t\\3":Ljava/lang/String;
    const/4 v9, 0x0

    .line 167
    .local v9, "$i$a$-let-AudioBrowser$buildFilters$6\\3\\167\\0":I
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda10;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda10;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    move-object v1, p0

    invoke-static/range {v1 .. v7}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip$default(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-static {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$add(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)V

    .line 168
    .end local v0    # "t\\3":Ljava/lang/String;
    .end local v9    # "$i$a$-let-AudioBrowser$buildFilters$6\\3\\167\\0":I
    :cond_104
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    const-string v1, "None"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_13e

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chartLabel(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Top charts: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda11;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda11;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    move-object v1, p0

    invoke-static/range {v1 .. v7}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip$default(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-static {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$add(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)V

    .line 169
    :cond_13e
    return-void

    .line 411
    .local v0, "$this$first\\1":Ljava/lang/Iterable;
    .restart local v1    # "$i$f$first\\1\\163":I
    :cond_13f
    new-instance v2, Ljava/util/NoSuchElementException;

    const-string v3, "Collection contains no element matching the predicate."

    invoke-direct {v2, v3}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method private static final buildFilters$add(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)V
    .registers 9
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "v"    # Landroid/view/View;

    .line 158
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->filterBar:Landroid/widget/LinearLayout;

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v2, -0x2

    const/4 v3, -0x2

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    .line 409
    move-object v2, v1

    .local v2, "$this$buildFilters_u24add_u24lambda_u247\\1":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v3, 0x0

    .line 158
    .local v3, "$i$a$-apply-AudioBrowser$buildFilters$add$1\\1\\158\\0":I
    const/high16 v4, 0x40c00000    # 6.0f

    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v2    # "$this$buildFilters_u24add_u24lambda_u247\\1":Landroid/widget/LinearLayout$LayoutParams;
    .end local v3    # "$i$a$-apply-AudioBrowser$buildFilters$add$1\\1\\158\\0":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method static final buildFilters$lambda$10(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;
    .registers 5
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "v"    # Landroid/view/View;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 161
    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "All audio"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "Music"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "Sound Effects"

    aput-object v2, v0, v1

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda13;

    invoke-direct {v1, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda13;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-direct {p0, p1, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->menu(Landroid/view/View;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 162
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final buildFilters$lambda$10$lambda$9(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "i"    # I

    .line 161
    packed-switch p1, :pswitch_data_12

    const/4 v0, 0x0

    goto :goto_a

    :pswitch_5
    const-string v0, "SoundEffect"

    goto :goto_a

    :pswitch_8
    const-string v0, "Music"

    :goto_a
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    :pswitch_data_12
    .packed-switch 0x1
        :pswitch_8
        :pswitch_5
    .end packed-switch
.end method

.method static final buildFilters$lambda$14(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;
    .registers 12
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "v"    # Landroid/view/View;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sorts:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 415
    .local v1, "$i$f$map\\1\\164":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 416
    .local v4, "$i$f$mapTo\\2\\415":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1d
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_35

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 417
    .local v6, "item\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lkotlin/Pair;

    .local v7, "it\\3":Lkotlin/Pair;
    const/4 v8, 0x0

    .line 164
    .local v8, "$i$a$-map-AudioBrowser$buildFilters$4$1\\3\\417\\0":I
    invoke-virtual {v7}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .line 417
    .end local v7    # "it\\3":Lkotlin/Pair;
    .end local v8    # "$i$a$-map-AudioBrowser$buildFilters$4$1\\3\\417\\0":I
    invoke-interface {v2, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1d

    .line 418
    .end local v6    # "item\\2":Ljava/lang/Object;
    :cond_35
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapTo\\2\\415":I
    check-cast v2, Ljava/util/List;

    .line 415
    nop

    .line 164
    .end local v0    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map\\1\\164":I
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda22;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda22;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-direct {p0, p1, v2, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->menu(Landroid/view/View;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 165
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final buildFilters$lambda$14$lambda$13(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "i"    # I

    .line 164
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sorts:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkotlin/Pair;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sort:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final buildFilters$lambda$17(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;
    .registers 12
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "v"    # Landroid/view/View;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 166
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengths:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 419
    .local v1, "$i$f$map\\1\\166":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 420
    .local v4, "$i$f$mapTo\\2\\419":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1d
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_35

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 421
    .local v6, "item\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lkotlin/Pair;

    .local v7, "it\\3":Lkotlin/Pair;
    const/4 v8, 0x0

    .line 166
    .local v8, "$i$a$-map-AudioBrowser$buildFilters$5$1\\3\\421\\0":I
    invoke-virtual {v7}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .line 421
    .end local v7    # "it\\3":Lkotlin/Pair;
    .end local v8    # "$i$a$-map-AudioBrowser$buildFilters$5$1\\3\\421\\0":I
    invoke-interface {v2, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1d

    .line 422
    .end local v6    # "item\\2":Ljava/lang/Object;
    :cond_35
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapTo\\2\\419":I
    check-cast v2, Ljava/util/List;

    .line 419
    nop

    .line 166
    .end local v0    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map\\1\\166":I
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda12;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda12;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-direct {p0, p1, v2, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->menu(Landroid/view/View;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final buildFilters$lambda$17$lambda$16(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "i"    # I

    .line 166
    iput p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengthIdx:I

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final buildFilters$lambda$19$lambda$18(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 167
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->keyword:Ljava/lang/String;

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_20

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    const-string v1, "None"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover()V

    goto :goto_23

    :cond_20
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    :goto_23
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final buildFilters$lambda$20(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 168
    const-string v0, "None"

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->keyword:Ljava/lang/String;

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1b

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    if-nez v0, :cond_1b

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover()V

    goto :goto_1e

    :cond_1b
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    :goto_1e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final buildFilters$lambda$8(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 159
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    const-string v0, "None"

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->keyword:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final buildResults()Landroid/view/View;
    .registers 20

    .line 247
    move-object/from16 v0, p0

    new-instance v1, Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 248
    .local v1, "host":Landroid/widget/FrameLayout;
    new-instance v2, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;)V

    .line 249
    .local v2, "rv":Landroidx/recyclerview/widget/RecyclerView;
    new-instance v3, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    .line 250
    .local v3, "lm":Landroidx/recyclerview/widget/LinearLayoutManager;
    move-object v4, v3

    check-cast v4, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    invoke-virtual {v2, v4}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 251
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->adapter:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;

    check-cast v4, Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v2, v4}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 252
    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    .line 253
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1;

    invoke-direct {v5, v3, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1;-><init>(Landroidx/recyclerview/widget/LinearLayoutManager;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    check-cast v5, Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;

    invoke-virtual {v2, v5}, Landroidx/recyclerview/widget/RecyclerView;->addOnScrollListener(Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;)V

    .line 256
    move-object v5, v2

    check-cast v5, Landroid/view/View;

    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v7, -0x1

    invoke-direct {v6, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v5, v6}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 257
    new-instance v5, Landroid/widget/ProgressBar;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    .line 409
    move-object v6, v5

    .local v6, "$this$buildResults_u24lambda_u2442\\1":Landroid/widget/ProgressBar;
    const/4 v8, 0x0

    .line 257
    .local v8, "$i$a$-apply-AudioBrowser$buildResults$2\\1\\257\\0":I
    const/4 v9, 0x1

    invoke-virtual {v6, v9}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    const/16 v9, 0x8

    invoke-virtual {v6, v9}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .end local v6    # "$this$buildResults_u24lambda_u2442\\1":Landroid/widget/ProgressBar;
    .end local v8    # "$i$a$-apply-AudioBrowser$buildResults$2\\1\\257\\0":I
    iput-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->progress:Landroid/widget/ProgressBar;

    .line 258
    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->progress:Landroid/widget/ProgressBar;

    if-nez v5, :cond_66

    const-string v5, "progress"

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v5, v4

    :cond_66
    check-cast v5, Landroid/view/View;

    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    const/high16 v8, 0x42080000    # 34.0f

    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v9

    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v8

    const/16 v10, 0x11

    invoke-direct {v6, v9, v8, v10}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v5, v6}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 259
    sget-object v11, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v12

    const-string v5, "getContext(...)"

    invoke-static {v12, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v15

    const/16 v17, 0x10

    const/16 v18, 0x0

    const-string v13, ""

    const/high16 v14, 0x41400000    # 12.0f

    const/16 v16, 0x0

    invoke-static/range {v11 .. v18}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v5

    .line 409
    move-object v6, v5

    .local v6, "$this$buildResults_u24lambda_u2443\\2":Landroid/widget/TextView;
    const/4 v8, 0x0

    .line 259
    .local v8, "$i$a$-apply-AudioBrowser$buildResults$3\\2\\259\\0":I
    const/4 v9, 0x0

    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setSingleLine(Z)V

    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v11, 0x41800000    # 16.0f

    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v12

    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v11

    invoke-virtual {v6, v12, v9, v11, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .end local v6    # "$this$buildResults_u24lambda_u2443\\2":Landroid/widget/TextView;
    .end local v8    # "$i$a$-apply-AudioBrowser$buildResults$3\\2\\259\\0":I
    iput-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->status:Landroid/widget/TextView;

    .line 260
    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->status:Landroid/widget/TextView;

    if-nez v5, :cond_bf

    const-string v5, "status"

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_c0

    :cond_bf
    move-object v4, v5

    :goto_c0
    check-cast v4, Landroid/view/View;

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, -0x2

    invoke-direct {v5, v7, v6, v10}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 261
    move-object v4, v1

    check-cast v4, Landroid/view/View;

    return-object v4
.end method

.method private final chartLabel(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .param p1, "c"    # Ljava/lang/String;

    .line 171
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_38

    goto :goto_31

    :sswitch_8
    const-string v0, "Month"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_31

    const-string v0, "This month"

    goto :goto_36

    :sswitch_13
    const-string v0, "Year"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_31

    const-string v0, "This year"

    goto :goto_36

    :sswitch_1e
    const-string v0, "Week"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_31

    const-string v0, "This week"

    goto :goto_36

    :sswitch_29
    const-string v0, "Current"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_32

    :cond_31
    :goto_31
    goto :goto_35

    :cond_32
    const-string v0, "Now"

    goto :goto_36

    :goto_35
    move-object v0, p1

    :goto_36
    return-object v0

    nop

    :sswitch_data_38
    .sparse-switch
        -0x599baaa7 -> :sswitch_29
        0x291414 -> :sswitch_1e
        0x29fc5d -> :sswitch_13
        0x4713260 -> :sswitch_8
    .end sparse-switch
.end method

.method private final chip(Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;)Landroid/widget/TextView;
    .registers 17
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "on"    # Z
    .param p3, "dropdown"    # Z
    .param p4, "onClick"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "ZZ",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroid/view/View;",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/widget/TextView;"
        }
    .end annotation

    .line 144
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz p3, :cond_10

    const-string v2, "  \u25be"

    goto :goto_12

    :cond_10
    const-string v2, ""

    :goto_12
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, -0x1

    if-eqz p2, :cond_28

    move v4, v8

    goto :goto_2f

    :cond_28
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v3

    move v4, v3

    :goto_2f
    const/16 v6, 0x10

    const/4 v7, 0x0

    const/high16 v3, 0x41400000    # 12.0f

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v0

    move-object v1, v0

    .local v1, "$this$chip_u24lambda_u246\\1":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 145
    .local v2, "$i$a$-apply-AudioBrowser$chip$1\\1\\144\\0":I
    const/high16 v3, 0x41300000    # 11.0f

    invoke-direct {p0, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v4

    const/high16 v5, 0x40a00000    # 5.0f

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v6

    invoke-direct {p0, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v3

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v5

    invoke-virtual {v1, v4, v6, v3, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 146
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v4, v3

    .local v4, "$this$chip_u24lambda_u246_u24lambda_u244\\2":Landroid/graphics/drawable/GradientDrawable;
    const/4 v5, 0x0

    .line 147
    .local v5, "$i$a$-apply-AudioBrowser$chip$1$1\\2\\146\\1":I
    const/high16 v6, -0x1000000

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    if-eqz p2, :cond_64

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getACCENT()I

    move-result v7

    goto :goto_7c

    :cond_64
    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getPANEL()I

    move-result v9

    sget-object v10, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getLIGHT()Z

    move-result v10

    if-eqz v10, :cond_74

    move v10, v6

    goto :goto_75

    :cond_74
    move v10, v8

    :goto_75
    const v11, 0x3da3d70a    # 0.08f

    invoke-virtual {v7, v9, v10, v11}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend(IIF)I

    move-result v7

    :goto_7c
    invoke-virtual {v4, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 148
    const/high16 v7, 0x41600000    # 14.0f

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v4, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 149
    if-nez p2, :cond_ac

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v7

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v10, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getPANEL()I

    move-result v10

    sget-object v11, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getLIGHT()Z

    move-result v11

    if-eqz v11, :cond_a2

    move v8, v6

    :cond_a2
    const v6, 0x3e3851ec    # 0.18f

    invoke-virtual {v9, v10, v8, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend(IIF)I

    move-result v6

    invoke-virtual {v4, v7, v6}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 150
    :cond_ac
    nop

    .line 146
    .end local v4    # "$this$chip_u24lambda_u246_u24lambda_u244\\2":Landroid/graphics/drawable/GradientDrawable;
    .end local v5    # "$i$a$-apply-AudioBrowser$chip$1$1\\2\\146\\1":I
    check-cast v3, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 151
    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda14;

    move-object/from16 v4, p4

    invoke-direct {v3, v4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda14;-><init>(Lkotlin/jvm/functions/Function1;)V

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 152
    nop

    .line 144
    .end local v1    # "$this$chip_u24lambda_u246\\1":Landroid/widget/TextView;
    .end local v2    # "$i$a$-apply-AudioBrowser$chip$1\\1\\144\\0":I
    nop

    .line 152
    return-object v0
.end method

.method static synthetic chip$default(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/TextView;
    .registers 7

    .line 143
    and-int/lit8 p5, p5, 0x4

    if-eqz p5, :cond_5

    const/4 p3, 0x0

    :cond_5
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip(Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object p0

    return-object p0
.end method

.method static final chip$lambda$6$lambda$5(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V
    .registers 2
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function1;
    .param p1, "p0"    # Landroid/view/View;

    .line 151
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private final dp(F)I
    .registers 5
    .param p1, "v"    # F

    .line 141
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    return v0
.end method

.method private final fmtClock(F)Ljava/lang/String;
    .registers 5
    .param p1, "sec"    # F

    .line 309
    float-to-int v0, p1

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v0

    .local v0, "s":I
    div-int/lit8 v1, v0, 0x3c

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    rem-int/lit8 v2, v0, 0x3c

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v1, v2}, [Ljava/lang/Object;

    move-result-object v1

    const/4 v2, 0x2

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%d:%02d"

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "format(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v1
.end method

.method private final fmtTime(I)Ljava/lang/String;
    .registers 4
    .param p1, "sec"    # I

    .line 308
    if-gtz p1, :cond_5

    const-string v0, ""

    goto :goto_25

    :cond_5
    div-int/lit8 v0, p1, 0x3c

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    rem-int/lit8 v1, p1, 0x3c

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x2

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%d:%02d"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_25
    return-object v0
.end method

.method private final loadMore()V
    .registers 7

    .line 271
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loading:Z

    if-nez v0, :cond_4a

    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->ended:Z

    if-nez v0, :cond_4a

    .line 272
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loading:Z

    .line 273
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->gen:I

    .line 274
    .local v0, "g":I
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->query()Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;

    move-result-object v1

    .line 275
    .local v1, "q":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->token:Ljava/lang/String;

    .line 276
    .local v2, "tok":Ljava/lang/String;
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->progress:Landroid/widget/ProgressBar;

    const/4 v4, 0x0

    if-nez v3, :cond_1e

    const-string v3, "progress"

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v3, v4

    :cond_1e
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->items:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_28

    const/4 v5, 0x0

    goto :goto_2a

    :cond_28
    const/16 v5, 0x8

    :goto_2a
    invoke-virtual {v3, v5}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 277
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->status:Landroid/widget/TextView;

    if-nez v3, :cond_37

    const-string v3, "status"

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_38

    :cond_37
    move-object v4, v3

    :goto_38
    const-string v3, ""

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 278
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->net:Ljava/util/concurrent/ExecutorService;

    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;

    invoke-direct {v4, p0, v1, v2, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;Ljava/lang/String;I)V

    invoke-interface {v3, v4}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 306
    return-void

    .line 271
    .end local v0    # "g":I
    .end local v1    # "q":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .end local v2    # "tok":Ljava/lang/String;
    :cond_4a
    return-void
.end method

.method static final loadMore$lambda$46(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;Ljava/lang/String;I)V
    .registers 14
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "$q"    # Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .param p2, "$tok"    # Ljava/lang/String;
    .param p3, "$g"    # I

    .line 279
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    move-object v1, v0

    .line 280
    .local v1, "result":Lkotlin/jvm/internal/Ref$ObjectRef;
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    move-object v2, v0

    .line 281
    .local v2, "err":Lkotlin/jvm/internal/Ref$ObjectRef;
    nop

    .line 282
    :try_start_d
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->useLegacy:Z
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_f} :catch_37

    if-eqz v0, :cond_22

    :try_start_11
    sget-object v0, Lcom/exampletest/mobilestudiotest/net/RobloxApi;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/RobloxApi;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;->getKeyword()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3, p2}, Lcom/exampletest/mobilestudiotest/net/RobloxApi;->searchAudioLegacy(Ljava/lang/String;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;

    move-result-object v0
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_1b} :catch_1e

    move-object v5, p1

    move-object v6, p2

    goto :goto_32

    .line 283
    :catch_1e
    move-exception v0

    move-object v5, p1

    move-object v6, p2

    goto :goto_3a

    .line 282
    :cond_22
    :try_start_22
    sget-object v3, Lcom/exampletest/mobilestudiotest/net/RobloxApi;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/RobloxApi;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v4
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_28} :catch_37

    const/16 v8, 0x8

    const/4 v9, 0x0

    const/4 v7, 0x0

    move-object v5, p1

    move-object v6, p2

    .end local p1    # "$q":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .end local p2    # "$tok":Ljava/lang/String;
    .local v5, "$q":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .local v6, "$tok":Ljava/lang/String;
    :try_start_2e
    invoke-static/range {v3 .. v9}, Lcom/exampletest/mobilestudiotest/net/RobloxApi;->searchAudio$default(Lcom/exampletest/mobilestudiotest/net/RobloxApi;Landroid/content/Context;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;Ljava/lang/String;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;

    move-result-object v0

    :goto_32
    iput-object v0, v1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_2e .. :try_end_34} :catch_35

    goto :goto_52

    .line 283
    :catch_35
    move-exception v0

    goto :goto_3a

    .end local v5    # "$q":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .end local v6    # "$tok":Ljava/lang/String;
    .restart local p1    # "$q":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .restart local p2    # "$tok":Ljava/lang/String;
    :catch_37
    move-exception v0

    move-object v5, p1

    move-object v6, p2

    .end local p1    # "$q":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .end local p2    # "$tok":Ljava/lang/String;
    .restart local v5    # "$q":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .restart local v6    # "$tok":Ljava/lang/String;
    :goto_3a
    move-object p1, v0

    .line 284
    .local p1, "e":Ljava/lang/Exception;
    iput-object p1, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 286
    iget-boolean p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->useLegacy:Z

    if-nez p2, :cond_52

    :try_start_41
    sget-object p2, Lcom/exampletest/mobilestudiotest/net/RobloxApi;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/RobloxApi;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;->getKeyword()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0, v6}, Lcom/exampletest/mobilestudiotest/net/RobloxApi;->searchAudioLegacy(Ljava/lang/String;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;

    move-result-object p2

    iput-object p2, v1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    const/4 p2, 0x1

    iput-boolean p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->useLegacy:Z
    :try_end_50
    .catch Ljava/lang/Exception; {:try_start_41 .. :try_end_50} :catch_51

    goto :goto_52

    :catch_51
    move-exception v0

    .line 288
    .end local p1    # "e":Ljava/lang/Exception;
    :cond_52
    :goto_52
    new-instance p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;

    invoke-direct {p1, p3, p0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;-><init>(ILcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->post(Ljava/lang/Runnable;)Z

    .line 305
    return-void
.end method

.method static final loadMore$lambda$46$lambda$45(ILcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V
    .registers 14
    .param p0, "$g"    # I
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p2, "$result"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p3, "$err"    # Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 289
    iget v0, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->gen:I

    if-eq p0, v0, :cond_5

    return-void

    .line 290
    :cond_5
    iget-object v0, p2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    const-string v1, ""

    const-string v2, "status"

    const-string v3, "progress"

    const/16 v4, 0x8

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez v0, :cond_57

    .line 291
    iput-boolean v5, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loading:Z

    iget-object v0, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->progress:Landroid/widget/ProgressBar;

    if-nez v0, :cond_1d

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v6

    :cond_1d
    invoke-virtual {v0, v4}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 292
    iget-object v0, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->items:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_56

    iget-object v0, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->status:Landroid/widget/TextView;

    if-nez v0, :cond_30

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_31

    :cond_30
    move-object v6, v0

    :goto_31
    iget-object v0, p3, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Exception;

    if-eqz v0, :cond_3e

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_3e

    move-object v1, v0

    :cond_3e
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Couldn\'t reach the Creator Store.\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 293
    :cond_56
    return-void

    .line 295
    :cond_57
    iget-object v0, p2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;

    .line 296
    .local v0, "result":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;
    iget-object v7, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->items:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    .line 297
    .local v7, "start":I
    iget-object v8, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->items:Ljava/util/ArrayList;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;->getItems()Ljava/util/List;

    move-result-object v9

    check-cast v9, Ljava/util/Collection;

    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 298
    iget-object v8, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->adapter:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;->getItems()Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    invoke-virtual {v8, v7, v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->notifyItemRangeInserted(II)V

    .line 299
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;->getNextToken()Ljava/lang/String;

    move-result-object v8

    iput-object v8, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->token:Ljava/lang/String;

    .line 300
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;->getNextToken()Ljava/lang/String;

    move-result-object v8

    if-eqz v8, :cond_94

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioPage;->getItems()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_94

    move v8, v5

    goto :goto_95

    :cond_94
    const/4 v8, 0x1

    :goto_95
    iput-boolean v8, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->ended:Z

    .line 301
    iput-boolean v5, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loading:Z

    .line 302
    iget-object v5, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->progress:Landroid/widget/ProgressBar;

    if-nez v5, :cond_a1

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v5, v6

    :cond_a1
    invoke-virtual {v5, v4}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 303
    iget-object v3, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->items:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_d8

    iget-object v3, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->status:Landroid/widget/TextView;

    if-nez v3, :cond_b4

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_b5

    :cond_b4
    move-object v6, v3

    :goto_b5
    iget v2, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengthIdx:I

    if-nez v2, :cond_be

    iget-object v2, p1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    if-nez v2, :cond_be

    goto :goto_c0

    :cond_be
    const-string v1, "\nTry removing a filter."

    :goto_c0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "No audio found."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v6, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 304
    :cond_d8
    return-void
.end method

.method private final menu(Landroid/view/View;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V
    .registers 16
    .param p1, "anchor"    # Landroid/view/View;
    .param p2, "labels"    # Ljava/util/List;
    .param p3, "pick"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 174
    new-instance v0, Landroid/widget/PopupMenu;

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "getContext(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->popupContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    .line 175
    .local v0, "m":Landroid/widget/PopupMenu;
    move-object v1, p2

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 412
    .local v2, "$i$f$forEachIndexed\\1\\175":I
    const/4 v3, 0x0

    .line 413
    .local v3, "index\\1":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3f

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "item\\1":Ljava/lang/Object;
    add-int/lit8 v6, v3, 0x1

    .end local v3    # "index\\1":I
    .local v6, "index\\1":I
    if-gez v3, :cond_2e

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_2e
    move-object v7, v5

    check-cast v7, Ljava/lang/String;

    .local v3, "i\\2":I
    .local v7, "s\\2":Ljava/lang/String;
    const/4 v8, 0x0

    .line 175
    .local v8, "$i$a$-forEachIndexed-AudioBrowser$menu$1\\2\\413\\0":I
    invoke-virtual {v0}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v9

    const/4 v10, 0x0

    move-object v11, v7

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v9, v10, v3, v3, v11}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 413
    .end local v3    # "i\\2":I
    .end local v7    # "s\\2":Ljava/lang/String;
    .end local v8    # "$i$a$-forEachIndexed-AudioBrowser$menu$1\\2\\413\\0":I
    move v3, v6

    .end local v5    # "item\\1":Ljava/lang/Object;
    goto :goto_1d

    .line 414
    .end local v6    # "index\\1":I
    .local v3, "index\\1":I
    :cond_3f
    nop

    .line 176
    .end local v1    # "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEachIndexed\\1\\175":I
    .end local v3    # "index\\1":I
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda21;

    invoke-direct {v1, p3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda21;-><init>(Lkotlin/jvm/functions/Function1;)V

    invoke-virtual {v0, v1}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    .line 177
    invoke-virtual {v0}, Landroid/widget/PopupMenu;->show()V

    .line 178
    return-void
.end method

.method static final menu$lambda$22(Lkotlin/jvm/functions/Function1;Landroid/view/MenuItem;)Z
    .registers 3
    .param p0, "$pick"    # Lkotlin/jvm/functions/Function1;
    .param p1, "it"    # Landroid/view/MenuItem;

    .line 176
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x1

    return v0
.end method

.method static final previewListener$lambda$2(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 129
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda3;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->post(Ljava/lang/Runnable;)Z

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final previewListener$lambda$2$lambda$1(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 129
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->draggingId:Ljava/lang/Long;

    if-nez v0, :cond_9

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->adapter:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->notifyDataSetChanged()V

    :cond_9
    return-void
.end method

.method private final query()Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;
    .registers 19

    .line 265
    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengths:Ljava/util/List;

    iget v2, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->lengthIdx:I

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkotlin/Pair;

    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkotlin/Pair;

    invoke-virtual {v1}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v7

    .local v7, "mn":I
    invoke-virtual {v1}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v1

    move-object v8, v1

    check-cast v8, Ljava/lang/Integer;

    .line 266
    .local v8, "mx":Ljava/lang/Integer;
    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->keyword:Ljava/lang/String;

    .line 409
    move-object v3, v2

    .local v3, "it\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 266
    .local v4, "$i$a$-takeIf-AudioBrowser$query$words$1\\1\\266\\0":I
    move-object v5, v3

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v5}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v5

    .end local v3    # "it\\1":Ljava/lang/String;
    .end local v4    # "$i$a$-takeIf-AudioBrowser$query$words$1\\1\\266\\0":I
    if-eqz v5, :cond_34

    const/4 v2, 0x0

    :cond_34
    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    aput-object v3, v1, v2

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    move-object v9, v1

    check-cast v9, Ljava/lang/Iterable;

    const-string v1, " "

    move-object v10, v1

    check-cast v10, Ljava/lang/CharSequence;

    const/16 v16, 0x3e

    const/16 v17, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static/range {v9 .. v17}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .line 267
    .local v4, "words":Ljava/lang/String;
    new-instance v3, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sort:Ljava/lang/String;

    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    const/16 v11, 0x40

    const/4 v10, 0x0

    invoke-direct/range {v3 .. v12}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v3
.end method

.method private final showDiscover()V
    .registers 18

    .line 188
    move-object/from16 v0, p0

    const/4 v6, 0x1

    iput-boolean v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->discover:Z

    .line 189
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters()V

    .line 190
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->content:Landroid/widget/FrameLayout;

    invoke-virtual {v1}, Landroid/widget/FrameLayout;->removeAllViews()V

    .line 191
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 409
    .local v2, "$this$showDiscover_u24lambda_u2423\\1":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 191
    .local v3, "$i$a$-apply-AudioBrowser$showDiscover$box$1\\1\\191\\0":I
    invoke-virtual {v2, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v4, 0x41200000    # 10.0f

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v5

    const/high16 v7, 0x40800000    # 4.0f

    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v7

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v4

    const/high16 v8, 0x41800000    # 16.0f

    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v8

    invoke-virtual {v2, v5, v7, v4, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .end local v2    # "$this$showDiscover_u24lambda_u2423\\1":Landroid/widget/LinearLayout;
    .end local v3    # "$i$a$-apply-AudioBrowser$showDiscover$box$1\\1\\191\\0":I
    move-object v7, v1

    .line 199
    .local v7, "box":Landroid/widget/LinearLayout;
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 409
    .local v2, "$this$showDiscover_u24lambda_u2426\\2":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 199
    .local v3, "$i$a$-apply-AudioBrowser$showDiscover$cards$1\\2\\199\\0":I
    const/4 v8, 0x0

    invoke-virtual {v2, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 211
    .end local v2    # "$this$showDiscover_u24lambda_u2426\\2":Landroid/widget/LinearLayout;
    .end local v3    # "$i$a$-apply-AudioBrowser$showDiscover$cards$1\\2\\199\\0":I
    .local v1, "cards":Landroid/widget/LinearLayout;
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda15;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda15;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    const-string v2, "Music"

    const-string v3, "Licensed tracks for your experience"

    const v4, -0x84c01c

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$card(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/functions/Function0;)V

    .line 212
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda16;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda16;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    const-string v2, "Sound Effects"

    const-string v3, "UI, impacts, ambience and more"

    const v4, -0xf37092

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$card(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/functions/Function0;)V

    .line 213
    move-object v2, v1

    check-cast v2, Landroid/view/View;

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v13, 0x4

    const/4 v14, 0x0

    const/4 v10, -0x1

    const/4 v11, -0x2

    const/4 v12, 0x0

    invoke-static/range {v9 .. v14}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    .line 409
    move-object v4, v3

    .local v4, "$this$showDiscover_u24lambda_u2434\\3":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v5, 0x0

    .line 213
    .local v5, "$i$a$-apply-AudioBrowser$showDiscover$3\\3\\213\\0":I
    const/high16 v9, 0x40c00000    # 6.0f

    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v9

    iput v9, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .end local v4    # "$this$showDiscover_u24lambda_u2434\\3":Landroid/widget/LinearLayout$LayoutParams;
    .end local v5    # "$i$a$-apply-AudioBrowser$showDiscover$3\\3\\213\\0":I
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v7, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 214
    const-string v2, "Top charts"

    invoke-static {v7, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$section(Landroid/widget/LinearLayout;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)V

    .line 215
    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Now"

    aput-object v3, v2, v8

    const-string v3, "This week"

    aput-object v3, v2, v6

    const/4 v3, 0x2

    const-string v4, "This month"

    aput-object v4, v2, v3

    const/4 v3, 0x3

    const-string v4, "This year"

    aput-object v4, v2, v3

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda17;

    invoke-direct {v3, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda17;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-static {v0, v7, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$flow(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 219
    const-string v2, "Genres"

    invoke-static {v7, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$section(Landroid/widget/LinearLayout;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)V

    .line 220
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->genres:Ljava/util/List;

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda18;

    invoke-direct {v3, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda18;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-static {v0, v7, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$flow(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 221
    const-string v2, "Vibes"

    invoke-static {v7, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$section(Landroid/widget/LinearLayout;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)V

    .line 222
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->vibes:Ljava/util/List;

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda19;

    invoke-direct {v3, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda19;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-static {v0, v7, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$flow(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 223
    const-string v2, "Sound effects"

    invoke-static {v7, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$section(Landroid/widget/LinearLayout;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)V

    .line 224
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->sfx:Ljava/util/List;

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda20;

    invoke-direct {v3, v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda20;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    invoke-static {v0, v7, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$flow(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 225
    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v10

    const-string v2, "getContext(...)"

    invoke-static {v10, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v13

    const/16 v15, 0x10

    const/16 v16, 0x0

    const-string v11, "Audio comes from the Roblox Creator Store. Previewing and playing audio needs a signed-in account (Roblox only serves audio files to signed-in users)."

    const/high16 v12, 0x41300000    # 11.0f

    const/4 v14, 0x0

    invoke-static/range {v9 .. v16}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v2

    move-object v3, v2

    .local v3, "$this$showDiscover_u24lambda_u2439\\4":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 226
    .local v4, "$i$a$-apply-AudioBrowser$showDiscover$8\\4\\225\\0":I
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/high16 v5, 0x41600000    # 14.0f

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v5

    invoke-virtual {v3, v8, v5, v8, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 227
    nop

    .line 225
    .end local v3    # "$this$showDiscover_u24lambda_u2439\\4":Landroid/widget/TextView;
    .end local v4    # "$i$a$-apply-AudioBrowser$showDiscover$8\\4\\225\\0":I
    check-cast v2, Landroid/view/View;

    invoke-virtual {v7, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 228
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->content:Landroid/widget/FrameLayout;

    new-instance v3, Landroid/widget/ScrollView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 409
    move-object v4, v3

    .local v4, "$this$showDiscover_u24lambda_u2440\\5":Landroid/widget/ScrollView;
    const/4 v5, 0x0

    .line 228
    .local v5, "$i$a$-apply-AudioBrowser$showDiscover$9\\5\\228\\0":I
    move-object v6, v7

    check-cast v6, Landroid/view/View;

    invoke-virtual {v4, v6}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .end local v4    # "$this$showDiscover_u24lambda_u2440\\5":Landroid/widget/ScrollView;
    .end local v5    # "$i$a$-apply-AudioBrowser$showDiscover$9\\5\\228\\0":I
    check-cast v3, Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 229
    return-void
.end method

.method private static final showDiscover$card(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/functions/Function0;)V
    .registers 23
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "cards"    # Landroid/widget/LinearLayout;
    .param p2, "label"    # Ljava/lang/String;
    .param p3, "sub"    # Ljava/lang/String;
    .param p4, "color"    # I
    .param p5, "onClick"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;",
            "Landroid/widget/LinearLayout;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "I",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 201
    move-object/from16 v0, p0

    move/from16 v1, p4

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$showDiscover_u24card_u24lambda_u2429\\1":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 202
    .local v4, "$i$a$-apply-AudioBrowser$showDiscover$card$c$1\\1\\201\\0":I
    const/4 v5, 0x1

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 203
    const/high16 v5, 0x41400000    # 12.0f

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v6

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v7

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v8

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v5

    invoke-virtual {v3, v6, v7, v8, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 204
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    sget-object v6, Landroid/graphics/drawable/GradientDrawable$Orientation;->TL_BR:Landroid/graphics/drawable/GradientDrawable$Orientation;

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v8, -0x1000000

    const v9, 0x3eb33333    # 0.35f

    invoke-virtual {v7, v1, v8, v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend(IIF)I

    move-result v7

    filled-new-array {v1, v7}, [I

    move-result-object v7

    invoke-direct {v5, v6, v7}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 409
    move-object v6, v5

    .local v6, "$this$showDiscover_u24card_u24lambda_u2429_u24lambda_u2427\\2":Landroid/graphics/drawable/GradientDrawable;
    const/4 v7, 0x0

    .line 204
    .local v7, "$i$a$-apply-AudioBrowser$showDiscover$card$c$1$1\\2\\204\\1":I
    const/high16 v8, 0x41000000    # 8.0f

    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v9

    int-to-float v9, v9

    invoke-virtual {v6, v9}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v6    # "$this$showDiscover_u24card_u24lambda_u2429_u24lambda_u2427\\2":Landroid/graphics/drawable/GradientDrawable;
    .end local v7    # "$i$a$-apply-AudioBrowser$showDiscover$card$c$1$1\\2\\204\\1":I
    check-cast v5, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 205
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda2;

    move-object/from16 v6, p5

    invoke-direct {v5, v6}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda2;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 206
    nop

    .line 201
    .end local v3    # "$this$showDiscover_u24card_u24lambda_u2429\\1":Landroid/widget/LinearLayout;
    .end local v4    # "$i$a$-apply-AudioBrowser$showDiscover$card$c$1\\1\\201\\0":I
    nop

    .line 207
    .local v2, "c":Landroid/widget/LinearLayout;
    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v10

    const-string v3, "getContext(...)"

    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v13, -0x1

    const/4 v14, 0x1

    const/high16 v12, 0x41700000    # 15.0f

    move-object/from16 v11, p2

    invoke-virtual/range {v9 .. v14}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v4

    check-cast v4, Landroid/view/View;

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 208
    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v15, 0x10

    const/16 v16, 0x0

    const/high16 v12, 0x41300000    # 11.0f

    const v13, -0x22000001

    const/4 v14, 0x0

    move-object/from16 v11, p3

    invoke-static/range {v9 .. v16}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v3

    .line 409
    move-object v4, v3

    .local v4, "$this$showDiscover_u24card_u24lambda_u2430\\3":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 208
    .local v5, "$i$a$-apply-AudioBrowser$showDiscover$card$1\\3\\208\\0":I
    const/4 v7, 0x0

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setSingleLine(Z)V

    .end local v4    # "$this$showDiscover_u24card_u24lambda_u2430\\3":Landroid/widget/TextView;
    .end local v5    # "$i$a$-apply-AudioBrowser$showDiscover$card$1\\3\\208\\0":I
    check-cast v3, Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 209
    move-object v3, v2

    check-cast v3, Landroid/view/View;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v5, -0x2

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-virtual {v4, v7, v5, v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    .line 409
    move-object v5, v4

    .local v5, "$this$showDiscover_u24card_u24lambda_u2431\\4":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v7, 0x0

    .line 209
    .local v7, "$i$a$-apply-AudioBrowser$showDiscover$card$2\\4\\209\\0":I
    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v8

    iput v8, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v5    # "$this$showDiscover_u24card_u24lambda_u2431\\4":Landroid/widget/LinearLayout$LayoutParams;
    .end local v7    # "$i$a$-apply-AudioBrowser$showDiscover$card$2\\4\\209\\0":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    move-object/from16 v5, p1

    invoke-virtual {v5, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 210
    return-void
.end method

.method static final showDiscover$card$lambda$29$lambda$28(Lkotlin/jvm/functions/Function0;Landroid/view/View;)V
    .registers 2
    .param p0, "$onClick"    # Lkotlin/jvm/functions/Function0;
    .param p1, "it"    # Landroid/view/View;

    .line 205
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private static final showDiscover$flow(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V
    .registers 14
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "box"    # Landroid/widget/LinearLayout;
    .param p2, "labels"    # Ljava/util/List;
    .param p3, "onPick"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;",
            "Landroid/widget/LinearLayout;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 194
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/FlowLayout;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/FlowLayout;-><init>(Landroid/content/Context;)V

    .line 195
    .local v0, "f":Lcom/exampletest/mobilestudiotest/ui/FlowLayout;
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_12
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_34

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v4, v2

    check-cast v4, Ljava/lang/String;

    .local v4, "l":Ljava/lang/String;
    new-instance v7, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda1;

    invoke-direct {v7, p3, v4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda1;-><init>(Lkotlin/jvm/functions/Function1;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v3, p0

    .end local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .local v3, "this$0":Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    invoke-static/range {v3 .. v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip$default(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;ZZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/FlowLayout;->addView(Landroid/view/View;)V

    move-object p0, v3

    .end local v4    # "l":Ljava/lang/String;
    goto :goto_12

    .line 196
    .end local v3    # "this$0":Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .restart local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    :cond_34
    move-object v3, p0

    .end local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .restart local v3    # "this$0":Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    move-object p0, v0

    check-cast p0, Landroid/view/View;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p1, p0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 197
    return-void
.end method

.method static final showDiscover$flow$lambda$25(Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/view/View;)Lkotlin/Unit;
    .registers 4
    .param p0, "$onPick"    # Lkotlin/jvm/functions/Function1;
    .param p1, "$l"    # Ljava/lang/String;
    .param p2, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showDiscover$lambda$32(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 211
    const-string v0, "Music"

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showDiscover$lambda$33(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 212
    const-string v0, "SoundEffect"

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showDiscover$lambda$35(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "l"    # Ljava/lang/String;

    const-string v0, "l"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 216
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_40

    goto :goto_2b

    :sswitch_d
    const-string v0, "This week"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2b

    const-string v0, "Week"

    goto :goto_31

    :sswitch_18
    const-string v0, "Now"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2b

    const-string v0, "Current"

    goto :goto_31

    :sswitch_23
    const-string v0, "This month"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2c

    :cond_2b
    :goto_2b
    goto :goto_2f

    :cond_2c
    const-string v0, "Month"

    goto :goto_31

    :goto_2f
    const-string v0, "Year"

    :goto_31
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    .line 217
    const-string v0, "Music"

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    .line 218
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    :sswitch_data_40
    .sparse-switch
        -0x828d62 -> :sswitch_23
        0x132b6 -> :sswitch_18
        0x5294d416 -> :sswitch_d
    .end sparse-switch
.end method

.method static final showDiscover$lambda$36(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "g"    # Ljava/lang/String;

    const-string v0, "g"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    const-string v0, "Music"

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showDiscover$lambda$37(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "v"    # Ljava/lang/String;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 222
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    const-string v0, "Music"

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showDiscover$lambda$38(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 224
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    const-string v0, "SoundEffect"

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final showDiscover$section(Landroid/widget/LinearLayout;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)V
    .registers 9
    .param p0, "box"    # Landroid/widget/LinearLayout;
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p2, "title"    # Ljava/lang/String;

    .line 192
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v4

    const/4 v5, 0x1

    const/high16 v3, 0x41500000    # 13.0f

    move-object v2, p2

    .end local p2    # "title":Ljava/lang/String;
    .local v2, "title":Ljava/lang/String;
    invoke-virtual/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p2

    .line 409
    move-object v0, p2

    .local v0, "$this$showDiscover_u24section_u24lambda_u2424\\1":Landroid/widget/TextView;
    const/4 v1, 0x0

    .line 192
    .local v1, "$i$a$-apply-AudioBrowser$showDiscover$section$1\\1\\192\\0":I
    const/high16 v3, 0x41400000    # 12.0f

    invoke-direct {p1, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v3

    const/high16 v4, 0x40c00000    # 6.0f

    invoke-direct {p1, v4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->dp(F)I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v0, v5, v3, v5, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    .end local v0    # "$this$showDiscover_u24section_u24lambda_u2424\\1":Landroid/widget/TextView;
    .end local v1    # "$i$a$-apply-AudioBrowser$showDiscover$section$1\\1\\192\\0":I
    check-cast p2, Landroid/view/View;

    invoke-virtual {p0, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private final showResults()V
    .registers 6

    .line 234
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->discover:Z

    .line 235
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters()V

    .line 236
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->content:Landroid/widget/FrameLayout;

    invoke-virtual {v1}, Landroid/widget/FrameLayout;->removeAllViews()V

    .line 237
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->results:Landroid/view/View;

    if-nez v1, :cond_17

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildResults()Landroid/view/View;

    move-result-object v1

    move-object v2, v1

    .line 409
    .local v2, "it\\1":Landroid/view/View;
    const/4 v3, 0x0

    .line 237
    .local v3, "$i$a$-also-AudioBrowser$showResults$v$1\\1\\237\\0":I
    iput-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->results:Landroid/view/View;

    .line 238
    .end local v2    # "it\\1":Landroid/view/View;
    .end local v3    # "$i$a$-also-AudioBrowser$showResults$v$1\\1\\237\\0":I
    .local v1, "v":Landroid/view/View;
    :cond_17
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    instance-of v3, v2, Landroid/view/ViewGroup;

    const/4 v4, 0x0

    if-eqz v3, :cond_23

    check-cast v2, Landroid/view/ViewGroup;

    goto :goto_24

    :cond_23
    move-object v2, v4

    :goto_24
    if-eqz v2, :cond_29

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 239
    :cond_29
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->content:Landroid/widget/FrameLayout;

    invoke-virtual {v2, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 240
    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->gen:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->gen:I

    .line 241
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->items:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    iput-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->token:Ljava/lang/String;

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->ended:Z

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loading:Z

    .line 242
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->adapter:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->notifyDataSetChanged()V

    .line 243
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loadMore()V

    .line 244
    return-void
.end method


# virtual methods
.method public final getKeyword()Ljava/lang/String;
    .registers 2

    .line 112
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->keyword:Ljava/lang/String;

    return-object v0
.end method

.method protected onAttachedToWindow()V
    .registers 3

    .line 138
    invoke-super {p0}, Landroid/widget/LinearLayout;->onAttachedToWindow()V

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->getPreviewListeners()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->previewListener:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 3

    .line 139
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->getPreviewListeners()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->previewListener:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    invoke-super {p0}, Landroid/widget/LinearLayout;->onDetachedFromWindow()V

    return-void
.end method

.method public final search(Ljava/lang/String;)V
    .registers 4
    .param p1, "q"    # Ljava/lang/String;

    const-string v0, "q"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 181
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->keyword:Ljava/lang/String;

    .line 182
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->keyword:Ljava/lang/String;

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_1e

    const/4 v0, 0x1

    goto :goto_1f

    :cond_1e
    const/4 v0, 0x0

    :goto_1f
    if-eqz v0, :cond_37

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->tag:Ljava/lang/String;

    if-nez v0, :cond_37

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chart:Ljava/lang/String;

    const-string v1, "None"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_37

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->type:Ljava/lang/String;

    if-nez v0, :cond_37

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover()V

    goto :goto_3a

    :cond_37
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showResults()V

    .line 183
    :goto_3a
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser.Adapter (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter)
.class final Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "AudioBrowser.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Adapter"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
        "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAudioBrowser.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AudioBrowser.kt\ncom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,408:1\n1#2:409\n774#3:410\n865#3,2:411\n*S KotlinDebug\n*F\n+ 1 AudioBrowser.kt\ncom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter\n*L\n363#1:410\n363#1:411,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0003\u0008\u0082\u0004\u0018\u00002\u000c\u0012\u0008\u0012\u00060\u0002R\u00020\u00030\u0001B\u0007\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0008\u0010\u0006\u001a\u00020\u0007H\u0016J\u001c\u0010\u0008\u001a\u00060\u0002R\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0007H\u0016J\u001c\u0010\u000c\u001a\u00020\r2\n\u0010\u000e\u001a\u00060\u0002R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0007H\u0016\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;",
        "Landroidx/recyclerview/widget/RecyclerView$Adapter;",
        "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;",
        "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V",
        "getItemCount",
        "",
        "onCreateViewHolder",
        "parent",
        "Landroid/view/ViewGroup;",
        "viewType",
        "onBindViewHolder",
        "",
        "h",
        "position",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 315
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    return-void
.end method

.method static final onBindViewHolder$lambda$18(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "$it"    # Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    .line 396
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$getNeedSignIn$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/jvm/functions/Function1;

    move-result-object p2

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda2;

    invoke-direct {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V

    invoke-interface {p2, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final onBindViewHolder$lambda$18$lambda$17(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)Lkotlin/Unit;
    .registers 7
    .param p0, "$it"    # Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    .line 396
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getId()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x0

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview$default(Lcom/exampletest/mobilestudiotest/audio/AudioEngine;JFILjava/lang/Object;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final onBindViewHolder$lambda$19(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "$it"    # Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    .line 397
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$getOnInsert$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/jvm/functions/Function1;

    move-result-object p2

    invoke-interface {p2, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final onBindViewHolder$lambda$21(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "$it"    # Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    .line 398
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$getNeedSignIn$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/jvm/functions/Function1;

    move-result-object p2

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda0;

    invoke-direct {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V

    invoke-interface {p2, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final onBindViewHolder$lambda$21$lambda$20(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)Lkotlin/Unit;
    .registers 7
    .param p0, "$it"    # Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    .line 398
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getId()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x0

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview$default(Lcom/exampletest/mobilestudiotest/audio/AudioEngine;JFILjava/lang/Object;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final onBindViewHolder$lambda$26(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)Z
    .registers 16
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "$label"    # Ljava/lang/String;
    .param p2, "$by"    # Ljava/lang/String;
    .param p3, "$kind"    # Ljava/lang/String;
    .param p4, "$it"    # Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    .line 400
    sget-object p5, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Dialogs;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "getContext(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p5, v0}, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->themed(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p5

    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p5, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p5

    .line 401
    move-object v0, p2

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_23

    .line 409
    const/4 v0, 0x0

    .line 401
    .local v0, "$i$a$-ifBlank-AudioBrowser$Adapter$onBindViewHolder$6$1\\1\\401\\0":I
    nop

    .end local v0    # "$i$a$-ifBlank-AudioBrowser$Adapter$onBindViewHolder$6$1\\1\\401\\0":I
    const-string v0, "Unknown"

    :cond_23
    move-object v1, p3

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_30

    .line 409
    const/4 v1, 0x0

    .line 401
    .local v1, "$i$a$-ifBlank-AudioBrowser$Adapter$onBindViewHolder$6$2\\2\\401\\0":I
    nop

    .end local v1    # "$i$a$-ifBlank-AudioBrowser$Adapter$onBindViewHolder$6$2\\2\\401\\0":I
    const-string v1, "Audio"

    :cond_30
    invoke-virtual {p4}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getSeconds()I

    move-result v2

    invoke-static {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$fmtTime(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const/4 v4, 0x1

    if-nez v3, :cond_43

    move v3, v4

    goto :goto_44

    :cond_43
    const/4 v3, 0x0

    :goto_44
    if-eqz v3, :cond_4a

    .line 409
    const/4 v2, 0x0

    .line 401
    .local v2, "$i$a$-ifEmpty-AudioBrowser$Adapter$onBindViewHolder$6$3\\3\\401\\0":I
    nop

    .end local v2    # "$i$a$-ifEmpty-AudioBrowser$Adapter$onBindViewHolder$6$3\\3\\401\\0":I
    const-string v2, "?"

    :cond_4a
    invoke-virtual {p4}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getCreator()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p4}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getVerified()Z

    move-result v5

    if-eqz v5, :cond_57

    const-string v5, " (verified)"

    goto :goto_59

    :cond_57
    const-string v5, ""

    :goto_59
    invoke-virtual {p4}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getId()J

    move-result-wide v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Artist: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, "\nType: "

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\nLength: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\nCreator: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\nAsset ID: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    .line 400
    invoke-virtual {p5, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p5

    .line 402
    const-string v0, "Insert"

    check-cast v0, Ljava/lang/CharSequence;

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, p4}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda7;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V

    invoke-virtual {p5, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p5

    const-string v0, "Close"

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v1, 0x0

    invoke-virtual {p5, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p5

    invoke-virtual {p5}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 403
    return v4
.end method

.method static final onBindViewHolder$lambda$26$lambda$25(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/content/DialogInterface;I)V
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p1, "$it"    # Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    .line 402
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$getOnInsert$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/jvm/functions/Function1;

    move-result-object p2

    invoke-interface {p2, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final onCreateViewHolder$lambda$8(Landroid/view/View;)Lkotlin/Unit;
    .registers 2
    .param p0, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 337
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public getItemCount()I
    .registers 2

    .line 316
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$getItems$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .registers 4
    .param p1, "p0"    # Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .param p2, "p1"    # I

    .line 315
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;

    invoke-virtual {p0, v0, p2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;I)V

    return-void
.end method

.method public onBindViewHolder(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;I)V
    .registers 29
    .param p1, "h"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;
    .param p2, "position"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "h"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 358
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$getItems$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Ljava/util/ArrayList;

    move-result-object v2

    move/from16 v3, p2

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const-string v4, "get(...)"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v10, v2

    check-cast v10, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    .line 359
    .local v10, "it":Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getTitle()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2e

    .line 409
    const/4 v2, 0x0

    .line 359
    .local v2, "$i$a$-ifBlank-AudioBrowser$Adapter$onBindViewHolder$label$1\\1\\359\\0":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getName()Ljava/lang/String;

    move-result-object v2

    .end local v2    # "$i$a$-ifBlank-AudioBrowser$Adapter$onBindViewHolder$label$1\\1\\359\\0":I
    :cond_2e
    move-object v7, v2

    check-cast v7, Ljava/lang/String;

    .line 360
    .local v7, "label":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getTitle()Landroid/widget/TextView;

    move-result-object v2

    move-object v4, v7

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 361
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getType()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    const-string v4, "Music"

    move-object v5, v4

    check-cast v5, Ljava/lang/CharSequence;

    const/4 v6, 0x1

    invoke-static {v2, v5, v6}, Lkotlin/text/StringsKt;->contains(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v2

    if-eqz v2, :cond_4f

    :goto_4d
    move-object v9, v4

    goto :goto_65

    :cond_4f
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getType()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    const-string v4, "Sound"

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v2, v4, v6}, Lkotlin/text/StringsKt;->contains(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v2

    if-eqz v2, :cond_62

    const-string v4, "Sound effect"

    goto :goto_4d

    :cond_62
    const-string v4, ""

    goto :goto_4d

    .line 362
    .local v9, "kind":Ljava/lang/String;
    :goto_65
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getArtist()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_76

    .line 409
    const/4 v2, 0x0

    .line 362
    .local v2, "$i$a$-ifBlank-AudioBrowser$Adapter$onBindViewHolder$by$1\\2\\362\\0":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getCreator()Ljava/lang/String;

    move-result-object v2

    .end local v2    # "$i$a$-ifBlank-AudioBrowser$Adapter$onBindViewHolder$by$1\\2\\362\\0":I
    :cond_76
    move-object v8, v2

    check-cast v8, Ljava/lang/String;

    .line 363
    .local v8, "by":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSub()Landroid/widget/TextView;

    move-result-object v2

    const/4 v4, 0x3

    new-array v4, v4, [Ljava/lang/String;

    const/4 v5, 0x0

    aput-object v8, v4, v5

    aput-object v9, v4, v6

    const/4 v11, 0x2

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getAlbum()Ljava/lang/String;

    move-result-object v12

    aput-object v12, v4, v11

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\3":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 410
    .local v11, "$i$f$filter\\3\\363":I
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    check-cast v12, Ljava/util/Collection;

    .local v12, "destination\\4":Ljava/util/Collection;
    move-object v13, v4

    .local v13, "$this$filterTo\\4":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 411
    .local v14, "$i$f$filterTo\\4\\410":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_a0
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_bf

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\4":Ljava/lang/Object;
    move-object/from16 v17, v6

    check-cast v17, Ljava/lang/String;

    .local v17, "s\\5":Ljava/lang/String;
    const/16 v18, 0x0

    .line 363
    .local v18, "$i$a$-filter-AudioBrowser$Adapter$onBindViewHolder$1\\5\\411\\0":I
    move-object/from16 v19, v17

    check-cast v19, Ljava/lang/CharSequence;

    invoke-static/range {v19 .. v19}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v19

    .line 411
    .end local v17    # "s\\5":Ljava/lang/String;
    .end local v18    # "$i$a$-filter-AudioBrowser$Adapter$onBindViewHolder$1\\5\\411\\0":I
    if-nez v19, :cond_bd

    invoke-interface {v12, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_bd
    const/4 v6, 0x1

    goto :goto_a0

    .line 412
    .end local v6    # "element\\4":Ljava/lang/Object;
    :cond_bf
    nop

    .end local v12    # "destination\\4":Ljava/util/Collection;
    .end local v13    # "$this$filterTo\\4":Ljava/lang/Iterable;
    .end local v14    # "$i$f$filterTo\\4\\410":I
    move-object v6, v12

    check-cast v6, Ljava/util/List;

    .line 410
    nop

    .end local v4    # "$this$filter\\3":Ljava/lang/Iterable;
    .end local v11    # "$i$f$filter\\3\\363":I
    move-object/from16 v17, v6

    check-cast v17, Ljava/lang/Iterable;

    .line 363
    const-string v4, "  \u00b7  "

    move-object/from16 v18, v4

    check-cast v18, Ljava/lang/CharSequence;

    const/16 v24, 0x3e

    const/16 v25, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    invoke-static/range {v17 .. v25}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 364
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getDur()Landroid/widget/TextView;

    move-result-object v2

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getSeconds()I

    move-result v6

    invoke-static {v4, v6}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$fmtTime(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 365
    sget-object v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->getPreview()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    move-result-object v2

    .line 366
    .local v2, "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    if-eqz v2, :cond_10e

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getId()J

    move-result-wide v11

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getId()J

    move-result-wide v13

    cmp-long v4, v11, v13

    if-nez v4, :cond_10e

    const/4 v4, 0x1

    goto :goto_10f

    :cond_10e
    move v4, v5

    .line 367
    .local v4, "mine":Z
    :goto_10f
    if-eqz v4, :cond_11e

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v6

    sget-object v11, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-ne v6, v11, :cond_11e

    const/4 v6, 0x1

    goto :goto_11f

    :cond_11e
    move v6, v5

    :goto_11f
    move v11, v6

    .line 368
    .local v11, "playing":Z
    if-eqz v4, :cond_12f

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v6

    sget-object v12, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->LOADING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-ne v6, v12, :cond_12f

    const/4 v6, 0x1

    goto :goto_130

    :cond_12f
    move v6, v5

    :goto_130
    move v12, v6

    .line 369
    .local v12, "load":Z
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getGlyph()Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;

    move-result-object v6

    invoke-virtual {v6, v11, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;->set(ZZ)V

    .line 370
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getPlay()Landroid/widget/ImageView;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/ImageView;->invalidate()V

    .line 371
    if-eqz v4, :cond_1e4

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v6

    sget-object v13, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-eq v6, v13, :cond_1e4

    .line 372
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSeekRow()Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 373
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getLength()F

    move-result v6

    const/4 v13, 0x0

    cmpl-float v6, v6, v13

    if-lez v6, :cond_161

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getLength()F

    move-result v6

    goto :goto_166

    :cond_161
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getSeconds()I

    move-result v6

    int-to-float v6, v6

    .line 374
    .local v6, "len":F
    :goto_166
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getLength()F

    move-result v14

    cmpl-float v13, v14, v13

    if-lez v13, :cond_16f

    const/4 v5, 0x1

    .line 375
    .local v5, "ready":Z
    :cond_16f
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSeek()Landroid/widget/SeekBar;

    move-result-object v13

    invoke-virtual {v13, v5}, Landroid/widget/SeekBar;->setEnabled(Z)V

    .line 376
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSeek()Landroid/widget/SeekBar;

    move-result-object v13

    const/high16 v14, 0x41200000    # 10.0f

    mul-float v15, v6, v14

    float-to-int v15, v15

    move/from16 v17, v14

    const/4 v14, 0x1

    invoke-static {v15, v14}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v14

    invoke-virtual {v13, v14}, Landroid/widget/SeekBar;->setMax(I)V

    .line 377
    iget-object v13, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v13}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$getDraggingId$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Ljava/lang/Long;

    move-result-object v13

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getId()J

    move-result-wide v14

    if-eqz v13, :cond_19d

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v18

    cmp-long v13, v18, v14

    if-eqz v13, :cond_1be

    .line 378
    :cond_19d
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSeek()Landroid/widget/SeekBar;

    move-result-object v13

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getPosition()F

    move-result v14

    mul-float v14, v14, v17

    float-to-int v14, v14

    invoke-virtual {v13, v14}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 379
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getElapsed()Landroid/widget/TextView;

    move-result-object v13

    iget-object v14, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getPosition()F

    move-result v15

    invoke-static {v14, v15}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$fmtClock(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)Ljava/lang/String;

    move-result-object v14

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 381
    :cond_1be
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getTotal()Landroid/widget/TextView;

    move-result-object v13

    iget-object v14, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v14, v6}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$fmtClock(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)Ljava/lang/String;

    move-result-object v14

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 382
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;->getId()J

    move-result-wide v13

    .line 383
    .local v13, "id":J
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSeek()Landroid/widget/SeekBar;

    move-result-object v15

    move-object/from16 v16, v2

    .end local v2    # "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .local v16, "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-direct {v2, v1, v3, v13, v14}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;J)V

    check-cast v2, Landroid/widget/SeekBar$OnSeekBarChangeListener;

    invoke-virtual {v15, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .end local v5    # "ready":Z
    .end local v6    # "len":F
    .end local v13    # "id":J
    goto :goto_1f7

    .line 371
    .end local v16    # "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .restart local v2    # "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    :cond_1e4
    move-object/from16 v16, v2

    .line 392
    .end local v2    # "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .restart local v16    # "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSeek()Landroid/widget/SeekBar;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 393
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSeekRow()Landroid/widget/LinearLayout;

    move-result-object v2

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 395
    :goto_1f7
    if-eqz v4, :cond_215

    invoke-static/range {v16 .. v16}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v2

    sget-object v3, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-ne v2, v3, :cond_215

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getSub()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getError()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_210

    const-string v3, "Can\'t play this audio"

    :cond_210
    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 396
    :cond_215
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getPlay()Landroid/widget/ImageView;

    move-result-object v2

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda3;

    invoke-direct {v5, v3, v10}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda3;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V

    invoke-virtual {v2, v5}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 397
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getInsert()Landroid/widget/TextView;

    move-result-object v2

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda4;

    invoke-direct {v5, v3, v10}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 398
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v2

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda5;

    invoke-direct {v5, v3, v10}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda5;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 399
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v2

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;

    invoke-direct/range {v5 .. v10}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 405
    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .registers 4
    .param p1, "p0"    # Landroid/view/ViewGroup;
    .param p2, "p1"    # I

    .line 315
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onCreateViewHolder(Landroid/view/ViewGroup;I)Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    return-object v0
.end method

.method public onCreateViewHolder(Landroid/view/ViewGroup;I)Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;
    .registers 31
    .param p1, "parent"    # Landroid/view/ViewGroup;
    .param p2, "viewType"    # I

    move-object/from16 v0, p0

    const-string v1, "parent"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 319
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v4

    .line 320
    .local v4, "ctx":Landroid/content/Context;
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    move-object v5, v1

    .local v5, "$this$onCreateViewHolder_u24lambda_u240\\1":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 321
    .local v6, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$outer$1\\1\\320\\0":I
    const/4 v7, 0x1

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 322
    new-instance v8, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;

    const/4 v11, -0x1

    const/4 v12, -0x2

    invoke-direct {v8, v11, v12}, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;-><init>(II)V

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v5, v8}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 323
    const/high16 v8, 0x41000000    # 8.0f

    invoke-static {v3, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v9

    const/high16 v13, 0x40c00000    # 6.0f

    invoke-static {v3, v13}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v10

    invoke-static {v3, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v8

    const/high16 v14, 0x40800000    # 4.0f

    invoke-static {v3, v14}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v3

    invoke-virtual {v5, v9, v10, v8, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 324
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getPANEL()I

    move-result v8

    const/4 v9, 0x0

    invoke-virtual {v3, v4, v8, v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->rippleBg(Landroid/content/Context;IF)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v3

    check-cast v3, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 325
    nop

    .line 320
    .end local v5    # "$this$onCreateViewHolder_u24lambda_u240\\1":Landroid/widget/LinearLayout;
    .end local v6    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$outer$1\\1\\320\\0":I
    nop

    .line 326
    .local v1, "outer":Landroid/widget/LinearLayout;
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v3

    .line 409
    .local v5, "$this$onCreateViewHolder_u24lambda_u241\\2":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 326
    .local v6, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$row$1\\2\\326\\0":I
    const/4 v15, 0x0

    invoke-virtual {v5, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v9, 0x10

    invoke-virtual {v5, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .end local v5    # "$this$onCreateViewHolder_u24lambda_u241\\2":Landroid/widget/LinearLayout;
    .end local v6    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$row$1\\2\\326\\0":I
    move-object v10, v3

    .line 327
    .local v10, "row":Landroid/widget/LinearLayout;
    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v3, v15, v15, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;-><init>(ZZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v19, v3

    .line 328
    .local v19, "glyph":Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;
    new-instance v3, Landroid/widget/ImageView;

    invoke-direct {v3, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    move-object v6, v3

    .line 409
    .local v6, "$this$onCreateViewHolder_u24lambda_u242\\3":Landroid/widget/ImageView;
    const/4 v8, 0x0

    .line 328
    .local v8, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$play$1\\3\\328\\0":I
    move-object/from16 v9, v19

    check-cast v9, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v6, v9}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/high16 v9, 0x40000000    # 2.0f

    invoke-static {v5, v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v14

    invoke-static {v5, v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v11

    invoke-static {v5, v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v13

    invoke-static {v5, v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v5

    invoke-virtual {v6, v14, v11, v13, v5}, Landroid/widget/ImageView;->setPadding(IIII)V

    .end local v6    # "$this$onCreateViewHolder_u24lambda_u242\\3":Landroid/widget/ImageView;
    .end local v8    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$play$1\\3\\328\\0":I
    move-object v11, v3

    .line 329
    .local v11, "play":Landroid/widget/ImageView;
    move-object v3, v11

    check-cast v3, Landroid/view/View;

    sget-object v21, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    const/high16 v6, 0x42080000    # 34.0f

    invoke-static {v5, v6}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v22

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v5, v6}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v23

    const/16 v25, 0x4

    const/16 v26, 0x0

    const/16 v24, 0x0

    invoke-static/range {v21 .. v26}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 409
    move-object v8, v5

    .local v8, "$this$onCreateViewHolder_u24lambda_u243\\4":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 329
    .local v13, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$1\\4\\329\\0":I
    const/high16 v14, 0x41200000    # 10.0f

    invoke-static {v6, v14}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v6

    iput v6, v8, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v8    # "$this$onCreateViewHolder_u24lambda_u243\\4":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$1\\4\\329\\0":I
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v10, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 330
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v3

    .line 409
    .local v5, "$this$onCreateViewHolder_u24lambda_u244\\5":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 330
    .local v6, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$texts$1\\5\\330\\0":I
    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .end local v5    # "$this$onCreateViewHolder_u24lambda_u244\\5":Landroid/widget/LinearLayout;
    .end local v6    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$texts$1\\5\\330\\0":I
    move-object v13, v3

    .line 331
    .local v13, "texts":Landroid/widget/LinearLayout;
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v7

    const/4 v8, 0x1

    const-string v5, ""

    const/high16 v6, 0x41500000    # 13.0f

    invoke-virtual/range {v3 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v3

    move-object v5, v3

    .line 409
    .local v5, "$this$onCreateViewHolder_u24lambda_u245\\6":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 331
    .local v6, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$title$1\\6\\331\\0":I
    sget-object v7, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .end local v5    # "$this$onCreateViewHolder_u24lambda_u245\\6":Landroid/widget/TextView;
    .end local v6    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$title$1\\6\\331\\0":I
    move-object/from16 v21, v3

    .line 332
    .local v21, "title":Landroid/widget/TextView;
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v7

    move v5, v9

    const/16 v9, 0x10

    move-object v6, v10

    .end local v10    # "row":Landroid/widget/LinearLayout;
    .local v6, "row":Landroid/widget/LinearLayout;
    const/4 v10, 0x0

    move v8, v5

    const-string v5, ""

    move-object/from16 v22, v6

    .end local v6    # "row":Landroid/widget/LinearLayout;
    .local v22, "row":Landroid/widget/LinearLayout;
    const/high16 v6, 0x41300000    # 11.0f

    move/from16 v23, v8

    const/4 v8, 0x0

    move-object/from16 v14, v22

    .end local v22    # "row":Landroid/widget/LinearLayout;
    .local v14, "row":Landroid/widget/LinearLayout;
    invoke-static/range {v3 .. v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v3

    move-object v5, v3

    .line 409
    .local v5, "$this$onCreateViewHolder_u24lambda_u246\\7":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 332
    .local v6, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$sub$1\\7\\332\\0":I
    sget-object v7, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .end local v5    # "$this$onCreateViewHolder_u24lambda_u246\\7":Landroid/widget/TextView;
    .end local v6    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$sub$1\\7\\332\\0":I
    move-object/from16 v16, v3

    .line 333
    .local v16, "sub":Landroid/widget/TextView;
    move-object/from16 v3, v21

    check-cast v3, Landroid/view/View;

    invoke-virtual {v13, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    move-object/from16 v3, v16

    check-cast v3, Landroid/view/View;

    invoke-virtual {v13, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 334
    move-object v3, v13

    check-cast v3, Landroid/view/View;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-virtual {v5, v15, v12, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v14, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 335
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v7

    const-string v5, ""

    move v8, v6

    const/high16 v6, 0x41300000    # 11.0f

    move v12, v8

    const/4 v8, 0x0

    invoke-static/range {v3 .. v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v22

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    move-object/from16 v5, v22

    .line 409
    .local v5, "$this$onCreateViewHolder_u24lambda_u247\\8":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 335
    .local v6, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$dur$1\\8\\335\\0":I
    const/high16 v7, 0x40c00000    # 6.0f

    invoke-static {v3, v7}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v8

    invoke-static {v3, v7}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v3

    invoke-virtual {v5, v8, v15, v3, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 336
    .end local v5    # "$this$onCreateViewHolder_u24lambda_u247\\8":Landroid/widget/TextView;
    .end local v6    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$dur$1\\8\\335\\0":I
    .local v22, "dur":Landroid/widget/TextView;
    move-object/from16 v3, v22

    check-cast v3, Landroid/view/View;

    invoke-virtual {v14, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 337
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getACCENT()I

    move-result v5

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda1;

    invoke-direct {v6}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda1;-><init>()V

    const-string v7, "Insert"

    invoke-virtual {v3, v4, v7, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->button(Landroid/content/Context;Ljava/lang/String;ILkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object v27

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    move-object/from16 v5, v27

    .line 409
    .local v5, "$this$onCreateViewHolder_u24lambda_u249\\9":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 337
    .local v6, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$insert$2\\9\\337\\0":I
    const/4 v7, -0x1

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v7, 0x41400000    # 12.0f

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextSize(F)V

    const/high16 v8, 0x41200000    # 10.0f

    invoke-static {v3, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v9

    const/high16 v10, 0x40800000    # 4.0f

    invoke-static {v3, v10}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v7

    invoke-static {v3, v8}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v8

    invoke-static {v3, v10}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v3

    invoke-virtual {v5, v9, v7, v8, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 338
    .end local v5    # "$this$onCreateViewHolder_u24lambda_u249\\9":Landroid/widget/TextView;
    .end local v6    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$insert$2\\9\\337\\0":I
    .local v27, "insert":Landroid/widget/TextView;
    move-object/from16 v3, v27

    check-cast v3, Landroid/view/View;

    invoke-virtual {v14, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 339
    move-object v3, v14

    check-cast v3, Landroid/view/View;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v9, 0x4

    const/4 v10, 0x0

    const/4 v6, -0x1

    const/4 v7, -0x2

    const/4 v8, 0x0

    invoke-static/range {v5 .. v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 341
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v3

    .line 409
    .local v5, "$this$onCreateViewHolder_u24lambda_u2410\\10":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 341
    .local v6, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$seekRow$1\\10\\341\\0":I
    invoke-virtual {v5, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v7, 0x10

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v7, 0x8

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .end local v5    # "$this$onCreateViewHolder_u24lambda_u2410\\10":Landroid/widget/LinearLayout;
    .end local v6    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$seekRow$1\\10\\341\\0":I
    move-object/from16 v23, v3

    .line 342
    .local v23, "seekRow":Landroid/widget/LinearLayout;
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v7

    const/16 v9, 0x10

    const-string v5, "0:00"

    const/high16 v6, 0x41300000    # 11.0f

    const/4 v8, 0x0

    move-object/from16 v12, v23

    const/high16 v15, 0x41400000    # 12.0f

    .end local v23    # "seekRow":Landroid/widget/LinearLayout;
    .local v12, "seekRow":Landroid/widget/LinearLayout;
    invoke-static/range {v3 .. v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v25

    move-object/from16 v3, v25

    .line 409
    .local v3, "$this$onCreateViewHolder_u24lambda_u2411\\11":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 342
    .local v5, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$elapsed$1\\11\\342\\0":I
    const v6, 0x800005

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 343
    .end local v3    # "$this$onCreateViewHolder_u24lambda_u2411\\11":Landroid/widget/TextView;
    .end local v5    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$elapsed$1\\11\\342\\0":I
    .local v25, "elapsed":Landroid/widget/TextView;
    new-instance v3, Landroid/widget/SeekBar;

    invoke-direct {v3, v4}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    move-object v6, v3

    .local v6, "$this$onCreateViewHolder_u24lambda_u2412\\12":Landroid/widget/SeekBar;
    const/4 v7, 0x0

    .line 344
    .local v7, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$seek$1\\12\\343\\0":I
    const/16 v8, 0x3e8

    invoke-virtual {v6, v8}, Landroid/widget/SeekBar;->setMax(I)V

    .line 345
    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getACCENT()I

    move-result v8

    invoke-static {v8}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    invoke-virtual {v6, v8}, Landroid/widget/SeekBar;->setProgressTintList(Landroid/content/res/ColorStateList;)V

    .line 346
    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getACCENT()I

    move-result v8

    invoke-static {v8}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    invoke-virtual {v6, v8}, Landroid/widget/SeekBar;->setThumbTintList(Landroid/content/res/ColorStateList;)V

    .line 347
    invoke-static {v5, v15}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v8

    invoke-static {v5, v15}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v5

    const/4 v9, 0x0

    invoke-virtual {v6, v8, v9, v5, v9}, Landroid/widget/SeekBar;->setPadding(IIII)V

    .line 348
    nop

    .line 343
    .end local v6    # "$this$onCreateViewHolder_u24lambda_u2412\\12":Landroid/widget/SeekBar;
    .end local v7    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$seek$1\\12\\343\\0":I
    move-object/from16 v24, v3

    .line 349
    .local v24, "seek":Landroid/widget/SeekBar;
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v7

    const/16 v9, 0x10

    const-string v5, ""

    const/high16 v6, 0x41300000    # 11.0f

    const/4 v8, 0x0

    invoke-static/range {v3 .. v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v26

    .line 350
    .local v26, "total":Landroid/widget/TextView;
    move-object/from16 v3, v25

    check-cast v3, Landroid/view/View;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    const/high16 v15, 0x42180000    # 38.0f

    invoke-static {v6, v15}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v6

    const/4 v9, 0x4

    const/4 v7, -0x2

    const/4 v8, 0x0

    invoke-static/range {v5 .. v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v12, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 351
    move-object/from16 v3, v24

    check-cast v3, Landroid/view/View;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    const/high16 v7, 0x41f00000    # 30.0f

    invoke-static {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v6

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v9, 0x0

    invoke-virtual {v5, v9, v6, v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v12, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 352
    move-object/from16 v3, v26

    check-cast v3, Landroid/view/View;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v6, v15}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v6

    const/4 v9, 0x4

    const/4 v7, -0x2

    const/4 v8, 0x0

    invoke-static/range {v5 .. v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v12, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 353
    move-object v3, v12

    check-cast v3, Landroid/view/View;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v6, -0x1

    invoke-static/range {v5 .. v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 409
    move-object v7, v5

    .local v7, "$this$onCreateViewHolder_u24lambda_u2413\\13":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v8, 0x0

    .line 353
    .local v8, "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$2\\13\\353\\0":I
    const/high16 v9, 0x40000000    # 2.0f

    invoke-static {v6, v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v9

    iput v9, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/high16 v9, 0x42100000    # 36.0f

    invoke-static {v6, v9}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$dp(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)I

    move-result v6

    iput v6, v7, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .end local v7    # "$this$onCreateViewHolder_u24lambda_u2413\\13":Landroid/widget/LinearLayout$LayoutParams;
    .end local v8    # "$i$a$-apply-AudioBrowser$Adapter$onCreateViewHolder$2\\13\\353\\0":I
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 354
    new-instance v15, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    move-object/from16 v17, v1

    move-object/from16 v18, v11

    move-object/from16 v20, v21

    move-object/from16 v21, v16

    move-object/from16 v16, v3

    .end local v1    # "outer":Landroid/widget/LinearLayout;
    .end local v11    # "play":Landroid/widget/ImageView;
    .end local v12    # "seekRow":Landroid/widget/LinearLayout;
    .end local v16    # "sub":Landroid/widget/TextView;
    .local v17, "outer":Landroid/widget/LinearLayout;
    .local v18, "play":Landroid/widget/ImageView;
    .local v20, "title":Landroid/widget/TextView;
    .local v21, "sub":Landroid/widget/TextView;
    .restart local v23    # "seekRow":Landroid/widget/LinearLayout;
    invoke-direct/range {v15 .. v27}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;-><init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Landroid/widget/ImageView;Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/SeekBar;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V

    return-object v15
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;"
    method = "onBindViewHolder$lambda$21$lambda$20"
    proto = "(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder$lambda$21$lambda$20(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;"
    method = "onCreateViewHolder$lambda$8"
    proto = "(Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Landroid/view/View;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onCreateViewHolder$lambda$8(Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;"
    method = "onBindViewHolder$lambda$18$lambda$17"
    proto = "(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder$lambda$18$lambda$17(Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;"
    method = "onBindViewHolder$lambda$18"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda3;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda3;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder$lambda$18(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;"
    method = "onBindViewHolder$lambda$19"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda4;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda4;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder$lambda$19(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;"
    method = "onBindViewHolder$lambda$21"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda5;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda5;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder$lambda$21(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;"
    method = "onBindViewHolder$lambda$26"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Ljava/lang/String;

.field public final synthetic f$4:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$2:Ljava/lang/String;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$3:Ljava/lang/String;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$4:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .registers 8

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$1:Ljava/lang/String;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$2:Ljava/lang/String;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$3:Ljava/lang/String;

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda6;->f$4:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    move-object v5, p1

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder$lambda$26(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/view/View;)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;"
    method = "onBindViewHolder$lambda$26$lambda$25"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/content/DialogInterface;I)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda7;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$$ExternalSyntheticLambda7;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;

    invoke-static {v0, v1, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder$lambda$26$lambda$25(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioItem;Landroid/content/DialogInterface;I)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$onBindViewHolder$2 (com.exampletest.mobilestudiotest.ui.AudioBrowser$Adapter$onBindViewHolder$2)
.class public final Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;
.super Ljava/lang/Object;
.source "AudioBrowser.kt"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter;->onBindViewHolder(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\tH\u0016J\u0010\u0010\n\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u000b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016\u00a8\u0006\u000c"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2",
        "Landroid/widget/SeekBar$OnSeekBarChangeListener;",
        "onProgressChanged",
        "",
        "sb",
        "Landroid/widget/SeekBar;",
        "v",
        "",
        "fromUser",
        "",
        "onStartTrackingTouch",
        "onStopTrackingTouch",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $h:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;

.field final synthetic $id:J

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;J)V
    .registers 5
    .param p1, "$h"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;
    .param p2, "$receiver"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p3, "$id"    # J

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->$h:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-wide p3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->$id:J

    .line 383
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 8
    .param p1, "sb"    # Landroid/widget/SeekBar;
    .param p2, "v"    # I
    .param p3, "fromUser"    # Z

    const-string v0, "sb"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 384
    if-eqz p3, :cond_1c

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->$h:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->getElapsed()Landroid/widget/TextView;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    int-to-float v2, p2

    const/high16 v3, 0x41200000    # 10.0f

    div-float/2addr v2, v3

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$fmtClock(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;F)Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1c
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 5
    .param p1, "sb"    # Landroid/widget/SeekBar;

    const-string v0, "sb"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 385
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iget-wide v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->$id:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$setDraggingId$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/Long;)V

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 7
    .param p1, "sb"    # Landroid/widget/SeekBar;

    const-string v0, "sb"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 387
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$setDraggingId$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/Long;)V

    .line 388
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    iget-wide v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$Adapter$onBindViewHolder$2;->$id:J

    invoke-virtual {p1}, Landroid/widget/SeekBar;->getProgress()I

    move-result v3

    int-to-float v3, v3

    const/high16 v4, 0x41200000    # 10.0f

    div-float/2addr v3, v4

    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->seekPreview(JF)V

    .line 389
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser.VH (com.exampletest.mobilestudiotest.ui.AudioBrowser$VH)
.class final Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;
.super Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
.source "AudioBrowser.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "VH"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0016\u0008\u0082\u0004\u0018\u00002\u00020\u0001B_\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u000b\u001a\u00020\t\u0012\u0006\u0010\u000c\u001a\u00020\u0003\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\u0006\u0010\u000f\u001a\u00020\t\u0012\u0006\u0010\u0010\u001a\u00020\t\u0012\u0006\u0010\u0011\u001a\u00020\t\u00a2\u0006\u0004\u0008\u0012\u0010\u0013R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0017R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0018\u0010\u0019R\u0011\u0010\u0008\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001a\u0010\u001bR\u0011\u0010\n\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001c\u0010\u001bR\u0011\u0010\u000b\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u001bR\u0011\u0010\u000c\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001e\u0010\u0015R\u0011\u0010\r\u001a\u00020\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001f\u0010 R\u0011\u0010\u000f\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008!\u0010\u001bR\u0011\u0010\u0010\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\"\u0010\u001bR\u0011\u0010\u0011\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008#\u0010\u001b\u00a8\u0006$"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;",
        "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;",
        "row",
        "Landroid/widget/LinearLayout;",
        "play",
        "Landroid/widget/ImageView;",
        "glyph",
        "Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;",
        "title",
        "Landroid/widget/TextView;",
        "sub",
        "dur",
        "seekRow",
        "seek",
        "Landroid/widget/SeekBar;",
        "elapsed",
        "total",
        "insert",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Landroid/widget/ImageView;Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/SeekBar;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V",
        "getRow",
        "()Landroid/widget/LinearLayout;",
        "getPlay",
        "()Landroid/widget/ImageView;",
        "getGlyph",
        "()Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;",
        "getTitle",
        "()Landroid/widget/TextView;",
        "getSub",
        "getDur",
        "getSeekRow",
        "getSeek",
        "()Landroid/widget/SeekBar;",
        "getElapsed",
        "getTotal",
        "getInsert",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final dur:Landroid/widget/TextView;

.field private final elapsed:Landroid/widget/TextView;

.field private final glyph:Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;

.field private final insert:Landroid/widget/TextView;

.field private final play:Landroid/widget/ImageView;

.field private final row:Landroid/widget/LinearLayout;

.field private final seek:Landroid/widget/SeekBar;

.field private final seekRow:Landroid/widget/LinearLayout;

.field private final sub:Landroid/widget/TextView;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

.field private final title:Landroid/widget/TextView;

.field private final total:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/widget/LinearLayout;Landroid/widget/ImageView;Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/SeekBar;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .registers 14
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;
    .param p2, "row"    # Landroid/widget/LinearLayout;
    .param p3, "play"    # Landroid/widget/ImageView;
    .param p4, "glyph"    # Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;
    .param p5, "title"    # Landroid/widget/TextView;
    .param p6, "sub"    # Landroid/widget/TextView;
    .param p7, "dur"    # Landroid/widget/TextView;
    .param p8, "seekRow"    # Landroid/widget/LinearLayout;
    .param p9, "seek"    # Landroid/widget/SeekBar;
    .param p10, "elapsed"    # Landroid/widget/TextView;
    .param p11, "total"    # Landroid/widget/TextView;
    .param p12, "insert"    # Landroid/widget/TextView;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Landroid/widget/ImageView;",
            "Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;",
            "Landroid/widget/TextView;",
            "Landroid/widget/TextView;",
            "Landroid/widget/TextView;",
            "Landroid/widget/LinearLayout;",
            "Landroid/widget/SeekBar;",
            "Landroid/widget/TextView;",
            "Landroid/widget/TextView;",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation

    const-string v0, "row"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "play"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "glyph"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "title"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sub"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "dur"

    invoke-static {p7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "seekRow"

    invoke-static {p8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "seek"

    invoke-static {p9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "elapsed"

    invoke-static {p10, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "total"

    invoke-static {p11, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "insert"

    invoke-static {p12, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 311
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 313
    move-object v0, p2

    check-cast v0, Landroid/view/View;

    invoke-direct {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    .line 311
    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->row:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->play:Landroid/widget/ImageView;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->glyph:Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->title:Landroid/widget/TextView;

    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->sub:Landroid/widget/TextView;

    .line 312
    iput-object p7, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->dur:Landroid/widget/TextView;

    iput-object p8, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->seekRow:Landroid/widget/LinearLayout;

    iput-object p9, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->seek:Landroid/widget/SeekBar;

    iput-object p10, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->elapsed:Landroid/widget/TextView;

    iput-object p11, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->total:Landroid/widget/TextView;

    .line 313
    iput-object p12, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->insert:Landroid/widget/TextView;

    .line 311
    return-void
.end method


# virtual methods
.method public final getDur()Landroid/widget/TextView;
    .registers 2

    .line 312
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->dur:Landroid/widget/TextView;

    return-object v0
.end method

.method public final getElapsed()Landroid/widget/TextView;
    .registers 2

    .line 312
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->elapsed:Landroid/widget/TextView;

    return-object v0
.end method

.method public final getGlyph()Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;
    .registers 2

    .line 311
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->glyph:Lcom/exampletest/mobilestudiotest/ui/PlayGlyph;

    return-object v0
.end method

.method public final getInsert()Landroid/widget/TextView;
    .registers 2

    .line 313
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->insert:Landroid/widget/TextView;

    return-object v0
.end method

.method public final getPlay()Landroid/widget/ImageView;
    .registers 2

    .line 311
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->play:Landroid/widget/ImageView;

    return-object v0
.end method

.method public final getRow()Landroid/widget/LinearLayout;
    .registers 2

    .line 311
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->row:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method public final getSeek()Landroid/widget/SeekBar;
    .registers 2

    .line 312
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->seek:Landroid/widget/SeekBar;

    return-object v0
.end method

.method public final getSeekRow()Landroid/widget/LinearLayout;
    .registers 2

    .line 312
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->seekRow:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method public final getSub()Landroid/widget/TextView;
    .registers 2

    .line 311
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->sub:Landroid/widget/TextView;

    return-object v0
.end method

.method public final getTitle()Landroid/widget/TextView;
    .registers 2

    .line 311
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->title:Landroid/widget/TextView;

    return-object v0
.end method

.method public final getTotal()Landroid/widget/TextView;
    .registers 2

    .line 312
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$VH;->total:Landroid/widget/TextView;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser.AnonymousClass1 (com.exampletest.mobilestudiotest.ui.AudioBrowser$buildResults$1)
.class public final Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1;
.super Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;
.source "AudioBrowser.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildResults()Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\u0007H\u0016\u00a8\u0006\t"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1",
        "Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;",
        "onScrolled",
        "",
        "r",
        "Landroidx/recyclerview/widget/RecyclerView;",
        "dx",
        "",
        "dy",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $lm:Landroidx/recyclerview/widget/LinearLayoutManager;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method constructor <init>(Landroidx/recyclerview/widget/LinearLayoutManager;Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 3
    .param p1, "$lm"    # Landroidx/recyclerview/widget/LinearLayoutManager;
    .param p2, "$receiver"    # Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1;->$lm:Landroidx/recyclerview/widget/LinearLayoutManager;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    .line 253
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onScrolled(Landroidx/recyclerview/widget/RecyclerView;II)V
    .registers 6
    .param p1, "r"    # Landroidx/recyclerview/widget/RecyclerView;
    .param p2, "dx"    # I
    .param p3, "dy"    # I

    const-string v0, "r"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 254
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1;->$lm:Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    move-result v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$getItems$p(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x5

    if-lt v0, v1, :cond_1e

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$buildResults$1;->this$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->access$loadMore(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    :cond_1e
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "previewListener$lambda$2"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->previewListener$lambda$2(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "showDiscover$flow$lambda$25"
    proto = "(Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;Ljava/lang/String;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda1;->f$0:Lkotlin/jvm/functions/Function1;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda1;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda1;->f$0:Lkotlin/jvm/functions/Function1;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda1;->f$1:Ljava/lang/String;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$flow$lambda$25(Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda10 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda10)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$19$lambda$18"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda10;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda10;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$19$lambda$18(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda11 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda11)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$20"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda11;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda11;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$20(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda12 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda12)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$17$lambda$16"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda12;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda12;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$17$lambda$16(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda13 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda13)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$10$lambda$9"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda13;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda13;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$10$lambda$9(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda14 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda14)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "chip$lambda$6$lambda$5"
    proto = "(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda14;->f$0:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda14;->f$0:Lkotlin/jvm/functions/Function1;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->chip$lambda$6$lambda$5(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda15 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda15)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "showDiscover$lambda$32"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda15;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda15;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$lambda$32(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda16 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda16)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "showDiscover$lambda$33"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda16;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda16;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$lambda$33(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda17 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda17)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "showDiscover$lambda$35"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda17;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda17;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$lambda$35(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda18 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda18)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "showDiscover$lambda$36"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda18;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda18;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$lambda$36(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda19 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda19)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "showDiscover$lambda$37"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda19;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda19;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$lambda$37(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "showDiscover$card$lambda$29$lambda$28"
    proto = "(Lkotlin/jvm/functions/Function0;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda2;->f$0:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda2;->f$0:Lkotlin/jvm/functions/Function0;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$card$lambda$29$lambda$28(Lkotlin/jvm/functions/Function0;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda20 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda20)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "showDiscover$lambda$38"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda20;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda20;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->showDiscover$lambda$38(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda21 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda21)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/PopupMenu$OnMenuItemClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "menu$lambda$22"
    proto = "(Lkotlin/jvm/functions/Function1;Landroid/view/MenuItem;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda21;->f$0:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final onMenuItemClick(Landroid/view/MenuItem;)Z
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda21;->f$0:Lkotlin/jvm/functions/Function1;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->menu$lambda$22(Lkotlin/jvm/functions/Function1;Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda22 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda22)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$14$lambda$13"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda22;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda22;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$14$lambda$13(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "previewListener$lambda$2$lambda$1"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->previewListener$lambda$2$lambda$1(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "loadMore$lambda$46"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;Ljava/lang/String;I)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:I


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;Ljava/lang/String;I)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;->f$2:Ljava/lang/String;

    iput p4, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;->f$3:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;->f$1:Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;->f$2:Ljava/lang/String;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda4;->f$3:I

    invoke-static {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loadMore$lambda$46(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lcom/exampletest/mobilestudiotest/net/RobloxApi$AudioQuery;Ljava/lang/String;I)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "loadMore$lambda$46$lambda$45"
    proto = "(ILcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

.field public final synthetic f$2:Lkotlin/jvm/internal/Ref$ObjectRef;

.field public final synthetic f$3:Lkotlin/jvm/internal/Ref$ObjectRef;


# direct methods
.method public synthetic constructor <init>(ILcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;->f$0:I

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;->f$1:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;->f$2:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;->f$3:Lkotlin/jvm/internal/Ref$ObjectRef;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;->f$0:I

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;->f$1:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;->f$2:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda5;->f$3:Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-static {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->loadMore$lambda$46$lambda$45(ILcom/exampletest/mobilestudiotest/ui/AudioBrowser;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$8"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$8(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$10"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$10(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda8 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$14"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$14(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda9 (com.exampletest.mobilestudiotest.ui.AudioBrowser$$ExternalSyntheticLambda9)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;"
    method = "buildFilters$lambda$17"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;->buildFilters$lambda$17(Lcom/exampletest/mobilestudiotest/ui/AudioBrowser;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
