###### Class com.exampletest.mobilestudiotest.ui.Icons (com.exampletest.mobilestudiotest.ui.Icons)
.class public final Lcom/exampletest/mobilestudiotest/ui/Icons;
.super Ljava/lang/Object;
.source "Icons.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nIcons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Icons.kt\ncom/exampletest/mobilestudiotest/ui/Icons\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 5 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,185:1\n1#2:186\n434#3:187\n507#3,5:188\n774#4:193\n865#4,2:194\n1563#4:196\n1634#4,3:197\n295#4,2:200\n774#4:202\n865#4,2:203\n774#4:205\n865#4,2:206\n774#4:208\n865#4,2:209\n1491#4:211\n1516#4,3:212\n1519#4,3:222\n1252#4,2:227\n295#4,2:229\n1255#4:231\n1869#4,2:232\n1869#4,2:234\n382#5,7:215\n463#5:225\n413#5:226\n*S KotlinDebug\n*F\n+ 1 Icons.kt\ncom/exampletest/mobilestudiotest/ui/Icons\n*L\n86#1:187\n86#1:188,5\n149#1:193\n149#1:194,2\n150#1:196\n150#1:197,3\n151#1:200,2\n155#1:202\n155#1:203,2\n156#1:205\n156#1:206,2\n158#1:208\n158#1:209,2\n161#1:211\n161#1:212,3\n161#1:222,3\n161#1:227,2\n161#1:229,2\n161#1:231\n175#1:232,2\n182#1:234,2\n161#1:215,7\n161#1:225\n161#1:226\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\"\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u00011B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u0013J\u001a\u0010\u0018\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0019\u001a\u00020\u00082\u0006\u0010\u001a\u001a\u00020\u0008H\u0002J\u0010\u0010\u001b\u001a\u0004\u0018\u00010\t2\u0006\u0010\u001c\u001a\u00020\u0008J\u0010\u0010\u001d\u001a\u0004\u0018\u00010\t2\u0006\u0010\u001a\u001a\u00020\u0008J\u0010\u0010\u001e\u001a\u0004\u0018\u00010\t2\u0006\u0010\u001a\u001a\u00020\u0008J\u0016\u0010\u001f\u001a\u00020 2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001c\u001a\u00020\u0008J \u0010!\u001a\u00020 2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\u00082\u0008\u0008\u0002\u0010\"\u001a\u00020\u0008J\u001e\u0010%\u001a\u00020 2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\u00082\u0006\u0010\"\u001a\u00020\u0008J\u0018\u0010&\u001a\u00020\'2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010(\u001a\u00020\tH\u0002J\u0010\u0010)\u001a\u00020\u00082\u0006\u0010*\u001a\u00020\u0008H\u0002J\u0010\u0010+\u001a\u00020,2\u0006\u0010\u001c\u001a\u00020\u0008H\u0002J\u0016\u0010-\u001a\u00020,2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010.\u001a\u00020/J\u000e\u00100\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u0013R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R.\u0010\u0006\u001a\"\u0012\u0004\u0012\u00020\u0008\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0007j\u0010\u0012\u0004\u0012\u00020\u0008\u0012\u0006\u0012\u0004\u0018\u00010\t`\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001d\u0010\u000b\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u000e0\r0\u000c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R\u0011\u0010\u0014\u001a\u00020\u00158F\u00a2\u0006\u0006\u001a\u0004\u0008\u0016\u0010\u0017R\u0014\u0010#\u001a\u0008\u0012\u0004\u0012\u00020\u00080$X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u00062"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/Icons;",
        "",
        "<init>",
        "()V",
        "dir",
        "Ljava/io/File;",
        "cache",
        "Ljava/util/HashMap;",
        "",
        "Landroid/graphics/Bitmap;",
        "Lkotlin/collections/HashMap;",
        "listeners",
        "Ljava/util/concurrent/CopyOnWriteArrayList;",
        "Lkotlin/Function0;",
        "",
        "getListeners",
        "()Ljava/util/concurrent/CopyOnWriteArrayList;",
        "init",
        "ctx",
        "Landroid/content/Context;",
        "installed",
        "",
        "getInstalled",
        "()Z",
        "load",
        "kind",
        "name",
        "instanceBitmap",
        "cls",
        "generalBitmap",
        "uiBitmap",
        "instance",
        "Landroid/graphics/drawable/Drawable;",
        "general",
        "fallback",
        "knownClassIcons",
        "",
        "ui",
        "pixelated",
        "Landroid/graphics/drawable/BitmapDrawable;",
        "b",
        "abbrev",
        "s",
        "categoryColor",
        "",
        "importZip",
        "input",
        "Ljava/io/InputStream;",
        "remove",
        "Badge",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

.field private static final cache:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field

.field private static dir:Ljava/io/File;

.field private static final knownClassIcons:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final listeners:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Icons;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/ui/Icons;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    .line 28
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    .line 29
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 78
    const/16 v0, 0x9

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "Script"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "LocalScript"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "ModuleScript"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "Model"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "Folder"

    aput-object v2, v0, v1

    const/4 v1, 0x5

    const-string v2, "Plugin"

    aput-object v2, v0, v1

    const/4 v1, 0x6

    const-string v2, "Humanoid"

    aput-object v2, v0, v1

    const/4 v1, 0x7

    const-string v2, "Sound"

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const-string v2, "Decal"

    aput-object v2, v0, v1

    invoke-static {v0}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->knownClassIcons:Ljava/util/Set;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final abbrev(Ljava/lang/String;)Ljava/lang/String;
    .registers 15
    .param p1, "s"    # Ljava/lang/String;

    .line 86
    move-object v0, p1

    .local v0, "$this$filter\\1":Ljava/lang/String;
    const/4 v1, 0x0

    .line 187
    .local v1, "$i$f$filter\\1\\86":I
    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    .local v2, "$this$filterTo\\2":Ljava/lang/CharSequence;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    check-cast v3, Ljava/lang/Appendable;

    .local v3, "destination\\2":Ljava/lang/Appendable;
    const/4 v4, 0x0

    .line 188
    .local v4, "$i$f$filterTo\\2\\187":I
    const/4 v5, 0x0

    .local v5, "index\\2":I
    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v6

    :goto_12
    const/4 v7, 0x0

    const/4 v8, 0x1

    if-ge v5, v6, :cond_32

    .line 189
    invoke-interface {v2, v5}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v9

    .line 190
    .local v9, "element\\2":C
    move v10, v9

    .local v10, "it\\3":C
    const/4 v11, 0x0

    .line 86
    .local v11, "$i$a$-filter-Icons$abbrev$caps$1\\3\\190\\0":I
    invoke-static {v10}, Ljava/lang/Character;->isUpperCase(C)Z

    move-result v12

    if-nez v12, :cond_29

    invoke-static {v10}, Ljava/lang/Character;->isDigit(C)Z

    move-result v12

    if-nez v12, :cond_29

    goto :goto_2a

    :cond_29
    move v7, v8

    .line 190
    .end local v10    # "it\\3":C
    .end local v11    # "$i$a$-filter-Icons$abbrev$caps$1\\3\\190\\0":I
    :goto_2a
    if-eqz v7, :cond_2f

    invoke-interface {v3, v9}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    .line 188
    .end local v9    # "element\\2":C
    :cond_2f
    add-int/lit8 v5, v5, 0x1

    goto :goto_12

    .line 192
    .end local v5    # "index\\2":I
    :cond_32
    nop

    .end local v2    # "$this$filterTo\\2":Ljava/lang/CharSequence;
    .end local v3    # "destination\\2":Ljava/lang/Appendable;
    .end local v4    # "$i$f$filterTo\\2\\187":I
    move-object v2, v3

    check-cast v2, Ljava/lang/StringBuilder;

    .line 187
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 86
    .end local v0    # "$this$filter\\1":Ljava/lang/String;
    .end local v1    # "$i$f$filter\\1\\86":I
    nop

    .line 87
    .local v0, "caps":Ljava/lang/String;
    nop

    .line 88
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x2

    if-lt v1, v2, :cond_48

    invoke-static {v0, v2}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_a1

    .line 89
    :cond_48
    move-object v1, p1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-lez v1, :cond_53

    move v1, v8

    goto :goto_54

    :cond_53
    move v1, v7

    :goto_54
    if-eqz v1, :cond_9f

    invoke-static {p1, v2}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lez v2, :cond_65

    move v2, v8

    goto :goto_66

    :cond_65
    move v2, v7

    :goto_66
    if-eqz v2, :cond_a1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    move-result v3

    .line 186
    nop

    .local v3, "it\\4":C
    const/4 v4, 0x0

    .line 89
    .local v4, "$i$a$-replaceFirstCharWithCharSequence-Icons$abbrev$1\\4\\89\\0":I
    invoke-static {v3}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v5

    const-string v6, "null cannot be cast to non-null type java.lang.String"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v6, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v5, v6}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "toUpperCase(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Ljava/lang/CharSequence;

    .end local v3    # "it\\4":C
    .end local v4    # "$i$a$-replaceFirstCharWithCharSequence-Icons$abbrev$1\\4\\89\\0":I
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    const-string v3, "substring(...)"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_a1

    .line 90
    :cond_9f
    const-string v1, "?"

    .line 87
    :cond_a1
    :goto_a1
    return-object v1
.end method

.method private final categoryColor(Ljava/lang/String;)I
    .registers 4
    .param p1, "cls"    # Ljava/lang/String;

    .line 94
    nop

    .line 95
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    const-string v1, "LuaSourceContainer"

    invoke-virtual {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isA(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_f

    const v0, -0xc5842b

    goto :goto_66

    .line 96
    :cond_f
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    const-string v1, "BasePart"

    invoke-virtual {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isA(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1d

    const v0, -0x737374

    goto :goto_66

    .line 97
    :cond_1d
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    const-string v1, "GuiBase2d"

    invoke-virtual {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isA(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_63

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    const-string v1, "UIBase"

    invoke-virtual {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isA(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_63

    .line 98
    const-string v0, "Model"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5f

    const-string v0, "Folder"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5f

    .line 99
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    const-string v1, "ValueBase"

    invoke-virtual {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isA(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4f

    const v0, -0x719339

    goto :goto_66

    .line 100
    :cond_4f
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isServiceName(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5b

    const v0, -0xb19378

    goto :goto_66

    .line 101
    :cond_5b
    const v0, -0x949495

    goto :goto_66

    .line 98
    :cond_5f
    const v0, -0x365dd9

    goto :goto_66

    .line 97
    :cond_63
    const v0, -0xc05995

    .line 102
    :goto_66
    return v0
.end method

.method public static synthetic general$default(Lcom/exampletest/mobilestudiotest/ui/Icons;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Landroid/graphics/drawable/Drawable;
    .registers 6

    .line 73
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_5

    move-object p3, p2

    :cond_5
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method private final load(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 13
    .param p1, "kind"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;

    .line 43
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getLIGHT()Z

    move-result v0

    .line 44
    .local v0, "light":Z
    if-eqz v0, :cond_b

    const-string v1, "light/"

    goto :goto_d

    :cond_b
    const-string v1, ""

    :goto_d
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 45
    .local v1, "key":Ljava/lang/String;
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    monitor-enter v2

    const/4 v3, 0x0

    .line 46
    .local v3, "$i$a$-synchronized-Icons$load$1\\1\\45\\0":I
    :try_start_2c
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    invoke-virtual {v4, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3e

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    invoke-virtual {v4, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/Bitmap;
    :try_end_3c
    .catchall {:try_start_2c .. :try_end_3c} :catchall_7b

    .end local v3    # "$i$a$-synchronized-Icons$load$1\\1\\45\\0":I
    monitor-exit v2

    return-object v4

    .line 47
    .restart local v3    # "$i$a$-synchronized-Icons$load$1\\1\\45\\0":I
    :cond_3e
    :try_start_3e
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Icons;->dir:Ljava/io/File;

    const/4 v5, 0x0

    if-eqz v4, :cond_5d

    .line 186
    .local v4, "it\\2":Ljava/io/File;
    const/4 v6, 0x0

    .line 47
    .local v6, "$i$a$-let-Icons$load$1$f$1\\2\\47\\1":I
    new-instance v7, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ".png"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v4, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .end local v4    # "it\\2":Ljava/io/File;
    .end local v6    # "$i$a$-let-Icons$load$1$f$1\\2\\47\\1":I
    goto :goto_5e

    :cond_5d
    move-object v7, v5

    .line 48
    .local v7, "f\\1":Ljava/io/File;
    :goto_5e
    if-eqz v7, :cond_71

    invoke-virtual {v7}, Ljava/io/File;->isFile()Z

    move-result v4
    :try_end_64
    .catchall {:try_start_3e .. :try_end_64} :catchall_7b

    if-eqz v4, :cond_71

    :try_start_66
    invoke-virtual {v7}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v4
    :try_end_6e
    .catchall {:try_start_66 .. :try_end_6e} :catchall_70

    move-object v5, v4

    goto :goto_71

    :catchall_70
    move-exception v4

    .line 49
    .local v5, "bmp\\1":Landroid/graphics/Bitmap;
    :cond_71
    :goto_71
    :try_start_71
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    check-cast v4, Ljava/util/Map;

    invoke-interface {v4, v1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_78
    .catchall {:try_start_71 .. :try_end_78} :catchall_7b

    .line 50
    nop

    .end local v3    # "$i$a$-synchronized-Icons$load$1\\1\\45\\0":I
    .end local v5    # "bmp\\1":Landroid/graphics/Bitmap;
    .end local v7    # "f\\1":Ljava/io/File;
    monitor-exit v2

    return-object v5

    :catchall_7b
    move-exception v3

    monitor-exit v2

    throw v3
.end method

.method private final pixelated(Landroid/content/Context;Landroid/graphics/Bitmap;)Landroid/graphics/drawable/BitmapDrawable;
    .registers 7
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "b"    # Landroid/graphics/Bitmap;

    .line 83
    new-instance v0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-direct {v0, v1, p2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    move-object v1, v0

    .line 186
    .local v1, "$this$pixelated_u24lambda_u247\\1":Landroid/graphics/drawable/BitmapDrawable;
    const/4 v2, 0x0

    .line 83
    .local v2, "$i$a$-apply-Icons$pixelated$1\\1\\83\\0":I
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Landroid/graphics/drawable/BitmapDrawable;->setFilterBitmap(Z)V

    .end local v1    # "$this$pixelated_u24lambda_u247\\1":Landroid/graphics/drawable/BitmapDrawable;
    .end local v2    # "$i$a$-apply-Icons$pixelated$1\\1\\83\\0":I
    return-object v0
.end method


# virtual methods
.method public final general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 11
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "fallback"    # Ljava/lang/String;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fallback"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    invoke-virtual {p0, p2}, Lcom/exampletest/mobilestudiotest/ui/Icons;->generalBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_21

    .line 186
    .local v0, "it\\1":Landroid/graphics/Bitmap;
    const/4 v1, 0x0

    .line 74
    .local v1, "$i$a$-let-Icons$general$1\\1\\74\\0":I
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    invoke-direct {v2, p1, v0}, Lcom/exampletest/mobilestudiotest/ui/Icons;->pixelated(Landroid/content/Context;Landroid/graphics/Bitmap;)Landroid/graphics/drawable/BitmapDrawable;

    move-result-object v0

    .end local v0    # "it\\1":Landroid/graphics/Bitmap;
    .end local v1    # "$i$a$-let-Icons$general$1\\1\\74\\0":I
    if-eqz v0, :cond_21

    check-cast v0, Landroid/graphics/drawable/Drawable;

    goto :goto_55

    :cond_21
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;

    invoke-virtual {v0, p2}, Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;->general(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_55

    .line 75
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v0, p2}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isServiceName(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_3b

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->knownClassIcons:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3b

    const/4 v0, 0x0

    goto :goto_41

    :cond_3b
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;

    invoke-virtual {v0, p2}, Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;->instance(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 74
    :goto_41
    if-nez v0, :cond_55

    .line 76
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;

    invoke-direct {p0, p3}, Lcom/exampletest/mobilestudiotest/ui/Icons;->abbrev(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const v3, -0xa59483

    const/4 v4, 0x0

    invoke-direct/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;-><init>(Ljava/lang/String;IZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v0, v1

    check-cast v0, Landroid/graphics/drawable/Drawable;

    :cond_55
    :goto_55
    return-object v0
.end method

.method public final generalBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 3
    .param p1, "name"    # Ljava/lang/String;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    const-string v0, "general"

    invoke-direct {p0, v0, p1}, Lcom/exampletest/mobilestudiotest/ui/Icons;->load(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    return-object v0
.end method

.method public final getInstalled()Z
    .registers 7

    .line 35
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->dir:Ljava/io/File;

    const/4 v1, 0x0

    if-eqz v0, :cond_27

    .line 186
    .local v0, "it\\1":Ljava/io/File;
    const/4 v2, 0x0

    .line 35
    .local v2, "$i$a$-let-Icons$installed$1\\1\\35\\0":I
    new-instance v3, Ljava/io/File;

    const-string v4, "general"

    invoke-direct {v3, v0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->isDirectory()Z

    move-result v3

    const/4 v4, 0x1

    if-nez v3, :cond_23

    new-instance v3, Ljava/io/File;

    const-string v5, "instance"

    invoke-direct {v3, v0, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->isDirectory()Z

    move-result v3

    if-nez v3, :cond_23

    move v0, v1

    goto :goto_24

    :cond_23
    move v0, v4

    .end local v0    # "it\\1":Ljava/io/File;
    .end local v2    # "$i$a$-let-Icons$installed$1\\1\\35\\0":I
    :goto_24
    if-ne v0, v4, :cond_27

    move v1, v4

    :cond_27
    return v1
.end method

.method public final getListeners()Ljava/util/concurrent/CopyOnWriteArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation

    .line 29
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    return-object v0
.end method

.method public final importZip(Landroid/content/Context;Ljava/io/InputStream;)I
    .registers 45
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "input"    # Ljava/io/InputStream;

    move-object/from16 v1, p2

    const-string v0, "ctx"

    move-object/from16 v2, p1

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "input"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 131
    invoke-virtual/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/ui/Icons;->init(Landroid/content/Context;)V

    .line 132
    new-instance v0, Ljava/io/File;

    invoke-virtual {v2}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v3

    const-string v4, "iconpack_import.zip"

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v3, v0

    .local v3, "tmp":Ljava/io/File;
    new-instance v0, Ljava/io/FileOutputStream;

    .line 133
    invoke-direct {v0, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v4, v0

    check-cast v4, Ljava/io/Closeable;

    :try_start_25
    move-object v0, v4

    check-cast v0, Ljava/io/FileOutputStream;

    .line 186
    .local v0, "it\\1":Ljava/io/FileOutputStream;
    const/4 v5, 0x0

    .line 133
    .local v5, "$i$a$-use-Icons$importZip$1\\1\\133\\0":I
    move-object v6, v0

    check-cast v6, Ljava/io/OutputStream;

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v1, v6, v8, v7, v9}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_32
    .catchall {:try_start_25 .. :try_end_32} :catchall_6a6

    .end local v0    # "it\\1":Ljava/io/FileOutputStream;
    .end local v5    # "$i$a$-use-Icons$importZip$1\\1\\133\\0":I
    invoke-static {v4, v9}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 134
    new-instance v0, Lkotlin/text/Regex;

    const-string v4, "(?:^|/)(?:([^/]+)/)?(Dark|Light)/RobloxCustom/(instance|general|ui)/(16x|32x)/200/([^/]+)\\.png$"

    sget-object v5, Lkotlin/text/RegexOption;->IGNORE_CASE:Lkotlin/text/RegexOption;

    invoke-direct {v0, v4, v5}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;Lkotlin/text/RegexOption;)V

    move-object v4, v0

    .line 135
    .local v4, "rx":Lkotlin/text/Regex;
    new-instance v0, Lkotlin/text/Regex;

    const-string v5, "(?:^|/)(instance|general|ui)/(16x|32x)/200/([^/]+)\\.png$"

    sget-object v6, Lkotlin/text/RegexOption;->IGNORE_CASE:Lkotlin/text/RegexOption;

    invoke-direct {v0, v5, v6}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;Lkotlin/text/RegexOption;)V

    move-object v5, v0

    .line 136
    .local v5, "loose":Lkotlin/text/Regex;
    const/4 v6, 0x0

    .line 137
    .local v6, "count":I
    new-instance v0, Ljava/util/zip/ZipFile;

    invoke-direct {v0, v3}, Ljava/util/zip/ZipFile;-><init>(Ljava/io/File;)V

    move-object v10, v0

    check-cast v10, Ljava/io/Closeable;

    :try_start_52
    move-object v0, v10

    check-cast v0, Ljava/util/zip/ZipFile;

    move-object v11, v0

    .local v11, "zip\\2":Ljava/util/zip/ZipFile;
    const/4 v12, 0x0

    .line 139
    .local v12, "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v13, v0

    .line 140
    .local v13, "all\\2":Ljava/util/ArrayList;
    invoke-virtual {v11}, Ljava/util/zip/ZipFile;->entries()Ljava/util/Enumeration;

    move-result-object v0

    const-string v14, "entries(...)"

    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->iterator(Ljava/util/Enumeration;)Ljava/util/Iterator;

    move-result-object v0

    :goto_6a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v14
    :try_end_6e
    .catchall {:try_start_52 .. :try_end_6e} :catchall_698

    if-eqz v14, :cond_17b

    :try_start_70
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/util/zip/ZipEntry;

    move-object/from16 v23, v14

    .line 141
    .local v23, "e\\2":Ljava/util/zip/ZipEntry;
    invoke-virtual/range {v23 .. v23}, Ljava/util/zip/ZipEntry;->isDirectory()Z

    move-result v14

    if-nez v14, :cond_174

    .line 142
    invoke-virtual/range {v23 .. v23}, Ljava/util/zip/ZipEntry;->getName()Ljava/lang/String;

    move-result-object v14

    const-string v15, "getName(...)"

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v21, 0x4

    const/16 v22, 0x0

    const/16 v18, 0x5c

    const/16 v19, 0x2f

    const/16 v20, 0x0

    move-object/from16 v17, v14

    invoke-static/range {v17 .. v22}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;CCZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v14

    .line 143
    .local v14, "n\\2":Ljava/lang/String;
    move-object v15, v14

    check-cast v15, Ljava/lang/CharSequence;

    invoke-static {v4, v15, v8, v7, v9}, Lkotlin/text/Regex;->find$default(Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/text/MatchResult;

    move-result-object v15

    .line 144
    .local v15, "m\\2":Lkotlin/text/MatchResult;
    if-eqz v15, :cond_10a

    .line 145
    new-instance v17, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    invoke-interface {v15}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v8

    const/4 v9, 0x1

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    move-object/from16 v18, v8

    check-cast v18, Ljava/lang/String;

    invoke-interface {v15}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v8

    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    move-object/from16 v19, v8

    check-cast v19, Ljava/lang/String;

    invoke-interface {v15}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v8

    const/4 v9, 0x3

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v8, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "toLowerCase(...)"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v15}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v9

    const/4 v7, 0x4

    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v7, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    const-string v9, "toLowerCase(...)"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v15}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v9

    move-object/from16 v27, v0

    const/4 v0, 0x5

    invoke-interface {v9, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v22, v0

    check-cast v22, Ljava/lang/String;

    invoke-static/range {v23 .. v23}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v21, v7

    move-object/from16 v20, v8

    invoke-direct/range {v17 .. v23}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/zip/ZipEntry;)V

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    goto :goto_16d

    .line 146
    :cond_10a
    move-object/from16 v27, v0

    move-object v0, v14

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v5, v0, v8, v7, v9}, Lkotlin/text/Regex;->find$default(Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/text/MatchResult;

    move-result-object v0

    if-eqz v0, :cond_16d

    .line 186
    .local v0, "l\\3":Lkotlin/text/MatchResult;
    const/4 v7, 0x0

    .line 146
    .local v7, "$i$a$-let-Icons$importZip$2$1\\3\\146\\2":I
    new-instance v17, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    const-string v18, ""

    const-string v19, "Dark"

    invoke-interface {v0}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v8

    const/4 v9, 0x1

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v8, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "toLowerCase(...)"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v0}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v9

    move-object/from16 v24, v0

    const/4 v0, 0x2

    .end local v0    # "l\\3":Lkotlin/text/MatchResult;
    .local v24, "l\\3":Lkotlin/text/MatchResult;
    invoke-interface {v9, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v9, "toLowerCase(...)"

    invoke-static {v0, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface/range {v24 .. v24}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v9

    move-object/from16 v21, v0

    const/4 v0, 0x3

    invoke-interface {v9, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v22, v0

    check-cast v22, Ljava/lang/String;

    invoke-static/range {v23 .. v23}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v20, v8

    invoke-direct/range {v17 .. v23}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/zip/ZipEntry;)V

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-result v0

    .end local v7    # "$i$a$-let-Icons$importZip$2$1\\3\\146\\2":I
    .end local v24    # "l\\3":Lkotlin/text/MatchResult;
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    :try_end_16d
    .catchall {:try_start_70 .. :try_end_16d} :catchall_2a1

    .end local v14    # "n\\2":Ljava/lang/String;
    .end local v15    # "m\\2":Lkotlin/text/MatchResult;
    :cond_16d
    :goto_16d
    move-object/from16 v0, v27

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto/16 :goto_6a

    .line 141
    :cond_174
    move-object/from16 v27, v0

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto/16 :goto_6a

    .line 148
    .end local v23    # "e\\2":Ljava/util/zip/ZipEntry;
    :cond_17b
    :try_start_17b
    invoke-virtual {v13}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_687

    .line 149
    move-object v0, v13

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\4":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 193
    .local v7, "$i$f$filter\\4\\149":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\5":Ljava/util/Collection;
    move-object v9, v0

    .local v9, "$this$filterTo\\5":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 194
    .local v14, "$i$f$filterTo\\5\\193":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_192
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v17
    :try_end_196
    .catchall {:try_start_17b .. :try_end_196} :catchall_698

    if-eqz v17, :cond_1c2

    :try_start_198
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v18, v17

    .local v18, "element\\5":Ljava/lang/Object;
    move-object/from16 v17, v18

    check-cast v17, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    .local v17, "it\\6":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    const/16 v19, 0x0

    .line 149
    .local v19, "$i$a$-filter-Icons$importZip$2$dark$1\\6\\194\\2":I
    move-object/from16 v20, v0

    .end local v0    # "$this$filter\\4":Ljava/lang/Iterable;
    .local v20, "$this$filter\\4":Ljava/lang/Iterable;
    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getTheme()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Dark"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    .line 194
    .end local v17    # "it\\6":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v19    # "$i$a$-filter-Icons$importZip$2$dark$1\\6\\194\\2":I
    if-eqz v0, :cond_1b9

    move-object/from16 v0, v18

    .end local v18    # "element\\5":Ljava/lang/Object;
    .local v0, "element\\5":Ljava/lang/Object;
    invoke-interface {v8, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    :try_end_1b8
    .catchall {:try_start_198 .. :try_end_1b8} :catchall_2a1

    goto :goto_1bb

    .end local v0    # "element\\5":Ljava/lang/Object;
    .restart local v18    # "element\\5":Ljava/lang/Object;
    :cond_1b9
    move-object/from16 v0, v18

    .end local v18    # "element\\5":Ljava/lang/Object;
    .restart local v0    # "element\\5":Ljava/lang/Object;
    :goto_1bb
    move-object/from16 v2, p1

    move-object/from16 v1, p2

    move-object/from16 v0, v20

    goto :goto_192

    .line 195
    .end local v20    # "$this$filter\\4":Ljava/lang/Iterable;
    .local v0, "$this$filter\\4":Ljava/lang/Iterable;
    :cond_1c2
    move-object/from16 v20, v0

    .end local v0    # "$this$filter\\4":Ljava/lang/Iterable;
    .end local v8    # "destination\\5":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\5":Ljava/lang/Iterable;
    .end local v14    # "$i$f$filterTo\\5\\193":I
    .restart local v20    # "$this$filter\\4":Ljava/lang/Iterable;
    :try_start_1c4
    move-object v0, v8

    check-cast v0, Ljava/util/List;

    .line 193
    nop

    .end local v7    # "$i$f$filter\\4\\149":I
    .end local v20    # "$this$filter\\4":Ljava/lang/Iterable;
    check-cast v0, Ljava/util/Collection;

    .line 149
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v1
    :try_end_1ce
    .catchall {:try_start_1c4 .. :try_end_1ce} :catchall_698

    if-eqz v1, :cond_1d5

    .line 186
    const/4 v0, 0x0

    .line 149
    .local v0, "$i$a$-ifEmpty-Icons$importZip$2$dark$2\\7\\149\\2":I
    :try_start_1d1
    move-object v1, v13

    check-cast v1, Ljava/util/List;
    :try_end_1d4
    .catchall {:try_start_1d1 .. :try_end_1d4} :catchall_2a1

    move-object v0, v1

    .end local v0    # "$i$a$-ifEmpty-Icons$importZip$2$dark$2\\7\\149\\2":I
    :cond_1d5
    :try_start_1d5
    check-cast v0, Ljava/util/List;

    move-object v1, v0

    .line 150
    .local v1, "dark\\2":Ljava/util/List;
    move-object v0, v1

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$map\\8":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 196
    .local v2, "$i$f$map\\8\\150":I
    new-instance v7, Ljava/util/ArrayList;

    const/16 v8, 0xa

    invoke-static {v0, v8}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\9":Ljava/util/Collection;
    move-object v8, v0

    .local v8, "$this$mapTo\\9":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 197
    .local v9, "$i$f$mapTo\\9\\196":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_1ef
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v15
    :try_end_1f3
    .catchall {:try_start_1d5 .. :try_end_1f3} :catchall_698

    if-eqz v15, :cond_20b

    :try_start_1f5
    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    .line 198
    .local v15, "item\\9":Ljava/lang/Object;
    move-object/from16 v17, v15

    check-cast v17, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    .local v17, "it\\10":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    const/16 v18, 0x0

    .line 150
    .local v18, "$i$a$-map-Icons$importZip$2$palettes$1\\10\\198\\2":I
    move-object/from16 v19, v0

    .end local v0    # "$this$map\\8":Ljava/lang/Iterable;
    .local v19, "$this$map\\8":Ljava/lang/Iterable;
    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getPalette()Ljava/lang/String;

    move-result-object v0

    .line 198
    .end local v17    # "it\\10":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v18    # "$i$a$-map-Icons$importZip$2$palettes$1\\10\\198\\2":I
    invoke-interface {v7, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    :try_end_208
    .catchall {:try_start_1f5 .. :try_end_208} :catchall_2a1

    move-object/from16 v0, v19

    goto :goto_1ef

    .line 199
    .end local v15    # "item\\9":Ljava/lang/Object;
    .end local v19    # "$this$map\\8":Ljava/lang/Iterable;
    .restart local v0    # "$this$map\\8":Ljava/lang/Iterable;
    :cond_20b
    move-object/from16 v19, v0

    .end local v0    # "$this$map\\8":Ljava/lang/Iterable;
    .end local v7    # "destination\\9":Ljava/util/Collection;
    .end local v8    # "$this$mapTo\\9":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapTo\\9\\196":I
    .restart local v19    # "$this$map\\8":Ljava/lang/Iterable;
    :try_start_20d
    move-object v0, v7

    check-cast v0, Ljava/util/List;

    .line 196
    nop

    .end local v2    # "$i$f$map\\8\\150":I
    .end local v19    # "$this$map\\8":Ljava/lang/Iterable;
    check-cast v0, Ljava/lang/Iterable;

    .line 150
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    move-object v2, v0

    .line 151
    .local v2, "palettes\\2":Ljava/util/List;
    move-object v0, v2

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\11":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 200
    .local v7, "$i$f$firstOrNull\\11\\151":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_220
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9
    :try_end_224
    .catchall {:try_start_20d .. :try_end_224} :catchall_698

    if-eqz v9, :cond_240

    :try_start_226
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\11":Ljava/lang/Object;
    move-object v14, v9

    check-cast v14, Ljava/lang/String;

    .local v14, "it\\12":Ljava/lang/String;
    const/4 v15, 0x0

    .line 151
    .local v15, "$i$a$-firstOrNull-Icons$importZip$2$palette$1\\12\\200\\2":I
    move-object/from16 v17, v0

    .end local v0    # "$this$firstOrNull\\11":Ljava/lang/Iterable;
    .local v17, "$this$firstOrNull\\11":Ljava/lang/Iterable;
    const-string v0, "Colourful"

    move-object/from16 v18, v1

    const/4 v1, 0x1

    .end local v1    # "dark\\2":Ljava/util/List;
    .local v18, "dark\\2":Ljava/util/List;
    invoke-static {v14, v0, v1}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0
    :try_end_239
    .catchall {:try_start_226 .. :try_end_239} :catchall_2a1

    .line 200
    .end local v14    # "it\\12":Ljava/lang/String;
    .end local v15    # "$i$a$-firstOrNull-Icons$importZip$2$palette$1\\12\\200\\2":I
    if-nez v0, :cond_245

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    goto :goto_220

    .line 201
    .end local v9    # "element\\11":Ljava/lang/Object;
    .end local v17    # "$this$firstOrNull\\11":Ljava/lang/Iterable;
    .end local v18    # "dark\\2":Ljava/util/List;
    .restart local v0    # "$this$firstOrNull\\11":Ljava/lang/Iterable;
    .restart local v1    # "dark\\2":Ljava/util/List;
    :cond_240
    move-object/from16 v17, v0

    move-object/from16 v18, v1

    .end local v0    # "$this$firstOrNull\\11":Ljava/lang/Iterable;
    .end local v1    # "dark\\2":Ljava/util/List;
    .restart local v17    # "$this$firstOrNull\\11":Ljava/lang/Iterable;
    .restart local v18    # "dark\\2":Ljava/util/List;
    const/4 v9, 0x0

    .line 151
    .end local v7    # "$i$f$firstOrNull\\11\\151":I
    .end local v17    # "$this$firstOrNull\\11":Ljava/lang/Iterable;
    :cond_245
    :try_start_245
    check-cast v9, Ljava/lang/String;
    :try_end_247
    .catchall {:try_start_245 .. :try_end_247} :catchall_698

    if-nez v9, :cond_250

    :try_start_249
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Ljava/lang/String;
    :try_end_250
    .catchall {:try_start_249 .. :try_end_250} :catchall_2a1

    .line 152
    .local v9, "palette\\2":Ljava/lang/String;
    :cond_250
    :try_start_250
    new-instance v0, Ljava/io/File;

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const-string v7, "iconpack.new"

    invoke-direct {v0, v1, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v1, v0

    .line 153
    .local v1, "out\\2":Ljava/io/File;
    invoke-static {v1}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 155
    const/4 v0, 0x2

    new-array v7, v0, [Lkotlin/Pair;

    const-string v0, ""

    move-object/from16 v8, v18

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$filter\\13":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 202
    .local v14, "$i$f$filter\\13\\155":I
    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    check-cast v15, Ljava/util/Collection;

    .local v15, "destination\\14":Ljava/util/Collection;
    move-object/from16 v17, v8

    .local v17, "$this$filterTo\\14":Ljava/lang/Iterable;
    const/16 v19, 0x0

    .line 203
    .local v19, "$i$f$filterTo\\14\\202":I
    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v20

    :goto_278
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v21
    :try_end_27c
    .catchall {:try_start_250 .. :try_end_27c} :catchall_698

    if-eqz v21, :cond_2ab

    :try_start_27e
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v21

    move-object/from16 v22, v21

    .local v22, "element\\14":Ljava/lang/Object;
    move-object/from16 v21, v22

    check-cast v21, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    .local v21, "it\\15":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    const/16 v23, 0x0

    .line 155
    .local v23, "$i$a$-filter-Icons$importZip$2$sets$1\\15\\203\\2":I
    move-object/from16 v27, v2

    .end local v2    # "palettes\\2":Ljava/util/List;
    .local v27, "palettes\\2":Ljava/util/List;
    invoke-virtual/range {v21 .. v21}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getPalette()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    .line 203
    .end local v21    # "it\\15":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v23    # "$i$a$-filter-Icons$importZip$2$sets$1\\15\\203\\2":I
    if-eqz v2, :cond_29c

    move-object/from16 v2, v22

    .end local v22    # "element\\14":Ljava/lang/Object;
    .local v2, "element\\14":Ljava/lang/Object;
    invoke-interface {v15, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    :try_end_29b
    .catchall {:try_start_27e .. :try_end_29b} :catchall_2a1

    goto :goto_29e

    .end local v2    # "element\\14":Ljava/lang/Object;
    .restart local v22    # "element\\14":Ljava/lang/Object;
    :cond_29c
    move-object/from16 v2, v22

    .end local v22    # "element\\14":Ljava/lang/Object;
    .restart local v2    # "element\\14":Ljava/lang/Object;
    :goto_29e
    move-object/from16 v2, v27

    goto :goto_278

    .line 137
    .end local v1    # "out\\2":Ljava/io/File;
    .end local v2    # "element\\14":Ljava/lang/Object;
    .end local v8    # "$this$filter\\13":Ljava/lang/Iterable;
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v14    # "$i$f$filter\\13\\155":I
    .end local v15    # "destination\\14":Ljava/util/Collection;
    .end local v17    # "$this$filterTo\\14":Ljava/lang/Iterable;
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v19    # "$i$f$filterTo\\14\\202":I
    .end local v27    # "palettes\\2":Ljava/util/List;
    :catchall_2a1
    move-exception v0

    move-object v1, v0

    move-object/from16 v28, v3

    move-object/from16 v29, v4

    move-object/from16 v41, v5

    goto/16 :goto_6a0

    .line 204
    .restart local v1    # "out\\2":Ljava/io/File;
    .local v2, "palettes\\2":Ljava/util/List;
    .restart local v8    # "$this$filter\\13":Ljava/lang/Iterable;
    .restart local v9    # "palette\\2":Ljava/lang/String;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v14    # "$i$f$filter\\13\\155":I
    .restart local v15    # "destination\\14":Ljava/util/Collection;
    .restart local v17    # "$this$filterTo\\14":Ljava/lang/Iterable;
    .restart local v18    # "dark\\2":Ljava/util/List;
    .restart local v19    # "$i$f$filterTo\\14\\202":I
    :cond_2ab
    move-object/from16 v27, v2

    .end local v2    # "palettes\\2":Ljava/util/List;
    .end local v15    # "destination\\14":Ljava/util/Collection;
    .end local v17    # "$this$filterTo\\14":Ljava/lang/Iterable;
    .end local v19    # "$i$f$filterTo\\14\\202":I
    .restart local v27    # "palettes\\2":Ljava/util/List;
    :try_start_2ad
    move-object v2, v15

    check-cast v2, Ljava/util/List;

    .line 202
    nop

    .line 155
    .end local v8    # "$this$filter\\13":Ljava/lang/Iterable;
    .end local v14    # "$i$f$filter\\13\\155":I
    invoke-static {v0, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v25, 0x0

    aput-object v0, v7, v25

    .line 156
    const-string v0, "light/"

    move-object v2, v13

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$filter\\16":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 205
    .local v8, "$i$f$filter\\16\\156":I
    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    check-cast v14, Ljava/util/Collection;

    .local v14, "destination\\17":Ljava/util/Collection;
    move-object v15, v2

    .local v15, "$this$filterTo\\17":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 206
    .local v17, "$i$f$filterTo\\17\\205":I
    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v19

    :goto_2cd
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    move-result v20
    :try_end_2d1
    .catchall {:try_start_2ad .. :try_end_2d1} :catchall_698

    if-eqz v20, :cond_322

    :try_start_2d3
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v20

    move-object/from16 v21, v20

    .local v21, "element\\17":Ljava/lang/Object;
    move-object/from16 v20, v21

    check-cast v20, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    .local v20, "it\\18":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    const/16 v22, 0x0

    .line 156
    .local v22, "$i$a$-filter-Icons$importZip$2$sets$2\\18\\206\\2":I
    move-object/from16 v23, v2

    .end local v2    # "$this$filter\\16":Ljava/lang/Iterable;
    .local v23, "$this$filter\\16":Ljava/lang/Iterable;
    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getTheme()Ljava/lang/String;

    move-result-object v2
    :try_end_2e5
    .catchall {:try_start_2d3 .. :try_end_2e5} :catchall_318

    move-object/from16 v28, v3

    .end local v3    # "tmp":Ljava/io/File;
    .local v28, "tmp":Ljava/io/File;
    :try_start_2e7
    const-string v3, "Light"
    :try_end_2e9
    .catchall {:try_start_2e7 .. :try_end_2e9} :catchall_310

    move-object/from16 v29, v4

    const/4 v4, 0x1

    .end local v4    # "rx":Lkotlin/text/Regex;
    .local v29, "rx":Lkotlin/text/Regex;
    :try_start_2ec
    invoke-static {v2, v3, v4}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_2fe

    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getPalette()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2fe

    const/4 v2, 0x1

    goto :goto_2ff

    :cond_2fe
    const/4 v2, 0x0

    .line 206
    .end local v20    # "it\\18":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v22    # "$i$a$-filter-Icons$importZip$2$sets$2\\18\\206\\2":I
    :goto_2ff
    if-eqz v2, :cond_307

    move-object/from16 v2, v21

    .end local v21    # "element\\17":Ljava/lang/Object;
    .local v2, "element\\17":Ljava/lang/Object;
    invoke-interface {v14, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    :try_end_306
    .catchall {:try_start_2ec .. :try_end_306} :catchall_43c

    goto :goto_309

    .end local v2    # "element\\17":Ljava/lang/Object;
    .restart local v21    # "element\\17":Ljava/lang/Object;
    :cond_307
    move-object/from16 v2, v21

    .end local v21    # "element\\17":Ljava/lang/Object;
    .restart local v2    # "element\\17":Ljava/lang/Object;
    :goto_309
    move-object/from16 v2, v23

    move-object/from16 v3, v28

    move-object/from16 v4, v29

    goto :goto_2cd

    .line 137
    .end local v1    # "out\\2":Ljava/io/File;
    .end local v2    # "element\\17":Ljava/lang/Object;
    .end local v8    # "$i$f$filter\\16\\156":I
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v14    # "destination\\17":Ljava/util/Collection;
    .end local v15    # "$this$filterTo\\17":Ljava/lang/Iterable;
    .end local v17    # "$i$f$filterTo\\17\\205":I
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v23    # "$this$filter\\16":Ljava/lang/Iterable;
    .end local v27    # "palettes\\2":Ljava/util/List;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .restart local v4    # "rx":Lkotlin/text/Regex;
    :catchall_310
    move-exception v0

    move-object/from16 v29, v4

    move-object v1, v0

    move-object/from16 v41, v5

    .end local v4    # "rx":Lkotlin/text/Regex;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    goto/16 :goto_6a0

    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .restart local v3    # "tmp":Ljava/io/File;
    .restart local v4    # "rx":Lkotlin/text/Regex;
    :catchall_318
    move-exception v0

    move-object/from16 v28, v3

    move-object/from16 v29, v4

    move-object v1, v0

    move-object/from16 v41, v5

    .end local v3    # "tmp":Ljava/io/File;
    .end local v4    # "rx":Lkotlin/text/Regex;
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    goto/16 :goto_6a0

    .line 207
    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .restart local v1    # "out\\2":Ljava/io/File;
    .local v2, "$this$filter\\16":Ljava/lang/Iterable;
    .restart local v3    # "tmp":Ljava/io/File;
    .restart local v4    # "rx":Lkotlin/text/Regex;
    .restart local v8    # "$i$f$filter\\16\\156":I
    .restart local v9    # "palette\\2":Ljava/lang/String;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v14    # "destination\\17":Ljava/util/Collection;
    .restart local v15    # "$this$filterTo\\17":Ljava/lang/Iterable;
    .restart local v17    # "$i$f$filterTo\\17\\205":I
    .restart local v18    # "dark\\2":Ljava/util/List;
    .restart local v27    # "palettes\\2":Ljava/util/List;
    :cond_322
    move-object/from16 v23, v2

    move-object/from16 v28, v3

    move-object/from16 v29, v4

    .end local v2    # "$this$filter\\16":Ljava/lang/Iterable;
    .end local v3    # "tmp":Ljava/io/File;
    .end local v4    # "rx":Lkotlin/text/Regex;
    .end local v14    # "destination\\17":Ljava/util/Collection;
    .end local v15    # "$this$filterTo\\17":Ljava/lang/Iterable;
    .end local v17    # "$i$f$filterTo\\17\\205":I
    .restart local v23    # "$this$filter\\16":Ljava/lang/Iterable;
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    :try_start_328
    move-object v2, v14

    check-cast v2, Ljava/util/List;

    .line 205
    nop

    .line 156
    .end local v8    # "$i$f$filter\\16\\156":I
    .end local v23    # "$this$filter\\16":Ljava/lang/Iterable;
    invoke-static {v0, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v24, 0x1

    aput-object v0, v7, v24

    .line 155
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    move-object v2, v0

    .line 157
    .local v2, "sets\\2":Ljava/util/List;
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_33d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_632

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lkotlin/Pair;

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .local v4, "prefix\\2":Ljava/lang/String;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/List;

    const/4 v7, 0x3

    .local v3, "chosen\\2":Ljava/util/List;
    new-array v8, v7, [Ljava/lang/String;

    const-string v14, "instance"

    const/16 v25, 0x0

    aput-object v14, v8, v25

    const-string v14, "general"

    const/16 v24, 0x1

    aput-object v14, v8, v24

    const-string v14, "ui"

    const/16 v26, 0x2

    aput-object v14, v8, v26

    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_372
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_620

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    .line 158
    .local v14, "kind\\2":Ljava/lang/String;
    move-object v15, v3

    check-cast v15, Ljava/lang/Iterable;

    .local v15, "$this$filter\\19":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 208
    .local v16, "$i$f$filter\\19\\158":I
    new-instance v17, Ljava/util/ArrayList;

    invoke-direct/range {v17 .. v17}, Ljava/util/ArrayList;-><init>()V

    check-cast v17, Ljava/util/Collection;

    move-object/from16 v19, v17

    .local v19, "destination\\20":Ljava/util/Collection;
    move-object/from16 v17, v15

    .local v17, "$this$filterTo\\20":Ljava/lang/Iterable;
    const/16 v20, 0x0

    .line 209
    .local v20, "$i$f$filterTo\\20\\208":I
    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v21

    :goto_394
    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->hasNext()Z

    move-result v22
    :try_end_398
    .catchall {:try_start_328 .. :try_end_398} :catchall_682

    if-eqz v22, :cond_3c6

    :try_start_39a
    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v22

    move-object/from16 v23, v22

    .local v23, "element\\20":Ljava/lang/Object;
    move-object/from16 v22, v23

    check-cast v22, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    .local v22, "it\\21":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    const/16 v30, 0x0

    .line 158
    .local v30, "$i$a$-filter-Icons$importZip$2$ofKind$1\\21\\209\\2":I
    invoke-virtual/range {v22 .. v22}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getKind()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    .line 209
    .end local v22    # "it\\21":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v30    # "$i$a$-filter-Icons$importZip$2$ofKind$1\\21\\209\\2":I
    if-eqz v7, :cond_3ba

    move-object/from16 v7, v19

    move-object/from16 v19, v0

    move-object/from16 v0, v23

    .end local v19    # "destination\\20":Ljava/util/Collection;
    .end local v23    # "element\\20":Ljava/lang/Object;
    .local v0, "element\\20":Ljava/lang/Object;
    .local v7, "destination\\20":Ljava/util/Collection;
    invoke-interface {v7, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    :try_end_3b9
    .catchall {:try_start_39a .. :try_end_3b9} :catchall_43c

    goto :goto_3c0

    .end local v0    # "element\\20":Ljava/lang/Object;
    .end local v7    # "destination\\20":Ljava/util/Collection;
    .restart local v19    # "destination\\20":Ljava/util/Collection;
    .restart local v23    # "element\\20":Ljava/lang/Object;
    :cond_3ba
    move-object/from16 v7, v19

    move-object/from16 v19, v0

    move-object/from16 v0, v23

    .end local v19    # "destination\\20":Ljava/util/Collection;
    .end local v23    # "element\\20":Ljava/lang/Object;
    .restart local v0    # "element\\20":Ljava/lang/Object;
    .restart local v7    # "destination\\20":Ljava/util/Collection;
    :goto_3c0
    move-object/from16 v0, v19

    move-object/from16 v19, v7

    const/4 v7, 0x3

    goto :goto_394

    .line 210
    .end local v0    # "element\\20":Ljava/lang/Object;
    .end local v7    # "destination\\20":Ljava/util/Collection;
    .restart local v19    # "destination\\20":Ljava/util/Collection;
    :cond_3c6
    move-object/from16 v7, v19

    move-object/from16 v19, v0

    .end local v17    # "$this$filterTo\\20":Ljava/lang/Iterable;
    .end local v19    # "destination\\20":Ljava/util/Collection;
    .end local v20    # "$i$f$filterTo\\20\\208":I
    :try_start_3ca
    move-object v0, v7

    check-cast v0, Ljava/util/List;

    .line 208
    nop

    .line 158
    .end local v15    # "$this$filter\\19":Ljava/lang/Iterable;
    .end local v16    # "$i$f$filter\\19\\158":I
    move-object v7, v0

    .line 159
    .local v7, "ofKind\\2":Ljava/util/List;
    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_60d

    .line 161
    move-object v0, v7

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$groupBy\\22":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 211
    .local v15, "$i$f$groupBy\\22\\161":I
    new-instance v16, Ljava/util/LinkedHashMap;

    invoke-direct/range {v16 .. v16}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v16, Ljava/util/Map;

    .local v16, "destination\\23":Ljava/util/Map;
    move-object/from16 v17, v0

    .local v17, "$this$groupByTo\\23":Ljava/lang/Iterable;
    const/16 v20, 0x0

    .line 212
    .local v20, "$i$f$groupByTo\\23\\211":I
    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v21

    :goto_3e8
    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->hasNext()Z

    move-result v22
    :try_end_3ec
    .catchall {:try_start_3ca .. :try_end_3ec} :catchall_682

    if-eqz v22, :cond_442

    :try_start_3ee
    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v22

    move-object/from16 v23, v22

    .line 213
    .local v23, "element\\23":Ljava/lang/Object;
    move-object/from16 v22, v23

    check-cast v22, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    .local v22, "it\\24":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    const/16 v30, 0x0

    .line 161
    .local v30, "$i$a$-groupBy-Icons$importZip$2$best$1\\24\\213\\2":I
    invoke-virtual/range {v22 .. v22}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getName()Ljava/lang/String;

    move-result-object v31

    .line 213
    .end local v22    # "it\\24":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v30    # "$i$a$-groupBy-Icons$importZip$2$best$1\\24\\213\\2":I
    move-object/from16 v22, v31

    .line 214
    .local v22, "key\\23":Ljava/lang/Object;
    move-object/from16 v30, v16

    .local v30, "$this$getOrPut\\25":Ljava/util/Map;
    const/16 v31, 0x0

    .line 215
    .local v31, "$i$f$getOrPut\\25\\214":I
    move-object/from16 v32, v0

    move-object/from16 v0, v22

    move-object/from16 v22, v2

    move-object/from16 v2, v30

    .end local v30    # "$this$getOrPut\\25":Ljava/util/Map;
    .local v0, "key\\23":Ljava/lang/Object;
    .local v2, "$this$getOrPut\\25":Ljava/util/Map;
    .local v22, "sets\\2":Ljava/util/List;
    .local v32, "$this$groupBy\\22":Ljava/lang/Iterable;
    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v30

    .line 216
    .local v30, "value\\25":Ljava/lang/Object;
    if-nez v30, :cond_427

    .line 217
    const/16 v33, 0x0

    .line 214
    .local v33, "$i$a$-getOrPut-CollectionsKt___CollectionsKt$groupByTo$list$1\\26\\217\\23":I
    new-instance v34, Ljava/util/ArrayList;

    invoke-direct/range {v34 .. v34}, Ljava/util/ArrayList;-><init>()V

    check-cast v34, Ljava/util/List;

    .line 217
    .end local v33    # "$i$a$-getOrPut-CollectionsKt___CollectionsKt$groupByTo$list$1\\26\\217\\23":I
    move-object/from16 v33, v34

    .line 218
    .local v33, "answer\\25":Ljava/lang/Object;
    move-object/from16 v34, v3

    move-object/from16 v3, v33

    .end local v33    # "answer\\25":Ljava/lang/Object;
    .local v3, "answer\\25":Ljava/lang/Object;
    .local v34, "chosen\\2":Ljava/util/List;
    invoke-interface {v2, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 219
    move-object/from16 v33, v3

    .end local v3    # "answer\\25":Ljava/lang/Object;
    goto :goto_42b

    .line 221
    .end local v34    # "chosen\\2":Ljava/util/List;
    .local v3, "chosen\\2":Ljava/util/List;
    :cond_427
    move-object/from16 v34, v3

    .end local v3    # "chosen\\2":Ljava/util/List;
    .restart local v34    # "chosen\\2":Ljava/util/List;
    move-object/from16 v33, v30

    .line 216
    :goto_42b
    nop

    .line 214
    .end local v2    # "$this$getOrPut\\25":Ljava/util/Map;
    .end local v30    # "value\\25":Ljava/lang/Object;
    .end local v31    # "$i$f$getOrPut\\25\\214":I
    check-cast v33, Ljava/util/List;

    move-object/from16 v2, v33

    .line 222
    .local v2, "list\\23":Ljava/util/List;
    move-object/from16 v3, v23

    .end local v23    # "element\\23":Ljava/lang/Object;
    .local v3, "element\\23":Ljava/lang/Object;
    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_435
    .catchall {:try_start_3ee .. :try_end_435} :catchall_43c

    move-object/from16 v2, v22

    move-object/from16 v0, v32

    move-object/from16 v3, v34

    .end local v0    # "key\\23":Ljava/lang/Object;
    .end local v2    # "list\\23":Ljava/util/List;
    goto :goto_3e8

    .line 137
    .end local v1    # "out\\2":Ljava/io/File;
    .end local v3    # "element\\23":Ljava/lang/Object;
    .end local v4    # "prefix\\2":Ljava/lang/String;
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v14    # "kind\\2":Ljava/lang/String;
    .end local v15    # "$i$f$groupBy\\22\\161":I
    .end local v16    # "destination\\23":Ljava/util/Map;
    .end local v17    # "$this$groupByTo\\23":Ljava/lang/Iterable;
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v20    # "$i$f$groupByTo\\23\\211":I
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v27    # "palettes\\2":Ljava/util/List;
    .end local v32    # "$this$groupBy\\22":Ljava/lang/Iterable;
    .end local v34    # "chosen\\2":Ljava/util/List;
    :catchall_43c
    move-exception v0

    move-object v1, v0

    move-object/from16 v41, v5

    goto/16 :goto_6a0

    .line 224
    .local v0, "$this$groupBy\\22":Ljava/lang/Iterable;
    .restart local v1    # "out\\2":Ljava/io/File;
    .local v2, "sets\\2":Ljava/util/List;
    .local v3, "chosen\\2":Ljava/util/List;
    .restart local v4    # "prefix\\2":Ljava/lang/String;
    .restart local v7    # "ofKind\\2":Ljava/util/List;
    .restart local v9    # "palette\\2":Ljava/lang/String;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v14    # "kind\\2":Ljava/lang/String;
    .restart local v15    # "$i$f$groupBy\\22\\161":I
    .restart local v16    # "destination\\23":Ljava/util/Map;
    .restart local v17    # "$this$groupByTo\\23":Ljava/lang/Iterable;
    .restart local v18    # "dark\\2":Ljava/util/List;
    .restart local v20    # "$i$f$groupByTo\\23\\211":I
    .restart local v27    # "palettes\\2":Ljava/util/List;
    :cond_442
    move-object/from16 v32, v0

    move-object/from16 v22, v2

    move-object/from16 v34, v3

    .line 211
    .end local v0    # "$this$groupBy\\22":Ljava/lang/Iterable;
    .end local v2    # "sets\\2":Ljava/util/List;
    .end local v3    # "chosen\\2":Ljava/util/List;
    .end local v16    # "destination\\23":Ljava/util/Map;
    .end local v17    # "$this$groupByTo\\23":Ljava/lang/Iterable;
    .end local v20    # "$i$f$groupByTo\\23\\211":I
    .restart local v22    # "sets\\2":Ljava/util/List;
    .restart local v32    # "$this$groupBy\\22":Ljava/lang/Iterable;
    .restart local v34    # "chosen\\2":Ljava/util/List;
    nop

    .line 161
    .end local v15    # "$i$f$groupBy\\22\\161":I
    .end local v32    # "$this$groupBy\\22":Ljava/lang/Iterable;
    nop

    .local v16, "$this$mapValues\\27":Ljava/util/Map;
    const/4 v0, 0x0

    .line 225
    .local v0, "$i$f$mapValues\\27\\161":I
    :try_start_44b
    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-interface/range {v16 .. v16}, Ljava/util/Map;->size()I

    move-result v3

    invoke-static {v3}, Lkotlin/collections/MapsKt;->mapCapacity(I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/LinkedHashMap;-><init>(I)V

    check-cast v2, Ljava/util/Map;

    .local v2, "destination\\28":Ljava/util/Map;
    move-object/from16 v3, v16

    .local v3, "$this$mapValuesTo\\28":Ljava/util/Map;
    const/4 v15, 0x0

    .line 226
    .local v15, "$i$f$mapValuesTo\\28\\225":I
    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v17

    check-cast v17, Ljava/lang/Iterable;

    .local v17, "$this$associateByTo\\29":Ljava/lang/Iterable;
    const/16 v20, 0x0

    .line 227
    .local v20, "$i$f$associateByTo\\29\\226":I
    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v21

    :goto_469
    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->hasNext()Z

    move-result v23

    if-eqz v23, :cond_4d8

    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v23

    .line 228
    .local v23, "element\\29":Ljava/lang/Object;
    move-object/from16 v30, v23

    check-cast v30, Ljava/util/Map$Entry;

    .local v30, "it\\30":Ljava/util/Map$Entry;
    const/16 v31, 0x0

    .line 226
    .local v31, "$i$a$-associateByTo-MapsKt__MapsKt$mapValuesTo$1\\30\\228\\28":I
    move/from16 v32, v0

    .end local v0    # "$i$f$mapValues\\27\\161":I
    .local v32, "$i$f$mapValues\\27\\161":I
    invoke-interface/range {v30 .. v30}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    .line 228
    .end local v30    # "it\\30":Ljava/util/Map$Entry;
    .end local v31    # "$i$a$-associateByTo-MapsKt__MapsKt$mapValuesTo$1\\30\\228\\28":I
    move-object/from16 v30, v23

    check-cast v30, Ljava/util/Map$Entry;

    const/16 v31, 0x0

    .local v31, "$i$a$-mapValues-Icons$importZip$2$best$2\\31\\228\\2":I
    invoke-interface/range {v30 .. v30}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v30

    check-cast v30, Ljava/util/List;

    .line 161
    .local v30, "v\\31":Ljava/util/List;
    move-object/from16 v33, v30

    check-cast v33, Ljava/lang/Iterable;

    .local v33, "$this$firstOrNull\\32":Ljava/lang/Iterable;
    const/16 v35, 0x0

    .line 229
    .local v35, "$i$f$firstOrNull\\32\\161":I
    invoke-interface/range {v33 .. v33}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v36

    :goto_495
    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v37

    if-eqz v37, :cond_4ba

    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v37

    .local v37, "element\\32":Ljava/lang/Object;
    move-object/from16 v38, v37

    check-cast v38, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    .local v38, "it\\33":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    const/16 v39, 0x0

    .line 161
    .local v39, "$i$a$-firstOrNull-Icons$importZip$2$best$2$1\\33\\229\\31":I
    move-object/from16 v40, v3

    .end local v3    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .local v40, "$this$mapValuesTo\\28":Ljava/util/Map;
    invoke-virtual/range {v38 .. v38}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getRes()Ljava/lang/String;

    move-result-object v3
    :try_end_4ab
    .catchall {:try_start_44b .. :try_end_4ab} :catchall_682

    move-object/from16 v41, v5

    .end local v5    # "loose":Lkotlin/text/Regex;
    .local v41, "loose":Lkotlin/text/Regex;
    :try_start_4ad
    const-string v5, "32x"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    .line 229
    .end local v38    # "it\\33":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v39    # "$i$a$-firstOrNull-Icons$importZip$2$best$2$1\\33\\229\\31":I
    if-nez v3, :cond_4c0

    move-object/from16 v3, v40

    move-object/from16 v5, v41

    goto :goto_495

    .line 230
    .end local v37    # "element\\32":Ljava/lang/Object;
    .end local v40    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .restart local v3    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .restart local v5    # "loose":Lkotlin/text/Regex;
    :cond_4ba
    move-object/from16 v40, v3

    move-object/from16 v41, v5

    .end local v3    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .end local v5    # "loose":Lkotlin/text/Regex;
    .restart local v40    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    const/16 v37, 0x0

    .line 161
    .end local v33    # "$this$firstOrNull\\32":Ljava/lang/Iterable;
    .end local v35    # "$i$f$firstOrNull\\32\\161":I
    :cond_4c0
    check-cast v37, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    if-nez v37, :cond_4cc

    invoke-static/range {v30 .. v30}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v37, v3

    check-cast v37, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    :cond_4cc
    move-object/from16 v3, v37

    .line 228
    .end local v30    # "v\\31":Ljava/util/List;
    .end local v31    # "$i$a$-mapValues-Icons$importZip$2$best$2\\31\\228\\2":I
    invoke-interface {v2, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move/from16 v0, v32

    move-object/from16 v3, v40

    move-object/from16 v5, v41

    goto :goto_469

    .line 231
    .end local v23    # "element\\29":Ljava/lang/Object;
    .end local v32    # "$i$f$mapValues\\27\\161":I
    .end local v40    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .restart local v0    # "$i$f$mapValues\\27\\161":I
    .restart local v3    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .restart local v5    # "loose":Lkotlin/text/Regex;
    :cond_4d8
    move/from16 v32, v0

    move-object/from16 v40, v3

    move-object/from16 v41, v5

    .line 226
    .end local v0    # "$i$f$mapValues\\27\\161":I
    .end local v3    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .end local v5    # "loose":Lkotlin/text/Regex;
    .end local v17    # "$this$associateByTo\\29":Ljava/lang/Iterable;
    .end local v20    # "$i$f$associateByTo\\29\\226":I
    .restart local v32    # "$i$f$mapValues\\27\\161":I
    .restart local v40    # "$this$mapValuesTo\\28":Ljava/util/Map;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    nop

    .line 225
    .end local v2    # "destination\\28":Ljava/util/Map;
    .end local v15    # "$i$f$mapValuesTo\\28\\225":I
    .end local v40    # "$this$mapValuesTo\\28":Ljava/util/Map;
    nop

    .line 161
    .end local v16    # "$this$mapValues\\27":Ljava/util/Map;
    .end local v32    # "$i$f$mapValues\\27\\161":I
    nop

    .line 162
    .local v2, "best\\2":Ljava/util/Map;
    new-instance v0, Ljava/io/File;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v1, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v3, v0

    .line 186
    .local v3, "it\\34":Ljava/io/File;
    const/4 v5, 0x0

    .line 162
    .local v5, "$i$a$-also-Icons$importZip$2$d$1\\34\\162\\2":I
    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    .end local v3    # "it\\34":Ljava/io/File;
    .end local v5    # "$i$a$-also-Icons$importZip$2$d$1\\34\\162\\2":I
    move-object v3, v0

    .line 163
    .local v3, "d\\2":Ljava/io/File;
    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0
    :try_end_505
    .catchall {:try_start_4ad .. :try_end_505} :catchall_695

    :goto_505
    :try_start_505
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_5f0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map$Entry;

    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    .local v15, "name\\2":Ljava/lang/String;
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;

    .line 164
    .local v5, "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    move-object/from16 v16, v0

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->getEntry()Ljava/util/zip/ZipEntry;

    move-result-object v0

    invoke-virtual {v11, v0}, Ljava/util/zip/ZipFile;->getInputStream(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;

    move-result-object v0

    move-object/from16 v17, v2

    .end local v2    # "best\\2":Ljava/util/Map;
    .local v17, "best\\2":Ljava/util/Map;
    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;
    :try_end_52c
    .catchall {:try_start_505 .. :try_end_52c} :catchall_607

    :try_start_52c
    move-object v0, v2

    check-cast v0, Ljava/io/InputStream;

    move-object/from16 v20, v0

    .line 186
    .local v20, "ins\\35":Ljava/io/InputStream;
    const/16 v21, 0x0

    .local v21, "$i$a$-use-Icons$importZip$2$2\\35\\164\\2":I
    new-instance v0, Ljava/io/FileOutputStream;
    :try_end_535
    .catchall {:try_start_52c .. :try_end_535} :catchall_5d8

    .line 164
    move-object/from16 v23, v4

    .end local v4    # "prefix\\2":Ljava/lang/String;
    .local v23, "prefix\\2":Ljava/lang/String;
    :try_start_537
    new-instance v4, Ljava/io/File;
    :try_end_539
    .catchall {:try_start_537 .. :try_end_539} :catchall_5cd

    move-object/from16 v30, v5

    .end local v5    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .local v30, "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    :try_start_53b
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5
    :try_end_544
    .catchall {:try_start_53b .. :try_end_544} :catchall_5c4

    move/from16 v31, v6

    .end local v6    # "count":I
    .local v31, "count":I
    :try_start_546
    const-string v6, ".png"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v4, v0

    check-cast v4, Ljava/io/Closeable;
    :try_end_559
    .catchall {:try_start_546 .. :try_end_559} :catchall_5bd

    :try_start_559
    move-object v0, v4

    check-cast v0, Ljava/io/FileOutputStream;

    .line 186
    .local v0, "it\\36":Ljava/io/FileOutputStream;
    const/4 v5, 0x0

    .line 164
    .local v5, "$i$a$-use-Icons$importZip$2$2$1\\36\\164\\35":I
    invoke-static/range {v20 .. v20}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v6, v0

    check-cast v6, Ljava/io/OutputStream;
    :try_end_563
    .catchall {:try_start_559 .. :try_end_563} :catchall_5aa

    move-object/from16 v25, v20

    move-object/from16 v20, v3

    move-object/from16 v3, v25

    move-object/from16 v32, v0

    move/from16 v25, v5

    move-object/from16 v26, v7

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v7, 0x0

    .end local v0    # "it\\36":Ljava/io/FileOutputStream;
    .end local v5    # "$i$a$-use-Icons$importZip$2$2$1\\36\\164\\35":I
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .local v3, "ins\\35":Ljava/io/InputStream;
    .local v20, "d\\2":Ljava/io/File;
    .local v25, "$i$a$-use-Icons$importZip$2$2$1\\36\\164\\35":I
    .local v26, "ofKind\\2":Ljava/util/List;
    .local v32, "it\\36":Ljava/io/FileOutputStream;
    :try_start_572
    invoke-static {v3, v6, v0, v5, v7}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_575
    .catchall {:try_start_572 .. :try_end_575} :catchall_5a7

    .end local v25    # "$i$a$-use-Icons$importZip$2$2$1\\36\\164\\35":I
    .end local v32    # "it\\36":Ljava/io/FileOutputStream;
    :try_start_575
    invoke-static {v4, v7}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_578
    .catchall {:try_start_575 .. :try_end_578} :catchall_5ba

    .end local v3    # "ins\\35":Ljava/io/InputStream;
    .end local v21    # "$i$a$-use-Icons$importZip$2$2\\35\\164\\2":I
    :try_start_578
    invoke-static {v2, v7}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 165
    move-object/from16 v2, v23

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2
    :try_end_583
    .catchall {:try_start_578 .. :try_end_583} :catchall_5ea

    if-nez v2, :cond_588

    move/from16 v2, v24

    goto :goto_589

    :cond_588
    move v2, v0

    :goto_589
    if-eqz v2, :cond_599

    add-int/lit8 v6, v31, 0x1

    move-object/from16 v0, v16

    move-object/from16 v2, v17

    move-object/from16 v3, v20

    move-object/from16 v4, v23

    move-object/from16 v7, v26

    .end local v15    # "name\\2":Ljava/lang/String;
    .end local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v31    # "count":I
    .restart local v6    # "count":I
    goto/16 :goto_505

    .end local v6    # "count":I
    .restart local v15    # "name\\2":Ljava/lang/String;
    .restart local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .restart local v31    # "count":I
    :cond_599
    move-object/from16 v0, v16

    move-object/from16 v2, v17

    move-object/from16 v3, v20

    move-object/from16 v4, v23

    move-object/from16 v7, v26

    move/from16 v6, v31

    goto/16 :goto_505

    .line 164
    .restart local v3    # "ins\\35":Ljava/io/InputStream;
    .restart local v21    # "$i$a$-use-Icons$importZip$2$2\\35\\164\\2":I
    :catchall_5a7
    move-exception v0

    move-object v5, v0

    goto :goto_5b4

    .end local v26    # "ofKind\\2":Ljava/util/List;
    .local v3, "d\\2":Ljava/io/File;
    .restart local v7    # "ofKind\\2":Ljava/util/List;
    .local v20, "ins\\35":Ljava/io/InputStream;
    :catchall_5aa
    move-exception v0

    move-object/from16 v26, v20

    move-object/from16 v20, v3

    move-object/from16 v3, v26

    move-object/from16 v26, v7

    move-object v5, v0

    .end local v1    # "out\\2":Ljava/io/File;
    .end local v3    # "d\\2":Ljava/io/File;
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v14    # "kind\\2":Ljava/lang/String;
    .end local v15    # "name\\2":Ljava/lang/String;
    .end local v17    # "best\\2":Ljava/util/Map;
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v20    # "ins\\35":Ljava/io/InputStream;
    .end local v21    # "$i$a$-use-Icons$importZip$2$2\\35\\164\\2":I
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v23    # "prefix\\2":Ljava/lang/String;
    .end local v27    # "palettes\\2":Ljava/util/List;
    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .end local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v31    # "count":I
    .end local v34    # "chosen\\2":Ljava/util/List;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "input":Ljava/io/InputStream;
    :goto_5b4
    :try_start_5b4
    throw v5
    :try_end_5b5
    .catchall {:try_start_5b4 .. :try_end_5b5} :catchall_5b5

    .restart local v1    # "out\\2":Ljava/io/File;
    .local v3, "ins\\35":Ljava/io/InputStream;
    .restart local v9    # "palette\\2":Ljava/lang/String;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v14    # "kind\\2":Ljava/lang/String;
    .restart local v15    # "name\\2":Ljava/lang/String;
    .restart local v17    # "best\\2":Ljava/util/Map;
    .restart local v18    # "dark\\2":Ljava/util/List;
    .local v20, "d\\2":Ljava/io/File;
    .restart local v21    # "$i$a$-use-Icons$importZip$2$2\\35\\164\\2":I
    .restart local v22    # "sets\\2":Ljava/util/List;
    .restart local v23    # "prefix\\2":Ljava/lang/String;
    .restart local v26    # "ofKind\\2":Ljava/util/List;
    .restart local v27    # "palettes\\2":Ljava/util/List;
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    .restart local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .restart local v31    # "count":I
    .restart local v34    # "chosen\\2":Ljava/util/List;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    .restart local p1    # "ctx":Landroid/content/Context;
    .restart local p2    # "input":Ljava/io/InputStream;
    :catchall_5b5
    move-exception v0

    :try_start_5b6
    invoke-static {v4, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v1    # "out\\2":Ljava/io/File;
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v14    # "kind\\2":Ljava/lang/String;
    .end local v15    # "name\\2":Ljava/lang/String;
    .end local v17    # "best\\2":Ljava/util/Map;
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v20    # "d\\2":Ljava/io/File;
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v23    # "prefix\\2":Ljava/lang/String;
    .end local v26    # "ofKind\\2":Ljava/util/List;
    .end local v27    # "palettes\\2":Ljava/util/List;
    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .end local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v31    # "count":I
    .end local v34    # "chosen\\2":Ljava/util/List;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "input":Ljava/io/InputStream;
    throw v0
    :try_end_5ba
    .catchall {:try_start_5b6 .. :try_end_5ba} :catchall_5ba

    .end local v3    # "ins\\35":Ljava/io/InputStream;
    .end local v21    # "$i$a$-use-Icons$importZip$2$2\\35\\164\\2":I
    .restart local v1    # "out\\2":Ljava/io/File;
    .restart local v9    # "palette\\2":Ljava/lang/String;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v14    # "kind\\2":Ljava/lang/String;
    .restart local v15    # "name\\2":Ljava/lang/String;
    .restart local v17    # "best\\2":Ljava/util/Map;
    .restart local v18    # "dark\\2":Ljava/util/List;
    .restart local v20    # "d\\2":Ljava/io/File;
    .restart local v22    # "sets\\2":Ljava/util/List;
    .restart local v23    # "prefix\\2":Ljava/lang/String;
    .restart local v26    # "ofKind\\2":Ljava/util/List;
    .restart local v27    # "palettes\\2":Ljava/util/List;
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    .restart local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .restart local v31    # "count":I
    .restart local v34    # "chosen\\2":Ljava/util/List;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    .restart local p1    # "ctx":Landroid/content/Context;
    .restart local p2    # "input":Ljava/io/InputStream;
    :catchall_5ba
    move-exception v0

    move-object v3, v0

    goto :goto_5e4

    .end local v20    # "d\\2":Ljava/io/File;
    .end local v26    # "ofKind\\2":Ljava/util/List;
    .local v3, "d\\2":Ljava/io/File;
    .restart local v7    # "ofKind\\2":Ljava/util/List;
    :catchall_5bd
    move-exception v0

    move-object/from16 v20, v3

    move-object/from16 v26, v7

    move-object v3, v0

    .end local v3    # "d\\2":Ljava/io/File;
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .restart local v20    # "d\\2":Ljava/io/File;
    .restart local v26    # "ofKind\\2":Ljava/util/List;
    goto :goto_5e4

    .end local v20    # "d\\2":Ljava/io/File;
    .end local v26    # "ofKind\\2":Ljava/util/List;
    .end local v31    # "count":I
    .restart local v3    # "d\\2":Ljava/io/File;
    .restart local v6    # "count":I
    .restart local v7    # "ofKind\\2":Ljava/util/List;
    :catchall_5c4
    move-exception v0

    move-object/from16 v20, v3

    move/from16 v31, v6

    move-object/from16 v26, v7

    move-object v3, v0

    .end local v3    # "d\\2":Ljava/io/File;
    .end local v6    # "count":I
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .restart local v20    # "d\\2":Ljava/io/File;
    .restart local v26    # "ofKind\\2":Ljava/util/List;
    .restart local v31    # "count":I
    goto :goto_5e4

    .end local v20    # "d\\2":Ljava/io/File;
    .end local v26    # "ofKind\\2":Ljava/util/List;
    .end local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v31    # "count":I
    .restart local v3    # "d\\2":Ljava/io/File;
    .local v5, "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .restart local v6    # "count":I
    .restart local v7    # "ofKind\\2":Ljava/util/List;
    :catchall_5cd
    move-exception v0

    move-object/from16 v20, v3

    move-object/from16 v30, v5

    move/from16 v31, v6

    move-object/from16 v26, v7

    move-object v3, v0

    .end local v3    # "d\\2":Ljava/io/File;
    .end local v5    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v6    # "count":I
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .restart local v20    # "d\\2":Ljava/io/File;
    .restart local v26    # "ofKind\\2":Ljava/util/List;
    .restart local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .restart local v31    # "count":I
    goto :goto_5e4

    .end local v20    # "d\\2":Ljava/io/File;
    .end local v23    # "prefix\\2":Ljava/lang/String;
    .end local v26    # "ofKind\\2":Ljava/util/List;
    .end local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v31    # "count":I
    .restart local v3    # "d\\2":Ljava/io/File;
    .restart local v4    # "prefix\\2":Ljava/lang/String;
    .restart local v5    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .restart local v6    # "count":I
    .restart local v7    # "ofKind\\2":Ljava/util/List;
    :catchall_5d8
    move-exception v0

    move-object/from16 v20, v3

    move-object/from16 v23, v4

    move-object/from16 v30, v5

    move/from16 v31, v6

    move-object/from16 v26, v7

    move-object v3, v0

    .end local v1    # "out\\2":Ljava/io/File;
    .end local v3    # "d\\2":Ljava/io/File;
    .end local v4    # "prefix\\2":Ljava/lang/String;
    .end local v5    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v6    # "count":I
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v14    # "kind\\2":Ljava/lang/String;
    .end local v15    # "name\\2":Ljava/lang/String;
    .end local v17    # "best\\2":Ljava/util/Map;
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v27    # "palettes\\2":Ljava/util/List;
    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .end local v34    # "chosen\\2":Ljava/util/List;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "input":Ljava/io/InputStream;
    :goto_5e4
    :try_start_5e4
    throw v3
    :try_end_5e5
    .catchall {:try_start_5e4 .. :try_end_5e5} :catchall_5e5

    .restart local v1    # "out\\2":Ljava/io/File;
    .restart local v9    # "palette\\2":Ljava/lang/String;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v14    # "kind\\2":Ljava/lang/String;
    .restart local v15    # "name\\2":Ljava/lang/String;
    .restart local v17    # "best\\2":Ljava/util/Map;
    .restart local v18    # "dark\\2":Ljava/util/List;
    .restart local v20    # "d\\2":Ljava/io/File;
    .restart local v22    # "sets\\2":Ljava/util/List;
    .restart local v23    # "prefix\\2":Ljava/lang/String;
    .restart local v26    # "ofKind\\2":Ljava/util/List;
    .restart local v27    # "palettes\\2":Ljava/util/List;
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    .restart local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .restart local v31    # "count":I
    .restart local v34    # "chosen\\2":Ljava/util/List;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    .restart local p1    # "ctx":Landroid/content/Context;
    .restart local p2    # "input":Ljava/io/InputStream;
    :catchall_5e5
    move-exception v0

    :try_start_5e6
    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .end local v31    # "count":I
    .end local v41    # "loose":Lkotlin/text/Regex;
    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "input":Ljava/io/InputStream;
    throw v0
    :try_end_5ea
    .catchall {:try_start_5e6 .. :try_end_5ea} :catchall_5ea

    .line 137
    .end local v1    # "out\\2":Ljava/io/File;
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v14    # "kind\\2":Ljava/lang/String;
    .end local v15    # "name\\2":Ljava/lang/String;
    .end local v17    # "best\\2":Ljava/util/Map;
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v20    # "d\\2":Ljava/io/File;
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v23    # "prefix\\2":Ljava/lang/String;
    .end local v26    # "ofKind\\2":Ljava/util/List;
    .end local v27    # "palettes\\2":Ljava/util/List;
    .end local v30    # "e\\2":Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
    .end local v34    # "chosen\\2":Ljava/util/List;
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    .restart local v31    # "count":I
    .restart local v41    # "loose":Lkotlin/text/Regex;
    .restart local p1    # "ctx":Landroid/content/Context;
    .restart local p2    # "input":Ljava/io/InputStream;
    :catchall_5ea
    move-exception v0

    move-object v1, v0

    move/from16 v6, v31

    goto/16 :goto_6a0

    .line 163
    .end local v31    # "count":I
    .restart local v1    # "out\\2":Ljava/io/File;
    .restart local v2    # "best\\2":Ljava/util/Map;
    .restart local v3    # "d\\2":Ljava/io/File;
    .restart local v4    # "prefix\\2":Ljava/lang/String;
    .restart local v6    # "count":I
    .restart local v7    # "ofKind\\2":Ljava/util/List;
    .restart local v9    # "palette\\2":Ljava/lang/String;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v14    # "kind\\2":Ljava/lang/String;
    .restart local v18    # "dark\\2":Ljava/util/List;
    .restart local v22    # "sets\\2":Ljava/util/List;
    .restart local v27    # "palettes\\2":Ljava/util/List;
    .restart local v34    # "chosen\\2":Ljava/util/List;
    :cond_5f0
    move-object/from16 v17, v2

    move-object/from16 v20, v3

    move-object/from16 v23, v4

    move/from16 v31, v6

    move-object/from16 v26, v7

    const/4 v0, 0x0

    const/4 v5, 0x2

    .end local v2    # "best\\2":Ljava/util/Map;
    .end local v3    # "d\\2":Ljava/io/File;
    .end local v4    # "prefix\\2":Ljava/lang/String;
    .end local v6    # "count":I
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .restart local v17    # "best\\2":Ljava/util/Map;
    .restart local v20    # "d\\2":Ljava/io/File;
    .restart local v23    # "prefix\\2":Ljava/lang/String;
    .restart local v26    # "ofKind\\2":Ljava/util/List;
    .restart local v31    # "count":I
    move-object/from16 v0, v19

    move-object/from16 v2, v22

    move-object/from16 v3, v34

    move-object/from16 v5, v41

    const/4 v7, 0x3

    goto/16 :goto_372

    .line 137
    .end local v1    # "out\\2":Ljava/io/File;
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v14    # "kind\\2":Ljava/lang/String;
    .end local v17    # "best\\2":Ljava/util/Map;
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v20    # "d\\2":Ljava/io/File;
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v23    # "prefix\\2":Ljava/lang/String;
    .end local v26    # "ofKind\\2":Ljava/util/List;
    .end local v27    # "palettes\\2":Ljava/util/List;
    .end local v31    # "count":I
    .end local v34    # "chosen\\2":Ljava/util/List;
    .restart local v6    # "count":I
    :catchall_607
    move-exception v0

    move/from16 v31, v6

    move-object v1, v0

    .end local v6    # "count":I
    .restart local v31    # "count":I
    goto/16 :goto_6a0

    .line 159
    .end local v31    # "count":I
    .end local v41    # "loose":Lkotlin/text/Regex;
    .restart local v1    # "out\\2":Ljava/io/File;
    .local v2, "sets\\2":Ljava/util/List;
    .local v3, "chosen\\2":Ljava/util/List;
    .restart local v4    # "prefix\\2":Ljava/lang/String;
    .local v5, "loose":Lkotlin/text/Regex;
    .restart local v6    # "count":I
    .restart local v7    # "ofKind\\2":Ljava/util/List;
    .restart local v9    # "palette\\2":Ljava/lang/String;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v14    # "kind\\2":Ljava/lang/String;
    .restart local v18    # "dark\\2":Ljava/util/List;
    .restart local v27    # "palettes\\2":Ljava/util/List;
    :cond_60d
    move-object/from16 v22, v2

    move-object/from16 v34, v3

    move-object/from16 v23, v4

    move-object/from16 v41, v5

    move-object/from16 v26, v7

    const/4 v0, 0x0

    const/4 v5, 0x2

    .end local v2    # "sets\\2":Ljava/util/List;
    .end local v3    # "chosen\\2":Ljava/util/List;
    .end local v4    # "prefix\\2":Ljava/lang/String;
    .end local v5    # "loose":Lkotlin/text/Regex;
    .end local v7    # "ofKind\\2":Ljava/util/List;
    .restart local v22    # "sets\\2":Ljava/util/List;
    .restart local v23    # "prefix\\2":Ljava/lang/String;
    .restart local v26    # "ofKind\\2":Ljava/util/List;
    .restart local v34    # "chosen\\2":Ljava/util/List;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    move-object/from16 v0, v19

    move-object/from16 v5, v41

    const/4 v7, 0x3

    goto/16 :goto_372

    .line 157
    .end local v14    # "kind\\2":Ljava/lang/String;
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v23    # "prefix\\2":Ljava/lang/String;
    .end local v26    # "ofKind\\2":Ljava/util/List;
    .end local v34    # "chosen\\2":Ljava/util/List;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .restart local v2    # "sets\\2":Ljava/util/List;
    .restart local v3    # "chosen\\2":Ljava/util/List;
    .restart local v4    # "prefix\\2":Ljava/lang/String;
    .restart local v5    # "loose":Lkotlin/text/Regex;
    :cond_620
    move-object/from16 v19, v0

    move-object/from16 v22, v2

    move-object/from16 v34, v3

    move-object/from16 v23, v4

    move-object/from16 v41, v5

    const/4 v0, 0x0

    const/4 v5, 0x2

    .end local v2    # "sets\\2":Ljava/util/List;
    .end local v3    # "chosen\\2":Ljava/util/List;
    .end local v4    # "prefix\\2":Ljava/lang/String;
    .end local v5    # "loose":Lkotlin/text/Regex;
    .restart local v22    # "sets\\2":Ljava/util/List;
    .restart local v23    # "prefix\\2":Ljava/lang/String;
    .restart local v34    # "chosen\\2":Ljava/util/List;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    move-object/from16 v0, v19

    move-object/from16 v5, v41

    goto/16 :goto_33d

    .line 168
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v23    # "prefix\\2":Ljava/lang/String;
    .end local v34    # "chosen\\2":Ljava/util/List;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .restart local v2    # "sets\\2":Ljava/util/List;
    .restart local v5    # "loose":Lkotlin/text/Regex;
    :cond_632
    move-object/from16 v22, v2

    move-object/from16 v41, v5

    .end local v2    # "sets\\2":Ljava/util/List;
    .end local v5    # "loose":Lkotlin/text/Regex;
    .restart local v22    # "sets\\2":Ljava/util/List;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    :try_start_636
    new-instance v0, Ljava/io/File;

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "iconpack"

    invoke-direct {v0, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 169
    .local v0, "target\\2":Ljava/io/File;
    invoke-static {v0}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 170
    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    .line 171
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->dir:Ljava/io/File;

    .line 172
    nop

    .end local v0    # "target\\2":Ljava/io/File;
    .end local v1    # "out\\2":Ljava/io/File;
    .end local v9    # "palette\\2":Ljava/lang/String;
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .end local v18    # "dark\\2":Ljava/util/List;
    .end local v22    # "sets\\2":Ljava/util/List;
    .end local v27    # "palettes\\2":Ljava/util/List;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_64e
    .catchall {:try_start_636 .. :try_end_64e} :catchall_695

    .line 137
    const/4 v7, 0x0

    invoke-static {v10, v7}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 173
    invoke-virtual/range {v28 .. v28}, Ljava/io/File;->delete()Z

    .line 174
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    monitor-enter v1

    .line 186
    const/4 v0, 0x0

    .line 174
    .local v0, "$i$a$-synchronized-Icons$importZip$3\\37\\174\\0":I
    :try_start_659
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    .end local v0    # "$i$a$-synchronized-Icons$importZip$3\\37\\174\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_660
    .catchall {:try_start_659 .. :try_end_660} :catchall_67f

    monitor-exit v1

    .line 175
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\38":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 232
    .local v1, "$i$f$forEach\\38\\175":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_66a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_67d

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\38":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lkotlin/jvm/functions/Function0;

    .local v4, "it\\39":Lkotlin/jvm/functions/Function0;
    const/4 v5, 0x0

    .line 175
    .local v5, "$i$a$-forEach-Icons$importZip$4\\39\\232\\0":I
    invoke-interface {v4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 232
    .end local v4    # "it\\39":Lkotlin/jvm/functions/Function0;
    .end local v5    # "$i$a$-forEach-Icons$importZip$4\\39\\232\\0":I
    nop

    .end local v3    # "element\\38":Ljava/lang/Object;
    goto :goto_66a

    .line 233
    :cond_67d
    nop

    .line 176
    .end local v0    # "$this$forEach\\38":Ljava/lang/Iterable;
    .end local v1    # "$i$f$forEach\\38\\175":I
    return v6

    .line 174
    :catchall_67f
    move-exception v0

    monitor-exit v1

    throw v0

    .line 137
    .end local v41    # "loose":Lkotlin/text/Regex;
    .local v5, "loose":Lkotlin/text/Regex;
    :catchall_682
    move-exception v0

    move-object/from16 v41, v5

    move-object v1, v0

    .end local v5    # "loose":Lkotlin/text/Regex;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    goto :goto_6a0

    .line 148
    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .local v3, "tmp":Ljava/io/File;
    .local v4, "rx":Lkotlin/text/Regex;
    .restart local v5    # "loose":Lkotlin/text/Regex;
    .restart local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .restart local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .restart local v13    # "all\\2":Ljava/util/ArrayList;
    :cond_687
    move-object/from16 v28, v3

    move-object/from16 v29, v4

    move-object/from16 v41, v5

    .end local v3    # "tmp":Ljava/io/File;
    .end local v4    # "rx":Lkotlin/text/Regex;
    .end local v5    # "loose":Lkotlin/text/Regex;
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    :try_start_68d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "No Vanilla icons found in this zip. Pick the \"Vanilla 3 for Roblox Studio\" zip from itch.io."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v6    # "count":I
    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "input":Ljava/io/InputStream;
    throw v0
    :try_end_695
    .catchall {:try_start_68d .. :try_end_695} :catchall_695

    .line 137
    .end local v11    # "zip\\2":Ljava/util/zip/ZipFile;
    .end local v12    # "$i$a$-use-Icons$importZip$2\\2\\137\\0":I
    .end local v13    # "all\\2":Ljava/util/ArrayList;
    .restart local v6    # "count":I
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    .restart local p1    # "ctx":Landroid/content/Context;
    .restart local p2    # "input":Ljava/io/InputStream;
    :catchall_695
    move-exception v0

    move-object v1, v0

    goto :goto_6a0

    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .restart local v3    # "tmp":Ljava/io/File;
    .restart local v4    # "rx":Lkotlin/text/Regex;
    .restart local v5    # "loose":Lkotlin/text/Regex;
    :catchall_698
    move-exception v0

    move-object/from16 v28, v3

    move-object/from16 v29, v4

    move-object/from16 v41, v5

    move-object v1, v0

    .end local v3    # "tmp":Ljava/io/File;
    .end local v4    # "rx":Lkotlin/text/Regex;
    .end local v5    # "loose":Lkotlin/text/Regex;
    .end local v6    # "count":I
    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "input":Ljava/io/InputStream;
    :goto_6a0
    :try_start_6a0
    throw v1
    :try_end_6a1
    .catchall {:try_start_6a0 .. :try_end_6a1} :catchall_6a1

    .restart local v6    # "count":I
    .restart local v28    # "tmp":Ljava/io/File;
    .restart local v29    # "rx":Lkotlin/text/Regex;
    .restart local v41    # "loose":Lkotlin/text/Regex;
    .restart local p1    # "ctx":Landroid/content/Context;
    .restart local p2    # "input":Ljava/io/InputStream;
    :catchall_6a1
    move-exception v0

    invoke-static {v10, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    .line 133
    .end local v6    # "count":I
    .end local v28    # "tmp":Ljava/io/File;
    .end local v29    # "rx":Lkotlin/text/Regex;
    .end local v41    # "loose":Lkotlin/text/Regex;
    .restart local v3    # "tmp":Ljava/io/File;
    :catchall_6a6
    move-exception v0

    move-object/from16 v28, v3

    move-object v1, v0

    .end local v3    # "tmp":Ljava/io/File;
    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "input":Ljava/io/InputStream;
    :try_start_6aa
    throw v1
    :try_end_6ab
    .catchall {:try_start_6aa .. :try_end_6ab} :catchall_6ab

    .restart local v28    # "tmp":Ljava/io/File;
    .restart local p1    # "ctx":Landroid/content/Context;
    .restart local p2    # "input":Ljava/io/InputStream;
    :catchall_6ab
    move-exception v0

    invoke-static {v4, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final init(Landroid/content/Context;)V
    .registers 5
    .param p1, "ctx"    # Landroid/content/Context;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->dir:Ljava/io/File;

    if-nez v0, :cond_16

    new-instance v0, Ljava/io/File;

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "iconpack"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->dir:Ljava/io/File;

    .line 33
    :cond_16
    return-void
.end method

.method public final instance(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 10
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "cls"    # Ljava/lang/String;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cls"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    invoke-virtual {p0, p2}, Lcom/exampletest/mobilestudiotest/ui/Icons;->instanceBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_1c

    .line 186
    .local v0, "it\\1":Landroid/graphics/Bitmap;
    const/4 v1, 0x0

    .line 71
    .local v1, "$i$a$-let-Icons$instance$1\\1\\71\\0":I
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    invoke-direct {v2, p1, v0}, Lcom/exampletest/mobilestudiotest/ui/Icons;->pixelated(Landroid/content/Context;Landroid/graphics/Bitmap;)Landroid/graphics/drawable/BitmapDrawable;

    move-result-object v0

    .end local v0    # "it\\1":Landroid/graphics/Bitmap;
    .end local v1    # "$i$a$-let-Icons$instance$1\\1\\71\\0":I
    if-eqz v0, :cond_1c

    check-cast v0, Landroid/graphics/drawable/Drawable;

    goto :goto_37

    :cond_1c
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;

    invoke-virtual {v0, p2}, Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;->instance(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_37

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;

    invoke-direct {p0, p2}, Lcom/exampletest/mobilestudiotest/ui/Icons;->abbrev(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, p2}, Lcom/exampletest/mobilestudiotest/ui/Icons;->categoryColor(Ljava/lang/String;)I

    move-result v3

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    invoke-direct/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;-><init>(Ljava/lang/String;IZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v0, v1

    check-cast v0, Landroid/graphics/drawable/Drawable;

    :cond_37
    :goto_37
    return-object v0
.end method

.method public final instanceBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 6
    .param p1, "cls"    # Ljava/lang/String;

    const-string v0, "cls"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    move-object v0, p1

    .line 57
    .local v0, "c":Ljava/lang/String;
    const/4 v1, 0x0

    .line 58
    .local v1, "guard":I
    :goto_7
    if-eqz v0, :cond_2a

    add-int/lit8 v2, v1, 0x1

    .end local v1    # "guard":I
    .local v2, "guard":I
    const/16 v3, 0xc

    if-ge v1, v3, :cond_29

    .line 59
    const-string v1, "instance"

    invoke-direct {p0, v1, v0}, Lcom/exampletest/mobilestudiotest/ui/Icons;->load(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_19

    .line 186
    .local v1, "it\\1":Landroid/graphics/Bitmap;
    const/4 v3, 0x0

    .line 59
    .local v3, "$i$a$-let-Icons$instanceBitmap$1\\1\\59\\0":I
    return-object v1

    .line 60
    .end local v1    # "it\\1":Landroid/graphics/Bitmap;
    .end local v3    # "$i$a$-let-Icons$instanceBitmap$1\\1\\59\\0":I
    :cond_19
    const-string v1, "Instance"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_29

    .line 61
    sget-object v1, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->superclass(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move v1, v2

    goto :goto_7

    .line 63
    :cond_29
    move v1, v2

    .end local v2    # "guard":I
    .local v1, "guard":I
    :cond_2a
    const/4 v2, 0x0

    return-object v2
.end method

.method public final remove(Landroid/content/Context;)V
    .registers 8
    .param p1, "ctx"    # Landroid/content/Context;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 180
    new-instance v0, Ljava/io/File;

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "iconpack"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 181
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    monitor-enter v0

    .line 186
    const/4 v1, 0x0

    .line 181
    .local v1, "$i$a$-synchronized-Icons$remove$1\\1\\181\\0":I
    :try_start_17
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Icons;->cache:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    .end local v1    # "$i$a$-synchronized-Icons$remove$1\\1\\181\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1e
    .catchall {:try_start_17 .. :try_end_1e} :catchall_3d

    monitor-exit v0

    .line 182
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\2":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 234
    .local v1, "$i$f$forEach\\2\\182":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_28
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\2":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lkotlin/jvm/functions/Function0;

    .local v4, "it\\3":Lkotlin/jvm/functions/Function0;
    const/4 v5, 0x0

    .line 182
    .local v5, "$i$a$-forEach-Icons$remove$2\\3\\234\\0":I
    invoke-interface {v4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 234
    .end local v4    # "it\\3":Lkotlin/jvm/functions/Function0;
    .end local v5    # "$i$a$-forEach-Icons$remove$2\\3\\234\\0":I
    nop

    .end local v3    # "element\\2":Ljava/lang/Object;
    goto :goto_28

    .line 235
    :cond_3b
    nop

    .line 183
    .end local v0    # "$this$forEach\\2":Ljava/lang/Iterable;
    .end local v1    # "$i$f$forEach\\2\\182":I
    return-void

    .line 181
    :catchall_3d
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final ui(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 7
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "fallback"    # Ljava/lang/String;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fallback"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    invoke-virtual {p0, p2}, Lcom/exampletest/mobilestudiotest/ui/Icons;->uiBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_1f

    .line 186
    .local v0, "it\\1":Landroid/graphics/Bitmap;
    const/4 v1, 0x0

    .line 81
    .local v1, "$i$a$-let-Icons$ui$1\\1\\81\\0":I
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    invoke-direct {v2, p1, v0}, Lcom/exampletest/mobilestudiotest/ui/Icons;->pixelated(Landroid/content/Context;Landroid/graphics/Bitmap;)Landroid/graphics/drawable/BitmapDrawable;

    move-result-object v0

    .end local v0    # "it\\1":Landroid/graphics/Bitmap;
    .end local v1    # "$i$a$-let-Icons$ui$1\\1\\81\\0":I
    if-eqz v0, :cond_1f

    goto :goto_2e

    :cond_1f
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;

    invoke-virtual {v0, p2}, Lcom/exampletest/mobilestudiotest/ui/BuiltinIcons;->ui(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_30

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, p3, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;-><init>(Ljava/lang/String;IZ)V

    :goto_2e
    check-cast v0, Landroid/graphics/drawable/Drawable;

    :cond_30
    return-object v0
.end method

.method public final uiBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 3
    .param p1, "name"    # Ljava/lang/String;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 67
    const-string v0, "ui"

    invoke-direct {p0, v0, p1}, Lcom/exampletest/mobilestudiotest/ui/Icons;->load(Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.Icons.Badge (com.exampletest.mobilestudiotest.ui.Icons$Badge)
.class public final Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;
.super Landroid/graphics/drawable/Drawable;
.source "Icons.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/Icons;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Badge"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nIcons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Icons.kt\ncom/exampletest/mobilestudiotest/ui/Icons$Badge\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,185:1\n1#2:186\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\u0010\u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u0005H\u0016J\u0012\u0010\u0013\u001a\u00020\u000e2\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0016J\u0008\u0010\u0016\u001a\u00020\u0005H\u0017J\u0008\u0010\u0017\u001a\u00020\u0005H\u0016J\u0008\u0010\u0018\u001a\u00020\u0005H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0019"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;",
        "Landroid/graphics/drawable/Drawable;",
        "label",
        "",
        "color",
        "",
        "plain",
        "",
        "<init>",
        "(Ljava/lang/String;IZ)V",
        "bg",
        "Landroid/graphics/Paint;",
        "tp",
        "draw",
        "",
        "c",
        "Landroid/graphics/Canvas;",
        "setAlpha",
        "alpha",
        "setColorFilter",
        "cf",
        "Landroid/graphics/ColorFilter;",
        "getOpacity",
        "getIntrinsicWidth",
        "getIntrinsicHeight",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final bg:Landroid/graphics/Paint;

.field private final color:I

.field private final label:Ljava/lang/String;

.field private final plain:Z

.field private final tp:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Ljava/lang/String;IZ)V
    .registers 8
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "color"    # I
    .param p3, "plain"    # Z

    const-string v0, "label"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 105
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->label:Ljava/lang/String;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->color:I

    iput-boolean p3, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->plain:Z

    .line 106
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->bg:Landroid/graphics/Paint;

    .line 107
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    .line 186
    move-object v1, v0

    .local v1, "$this$tp_u24lambda_u240\\1":Landroid/graphics/Paint;
    const/4 v2, 0x0

    .line 107
    .local v2, "$i$a$-apply-Icons$Badge$tp$1\\1\\107\\0":I
    sget-object v3, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    sget-object v3, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .end local v1    # "$this$tp_u24lambda_u240\\1":Landroid/graphics/Paint;
    .end local v2    # "$i$a$-apply-Icons$Badge$tp$1\\1\\107\\0":I
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->tp:Landroid/graphics/Paint;

    .line 105
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;IZILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 6

    .line 105
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_5

    const/4 p3, 0x0

    :cond_5
    invoke-direct {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;-><init>(Ljava/lang/String;IZ)V

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 11
    .param p1, "c"    # Landroid/graphics/Canvas;

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const-string v1, "getBounds(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    .local v0, "b":Landroid/graphics/Rect;
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1, v0}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    .line 111
    .local v1, "r":Landroid/graphics/RectF;
    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v2

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    .line 112
    .local v2, "s":F
    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v3

    sub-float/2addr v3, v2

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v3, v4

    const v5, 0x3d75c28f    # 0.06f

    mul-float v6, v2, v5

    add-float/2addr v3, v6

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v6

    sub-float/2addr v6, v2

    div-float/2addr v6, v4

    mul-float/2addr v5, v2

    add-float/2addr v6, v5

    invoke-virtual {v1, v3, v6}, Landroid/graphics/RectF;->inset(FF)V

    .line 113
    iget-boolean v3, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->plain:Z

    if-nez v3, :cond_4e

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->bg:Landroid/graphics/Paint;

    iget v5, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->color:I

    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setColor(I)V

    const v3, 0x3e4ccccd    # 0.2f

    mul-float v5, v2, v3

    mul-float/2addr v3, v2

    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->bg:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v5, v3, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 114
    :cond_4e
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->tp:Landroid/graphics/Paint;

    iget-boolean v5, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->plain:Z

    if-eqz v5, :cond_5b

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v5

    goto :goto_5c

    :cond_5b
    const/4 v5, -0x1

    :goto_5c
    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 115
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->tp:Landroid/graphics/Paint;

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->label:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v6, 0x1

    if-le v5, v6, :cond_6e

    const v5, 0x3ed70a3d    # 0.42f

    goto :goto_71

    :cond_6e
    const v5, 0x3f19999a    # 0.6f

    :goto_71
    mul-float/2addr v5, v2

    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 116
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->label:Ljava/lang/String;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->tp:Landroid/graphics/Paint;

    invoke-virtual {v7}, Landroid/graphics/Paint;->descent()F

    move-result v7

    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->tp:Landroid/graphics/Paint;

    invoke-virtual {v8}, Landroid/graphics/Paint;->ascent()F

    move-result v8

    add-float/2addr v7, v8

    div-float/2addr v7, v4

    sub-float/2addr v6, v7

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->tp:Landroid/graphics/Paint;

    invoke-virtual {p1, v3, v5, v6, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 117
    return-void
.end method

.method public getIntrinsicHeight()I
    .registers 2

    .line 123
    const/16 v0, 0x20

    return v0
.end method

.method public getIntrinsicWidth()I
    .registers 2

    .line 122
    const/16 v0, 0x20

    return v0
.end method

.method public getOpacity()I
    .registers 2
    .annotation runtime Lkotlin/Deprecated;
        message = "Deprecated in Java"
    .end annotation

    .line 121
    const/4 v0, -0x3

    return v0
.end method

.method public setAlpha(I)V
    .registers 3
    .param p1, "alpha"    # I

    .line 118
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->bg:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$Badge;->tp:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2
    .param p1, "cf"    # Landroid/graphics/ColorFilter;

    .line 119
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.Icons$importZip$2$E (com.exampletest.mobilestudiotest.ui.Icons$importZip$2$E)
.class public final Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;
.super Ljava/lang/Object;
.source "Icons.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/Icons;->importZip(Landroid/content/Context;Ljava/io/InputStream;)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "E"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u000b*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\u0008\u001a\u00020\t\u00a2\u0006\u0004\u0008\n\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\rR\u0011\u0010\u0007\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\rR\u0011\u0010\u0008\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0013\u00a8\u0006\u0014"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/ui/Icons$importZip$2$E",
        "",
        "palette",
        "",
        "theme",
        "kind",
        "res",
        "name",
        "entry",
        "Ljava/util/zip/ZipEntry;",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/zip/ZipEntry;)V",
        "getPalette",
        "()Ljava/lang/String;",
        "getTheme",
        "getKind",
        "getRes",
        "getName",
        "getEntry",
        "()Ljava/util/zip/ZipEntry;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final entry:Ljava/util/zip/ZipEntry;

.field private final kind:Ljava/lang/String;

.field private final name:Ljava/lang/String;

.field private final palette:Ljava/lang/String;

.field private final res:Ljava/lang/String;

.field private final theme:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/zip/ZipEntry;)V
    .registers 8
    .param p1, "palette"    # Ljava/lang/String;
    .param p2, "theme"    # Ljava/lang/String;
    .param p3, "kind"    # Ljava/lang/String;
    .param p4, "res"    # Ljava/lang/String;
    .param p5, "name"    # Ljava/lang/String;
    .param p6, "entry"    # Ljava/util/zip/ZipEntry;

    const-string v0, "palette"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "theme"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "kind"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "res"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "entry"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->palette:Ljava/lang/String;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->theme:Ljava/lang/String;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->kind:Ljava/lang/String;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->res:Ljava/lang/String;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->name:Ljava/lang/String;

    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->entry:Ljava/util/zip/ZipEntry;

    return-void
.end method


# virtual methods
.method public final getEntry()Ljava/util/zip/ZipEntry;
    .registers 2

    .line 138
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->entry:Ljava/util/zip/ZipEntry;

    return-object v0
.end method

.method public final getKind()Ljava/lang/String;
    .registers 2

    .line 138
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->kind:Ljava/lang/String;

    return-object v0
.end method

.method public final getName()Ljava/lang/String;
    .registers 2

    .line 138
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final getPalette()Ljava/lang/String;
    .registers 2

    .line 138
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->palette:Ljava/lang/String;

    return-object v0
.end method

.method public final getRes()Ljava/lang/String;
    .registers 2

    .line 138
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->res:Ljava/lang/String;

    return-object v0
.end method

.method public final getTheme()Ljava/lang/String;
    .registers 2

    .line 138
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Icons$importZip$2$E;->theme:Ljava/lang/String;

    return-object v0
.end method
