###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor (com.exampletest.mobilestudiotest.ui.ScriptEditor)
.class public final Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
.super Landroid/widget/LinearLayout;
.source "ScriptEditor.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;,
        Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;,
        Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nScriptEditor.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ScriptEditor.kt\ncom/exampletest/mobilestudiotest/ui/ScriptEditor\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,487:1\n1#2:488\n648#3,5:489\n648#3,5:494\n1104#3,3:499\n*S KotlinDebug\n*F\n+ 1 ScriptEditor.kt\ncom/exampletest/mobilestudiotest/ui/ScriptEditor\n*L\n180#1:489,5\n198#1:494,5\n373#1:499,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u000c\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0015\u0008\u0007\u0018\u0000 H2\u00020\u0001:\u0003HIJB\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u0010\u0010\'\u001a\u00020(2\u0006\u0010)\u001a\u00020*H\u0002J\u0010\u0010+\u001a\u00020\u00162\u0006\u0010,\u001a\u00020-H\u0002J \u0010.\u001a\u00020(2\u0006\u0010)\u001a\u00020*2\u0006\u0010/\u001a\u0002002\u0006\u00101\u001a\u00020\u0016H\u0002J\u0010\u00102\u001a\u00020(2\u0006\u0010)\u001a\u00020-H\u0002J\u0010\u00103\u001a\u00020(2\u0006\u00104\u001a\u00020\u0018H\u0002J\u0014\u00105\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u001606H\u0002J\u0008\u00107\u001a\u00020(H\u0002J\u0008\u00108\u001a\u00020(H\u0002J\u001c\u00109\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u0016062\u0006\u0010:\u001a\u00020\u0016H\u0002J\u0008\u0010;\u001a\u00020(H\u0002J\u0010\u0010<\u001a\u00020(2\u0006\u0010=\u001a\u00020\u0016H\u0002J\u0010\u0010>\u001a\u00020(2\u0006\u0010?\u001a\u00020\u0016H\u0002J\u0008\u0010@\u001a\u00020(H\u0002J\u0006\u0010A\u001a\u00020(J\u0008\u0010B\u001a\u00020(H\u0002J\u0010\u0010C\u001a\u00020(2\u0006\u0010D\u001a\u00020\u0016H\u0002J\u0008\u0010E\u001a\u00020(H\u0002J\u0008\u0010F\u001a\u00020(H\u0002J\u0008\u0010G\u001a\u00020(H\u0014R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u0012\u0010\u000c\u001a\u00060\rR\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020!X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\"\u001a\u0004\u0018\u00010#X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006K"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;",
        "Landroid/widget/LinearLayout;",
        "ctx",
        "Landroid/content/Context;",
        "studio",
        "Lcom/exampletest/mobilestudiotest/core/Studio;",
        "script",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "<init>",
        "(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;)V",
        "getScript",
        "()Lcom/exampletest/mobilestudiotest/model/Instance;",
        "editor",
        "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;",
        "lines",
        "Landroid/widget/TextView;",
        "status",
        "scroll",
        "Landroid/widget/ScrollView;",
        "hsv",
        "Landroid/widget/HorizontalScrollView;",
        "lineCount",
        "",
        "highlighting",
        "",
        "dirtyText",
        "highlightRunnable",
        "Ljava/lang/Runnable;",
        "commitRunnable",
        "completeRunnable",
        "popup",
        "Landroid/widget/PopupWindow;",
        "popupList",
        "Landroid/widget/ListView;",
        "completion",
        "Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;",
        "selectedIdx",
        "suppressCompletion",
        "autoClosedAt",
        "handleNewline",
        "",
        "s",
        "Landroid/text/Editable;",
        "unbalancedEnds",
        "text",
        "",
        "handleTypedChar",
        "c",
        "",
        "at",
        "insert",
        "updateCompletion",
        "explicit",
        "popupSize",
        "Lkotlin/Pair;",
        "showPopup",
        "positionPopup",
        "cursorScreenPos",
        "popupH",
        "hidePopup",
        "moveSelection",
        "delta",
        "acceptCompletion",
        "index",
        "updateLines",
        "commit",
        "checkSyntax",
        "goToLine",
        "line",
        "find",
        "highlight",
        "onDetachedFromWindow",
        "Companion",
        "CodeEdit",
        "CompletionAdapter",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;

.field private static final builtins:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final keywords:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final pairs:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Character;",
            "Ljava/lang/Character;",
            ">;"
        }
    .end annotation
.end field

.field private static final syntaxCheck$delegate:Lkotlin/Lazy;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Lazy<",
            "Lorg/luaj/vm2/Globals;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private autoClosedAt:I

.field private final commitRunnable:Ljava/lang/Runnable;

.field private final completeRunnable:Ljava/lang/Runnable;

.field private completion:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

.field private dirtyText:Z

.field private final editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

.field private final highlightRunnable:Ljava/lang/Runnable;

.field private highlighting:Z

.field private final hsv:Landroid/widget/HorizontalScrollView;

.field private lineCount:I

.field private final lines:Landroid/widget/TextView;

.field private popup:Landroid/widget/PopupWindow;

.field private final popupList:Landroid/widget/ListView;

.field private final script:Lcom/exampletest/mobilestudiotest/model/Instance;

.field private final scroll:Landroid/widget/ScrollView;

.field private selectedIdx:I

.field private final status:Landroid/widget/TextView;

.field private final studio:Lcom/exampletest/mobilestudiotest/core/Studio;

.field private suppressCompletion:Z


# direct methods
.method static constructor <clinit>()V
    .registers 23

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->Companion:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;

    .line 57
    const/16 v0, 0x19

    new-array v1, v0, [Ljava/lang/String;

    const-string v2, "and"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "break"

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const-string v2, "do"

    const/4 v5, 0x2

    aput-object v2, v1, v5

    const-string v2, "else"

    const/4 v6, 0x3

    aput-object v2, v1, v6

    const-string v2, "elseif"

    const/4 v7, 0x4

    aput-object v2, v1, v7

    const-string v2, "end"

    const/4 v8, 0x5

    aput-object v2, v1, v8

    const-string v2, "false"

    const/4 v9, 0x6

    aput-object v2, v1, v9

    const-string v2, "for"

    const/4 v10, 0x7

    aput-object v2, v1, v10

    const-string v2, "function"

    const/16 v11, 0x8

    aput-object v2, v1, v11

    const-string v2, "if"

    const/16 v12, 0x9

    aput-object v2, v1, v12

    const-string v2, "in"

    const/16 v13, 0xa

    aput-object v2, v1, v13

    const-string v2, "local"

    const/16 v14, 0xb

    aput-object v2, v1, v14

    const-string v2, "nil"

    const/16 v15, 0xc

    aput-object v2, v1, v15

    .line 58
    const-string v2, "not"

    const/16 v16, 0xd

    aput-object v2, v1, v16

    .line 57
    nop

    .line 58
    const-string v2, "or"

    const/16 v17, 0xe

    aput-object v2, v1, v17

    .line 57
    nop

    .line 58
    const-string v2, "repeat"

    const/16 v18, 0xf

    aput-object v2, v1, v18

    .line 57
    nop

    .line 58
    const-string v2, "return"

    const/16 v19, 0x10

    aput-object v2, v1, v19

    .line 57
    nop

    .line 58
    const-string v2, "then"

    const/16 v20, 0x11

    aput-object v2, v1, v20

    .line 57
    nop

    .line 58
    const-string v2, "true"

    const/16 v21, 0x12

    aput-object v2, v1, v21

    .line 57
    nop

    .line 58
    const-string v2, "until"

    const/16 v22, 0x13

    aput-object v2, v1, v22

    .line 57
    nop

    .line 58
    const-string v2, "while"

    const/16 v22, 0x14

    aput-object v2, v1, v22

    .line 57
    nop

    .line 58
    const-string v2, "continue"

    const/16 v22, 0x15

    aput-object v2, v1, v22

    .line 57
    nop

    .line 58
    const-string v2, "export"

    const/16 v22, 0x16

    aput-object v2, v1, v22

    .line 57
    nop

    .line 58
    const-string v2, "type"

    const/16 v22, 0x17

    aput-object v2, v1, v22

    .line 57
    nop

    .line 58
    const-string v2, "self"

    const/16 v22, 0x18

    aput-object v2, v1, v22

    .line 57
    invoke-static {v1}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    sput-object v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->keywords:Ljava/util/Set;

    .line 59
    const/16 v1, 0x3b

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "game"

    aput-object v2, v1, v3

    const-string v2, "workspace"

    aput-object v2, v1, v4

    const-string v2, "script"

    aput-object v2, v1, v5

    const-string v2, "plugin"

    aput-object v2, v1, v6

    const-string v2, "Instance"

    aput-object v2, v1, v7

    const-string v2, "Vector3"

    aput-object v2, v1, v8

    const-string v2, "Vector2"

    aput-object v2, v1, v9

    const-string v2, "CFrame"

    aput-object v2, v1, v10

    const-string v2, "Color3"

    aput-object v2, v1, v11

    const-string v2, "BrickColor"

    aput-object v2, v1, v12

    .line 60
    const-string v2, "UDim"

    aput-object v2, v1, v13

    .line 59
    nop

    .line 60
    const-string v2, "UDim2"

    aput-object v2, v1, v14

    .line 59
    nop

    .line 60
    const-string v2, "Enum"

    aput-object v2, v1, v15

    .line 59
    nop

    .line 60
    const-string v2, "TweenInfo"

    aput-object v2, v1, v16

    .line 59
    nop

    .line 60
    const-string v2, "Ray"

    aput-object v2, v1, v17

    .line 59
    nop

    .line 60
    const-string v2, "task"

    aput-object v2, v1, v18

    .line 59
    nop

    .line 60
    const-string v2, "wait"

    aput-object v2, v1, v19

    .line 59
    nop

    .line 60
    const-string v2, "print"

    aput-object v2, v1, v20

    .line 59
    nop

    .line 60
    const-string v2, "warn"

    aput-object v2, v1, v21

    .line 59
    nop

    .line 60
    const-string v2, "error"

    const/16 v9, 0x13

    aput-object v2, v1, v9

    .line 59
    nop

    .line 60
    const-string v2, "pairs"

    const/16 v9, 0x14

    aput-object v2, v1, v9

    .line 59
    nop

    .line 60
    const-string v2, "ipairs"

    const/16 v9, 0x15

    aput-object v2, v1, v9

    .line 59
    nop

    .line 60
    const-string v2, "math"

    const/16 v9, 0x16

    aput-object v2, v1, v9

    .line 59
    nop

    .line 60
    const-string v2, "string"

    const/16 v9, 0x17

    aput-object v2, v1, v9

    .line 59
    nop

    .line 60
    const-string v2, "table"

    const/16 v9, 0x18

    aput-object v2, v1, v9

    .line 59
    nop

    .line 61
    const-string v2, "require"

    aput-object v2, v1, v0

    .line 59
    nop

    .line 61
    const-string v0, "typeof"

    const/16 v2, 0x1a

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "type"

    const/16 v2, 0x1b

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "tostring"

    const/16 v2, 0x1c

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "tonumber"

    const/16 v2, 0x1d

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "pcall"

    const/16 v2, 0x1e

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "xpcall"

    const/16 v2, 0x1f

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "spawn"

    const/16 v2, 0x20

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "delay"

    const/16 v2, 0x21

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "tick"

    const/16 v2, 0x22

    .line 65
    invoke-static {v2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v9

    .line 61
    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "time"

    const/16 v2, 0x23

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "os"

    const/16 v2, 0x24

    aput-object v0, v1, v2

    .line 59
    nop

    .line 61
    const-string v0, "coroutine"

    const/16 v2, 0x25

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "setmetatable"

    const/16 v2, 0x26

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "getmetatable"

    const/16 v2, 0x27

    .line 65
    invoke-static {v2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v10

    .line 62
    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "rawget"

    const/16 v2, 0x28

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "rawset"

    const/16 v2, 0x29

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "select"

    const/16 v2, 0x2a

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "next"

    const/16 v2, 0x2b

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "unpack"

    const/16 v2, 0x2c

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "assert"

    const/16 v2, 0x2d

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "shared"

    const/16 v2, 0x2e

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "_G"

    const/16 v2, 0x2f

    aput-object v0, v1, v2

    .line 59
    nop

    .line 62
    const-string v0, "NumberRange"

    const/16 v2, 0x30

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "NumberSequence"

    const/16 v2, 0x31

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "ColorSequence"

    const/16 v2, 0x32

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "Random"

    const/16 v2, 0x33

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "RaycastParams"

    const/16 v2, 0x34

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "OverlapParams"

    const/16 v2, 0x35

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "utf8"

    const/16 v2, 0x36

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "bit32"

    const/16 v2, 0x37

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "debug"

    const/16 v2, 0x38

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "buffer"

    const/16 v2, 0x39

    aput-object v0, v1, v2

    .line 59
    nop

    .line 63
    const-string v0, "DateTime"

    const/16 v2, 0x3a

    aput-object v0, v1, v2

    .line 59
    invoke-static {v1}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->builtins:Ljava/util/Set;

    .line 64
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda0;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->syntaxCheck$delegate:Lkotlin/Lazy;

    .line 65
    new-array v0, v8, [Lkotlin/Pair;

    const/16 v1, 0x28

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    const/16 v2, 0x29

    invoke-static {v2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    aput-object v1, v0, v3

    const/16 v1, 0x5b

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    const/16 v2, 0x5d

    invoke-static {v2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    aput-object v1, v0, v4

    const/16 v1, 0x7b

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    const/16 v2, 0x7d

    invoke-static {v2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    aput-object v1, v0, v5

    invoke-static {v9, v9}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    aput-object v1, v0, v6

    invoke-static {v10, v10}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    aput-object v1, v0, v7

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->pairs:Ljava/util/Map;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 34
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;
    .param p3, "script"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object/from16 v1, p0

    move-object/from16 v3, p1

    move-object/from16 v10, p2

    move-object/from16 v11, p3

    const-string v0, "ctx"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "studio"

    invoke-static {v10, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "script"

    invoke-static {v11, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    invoke-direct/range {p0 .. p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v10, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    iput-object v11, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 43
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda3;

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda3;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    iput-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlightRunnable:Ljava/lang/Runnable;

    .line 44
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda4;

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    iput-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->commitRunnable:Ljava/lang/Runnable;

    .line 45
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda5;

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda5;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    iput-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completeRunnable:Ljava/lang/Runnable;

    .line 54
    const/4 v0, -0x1

    iput v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I

    .line 89
    nop

    .line 90
    const/4 v12, 0x1

    invoke-virtual {v1, v12}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->setOrientation(I)V

    .line 91
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getEDITOR_BG()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->setBackgroundColor(I)V

    .line 92
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v2

    .line 488
    .local v4, "$this$_init__u24lambda_u243\\1":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 92
    .local v5, "$i$a$-apply-ScriptEditor$bar$1\\1\\92\\0":I
    const/4 v13, 0x0

    invoke-virtual {v4, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v14, 0x10

    invoke-virtual {v4, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getHEADER()I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .end local v4    # "$this$_init__u24lambda_u243\\1":Landroid/widget/LinearLayout;
    .end local v5    # "$i$a$-apply-ScriptEditor$bar$1\\1\\92\\0":I
    move-object v15, v2

    .line 93
    .local v15, "bar":Landroid/widget/LinearLayout;
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const-string v4, ""

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v6

    const/16 v8, 0x10

    const/4 v9, 0x0

    const/high16 v5, 0x41300000    # 11.0f

    const/4 v7, 0x0

    invoke-static/range {v2 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v2

    .line 488
    move-object v4, v2

    .local v4, "$this$_init__u24lambda_u244\\2":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 93
    .local v5, "$i$a$-apply-ScriptEditor$1\\2\\93\\0":I
    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v7, 0x41000000    # 8.0f

    invoke-virtual {v6, v3, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8, v3, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    invoke-virtual {v4, v6, v13, v8, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .end local v4    # "$this$_init__u24lambda_u244\\2":Landroid/widget/TextView;
    .end local v5    # "$i$a$-apply-ScriptEditor$1\\2\\93\\0":I
    iput-object v2, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->status:Landroid/widget/TextView;

    .line 94
    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, v3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 488
    move-object v4, v2

    .local v4, "$this$_init__u24lambda_u245\\3":Landroid/widget/ImageView;
    const/4 v5, 0x0

    .line 94
    .local v5, "$i$a$-apply-ScriptEditor$2\\3\\94\\0":I
    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v6, v3, v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->icon(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/model/Instance;)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .end local v4    # "$this$_init__u24lambda_u245\\3":Landroid/widget/ImageView;
    .end local v5    # "$i$a$-apply-ScriptEditor$2\\3\\94\\0":I
    check-cast v2, Landroid/view/View;

    sget-object v16, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v5, 0x41800000    # 16.0f

    invoke-virtual {v4, v3, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v17

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v4, v3, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v18

    const/16 v20, 0x4

    const/16 v21, 0x0

    const/16 v19, 0x0

    invoke-static/range {v16 .. v21}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    .line 488
    move-object v5, v4

    .local v5, "$this$_init__u24lambda_u246\\4":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v6, 0x0

    .line 94
    .local v6, "$i$a$-apply-ScriptEditor$3\\4\\94\\0":I
    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8, v3, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    iput v8, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .end local v5    # "$this$_init__u24lambda_u246\\4":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6    # "$i$a$-apply-ScriptEditor$3\\4\\94\\0":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v15, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 95
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->fullName()Ljava/lang/String;

    move-result-object v4

    const/16 v8, 0x18

    const/high16 v5, 0x41400000    # 12.0f

    const/4 v6, 0x0

    move/from16 v16, v7

    const/4 v7, 0x0

    move/from16 v17, v14

    move/from16 v14, v16

    invoke-static/range {v2 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v2

    .line 488
    move-object v4, v2

    .local v4, "$this$_init__u24lambda_u247\\5":Landroid/widget/TextView;
    const/4 v5, 0x0

    .line 95
    .local v5, "$i$a$-apply-ScriptEditor$4\\5\\95\\0":I
    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v9, 0x40c00000    # 6.0f

    invoke-virtual {v6, v3, v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-virtual {v4, v6, v13, v13, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .end local v4    # "$this$_init__u24lambda_u247\\5":Landroid/widget/TextView;
    .end local v5    # "$i$a$-apply-ScriptEditor$4\\5\\95\\0":I
    check-cast v2, Landroid/view/View;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v8, -0x2

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-virtual {v4, v13, v8, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v15, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 96
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->status:Landroid/widget/TextView;

    check-cast v2, Landroid/view/View;

    invoke-virtual {v15, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 97
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const-string v6, "ScriptAnalysis"

    const-string v7, "Chk"

    invoke-virtual {v4, v3, v6, v7}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    move v6, v5

    const-string v5, "Check"

    new-instance v7, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda6;

    invoke-direct {v7, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    move/from16 v16, v6

    const/4 v6, 0x0

    move/from16 v0, v16

    invoke-virtual/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconTextButton(Landroid/content/Context;Landroid/graphics/drawable/Drawable;Ljava/lang/String;ILkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v15, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 98
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const-string v5, "FindAll"

    const-string v6, "Find"

    invoke-virtual {v4, v3, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda7;

    invoke-direct {v6, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda7;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    const/4 v7, 0x4

    move v5, v8

    const/4 v8, 0x0

    move/from16 v16, v5

    const/4 v5, 0x0

    invoke-static/range {v2 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/ImageView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v15, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 99
    move-object v2, v15

    check-cast v2, Landroid/view/View;

    sget-object v23, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/16 v27, 0x4

    const/16 v28, 0x0

    const/16 v24, -0x1

    const/16 v25, -0x2

    const/16 v26, 0x0

    invoke-static/range {v23 .. v28}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v2, v4}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 101
    sget-object v2, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Settings;->getEditorFontSize()F

    move-result v2

    .line 102
    .local v2, "fontSize":F
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v5, v4

    .local v5, "$this$_init__u24lambda_u2410\\6":Landroid/widget/TextView;
    const/4 v6, 0x0

    .line 103
    .local v6, "$i$a$-apply-ScriptEditor$7\\6\\102\\0":I
    sget-object v7, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 104
    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 105
    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getEDITOR_GUTTER()I

    move-result v8

    sget-object v16, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getEDITOR_TEXT()I

    move-result v0

    const v12, 0x3ee66666    # 0.45f

    invoke-virtual {v7, v8, v0, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend(IIF)I

    move-result v0

    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 106
    const v0, 0x800005

    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 107
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0, v3, v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7, v3, v14}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8, v3, v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9, v3, v14}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v9

    invoke-virtual {v5, v0, v7, v8, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 108
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getEDITOR_GUTTER()I

    move-result v0

    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setBackgroundColor(I)V

    .line 109
    nop

    .line 102
    .end local v5    # "$this$_init__u24lambda_u2410\\6":Landroid/widget/TextView;
    .end local v6    # "$i$a$-apply-ScriptEditor$7\\6\\102\\0":I
    iput-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->lines:Landroid/widget/TextView;

    .line 110
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-direct {v0, v1, v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/content/Context;)V

    move-object v4, v0

    .local v4, "$this$_init__u24lambda_u2412\\7":Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;
    const/4 v5, 0x0

    .line 111
    .local v5, "$i$a$-apply-ScriptEditor$8\\7\\110\\0":I
    sget-object v6, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v4, v6}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setTypeface(Landroid/graphics/Typeface;)V

    .line 112
    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setTextSize(F)V

    .line 113
    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getEDITOR_TEXT()I

    move-result v6

    invoke-virtual {v4, v6}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setTextColor(I)V

    .line 114
    const/4 v6, 0x0

    invoke-virtual {v4, v6}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 115
    const v7, 0x800033

    invoke-virtual {v4, v7}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setGravity(I)V

    .line 116
    const v7, 0xa0001

    invoke-virtual {v4, v7}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setInputType(I)V

    .line 117
    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setHorizontallyScrolling(Z)V

    .line 118
    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7, v3, v14}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8, v3, v14}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v12, 0x41c00000    # 24.0f

    invoke-virtual {v9, v3, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v9

    sget-object v12, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v14, 0x43480000    # 200.0f

    invoke-virtual {v12, v3, v14}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v12

    invoke-virtual {v4, v7, v8, v9, v12}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setPadding(IIII)V

    .line 119
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v7

    iget v7, v7, Landroid/util/DisplayMetrics;->widthPixels:I

    invoke-virtual {v4, v7}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setMinWidth(I)V

    .line 120
    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v7

    monitor-enter v7

    .line 488
    const/4 v8, 0x0

    .line 120
    .local v8, "$i$a$-synchronized-ScriptEditor$8$1\\8\\120\\7":I
    :try_start_215
    iget-object v9, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v12, "Source"

    invoke-virtual {v9, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    instance-of v12, v9, Ljava/lang/String;
    :try_end_21f
    .catchall {:try_start_215 .. :try_end_21f} :catchall_3fa

    if-eqz v12, :cond_224

    :try_start_221
    check-cast v9, Ljava/lang/String;

    goto :goto_225

    :cond_224
    move-object v9, v6

    :goto_225
    if-nez v9, :cond_22f

    const-string v9, ""
    :try_end_229
    .catchall {:try_start_221 .. :try_end_229} :catchall_22a

    goto :goto_22f

    .end local v8    # "$i$a$-synchronized-ScriptEditor$8$1\\8\\120\\7":I
    :catchall_22a
    move-exception v0

    move/from16 v17, v2

    goto/16 :goto_3fd

    :cond_22f
    :goto_22f
    monitor-exit v7

    check-cast v9, Ljava/lang/CharSequence;

    invoke-virtual {v4, v9}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setText(Ljava/lang/CharSequence;)V

    .line 121
    nop

    .line 110
    .end local v4    # "$this$_init__u24lambda_u2412\\7":Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;
    .end local v5    # "$i$a$-apply-ScriptEditor$8\\7\\110\\0":I
    iput-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    .line 122
    new-instance v0, Landroid/widget/HorizontalScrollView;

    invoke-direct {v0, v3}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    .line 488
    move-object v4, v0

    .local v4, "$this$_init__u24lambda_u2413\\9":Landroid/widget/HorizontalScrollView;
    const/4 v5, 0x0

    .line 122
    .local v5, "$i$a$-apply-ScriptEditor$9\\9\\122\\0":I
    const/4 v7, 0x1

    invoke-virtual {v4, v7}, Landroid/widget/HorizontalScrollView;->setFillViewport(Z)V

    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    check-cast v7, Landroid/view/View;

    invoke-virtual {v4, v7}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    .end local v4    # "$this$_init__u24lambda_u2413\\9":Landroid/widget/HorizontalScrollView;
    .end local v5    # "$i$a$-apply-ScriptEditor$9\\9\\122\\0":I
    iput-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->hsv:Landroid/widget/HorizontalScrollView;

    .line 123
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v0

    .line 488
    .local v4, "$this$_init__u24lambda_u2414\\10":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 123
    .local v5, "$i$a$-apply-ScriptEditor$inner$1\\10\\123\\0":I
    invoke-virtual {v4, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->lines:Landroid/widget/TextView;

    check-cast v7, Landroid/view/View;

    sget-object v23, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/16 v27, 0x4

    const/16 v28, 0x0

    const/16 v24, -0x2

    const/16 v25, -0x1

    const/16 v26, 0x0

    invoke-static/range {v23 .. v28}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v8

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->hsv:Landroid/widget/HorizontalScrollView;

    check-cast v7, Landroid/view/View;

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v9, -0x2

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-virtual {v8, v13, v9, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v8

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 124
    .end local v4    # "$this$_init__u24lambda_u2414\\10":Landroid/widget/LinearLayout;
    .end local v5    # "$i$a$-apply-ScriptEditor$inner$1\\10\\123\\0":I
    .local v0, "inner":Landroid/widget/LinearLayout;
    new-instance v4, Landroid/widget/ScrollView;

    invoke-direct {v4, v3}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 488
    move-object v5, v4

    .local v5, "$this$_init__u24lambda_u2415\\11":Landroid/widget/ScrollView;
    const/4 v7, 0x0

    .line 124
    .local v7, "$i$a$-apply-ScriptEditor$10\\11\\124\\0":I
    const/4 v8, 0x1

    invoke-virtual {v5, v8}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    move-object v8, v0

    check-cast v8, Landroid/view/View;

    invoke-virtual {v5, v8}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .end local v5    # "$this$_init__u24lambda_u2415\\11":Landroid/widget/ScrollView;
    .end local v7    # "$i$a$-apply-ScriptEditor$10\\11\\124\\0":I
    iput-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->scroll:Landroid/widget/ScrollView;

    .line 125
    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->scroll:Landroid/widget/ScrollView;

    check-cast v4, Landroid/view/View;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v7, -0x1

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-virtual {v5, v7, v13, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 126
    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->scroll:Landroid/widget/ScrollView;

    invoke-virtual {v4}, Landroid/widget/ScrollView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v4

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda8;

    invoke-direct {v5, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda8;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    invoke-virtual {v4, v5}, Landroid/view/ViewTreeObserver;->addOnScrollChangedListener(Landroid/view/ViewTreeObserver$OnScrollChangedListener;)V

    .line 128
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v4

    .line 488
    .local v5, "$this$_init__u24lambda_u2417\\12":Landroid/widget/LinearLayout;
    const/4 v8, 0x0

    .line 128
    .local v8, "$i$a$-apply-ScriptEditor$symbols$1\\12\\128\\0":I
    invoke-virtual {v5, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getHEADER()I

    move-result v9

    invoke-virtual {v5, v9}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 129
    .end local v5    # "$this$_init__u24lambda_u2417\\12":Landroid/widget/LinearLayout;
    .end local v8    # "$i$a$-apply-ScriptEditor$symbols$1\\12\\128\\0":I
    .local v4, "symbols":Landroid/widget/LinearLayout;
    const/16 v5, 0x12

    new-array v5, v5, [Ljava/lang/String;

    const-string v8, "Tab"

    aput-object v8, v5, v13

    const-string v8, "("

    const/16 v16, 0x1

    aput-object v8, v5, v16

    const/4 v8, 0x2

    const-string v9, ")"

    aput-object v9, v5, v8

    const/4 v8, 0x3

    const-string v9, "{"

    aput-object v9, v5, v8

    const/4 v8, 0x4

    const-string v9, "}"

    aput-object v9, v5, v8

    const/4 v8, 0x5

    const-string v9, "["

    aput-object v9, v5, v8

    const/4 v8, 0x6

    const-string v9, "]"

    aput-object v9, v5, v8

    const/4 v8, 0x7

    const-string v9, "="

    aput-object v9, v5, v8

    const/16 v8, 0x8

    const-string v9, "\""

    aput-object v9, v5, v8

    const/16 v8, 0x9

    const-string v9, ":"

    aput-object v9, v5, v8

    const/16 v8, 0xa

    const-string v9, "."

    aput-object v9, v5, v8

    const/16 v8, 0xb

    const-string v9, ","

    aput-object v9, v5, v8

    const/16 v8, 0xc

    const-string v9, "~"

    aput-object v9, v5, v8

    const/16 v8, 0xd

    const-string v9, "#"

    aput-object v9, v5, v8

    const/16 v8, 0xe

    const-string v9, "end"

    aput-object v9, v5, v8

    const/16 v8, 0xf

    const-string v9, "local"

    aput-object v9, v5, v8

    const-string v8, "function"

    aput-object v8, v5, v17

    const/16 v8, 0x11

    const-string v9, "then"

    aput-object v9, v5, v8

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_335
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_352

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .line 130
    .local v8, "s":Ljava/lang/String;
    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    new-instance v12, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda9;

    invoke-direct {v12, v1, v8}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda9;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;)V

    invoke-virtual {v9, v3, v8, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui;->smallIconButton(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object v9

    check-cast v9, Landroid/view/View;

    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .end local v8    # "s":Ljava/lang/String;
    goto :goto_335

    .line 132
    :cond_352
    new-instance v5, Landroid/widget/HorizontalScrollView;

    invoke-direct {v5, v3}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    .line 488
    move-object v8, v5

    .local v8, "$this$_init__u24lambda_u2419\\13":Landroid/widget/HorizontalScrollView;
    const/4 v9, 0x0

    .line 132
    .local v9, "$i$a$-apply-ScriptEditor$13\\13\\132\\0":I
    move-object v12, v4

    check-cast v12, Landroid/view/View;

    invoke-virtual {v8, v12}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    .end local v8    # "$this$_init__u24lambda_u2419\\13":Landroid/widget/HorizontalScrollView;
    .end local v9    # "$i$a$-apply-ScriptEditor$13\\13\\132\\0":I
    check-cast v5, Landroid/view/View;

    sget-object v20, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/16 v24, 0x4

    const/16 v25, 0x0

    const/16 v21, -0x1

    const/16 v22, -0x2

    const/16 v23, 0x0

    invoke-static/range {v20 .. v25}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v8

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v5, v8}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 135
    new-instance v5, Landroid/widget/ListView;

    invoke-direct {v5, v3}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V

    move-object v8, v5

    .local v8, "$this$_init__u24lambda_u2422\\14":Landroid/widget/ListView;
    const/4 v9, 0x0

    .line 136
    .local v9, "$i$a$-apply-ScriptEditor$14\\14\\135\\0":I
    invoke-virtual {v8, v6}, Landroid/widget/ListView;->setDivider(Landroid/graphics/drawable/Drawable;)V

    .line 137
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 488
    move-object v12, v6

    .local v12, "$this$lambda_u2422_u24lambda_u2420\\15":Landroid/graphics/drawable/GradientDrawable;
    const/4 v13, 0x0

    .line 137
    .local v13, "$i$a$-apply-ScriptEditor$14$1\\15\\137\\14":I
    sget-object v14, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v16, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getEDITOR_BG()I

    move-result v7

    sget-object v16, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getLIGHT()Z

    move-result v16

    if-eqz v16, :cond_3a0

    const/high16 v16, -0x1000000

    move/from16 v29, v16

    move-object/from16 v16, v0

    move/from16 v0, v29

    goto :goto_3a3

    :cond_3a0
    move-object/from16 v16, v0

    const/4 v0, -0x1

    .end local v0    # "inner":Landroid/widget/LinearLayout;
    .local v16, "inner":Landroid/widget/LinearLayout;
    :goto_3a3
    move/from16 v17, v2

    .end local v2    # "fontSize":F
    .local v17, "fontSize":F
    const v2, 0x3d8f5c29    # 0.07f

    invoke-virtual {v14, v7, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend(IIF)I

    move-result v0

    invoke-virtual {v12, v0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v0, v3, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getBORDER()I

    move-result v2

    invoke-virtual {v12, v0, v2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v2, 0x40800000    # 4.0f

    invoke-virtual {v0, v3, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v12, v0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v12    # "$this$lambda_u2422_u24lambda_u2420\\15":Landroid/graphics/drawable/GradientDrawable;
    .end local v13    # "$i$a$-apply-ScriptEditor$14$1\\15\\137\\14":I
    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v8, v6}, Landroid/widget/ListView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 138
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    check-cast v0, Landroid/widget/ListAdapter;

    invoke-virtual {v8, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 139
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda10;

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda10;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    invoke-virtual {v8, v0}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 140
    nop

    .line 135
    .end local v8    # "$this$_init__u24lambda_u2422\\14":Landroid/widget/ListView;
    .end local v9    # "$i$a$-apply-ScriptEditor$14\\14\\135\\0":I
    iput-object v5, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupList:Landroid/widget/ListView;

    .line 142
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;

    invoke-direct {v2, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    check-cast v2, Landroid/text/TextWatcher;

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 168
    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->updateLines()V

    .line 169
    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight()V

    .line 170
    .end local v4    # "symbols":Landroid/widget/LinearLayout;
    .end local v15    # "bar":Landroid/widget/LinearLayout;
    .end local v16    # "inner":Landroid/widget/LinearLayout;
    .end local v17    # "fontSize":F
    nop

    .line 34
    return-void

    .line 120
    .restart local v2    # "fontSize":F
    .local v4, "$this$_init__u24lambda_u2412\\7":Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;
    .local v5, "$i$a$-apply-ScriptEditor$8\\7\\110\\0":I
    .restart local v15    # "bar":Landroid/widget/LinearLayout;
    :catchall_3fa
    move-exception v0

    move/from16 v17, v2

    .end local v2    # "fontSize":F
    .restart local v17    # "fontSize":F
    :goto_3fd
    monitor-exit v7

    throw v0
.end method

.method static final _init_$lambda$16(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 126
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popup:Landroid/widget/PopupWindow;

    const/4 v1, 0x0

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_d

    move v1, v2

    :cond_d
    if-eqz v1, :cond_12

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->positionPopup()V

    :cond_12
    return-void
.end method

.method static final _init_$lambda$18(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;Landroid/view/View;)Lkotlin/Unit;
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "$s"    # Ljava/lang/String;
    .param p2, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 130
    const-string v0, "Tab"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10

    const-string v0, "    "

    goto :goto_11

    :cond_10
    move-object v0, p1

    :goto_11
    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->insert(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$8(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/view/View;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 97
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->checkSyntax()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$9(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/view/View;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->find()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final acceptCompletion(I)V
    .registers 11
    .param p1, "index"    # I

    .line 321
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completion:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    if-nez v0, :cond_5

    return-void

    .line 322
    .local v0, "r":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;
    :cond_5
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getItems()Ljava/util/List;

    move-result-object v1

    invoke-static {v1, p1}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    if-nez v1, :cond_12

    return-void

    .line 323
    .local v1, "item":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;
    :cond_12
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v2

    .line 324
    .local v2, "text":Landroid/text/Editable;
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getSelectionStart()I

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getStart()I

    move-result v4

    invoke-interface {v2}, Landroid/text/Editable;->length()I

    move-result v5

    invoke-static {v3, v4, v5}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v3

    .line 326
    .local v3, "end":I
    move v4, v3

    .line 327
    .local v4, "wordEnd":I
    :goto_2b
    invoke-interface {v2}, Landroid/text/Editable;->length()I

    move-result v5

    if-ge v4, v5, :cond_46

    invoke-interface {v2, v4}, Landroid/text/Editable;->charAt(I)C

    move-result v5

    invoke-static {v5}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v5

    if-nez v5, :cond_43

    invoke-interface {v2, v4}, Landroid/text/Editable;->charAt(I)C

    move-result v5

    const/16 v6, 0x5f

    if-ne v5, v6, :cond_46

    :cond_43
    add-int/lit8 v4, v4, 0x1

    goto :goto_2b

    .line 328
    :cond_46
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completeRunnable:Ljava/lang/Runnable;

    invoke-virtual {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 329
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->hidePopup()V

    .line 330
    const/4 v5, 0x1

    iput-boolean v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 331
    nop

    .line 332
    const/4 v5, 0x0

    :try_start_53
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getStart()I

    move-result v6

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;->getInsert()Ljava/lang/String;

    move-result-object v7

    check-cast v7, Ljava/lang/CharSequence;

    invoke-interface {v2, v6, v4, v7}, Landroid/text/Editable;->replace(IILjava/lang/CharSequence;)Landroid/text/Editable;

    .line 333
    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getStart()I

    move-result v7

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;->getInsert()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    add-int/2addr v7, v8

    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v8

    invoke-interface {v8}, Landroid/text/Editable;->length()I

    move-result v8

    invoke-static {v7, v8}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result v7

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setSelection(I)V
    :try_end_80
    .catchall {:try_start_53 .. :try_end_80} :catchall_83

    .line 334
    iput-boolean v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 335
    return-void

    .line 334
    :catchall_83
    move-exception v6

    iput-boolean v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    throw v6
.end method

.method public static final synthetic access$acceptCompletion(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;I)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "index"    # I

    .line 33
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->acceptCompletion(I)V

    return-void
.end method

.method public static final synthetic access$getCommitRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->commitRunnable:Ljava/lang/Runnable;

    return-object v0
.end method

.method public static final synthetic access$getCompleteRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completeRunnable:Ljava/lang/Runnable;

    return-object v0
.end method

.method public static final synthetic access$getCompletion$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completion:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    return-object v0
.end method

.method public static final synthetic access$getHighlightRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlightRunnable:Ljava/lang/Runnable;

    return-object v0
.end method

.method public static final synthetic access$getHighlighting$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Z
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlighting:Z

    return v0
.end method

.method public static final synthetic access$getPopup$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Landroid/widget/PopupWindow;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popup:Landroid/widget/PopupWindow;

    return-object v0
.end method

.method public static final synthetic access$getSelectedIdx$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)I
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->selectedIdx:I

    return v0
.end method

.method public static final synthetic access$getSuppressCompletion$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Z
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    return v0
.end method

.method public static final synthetic access$getSyntaxCheck$delegate$cp()Lkotlin/Lazy;
    .registers 1

    .line 33
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->syntaxCheck$delegate:Lkotlin/Lazy;

    return-object v0
.end method

.method public static final synthetic access$handleNewline(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/text/Editable;)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "s"    # Landroid/text/Editable;

    .line 33
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->handleNewline(Landroid/text/Editable;)V

    return-void
.end method

.method public static final synthetic access$handleTypedChar(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/text/Editable;CI)V
    .registers 4
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "s"    # Landroid/text/Editable;
    .param p2, "c"    # C
    .param p3, "at"    # I

    .line 33
    invoke-direct {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->handleTypedChar(Landroid/text/Editable;CI)V

    return-void
.end method

.method public static final synthetic access$hidePopup(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 1
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->hidePopup()V

    return-void
.end method

.method public static final synthetic access$insert(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "s"    # Ljava/lang/String;

    .line 33
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->insert(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$moveSelection(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;I)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "delta"    # I

    .line 33
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->moveSelection(I)V

    return-void
.end method

.method public static final synthetic access$setDirtyText$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Z)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "<set-?>"    # Z

    .line 33
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->dirtyText:Z

    return-void
.end method

.method public static final synthetic access$updateCompletion(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Z)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "explicit"    # Z

    .line 33
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->updateCompletion(Z)V

    return-void
.end method

.method public static final synthetic access$updateLines(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 1
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 33
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->updateLines()V

    return-void
.end method

.method private final checkSyntax()V
    .registers 9

    .line 395
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->commit()V

    .line 396
    nop

    .line 397
    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    :try_start_7
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->Companion:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;->access$getSyntaxCheck(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;)Lorg/luaj/vm2/Globals;

    move-result-object v3

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5, v2, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->transpile$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lorg/luaj/vm2/Globals;->load(Ljava/lang/String;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    .line 398
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->status:Landroid/widget/TextView;

    const-string v4, "No syntax errors"

    check-cast v4, Ljava/lang/CharSequence;

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 399
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->status:Landroid/widget/TextView;

    const v4, -0xd174a9

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextColor(I)V
    :try_end_4a
    .catch Lorg/luaj/vm2/LuaError; {:try_start_7 .. :try_end_4a} :catch_4b

    goto :goto_99

    .line 400
    :catch_4b
    move-exception v3

    .line 401
    .local v3, "e":Lorg/luaj/vm2/LuaError;
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->status:Landroid/widget/TextView;

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaError;->getMessage()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_56

    const-string v5, "Syntax error"

    :cond_56
    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 402
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->status:Landroid/widget/TextView;

    const v5, -0xaaab

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 403
    new-instance v4, Lkotlin/text/Regex;

    const-string v5, ":(\\d+):"

    invoke-direct {v4, v5}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaError;->getMessage()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_72

    const-string v5, ""

    :cond_72
    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v4, v5, v2, v1, v0}, Lkotlin/text/Regex;->find$default(Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/text/MatchResult;

    move-result-object v0

    if-eqz v0, :cond_99

    invoke-interface {v0}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_99

    const/4 v1, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_99

    invoke-static {v0}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_99

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 488
    .local v0, "it\\1":I
    const/4 v1, 0x0

    .line 403
    .local v1, "$i$a$-let-ScriptEditor$checkSyntax$1\\1\\403\\0":I
    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->goToLine(I)V

    .line 405
    .end local v0    # "it\\1":I
    .end local v1    # "$i$a$-let-ScriptEditor$checkSyntax$1\\1\\403\\0":I
    .end local v3    # "e":Lorg/luaj/vm2/LuaError;
    :cond_99
    :goto_99
    return-void
.end method

.method static final commitRunnable$lambda$1(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 1
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 44
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->commit()V

    return-void
.end method

.method static final completeRunnable$lambda$2(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 45
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->updateCompletion(Z)V

    return-void
.end method

.method private final cursorScreenPos(I)Lkotlin/Pair;
    .registers 15
    .param p1, "popupH"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 293
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getLayout()Landroid/text/Layout;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    if-nez v0, :cond_12

    invoke-static {v2, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    return-object v0

    .line 294
    .local v0, "layout":Landroid/text/Layout;
    :cond_12
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getSelectionStart()I

    move-result v2

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v3

    invoke-interface {v3}, Landroid/text/Editable;->length()I

    move-result v3

    invoke-static {v2, v1, v3}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v2

    .line 295
    .local v2, "cur":I
    invoke-virtual {v0, v2}, Landroid/text/Layout;->getLineForOffset(I)I

    move-result v3

    .line 296
    .local v3, "line":I
    const/4 v4, 0x2

    new-array v4, v4, [I

    .local v4, "loc":[I
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v5, v4}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getLocationOnScreen([I)V

    .line 297
    aget v1, v4, v1

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getTotalPaddingLeft()I

    move-result v5

    add-int/2addr v1, v5

    invoke-virtual {v0, v2}, Landroid/text/Layout;->getPrimaryHorizontal(I)F

    move-result v5

    float-to-int v5, v5

    add-int/2addr v1, v5

    .line 298
    .local v1, "x":I
    const/4 v5, 0x1

    aget v6, v4, v5

    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getTotalPaddingTop()I

    move-result v7

    add-int/2addr v6, v7

    invoke-virtual {v0, v3}, Landroid/text/Layout;->getLineBottom(I)I

    move-result v7

    add-int/2addr v6, v7

    .line 299
    .local v6, "below":I
    aget v5, v4, v5

    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getTotalPaddingTop()I

    move-result v7

    add-int/2addr v5, v7

    invoke-virtual {v0, v3}, Landroid/text/Layout;->getLineTop(I)I

    move-result v7

    add-int/2addr v5, v7

    sub-int/2addr v5, p1

    .line 300
    .local v5, "above":I
    new-instance v7, Landroid/graphics/Rect;

    invoke-direct {v7}, Landroid/graphics/Rect;-><init>()V

    .local v7, "frame":Landroid/graphics/Rect;
    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v8, v7}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 301
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupSize()Lkotlin/Pair;

    move-result-object v8

    invoke-virtual {v8}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v8

    .line 302
    .local v8, "w":I
    iget v9, v7, Landroid/graphics/Rect;->left:I

    iget v10, v7, Landroid/graphics/Rect;->left:I

    iget v11, v7, Landroid/graphics/Rect;->right:I

    sub-int/2addr v11, v8

    invoke-static {v10, v11}, Ljava/lang/Math;->max(II)I

    move-result v10

    invoke-static {v1, v9, v10}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v9

    .line 303
    .local v9, "cx":I
    add-int v10, v6, p1

    iget v11, v7, Landroid/graphics/Rect;->bottom:I

    if-le v10, v11, :cond_92

    iget v10, v7, Landroid/graphics/Rect;->top:I

    if-le v5, v10, :cond_92

    move v10, v5

    goto :goto_93

    :cond_92
    move v10, v6

    .line 304
    .local v10, "cy":I
    :goto_93
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v11, v12}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    return-object v11
.end method

.method private final find()V
    .registers 6

    .line 416
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Dialogs;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    const-string v3, "Find"

    const-string v4, ""

    invoke-virtual {v0, v1, v3, v4, v2}, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->prompt(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 423
    return-void
.end method

.method static final find$lambda$35(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;)Lkotlin/Unit;
    .registers 10
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p1, "q"    # Ljava/lang/String;

    const-string v0, "q"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 417
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_11

    const/4 v0, 0x1

    goto :goto_12

    :cond_11
    move v0, v1

    :goto_12
    if-eqz v0, :cond_17

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 418
    :cond_17
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 419
    .local v0, "t":Ljava/lang/String;
    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getSelectionEnd()I

    move-result v3

    invoke-static {v3, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v3, p1

    .end local p1    # "q":Ljava/lang/String;
    .local v3, "q":Ljava/lang/String;
    invoke-static/range {v2 .. v7}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I

    move-result p1

    .line 420
    move-object v2, v3

    .end local v3    # "q":Ljava/lang/String;
    .local v2, "q":Ljava/lang/String;
    .local p1, "i":I
    if-gez p1, :cond_44

    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I

    move-result p1

    .line 421
    :cond_44
    if-ltz p1, :cond_56

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->requestFocus()Z

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    add-int/2addr v3, p1

    invoke-virtual {v1, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setSelection(II)V

    goto :goto_76

    :cond_56
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->status:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\""

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\" not found"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 422
    :goto_76
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private final goToLine(I)V
    .registers 14
    .param p1, "line"    # I

    .line 408
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v0

    .line 409
    .local v0, "t":Landroid/text/Editable;
    const/4 v1, 0x0

    .line 410
    .local v1, "idx":I
    add-int/lit8 v2, p1, -0x1

    const/4 v3, 0x0

    move v6, v1

    move v1, v3

    .end local v1    # "idx":I
    .local v6, "idx":I
    :goto_c
    if-ge v1, v2, :cond_27

    move v10, v1

    .line 488
    .local v10, "it\\1":I
    const/4 v11, 0x0

    .line 410
    .local v11, "$i$a$-repeat-ScriptEditor$goToLine$1\\1\\410\\0":I
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v4, v0

    check-cast v4, Ljava/lang/CharSequence;

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/16 v5, 0xa

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v4

    .local v4, "n\\1":I
    if-ltz v4, :cond_24

    add-int/lit8 v5, v4, 0x1

    move v6, v5

    .end local v4    # "n\\1":I
    .end local v10    # "it\\1":I
    .end local v11    # "$i$a$-repeat-ScriptEditor$goToLine$1\\1\\410\\0":I
    :cond_24
    add-int/lit8 v1, v1, 0x1

    goto :goto_c

    .line 411
    :cond_27
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->requestFocus()Z

    .line 412
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-interface {v0}, Landroid/text/Editable;->length()I

    move-result v2

    invoke-static {v6, v3, v2}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setSelection(I)V

    .line 413
    return-void
.end method

.method private final handleNewline(Landroid/text/Editable;)V
    .registers 32
    .param p1, "s"    # Landroid/text/Editable;

    .line 176
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string v0, "end"

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getSelectionStart()I

    move-result v3

    .line 177
    .local v3, "pos":I
    if-gtz v3, :cond_f

    return-void

    .line 178
    :cond_f
    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    add-int/lit8 v6, v3, -0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/16 v5, 0xa

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lkotlin/text/StringsKt;->lastIndexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v4

    .line 488
    .local v4, "it\\1":I
    const/4 v5, 0x0

    .line 178
    .local v5, "$i$a$-let-ScriptEditor$handleNewline$prevStart$1\\1\\178\\0":I
    const/4 v6, 0x0

    if-gez v4, :cond_23

    move v7, v6

    goto :goto_25

    :cond_23
    add-int/lit8 v7, v4, 0x1

    .line 179
    .end local v4    # "it\\1":I
    .end local v5    # "$i$a$-let-ScriptEditor$handleNewline$prevStart$1\\1\\178\\0":I
    .local v7, "prevStart":I
    :goto_25
    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    add-int/lit8 v5, v3, -0x1

    invoke-static {v7, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-interface {v4, v7, v5}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    .line 180
    .local v4, "prevLine":Ljava/lang/String;
    move-object v5, v4

    .local v5, "$this$takeWhile\\2":Ljava/lang/String;
    const/4 v8, 0x0

    .line 489
    .local v8, "$i$f$takeWhile\\2\\180":I
    const/4 v9, 0x0

    .local v9, "index\\2":I
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v10

    :goto_3d
    const-string v11, "substring(...)"

    const/16 v12, 0x9

    const/16 v13, 0x20

    if-ge v9, v10, :cond_60

    .line 490
    invoke-virtual {v5, v9}, Ljava/lang/String;->charAt(I)C

    move-result v15

    .local v15, "it\\3":C
    const/16 v16, 0x0

    .line 180
    .local v16, "$i$a$-takeWhile-ScriptEditor$handleNewline$baseIndent$1\\3\\490\\0":I
    if-eq v15, v13, :cond_51

    if-eq v15, v12, :cond_51

    move v15, v6

    goto :goto_52

    :cond_51
    const/4 v15, 0x1

    .line 490
    .end local v15    # "it\\3":C
    .end local v16    # "$i$a$-takeWhile-ScriptEditor$handleNewline$baseIndent$1\\3\\490\\0":I
    :goto_52
    if-nez v15, :cond_5d

    .line 491
    invoke-virtual {v5, v6, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v5, v10

    goto :goto_61

    .line 489
    :cond_5d
    add-int/lit8 v9, v9, 0x1

    goto :goto_3d

    .line 493
    .end local v9    # "index\\2":I
    :cond_60
    nop

    .line 180
    .end local v5    # "$this$takeWhile\\2":Ljava/lang/String;
    .end local v8    # "$i$f$takeWhile\\2\\180":I
    :goto_61
    nop

    .line 181
    .local v5, "baseIndent":Ljava/lang/String;
    move-object v8, v4

    check-cast v8, Ljava/lang/CharSequence;

    invoke-static {v8}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    .line 182
    .local v8, "t":Ljava/lang/String;
    new-instance v9, Lkotlin/text/Regex;

    const-string v10, "(^|[^\\w])function\\s*[\\w.:]*\\s*\\([^)]*\\)\\s*$"

    invoke-direct {v9, v10}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    move-object v10, v8

    check-cast v10, Ljava/lang/CharSequence;

    invoke-virtual {v9, v10}, Lkotlin/text/Regex;->containsMatchIn(Ljava/lang/CharSequence;)Z

    move-result v9

    .line 183
    .local v9, "opensFunction":Z
    const-string v10, " then"

    const/4 v15, 0x2

    const/4 v12, 0x0

    invoke-static {v8, v10, v6, v15, v12}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v17

    const-string v13, "elseif"

    const-string v14, "do"

    const-string v6, " do"

    const-string v12, "else"

    if-nez v17, :cond_d8

    const-string v15, "then"

    invoke-static {v8, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v19

    if-nez v19, :cond_d8

    move-object/from16 v19, v4

    move/from16 v20, v7

    move/from16 v21, v9

    const/4 v4, 0x0

    const/4 v7, 0x2

    const/4 v9, 0x0

    .end local v4    # "prevLine":Ljava/lang/String;
    .end local v7    # "prevStart":I
    .end local v9    # "opensFunction":Z
    .local v19, "prevLine":Ljava/lang/String;
    .local v20, "prevStart":I
    .local v21, "opensFunction":Z
    invoke-static {v8, v6, v9, v7, v4}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v22

    if-nez v22, :cond_d5

    invoke-static {v8, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_d5

    if-nez v21, :cond_d5

    const-string v4, "repeat"

    invoke-static {v8, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_d5

    const-string v4, "{"

    move-object/from16 v22, v5

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x2

    .end local v5    # "baseIndent":Ljava/lang/String;
    .local v22, "baseIndent":Ljava/lang/String;
    invoke-static {v8, v4, v5, v9, v7}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_e0

    invoke-static {v8, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_e0

    invoke-static {v8, v13, v5, v9, v7}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_d3

    invoke-static {v8, v15, v5, v9, v7}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_e0

    :cond_d3
    const/4 v4, 0x0

    goto :goto_e1

    .end local v22    # "baseIndent":Ljava/lang/String;
    .restart local v5    # "baseIndent":Ljava/lang/String;
    :cond_d5
    move-object/from16 v22, v5

    .end local v5    # "baseIndent":Ljava/lang/String;
    .restart local v22    # "baseIndent":Ljava/lang/String;
    goto :goto_e0

    .end local v19    # "prevLine":Ljava/lang/String;
    .end local v20    # "prevStart":I
    .end local v21    # "opensFunction":Z
    .end local v22    # "baseIndent":Ljava/lang/String;
    .restart local v4    # "prevLine":Ljava/lang/String;
    .restart local v5    # "baseIndent":Ljava/lang/String;
    .restart local v7    # "prevStart":I
    .restart local v9    # "opensFunction":Z
    :cond_d8
    move-object/from16 v19, v4

    move-object/from16 v22, v5

    move/from16 v20, v7

    move/from16 v21, v9

    .end local v4    # "prevLine":Ljava/lang/String;
    .end local v5    # "baseIndent":Ljava/lang/String;
    .end local v7    # "prevStart":I
    .end local v9    # "opensFunction":Z
    .restart local v19    # "prevLine":Ljava/lang/String;
    .restart local v20    # "prevStart":I
    .restart local v21    # "opensFunction":Z
    .restart local v22    # "baseIndent":Ljava/lang/String;
    :cond_e0
    :goto_e0
    const/4 v4, 0x1

    .line 184
    .local v4, "opensBlock":Z
    :goto_e1
    move-object/from16 v5, v22

    .line 185
    .local v5, "indent":Ljava/lang/String;
    if-eqz v4, :cond_f8

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v9, "    "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 186
    :cond_f8
    const/4 v7, 0x1

    iput-boolean v7, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 187
    nop

    .line 188
    :try_start_fc
    move-object v9, v5

    check-cast v9, Ljava/lang/CharSequence;

    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    move-result v9
    :try_end_103
    .catchall {:try_start_fc .. :try_end_103} :catchall_2f0

    if-lez v9, :cond_107

    move v9, v7

    goto :goto_108

    :cond_107
    const/4 v9, 0x0

    :goto_108
    if-eqz v9, :cond_11c

    :try_start_10a
    move-object v9, v5

    check-cast v9, Ljava/lang/CharSequence;

    invoke-interface {v2, v3, v9}, Landroid/text/Editable;->insert(ILjava/lang/CharSequence;)Landroid/text/Editable;
    :try_end_110
    .catchall {:try_start_10a .. :try_end_110} :catchall_111

    goto :goto_11c

    .line 208
    :catchall_111
    move-exception v0

    move/from16 v23, v3

    move/from16 v27, v4

    move-object/from16 v18, v5

    move-object/from16 v5, v22

    goto/16 :goto_2f9

    .line 189
    :cond_11c
    :goto_11c
    :try_start_11c
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v9
    :try_end_120
    .catchall {:try_start_11c .. :try_end_120} :catchall_2f0

    add-int/2addr v9, v3

    .line 191
    .local v9, "cur":I
    move/from16 v23, v3

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v15, 0x0

    .end local v3    # "pos":I
    .local v23, "pos":I
    :try_start_126
    invoke-static {v8, v10, v3, v7, v15}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v10
    :try_end_12a
    .catchall {:try_start_126 .. :try_end_12a} :catchall_2e8

    if-eqz v10, :cond_132

    :try_start_12c
    invoke-static {v8, v13, v3, v7, v15}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v10
    :try_end_130
    .catchall {:try_start_12c .. :try_end_130} :catchall_1ab

    if-eqz v10, :cond_145

    :cond_132
    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v15, 0x0

    :try_start_135
    invoke-static {v8, v6, v3, v7, v15}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v6
    :try_end_139
    .catchall {:try_start_135 .. :try_end_139} :catchall_2e8

    if-nez v6, :cond_145

    :try_start_13b
    invoke-static {v8, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3
    :try_end_13f
    .catchall {:try_start_13b .. :try_end_13f} :catchall_1ab

    if-nez v3, :cond_145

    if-nez v21, :cond_145

    const/4 v3, 0x0

    goto :goto_146

    :cond_145
    const/4 v3, 0x1

    .line 192
    .local v3, "needsEnd":Z
    :goto_146
    if-eqz v3, :cond_2dc

    :try_start_148
    invoke-static {v8, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2dc

    .line 193
    move/from16 v26, v9

    .line 194
    .local v26, "nextStart":I
    move-object/from16 v24, v2

    check-cast v24, Ljava/lang/CharSequence;

    const/16 v28, 0x4

    const/16 v29, 0x0

    const/16 v25, 0xa

    const/16 v27, 0x0

    invoke-static/range {v24 .. v29}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v6
    :try_end_160
    .catchall {:try_start_148 .. :try_end_160} :catchall_2e8

    move/from16 v7, v26

    .line 488
    .end local v26    # "nextStart":I
    .local v6, "it\\4":I
    .local v7, "nextStart":I
    const/4 v10, 0x0

    .line 194
    .local v10, "$i$a$-let-ScriptEditor$handleNewline$restLineEnd$1\\4\\194\\0":I
    if-gez v6, :cond_16a

    :try_start_165
    invoke-interface {v2}, Landroid/text/Editable;->length()I

    move-result v13
    :try_end_169
    .catchall {:try_start_165 .. :try_end_169} :catchall_1ab

    move v6, v13

    .line 195
    .end local v10    # "$i$a$-let-ScriptEditor$handleNewline$restLineEnd$1\\4\\194\\0":I
    .local v6, "restLineEnd":I
    :cond_16a
    :try_start_16a
    move-object v10, v2

    check-cast v10, Ljava/lang/CharSequence;

    invoke-interface {v10, v7, v6}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    .line 196
    .local v10, "afterCursor":Ljava/lang/String;
    invoke-interface {v2}, Landroid/text/Editable;->length()I

    move-result v13
    :try_end_179
    .catchall {:try_start_16a .. :try_end_179} :catchall_2e8

    if-ge v6, v13, :cond_17e

    add-int/lit8 v13, v6, 0x1

    goto :goto_17f

    :cond_17e
    const/4 v13, -0x1

    :goto_17f
    move/from16 v26, v13

    .line 197
    .local v26, "nextLineStart":I
    if-ltz v26, :cond_1b4

    :try_start_183
    move-object v13, v2

    check-cast v13, Ljava/lang/CharSequence;

    move-object/from16 v24, v2

    check-cast v24, Ljava/lang/CharSequence;

    const/16 v28, 0x4

    const/16 v29, 0x0

    const/16 v25, 0xa

    const/16 v27, 0x0

    invoke-static/range {v24 .. v29}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v14

    move/from16 v15, v26

    .line 488
    .end local v26    # "nextLineStart":I
    .local v14, "it\\5":I
    .local v15, "nextLineStart":I
    const/16 v24, 0x0

    .line 197
    .local v24, "$i$a$-let-ScriptEditor$handleNewline$nextLine$1\\5\\197\\0":I
    if-gez v14, :cond_1a2

    invoke-interface {v2}, Landroid/text/Editable;->length()I

    move-result v25

    move/from16 v14, v25

    .end local v14    # "it\\5":I
    .end local v24    # "$i$a$-let-ScriptEditor$handleNewline$nextLine$1\\5\\197\\0":I
    :cond_1a2
    invoke-interface {v13, v15, v14}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v13
    :try_end_1aa
    .catchall {:try_start_183 .. :try_end_1aa} :catchall_1ab

    goto :goto_1b8

    .line 208
    .end local v3    # "needsEnd":Z
    .end local v6    # "restLineEnd":I
    .end local v7    # "nextStart":I
    .end local v9    # "cur":I
    .end local v10    # "afterCursor":Ljava/lang/String;
    .end local v15    # "nextLineStart":I
    :catchall_1ab
    move-exception v0

    move/from16 v27, v4

    move-object/from16 v18, v5

    move-object/from16 v5, v22

    goto/16 :goto_2f9

    .line 197
    .restart local v3    # "needsEnd":Z
    .restart local v6    # "restLineEnd":I
    .restart local v7    # "nextStart":I
    .restart local v9    # "cur":I
    .restart local v10    # "afterCursor":Ljava/lang/String;
    .restart local v26    # "nextLineStart":I
    :cond_1b4
    move/from16 v15, v26

    .end local v26    # "nextLineStart":I
    .restart local v15    # "nextLineStart":I
    :try_start_1b6
    const-string v13, ""

    .line 198
    .local v13, "nextLine":Ljava/lang/String;
    :goto_1b8
    move-object v14, v13

    .local v14, "$this$takeWhile\\6":Ljava/lang/String;
    const/16 v24, 0x0

    .line 494
    .local v24, "$i$f$takeWhile\\6\\198":I
    const/16 v25, 0x0

    move/from16 v26, v3

    .end local v3    # "needsEnd":Z
    .local v25, "index\\6":I
    .local v26, "needsEnd":Z
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v3
    :try_end_1c3
    .catchall {:try_start_1b6 .. :try_end_1c3} :catchall_2e8

    move/from16 v27, v4

    move/from16 v4, v25

    .end local v25    # "index\\6":I
    .local v4, "index\\6":I
    .local v27, "opensBlock":Z
    :goto_1c7
    if-ge v4, v3, :cond_1fe

    .line 495
    :try_start_1c9
    invoke-virtual {v14, v4}, Ljava/lang/String;->charAt(I)C

    move-result v25
    :try_end_1cd
    .catchall {:try_start_1c9 .. :try_end_1cd} :catchall_1f7

    move/from16 v28, v25

    .local v28, "it\\7":C
    const/16 v25, 0x0

    .line 198
    .local v25, "$i$a$-takeWhile-ScriptEditor$handleNewline$nextIndent$1\\7\\495\\0":I
    move/from16 v29, v3

    move-object/from16 v18, v5

    move/from16 v3, v28

    const/16 v5, 0x20

    .end local v5    # "indent":Ljava/lang/String;
    .end local v28    # "it\\7":C
    .local v3, "it\\7":C
    .local v18, "indent":Ljava/lang/String;
    if-eq v3, v5, :cond_1e1

    const/16 v5, 0x9

    if-eq v3, v5, :cond_1e3

    const/4 v3, 0x0

    goto :goto_1e4

    :cond_1e1
    const/16 v5, 0x9

    :cond_1e3
    const/4 v3, 0x1

    .line 495
    .end local v3    # "it\\7":C
    .end local v25    # "$i$a$-takeWhile-ScriptEditor$handleNewline$nextIndent$1\\7\\495\\0":I
    :goto_1e4
    if-nez v3, :cond_1f0

    .line 496
    const/4 v3, 0x0

    :try_start_1e7
    invoke-virtual {v14, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_1ee
    .catchall {:try_start_1e7 .. :try_end_1ee} :catchall_2a5

    move-object v14, v5

    goto :goto_201

    .line 494
    :cond_1f0
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v5, v18

    move/from16 v3, v29

    goto :goto_1c7

    .line 208
    .end local v4    # "index\\6":I
    .end local v6    # "restLineEnd":I
    .end local v7    # "nextStart":I
    .end local v9    # "cur":I
    .end local v10    # "afterCursor":Ljava/lang/String;
    .end local v13    # "nextLine":Ljava/lang/String;
    .end local v14    # "$this$takeWhile\\6":Ljava/lang/String;
    .end local v15    # "nextLineStart":I
    .end local v18    # "indent":Ljava/lang/String;
    .end local v24    # "$i$f$takeWhile\\6\\198":I
    .end local v26    # "needsEnd":Z
    .restart local v5    # "indent":Ljava/lang/String;
    :catchall_1f7
    move-exception v0

    move-object/from16 v18, v5

    move-object/from16 v5, v22

    .end local v5    # "indent":Ljava/lang/String;
    .restart local v18    # "indent":Ljava/lang/String;
    goto/16 :goto_2f9

    .line 494
    .end local v18    # "indent":Ljava/lang/String;
    .restart local v4    # "index\\6":I
    .restart local v5    # "indent":Ljava/lang/String;
    .restart local v6    # "restLineEnd":I
    .restart local v7    # "nextStart":I
    .restart local v9    # "cur":I
    .restart local v10    # "afterCursor":Ljava/lang/String;
    .restart local v13    # "nextLine":Ljava/lang/String;
    .restart local v14    # "$this$takeWhile\\6":Ljava/lang/String;
    .restart local v15    # "nextLineStart":I
    .restart local v24    # "$i$f$takeWhile\\6\\198":I
    .restart local v26    # "needsEnd":Z
    :cond_1fe
    move-object/from16 v18, v5

    .line 498
    .end local v4    # "index\\6":I
    .end local v5    # "indent":Ljava/lang/String;
    .restart local v18    # "indent":Ljava/lang/String;
    nop

    .line 198
    .end local v14    # "$this$takeWhile\\6":Ljava/lang/String;
    .end local v24    # "$i$f$takeWhile\\6\\198":I
    :goto_201
    :try_start_201
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v3

    .line 199
    .local v3, "nextIndent":I
    move-object v4, v13

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v4}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    .line 200
    .local v4, "nt":Ljava/lang/String;
    const/4 v5, 0x0

    const/4 v11, 0x2

    const/4 v14, 0x0

    invoke-static {v4, v0, v14, v11, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v16
    :try_end_217
    .catchall {:try_start_201 .. :try_end_217} :catchall_2d8

    if-nez v16, :cond_267

    :try_start_219
    invoke-static {v4, v12, v14, v11, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_267

    const-string v12, "until"

    invoke-static {v4, v12, v14, v11, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_267

    const-string v12, ")"

    invoke-static {v4, v12, v14, v11, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_267

    .line 201
    move-object v5, v4

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-lez v5, :cond_23a

    const/4 v5, 0x1

    goto :goto_23b

    :cond_23a
    const/4 v5, 0x0

    :goto_23b
    if-eqz v5, :cond_243

    invoke-virtual/range {v22 .. v22}, Ljava/lang/String;->length()I

    move-result v5

    if-gt v3, v5, :cond_267

    :cond_243
    move-object v5, v10

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v5}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-lez v5, :cond_258

    const/4 v5, 0x1

    goto :goto_259

    :cond_258
    const/4 v5, 0x0

    :goto_259
    if-nez v5, :cond_267

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v1, v5}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->unbalancedEnds(Ljava/lang/String;)I

    move-result v5

    if-lez v5, :cond_267

    const/4 v14, 0x0

    goto :goto_268

    :cond_267
    const/4 v14, 0x1

    .line 200
    :goto_268
    nop

    .line 202
    .local v14, "closed":Z
    if-nez v14, :cond_2d1

    .line 203
    if-eqz v21, :cond_282

    new-instance v5, Lkotlin/text/Regex;

    const-string v11, "\\(\\s*function"

    invoke-direct {v5, v11}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    move-object v11, v8

    check-cast v11, Ljava/lang/CharSequence;

    invoke-virtual {v5, v11}, Lkotlin/text/Regex;->containsMatchIn(Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_27b
    .catchall {:try_start_219 .. :try_end_27b} :catchall_2a5

    if-eqz v5, :cond_282

    move/from16 v16, v3

    move-object/from16 v17, v4

    goto :goto_2a2

    :cond_282
    :try_start_282
    const-string v5, "function()"

    move/from16 v16, v3

    const/4 v3, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    .end local v3    # "nextIndent":I
    .local v16, "nextIndent":I
    invoke-static {v8, v5, v3, v12, v11}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5
    :try_end_28d
    .catchall {:try_start_282 .. :try_end_28d} :catchall_2d8

    if-eqz v5, :cond_2a9

    :try_start_28f
    move-object/from16 v3, v19

    check-cast v3, Ljava/lang/CharSequence;

    const-string v5, "("

    check-cast v5, Ljava/lang/CharSequence;

    move-object/from16 v17, v4

    const/4 v4, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    .end local v4    # "nt":Ljava/lang/String;
    .local v17, "nt":Ljava/lang/String;
    invoke-static {v3, v5, v4, v12, v11}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2ab

    :goto_2a2
    const-string v0, "end)"
    :try_end_2a4
    .catchall {:try_start_28f .. :try_end_2a4} :catchall_2a5

    goto :goto_2ab

    .line 208
    .end local v6    # "restLineEnd":I
    .end local v7    # "nextStart":I
    .end local v9    # "cur":I
    .end local v10    # "afterCursor":Ljava/lang/String;
    .end local v13    # "nextLine":Ljava/lang/String;
    .end local v14    # "closed":Z
    .end local v15    # "nextLineStart":I
    .end local v16    # "nextIndent":I
    .end local v17    # "nt":Ljava/lang/String;
    .end local v26    # "needsEnd":Z
    :catchall_2a5
    move-exception v0

    move-object/from16 v5, v22

    goto :goto_2f9

    .line 203
    .restart local v4    # "nt":Ljava/lang/String;
    .restart local v6    # "restLineEnd":I
    .restart local v7    # "nextStart":I
    .restart local v9    # "cur":I
    .restart local v10    # "afterCursor":Ljava/lang/String;
    .restart local v13    # "nextLine":Ljava/lang/String;
    .restart local v14    # "closed":Z
    .restart local v15    # "nextLineStart":I
    .restart local v16    # "nextIndent":I
    .restart local v26    # "needsEnd":Z
    :cond_2a9
    move-object/from16 v17, v4

    .line 204
    .end local v4    # "nt":Ljava/lang/String;
    .local v0, "close":Ljava/lang/String;
    .restart local v17    # "nt":Ljava/lang/String;
    :cond_2ab
    :goto_2ab
    :try_start_2ab
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3
    :try_end_2b6
    .catchall {:try_start_2ab .. :try_end_2b6} :catchall_2d8

    move-object/from16 v5, v22

    .end local v22    # "baseIndent":Ljava/lang/String;
    .local v5, "baseIndent":Ljava/lang/String;
    :try_start_2b8
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v2, v9, v3}, Landroid/text/Editable;->insert(ILjava/lang/CharSequence;)Landroid/text/Editable;

    .line 205
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v3, v9}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setSelection(I)V
    :try_end_2ce
    .catchall {:try_start_2b8 .. :try_end_2ce} :catchall_2cf

    goto :goto_2e4

    .line 208
    .end local v0    # "close":Ljava/lang/String;
    .end local v6    # "restLineEnd":I
    .end local v7    # "nextStart":I
    .end local v9    # "cur":I
    .end local v10    # "afterCursor":Ljava/lang/String;
    .end local v13    # "nextLine":Ljava/lang/String;
    .end local v14    # "closed":Z
    .end local v15    # "nextLineStart":I
    .end local v16    # "nextIndent":I
    .end local v17    # "nt":Ljava/lang/String;
    .end local v26    # "needsEnd":Z
    :catchall_2cf
    move-exception v0

    goto :goto_2f9

    .line 202
    .end local v5    # "baseIndent":Ljava/lang/String;
    .restart local v3    # "nextIndent":I
    .restart local v4    # "nt":Ljava/lang/String;
    .restart local v6    # "restLineEnd":I
    .restart local v7    # "nextStart":I
    .restart local v9    # "cur":I
    .restart local v10    # "afterCursor":Ljava/lang/String;
    .restart local v13    # "nextLine":Ljava/lang/String;
    .restart local v14    # "closed":Z
    .restart local v15    # "nextLineStart":I
    .restart local v22    # "baseIndent":Ljava/lang/String;
    .restart local v26    # "needsEnd":Z
    :cond_2d1
    move/from16 v16, v3

    move-object/from16 v17, v4

    move-object/from16 v5, v22

    .end local v3    # "nextIndent":I
    .end local v4    # "nt":Ljava/lang/String;
    .end local v22    # "baseIndent":Ljava/lang/String;
    .restart local v5    # "baseIndent":Ljava/lang/String;
    .restart local v16    # "nextIndent":I
    .restart local v17    # "nt":Ljava/lang/String;
    goto :goto_2e4

    .line 208
    .end local v5    # "baseIndent":Ljava/lang/String;
    .end local v6    # "restLineEnd":I
    .end local v7    # "nextStart":I
    .end local v9    # "cur":I
    .end local v10    # "afterCursor":Ljava/lang/String;
    .end local v13    # "nextLine":Ljava/lang/String;
    .end local v14    # "closed":Z
    .end local v15    # "nextLineStart":I
    .end local v16    # "nextIndent":I
    .end local v17    # "nt":Ljava/lang/String;
    .end local v26    # "needsEnd":Z
    .restart local v22    # "baseIndent":Ljava/lang/String;
    :catchall_2d8
    move-exception v0

    move-object/from16 v5, v22

    .end local v22    # "baseIndent":Ljava/lang/String;
    .restart local v5    # "baseIndent":Ljava/lang/String;
    goto :goto_2f9

    .line 192
    .end local v18    # "indent":Ljava/lang/String;
    .end local v27    # "opensBlock":Z
    .local v3, "needsEnd":Z
    .local v4, "opensBlock":Z
    .local v5, "indent":Ljava/lang/String;
    .restart local v9    # "cur":I
    .restart local v22    # "baseIndent":Ljava/lang/String;
    :cond_2dc
    move/from16 v26, v3

    move/from16 v27, v4

    move-object/from16 v18, v5

    move-object/from16 v5, v22

    .line 208
    .end local v3    # "needsEnd":Z
    .end local v4    # "opensBlock":Z
    .end local v9    # "cur":I
    .end local v22    # "baseIndent":Ljava/lang/String;
    .local v5, "baseIndent":Ljava/lang/String;
    .restart local v18    # "indent":Ljava/lang/String;
    .restart local v27    # "opensBlock":Z
    :goto_2e4
    const/4 v3, 0x0

    iput-boolean v3, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 209
    return-void

    .line 208
    .end local v18    # "indent":Ljava/lang/String;
    .end local v27    # "opensBlock":Z
    .restart local v4    # "opensBlock":Z
    .local v5, "indent":Ljava/lang/String;
    .restart local v22    # "baseIndent":Ljava/lang/String;
    :catchall_2e8
    move-exception v0

    move/from16 v27, v4

    move-object/from16 v18, v5

    move-object/from16 v5, v22

    .end local v4    # "opensBlock":Z
    .end local v22    # "baseIndent":Ljava/lang/String;
    .local v5, "baseIndent":Ljava/lang/String;
    .restart local v18    # "indent":Ljava/lang/String;
    .restart local v27    # "opensBlock":Z
    goto :goto_2f9

    .end local v18    # "indent":Ljava/lang/String;
    .end local v23    # "pos":I
    .end local v27    # "opensBlock":Z
    .local v3, "pos":I
    .restart local v4    # "opensBlock":Z
    .local v5, "indent":Ljava/lang/String;
    .restart local v22    # "baseIndent":Ljava/lang/String;
    :catchall_2f0
    move-exception v0

    move/from16 v23, v3

    move/from16 v27, v4

    move-object/from16 v18, v5

    move-object/from16 v5, v22

    .end local v3    # "pos":I
    .end local v4    # "opensBlock":Z
    .end local v22    # "baseIndent":Ljava/lang/String;
    .local v5, "baseIndent":Ljava/lang/String;
    .restart local v18    # "indent":Ljava/lang/String;
    .restart local v23    # "pos":I
    .restart local v27    # "opensBlock":Z
    :goto_2f9
    const/4 v3, 0x0

    iput-boolean v3, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    throw v0
.end method

.method private final handleTypedChar(Landroid/text/Editable;CI)V
    .registers 12
    .param p1, "s"    # Landroid/text/Editable;
    .param p2, "c"    # C
    .param p3, "at"    # I

    .line 224
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 225
    nop

    .line 226
    const/4 v1, 0x0

    :try_start_5
    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I

    const/16 v3, 0x27

    const/16 v4, 0x22

    const/4 v5, -0x1

    if-ne v2, p3, :cond_63

    add-int/lit8 v2, p3, 0x1

    invoke-interface {p1}, Landroid/text/Editable;->length()I

    move-result v6

    if-ge v2, v6, :cond_63

    add-int/lit8 v2, p3, 0x1

    invoke-interface {p1, v2}, Landroid/text/Editable;->charAt(I)C

    move-result v2

    if-ne v2, p2, :cond_63

    const/4 v2, 0x5

    new-array v2, v2, [Ljava/lang/Character;

    const/16 v6, 0x29

    invoke-static {v6}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v6

    aput-object v6, v2, v1

    const/16 v6, 0x5d

    invoke-static {v6}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v6

    aput-object v6, v2, v0

    const/16 v6, 0x7d

    invoke-static {v6}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v6

    const/4 v7, 0x2

    aput-object v6, v2, v7

    invoke-static {v4}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v6

    const/4 v7, 0x3

    aput-object v6, v2, v7

    invoke-static {v3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v6

    const/4 v7, 0x4

    aput-object v6, v2, v7

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v6

    invoke-interface {v2, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_63

    .line 227
    add-int/lit8 v0, p3, 0x1

    add-int/lit8 v2, p3, 0x2

    invoke-interface {p1, v0, v2}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    .line 228
    iput v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I
    :try_end_5f
    .catchall {:try_start_5 .. :try_end_5f} :catchall_df

    .line 229
    nop

    .line 241
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 229
    return-void

    .line 232
    :cond_63
    :try_start_63
    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I

    if-ltz v2, :cond_70

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I

    if-gt p3, v2, :cond_70

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I

    add-int/2addr v2, v0

    iput v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I

    .line 233
    :cond_70
    const/16 v0, 0xa

    if-ne p2, v0, :cond_76

    iput v5, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I

    .line 234
    :cond_76
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->pairs:Ljava/util/Map;

    invoke-static {p2}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Character;

    if-eqz v0, :cond_dc

    invoke-virtual {v0}, Ljava/lang/Character;->charValue()C

    move-result v0

    .line 235
    .local v0, "close":C
    add-int/lit8 v2, p3, 0x1

    invoke-interface {p1}, Landroid/text/Editable;->length()I

    move-result v5

    if-ge v2, v5, :cond_97

    add-int/lit8 v2, p3, 0x1

    invoke-interface {p1, v2}, Landroid/text/Editable;->charAt(I)C

    move-result v2

    goto :goto_99

    :cond_97
    const/16 v2, 0x20

    .line 236
    .local v2, "next":C
    :goto_99
    invoke-static {v2}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v5

    if-nez v5, :cond_d9

    const/16 v5, 0x5f

    if-eq v2, v5, :cond_d9

    .line 237
    if-eq p2, v4, :cond_a7

    if-ne p2, v3, :cond_c0

    :cond_a7
    if-lez p3, :cond_c0

    add-int/lit8 v3, p3, -0x1

    invoke-interface {p1, v3}, Landroid/text/Editable;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v3

    if-nez v3, :cond_bd

    add-int/lit8 v3, p3, -0x1

    invoke-interface {p1, v3}, Landroid/text/Editable;->charAt(I)C

    move-result v3
    :try_end_bb
    .catchall {:try_start_63 .. :try_end_bb} :catchall_df

    if-ne v3, p2, :cond_c0

    .line 241
    .end local v0    # "close":C
    .end local v2    # "next":C
    :cond_bd
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 237
    .restart local v0    # "close":C
    .restart local v2    # "next":C
    return-void

    .line 238
    :cond_c0
    add-int/lit8 v3, p3, 0x1

    :try_start_c2
    invoke-static {v0}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {p1, v3, v4}, Landroid/text/Editable;->insert(ILjava/lang/CharSequence;)Landroid/text/Editable;

    .line 239
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    add-int/lit8 v4, p3, 0x1

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->setSelection(I)V

    .line 240
    add-int/lit8 v3, p3, 0x1

    iput v3, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->autoClosedAt:I
    :try_end_d6
    .catchall {:try_start_c2 .. :try_end_d6} :catchall_df

    .line 241
    .end local v0    # "close":C
    .end local v2    # "next":C
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 242
    return-void

    .line 241
    :cond_d9
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 236
    .restart local v0    # "close":C
    .restart local v2    # "next":C
    return-void

    .line 241
    .end local v0    # "close":C
    .end local v2    # "next":C
    :cond_dc
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    .line 234
    return-void

    .line 241
    :catchall_df
    move-exception v0

    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->suppressCompletion:Z

    throw v0
.end method

.method private final hidePopup()V
    .registers 4

    .line 309
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completion:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    .line 310
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popup:Landroid/widget/PopupWindow;

    if-eqz v0, :cond_11

    .line 488
    .local v0, "it\\1":Landroid/widget/PopupWindow;
    const/4 v1, 0x0

    .line 310
    .local v1, "$i$a$-let-ScriptEditor$hidePopup$1\\1\\310\\0":I
    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v2

    if-eqz v2, :cond_11

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    .line 311
    .end local v0    # "it\\1":Landroid/widget/PopupWindow;
    .end local v1    # "$i$a$-let-ScriptEditor$hidePopup$1\\1\\310\\0":I
    :cond_11
    return-void
.end method

.method private final highlight()V
    .registers 21

    .line 426
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v2

    .line 427
    .local v2, "s":Landroid/text/Editable;
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTheme()Lcom/exampletest/mobilestudiotest/core/Theme;

    move-result-object v3

    .line 428
    .local v3, "th":Lcom/exampletest/mobilestudiotest/core/Theme;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Theme;->getSynKeyword()I

    move-result v4

    .local v4, "kw":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Theme;->getSynString()I

    move-result v5

    .local v5, "str":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Theme;->getSynNumber()I

    move-result v6

    .local v6, "num":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Theme;->getSynComment()I

    move-result v7

    .local v7, "comment":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Theme;->getSynBuiltin()I

    move-result v8

    .line 429
    .local v8, "builtin":I
    const/4 v0, 0x1

    iput-boolean v0, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlighting:Z

    .line 430
    nop

    .line 431
    const/4 v9, 0x0

    :try_start_27
    invoke-interface {v2}, Landroid/text/Editable;->length()I

    move-result v10

    const-class v11, Landroid/text/style/ForegroundColorSpan;

    invoke-interface {v2, v9, v10, v11}, Landroid/text/Editable;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v10

    invoke-static {v10}, Lkotlin/jvm/internal/ArrayIteratorKt;->iterator([Ljava/lang/Object;)Ljava/util/Iterator;

    move-result-object v10

    :goto_35
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_45

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/text/style/ForegroundColorSpan;

    .local v11, "sp":Landroid/text/style/ForegroundColorSpan;
    invoke-interface {v2, v11}, Landroid/text/Editable;->removeSpan(Ljava/lang/Object;)V

    .end local v11    # "sp":Landroid/text/style/ForegroundColorSpan;
    goto :goto_35

    .line 432
    :cond_45
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    .line 433
    .local v10, "text":Ljava/lang/String;
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v11

    .line 434
    .local v11, "n":I
    const/4 v12, 0x0

    move v15, v12

    .line 443
    .local v15, "i":I
    :goto_4f
    if-ge v15, v11, :cond_18a

    .line 444
    invoke-virtual {v10, v15}, Ljava/lang/String;->charAt(I)C

    move-result v12

    .line 445
    .local v12, "c":C
    nop

    .line 446
    const/16 v13, 0x2d

    if-ne v12, v13, :cond_97

    add-int/lit8 v14, v15, 0x1

    if-ge v14, v11, :cond_97

    add-int/lit8 v14, v15, 0x1

    invoke-virtual {v10, v14}, Ljava/lang/String;->charAt(I)C

    move-result v14

    if-ne v14, v13, :cond_97

    .line 447
    add-int/lit8 v13, v15, 0x2

    invoke-static {v11, v10, v13}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$longLevel(ILjava/lang/String;I)I

    move-result v13

    .line 448
    .local v13, "lvl":I
    if-ltz v13, :cond_78

    add-int/lit8 v14, v15, 0x4

    add-int/2addr v14, v13

    invoke-static {v10, v11, v14, v13}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$longClose(Ljava/lang/String;III)I

    move-result v14

    move/from16 v19, v13

    goto :goto_92

    :cond_78
    move v14, v13

    .end local v13    # "lvl":I
    .local v14, "lvl":I
    move-object v13, v10

    check-cast v13, Ljava/lang/CharSequence;

    const/16 v17, 0x4

    const/16 v18, 0x0

    move/from16 v16, v14

    .end local v14    # "lvl":I
    .local v16, "lvl":I
    const/16 v14, 0xa

    move/from16 v19, v16

    .end local v16    # "lvl":I
    .local v19, "lvl":I
    const/16 v16, 0x0

    invoke-static/range {v13 .. v18}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v13

    .line 488
    .local v13, "it\\1":I
    const/4 v14, 0x0

    .line 448
    .local v14, "$i$a$-let-ScriptEditor$highlight$e$1\\1\\448\\0":I
    if-gez v13, :cond_91

    move v14, v11

    goto :goto_92

    :cond_91
    move v14, v13

    .line 449
    .end local v13    # "it\\1":I
    .local v14, "e":I
    :goto_92
    invoke-static {v2, v11, v15, v14, v7}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$span(Landroid/text/Editable;IIII)V

    move v15, v14

    .end local v14    # "e":I
    .end local v19    # "lvl":I
    goto :goto_4f

    .line 451
    :cond_97
    const/16 v13, 0x22

    if-eq v12, v13, :cond_15a

    const/16 v13, 0x27

    if-eq v12, v13, :cond_15a

    const/16 v13, 0x60

    if-ne v12, v13, :cond_a7

    move/from16 v16, v0

    goto/16 :goto_15c

    .line 457
    :cond_a7
    const/16 v13, 0x5b

    if-ne v12, v13, :cond_c1

    invoke-static {v11, v10, v15}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$longLevel(ILjava/lang/String;I)I

    move-result v13

    if-ltz v13, :cond_c1

    invoke-static {v11, v10, v15}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$longLevel(ILjava/lang/String;I)I

    move-result v13

    .local v13, "l":I
    add-int/lit8 v14, v15, 0x2

    add-int/2addr v14, v13

    invoke-static {v10, v11, v14, v13}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$longClose(Ljava/lang/String;III)I

    move-result v14

    .restart local v14    # "e":I
    invoke-static {v2, v11, v15, v14, v5}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$span(Landroid/text/Editable;IIII)V

    move v15, v14

    .end local v13    # "l":I
    .end local v14    # "e":I
    goto :goto_4f

    .line 458
    :cond_c1
    invoke-static {v12}, Ljava/lang/Character;->isDigit(C)Z

    move-result v13

    const/16 v14, 0x2e

    move/from16 v16, v0

    const/16 v0, 0x5f

    if-eqz v13, :cond_f3

    .line 459
    move v13, v15

    .line 460
    .local v13, "j":I
    :goto_ce
    if-ge v13, v11, :cond_ea

    invoke-virtual {v10, v13}, Ljava/lang/String;->charAt(I)C

    move-result v17

    invoke-static/range {v17 .. v17}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v17

    if-nez v17, :cond_e6

    invoke-virtual {v10, v13}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-eq v9, v14, :cond_e6

    invoke-virtual {v10, v13}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-ne v9, v0, :cond_ea

    :cond_e6
    add-int/lit8 v13, v13, 0x1

    const/4 v9, 0x0

    goto :goto_ce

    .line 461
    :cond_ea
    invoke-static {v2, v11, v15, v13, v6}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$span(Landroid/text/Editable;IIII)V

    move v15, v13

    move/from16 v0, v16

    const/4 v9, 0x0

    .end local v13    # "j":I
    goto/16 :goto_4f

    .line 463
    :cond_f3
    invoke-static {v12}, Ljava/lang/Character;->isLetter(C)Z

    move-result v9

    if-nez v9, :cond_102

    if-eq v12, v0, :cond_102

    .line 472
    add-int/lit8 v15, v15, 0x1

    move/from16 v0, v16

    const/4 v9, 0x0

    goto/16 :goto_4f

    .line 464
    :cond_102
    move v9, v15

    .line 465
    .local v9, "j":I
    :goto_103
    if-ge v9, v11, :cond_118

    invoke-virtual {v10, v9}, Ljava/lang/String;->charAt(I)C

    move-result v13

    invoke-static {v13}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v13

    if-nez v13, :cond_115

    invoke-virtual {v10, v9}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-ne v13, v0, :cond_118

    :cond_115
    add-int/lit8 v9, v9, 0x1

    goto :goto_103

    .line 466
    :cond_118
    invoke-virtual {v10, v15, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const-string v13, "substring(...)"

    invoke-static {v0, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 467
    .local v0, "w":Ljava/lang/String;
    if-lez v15, :cond_138

    add-int/lit8 v13, v15, -0x1

    invoke-virtual {v10, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    if-eq v13, v14, :cond_135

    add-int/lit8 v13, v15, -0x1

    invoke-virtual {v10, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    const/16 v14, 0x3a

    if-ne v13, v14, :cond_138

    :cond_135
    move/from16 v13, v16

    goto :goto_139

    :cond_138
    const/4 v13, 0x0

    .line 468
    .local v13, "prevDot":Z
    :goto_139
    if-nez v13, :cond_147

    sget-object v14, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->keywords:Ljava/util/Set;

    invoke-interface {v14, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_147

    invoke-static {v2, v11, v15, v9, v4}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$span(Landroid/text/Editable;IIII)V

    goto :goto_154

    .line 469
    :cond_147
    if-nez v13, :cond_154

    sget-object v14, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->builtins:Ljava/util/Set;

    invoke-interface {v14, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_154

    invoke-static {v2, v11, v15, v9, v8}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$span(Landroid/text/Editable;IIII)V

    .line 470
    :cond_154
    :goto_154
    move v15, v9

    move/from16 v0, v16

    const/4 v9, 0x0

    .end local v0    # "w":Ljava/lang/String;
    .end local v9    # "j":I
    .end local v13    # "prevDot":Z
    goto/16 :goto_4f

    .line 451
    :cond_15a
    move/from16 v16, v0

    .line 452
    :goto_15c
    add-int/lit8 v0, v15, 0x1

    .line 453
    .local v0, "j":I
    :goto_15e
    if-ge v0, v11, :cond_17b

    invoke-virtual {v10, v0}, Ljava/lang/String;->charAt(I)C

    move-result v9

    if-eq v9, v12, :cond_17b

    invoke-virtual {v10, v0}, Ljava/lang/String;->charAt(I)C

    move-result v9

    const/16 v13, 0xa

    if-eq v9, v13, :cond_17b

    invoke-virtual {v10, v0}, Ljava/lang/String;->charAt(I)C

    move-result v9

    const/16 v13, 0x5c

    if-ne v9, v13, :cond_178

    add-int/lit8 v0, v0, 0x1

    :cond_178
    add-int/lit8 v0, v0, 0x1

    goto :goto_15e

    .line 454
    :cond_17b
    add-int/lit8 v9, v0, 0x1

    invoke-static {v9, v11}, Ljava/lang/Math;->min(II)I

    move-result v9

    .line 455
    .end local v0    # "j":I
    .restart local v9    # "j":I
    invoke-static {v2, v11, v15, v9, v5}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight$span(Landroid/text/Editable;IIII)V
    :try_end_184
    .catchall {:try_start_27 .. :try_end_184} :catchall_18f

    move v15, v9

    move/from16 v0, v16

    const/4 v9, 0x0

    .end local v9    # "j":I
    goto/16 :goto_4f

    .line 476
    .end local v10    # "text":Ljava/lang/String;
    .end local v11    # "n":I
    .end local v12    # "c":C
    .end local v15    # "i":I
    :cond_18a
    const/4 v9, 0x0

    iput-boolean v9, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlighting:Z

    .line 477
    nop

    .line 478
    return-void

    .line 476
    :catchall_18f
    move-exception v0

    const/4 v9, 0x0

    iput-boolean v9, v1, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlighting:Z

    throw v0
.end method

.method private static final highlight$longClose(Ljava/lang/String;III)I
    .registers 11
    .param p0, "text"    # Ljava/lang/String;
    .param p1, "n"    # I
    .param p2, "from"    # I
    .param p3, "lvl"    # I

    .line 436
    const-string v0, "="

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0, p3}, Lkotlin/text/StringsKt;->repeat(Ljava/lang/CharSequence;I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .local v2, "close":Ljava/lang/String;
    move-object v1, p0

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    move v3, p2

    .end local p2    # "from":I
    .local v3, "from":I
    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I

    move-result p2

    .local p2, "e":I
    if-gez p2, :cond_2e

    move v0, p1

    goto :goto_33

    :cond_2e
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v0

    add-int/2addr v0, p2

    :goto_33
    return v0
.end method

.method private static final highlight$longLevel(ILjava/lang/String;I)I
    .registers 9
    .param p0, "n"    # I
    .param p1, "text"    # Ljava/lang/String;
    .param p2, "at"    # I

    .line 438
    const/4 v0, -0x1

    if-ge p2, p0, :cond_27

    invoke-virtual {p1, p2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x5b

    if-ne v1, v2, :cond_27

    .line 439
    add-int/lit8 v1, p2, 0x1

    .local v1, "j":I
    const/4 v3, 0x0

    .line 440
    .local v3, "l":I
    :goto_e
    if-ge v1, p0, :cond_1d

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/16 v5, 0x3d

    if-ne v4, v5, :cond_1d

    add-int/lit8 v3, v3, 0x1

    add-int/lit8 v1, v1, 0x1

    goto :goto_e

    .line 441
    :cond_1d
    if-ge v1, p0, :cond_26

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ne v4, v2, :cond_26

    move v0, v3

    :cond_26
    return v0

    .line 438
    .end local v1    # "j":I
    .end local v3    # "l":I
    :cond_27
    return v0
.end method

.method private static final highlight$span(Landroid/text/Editable;IIII)V
    .registers 8
    .param p0, "s"    # Landroid/text/Editable;
    .param p1, "n"    # I
    .param p2, "a"    # I
    .param p3, "b"    # I
    .param p4, "c"    # I

    .line 435
    if-le p3, p2, :cond_10

    new-instance v0, Landroid/text/style/ForegroundColorSpan;

    invoke-direct {v0, p4}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-static {p3, p1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/16 v2, 0x21

    invoke-interface {p0, v0, p2, v1, v2}, Landroid/text/Editable;->setSpan(Ljava/lang/Object;III)V

    :cond_10
    return-void
.end method

.method static final highlightRunnable$lambda$0(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 1
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 43
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlight()V

    return-void
.end method

.method private final insert(Ljava/lang/String;)V
    .registers 8
    .param p1, "s"    # Ljava/lang/String;

    .line 245
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getSelectionStart()I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v0

    .line 246
    .local v0, "st":I
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getSelectionEnd()I

    move-result v2

    invoke-static {v2, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v1

    .line 247
    .local v1, "en":I
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v4

    move-object v5, p1

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v2, v3, v4, v5}, Landroid/text/Editable;->replace(IILjava/lang/CharSequence;)Landroid/text/Editable;

    .line 248
    return-void
.end method

.method static final lambda$22$lambda$21(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p3, "pos"    # I

    .line 139
    invoke-direct {p0, p3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->acceptCompletion(I)V

    return-void
.end method

.method private final moveSelection(I)V
    .registers 6
    .param p1, "delta"    # I

    .line 314
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completion:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    if-eqz v0, :cond_32

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getItems()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_32

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    .line 315
    .local v0, "n":I
    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->selectedIdx:I

    add-int/2addr v1, p1

    add-int/lit8 v2, v0, -0x1

    const/4 v3, 0x0

    invoke-static {v1, v3, v2}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v1

    iput v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->selectedIdx:I

    .line 316
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupList:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type android.widget.BaseAdapter"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Landroid/widget/BaseAdapter;

    invoke-virtual {v1}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 317
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupList:Landroid/widget/ListView;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->selectedIdx:I

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->smoothScrollToPosition(I)V

    .line 318
    return-void

    .line 314
    .end local v0    # "n":I
    :cond_32
    return-void
.end method

.method private final popupSize()Lkotlin/Pair;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 266
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completion:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getItems()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_f

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    .line 267
    .local v0, "n":I
    :goto_10
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "getContext(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v4, 0x41f00000    # 30.0f

    invoke-virtual {v1, v2, v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    .line 268
    .local v1, "rowH":I
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v5, 0x438c0000    # 280.0f

    invoke-virtual {v2, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x7

    invoke-static {v0, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    mul-int/2addr v4, v1

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v3, 0x40800000    # 4.0f

    invoke-virtual {v5, v6, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    add-int/2addr v4, v3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    return-object v2
.end method

.method private final positionPopup()V
    .registers 6

    .line 285
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popup:Landroid/widget/PopupWindow;

    if-nez v0, :cond_5

    return-void

    .line 286
    .local v0, "p":Landroid/widget/PopupWindow;
    :cond_5
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupSize()Lkotlin/Pair;

    move-result-object v1

    invoke-virtual {v1}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    .local v2, "w":I
    invoke-virtual {v1}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    .line 287
    .local v1, "h":I
    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->cursorScreenPos(I)Lkotlin/Pair;

    move-result-object v3

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    .local v4, "x":I
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    .line 288
    .local v3, "y":I
    invoke-virtual {v0, v4, v3, v2, v1}, Landroid/widget/PopupWindow;->update(IIII)V

    .line 289
    return-void
.end method

.method private final showPopup()V
    .registers 8

    .line 272
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupSize()Lkotlin/Pair;

    move-result-object v0

    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    .local v1, "w":I
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 273
    .local v0, "h":I
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popup:Landroid/widget/PopupWindow;

    const/4 v3, 0x0

    if-nez v2, :cond_41

    new-instance v2, Landroid/widget/PopupWindow;

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupList:Landroid/widget/ListView;

    check-cast v4, Landroid/view/View;

    invoke-direct {v2, v4, v1, v0, v3}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;IIZ)V

    move-object v4, v2

    .local v4, "$this$showPopup_u24lambda_u2429\\1":Landroid/widget/PopupWindow;
    const/4 v5, 0x0

    .line 274
    .local v5, "$i$a$-apply-ScriptEditor$showPopup$p$1\\1\\273\\0":I
    const/4 v6, 0x1

    invoke-virtual {v4, v6}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    .line 275
    const/4 v6, 0x2

    invoke-virtual {v4, v6}, Landroid/widget/PopupWindow;->setInputMethodMode(I)V

    .line 276
    const/high16 v6, 0x41000000    # 8.0f

    invoke-virtual {v4, v6}, Landroid/widget/PopupWindow;->setElevation(F)V

    .line 277
    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda2;

    invoke-direct {v6, p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    invoke-virtual {v4, v6}, Landroid/widget/PopupWindow;->setOnDismissListener(Landroid/widget/PopupWindow$OnDismissListener;)V

    .line 278
    iput-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popup:Landroid/widget/PopupWindow;

    .line 279
    nop

    .line 273
    .end local v4    # "$this$showPopup_u24lambda_u2429\\1":Landroid/widget/PopupWindow;
    .end local v5    # "$i$a$-apply-ScriptEditor$showPopup$p$1\\1\\273\\0":I
    nop

    .line 280
    .local v2, "p":Landroid/widget/PopupWindow;
    :cond_41
    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->cursorScreenPos(I)Lkotlin/Pair;

    move-result-object v4

    invoke-virtual {v4}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    .local v5, "x":I
    invoke-virtual {v4}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    .line 281
    .local v4, "y":I
    invoke-virtual {v2}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v6

    if-eqz v6, :cond_63

    invoke-virtual {v2, v5, v4, v1, v0}, Landroid/widget/PopupWindow;->update(IIII)V

    goto :goto_6a

    :cond_63
    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    check-cast v6, Landroid/view/View;

    invoke-virtual {v2, v6, v3, v5, v4}, Landroid/widget/PopupWindow;->showAtLocation(Landroid/view/View;III)V

    .line 282
    :goto_6a
    return-void
.end method

.method static final showPopup$lambda$29$lambda$28(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 277
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completion:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    return-void
.end method

.method static final syntaxCheck_delegate$lambda$37()Lorg/luaj/vm2/Globals;
    .registers 1

    .line 64
    invoke-static {}, Lorg/luaj/vm2/lib/jse/JsePlatform;->standardGlobals()Lorg/luaj/vm2/Globals;

    move-result-object v0

    return-object v0
.end method

.method private final unbalancedEnds(Ljava/lang/String;)I
    .registers 10
    .param p1, "text"    # Ljava/lang/String;

    .line 213
    const/4 v0, 0x0

    .local v0, "opens":I
    const/4 v1, 0x0

    .line 214
    .local v1, "ends":I
    move-object v2, p1

    check-cast v2, Ljava/lang/CharSequence;

    new-instance v3, Lkotlin/text/Regex;

    const-string v4, "--\\[(=*)\\[[\\s\\S]*?]\\1]|--[^\\n]*|\"(\\\\.|[^\"\\\\\\n])*\"|\'(\\\\.|[^\'\\\\\\n])*\'|\\[(=*)\\[[\\s\\S]*?]\\5]"

    invoke-direct {v3, v4}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const-string v4, " "

    invoke-virtual {v3, v2, v4}, Lkotlin/text/Regex;->replace(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 215
    .local v2, "noStrings":Ljava/lang/String;
    new-instance v3, Lkotlin/text/Regex;

    const-string v4, "\\b(function|do|then|end|repeat|until|elseif)\\b"

    invoke-direct {v3, v4}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v3, v4, v7, v5, v6}, Lkotlin/text/Regex;->findAll$default(Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/sequences/Sequence;

    move-result-object v3

    invoke-interface {v3}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_27
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_85

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lkotlin/text/MatchResult;

    .line 216
    .local v4, "m":Lkotlin/text/MatchResult;
    invoke-interface {v4}, Lkotlin/text/MatchResult;->getValue()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    move-result v6

    sparse-switch v6, :sswitch_data_88

    goto :goto_27

    :sswitch_3f
    const-string v6, "function"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_76

    goto :goto_81

    :sswitch_48
    const-string v6, "until"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_62

    goto :goto_81

    :sswitch_51
    const-string v6, "then"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_76

    goto :goto_81

    :sswitch_5a
    const-string v6, "end"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_81

    :cond_62
    add-int/lit8 v1, v1, 0x1

    goto :goto_27

    :sswitch_65
    const-string v6, "do"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_76

    goto :goto_81

    :sswitch_6e
    const-string v6, "repeat"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_81

    :cond_76
    add-int/lit8 v0, v0, 0x1

    goto :goto_27

    :sswitch_79
    const-string v6, "elseif"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_82

    :cond_81
    :goto_81
    goto :goto_27

    :cond_82
    add-int/lit8 v0, v0, -0x1

    goto :goto_27

    .line 219
    .end local v4    # "m":Lkotlin/text/MatchResult;
    :cond_85
    sub-int v3, v0, v1

    return v3

    :sswitch_data_88
    .sparse-switch
        -0x4d7ecfea -> :sswitch_79
        -0x37b3d265 -> :sswitch_6e
        0xc8b -> :sswitch_65
        0x188db -> :sswitch_5a
        0x364e1d -> :sswitch_51
        0x6a47f5e -> :sswitch_48
        0x524f73d8 -> :sswitch_3f
    .end sparse-switch
.end method

.method private final updateCompletion(Z)V
    .registers 9
    .param p1, "explicit"    # Z

    .line 253
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Settings;->getAutocomplete()Z

    move-result v0

    if-nez v0, :cond_e

    if-nez p1, :cond_e

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->hidePopup()V

    return-void

    .line 254
    :cond_e
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getSelectionStart()I

    move-result v5

    .line 255
    .local v5, "cur":I
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getSelectionEnd()I

    move-result v0

    if-ne v5, v0, :cond_6c

    if-gez v5, :cond_20

    move v6, p1

    goto :goto_6d

    .line 256
    :cond_20
    :try_start_20
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Autocomplete;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_30} :catch_39

    move v6, p1

    .end local p1    # "explicit":Z
    .local v6, "explicit":Z
    :try_start_31
    invoke-virtual/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete;->complete(Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;IZ)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    move-result-object p1
    :try_end_35
    .catch Ljava/lang/Exception; {:try_start_31 .. :try_end_35} :catch_36

    goto :goto_3e

    :catch_36
    move-exception v0

    move-object p1, v0

    goto :goto_3c

    .end local v6    # "explicit":Z
    .restart local p1    # "explicit":Z
    :catch_39
    move-exception v0

    move v6, p1

    move-object p1, v0

    .restart local v6    # "explicit":Z
    .local p1, "<unused var>":Ljava/lang/Exception;
    :goto_3c
    const/4 v0, 0x0

    move-object p1, v0

    .line 257
    .local p1, "r":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;
    :goto_3e
    if-eqz p1, :cond_68

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getItems()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_68

    .line 258
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completion:Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    .line 259
    const/4 v0, 0x0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->selectedIdx:I

    .line 260
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupList:Landroid/widget/ListView;

    invoke-virtual {v1}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type android.widget.BaseAdapter"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Landroid/widget/BaseAdapter;

    invoke-virtual {v1}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 261
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->popupList:Landroid/widget/ListView;

    invoke-virtual {v1, v0}, Landroid/widget/ListView;->setSelection(I)V

    .line 262
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->showPopup()V

    .line 263
    return-void

    .line 257
    :cond_68
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->hidePopup()V

    return-void

    .line 255
    .end local v6    # "explicit":Z
    .local p1, "explicit":Z
    :cond_6c
    move v6, p1

    .end local p1    # "explicit":Z
    .restart local v6    # "explicit":Z
    :goto_6d
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->hidePopup()V

    return-void
.end method

.method private final updateLines()V
    .registers 11

    .line 373
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v0

    const-string v1, "getText(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/CharSequence;

    .local v0, "$this$count\\1":Ljava/lang/CharSequence;
    const/4 v1, 0x0

    .line 499
    .local v1, "$i$f$count\\1\\373":I
    const/4 v2, 0x0

    .line 500
    .local v2, "count\\1":I
    const/4 v3, 0x0

    move v4, v3

    :goto_11
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v5

    const/16 v6, 0xa

    const/4 v7, 0x1

    if-ge v4, v5, :cond_2a

    invoke-interface {v0, v4}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v5

    .local v5, "element\\1":C
    move v8, v5

    .local v8, "it\\2":C
    const/4 v9, 0x0

    .line 373
    .local v9, "$i$a$-count-ScriptEditor$updateLines$n$1\\2\\500\\0":I
    if-eq v8, v6, :cond_23

    move v7, v3

    .line 500
    .end local v8    # "it\\2":C
    .end local v9    # "$i$a$-count-ScriptEditor$updateLines$n$1\\2\\500\\0":I
    :cond_23
    if-eqz v7, :cond_27

    add-int/lit8 v2, v2, 0x1

    .end local v5    # "element\\1":C
    :cond_27
    add-int/lit8 v4, v4, 0x1

    goto :goto_11

    .line 501
    :cond_2a
    nop

    .line 373
    .end local v0    # "$this$count\\1":Ljava/lang/CharSequence;
    .end local v1    # "$i$f$count\\1\\373":I
    .end local v2    # "count\\1":I
    add-int/2addr v2, v7

    .line 374
    .local v2, "n":I
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->lineCount:I

    if-ne v2, v0, :cond_31

    return-void

    .line 375
    :cond_31
    iput v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->lineCount:I

    .line 376
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 377
    .local v0, "sb":Ljava/lang/StringBuilder;
    const/4 v1, 0x1

    .local v1, "i":I
    if-gt v1, v2, :cond_48

    :goto_3b
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    if-ge v1, v2, :cond_43

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_43
    if-eq v1, v2, :cond_48

    add-int/lit8 v1, v1, 0x1

    goto :goto_3b

    .line 378
    .end local v1    # "i":I
    :cond_48
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->lines:Landroid/widget/TextView;

    move-object v3, v0

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 379
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->status:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " lines"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 380
    return-void
.end method


# virtual methods
.method public final commit()V
    .registers 9

    .line 383
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->dirtyText:Z

    if-nez v0, :cond_5

    return-void

    .line 384
    :cond_5
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->dirtyText:Z

    .line 385
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->editor:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    .line 386
    .local v3, "text":Ljava/lang/String;
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v7

    monitor-enter v7

    const/4 v0, 0x0

    .line 387
    .local v0, "$i$a$-synchronized-ScriptEditor$commit$1\\1\\386\\0":I
    :try_start_1a
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v2, "Source"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_37

    .line 388
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v2, "Source"

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 389
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->markDirty()V

    .line 391
    :cond_37
    nop

    .end local v0    # "$i$a$-synchronized-ScriptEditor$commit$1\\1\\386\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3a
    .catchall {:try_start_1a .. :try_end_3a} :catchall_3c

    .line 386
    monitor-exit v7

    .line 392
    return-void

    .line 386
    :catchall_3c
    move-exception v0

    monitor-exit v7

    throw v0
.end method

.method public final getScript()Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 2

    .line 34
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->script:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-object v0
.end method

.method protected onDetachedFromWindow()V
    .registers 2

    .line 481
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completeRunnable:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 482
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->hidePopup()V

    .line 483
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->commit()V

    .line 484
    invoke-super {p0}, Landroid/widget/LinearLayout;->onDetachedFromWindow()V

    .line 485
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor.AnonymousClass15 (com.exampletest.mobilestudiotest.ui.ScriptEditor$15)
.class public final Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;
.super Ljava/lang/Object;
.source "ScriptEditor.kt"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;-><init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/model/Instance;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00003\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000c\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\r\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J*\u0010\t\u001a\u00020\n2\u0008\u0010\u000b\u001a\u0004\u0018\u00010\u000c2\u0006\u0010\r\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u00082\u0006\u0010\u000f\u001a\u00020\u0008H\u0016J*\u0010\u0010\u001a\u00020\n2\u0008\u0010\u000b\u001a\u0004\u0018\u00010\u000c2\u0006\u0010\r\u001a\u00020\u00082\u0006\u0010\u0011\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u0008H\u0016J\u0012\u0010\u0012\u001a\u00020\n2\u0008\u0010\u000b\u001a\u0004\u0018\u00010\u0013H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\u0006R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0014"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/ui/ScriptEditor$15",
        "Landroid/text/TextWatcher;",
        "autoIndent",
        "",
        "typed",
        "",
        "Ljava/lang/Character;",
        "typedAt",
        "",
        "beforeTextChanged",
        "",
        "s",
        "",
        "start",
        "count",
        "after",
        "onTextChanged",
        "before",
        "afterTextChanged",
        "Landroid/text/Editable;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private autoIndent:Z

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

.field private typed:Ljava/lang/Character;

.field private typedAt:I


# direct methods
.method constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 3
    .param p1, "$receiver"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    .line 142
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 145
    const/4 v0, -0x1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->typedAt:I

    .line 142
    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .registers 6
    .param p1, "s"    # Landroid/text/Editable;

    .line 153
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getHighlighting$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Z

    move-result v0

    if-nez v0, :cond_a2

    if-eqz p1, :cond_a2

    .line 154
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->autoIndent:Z

    if-eqz v0, :cond_1f

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Settings;->getAutoIndent()Z

    move-result v0

    if-eqz v0, :cond_1f

    .line 155
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->autoIndent:Z

    .line 156
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$handleNewline(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/text/Editable;)V

    goto :goto_3b

    .line 157
    :cond_1f
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->typed:Ljava/lang/Character;

    if-eqz v0, :cond_3b

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Settings;->getAutoCloseBrackets()Z

    move-result v0

    if-eqz v0, :cond_3b

    .line 158
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->typed:Ljava/lang/Character;

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v1}, Ljava/lang/Character;->charValue()C

    move-result v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->typedAt:I

    invoke-static {v0, p1, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$handleTypedChar(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/text/Editable;CI)V

    .line 160
    :cond_3b
    :goto_3b
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->typed:Ljava/lang/Character;

    .line 161
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$setDirtyText$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Z)V

    .line 162
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$updateLines(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    .line 163
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getHighlightRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getHighlightRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;

    move-result-object v1

    const-wide/16 v2, 0xfa

    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 164
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCommitRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCommitRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;

    move-result-object v1

    const-wide/16 v2, 0x320

    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 165
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Settings;->getAutocomplete()Z

    move-result v0

    if-eqz v0, :cond_a1

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getSuppressCompletion$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Z

    move-result v0

    if-nez v0, :cond_a1

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCompleteRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCompleteRunnable$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Ljava/lang/Runnable;

    move-result-object v1

    const-wide/16 v2, 0x46

    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 166
    :cond_a1
    return-void

    .line 153
    :cond_a2
    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .registers 5
    .param p1, "s"    # Ljava/lang/CharSequence;
    .param p2, "start"    # I
    .param p3, "count"    # I
    .param p4, "after"    # I

    .line 146
    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .registers 8
    .param p1, "s"    # Ljava/lang/CharSequence;
    .param p2, "start"    # I
    .param p3, "before"    # I
    .param p4, "count"    # I

    .line 148
    const/4 v0, 0x1

    if-ne p4, v0, :cond_17

    if-nez p3, :cond_17

    if-eqz p1, :cond_17

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-ge p2, v1, :cond_17

    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v1

    const/16 v2, 0xa

    if-ne v1, v2, :cond_17

    move v1, v0

    goto :goto_18

    :cond_17
    const/4 v1, 0x0

    :goto_18
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->autoIndent:Z

    .line 149
    if-ne p4, v0, :cond_2f

    if-nez p3, :cond_2f

    if-eqz p1, :cond_2f

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-ge p2, v0, :cond_2f

    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    invoke-static {v0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v0

    goto :goto_30

    :cond_2f
    const/4 v0, 0x0

    :goto_30
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->typed:Ljava/lang/Character;

    .line 150
    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$15;->typedAt:I

    .line 151
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor.CodeEdit (com.exampletest.mobilestudiotest.ui.ScriptEditor$CodeEdit)
.class final Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;
.super Landroid/widget/EditText;
.source "ScriptEditor.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "CodeEdit"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\u0008\u0082\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0018\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\tH\u0014J\u0018\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;",
        "Landroid/widget/EditText;",
        "c",
        "Landroid/content/Context;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/content/Context;)V",
        "onSelectionChanged",
        "",
        "selStart",
        "",
        "selEnd",
        "onKeyDown",
        "",
        "keyCode",
        "event",
        "Landroid/view/KeyEvent;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/content/Context;)V
    .registers 4
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .param p2, "c"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    const-string v0, "c"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-direct {p0, p2}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .registers 6
    .param p1, "keyCode"    # I
    .param p2, "event"    # Landroid/view/KeyEvent;

    const-string v0, "event"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getPopup$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Landroid/widget/PopupWindow;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_16

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v0

    if-ne v0, v2, :cond_16

    move v1, v2

    :cond_16
    if-eqz v1, :cond_3b

    .line 77
    sparse-switch p1, :sswitch_data_5c

    .line 81
    goto :goto_57

    :sswitch_1c
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$hidePopup(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    return v2

    .line 78
    :sswitch_22
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getSelectedIdx$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)I

    move-result v1

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$acceptCompletion(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;I)V

    return v2

    .line 79
    :sswitch_2e
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$moveSelection(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;I)V

    return v2

    .line 80
    :sswitch_34
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    const/4 v1, -0x1

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$moveSelection(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;I)V

    return v2

    .line 83
    :cond_3b
    const/16 v0, 0x3e

    if-ne p1, v0, :cond_4b

    invoke-virtual {p2}, Landroid/view/KeyEvent;->isCtrlPressed()Z

    move-result v0

    if-eqz v0, :cond_4b

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$updateCompletion(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Z)V

    return v2

    .line 84
    :cond_4b
    const/16 v0, 0x3d

    if-ne p1, v0, :cond_57

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    const-string v1, "    "

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$insert(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;)V

    return v2

    .line 85
    :cond_57
    :goto_57
    invoke-super {p0, p1, p2}, Landroid/widget/EditText;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result v0

    return v0

    :sswitch_data_5c
    .sparse-switch
        0x13 -> :sswitch_34
        0x14 -> :sswitch_2e
        0x3d -> :sswitch_22
        0x42 -> :sswitch_22
        0x6f -> :sswitch_1c
    .end sparse-switch
.end method

.method protected onSelectionChanged(II)V
    .registers 5
    .param p1, "selStart"    # I
    .param p2, "selEnd"    # I

    .line 71
    invoke-super {p0, p1, p2}, Landroid/widget/EditText;->onSelectionChanged(II)V

    .line 72
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCompletion$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    move-result-object v0

    .line 73
    .local v0, "r":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;
    if-eqz v0, :cond_20

    if-ne p1, p2, :cond_1b

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getStart()I

    move-result v1

    if-lt p1, v1, :cond_1b

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getEnd()I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    if-le p1, v1, :cond_20

    :cond_1b
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CodeEdit;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$hidePopup(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    .line 74
    :cond_20
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor.Companion (com.exampletest.mobilestudiotest.ui.ScriptEditor$Companion)
.class public final Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;
.super Ljava/lang/Object;
.source "ScriptEditor.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010$\n\u0002\u0010\u000c\n\u0000\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u0014\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001b\u0010\u0008\u001a\u00020\t8BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u000c\u0010\r\u001a\u0004\u0008\n\u0010\u000bR\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0011"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;",
        "",
        "<init>",
        "()V",
        "keywords",
        "",
        "",
        "builtins",
        "syntaxCheck",
        "Lorg/luaj/vm2/Globals;",
        "getSyntaxCheck",
        "()Lorg/luaj/vm2/Globals;",
        "syntaxCheck$delegate",
        "Lkotlin/Lazy;",
        "pairs",
        "",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 56
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;-><init>()V

    return-void
.end method

.method public static final synthetic access$getSyntaxCheck(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;)Lorg/luaj/vm2/Globals;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;

    .line 56
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$Companion;->getSyntaxCheck()Lorg/luaj/vm2/Globals;

    move-result-object v0

    return-object v0
.end method

.method private final getSyntaxCheck()Lorg/luaj/vm2/Globals;
    .registers 3

    .line 64
    invoke-static {}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getSyntaxCheck$delegate$cp()Lkotlin/Lazy;

    move-result-object v0

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "getValue(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Globals;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor.CompletionAdapter (com.exampletest.mobilestudiotest.ui.ScriptEditor$CompletionAdapter)
.class final Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;
.super Landroid/widget/BaseAdapter;
.source "ScriptEditor.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "CompletionAdapter"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nScriptEditor.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ScriptEditor.kt\ncom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,487:1\n1#2:488\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\u0008\u0082\u0004\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0008\u0010\u0004\u001a\u00020\u0005H\u0016J\u0012\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u0008\u001a\u00020\u0005H\u0016J\u0010\u0010\t\u001a\u00020\n2\u0006\u0010\u0008\u001a\u00020\u0005H\u0016J\"\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\u0008\u001a\u00020\u00052\u0008\u0010\r\u001a\u0004\u0018\u00010\u000c2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;",
        "Landroid/widget/BaseAdapter;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V",
        "getCount",
        "",
        "getItem",
        "Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;",
        "p",
        "getItemId",
        "",
        "getView",
        "Landroid/view/View;",
        "convert",
        "parent",
        "Landroid/view/ViewGroup;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 337
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public getCount()I
    .registers 2

    .line 338
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCompletion$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    move-result-object v0

    if-eqz v0, :cond_13

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getItems()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_13

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    goto :goto_14

    :cond_13
    const/4 v0, 0x0

    :goto_14
    return v0
.end method

.method public getItem(I)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;
    .registers 3
    .param p1, "p"    # I

    .line 339
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCompletion$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    move-result-object v0

    if-eqz v0, :cond_15

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getItems()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_15

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    goto :goto_16

    :cond_15
    const/4 v0, 0x0

    :goto_16
    return-object v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .registers 3
    .param p1, "p0"    # I

    .line 337
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;->getItem(I)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .registers 4
    .param p1, "p"    # I

    .line 340
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 26
    .param p1, "p"    # I
    .param p2, "convert"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    const-string v3, "parent"

    move-object/from16 v4, p3

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 342
    invoke-virtual {v4}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v3

    .line 343
    .local v3, "ctx":Landroid/content/Context;
    instance-of v5, v2, Landroid/widget/LinearLayout;

    if-eqz v5, :cond_19

    move-object v5, v2

    check-cast v5, Landroid/widget/LinearLayout;

    goto :goto_1a

    :cond_19
    const/4 v5, 0x0

    :goto_1a
    const/4 v6, 0x1

    const/4 v7, 0x0

    if-nez v5, :cond_d4

    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v8, v5

    .local v8, "$this$getView_u24lambda_u244\\1":Landroid/widget/LinearLayout;
    const/4 v9, 0x0

    .line 344
    .local v9, "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1\\1\\343\\0":I
    invoke-virtual {v8, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v10, 0x10

    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 345
    sget-object v10, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/high16 v11, 0x40c00000    # 6.0f

    invoke-virtual {v10, v3, v11}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v10

    sget-object v11, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v12, 0x41000000    # 8.0f

    invoke-virtual {v11, v3, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v11

    invoke-virtual {v8, v10, v7, v11, v7}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 346
    sget-object v10, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v11, 0x41f00000    # 30.0f

    invoke-virtual {v10, v3, v11}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v10

    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->setMinimumHeight(I)V

    .line 347
    new-instance v10, Landroid/widget/TextView;

    invoke-direct {v10, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 488
    move-object v11, v10

    .local v11, "$this$getView_u24lambda_u244_u24lambda_u240\\2":Landroid/widget/TextView;
    const/4 v13, 0x0

    .line 347
    .local v13, "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1$1\\2\\347\\1":I
    const/high16 v14, 0x41100000    # 9.0f

    invoke-virtual {v11, v14}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v14, 0x11

    invoke-virtual {v11, v14}, Landroid/widget/TextView;->setGravity(I)V

    sget-object v14, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v11, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const v14, -0xe1e1e2

    invoke-virtual {v11, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .end local v11    # "$this$getView_u24lambda_u244_u24lambda_u240\\2":Landroid/widget/TextView;
    .end local v13    # "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1$1\\2\\347\\1":I
    check-cast v10, Landroid/view/View;

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v13, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v14, 0x41b00000    # 22.0f

    invoke-virtual {v13, v3, v14}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v13

    sget-object v14, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v15, 0x41800000    # 16.0f

    invoke-virtual {v14, v3, v15}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v14

    invoke-direct {v11, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 488
    move-object v13, v11

    .local v13, "$this$getView_u24lambda_u244_u24lambda_u241\\3":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v14, 0x0

    .line 347
    .local v14, "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1$2\\3\\347\\1":I
    sget-object v15, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v15, v3, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v12

    iput v12, v13, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v13    # "$this$getView_u24lambda_u244_u24lambda_u241\\3":Landroid/widget/LinearLayout$LayoutParams;
    .end local v14    # "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1$2\\3\\347\\1":I
    sget-object v12, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v10, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 348
    new-instance v10, Landroid/widget/TextView;

    invoke-direct {v10, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 488
    move-object v11, v10

    .local v11, "$this$getView_u24lambda_u244_u24lambda_u242\\4":Landroid/widget/TextView;
    const/4 v12, 0x0

    .line 348
    .local v12, "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1$3\\4\\348\\1":I
    const/high16 v13, 0x41500000    # 13.0f

    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setTextSize(F)V

    sget-object v13, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    invoke-virtual {v11, v6}, Landroid/widget/TextView;->setSingleLine(Z)V

    .end local v11    # "$this$getView_u24lambda_u244_u24lambda_u242\\4":Landroid/widget/TextView;
    .end local v12    # "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1$3\\4\\348\\1":I
    check-cast v10, Landroid/view/View;

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v11, v7, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v10, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 349
    new-instance v10, Landroid/widget/TextView;

    invoke-direct {v10, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 488
    move-object v11, v10

    .local v11, "$this$getView_u24lambda_u244_u24lambda_u243\\5":Landroid/widget/TextView;
    const/4 v12, 0x0

    .line 349
    .local v12, "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1$4\\5\\349\\1":I
    const/high16 v13, 0x41200000    # 10.0f

    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v11, v6}, Landroid/widget/TextView;->setSingleLine(Z)V

    sget-object v13, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v13

    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .end local v11    # "$this$getView_u24lambda_u244_u24lambda_u243\\5":Landroid/widget/TextView;
    .end local v12    # "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1$4\\5\\349\\1":I
    check-cast v10, Landroid/view/View;

    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 350
    nop

    .line 343
    .end local v8    # "$this$getView_u24lambda_u244\\1":Landroid/widget/LinearLayout;
    .end local v9    # "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$row$1\\1\\343\\0":I
    nop

    .line 351
    .local v5, "row":Landroid/widget/LinearLayout;
    :cond_d4
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v8}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCompletion$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    move-result-object v8

    if-eqz v8, :cond_1e4

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getItems()Ljava/util/List;

    move-result-object v8

    if-eqz v8, :cond_1e4

    invoke-static {v8, v1}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;

    if-eqz v8, :cond_1e4

    .line 352
    .local v8, "item":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;
    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v9

    const-string v10, "null cannot be cast to non-null type android.widget.TextView"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v9, Landroid/widget/TextView;

    .local v9, "$this$getView_u24lambda_u246\\6":Landroid/widget/TextView;
    const/4 v11, 0x0

    .line 353
    .local v11, "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$1\\6\\352\\0":I
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;->getKind()Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    move-result-object v12

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->getBadge()Ljava/lang/String;

    move-result-object v12

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 354
    new-instance v12, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v12}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 488
    move-object v13, v12

    .local v13, "$this$getView_u24lambda_u246_u24lambda_u245\\7":Landroid/graphics/drawable/GradientDrawable;
    const/4 v14, 0x0

    .line 354
    .local v14, "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$1$1\\7\\354\\6":I
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;->getKind()Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;

    move-result-object v15

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Kind;->getColor()I

    move-result v15

    invoke-virtual {v13, v15}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    sget-object v15, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/high16 v7, 0x40400000    # 3.0f

    invoke-virtual {v15, v3, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v13, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v13    # "$this$getView_u24lambda_u246_u24lambda_u245\\7":Landroid/graphics/drawable/GradientDrawable;
    .end local v14    # "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$1$1\\7\\354\\6":I
    check-cast v12, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 355
    nop

    .line 352
    .end local v9    # "$this$getView_u24lambda_u246\\6":Landroid/widget/TextView;
    .end local v11    # "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$1\\6\\352\\0":I
    nop

    .line 356
    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    invoke-static {v7, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v7, Landroid/widget/TextView;

    .local v7, "$this$getView_u24lambda_u247\\8":Landroid/widget/TextView;
    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    const/4 v11, 0x0

    .line 357
    .local v11, "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$2\\8\\356\\0":I
    invoke-static {v9}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getCompletion$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;

    move-result-object v9

    if-eqz v9, :cond_144

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Result;->getPrefix()Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_144

    goto :goto_146

    :cond_144
    const-string v9, ""

    .line 358
    .local v9, "pre\\8":Ljava/lang/String;
    :goto_146
    new-instance v12, Landroid/text/SpannableString;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;->getLabel()Ljava/lang/String;

    move-result-object v13

    check-cast v13, Ljava/lang/CharSequence;

    invoke-direct {v12, v13}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 359
    .local v12, "sp\\8":Landroid/text/SpannableString;
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;->getLabel()Ljava/lang/String;

    move-result-object v13

    sget-object v14, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v13, v14}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "toLowerCase(...)"

    invoke-static {v13, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v16, v13

    check-cast v16, Ljava/lang/CharSequence;

    sget-object v13, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v13}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v20, 0x6

    const/16 v21, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v17, v13

    invoke-static/range {v16 .. v21}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I

    move-result v13

    .line 360
    .local v13, "i\\8":I
    move-object v14, v9

    check-cast v14, Ljava/lang/CharSequence;

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-lez v14, :cond_186

    move v14, v6

    goto :goto_187

    :cond_186
    const/4 v14, 0x0

    :goto_187
    if-eqz v14, :cond_19a

    if-ltz v13, :cond_19a

    new-instance v14, Landroid/text/style/StyleSpan;

    invoke-direct {v14, v6}, Landroid/text/style/StyleSpan;-><init>(I)V

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v6

    add-int/2addr v6, v13

    const/16 v15, 0x21

    invoke-virtual {v12, v14, v13, v6, v15}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 361
    :cond_19a
    move-object v6, v12

    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 362
    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getEDITOR_TEXT()I

    move-result v6

    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 363
    nop

    .line 356
    .end local v7    # "$this$getView_u24lambda_u247\\8":Landroid/widget/TextView;
    .end local v9    # "pre\\8":Ljava/lang/String;
    .end local v11    # "$i$a$-apply-ScriptEditor$CompletionAdapter$getView$2\\8\\356\\0":I
    .end local v12    # "sp\\8":Landroid/text/SpannableString;
    .end local v13    # "i\\8":I
    nop

    .line 364
    const/4 v6, 0x2

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-static {v6, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Landroid/widget/TextView;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;->getDetail()Ljava/lang/String;

    move-result-object v7

    check-cast v7, Ljava/lang/CharSequence;

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 365
    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$CompletionAdapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->access$getSelectedIdx$p(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)I

    move-result v6

    if-ne v1, v6, :cond_1dc

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getACCENT()I

    move-result v7

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getEDITOR_BG()I

    move-result v9

    const v10, 0x3f0ccccd    # 0.55f

    invoke-virtual {v6, v7, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend(IIF)I

    move-result v7

    goto :goto_1dd

    :cond_1dc
    const/4 v7, 0x0

    :goto_1dd
    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 366
    move-object v6, v5

    check-cast v6, Landroid/view/View;

    return-object v6

    .line 351
    .end local v8    # "item":Lcom/exampletest/mobilestudiotest/ui/Autocomplete$Item;
    :cond_1e4
    move-object v6, v5

    check-cast v6, Landroid/view/View;

    return-object v6
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "syntaxCheck_delegate$lambda$37"
    proto = "()Lorg/luaj/vm2/Globals;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    invoke-static {}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->syntaxCheck_delegate$lambda$37()Lorg/luaj/vm2/Globals;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "find$lambda$35"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->find$lambda$35(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda10 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda10)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "lambda$22$lambda$21"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/widget/AdapterView;Landroid/view/View;IJ)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda10;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 12

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda10;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-wide v4, p4

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->lambda$22$lambda$21(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/widget/AdapterView;Landroid/view/View;IJ)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "showPopup$lambda$29$lambda$28"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final onDismiss()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->showPopup$lambda$29$lambda$28(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "highlightRunnable$lambda$0"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->highlightRunnable$lambda$0(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "commitRunnable$lambda$1"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->commitRunnable$lambda$1(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "completeRunnable$lambda$2"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->completeRunnable$lambda$2(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "_init_$lambda$8"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->_init_$lambda$8(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "_init_$lambda$9"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->_init_$lambda$9(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda8 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnScrollChangedListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "_init_$lambda$16"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    return-void
.end method


# virtual methods
.method public final onScrollChanged()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->_init_$lambda$16(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda9 (com.exampletest.mobilestudiotest.ui.ScriptEditor$$ExternalSyntheticLambda9)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;"
    method = "_init_$lambda$18"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda9;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor$$ExternalSyntheticLambda9;->f$1:Ljava/lang/String;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;->_init_$lambda$18(Lcom/exampletest/mobilestudiotest/ui/ScriptEditor;Ljava/lang/String;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
