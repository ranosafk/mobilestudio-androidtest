###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel (com.exampletest.mobilestudiotest.ui.PropertiesPanel)
.class public final Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
.super Landroid/widget/LinearLayout;
.source "PropertiesPanel.kt"

# interfaces
.implements Lcom/exampletest/mobilestudiotest/core/Studio$Listener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;,
        Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Companion;,
        Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;,
        Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPropertiesPanel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PropertiesPanel.kt\ncom/exampletest/mobilestudiotest/ui/PropertiesPanel\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,384:1\n774#2:385\n865#2,2:386\n1056#2:388\n1#3:389\n382#4,7:390\n*S KotlinDebug\n*F\n+ 1 PropertiesPanel.kt\ncom/exampletest/mobilestudiotest/ui/PropertiesPanel\n*L\n214#1:385\n214#1:386,2\n226#1:388\n146#1:390,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000j\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0010\u0000\n\u0002\u0008\u0006\u0008\u0007\u0018\u0000 ,2\u00020\u00012\u00020\u0002:\u0004+,-.B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u0008\u0010\u0019\u001a\u00020\u0018H\u0014J\u0008\u0010\u001a\u001a\u00020\u0018H\u0014J\u0008\u0010\u001b\u001a\u00020\u0018H\u0016J\u0008\u0010\u001c\u001a\u00020\u0018H\u0016J\u0008\u0010\u001d\u001a\u00020\u0018H\u0016J \u0010\u001e\u001a\u00020\u00142\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u00142\u0006\u0010\"\u001a\u00020#H\u0002J\u0006\u0010$\u001a\u00020\u0018J\u001a\u0010%\u001a\u00020\u00142\u0006\u0010&\u001a\u00020\u000b2\u0008\u0010\u001f\u001a\u0004\u0018\u00010 H\u0002J\u001a\u0010\'\u001a\u00020\u00182\u0006\u0010&\u001a\u00020\u000b2\u0008\u0010(\u001a\u0004\u0018\u00010)H\u0002J\u0010\u0010*\u001a\u00020\u00182\u0006\u0010&\u001a\u00020\u000bH\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u000e\u001a\u00060\u000fR\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0012\u001a\u0012\u0012\u0004\u0012\u00020\u00140\u0013j\u0008\u0012\u0004\u0012\u00020\u0014`\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u00180\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006/"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;",
        "Landroid/widget/LinearLayout;",
        "Lcom/exampletest/mobilestudiotest/core/Studio$Listener;",
        "ctx",
        "Landroid/content/Context;",
        "studio",
        "Lcom/exampletest/mobilestudiotest/core/Studio;",
        "<init>",
        "(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V",
        "rows",
        "",
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;",
        "list",
        "Landroidx/recyclerview/widget/RecyclerView;",
        "adapter",
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;",
        "title",
        "Landroid/widget/TextView;",
        "collapsed",
        "Ljava/util/HashSet;",
        "",
        "Lkotlin/collections/HashSet;",
        "previewListener",
        "Lkotlin/Function0;",
        "",
        "onAttachedToWindow",
        "onDetachedFromWindow",
        "onSelectionChanged",
        "onPropsChanged",
        "onModelReplaced",
        "categoryOf",
        "inst",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "disp",
        "t",
        "",
        "rebuild",
        "valueText",
        "r",
        "applyEdit",
        "newValue",
        "",
        "edit",
        "Row",
        "Companion",
        "VH",
        "Adapter",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final CATEGORY:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Companion;

.field private static final DEG:F = 57.29578f

.field private static final ORDER:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final RAD:F = 0.017453292f

.field private static final skip:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final surfaceProps:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final adapter:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;

.field private final collapsed:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final list:Landroidx/recyclerview/widget/RecyclerView;

.field private final previewListener:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private rows:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;",
            ">;"
        }
    .end annotation
.end field

.field private final studio:Lcom/exampletest/mobilestudiotest/core/Studio;

.field private final title:Landroid/widget/TextView;


# direct methods
.method static constructor <clinit>()V
    .registers 28

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->Companion:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Companion;

    .line 41
    nop

    .line 42
    const/16 v0, 0x24

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "Appearance"

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const-string v1, "Data"

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const-string v1, "Text"

    const/4 v4, 0x2

    aput-object v1, v0, v4

    const-string v1, "Image"

    const/4 v5, 0x3

    aput-object v1, v0, v5

    const-string v1, "Behavior"

    const/4 v6, 0x4

    aput-object v1, v0, v6

    const-string v1, "Transform"

    const/4 v7, 0x5

    aput-object v1, v0, v7

    const-string v1, "Pivot"

    const/4 v8, 0x6

    aput-object v1, v0, v8

    const-string v1, "Collision"

    const/4 v9, 0x7

    aput-object v1, v0, v9

    const-string v1, "Part"

    const/16 v10, 0x8

    aput-object v1, v0, v10

    const-string v1, "Surface"

    const/16 v11, 0x9

    aput-object v1, v0, v11

    const-string v1, "Assembly"

    const/16 v12, 0xa

    aput-object v1, v0, v12

    .line 43
    const-string v1, "Playback"

    const/16 v13, 0xb

    aput-object v1, v0, v13

    .line 42
    nop

    .line 43
    const-string v1, "Emitter"

    const/16 v14, 0xc

    aput-object v1, v0, v14

    .line 42
    nop

    .line 43
    const-string v1, "Character"

    const/16 v15, 0xd

    aput-object v1, v0, v15

    .line 42
    nop

    .line 43
    const-string v1, "Health"

    const/16 v16, 0xe

    aput-object v1, v0, v16

    .line 42
    nop

    .line 43
    const-string v1, "Movement"

    const/16 v17, 0xf

    aput-object v1, v0, v17

    .line 42
    nop

    .line 43
    const-string v1, "Rigging"

    move/from16 v18, v2

    const/16 v2, 0x10

    aput-object v1, v0, v2

    .line 42
    nop

    .line 43
    const-string v1, "Camera"

    move/from16 v19, v3

    const/16 v3, 0x11

    aput-object v1, v0, v3

    .line 42
    nop

    .line 43
    const-string v1, "Controls"

    const/16 v20, 0x12

    aput-object v1, v0, v20

    .line 42
    nop

    .line 43
    const-string v1, "Mobile"

    move/from16 v21, v4

    const/16 v4, 0x13

    aput-object v1, v0, v4

    .line 42
    nop

    .line 43
    const-string v1, "Shape"

    const/16 v22, 0x14

    aput-object v1, v0, v22

    .line 42
    nop

    .line 43
    const-string v1, "Emission"

    move/from16 v23, v13

    const/16 v13, 0x15

    aput-object v1, v0, v13

    .line 42
    nop

    .line 44
    const-string v1, "Motion"

    const/16 v24, 0x16

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Particles"

    const/16 v24, 0x17

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Light"

    const/16 v24, 0x18

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Scripting"

    const/16 v24, 0x19

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Model"

    const/16 v24, 0x1a

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Physics"

    const/16 v24, 0x1b

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Attachments"

    const/16 v24, 0x1c

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Constraints"

    const/16 v24, 0x1d

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Input"

    const/16 v24, 0x1e

    aput-object v1, v0, v24

    .line 42
    nop

    .line 44
    const-string v1, "Layout"

    const/16 v24, 0x1f

    aput-object v1, v0, v24

    .line 42
    nop

    .line 45
    const-string v1, "State"

    const/16 v24, 0x20

    aput-object v1, v0, v24

    .line 42
    nop

    .line 45
    const-string v1, "Teams"

    const/16 v24, 0x21

    aput-object v1, v0, v24

    .line 42
    nop

    .line 45
    const-string v1, "Game"

    const/16 v24, 0x22

    aput-object v1, v0, v24

    .line 42
    nop

    .line 45
    const-string v1, "Other"

    const/16 v24, 0x23

    aput-object v1, v0, v24

    .line 42
    nop

    .line 41
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->ORDER:Ljava/util/List;

    .line 49
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    move-object v1, v0

    .local v1, "$this$CATEGORY_u24lambda_u2414\\1":Ljava/util/HashMap;
    const/16 v24, 0x0

    .line 51
    .local v24, "$i$a$-apply-PropertiesPanel$Companion$CATEGORY$1\\1\\49\\0":I
    move/from16 v25, v15

    const/16 v15, 0x30

    new-array v15, v15, [Ljava/lang/String;

    const-string v26, "BrickColor"

    aput-object v26, v15, v18

    const-string v26, "CastShadow"

    aput-object v26, v15, v19

    const-string v26, "Color"

    aput-object v26, v15, v21

    const-string v26, "Material"

    aput-object v26, v15, v5

    const-string v26, "MaterialVariant"

    aput-object v26, v15, v6

    const-string v26, "Reflectance"

    aput-object v26, v15, v7

    const-string v26, "Transparency"

    aput-object v26, v15, v8

    .line 52
    const-string v26, "BackgroundColor3"

    aput-object v26, v15, v9

    .line 51
    nop

    .line 52
    const-string v26, "BackgroundTransparency"

    aput-object v26, v15, v10

    .line 51
    nop

    .line 52
    const-string v26, "BorderColor3"

    aput-object v26, v15, v11

    .line 51
    nop

    .line 52
    const-string v26, "BorderMode"

    aput-object v26, v15, v12

    .line 51
    nop

    .line 52
    const-string v26, "BorderSizePixel"

    aput-object v26, v15, v23

    .line 51
    nop

    .line 52
    const-string v26, "Visible"

    aput-object v26, v15, v14

    .line 51
    nop

    .line 52
    const-string v26, "Texture"

    aput-object v26, v15, v25

    .line 51
    nop

    .line 53
    const-string v26, "Face"

    aput-object v26, v15, v16

    .line 51
    nop

    .line 53
    const-string v26, "Color3"

    aput-object v26, v15, v17

    .line 51
    nop

    .line 53
    const-string v26, "ZIndex"

    aput-object v26, v15, v2

    .line 51
    nop

    .line 53
    const-string v26, "TextureID"

    aput-object v26, v15, v3

    .line 51
    nop

    .line 53
    const-string v26, "DoubleSided"

    aput-object v26, v15, v20

    .line 51
    nop

    .line 53
    const-string v26, "RenderFidelity"

    aput-object v26, v15, v4

    .line 51
    nop

    .line 53
    const-string v26, "SmoothingAngle"

    aput-object v26, v15, v22

    .line 51
    nop

    .line 53
    const-string v26, "UsePartColor"

    aput-object v26, v15, v13

    .line 51
    nop

    .line 54
    const-string v26, "FillColor"

    const/16 v27, 0x16

    aput-object v26, v15, v27

    .line 51
    nop

    .line 54
    const-string v26, "FillTransparency"

    const/16 v27, 0x17

    aput-object v26, v15, v27

    .line 51
    nop

    .line 54
    const-string v26, "OutlineColor"

    const/16 v27, 0x18

    aput-object v26, v15, v27

    .line 51
    nop

    .line 54
    const-string v26, "OutlineTransparency"

    const/16 v27, 0x19

    aput-object v26, v15, v27

    .line 51
    nop

    .line 54
    const-string v26, "DepthMode"

    const/16 v27, 0x1a

    aput-object v26, v15, v27

    .line 51
    nop

    .line 54
    const-string v26, "LineThickness"

    const/16 v27, 0x1b

    aput-object v26, v15, v27

    .line 51
    nop

    .line 54
    const-string v26, "SurfaceColor3"

    const/16 v27, 0x1c

    aput-object v26, v15, v27

    .line 51
    nop

    .line 55
    const-string v26, "SurfaceTransparency"

    const/16 v27, 0x1d

    aput-object v26, v15, v27

    .line 51
    nop

    .line 55
    const-string v26, "StudsPerTileU"

    const/16 v27, 0x1e

    aput-object v26, v15, v27

    .line 51
    nop

    .line 55
    const-string v26, "StudsPerTileV"

    const/16 v27, 0x1f

    aput-object v26, v15, v27

    .line 51
    nop

    .line 55
    const-string v26, "OffsetStudsU"

    const/16 v27, 0x20

    aput-object v26, v15, v27

    .line 51
    nop

    .line 55
    const-string v26, "OffsetStudsV"

    const/16 v27, 0x21

    aput-object v26, v15, v27

    .line 51
    nop

    .line 55
    const-string v26, "LightInfluence"

    const/16 v27, 0x22

    aput-object v26, v15, v27

    .line 51
    nop

    .line 55
    const-string v26, "Brightness"

    const/16 v27, 0x23

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "Shadows"

    const/16 v27, 0x24

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "Range"

    const/16 v27, 0x25

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "Angle"

    const/16 v27, 0x26

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "Thickness"

    const/16 v27, 0x27

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "LineJoinMode"

    const/16 v27, 0x28

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "CornerRadius"

    const/16 v27, 0x29

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "Rotation"

    const/16 v27, 0x2a

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "Offset"

    const/16 v27, 0x2b

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "VertexColor"

    const/16 v27, 0x2c

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "Scale"

    const/16 v27, 0x2d

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "MeshType"

    const/16 v27, 0x2e

    aput-object v26, v15, v27

    .line 51
    nop

    .line 56
    const-string v26, "TextureId"

    const/16 v27, 0x2f

    aput-object v26, v15, v27

    .line 51
    move/from16 v26, v4

    const-string v4, "Appearance"

    invoke-static {v1, v4, v15}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 57
    const/16 v4, 0x1b

    new-array v4, v4, [Ljava/lang/String;

    const-string v15, "ClassName"

    aput-object v15, v4, v18

    const-string v15, "Name"

    aput-object v15, v4, v19

    const-string v15, "Parent"

    aput-object v15, v4, v21

    const-string v15, "Source"

    aput-object v15, v4, v5

    const-string v15, "LinkedSource"

    aput-object v15, v4, v6

    const-string v15, "SoundId"

    aput-object v15, v4, v7

    const-string v15, "MeshId"

    aput-object v15, v4, v8

    const-string v15, "AnimationId"

    aput-object v15, v4, v9

    const-string v15, "Value"

    aput-object v15, v4, v10

    const-string v15, "Adornee"

    aput-object v15, v4, v11

    .line 58
    const-string v15, "PrimaryPart"

    aput-object v15, v4, v12

    .line 57
    nop

    .line 58
    const-string v15, "Part0"

    aput-object v15, v4, v23

    .line 57
    nop

    .line 58
    const-string v15, "Part1"

    aput-object v15, v4, v14

    .line 57
    nop

    .line 58
    const-string v15, "Attachment0"

    aput-object v15, v4, v25

    .line 57
    nop

    .line 58
    const-string v15, "Attachment1"

    aput-object v15, v4, v16

    .line 57
    nop

    .line 58
    const-string v15, "LayoutOrder"

    aput-object v15, v4, v17

    .line 57
    nop

    .line 58
    const-string v15, "SoundGroup"

    aput-object v15, v4, v2

    .line 57
    nop

    .line 58
    const-string v15, "TimeLength"

    aput-object v15, v4, v3

    .line 57
    nop

    .line 58
    const-string v15, "DisplayName"

    aput-object v15, v4, v20

    .line 57
    nop

    .line 59
    const-string v15, "Tags"

    aput-object v15, v4, v26

    .line 57
    nop

    .line 59
    const-string v15, "PlaceholderText"

    aput-object v15, v4, v22

    .line 57
    nop

    .line 59
    const-string v15, "Title"

    aput-object v15, v4, v13

    .line 57
    nop

    .line 59
    const-string v15, "Graphic"

    const/16 v27, 0x16

    aput-object v15, v4, v27

    .line 57
    nop

    .line 59
    const-string v15, "ShirtTemplate"

    const/16 v27, 0x17

    aput-object v15, v4, v27

    .line 57
    nop

    .line 59
    const-string v15, "PantsTemplate"

    const/16 v27, 0x18

    aput-object v15, v4, v27

    .line 57
    nop

    .line 59
    const-string v15, "Tool"

    const/16 v27, 0x19

    aput-object v15, v4, v27

    .line 57
    nop

    .line 59
    const-string v15, "ToolTip"

    const/16 v27, 0x1a

    aput-object v15, v4, v27

    .line 57
    const-string v15, "Data"

    invoke-static {v1, v15, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 60
    new-array v4, v13, [Ljava/lang/String;

    const-string v15, "Font"

    aput-object v15, v4, v18

    const-string v15, "FontFace"

    aput-object v15, v4, v19

    const-string v15, "LineHeight"

    aput-object v15, v4, v21

    const-string v15, "MaxVisibleGraphemes"

    aput-object v15, v4, v5

    const-string v15, "RichText"

    aput-object v15, v4, v6

    const-string v15, "Text"

    aput-object v15, v4, v7

    const-string v15, "TextColor3"

    aput-object v15, v4, v8

    const-string v15, "TextScaled"

    aput-object v15, v4, v9

    const-string v15, "TextSize"

    aput-object v15, v4, v10

    .line 61
    const-string v15, "TextStrokeColor3"

    aput-object v15, v4, v11

    .line 60
    nop

    .line 61
    const-string v15, "TextStrokeTransparency"

    aput-object v15, v4, v12

    .line 60
    nop

    .line 61
    const-string v15, "TextTransparency"

    aput-object v15, v4, v23

    .line 60
    nop

    .line 61
    const-string v15, "TextTruncate"

    aput-object v15, v4, v14

    .line 60
    nop

    .line 61
    const-string v15, "TextWrapped"

    aput-object v15, v4, v25

    .line 60
    nop

    .line 61
    const-string v15, "TextXAlignment"

    aput-object v15, v4, v16

    .line 60
    nop

    .line 62
    const-string v15, "TextYAlignment"

    aput-object v15, v4, v17

    .line 60
    nop

    .line 62
    const-string v15, "TextEditable"

    aput-object v15, v4, v2

    .line 60
    nop

    .line 62
    const-string v15, "ClearTextOnFocus"

    aput-object v15, v4, v3

    .line 60
    nop

    .line 62
    const-string v15, "MultiLine"

    aput-object v15, v4, v20

    .line 60
    nop

    .line 62
    const-string v15, "PlaceholderColor3"

    aput-object v15, v4, v26

    .line 60
    nop

    .line 62
    const-string v15, "ShowNativeInput"

    aput-object v15, v4, v22

    .line 60
    const-string v15, "Text"

    invoke-static {v1, v15, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 63
    new-array v4, v14, [Ljava/lang/String;

    const-string v15, "Image"

    aput-object v15, v4, v18

    const-string v15, "ImageColor3"

    aput-object v15, v4, v19

    const-string v15, "ImageRectOffset"

    aput-object v15, v4, v21

    const-string v15, "ImageRectSize"

    aput-object v15, v4, v5

    const-string v15, "ImageTransparency"

    aput-object v15, v4, v6

    const-string v15, "ResampleMode"

    aput-object v15, v4, v7

    const-string v15, "ScaleType"

    aput-object v15, v4, v8

    .line 64
    const-string v15, "SliceCenter"

    aput-object v15, v4, v9

    .line 63
    nop

    .line 64
    const-string v15, "SliceScale"

    aput-object v15, v4, v10

    .line 63
    nop

    .line 64
    const-string v15, "TileSize"

    aput-object v15, v4, v11

    .line 63
    nop

    .line 64
    const-string v15, "HoverImage"

    aput-object v15, v4, v12

    .line 63
    nop

    .line 64
    const-string v15, "PressedImage"

    aput-object v15, v4, v23

    .line 63
    const-string v15, "Image"

    invoke-static {v1, v15, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 65
    const/16 v4, 0x20

    new-array v4, v4, [Ljava/lang/String;

    const-string v15, "Archivable"

    aput-object v15, v4, v18

    const-string v15, "Locked"

    aput-object v15, v4, v19

    const-string v15, "Active"

    aput-object v15, v4, v21

    const-string v15, "AutoButtonColor"

    aput-object v15, v4, v5

    const-string v15, "ClipsDescendants"

    aput-object v15, v4, v6

    const-string v15, "Draggable"

    aput-object v15, v4, v7

    const-string v15, "Interactable"

    aput-object v15, v4, v8

    const-string v15, "Selectable"

    aput-object v15, v4, v9

    .line 66
    const-string v15, "Disabled"

    aput-object v15, v4, v10

    .line 65
    nop

    .line 66
    const-string v15, "Enabled"

    aput-object v15, v4, v11

    .line 65
    nop

    .line 66
    const-string v15, "RunContext"

    aput-object v15, v4, v12

    .line 65
    nop

    .line 66
    const-string v15, "ResetOnSpawn"

    aput-object v15, v4, v23

    .line 65
    nop

    .line 66
    const-string v15, "IgnoreGuiInset"

    aput-object v15, v4, v14

    .line 65
    nop

    .line 66
    const-string v15, "ZIndexBehavior"

    aput-object v15, v4, v25

    .line 65
    nop

    .line 66
    const-string v15, "DisplayOrder"

    aput-object v15, v4, v16

    .line 65
    nop

    .line 66
    const-string v15, "AlwaysOnTop"

    aput-object v15, v4, v17

    .line 65
    nop

    .line 67
    const-string v15, "Modal"

    aput-object v15, v4, v2

    .line 65
    nop

    .line 67
    const-string v15, "Selected"

    aput-object v15, v4, v3

    .line 65
    nop

    .line 67
    const-string v15, "AutoLocalize"

    aput-object v15, v4, v20

    .line 65
    nop

    .line 67
    const-string v15, "ScreenInsets"

    aput-object v15, v4, v26

    .line 65
    nop

    .line 67
    const-string v15, "SafeAreaCompatibility"

    aput-object v15, v4, v22

    .line 65
    nop

    .line 67
    const-string v15, "CanBeDropped"

    aput-object v15, v4, v13

    .line 65
    nop

    .line 67
    const-string v13, "ManualActivationOnly"

    const/16 v15, 0x16

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "RequiresHandle"

    const/16 v15, 0x17

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "MaxActivationDistance"

    const/16 v15, 0x18

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "HoldDuration"

    const/16 v15, 0x19

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "KeyboardKeyCode"

    const/16 v15, 0x1a

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "ActionText"

    const/16 v15, 0x1b

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "ObjectText"

    const/16 v15, 0x1c

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "RequiresLineOfSight"

    const/16 v15, 0x1d

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "Exclusivity"

    const/16 v15, 0x1e

    aput-object v13, v4, v15

    .line 65
    nop

    .line 68
    const-string v13, "Style"

    const/16 v15, 0x1f

    aput-object v13, v4, v15

    .line 65
    const-string v13, "Behavior"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 69
    new-array v4, v9, [Ljava/lang/String;

    const-string v13, "Size"

    aput-object v13, v4, v18

    const-string v13, "Position"

    aput-object v13, v4, v19

    const-string v13, "Orientation"

    aput-object v13, v4, v21

    const-string v13, "CFrame"

    aput-object v13, v4, v5

    const-string v13, "AnchorPoint"

    aput-object v13, v4, v6

    const-string v13, "SizeConstraint"

    aput-object v13, v4, v7

    const-string v13, "AutomaticSize"

    aput-object v13, v4, v8

    const-string v13, "Transform"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 70
    new-array v4, v6, [Ljava/lang/String;

    const-string v13, "PivotOffset"

    aput-object v13, v4, v18

    const-string v13, "WorldPivot"

    aput-object v13, v4, v19

    const-string v13, "Pivot Offset"

    aput-object v13, v4, v21

    const-string v13, "Origin"

    aput-object v13, v4, v5

    const-string v13, "Pivot"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 71
    new-array v4, v9, [Ljava/lang/String;

    const-string v13, "CanCollide"

    aput-object v13, v4, v18

    const-string v13, "CanQuery"

    aput-object v13, v4, v19

    const-string v13, "CanTouch"

    aput-object v13, v4, v21

    const-string v13, "CollisionGroup"

    aput-object v13, v4, v5

    const-string v13, "CollisionGroupId"

    aput-object v13, v4, v6

    const-string v13, "CollisionFidelity"

    aput-object v13, v4, v7

    const-string v13, "AudioCanCollide"

    aput-object v13, v4, v8

    const-string v13, "Collision"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 72
    new-array v4, v9, [Ljava/lang/String;

    const-string v13, "Anchored"

    aput-object v13, v4, v18

    const-string v13, "CustomPhysicalProperties"

    aput-object v13, v4, v19

    const-string v13, "Massless"

    aput-object v13, v4, v21

    const-string v13, "RootPriority"

    aput-object v13, v4, v5

    const-string v13, "Shape"

    aput-object v13, v4, v6

    const-string v13, "EnableFluidForces"

    aput-object v13, v4, v7

    const-string v13, "FormFactor"

    aput-object v13, v4, v8

    const-string v13, "Part"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 73
    new-array v4, v14, [Ljava/lang/String;

    const-string v13, "BackSurface"

    aput-object v13, v4, v18

    const-string v13, "BottomSurface"

    aput-object v13, v4, v19

    const-string v13, "FrontSurface"

    aput-object v13, v4, v21

    const-string v13, "LeftSurface"

    aput-object v13, v4, v5

    const-string v13, "RightSurface"

    aput-object v13, v4, v6

    const-string v13, "TopSurface"

    aput-object v13, v4, v7

    .line 74
    const-string v13, "BackSurfaceInput"

    aput-object v13, v4, v8

    .line 73
    nop

    .line 74
    const-string v13, "BottomSurfaceInput"

    aput-object v13, v4, v9

    .line 73
    nop

    .line 74
    const-string v13, "FrontSurfaceInput"

    aput-object v13, v4, v10

    .line 73
    nop

    .line 74
    const-string v13, "LeftSurfaceInput"

    aput-object v13, v4, v11

    .line 73
    nop

    .line 74
    const-string v13, "RightSurfaceInput"

    aput-object v13, v4, v12

    .line 73
    nop

    .line 74
    const-string v13, "TopSurfaceInput"

    aput-object v13, v4, v23

    .line 73
    const-string v13, "Surface"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 75
    new-array v4, v6, [Ljava/lang/String;

    const-string v13, "AssemblyLinearVelocity"

    aput-object v13, v4, v18

    const-string v13, "AssemblyAngularVelocity"

    aput-object v13, v4, v19

    const-string v13, "Velocity"

    aput-object v13, v4, v21

    const-string v13, "RotVelocity"

    aput-object v13, v4, v5

    const-string v13, "Assembly"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 76
    new-array v4, v10, [Ljava/lang/String;

    const-string v13, "Looped"

    aput-object v13, v4, v18

    const-string v13, "PlaybackSpeed"

    aput-object v13, v4, v19

    const-string v13, "Playing"

    aput-object v13, v4, v21

    const-string v13, "TimePosition"

    aput-object v13, v4, v5

    const-string v13, "Volume"

    aput-object v13, v4, v6

    const-string v13, "PlayOnRemove"

    aput-object v13, v4, v7

    const-string v13, "PlaybackRegionsEnabled"

    aput-object v13, v4, v8

    const-string v13, "Pitch"

    aput-object v13, v4, v9

    const-string v13, "Playback"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 77
    new-array v4, v8, [Ljava/lang/String;

    const-string v13, "RollOffMaxDistance"

    aput-object v13, v4, v18

    const-string v13, "RollOffMinDistance"

    aput-object v13, v4, v19

    const-string v13, "RollOffMode"

    aput-object v13, v4, v21

    const-string v13, "EmitterSize"

    aput-object v13, v4, v5

    const-string v13, "MaxDistance"

    aput-object v13, v4, v6

    const-string v13, "MinDistance"

    aput-object v13, v4, v7

    const-string v13, "Emitter"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 78
    new-array v4, v7, [Ljava/lang/String;

    const-string v13, "Health"

    aput-object v13, v4, v18

    const-string v13, "MaxHealth"

    aput-object v13, v4, v19

    const-string v13, "BreakJointsOnDeath"

    aput-object v13, v4, v21

    const-string v13, "HealthDisplayDistance"

    aput-object v13, v4, v5

    const-string v13, "HealthDisplayType"

    aput-object v13, v4, v6

    const-string v13, "Health"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 79
    new-array v4, v12, [Ljava/lang/String;

    const-string v13, "WalkSpeed"

    aput-object v13, v4, v18

    const-string v13, "HipHeight"

    aput-object v13, v4, v19

    const-string v13, "MaxSlopeAngle"

    aput-object v13, v4, v21

    const-string v13, "AutoRotate"

    aput-object v13, v4, v5

    const-string v13, "AutoJumpEnabled"

    aput-object v13, v4, v6

    const-string v13, "JumpPower"

    aput-object v13, v4, v7

    const-string v13, "JumpHeight"

    aput-object v13, v4, v8

    const-string v13, "UseJumpPower"

    aput-object v13, v4, v9

    const-string v13, "PlatformStand"

    aput-object v13, v4, v10

    const-string v13, "Sit"

    aput-object v13, v4, v11

    const-string v13, "Movement"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 80
    new-array v4, v5, [Ljava/lang/String;

    const-string v13, "RigType"

    aput-object v13, v4, v18

    const-string v13, "RequiresNeck"

    aput-object v13, v4, v19

    const-string v13, "AutomaticScalingEnabled"

    aput-object v13, v4, v21

    const-string v13, "Rigging"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 81
    new-array v4, v11, [Ljava/lang/String;

    const-string v13, "CameraType"

    aput-object v13, v4, v18

    const-string v13, "FieldOfView"

    aput-object v13, v4, v19

    const-string v13, "FieldOfViewMode"

    aput-object v13, v4, v21

    const-string v13, "CameraSubject"

    aput-object v13, v4, v5

    const-string v13, "Focus"

    aput-object v13, v4, v6

    const-string v13, "HeadLocked"

    aput-object v13, v4, v7

    const-string v13, "HeadScale"

    aput-object v13, v4, v8

    const-string v13, "DiagonalFieldOfView"

    aput-object v13, v4, v9

    const-string v13, "MaxAxisFieldOfView"

    aput-object v13, v4, v10

    const-string v13, "Camera"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 82
    new-array v4, v14, [Ljava/lang/String;

    const-string v13, "Rate"

    aput-object v13, v4, v18

    const-string v13, "Lifetime"

    aput-object v13, v4, v19

    const-string v13, "Speed"

    aput-object v13, v4, v21

    const-string v13, "SpreadAngle"

    aput-object v13, v4, v5

    const-string v13, "EmissionDirection"

    aput-object v13, v4, v6

    const-string v13, "Drag"

    aput-object v13, v4, v7

    const-string v13, "Acceleration"

    aput-object v13, v4, v8

    const-string v13, "LockedToPart"

    aput-object v13, v4, v9

    const-string v13, "VelocityInheritance"

    aput-object v13, v4, v10

    const-string v13, "ZOffset"

    aput-object v13, v4, v11

    const-string v13, "Squash"

    aput-object v13, v4, v12

    const-string v13, "TimeScale"

    aput-object v13, v4, v23

    const-string v13, "Emission"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 83
    new-array v4, v2, [Ljava/lang/String;

    const-string v13, "Ambient"

    aput-object v13, v4, v18

    const-string v13, "OutdoorAmbient"

    aput-object v13, v4, v19

    const-string v13, "ClockTime"

    aput-object v13, v4, v21

    const-string v13, "GeographicLatitude"

    aput-object v13, v4, v5

    const-string v13, "TimeOfDay"

    aput-object v13, v4, v6

    const-string v13, "ExposureCompensation"

    aput-object v13, v4, v7

    const-string v13, "GlobalShadows"

    aput-object v13, v4, v8

    .line 84
    const-string v13, "FogColor"

    aput-object v13, v4, v9

    .line 83
    nop

    .line 84
    const-string v13, "FogEnd"

    aput-object v13, v4, v10

    .line 83
    nop

    .line 84
    const-string v13, "FogStart"

    aput-object v13, v4, v11

    .line 83
    nop

    .line 84
    const-string v13, "EnvironmentDiffuseScale"

    aput-object v13, v4, v12

    .line 83
    nop

    .line 84
    const-string v13, "EnvironmentSpecularScale"

    aput-object v13, v4, v23

    .line 83
    nop

    .line 84
    const-string v13, "ColorShift_Bottom"

    aput-object v13, v4, v14

    .line 83
    nop

    .line 84
    const-string v13, "ColorShift_Top"

    aput-object v13, v4, v25

    .line 83
    nop

    .line 84
    const-string v13, "Technology"

    aput-object v13, v4, v16

    .line 83
    nop

    .line 84
    const-string v13, "ShadowSoftness"

    aput-object v13, v4, v17

    .line 83
    const-string v13, "Light"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 85
    new-array v4, v8, [Ljava/lang/String;

    const-string v13, "Gravity"

    aput-object v13, v4, v18

    const-string v13, "FallenPartsDestroyHeight"

    aput-object v13, v4, v19

    const-string v13, "StreamingEnabled"

    aput-object v13, v4, v21

    const-string v13, "RespawnTime"

    aput-object v13, v4, v5

    const-string v13, "MaxPlayers"

    aput-object v13, v4, v6

    const-string v13, "CharacterAutoLoads"

    aput-object v13, v4, v7

    const-string v13, "Game"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 86
    new-array v4, v7, [Ljava/lang/String;

    const-string v13, "TeamColor"

    aput-object v13, v4, v18

    const-string v13, "AutoAssignable"

    aput-object v13, v4, v19

    const-string v13, "Neutral"

    aput-object v13, v4, v21

    const-string v13, "AllowTeamChangeOnTouch"

    aput-object v13, v4, v5

    const-string v13, "Duration"

    aput-object v13, v4, v6

    const-string v13, "Teams"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 87
    new-array v4, v3, [Ljava/lang/String;

    const-string v13, "Padding"

    aput-object v13, v4, v18

    const-string v13, "FillDirection"

    aput-object v13, v4, v19

    const-string v13, "HorizontalAlignment"

    aput-object v13, v4, v21

    const-string v13, "VerticalAlignment"

    aput-object v13, v4, v5

    const-string v13, "SortOrder"

    aput-object v13, v4, v6

    const-string v13, "CellSize"

    aput-object v13, v4, v7

    const-string v13, "CellPadding"

    aput-object v13, v4, v8

    .line 88
    const-string v13, "PaddingTop"

    aput-object v13, v4, v9

    .line 87
    nop

    .line 88
    const-string v13, "PaddingBottom"

    aput-object v13, v4, v10

    .line 87
    nop

    .line 88
    const-string v13, "PaddingLeft"

    aput-object v13, v4, v11

    .line 87
    nop

    .line 88
    const-string v13, "PaddingRight"

    aput-object v13, v4, v12

    .line 87
    nop

    .line 88
    const-string v13, "AspectRatio"

    aput-object v13, v4, v23

    .line 87
    nop

    .line 88
    const-string v13, "AspectType"

    aput-object v13, v4, v14

    .line 87
    nop

    .line 88
    const-string v13, "DominantAxis"

    aput-object v13, v4, v25

    .line 87
    nop

    .line 88
    const-string v13, "MinSize"

    aput-object v13, v4, v16

    .line 87
    nop

    .line 88
    const-string v13, "MaxSize"

    aput-object v13, v4, v17

    .line 87
    nop

    .line 88
    const-string v13, "Wraps"

    aput-object v13, v4, v2

    .line 87
    const-string v13, "Layout"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 89
    new-array v4, v5, [Ljava/lang/String;

    const-string v13, "LevelOfDetail"

    aput-object v13, v4, v18

    const-string v13, "ModelStreamingMode"

    aput-object v13, v4, v19

    const-string v13, "WorldPivotData"

    aput-object v13, v4, v21

    const-string v13, "Model"

    invoke-static {v1, v13, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V

    .line 90
    nop

    .line 49
    .end local v1    # "$this$CATEGORY_u24lambda_u2414\\1":Ljava/util/HashMap;
    .end local v24    # "$i$a$-apply-PropertiesPanel$Companion$CATEGORY$1\\1\\49\\0":I
    check-cast v0, Ljava/util/Map;

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY:Ljava/util/Map;

    .line 92
    new-array v0, v8, [Ljava/lang/String;

    const-string v1, "TopSurface"

    aput-object v1, v0, v18

    const-string v1, "BottomSurface"

    aput-object v1, v0, v19

    const-string v1, "FrontSurface"

    aput-object v1, v0, v21

    const-string v1, "BackSurface"

    aput-object v1, v0, v5

    const-string v1, "LeftSurface"

    aput-object v1, v0, v6

    const-string v1, "RightSurface"

    aput-object v1, v0, v7

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->surfaceProps:Ljava/util/List;

    .line 93
    move/from16 v0, v26

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "AttributesSerialize"

    aput-object v1, v0, v18

    const-string v1, "Tags"

    aput-object v1, v0, v19

    const-string v1, "SourceAssetId"

    aput-object v1, v0, v21

    const-string v1, "HistoryId"

    aput-object v1, v0, v5

    const-string v1, "UniqueId"

    aput-object v1, v0, v6

    const-string v1, "ScriptGuid"

    aput-object v1, v0, v7

    const-string v1, "Capabilities"

    aput-object v1, v0, v8

    .line 94
    const-string v1, "DefinesCapabilities"

    aput-object v1, v0, v9

    .line 93
    nop

    .line 94
    const-string v1, "MeshContent"

    aput-object v1, v0, v10

    .line 93
    nop

    .line 94
    const-string v1, "TextureContent"

    aput-object v1, v0, v11

    .line 93
    nop

    .line 94
    const-string v1, "PhysicsData"

    aput-object v1, v0, v12

    .line 93
    nop

    .line 94
    const-string v1, "PhysicalConfigData"

    aput-object v1, v0, v23

    .line 93
    nop

    .line 94
    const-string v1, "ChildData"

    aput-object v1, v0, v14

    .line 93
    nop

    .line 94
    const-string v1, "MeshData"

    aput-object v1, v0, v25

    .line 93
    nop

    .line 94
    const-string v1, "InitialSize"

    aput-object v1, v0, v16

    .line 93
    nop

    .line 95
    const-string v1, "ModelMeshData"

    aput-object v1, v0, v17

    .line 93
    nop

    .line 95
    const-string v1, "ModelMeshSize"

    aput-object v1, v0, v2

    .line 93
    nop

    .line 95
    const-string v1, "ModelMeshCFrame"

    aput-object v1, v0, v3

    .line 93
    nop

    .line 95
    const-string v1, "LevelOfDetail"

    aput-object v1, v0, v20

    .line 93
    invoke-static {v0}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->skip:Ljava/util/Set;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V
    .registers 12
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "studio"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    .line 29
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rows:Ljava/util/List;

    .line 30
    new-instance v0, Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {v0, p1}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    .line 31
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;-><init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;

    .line 33
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->collapsed:Ljava/util/HashSet;

    .line 34
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda5;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda5;-><init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->previewListener:Lkotlin/jvm/functions/Function0;

    .line 98
    nop

    .line 99
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->setOrientation(I)V

    .line 100
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getPANEL()I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->setBackgroundColor(I)V

    .line 101
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v3, "Properties"

    const/4 v4, 0x0

    move-object v2, p1

    .end local p1    # "ctx":Landroid/content/Context;
    .local v2, "ctx":Landroid/content/Context;
    invoke-static/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general$default(Lcom/exampletest/mobilestudiotest/ui/Icons;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const-string v1, "Properties"

    invoke-virtual {v0, v2, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->header(Landroid/content/Context;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)Landroid/widget/LinearLayout;

    move-result-object p1

    .line 102
    .local p1, "h":Landroid/widget/LinearLayout;
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v5

    const/16 v7, 0x10

    const/4 v8, 0x0

    const-string v3, ""

    const/high16 v4, 0x41300000    # 11.0f

    const/4 v6, 0x0

    invoke-static/range {v1 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->title:Landroid/widget/TextView;

    .line 103
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->title:Landroid/widget/TextView;

    check-cast v0, Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 104
    move-object v0, p1

    check-cast v0, Landroid/view/View;

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v7, 0x4

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 105
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v1, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v1, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    check-cast v1, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 106
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;

    check-cast v1, Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 107
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    .line 108
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    check-cast v0, Landroid/view/View;

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v3, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v5, -0x1

    invoke-virtual {v1, v5, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 109
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild()V

    .line 110
    .end local p1    # "h":Landroid/widget/LinearLayout;
    nop

    .line 25
    return-void
.end method

.method private static final varargs CATEGORY$lambda$14$c(Ljava/util/HashMap;Ljava/lang/String;[Ljava/lang/String;)V
    .registers 6
    .param p0, "$this_apply"    # Ljava/util/HashMap;
    .param p1, "cat"    # Ljava/lang/String;
    .param p2, "names"    # [Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 50
    array-length v0, p2

    const/4 v1, 0x0

    :goto_2
    if-ge v1, v0, :cond_c

    aget-object v2, p2, v1

    .local v2, "n":Ljava/lang/String;
    invoke-virtual {p0, v2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .end local v2    # "n":Ljava/lang/String;
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_c
    return-void
.end method

.method public static final synthetic access$edit(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    .line 24
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->edit(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V

    return-void
.end method

.method public static final synthetic access$getCollapsed$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Ljava/util/HashSet;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    .line 24
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->collapsed:Ljava/util/HashSet;

    return-object v0
.end method

.method public static final synthetic access$getRows$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Ljava/util/List;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    .line 24
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rows:Ljava/util/List;

    return-object v0
.end method

.method public static final synthetic access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Lcom/exampletest/mobilestudiotest/core/Studio;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    .line 24
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    return-object v0
.end method

.method public static final synthetic access$valueText(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;
    .registers 4
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
    .param p2, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 24
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->valueText(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private final applyEdit(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Ljava/lang/Object;)V
    .registers 15
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
    .param p2, "newValue"    # Ljava/lang/Object;

    .line 260
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getProp()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_7

    return-void

    .line 261
    .local v0, "prop":Ljava/lang/String;
    :cond_7
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    const/4 v2, 0x0

    .line 262
    .local v2, "$i$a$-synchronized-PropertiesPanel$applyEdit$1\\1\\261\\0":I
    :try_start_f
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v3

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Change "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->begin(Ljava/lang/String;)V

    .line 263
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_3f
    :goto_3f
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_256

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 264
    .local v4, "inst\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v5

    const/16 v6, 0x1a

    sparse-switch v5, :sswitch_data_270

    goto/16 :goto_198

    :sswitch_56
    const-string v5, "@Position"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_198

    .line 265
    const-string v5, "BasePart"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3f

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v6, "CFrame"

    sget-object v7, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v7, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    const-string v8, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Vector3"

    invoke-static {p2, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v8, p2

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    invoke-virtual {v5, v4, v6, v7}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_3f

    .line 264
    :sswitch_80
    const-string v5, "@BrickColor"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_198

    .line 271
    const-string v5, "BasePart"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3f

    .line 272
    const-string v5, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.BrickColorV"

    invoke-static {p2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v5, p2

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    .line 273
    .local v5, "b\\1":Lcom/exampletest/mobilestudiotest/model/BrickColorV;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v7

    const-string v8, "Color"

    invoke-virtual {v7, v8}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_a7

    const-string v7, "Color"

    goto :goto_a9

    :cond_a7
    const-string v7, "Color3uint8"

    .line 274
    .local v7, "key\\1":Ljava/lang/String;
    :goto_a9
    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v9

    invoke-virtual {v8, v4, v7, v9}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .line 275
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v8

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v8, v7, v6}, Ljava/util/HashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 276
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v6

    const-string v8, "BrickColor"

    invoke-virtual {v6, v8}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3f

    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v8, "BrickColor"

    invoke-virtual {v6, v4, v8, v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .end local v5    # "b\\1":Lcom/exampletest/mobilestudiotest/model/BrickColorV;
    .end local v7    # "key\\1":Ljava/lang/String;
    goto/16 :goto_3f

    .line 264
    :sswitch_d2
    const-string v5, "size"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_e4

    goto/16 :goto_198

    :sswitch_dc
    const-string v5, "Size"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_198

    .line 280
    :cond_e4
    const-string v5, "BasePart"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_104

    .line 281
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v5

    const-string v6, "size"

    invoke-virtual {v5, v6}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_fb

    const-string v5, "size"

    goto :goto_fd

    :cond_fb
    const-string v5, "Size"

    .line 282
    .local v5, "key\\1":Ljava/lang/String;
    :goto_fd
    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v6, v4, v5, p2}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .end local v5    # "key\\1":Ljava/lang/String;
    goto/16 :goto_3f

    .line 283
    :cond_104
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3f

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v5, v4, v0, p2}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    goto/16 :goto_3f

    .line 264
    :sswitch_115
    const-string v5, "Name"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_198

    .line 279
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v5

    if-nez v5, :cond_3f

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v6, "Name"

    invoke-virtual {v5, v4, v6, p2}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    goto/16 :goto_3f

    .line 264
    :sswitch_12c
    const-string v5, "@Orientation"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_198

    .line 266
    const-string v5, "BasePart"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3f

    .line 267
    const-string v5, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Vector3"

    invoke-static {p2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v5, p2

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const v6, 0x3c8efa35

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    .line 268
    .local v5, "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v7, "CFrame"

    sget-object v8, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v9

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v10

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v11

    invoke-virtual {v8, v9, v10, v11}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromOrientation(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v8

    sget-object v9, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v9, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v8

    invoke-virtual {v6, v4, v7, v8}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .end local v5    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    goto/16 :goto_3f

    .line 264
    :sswitch_174
    const-string v5, "@Archivable"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_198

    .line 270
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v5

    if-nez v5, :cond_3f

    const/4 v5, 0x1

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-static {p2, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->setArchivable(Z)V

    goto/16 :goto_3f

    .line 264
    :sswitch_190
    const-string v5, "PivotOffset"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_199

    :cond_198
    :goto_198
    goto :goto_1cc

    .line 278
    :cond_199
    const-string v5, "BasePart"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3f

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v6, "PivotOffset"

    const-string v7, "PivotOffset"

    invoke-virtual {v4, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v8, :cond_1b2

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/CFrame;

    goto :goto_1b3

    :cond_1b2
    const/4 v7, 0x0

    :goto_1b3
    if-nez v7, :cond_1bb

    sget-object v7, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    :cond_1bb
    const-string v8, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Vector3"

    invoke-static {p2, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v8, p2

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    invoke-virtual {v5, v4, v6, v7}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    goto/16 :goto_3f

    .line 284
    :goto_1cc
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1ee

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v5

    if-eq v4, v5, :cond_1ee

    const-string v5, "BasePart"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_1ee

    goto/16 :goto_3f

    .line 285
    :cond_1ee
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v5, v4, v0, p2}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .line 286
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getType()I

    move-result v5

    if-ne v5, v6, :cond_208

    instance-of v5, p2, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v5, :cond_208

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v5

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v5, v0, v6}, Ljava/util/HashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 287
    :cond_208
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getType()I

    move-result v5

    const/16 v6, 0x12

    if-ne v5, v6, :cond_21f

    instance-of v5, p2, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v5, :cond_21f

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v5

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v5, v0, v6}, Ljava/util/HashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 288
    :cond_21f
    const-string v5, "Color3uint8"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_22f

    const-string v5, "Color"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3f

    :cond_22f
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v5

    const-string v6, "BrickColor"

    invoke-virtual {v5, v6}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3f

    instance-of v5, p2, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v5, :cond_3f

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v6, "BrickColor"

    new-instance v7, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v8, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    move-object v9, p2

    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->closest(Lcom/exampletest/mobilestudiotest/model/Color3;)I

    move-result v8

    invoke-direct {v7, v8}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {v5, v4, v6, v7}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .end local v4    # "inst\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto/16 :goto_3f

    .line 292
    :cond_256
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->commit()V

    .line 293
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->markDirty()V

    .line 294
    nop

    .end local v2    # "$i$a$-synchronized-PropertiesPanel$applyEdit$1\\1\\261\\0":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_267
    .catchall {:try_start_f .. :try_end_267} :catchall_26c

    .line 261
    monitor-exit v1

    .line 295
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild()V

    .line 296
    return-void

    .line 261
    :catchall_26c
    move-exception v2

    monitor-exit v1

    throw v2

    nop

    :sswitch_data_270
    .sparse-switch
        -0x5f4bf4ab -> :sswitch_190
        -0x563e77c3 -> :sswitch_174
        -0x5fa0a90 -> :sswitch_12c
        0x24eeab -> :sswitch_115
        0x275421 -> :sswitch_dc
        0x35e001 -> :sswitch_d2
        0x5746402 -> :sswitch_80
        0x4188bd89 -> :sswitch_56
    .end sparse-switch
.end method

.method private final categoryOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)Ljava/lang/String;
    .registers 10
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "disp"    # Ljava/lang/String;
    .param p3, "t"    # I

    .line 120
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->CATEGORY:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "Data"

    const-string v2, "Appearance"

    if-eqz v0, :cond_91

    .local v0, "cat\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 122
    .local v3, "$i$a$-let-PropertiesPanel$categoryOf$1\\1\\120\\0":I
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v4

    sparse-switch v4, :sswitch_data_bc

    goto :goto_31

    :sswitch_17
    const-string v4, "Position"

    invoke-virtual {p2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_32

    goto :goto_31

    :sswitch_20
    const-string v4, "Rotation"

    invoke-virtual {p2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_31

    goto :goto_32

    :sswitch_29
    const-string v4, "Size"

    invoke-virtual {p2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_32

    :cond_31
    :goto_31
    goto :goto_46

    :cond_32
    :goto_32
    const-string v2, "GuiObject"

    invoke-virtual {p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_43

    const-string v2, "BasePart"

    invoke-virtual {p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_43

    goto :goto_45

    :cond_43
    const-string v1, "Transform"

    :goto_45
    return-object v1

    .line 123
    :goto_46
    const-string v1, "Brightness"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const-string v4, "Light"

    if-eqz v1, :cond_5d

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v1

    const-string v5, "Lighting"

    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5d

    return-object v4

    .line 124
    :cond_5d
    const-string v1, "Color"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6c

    invoke-virtual {p1, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6c

    return-object v2

    .line 125
    :cond_6c
    const-string v1, "Enabled"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7b

    invoke-virtual {p1, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_7b

    return-object v2

    .line 126
    :cond_7b
    const-string v1, "Texture"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_90

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v1

    const-string v4, "Decal"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_90

    return-object v2

    .line 127
    :cond_90
    return-object v0

    .line 129
    .end local v0    # "cat\\1":Ljava/lang/String;
    .end local v3    # "$i$a$-let-PropertiesPanel$categoryOf$1\\1\\120\\0":I
    :cond_91
    const-string v0, "ParticleEmitter"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_ba

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "Trail"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_ba

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "Beam"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_ba

    .line 130
    sparse-switch p3, :sswitch_data_ca

    .line 133
    goto :goto_b9

    .line 132
    :sswitch_b5
    const-string v1, "Behavior"

    goto :goto_b9

    .line 131
    :sswitch_b8
    nop

    .line 130
    :goto_b9
    return-object v1

    .line 129
    :cond_ba
    return-object v2

    nop

    :sswitch_data_bc
    .sparse-switch
        0x275421 -> :sswitch_29
        0x173739e -> :sswitch_20
        0x306cfd49 -> :sswitch_17
    .end sparse-switch

    :sswitch_data_ca
    .sparse-switch
        0x1 -> :sswitch_b8
        0x2 -> :sswitch_b5
        0x13 -> :sswitch_b8
        0x22 -> :sswitch_b8
    .end sparse-switch
.end method

.method private final edit(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V
    .registers 14
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    .line 299
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getAction()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 389
    .local v0, "it\\1":Lkotlin/jvm/functions/Function0;
    const/4 v1, 0x0

    .line 299
    .local v1, "$i$a$-let-PropertiesPanel$edit$1\\1\\299\\0":I
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild()V

    return-void

    .line 300
    .end local v0    # "it\\1":Lkotlin/jvm/functions/Function0;
    .end local v1    # "$i$a$-let-PropertiesPanel$edit$1\\1\\299\\0":I
    :cond_e
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v0, :cond_1f

    return-void

    .line 301
    .local v0, "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_1f
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getProp()Ljava/lang/String;

    move-result-object v1

    const-string v2, "@Source"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_31

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->openScript(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    return-void

    .line 302
    :cond_31
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getType()I

    move-result v1

    const/16 v2, 0x13

    const/4 v3, 0x0

    if-ne v1, v2, :cond_52

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getValue()Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v2, :cond_45

    move-object v3, v1

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    :cond_45
    if-eqz v3, :cond_51

    .line 389
    .local v3, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v1, 0x0

    .line 302
    .local v1, "$i$a$-let-PropertiesPanel$edit$2\\2\\302\\0":I
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    .end local v1    # "$i$a$-let-PropertiesPanel$edit$2\\2\\302\\0":I
    .end local v3    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_51
    return-void

    .line 303
    :cond_52
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getEditable()Z

    move-result v1

    if-nez v1, :cond_59

    return-void

    .line 304
    :cond_59
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getType()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v2, :cond_76

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    xor-int/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-direct {p0, p1, v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->applyEdit(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Ljava/lang/Object;)V

    return-void

    .line 305
    :cond_76
    nop

    .line 306
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v1

    const-string v4, "Material"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_84

    goto :goto_c3

    .line 307
    :cond_84
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v1

    const-string v4, "Surface"

    const/4 v5, 0x0

    invoke-static {v1, v4, v5, v2, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    const-string v2, "BasePart"

    if-eqz v1, :cond_9c

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_9c

    const-string v4, "SurfaceType"

    goto :goto_c3

    .line 308
    :cond_9c
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v1

    const-string v3, "Shape"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b1

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_b1

    const-string v4, "PartType"

    goto :goto_c3

    .line 309
    :cond_b1
    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getProp()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_bf

    const-string v3, ""

    :cond_bf
    invoke-virtual {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Enums;->typeForProp(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 305
    :goto_c3
    move-object v10, v4

    .line 311
    .local v10, "enumType":Ljava/lang/String;
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Dialogs;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->getContext()Landroid/content/Context;

    move-result-object v6

    const-string v1, "getContext(...)"

    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getValue()Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getType()I

    move-result v9

    new-instance v11, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda0;

    invoke-direct {v11, p0, p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V

    invoke-virtual/range {v5 .. v11}, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->editValue(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;ILjava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 312
    return-void
.end method

.method static final edit$lambda$13(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Ljava/lang/Object;)Lkotlin/Unit;
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
    .param p1, "$r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
    .param p2, "it"    # Ljava/lang/Object;

    .line 311
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->applyEdit(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Ljava/lang/Object;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final previewListener$lambda$1(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    .line 34
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->post(Ljava/lang/Runnable;)Z

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final previewListener$lambda$1$lambda$0(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    .line 34
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->notifyDataSetChanged()V

    return-void
.end method

.method private static final rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z
    .registers 9
    .param p0, "cats"    # Ljava/util/LinkedHashMap;
    .param p1, "cat"    # Ljava/lang/String;
    .param p2, "r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;",
            ">;>;",
            "Ljava/lang/String;",
            "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;",
            ")Z"
        }
    .end annotation

    .line 146
    move-object v0, p0

    check-cast v0, Ljava/util/Map;

    .local v0, "$this$getOrPut\\1":Ljava/util/Map;
    move-object v1, p1

    .local v1, "key\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .line 390
    .local v2, "$i$f$getOrPut\\1\\146":I
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .line 391
    .local v3, "value\\1":Ljava/lang/Object;
    if-nez v3, :cond_17

    .line 392
    const/4 v4, 0x0

    .line 146
    .local v4, "$i$a$-getOrPut-PropertiesPanel$rebuild$1$add$1\\2\\392\\0":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 392
    .end local v4    # "$i$a$-getOrPut-PropertiesPanel$rebuild$1$add$1\\2\\392\\0":I
    nop

    .line 393
    .local v5, "answer\\1":Ljava/lang/Object;
    invoke-interface {v0, v1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 394
    nop

    .end local v5    # "answer\\1":Ljava/lang/Object;
    goto :goto_18

    .line 396
    :cond_17
    move-object v5, v3

    .line 391
    :goto_18
    nop

    .end local v0    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v1    # "key\\1":Ljava/lang/Object;
    .end local v2    # "$i$f$getOrPut\\1\\146":I
    .end local v3    # "value\\1":Ljava/lang/Object;
    check-cast v5, Ljava/util/ArrayList;

    .line 146
    invoke-virtual {v5, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method static final rebuild$lambda$9$lambda$4(Ljava/lang/Long;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;
    .registers 7
    .param p0, "$id"    # Ljava/lang/Long;
    .param p1, "$inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 155
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const-string v3, "Volume"

    invoke-virtual {p1, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Ljava/lang/Number;

    if-eqz v4, :cond_13

    check-cast v3, Ljava/lang/Number;

    goto :goto_14

    :cond_13
    const/4 v3, 0x0

    :goto_14
    if-eqz v3, :cond_1b

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v3

    goto :goto_1d

    :cond_1b
    const/high16 v3, 0x3f000000    # 0.5f

    :goto_1d
    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview(JF)V

    .line 156
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final rebuild$lambda$9$lambda$6(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Ljava/lang/Comparable;
    .registers 3
    .param p0, "it"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getProp()Ljava/lang/String;

    move-result-object v0

    const-string v1, "@Preview"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13

    const/4 v0, 0x0

    goto :goto_14

    :cond_13
    const/4 v0, 0x1

    :goto_14
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    check-cast v0, Ljava/lang/Comparable;

    return-object v0
.end method

.method static final rebuild$lambda$9$lambda$7(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Ljava/lang/Comparable;
    .registers 3
    .param p0, "it"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "toLowerCase(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Comparable;

    return-object v0
.end method

.method private final valueText(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;
    .registers 11
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
    .param p2, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 239
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getValue()Ljava/lang/Object;

    move-result-object v0

    .line 240
    .local v0, "v":Ljava/lang/Object;
    nop

    .line 241
    const-string v1, ""

    if-nez v0, :cond_15

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getType()I

    move-result v2

    const/16 v3, 0x13

    if-eq v2, v3, :cond_1a3

    const-string v1, "nil"

    goto/16 :goto_1a3

    .line 242
    :cond_15
    instance-of v2, v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v2, :cond_22

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_1a3

    .line 243
    :cond_22
    instance-of v2, v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v2, :cond_b7

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    if-eqz p2, :cond_33

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_33

    goto :goto_34

    :cond_33
    move-object v4, v1

    :goto_34
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getProp()Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_3b

    move-object v1, v5

    :cond_3b
    invoke-virtual {v3, v4, v1}, Lcom/exampletest/mobilestudiotest/model/Enums;->typeForProp(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object v3, v0

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v3

    invoke-virtual {v2, v1, v3}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1a3

    .line 244
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Material"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x0

    if-eqz v1, :cond_67

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    move-object v4, v0

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v4

    invoke-virtual {v1, v2, v4}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_68

    :cond_67
    move-object v1, v3

    .line 243
    :goto_68
    if-nez v1, :cond_1a3

    .line 245
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v4, 0x2

    const-string v5, "Surface"

    invoke-static {v1, v5, v2, v4, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_88

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    move-object v2, v0

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v2

    const-string v4, "SurfaceType"

    invoke-virtual {v1, v4, v2}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_89

    :cond_88
    move-object v1, v3

    .line 243
    :goto_89
    if-nez v1, :cond_1a3

    .line 246
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Shape"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a7

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    move-object v2, v0

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v2

    const-string v3, "PartType"

    invoke-virtual {v1, v3, v2}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_a8

    :cond_a7
    move-object v1, v3

    .line 243
    :goto_a8
    if-nez v1, :cond_1a3

    .line 247
    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_1a3

    .line 248
    :cond_b7
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    if-eqz v1, :cond_c4

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getName()Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_1a3

    .line 249
    :cond_c4
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/Color3;

    const-string v2, ", "

    if-eqz v1, :cond_112

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Color3;->getR()F

    move-result v1

    const/high16 v3, 0x437f0000    # 255.0f

    mul-float/2addr v1, v3

    float-to-int v1, v1

    move-object v4, v0

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Color3;->getG()F

    move-result v4

    mul-float/2addr v4, v3

    float-to-int v4, v4

    move-object v5, v0

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Color3;->getB()F

    move-result v5

    mul-float/2addr v5, v3

    float-to-int v3, v5

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "["

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_1a3

    .line 250
    :cond_112
    instance-of v1, v0, Ljava/lang/Float;

    if-eqz v1, :cond_123

    move-object v1, v0

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_1a3

    .line 251
    :cond_123
    instance-of v1, v0, Ljava/lang/Double;

    if-eqz v1, :cond_133

    move-object v1, v0

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(D)Ljava/lang/String;

    move-result-object v1

    goto :goto_1a3

    .line 252
    :cond_133
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v1, :cond_176

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v1

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v1

    move-object v3, v0

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v3

    move-object v4, v0

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_1a3

    .line 253
    :cond_176
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v1, :cond_186

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_1a3

    .line 254
    :cond_186
    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_19f

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/16 v3, 0xa

    const/16 v4, 0x20

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;CCZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x78

    invoke-static {v1, v2}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_1a3

    .line 255
    :cond_19f
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    .line 240
    :cond_1a3
    :goto_1a3
    return-object v1
.end method


# virtual methods
.method protected onAttachedToWindow()V
    .registers 3

    .line 112
    invoke-super {p0}, Landroid/widget/LinearLayout;->onAttachedToWindow()V

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->getPreviewListeners()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->previewListener:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 3

    .line 113
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->getPreviewListeners()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->previewListener:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    invoke-super {p0}, Landroid/widget/LinearLayout;->onDetachedFromWindow()V

    return-void
.end method

.method public onDirtyChanged()V
    .registers 1

    .line 24
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onDirtyChanged()V

    return-void
.end method

.method public onModelReplaced()V
    .registers 1

    .line 117
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild()V

    return-void
.end method

.method public onPlayStateChanged()V
    .registers 1

    .line 24
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onPlayStateChanged()V

    return-void
.end method

.method public onPluginsChanged()V
    .registers 1

    .line 24
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onPluginsChanged()V

    return-void
.end method

.method public onPropsChanged()V
    .registers 1

    .line 116
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild()V

    return-void
.end method

.method public onSelectionChanged()V
    .registers 1

    .line 115
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild()V

    return-void
.end method

.method public onToolChanged()V
    .registers 1

    .line 24
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onToolChanged()V

    return-void
.end method

.method public onTreeChanged()V
    .registers 1

    .line 24
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onTreeChanged()V

    return-void
.end method

.method public final rebuild()V
    .registers 42

    .line 138
    move-object/from16 v1, p0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v2, v0

    .line 139
    .local v2, "out":Ljava/util/ArrayList;
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    const/4 v0, 0x0

    .line 140
    .local v0, "$i$a$-synchronized-PropertiesPanel$rebuild$1\\1\\139\\0":I
    :try_start_10
    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v4

    check-cast v4, Ljava/util/List;

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 141
    .local v4, "inst\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    if-nez v4, :cond_2b

    .line 142
    iget-object v5, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->title:Landroid/widget/TextView;

    const-string v6, ""

    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_952

    .line 144
    :cond_2b
    iget-object v5, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->title:Landroid/widget/TextView;

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/4 v7, 0x1

    if-le v6, v7, :cond_50

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v8, " selected  "

    goto :goto_6d

    :cond_50
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v9, " \""

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v8, "\"  "

    :goto_6d
    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 145
    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    .line 147
    .local v5, "cats\\1":Ljava/util/LinkedHashMap;
    new-instance v6, Ljava/util/HashSet;

    invoke-direct {v6}, Ljava/util/HashSet;-><init>()V

    .line 148
    .local v6, "shown\\1":Ljava/util/HashSet;
    const-string v8, "BasePart"

    invoke-virtual {v4, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v8

    .line 149
    .local v8, "isPart\\1":Z
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v9

    const-string v10, "Sound"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_f3

    .line 150
    sget-object v9, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    const-string v11, "SoundId"

    invoke-virtual {v4, v11}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->idOf(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object v9

    .line 151
    .local v9, "id\\1":Ljava/lang/Long;
    if-eqz v9, :cond_f0

    .line 152
    sget-object v11, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->getPreview()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    move-result-object v11

    .line 153
    .local v11, "p\\1":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    if-eqz v11, :cond_ca

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getId()J

    move-result-wide v12

    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    cmp-long v12, v12, v14

    if-nez v12, :cond_ca

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v12

    sget-object v13, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-eq v12, v13, :cond_c8

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v12

    sget-object v13, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->LOADING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-ne v12, v13, :cond_ca

    :cond_c8
    move v12, v7

    goto :goto_cb

    :cond_ca
    const/4 v12, 0x0

    .line 154
    .local v12, "playing\\1":Z
    :goto_cb
    const-string v13, "Data"

    new-instance v14, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v15, ""

    const-string v16, "@Preview"

    const-string v17, "Preview"

    if-eqz v12, :cond_da

    const-string v18, "\u25a0 Stop"

    goto :goto_dc

    :cond_da
    const-string v18, "\u25b6 Play"

    :goto_dc
    const/16 v22, 0x0

    new-instance v10, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda2;

    invoke-direct {v10, v9, v4}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda2;-><init>(Ljava/lang/Long;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const/16 v19, 0x1

    const/16 v20, 0x1

    move-object/from16 v21, v10

    invoke-direct/range {v14 .. v21}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;)V

    invoke-static {v5, v13, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .end local v11    # "p\\1":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .end local v12    # "playing\\1":Z
    goto :goto_f5

    .line 151
    :cond_f0
    const/16 v22, 0x0

    goto :goto_f5

    .line 149
    .end local v9    # "id\\1":Ljava/lang/Long;
    :cond_f3
    const/16 v22, 0x0

    .line 159
    :goto_f5
    const-string v9, "Data"

    new-instance v10, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v11, ""

    const-string v12, "Name"

    const-string v13, "Name"

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v15

    if-nez v15, :cond_10c

    move/from16 v16, v7

    goto :goto_10e

    :cond_10c
    move/from16 v16, v22

    :goto_10e
    const/16 v18, 0x40

    const/16 v19, 0x0

    const/4 v15, 0x1

    const/16 v17, 0x0

    invoke-direct/range {v10 .. v19}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-static {v5, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    move-object v9, v6

    check-cast v9, Ljava/util/Collection;

    const-string v10, "Name"

    invoke-interface {v9, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 160
    const-string v9, "Data"

    new-instance v10, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v11, ""

    const-string v12, "ClassName"

    const-string v13, "ClassName"

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v14

    const/16 v18, 0x40

    const/16 v19, 0x0

    const/4 v15, 0x1

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-direct/range {v10 .. v19}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-static {v5, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 161
    const-string v9, "Data"

    new-instance v10, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v11, ""

    const-string v12, "Parent"

    const-string v13, "Parent"

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v14

    const/16 v18, 0x40

    const/16 v19, 0x0

    const/16 v15, 0x13

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-direct/range {v10 .. v19}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-static {v5, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 162
    const-string v9, "Behavior"

    new-instance v10, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v11, ""

    const-string v12, "@Archivable"

    const-string v13, "Archivable"

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getArchivable()Z

    move-result v14

    invoke-static {v14}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v15

    if-nez v15, :cond_179

    move/from16 v16, v7

    goto :goto_17b

    :cond_179
    move/from16 v16, v22

    :goto_17b
    const/16 v18, 0x40

    const/16 v19, 0x0

    const/4 v15, 0x2

    const/16 v17, 0x0

    invoke-direct/range {v10 .. v19}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-static {v5, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 163
    const-string v9, "LuaSourceContainer"

    invoke-virtual {v4, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_1b3

    const-string v9, "Data"

    new-instance v10, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v11, ""

    const-string v12, "@Source"

    const-string v13, "Source"

    const-string v14, "Open in editor\u2026"

    const/16 v18, 0x40

    const/16 v19, 0x0

    const/4 v15, 0x1

    const/16 v16, 0x1

    const/16 v17, 0x0

    invoke-direct/range {v10 .. v19}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-static {v5, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    move-object v9, v6

    check-cast v9, Ljava/util/Collection;

    const-string v10, "Source"

    invoke-interface {v9, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 164
    :cond_1b3
    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eqz v8, :cond_721

    .line 165
    sget-object v11, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v11, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v11

    .line 166
    .local v11, "cf\\1":Lcom/exampletest/mobilestudiotest/model/CFrame;
    const-string v12, "Transform"

    new-instance v23, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v24, ""

    const-string v25, "@Position"

    const-string v26, "Position"

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v27

    const/16 v31, 0x40

    const/16 v32, 0x0

    const/16 v28, 0xe

    const/16 v29, 0x1

    const/16 v30, 0x0

    invoke-direct/range {v23 .. v32}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v23

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 167
    const-string v12, "Transform"

    new-instance v23, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v24, ""

    const-string v25, "@Orientation"

    const-string v26, "Orientation"

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toOrientation()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v13

    const v14, 0x42652ee1

    invoke-virtual {v13, v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v27

    const/16 v31, 0x40

    const/16 v32, 0x0

    const/16 v28, 0xe

    const/16 v29, 0x1

    const/16 v30, 0x0

    invoke-direct/range {v23 .. v32}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v23

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 168
    const-string v12, "Transform"

    new-instance v23, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v24, ""

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v13

    const-string v14, "size"

    invoke-virtual {v13, v14}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_219

    const-string v13, "size"

    goto :goto_21b

    :cond_219
    const-string v13, "Size"

    :goto_21b
    move-object/from16 v25, v13

    const-string v26, "Size"

    sget-object v13, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v13, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v27

    const/16 v31, 0x40

    const/16 v32, 0x0

    const/16 v28, 0xe

    const/16 v29, 0x1

    const/16 v30, 0x0

    invoke-direct/range {v23 .. v32}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v23

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 169
    move-object v12, v6

    check-cast v12, Ljava/util/Collection;

    const/4 v13, 0x5

    new-array v14, v13, [Ljava/lang/String;

    const-string v15, "CFrame"

    aput-object v15, v14, v22

    const-string v15, "size"

    aput-object v15, v14, v7

    const-string v15, "Size"

    aput-object v15, v14, v10

    const-string v15, "Position"

    const/16 v16, 0x3

    aput-object v15, v14, v16

    const-string v15, "Orientation"

    const/16 v17, 0x4

    aput-object v15, v14, v17

    invoke-static {v14}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v14

    check-cast v14, Ljava/lang/Iterable;

    invoke-static {v12, v14}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .line 171
    sget-object v12, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v12, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->color(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v12

    .line 172
    .local v12, "color\\1":Lcom/exampletest/mobilestudiotest/model/Color3;
    const-string v14, "Appearance"

    new-instance v23, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v24, ""

    const-string v25, "@BrickColor"

    const-string v26, "BrickColor"

    const-string v15, "BrickColor"

    invoke-virtual {v4, v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v15

    move/from16 v18, v13

    instance-of v13, v15, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    if-eqz v13, :cond_27d

    check-cast v15, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    goto :goto_27e

    :cond_27d
    move-object v15, v9

    :goto_27e
    if-nez v15, :cond_28b

    new-instance v15, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v13, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    invoke-virtual {v13, v12}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->closest(Lcom/exampletest/mobilestudiotest/model/Color3;)I

    move-result v13

    invoke-direct {v15, v13}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    :cond_28b
    move-object/from16 v27, v15

    const/16 v31, 0x40

    const/16 v32, 0x0

    const/16 v28, 0xb

    const/16 v29, 0x1

    const/16 v30, 0x0

    invoke-direct/range {v23 .. v32}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v23

    invoke-static {v5, v14, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 173
    const-string v13, "Appearance"

    new-instance v23, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v24, ""

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v14

    const-string v15, "Color"

    invoke-virtual {v14, v15}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_2b4

    const-string v14, "Color"

    goto :goto_2b6

    :cond_2b4
    const-string v14, "Color3uint8"

    :goto_2b6
    move-object/from16 v25, v14

    const-string v26, "Color"

    const/16 v31, 0x40

    const/16 v32, 0x0

    const/16 v28, 0x1a

    const/16 v29, 0x1

    const/16 v30, 0x0

    move-object/from16 v27, v12

    .end local v12    # "color\\1":Lcom/exampletest/mobilestudiotest/model/Color3;
    .local v27, "color\\1":Lcom/exampletest/mobilestudiotest/model/Color3;
    invoke-direct/range {v23 .. v32}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v12, v23

    invoke-static {v5, v13, v12}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 174
    const-string v12, "Appearance"

    new-instance v28, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v29, ""

    const-string v30, "Material"

    const-string v31, "Material"

    const-string v13, "Material"

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v13

    if-nez v13, :cond_2e7

    new-instance v13, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    const/16 v14, 0x100

    invoke-direct {v13, v14}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    :cond_2e7
    move-object/from16 v32, v13

    const/16 v36, 0x40

    const/16 v37, 0x0

    const/16 v33, 0x12

    const/16 v34, 0x1

    const/16 v35, 0x0

    invoke-direct/range {v28 .. v37}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v28

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 175
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v12

    const-string v13, "MaterialVariantSerialized"

    invoke-virtual {v12, v13}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_30a

    const-string v12, "MaterialVariantSerialized"

    goto :goto_30c

    :cond_30a
    const-string v12, "MaterialVariant"

    .line 176
    .local v12, "mvKey\\1":Ljava/lang/String;
    :goto_30c
    const-string v13, "Appearance"

    new-instance v28, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v29, ""

    const-string v31, "MaterialVariant"

    invoke-virtual {v4, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_31c

    const-string v14, ""

    :cond_31c
    move-object/from16 v32, v14

    const/16 v36, 0x40

    const/16 v37, 0x0

    const/16 v33, 0x1

    const/16 v34, 0x1

    const/16 v35, 0x0

    move-object/from16 v30, v12

    .end local v12    # "mvKey\\1":Ljava/lang/String;
    .local v30, "mvKey\\1":Ljava/lang/String;
    invoke-direct/range {v28 .. v37}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v12, v28

    invoke-static {v5, v13, v12}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 177
    const-string v12, "Appearance"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "Reflectance"

    const-string v34, "Reflectance"

    const-string v13, "Reflectance"

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v13

    const/4 v14, 0x0

    if-nez v13, :cond_349

    invoke-static {v14}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v13

    :cond_349
    move-object/from16 v35, v13

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x4

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v31

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 178
    const-string v12, "Appearance"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "Transparency"

    const-string v34, "Transparency"

    const-string v13, "Transparency"

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v13

    if-nez v13, :cond_373

    invoke-static {v14}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v13

    :cond_373
    move-object/from16 v35, v13

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x4

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v31

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 179
    const-string v12, "Appearance"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "CastShadow"

    const-string v34, "CastShadow"

    const-string v13, "CastShadow"

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v13

    if-nez v13, :cond_39d

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v13

    :cond_39d
    move-object/from16 v35, v13

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x2

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v31

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 180
    move-object v12, v6

    check-cast v12, Ljava/util/Collection;

    const/16 v13, 0x9

    new-array v14, v13, [Ljava/lang/String;

    const-string v15, "BrickColor"

    aput-object v15, v14, v22

    const-string v15, "Color"

    aput-object v15, v14, v7

    const-string v15, "Color3uint8"

    aput-object v15, v14, v10

    const-string v15, "Material"

    aput-object v15, v14, v16

    const-string v15, "MaterialVariant"

    aput-object v15, v14, v17

    const-string v15, "MaterialVariantSerialized"

    aput-object v15, v14, v18

    const-string v15, "Reflectance"

    const/16 v19, 0x6

    aput-object v15, v14, v19

    const-string v15, "Transparency"

    const/16 v20, 0x7

    aput-object v15, v14, v20

    const-string v15, "CastShadow"

    const/16 v21, 0x8

    aput-object v15, v14, v21

    invoke-static {v14}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v14

    check-cast v14, Ljava/lang/Iterable;

    invoke-static {v12, v14}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .line 181
    const-string v12, "Behavior"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "Locked"

    const-string v34, "Locked"

    const-string v14, "Locked"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_401

    invoke-static/range {v22 .. v22}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    :cond_401
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x2

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 182
    const-string v12, "Collision"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "CanCollide"

    const-string v34, "CanCollide"

    const-string v14, "CanCollide"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_42b

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    :cond_42b
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x2

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 183
    const-string v12, "Collision"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "CanQuery"

    const-string v34, "CanQuery"

    const-string v14, "CanQuery"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_455

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    :cond_455
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x2

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 184
    const-string v12, "Collision"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "CanTouch"

    const-string v34, "CanTouch"

    const-string v14, "CanTouch"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_47f

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    :cond_47f
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x2

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 185
    const-string v12, "Collision"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "CollisionGroup"

    const-string v34, "CollisionGroup"

    const-string v14, "CollisionGroup"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_4a7

    const-string v14, "Default"

    :cond_4a7
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x1

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 186
    const-string v12, "Part"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "Anchored"

    const-string v34, "Anchored"

    const-string v14, "Anchored"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_4d1

    invoke-static/range {v22 .. v22}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    :cond_4d1
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x2

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 187
    const-string v12, "Part"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "Massless"

    const-string v34, "Massless"

    const-string v14, "Massless"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_4fb

    invoke-static/range {v22 .. v22}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    :cond_4fb
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x2

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 188
    const-string v12, "Part"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "RootPriority"

    const-string v34, "RootPriority"

    const-string v14, "RootPriority"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_525

    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    :cond_525
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x3

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 189
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    const-string v14, "Part"

    invoke-static {v12, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_55e

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    const-string v14, "SpawnLocation"

    invoke-static {v12, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_55e

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    const-string v14, "Seat"

    invoke-static {v12, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_55e

    goto :goto_5a2

    .line 190
    :cond_55e
    const-string v12, "Part"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v14

    const-string v15, "Shape"

    invoke-virtual {v14, v15}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_573

    const-string v14, "Shape"

    goto :goto_575

    :cond_573
    const-string v14, "shape"

    :goto_575
    move-object/from16 v33, v14

    const-string v34, "Shape"

    const-string v14, "shape"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_58e

    const-string v14, "Shape"

    invoke-virtual {v4, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    if-nez v14, :cond_58e

    new-instance v14, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-direct {v14, v7}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    :cond_58e
    move-object/from16 v35, v14

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x12

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v14, v31

    invoke-static {v5, v12, v14}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 191
    :goto_5a2
    move-object v12, v6

    check-cast v12, Ljava/util/Collection;

    const/16 v14, 0xa

    new-array v14, v14, [Ljava/lang/String;

    const-string v15, "Locked"

    aput-object v15, v14, v22

    const-string v15, "CanCollide"

    aput-object v15, v14, v7

    const-string v15, "CanQuery"

    aput-object v15, v14, v10

    const-string v15, "CanTouch"

    aput-object v15, v14, v16

    const-string v15, "CollisionGroup"

    aput-object v15, v14, v17

    const-string v15, "Anchored"

    aput-object v15, v14, v18

    const-string v15, "Massless"

    aput-object v15, v14, v19

    const-string v15, "RootPriority"

    aput-object v15, v14, v20

    const-string v15, "shape"

    aput-object v15, v14, v21

    const-string v15, "Shape"

    aput-object v15, v14, v13

    invoke-static {v14}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v13

    check-cast v13, Ljava/lang/Iterable;

    invoke-static {v12, v13}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .line 193
    const-string v12, "PartOperation"

    invoke-virtual {v4, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_5ee

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    const-string v13, "NegateOperation"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_5fa

    :cond_5ee
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    const-string v13, "MeshPart"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_66b

    .line 194
    :cond_5fa
    const-string v12, "Collision"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "CollisionFidelity"

    const-string v34, "CollisionFidelity"

    const-string v13, "CollisionFidelity"

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v13

    if-nez v13, :cond_613

    new-instance v13, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    move/from16 v14, v22

    invoke-direct {v13, v14}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    :cond_613
    move-object/from16 v35, v13

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x12

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v31

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 195
    const-string v12, "Appearance"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "RenderFidelity"

    const-string v34, "RenderFidelity"

    const-string v13, "RenderFidelity"

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v13

    if-nez v13, :cond_63f

    new-instance v13, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    const/4 v14, 0x0

    invoke-direct {v13, v14}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    :cond_63f
    move-object/from16 v35, v13

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x12

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v13, v31

    invoke-static {v5, v12, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 196
    move-object v12, v6

    check-cast v12, Ljava/util/Collection;

    new-array v13, v10, [Ljava/lang/String;

    const-string v14, "CollisionFidelity"

    const/16 v22, 0x0

    aput-object v14, v13, v22

    const-string v14, "RenderFidelity"

    aput-object v14, v13, v7

    invoke-static {v13}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v13

    check-cast v13, Ljava/lang/Iterable;

    invoke-static {v12, v13}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .line 199
    :cond_66b
    const-string v12, "PartOperation"

    invoke-virtual {v4, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v12

    if-nez v12, :cond_6d2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    const-string v13, "MeshPart"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_6d2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    const-string v13, "Terrain"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_6d2

    .line 200
    sget-object v12, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->surfaceProps:Ljava/util/List;

    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_691
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_6cf

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    .local v13, "s\\1":Ljava/lang/String;
    const-string v14, "Surface"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v15

    if-nez v15, :cond_6b2

    new-instance v15, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    move/from16 v16, v7

    const/4 v7, 0x0

    invoke-direct {v15, v7}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    goto :goto_6b4

    :cond_6b2
    move/from16 v16, v7

    :goto_6b4
    move-object/from16 v35, v15

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0x12

    const/16 v37, 0x1

    const/16 v38, 0x0

    move-object/from16 v34, v13

    move-object/from16 v33, v13

    .end local v13    # "s\\1":Ljava/lang/String;
    .local v33, "s\\1":Ljava/lang/String;
    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v7, v31

    invoke-static {v5, v14, v7}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    move/from16 v7, v16

    goto :goto_691

    .end local v33    # "s\\1":Ljava/lang/String;
    :cond_6cf
    move/from16 v16, v7

    goto :goto_6d4

    .line 199
    :cond_6d2
    move/from16 v16, v7

    .line 201
    :goto_6d4
    move-object v7, v6

    check-cast v7, Ljava/util/Collection;

    sget-object v12, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->surfaceProps:Ljava/util/List;

    check-cast v12, Ljava/lang/Iterable;

    invoke-static {v7, v12}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .line 202
    const-string v7, "Pivot"

    new-instance v31, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v32, ""

    const-string v33, "PivotOffset"

    const-string v34, "Pivot Offset"

    const-string v12, "PivotOffset"

    invoke-virtual {v4, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    instance-of v13, v12, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v13, :cond_6f5

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/CFrame;

    goto :goto_6f6

    :cond_6f5
    move-object v12, v9

    :goto_6f6
    if-eqz v12, :cond_6fe

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v12

    if-nez v12, :cond_704

    :cond_6fe
    sget-object v12, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v12

    :cond_704
    move-object/from16 v35, v12

    const/16 v39, 0x40

    const/16 v40, 0x0

    const/16 v36, 0xe

    const/16 v37, 0x1

    const/16 v38, 0x0

    invoke-direct/range {v31 .. v40}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v12, v31

    invoke-static {v5, v7, v12}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .line 203
    move-object v7, v6

    check-cast v7, Ljava/util/Collection;

    const-string v12, "PivotOffset"

    invoke-interface {v7, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_723

    .line 164
    .end local v11    # "cf\\1":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v27    # "color\\1":Lcom/exampletest/mobilestudiotest/model/Color3;
    .end local v30    # "mvKey\\1":Ljava/lang/String;
    :cond_721
    move/from16 v16, v7

    .line 205
    :goto_723
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v7

    check-cast v7, Ljava/util/Map;

    invoke-interface {v7}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_731
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_7cf

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/util/Map$Entry;

    invoke-interface {v11}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    .local v12, "k\\1":Ljava/lang/String;
    invoke-interface {v11}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v27

    move-object/from16 v11, v27

    .line 206
    .local v11, "v\\1":Ljava/lang/Object;
    invoke-virtual {v6, v12}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_7c9

    sget-object v13, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->skip:Ljava/util/Set;

    invoke-interface {v13, v12}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_758

    goto :goto_731

    .line 207
    :cond_758
    const-string v13, "xmlRead"

    const/4 v14, 0x0

    invoke-static {v12, v13, v14, v10, v9}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_764

    if-nez v11, :cond_764

    goto :goto_731

    .line 208
    :cond_764
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v13

    invoke-virtual {v13, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Integer;

    if-eqz v13, :cond_775

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    goto :goto_77b

    :cond_775
    sget-object v13, Lcom/exampletest/mobilestudiotest/model/PropType;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropType;

    invoke-virtual {v13, v11}, Lcom/exampletest/mobilestudiotest/model/PropType;->infer(Ljava/lang/Object;)I

    move-result v13

    :goto_77b
    move/from16 v28, v13

    move/from16 v13, v28

    .line 209
    .local v13, "t\\1":I
    sget-object v14, Lcom/exampletest/mobilestudiotest/model/PropType;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropType;

    invoke-virtual {v14, v13, v11}, Lcom/exampletest/mobilestudiotest/model/PropType;->hidden(ILjava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_7c1

    .line 210
    sget-object v14, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v14, v12}, Lcom/exampletest/mobilestudiotest/model/PropNames;->display(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v26

    move-object/from16 v14, v26

    .line 211
    .local v14, "disp\\1":Ljava/lang/String;
    invoke-virtual {v6, v14}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_7b7

    .line 212
    invoke-direct {v1, v4, v14, v13}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->categoryOf(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v15

    new-instance v23, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v24, ""

    const/16 v31, 0x40

    const/16 v32, 0x0

    const/16 v29, 0x1

    const/16 v30, 0x0

    move-object/from16 v27, v11

    move-object/from16 v25, v12

    move/from16 v28, v13

    move-object/from16 v26, v14

    .end local v11    # "v\\1":Ljava/lang/Object;
    .end local v12    # "k\\1":Ljava/lang/String;
    .end local v13    # "t\\1":I
    .end local v14    # "disp\\1":Ljava/lang/String;
    .local v25, "k\\1":Ljava/lang/String;
    .local v26, "disp\\1":Ljava/lang/String;
    .local v27, "v\\1":Ljava/lang/Object;
    .local v28, "t\\1":I
    invoke-direct/range {v23 .. v32}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v11, v23

    invoke-static {v5, v15, v11}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$add(Ljava/util/LinkedHashMap;Ljava/lang/String;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Z

    .end local v26    # "disp\\1":Ljava/lang/String;
    .end local v28    # "t\\1":I
    goto/16 :goto_731

    .line 211
    .end local v25    # "k\\1":Ljava/lang/String;
    .end local v27    # "v\\1":Ljava/lang/Object;
    .restart local v11    # "v\\1":Ljava/lang/Object;
    .restart local v12    # "k\\1":Ljava/lang/String;
    .restart local v13    # "t\\1":I
    .restart local v14    # "disp\\1":Ljava/lang/String;
    :cond_7b7
    move-object/from16 v27, v11

    move-object/from16 v25, v12

    move/from16 v28, v13

    move-object/from16 v26, v14

    .end local v11    # "v\\1":Ljava/lang/Object;
    .end local v12    # "k\\1":Ljava/lang/String;
    .end local v13    # "t\\1":I
    .end local v14    # "disp\\1":Ljava/lang/String;
    .restart local v25    # "k\\1":Ljava/lang/String;
    .restart local v26    # "disp\\1":Ljava/lang/String;
    .restart local v27    # "v\\1":Ljava/lang/Object;
    .restart local v28    # "t\\1":I
    goto/16 :goto_731

    .line 209
    .end local v25    # "k\\1":Ljava/lang/String;
    .end local v26    # "disp\\1":Ljava/lang/String;
    .end local v27    # "v\\1":Ljava/lang/Object;
    .end local v28    # "t\\1":I
    .restart local v11    # "v\\1":Ljava/lang/Object;
    .restart local v12    # "k\\1":Ljava/lang/String;
    .restart local v13    # "t\\1":I
    :cond_7c1
    move-object/from16 v27, v11

    move-object/from16 v25, v12

    move/from16 v28, v13

    .end local v11    # "v\\1":Ljava/lang/Object;
    .end local v12    # "k\\1":Ljava/lang/String;
    .end local v13    # "t\\1":I
    .restart local v25    # "k\\1":Ljava/lang/String;
    .restart local v27    # "v\\1":Ljava/lang/Object;
    .restart local v28    # "t\\1":I
    goto/16 :goto_731

    .line 206
    .end local v25    # "k\\1":Ljava/lang/String;
    .end local v27    # "v\\1":Ljava/lang/Object;
    .end local v28    # "t\\1":I
    .restart local v11    # "v\\1":Ljava/lang/Object;
    .restart local v12    # "k\\1":Ljava/lang/String;
    :cond_7c9
    move-object/from16 v27, v11

    move-object/from16 v25, v12

    .end local v11    # "v\\1":Ljava/lang/Object;
    .end local v12    # "k\\1":Ljava/lang/String;
    .restart local v25    # "k\\1":Ljava/lang/String;
    .restart local v27    # "v\\1":Ljava/lang/Object;
    goto/16 :goto_731

    .line 214
    .end local v25    # "k\\1":Ljava/lang/String;
    .end local v27    # "v\\1":Ljava/lang/Object;
    :cond_7cf
    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->ORDER:Ljava/util/List;

    check-cast v7, Ljava/util/Collection;

    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v11

    const-string v12, "<get-keys>(...)"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v11, Ljava/lang/Iterable;

    .local v11, "$this$filter\\2":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 385
    .local v12, "$i$f$filter\\2\\214":I
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    check-cast v13, Ljava/util/Collection;

    .local v13, "destination\\3":Ljava/util/Collection;
    move-object v14, v11

    .local v14, "$this$filterTo\\3":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 386
    .local v15, "$i$f$filterTo\\3\\385":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_7ec
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_815

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v19, v18

    .local v19, "element\\3":Ljava/lang/Object;
    move-object/from16 v18, v19

    check-cast v18, Ljava/lang/String;

    move-object/from16 v20, v18

    .local v20, "it\\4":Ljava/lang/String;
    const/16 v18, 0x0

    .line 214
    .local v18, "$i$a$-filter-PropertiesPanel$rebuild$1$2\\4\\386\\1":I
    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->ORDER:Ljava/util/List;

    move-object/from16 v10, v20

    .end local v20    # "it\\4":Ljava/lang/String;
    .local v10, "it\\4":Ljava/lang/String;
    invoke-interface {v9, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v9

    .line 386
    .end local v10    # "it\\4":Ljava/lang/String;
    .end local v18    # "$i$a$-filter-PropertiesPanel$rebuild$1$2\\4\\386\\1":I
    if-nez v9, :cond_810

    move-object/from16 v9, v19

    .end local v19    # "element\\3":Ljava/lang/Object;
    .local v9, "element\\3":Ljava/lang/Object;
    invoke-interface {v13, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_812

    .end local v9    # "element\\3":Ljava/lang/Object;
    .restart local v19    # "element\\3":Ljava/lang/Object;
    :cond_810
    move-object/from16 v9, v19

    .end local v19    # "element\\3":Ljava/lang/Object;
    .restart local v9    # "element\\3":Ljava/lang/Object;
    :goto_812
    const/4 v9, 0x0

    const/4 v10, 0x2

    goto :goto_7ec

    .line 387
    .end local v9    # "element\\3":Ljava/lang/Object;
    :cond_815
    nop

    .end local v13    # "destination\\3":Ljava/util/Collection;
    .end local v14    # "$this$filterTo\\3":Ljava/lang/Iterable;
    .end local v15    # "$i$f$filterTo\\3\\385":I
    move-object v9, v13

    check-cast v9, Ljava/util/List;

    .line 385
    nop

    .end local v11    # "$this$filter\\2":Ljava/lang/Iterable;
    .end local v12    # "$i$f$filter\\2\\214":I
    check-cast v9, Ljava/lang/Iterable;

    .line 214
    invoke-static {v7, v9}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_824
    :goto_824
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_887

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .line 215
    .local v9, "cat\\1":Ljava/lang/String;
    invoke-virtual {v5, v9}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/ArrayList;

    if-nez v10, :cond_839

    goto :goto_824

    .line 216
    .local v10, "items\\1":Ljava/util/ArrayList;
    :cond_839
    invoke-virtual {v10}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_824

    .line 217
    new-instance v24, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const/16 v32, 0x40

    const/16 v33, 0x0

    const/16 v26, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    move-object/from16 v27, v9

    move-object/from16 v25, v9

    .end local v9    # "cat\\1":Ljava/lang/String;
    .local v25, "cat\\1":Ljava/lang/String;
    invoke-direct/range {v24 .. v33}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v11, v24

    .end local v25    # "cat\\1":Ljava/lang/String;
    .restart local v9    # "cat\\1":Ljava/lang/String;
    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 218
    iget-object v11, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->collapsed:Ljava/util/HashSet;

    invoke-virtual {v11, v9}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_824

    .line 220
    move-object v11, v10

    check-cast v11, Ljava/lang/Iterable;

    const/4 v12, 0x2

    new-array v13, v12, [Lkotlin/jvm/functions/Function1;

    new-instance v12, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda3;

    invoke-direct {v12}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda3;-><init>()V

    const/16 v22, 0x0

    aput-object v12, v13, v22

    new-instance v12, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda4;

    invoke-direct {v12}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda4;-><init>()V

    aput-object v12, v13, v16

    invoke-static {v13}, Lkotlin/comparisons/ComparisonsKt;->compareBy([Lkotlin/jvm/functions/Function1;)Ljava/util/Comparator;

    move-result-object v12

    invoke-static {v11, v12}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v11

    check-cast v11, Ljava/util/Collection;

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .end local v10    # "items\\1":Ljava/util/ArrayList;
    goto :goto_824

    .line 222
    .end local v9    # "cat\\1":Ljava/lang/String;
    :cond_887
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v7

    check-cast v7, Ljava/util/Map;

    invoke-interface {v7}, Ljava/util/Map;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_8a1

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v7

    const-string v9, "AttributesSerialize"

    invoke-virtual {v7, v9}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_8a1

    goto/16 :goto_952

    .line 223
    :cond_8a1
    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/Attributes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

    invoke-virtual {v7, v4}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 224
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v7

    check-cast v7, Ljava/util/Map;

    invoke-interface {v7}, Ljava/util/Map;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_952

    .line 225
    new-instance v9, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    const-string v10, "Attributes"

    const-string v12, "Attributes"

    const/16 v17, 0x40

    const/16 v18, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    invoke-direct/range {v9 .. v18}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 226
    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->collapsed:Ljava/util/HashSet;

    const-string v9, "Attributes"

    invoke-virtual {v7, v9}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_952

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v7

    const-string v9, "<get-entries>(...)"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v7, Ljava/lang/Iterable;

    .local v7, "$this$sortedBy\\5":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 388
    .local v9, "$i$f$sortedBy\\5\\226":I
    new-instance v10, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$rebuild$lambda$9$$inlined$sortedBy$1;

    invoke-direct {v10}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$rebuild$lambda$9$$inlined$sortedBy$1;-><init>()V

    check-cast v10, Ljava/util/Comparator;

    invoke-static {v7, v10}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v10

    .line 226
    .end local v7    # "$this$sortedBy\\5":Ljava/lang/Iterable;
    .end local v9    # "$i$f$sortedBy\\5\\226":I
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_8f1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_952

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    const-string v10, "next(...)"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v9, Ljava/util/Map$Entry;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v10

    const-string v11, "component1(...)"

    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v10, Ljava/lang/String;

    move-object v14, v10

    .local v14, "k\\1":Ljava/lang/String;
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v15

    .line 227
    .local v15, "v\\1":Ljava/lang/Object;
    const-string v9, "__"

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-static {v14, v9, v12, v11, v10}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_94d

    .line 228
    move/from16 v23, v11

    new-instance v11, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    move/from16 v22, v12

    const-string v12, ""

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "@attr:"

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    sget-object v9, Lcom/exampletest/mobilestudiotest/model/PropType;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropType;

    invoke-virtual {v9, v15}, Lcom/exampletest/mobilestudiotest/model/PropType;->infer(Ljava/lang/Object;)I

    move-result v16

    const/16 v19, 0x40

    const/16 v20, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    invoke-direct/range {v11 .. v20}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_8f1

    .line 227
    :cond_94d
    move/from16 v23, v11

    move/from16 v22, v12

    goto :goto_8f1

    .line 233
    .end local v5    # "cats\\1":Ljava/util/LinkedHashMap;
    .end local v6    # "shown\\1":Ljava/util/HashSet;
    .end local v8    # "isPart\\1":Z
    .end local v14    # "k\\1":Ljava/lang/String;
    .end local v15    # "v\\1":Ljava/lang/Object;
    :cond_952
    :goto_952
    nop

    .end local v0    # "$i$a$-synchronized-PropertiesPanel$rebuild$1\\1\\139\\0":I
    .end local v4    # "inst\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_955
    .catchall {:try_start_10 .. :try_end_955} :catchall_961

    .line 139
    monitor-exit v3

    .line 234
    move-object v0, v2

    check-cast v0, Ljava/util/List;

    iput-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rows:Ljava/util/List;

    .line 235
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->notifyDataSetChanged()V

    .line 236
    return-void

    .line 139
    :catchall_961
    move-exception v0

    monitor-exit v3

    throw v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel.Adapter (com.exampletest.mobilestudiotest.ui.PropertiesPanel$Adapter)
.class final Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "PropertiesPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Adapter"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPropertiesPanel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PropertiesPanel.kt\ncom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,384:1\n1#2:385\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0003\u0008\u0082\u0004\u0018\u00002\u000c\u0012\u0008\u0012\u00060\u0002R\u00020\u00030\u0001B\u0007\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0008\u0010\u0006\u001a\u00020\u0007H\u0016J\u001c\u0010\u0008\u001a\u00060\u0002R\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0007H\u0016J\u001c\u0010\u000c\u001a\u00020\r2\n\u0010\u000e\u001a\u00060\u0002R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0007H\u0016\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;",
        "Landroidx/recyclerview/widget/RecyclerView$Adapter;",
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;",
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V",
        "getItemCount",
        "",
        "onCreateViewHolder",
        "parent",
        "Landroid/view/ViewGroup;",
        "viewType",
        "onBindViewHolder",
        "",
        "h",
        "position",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V
    .registers 2
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 316
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    return-void
.end method

.method static final onBindViewHolder$lambda$5(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Landroid/view/View;)V
    .registers 5
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
    .param p1, "$r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
    .param p2, "it"    # Landroid/view/View;

    .line 353
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->access$getCollapsed$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Ljava/util/HashSet;

    move-result-object v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_19

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->access$getCollapsed$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Ljava/util/HashSet;

    move-result-object v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    :cond_19
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild()V

    return-void
.end method

.method static final onBindViewHolder$lambda$8(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Landroid/view/View;)V
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
    .param p1, "$r"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
    .param p2, "it"    # Landroid/view/View;

    .line 380
    invoke-static {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->access$edit(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V

    return-void
.end method


# virtual methods
.method public getItemCount()I
    .registers 2

    .line 317
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->access$getRows$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .registers 4
    .param p1, "p0"    # Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .param p2, "p1"    # I

    .line 316
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;

    invoke-virtual {p0, v0, p2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->onBindViewHolder(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;I)V

    return-void
.end method

.method public onBindViewHolder(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;I)V
    .registers 21
    .param p1, "h"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;
    .param p2, "position"    # I

    move-object/from16 v0, p0

    const-string v1, "h"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 338
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->access$getRows$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Ljava/util/List;

    move-result-object v1

    move/from16 v3, p2

    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    .line 339
    .local v1, "r":Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v4

    .line 340
    .local v4, "ctx":Landroid/content/Context;
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/high16 v6, 0x41600000    # 14.0f

    invoke-virtual {v5, v4, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    .line 341
    .local v5, "dsz":I
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getProp()Ljava/lang/String;

    move-result-object v6

    const/high16 v7, 0x3f800000    # 1.0f

    const/high16 v8, 0x40c00000    # 6.0f

    const/4 v9, -0x2

    const/high16 v10, 0x40800000    # 4.0f

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    if-nez v6, :cond_ef

    .line 342
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getTitle()Ljava/lang/String;

    move-result-object v15

    check-cast v15, Ljava/lang/CharSequence;

    invoke-virtual {v6, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 343
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    sget-object v15, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v15, v4, v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    sget-object v15, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v15, v4, v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v15

    invoke-virtual {v6, v8, v13, v15, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 344
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    new-instance v8, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    invoke-static {v15}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->access$getCollapsed$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Ljava/util/HashSet;

    move-result-object v15

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getTitle()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v15, v11}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v11

    xor-int/2addr v11, v12

    sget-object v15, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v15

    invoke-direct {v8, v11, v15}, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;-><init>(ZI)V

    .line 385
    move-object v11, v8

    .local v11, "$this$onBindViewHolder_u24lambda_u244\\1":Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;
    const/4 v15, 0x0

    .line 344
    .local v15, "$i$a$-apply-PropertiesPanel$Adapter$onBindViewHolder$1\\1\\344\\0":I
    invoke-virtual {v11, v13, v13, v5, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->setBounds(IIII)V

    .end local v11    # "$this$onBindViewHolder_u24lambda_u244\\1":Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;
    .end local v15    # "$i$a$-apply-PropertiesPanel$Adapter$onBindViewHolder$1\\1\\344\\0":I
    check-cast v8, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v6, v8, v14, v14, v14}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 345
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8, v4, v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    .line 346
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v6, v14, v14, v14, v14}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 347
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v8

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 348
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v6, v14, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 349
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v8, v13, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 350
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v6

    const/16 v7, 0x8

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setVisibility(I)V

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getSwatch()Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    .line 351
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-virtual {v6, v12}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    .line 352
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v6

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getHEADER()I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 353
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v6

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    new-instance v8, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda0;

    invoke-direct {v8, v7, v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V

    invoke-virtual {v6, v8}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 354
    return-void

    .line 356
    :cond_ef
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-virtual {v6, v12}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6, v13}, Landroid/view/View;->setVisibility(I)V

    .line 357
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    sget-object v11, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v15, 0x41b00000    # 22.0f

    invoke-virtual {v11, v4, v15}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v11

    sget-object v15, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v15, v4, v10}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v10

    invoke-virtual {v6, v11, v13, v10, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 358
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const v11, 0x3ee66666    # 0.45f

    invoke-direct {v10, v13, v9, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v10, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 359
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v6, v14, v13}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 360
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v6, v14, v14, v14, v14}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 361
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getDisplay()Ljava/lang/String;

    move-result-object v9

    check-cast v9, Ljava/lang/CharSequence;

    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 362
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getEditable()Z

    move-result v9

    if-nez v9, :cond_152

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getAction()Lkotlin/jvm/functions/Function0;

    move-result-object v9

    if-nez v9, :cond_152

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result v9

    goto :goto_158

    :cond_152
    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v9

    :goto_158
    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 363
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setVisibility(I)V

    .line 364
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v6

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getPANEL()I

    move-result v9

    invoke-virtual {v6, v9}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 365
    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v6

    check-cast v6, Ljava/util/List;

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 366
    .local v6, "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "v":Ljava/lang/Object;
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v10, :cond_18d

    move-object v10, v9

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Color3;

    goto :goto_19a

    :cond_18d
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    if-eqz v10, :cond_199

    move-object v10, v9

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v10

    goto :goto_19a

    :cond_199
    move-object v10, v14

    .line 367
    .end local v9    # "v":Ljava/lang/Object;
    .local v10, "color":Lcom/exampletest/mobilestudiotest/model/Color3;
    :goto_19a
    if-eqz v10, :cond_1ca

    .line 368
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getSwatch()Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9, v13}, Landroid/view/View;->setVisibility(I)V

    .line 369
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getSwatch()Landroid/view/View;

    move-result-object v9

    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 385
    move-object v15, v11

    .local v15, "$this$onBindViewHolder_u24lambda_u246\\2":Landroid/graphics/drawable/GradientDrawable;
    const/16 v16, 0x0

    .line 369
    .local v16, "$i$a$-apply-PropertiesPanel$Adapter$onBindViewHolder$3\\2\\369\\0":I
    move/from16 v17, v12

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Color3;->toArgb()I

    move-result v12

    invoke-virtual {v15, v12}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    sget-object v12, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v12, v4, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    const v12, -0x777778

    invoke-virtual {v15, v7, v12}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .end local v15    # "$this$onBindViewHolder_u24lambda_u246\\2":Landroid/graphics/drawable/GradientDrawable;
    .end local v16    # "$i$a$-apply-PropertiesPanel$Adapter$onBindViewHolder$3\\2\\369\\0":I
    check-cast v11, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v9, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_1d5

    .line 370
    :cond_1ca
    move/from16 v17, v12

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getSwatch()Landroid/view/View;

    move-result-object v7

    const/16 v9, 0x8

    invoke-virtual {v7, v9}, Landroid/view/View;->setVisibility(I)V

    .line 371
    :goto_1d5
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getType()I

    move-result v7

    const/4 v9, 0x2

    if-ne v7, v9, :cond_21e

    .line 372
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v7

    const-string v9, ""

    check-cast v9, Ljava/lang/CharSequence;

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 373
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v7

    new-instance v9, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getValue()Ljava/lang/Object;

    move-result-object v11

    invoke-static/range {v17 .. v17}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    invoke-virtual {v12}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v12

    iget v12, v12, Landroid/util/DisplayMetrics;->density:F

    invoke-direct {v9, v11, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;-><init>(ZF)V

    .line 385
    move-object v11, v9

    .local v11, "$this$onBindViewHolder_u24lambda_u247\\3":Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;
    const/4 v12, 0x0

    .line 373
    .local v12, "$i$a$-apply-PropertiesPanel$Adapter$onBindViewHolder$4\\3\\373\\0":I
    invoke-virtual {v11, v13, v13, v5, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->setBounds(IIII)V

    .end local v11    # "$this$onBindViewHolder_u24lambda_u247\\3":Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;
    .end local v12    # "$i$a$-apply-PropertiesPanel$Adapter$onBindViewHolder$4\\3\\373\\0":I
    check-cast v9, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v7, v9, v14, v14, v14}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 374
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v7

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9, v4, v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    goto :goto_234

    .line 376
    :cond_21e
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v7

    invoke-virtual {v7, v14, v14, v14, v14}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 377
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v7

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    invoke-static {v8, v1, v6}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->access$valueText(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;

    move-result-object v8

    check-cast v8, Ljava/lang/CharSequence;

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 379
    :goto_234
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getValue()Landroid/widget/TextView;

    move-result-object v7

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getAction()Lkotlin/jvm/functions/Function0;

    move-result-object v8

    const v9, -0x934901

    if-nez v8, :cond_249

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->getType()I

    move-result v8

    const/16 v11, 0x13

    if-ne v8, v11, :cond_24a

    :cond_249
    goto :goto_250

    :cond_24a
    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v9

    :goto_250
    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 380
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v7

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    new-instance v9, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda1;

    invoke-direct {v9, v8, v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V

    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 381
    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .registers 4
    .param p1, "p0"    # Landroid/view/ViewGroup;
    .param p2, "p1"    # I

    .line 316
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->onCreateViewHolder(Landroid/view/ViewGroup;I)Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    return-object v0
.end method

.method public onCreateViewHolder(Landroid/view/ViewGroup;I)Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;
    .registers 21
    .param p1, "parent"    # Landroid/view/ViewGroup;
    .param p2, "viewType"    # I

    const-string v0, "parent"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 320
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v3

    .line 321
    .local v3, "ctx":Landroid/content/Context;
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v0

    .local v2, "$this$onCreateViewHolder_u24lambda_u240\\1":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 322
    .local v4, "$i$a$-apply-PropertiesPanel$Adapter$onCreateViewHolder$row$1\\1\\321\\0":I
    const/4 v10, 0x0

    invoke-virtual {v2, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 323
    const/16 v5, 0x10

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 324
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/high16 v6, 0x41d80000    # 27.0f

    invoke-virtual {v5, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setMinimumHeight(I)V

    .line 325
    new-instance v5, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;

    const/4 v6, -0x1

    const/4 v11, -0x2

    invoke-direct {v5, v6, v11}, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;-><init>(II)V

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 326
    nop

    .line 321
    .end local v2    # "$this$onCreateViewHolder_u24lambda_u240\\1":Landroid/widget/LinearLayout;
    .end local v4    # "$i$a$-apply-PropertiesPanel$Adapter$onCreateViewHolder$row$1\\1\\321\\0":I
    move-object v14, v0

    .line 327
    .local v14, "row":Landroid/widget/LinearLayout;
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v6

    const/16 v8, 0x10

    const/4 v9, 0x0

    const-string v4, ""

    const/high16 v5, 0x41400000    # 12.0f

    const/4 v7, 0x0

    invoke-static/range {v2 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v15

    move-object v0, v15

    .line 385
    .local v0, "$this$onCreateViewHolder_u24lambda_u241\\2":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 327
    .local v2, "$i$a$-apply-PropertiesPanel$Adapter$onCreateViewHolder$name$1\\2\\327\\0":I
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v5, 0x41b00000    # 22.0f

    invoke-virtual {v4, v3, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x40800000    # 4.0f

    invoke-virtual {v5, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    invoke-virtual {v0, v4, v10, v5, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 328
    .end local v0    # "$this$onCreateViewHolder_u24lambda_u241\\2":Landroid/widget/TextView;
    .end local v2    # "$i$a$-apply-PropertiesPanel$Adapter$onCreateViewHolder$name$1\\2\\327\\0":I
    .local v15, "name":Landroid/widget/TextView;
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, v3}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 329
    .local v0, "sw":Landroid/view/View;
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v6

    const-string v4, ""

    const/high16 v5, 0x41400000    # 12.0f

    invoke-static/range {v2 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v17

    move-object/from16 v2, v17

    .line 385
    .local v2, "$this$onCreateViewHolder_u24lambda_u242\\3":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 329
    .local v4, "$i$a$-apply-PropertiesPanel$Adapter$onCreateViewHolder$value$1\\3\\329\\0":I
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-virtual {v5, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-virtual {v2, v5, v10, v7, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    sget-object v5, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 330
    .end local v2    # "$this$onCreateViewHolder_u24lambda_u242\\3":Landroid/widget/TextView;
    .end local v4    # "$i$a$-apply-PropertiesPanel$Adapter$onCreateViewHolder$value$1\\3\\329\\0":I
    .local v17, "value":Landroid/widget/TextView;
    move-object v2, v15

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const v5, 0x3ee66666    # 0.45f

    invoke-direct {v4, v10, v11, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v14, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 331
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v4, 0x1

    invoke-virtual {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->divider(Landroid/content/Context;Z)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v14, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 332
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v5, 0x41600000    # 14.0f

    invoke-virtual {v4, v3, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7, v3, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    invoke-direct {v2, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 385
    move-object v4, v2

    .local v4, "$this$onCreateViewHolder_u24lambda_u243\\4":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v5, 0x0

    .line 332
    .local v5, "$i$a$-apply-PropertiesPanel$Adapter$onCreateViewHolder$1\\4\\332\\0":I
    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    iput v6, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .end local v4    # "$this$onCreateViewHolder_u24lambda_u243\\4":Landroid/widget/LinearLayout$LayoutParams;
    .end local v5    # "$i$a$-apply-PropertiesPanel$Adapter$onCreateViewHolder$1\\4\\332\\0":I
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v14, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 333
    move-object/from16 v2, v17

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const v5, 0x3f0ccccd    # 0.55f

    invoke-direct {v4, v10, v11, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v14, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 334
    new-instance v12, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;

    move-object/from16 v2, p0

    iget-object v13, v2, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    move-object/from16 v16, v0

    .end local v0    # "sw":Landroid/view/View;
    .local v16, "sw":Landroid/view/View;
    invoke-direct/range {v12 .. v17}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;-><init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;)V

    return-object v12
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$Adapter$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$Adapter$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;"
    method = "onBindViewHolder$lambda$5"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->onBindViewHolder$lambda$5(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$Adapter$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$Adapter$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;"
    method = "onBindViewHolder$lambda$8"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda1;->f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter$$ExternalSyntheticLambda1;->f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Adapter;->onBindViewHolder$lambda$8(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel.Companion (com.exampletest.mobilestudiotest.ui.PropertiesPanel$Companion)
.class public final Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Companion;
.super Ljava/lang/Object;
.source "PropertiesPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0008\u0002\n\u0002\u0010\"\n\u0000\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\t0\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\u0008\u0012\u0004\u0012\u00020\t0\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Companion;",
        "",
        "<init>",
        "()V",
        "DEG",
        "",
        "RAD",
        "ORDER",
        "",
        "",
        "CATEGORY",
        "",
        "surfaceProps",
        "skip",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Companion;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel.Row (com.exampletest.mobilestudiotest.ui.PropertiesPanel$Row)
.class final Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;
.super Ljava/lang/Object;
.source "PropertiesPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Row"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u000f\u0008\u0002\u0018\u00002\u00020\u0001BM\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u0001\u0012\u0006\u0010\u0007\u001a\u00020\u0008\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0010\u0008\u0002\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\u000c\u00a2\u0006\u0004\u0008\u000e\u0010\u000fR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0011R\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0011R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0001\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0011\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0017R\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0018\u0010\u0019R\u0019\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\u000c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001a\u0010\u001b\u00a8\u0006\u001c"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;",
        "",
        "title",
        "",
        "prop",
        "display",
        "value",
        "type",
        "",
        "editable",
        "",
        "action",
        "Lkotlin/Function0;",
        "",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;)V",
        "getTitle",
        "()Ljava/lang/String;",
        "getProp",
        "getDisplay",
        "getValue",
        "()Ljava/lang/Object;",
        "getType",
        "()I",
        "getEditable",
        "()Z",
        "getAction",
        "()Lkotlin/jvm/functions/Function0;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final action:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final display:Ljava/lang/String;

.field private final editable:Z

.field private final prop:Ljava/lang/String;

.field private final title:Ljava/lang/String;

.field private final type:I

.field private final value:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;)V
    .registers 9
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "prop"    # Ljava/lang/String;
    .param p3, "display"    # Ljava/lang/String;
    .param p4, "value"    # Ljava/lang/Object;
    .param p5, "type"    # I
    .param p6, "editable"    # Z
    .param p7, "action"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "IZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "title"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "display"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->title:Ljava/lang/String;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->prop:Ljava/lang/String;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->display:Ljava/lang/String;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->value:Ljava/lang/Object;

    iput p5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->type:I

    iput-boolean p6, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->editable:Z

    iput-object p7, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->action:Lkotlin/jvm/functions/Function0;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 19

    .line 27
    and-int/lit8 v0, p8, 0x40

    if-eqz v0, :cond_7

    const/4 v0, 0x0

    move-object v8, v0

    goto :goto_9

    :cond_7
    move-object/from16 v8, p7

    :goto_9
    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move v6, p5

    move v7, p6

    invoke-direct/range {v1 .. v8}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;IZLkotlin/jvm/functions/Function0;)V

    return-void
.end method


# virtual methods
.method public final getAction()Lkotlin/jvm/functions/Function0;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 27
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->action:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getDisplay()Ljava/lang/String;
    .registers 2

    .line 27
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->display:Ljava/lang/String;

    return-object v0
.end method

.method public final getEditable()Z
    .registers 2

    .line 27
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->editable:Z

    return v0
.end method

.method public final getProp()Ljava/lang/String;
    .registers 2

    .line 27
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->prop:Ljava/lang/String;

    return-object v0
.end method

.method public final getTitle()Ljava/lang/String;
    .registers 2

    .line 27
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->title:Ljava/lang/String;

    return-object v0
.end method

.method public final getType()I
    .registers 2

    .line 27
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->type:I

    return v0
.end method

.method public final getValue()Ljava/lang/Object;
    .registers 2

    .line 27
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;->value:Ljava/lang/Object;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel.VH (com.exampletest.mobilestudiotest.ui.PropertiesPanel$VH)
.class final Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;
.super Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
.source "PropertiesPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "VH"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u000b\u0008\u0082\u0004\u0018\u00002\u00020\u0001B\'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R\u0011\u0010\u0008\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u000e\u00a8\u0006\u0012"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;",
        "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;",
        "row",
        "Landroid/widget/LinearLayout;",
        "name",
        "Landroid/widget/TextView;",
        "swatch",
        "Landroid/view/View;",
        "value",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;)V",
        "getRow",
        "()Landroid/widget/LinearLayout;",
        "getName",
        "()Landroid/widget/TextView;",
        "getSwatch",
        "()Landroid/view/View;",
        "getValue",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final name:Landroid/widget/TextView;

.field private final row:Landroid/widget/LinearLayout;

.field private final swatch:Landroid/view/View;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

.field private final value:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;)V
    .registers 7
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;
    .param p2, "row"    # Landroid/widget/LinearLayout;
    .param p3, "name"    # Landroid/widget/TextView;
    .param p4, "swatch"    # Landroid/view/View;
    .param p5, "value"    # Landroid/widget/TextView;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Landroid/widget/TextView;",
            "Landroid/view/View;",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation

    const-string v0, "row"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "swatch"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "value"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 314
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->this$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    move-object v0, p2

    check-cast v0, Landroid/view/View;

    invoke-direct {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->row:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->name:Landroid/widget/TextView;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->swatch:Landroid/view/View;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->value:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final getName()Landroid/widget/TextView;
    .registers 2

    .line 314
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->name:Landroid/widget/TextView;

    return-object v0
.end method

.method public final getRow()Landroid/widget/LinearLayout;
    .registers 2

    .line 314
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->row:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method public final getSwatch()Landroid/view/View;
    .registers 2

    .line 314
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->swatch:Landroid/view/View;

    return-object v0
.end method

.method public final getValue()Landroid/widget/TextView;
    .registers 2

    .line 314
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$VH;->value:Landroid/widget/TextView;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;"
    method = "edit$lambda$13"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Ljava/lang/Object;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->edit$lambda$13(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;Ljava/lang/Object;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;"
    method = "previewListener$lambda$1$lambda$0"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->previewListener$lambda$1$lambda$0(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;"
    method = "rebuild$lambda$9$lambda$4"
    proto = "(Ljava/lang/Long;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/lang/Long;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Long;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda2;->f$0:Ljava/lang/Long;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda2;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda2;->f$0:Ljava/lang/Long;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda2;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$lambda$4(Ljava/lang/Long;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;"
    method = "rebuild$lambda$9$lambda$6"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Ljava/lang/Comparable;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$lambda$6(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Ljava/lang/Comparable;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;"
    method = "rebuild$lambda$9$lambda$7"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Ljava/lang/Comparable;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild$lambda$9$lambda$7(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$Row;)Ljava/lang/Comparable;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;"
    method = "previewListener$lambda$1"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->previewListener$lambda$1(Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PropertiesPanel$rebuild$lambda$9$$inlined$sortedBy$1 (com.exampletest.mobilestudiotest.ui.PropertiesPanel$rebuild$lambda$9$$inlined$sortedBy$1)
.class public final Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel$rebuild$lambda$9$$inlined$sortedBy$1;
.super Ljava/lang/Object;
.source "Comparisons.kt"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/PropertiesPanel;->rebuild()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Comparator;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nComparisons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Comparisons.kt\nkotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2\n+ 2 PropertiesPanel.kt\ncom/exampletest/mobilestudiotest/ui/PropertiesPanel\n*L\n1#1,328:1\n226#2:329\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 9
    .param p1, "a"    # Ljava/lang/Object;
    .param p2, "b"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)I"
        }
    .end annotation

    .line 102
    move-object v0, p1

    check-cast v0, Ljava/util/Map$Entry;

    .local v0, "it\\1":Ljava/util/Map$Entry;
    const/4 v1, 0x0

    .line 329
    .local v1, "$i$a$-sortedBy-PropertiesPanel$rebuild$1$5\\1\\102\\0":I
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "toLowerCase(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    .end local v0    # "it\\1":Ljava/util/Map$Entry;
    .end local v1    # "$i$a$-sortedBy-PropertiesPanel$rebuild$1$5\\1\\102\\0":I
    check-cast v2, Ljava/lang/Comparable;

    move-object v0, p2

    check-cast v0, Ljava/util/Map$Entry;

    .local v0, "it\\2":Ljava/util/Map$Entry;
    const/4 v1, 0x0

    .line 329
    .local v1, "$i$a$-sortedBy-PropertiesPanel$rebuild$1$5\\2\\102\\0":I
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v4, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    .end local v0    # "it\\2":Ljava/util/Map$Entry;
    .end local v1    # "$i$a$-sortedBy-PropertiesPanel$rebuild$1$5\\2\\102\\0":I
    check-cast v4, Ljava/lang/Comparable;

    invoke-static {v2, v4}, Lkotlin/comparisons/ComparisonsKt;->compareValues(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    move-result v0

    return v0
.end method
