###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel (com.exampletest.mobilestudiotest.ui.ExplorerPanel)
.class public final Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
.super Landroid/widget/LinearLayout;
.source "ExplorerPanel.kt"

# interfaces
.implements Lcom/exampletest/mobilestudiotest/core/Studio$Listener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;,
        Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;,
        Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;,
        Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nExplorerPanel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ExplorerPanel.kt\ncom/exampletest/mobilestudiotest/ui/ExplorerPanel\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n*L\n1#1,330:1\n1#2:331\n1#2:395\n2746#3,3:332\n774#3:335\n865#3,2:336\n2746#3,3:338\n774#3:341\n865#3,2:342\n1056#3:344\n774#3:345\n865#3,2:346\n360#3,7:348\n360#3,7:355\n1563#3:362\n1634#3,3:363\n774#3:366\n865#3:367\n2746#3,3:368\n866#3:371\n2746#3,3:372\n1878#3,3:375\n1617#3,9:378\n1869#3:387\n1870#3:396\n1626#3:397\n320#4,7:388\n*S KotlinDebug\n*F\n+ 1 ExplorerPanel.kt\ncom/exampletest/mobilestudiotest/ui/ExplorerPanel\n*L\n242#1:395\n88#1:332,3\n89#1:335\n89#1:336,2\n135#1:338,3\n156#1:341\n156#1:342,2\n157#1:344\n160#1:345\n160#1:346,2\n197#1:348,7\n220#1:355,7\n222#1:362\n222#1:363,3\n223#1:366\n223#1:367\n223#1:368,3\n223#1:371\n233#1:372,3\n262#1:375,3\n242#1:378,9\n242#1:387\n242#1:396\n242#1:397\n242#1:388,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0090\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010#\n\u0000\n\u0002\u0010\"\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u001a\u0008\u0007\u0018\u00002\u00020\u00012\u00020\u0002:\u0004OPQRB\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0004\u0008\t\u0010\nJ\u001a\u0010-\u001a\u0004\u0018\u00010\u000c2\u0006\u0010.\u001a\u00020\u00112\u0006\u0010/\u001a\u00020\u0011H\u0002J\u0018\u00100\u001a\u0002012\u0006\u0010\"\u001a\u00020\u000e2\u0006\u00102\u001a\u00020\u000cH\u0002J\u0010\u00103\u001a\u00020\u00132\u0006\u00104\u001a\u000205H\u0002J\u001a\u00106\u001a\u00020\u00132\u0006\u00107\u001a\u00020\u00152\u0008\u00108\u001a\u0004\u0018\u000109H\u0002J\u0008\u0010:\u001a\u000201H\u0002J\u0006\u0010;\u001a\u000201J\u0008\u0010<\u001a\u000201H\u0002J\u0008\u0010=\u001a\u000201H\u0002J\u0016\u0010>\u001a\u0008\u0012\u0004\u0012\u00020\u00150\u001b2\u0006\u0010?\u001a\u00020\u0015H\u0002J\u0006\u0010@\u001a\u000201J\u0008\u0010A\u001a\u000201H\u0002J\u0008\u0010B\u001a\u000201H\u0016J\u0008\u0010C\u001a\u000201H\u0016J\u0008\u0010D\u001a\u000201H\u0016J\u0008\u0010E\u001a\u000201H\u0016J\u0010\u0010F\u001a\u0002012\u0006\u00102\u001a\u00020\u000cH\u0002J\u0010\u0010G\u001a\u0002012\u0006\u00102\u001a\u00020\u000cH\u0002J\u0010\u0010H\u001a\u0002012\u0006\u00102\u001a\u00020\u000cH\u0002J\u0018\u0010I\u001a\u0002012\u0006\u0010J\u001a\u00020\u000e2\u0006\u00102\u001a\u00020\u000cH\u0002J\u0010\u0010K\u001a\u0002012\u0006\u0010?\u001a\u00020\u0015H\u0002J\u0010\u0010L\u001a\u0002012\u0006\u0010?\u001a\u00020\u0015H\u0002J\u0010\u0010M\u001a\u0002012\u0008\u0010N\u001a\u0004\u0018\u00010\u0015R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\u000cX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u000f\u001a\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u0016\u001a&\u0012\u000c\u0012\n \u0018*\u0004\u0018\u00010\u00150\u0015 \u0018*\u0012\u0012\u000c\u0012\n \u0018*\u0004\u0018\u00010\u00150\u0015\u0018\u00010\u00190\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001a\u001a\u0008\u0012\u0004\u0012\u00020\u000c0\u001bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001e\u001a\u00060\u001fR\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R$\u0010#\u001a\u00020\u00132\u0006\u0010\"\u001a\u00020\u00138F@FX\u0086\u000e\u00a2\u0006\u000c\u001a\u0004\u0008$\u0010%\"\u0004\u0008&\u0010\'R\u000e\u0010(\u001a\u00020)X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010*\u001a\u0010\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020+\u0018\u00010\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010,\u001a\u0004\u0018\u00010\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006S"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;",
        "Landroid/widget/LinearLayout;",
        "Lcom/exampletest/mobilestudiotest/core/Studio$Listener;",
        "ctx",
        "Landroid/content/Context;",
        "studio",
        "Lcom/exampletest/mobilestudiotest/core/Studio;",
        "actions",
        "Lcom/exampletest/mobilestudiotest/ui/MainActions;",
        "<init>",
        "(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/ui/MainActions;)V",
        "dragRow",
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;",
        "dragAnchor",
        "Landroid/view/View;",
        "dragStart",
        "Lkotlin/Pair;",
        "",
        "dragMoved",
        "",
        "dropTarget",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "expanded",
        "",
        "kotlin.jvm.PlatformType",
        "",
        "rows",
        "",
        "list",
        "Landroidx/recyclerview/widget/RecyclerView;",
        "adapter",
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;",
        "filter",
        "",
        "v",
        "multiSelect",
        "getMultiSelect",
        "()Z",
        "setMultiSelect",
        "(Z)V",
        "multiBtn",
        "Landroid/widget/ImageView;",
        "lastClick",
        "",
        "rangeAnchor",
        "rowAt",
        "x",
        "y",
        "startDrag",
        "",
        "r",
        "onDrag",
        "e",
        "Landroid/view/DragEvent;",
        "canDropInto",
        "target",
        "payload",
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;",
        "updateMultiBtn",
        "refreshIcons",
        "expandDefaults",
        "collapseAll",
        "visibleChildren",
        "i",
        "rebuild",
        "revealSelection",
        "onTreeChanged",
        "onSelectionChanged",
        "onModelReplaced",
        "onToolChanged",
        "onRowClick",
        "selectRange",
        "toggleExpand",
        "showContextMenu",
        "anchor",
        "expandAll",
        "rename",
        "showInsertDialog",
        "parent",
        "Row",
        "DragPayload",
        "VH",
        "Adapter",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final actions:Lcom/exampletest/mobilestudiotest/ui/MainActions;

.field private final adapter:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

.field private dragAnchor:Landroid/view/View;

.field private dragMoved:Z

.field private dragRow:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

.field private dragStart:Lkotlin/Pair;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Pair<",
            "Ljava/lang/Float;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field private dropTarget:Lcom/exampletest/mobilestudiotest/model/Instance;

.field private final expanded:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation
.end field

.field private filter:Ljava/lang/String;

.field private lastClick:Lkotlin/Pair;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Pair<",
            "+",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private final list:Landroidx/recyclerview/widget/RecyclerView;

.field private final multiBtn:Landroid/widget/ImageView;

.field private rangeAnchor:Lcom/exampletest/mobilestudiotest/model/Instance;

.field private rows:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;",
            ">;"
        }
    .end annotation
.end field

.field private final studio:Lcom/exampletest/mobilestudiotest/core/Studio;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/ui/MainActions;)V
    .registers 15
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;
    .param p3, "actions"    # Lcom/exampletest/mobilestudiotest/ui/MainActions;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "studio"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "actions"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->actions:Lcom/exampletest/mobilestudiotest/ui/MainActions;

    .line 36
    new-instance v0, Ljava/util/IdentityHashMap;

    invoke-direct {v0}, Ljava/util/IdentityHashMap;-><init>()V

    check-cast v0, Ljava/util/Map;

    invoke-static {v0}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    .line 37
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rows:Ljava/util/List;

    .line 38
    new-instance v0, Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {v0, p1}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    .line 39
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

    .line 40
    const-string v0, ""

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->filter:Ljava/lang/String;

    .line 50
    nop

    .line 51
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->setOrientation(I)V

    .line 52
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getPANEL()I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->setBackgroundColor(I)V

    .line 53
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v3, "Explorer"

    const/4 v4, 0x0

    move-object v2, p1

    .end local p1    # "ctx":Landroid/content/Context;
    .local v2, "ctx":Landroid/content/Context;
    invoke-static/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general$default(Lcom/exampletest/mobilestudiotest/ui/Icons;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const-string v1, "Explorer"

    invoke-virtual {v0, v2, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->header(Landroid/content/Context;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)Landroid/widget/LinearLayout;

    move-result-object p1

    .line 54
    .local p1, "h":Landroid/widget/LinearLayout;
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const-string v3, "SelectAll"

    const-string v4, "Multi"

    invoke-virtual {v0, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda3;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda3;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/ImageView;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->multiBtn:Landroid/widget/ImageView;

    .line 58
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->multiBtn:Landroid/widget/ImageView;

    check-cast v0, Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 59
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const-string v3, "InsertObject"

    const-string v4, "+"

    invoke-virtual {v0, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda4;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const/4 v4, 0x0

    invoke-static/range {v1 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/ImageView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 60
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const-string v3, "CollapseAll"

    const-string v4, "Col"

    invoke-virtual {v0, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda5;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda5;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const/4 v4, 0x0

    invoke-static/range {v1 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/ImageView;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 61
    move-object v0, p1

    check-cast v0, Landroid/view/View;

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 62
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/16 v7, 0x18

    const-string v3, ""

    const-string v4, "Filter workspace (name or class)"

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->input$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZILjava/lang/Object;)Landroid/widget/EditText;

    move-result-object v0

    .line 63
    .local v0, "search":Landroid/widget/EditText;
    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setTextSize(F)V

    .line 64
    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$4;

    invoke-direct {v1, p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$4;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    check-cast v1, Landroid/text/TextWatcher;

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 69
    move-object v1, v0

    check-cast v1, Landroid/view/View;

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v7, 0x4

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    .line 331
    move-object v4, v3

    .local v4, "$this$_init__u24lambda_u243\\1":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v5, 0x0

    .line 69
    .local v5, "$i$a$-apply-ExplorerPanel$5\\1\\69\\0":I
    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v7, 0x40800000    # 4.0f

    invoke-virtual {v6, v2, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    sget-object v8, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v8, v2, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v9, v2, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v9

    sget-object v10, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v10, v2, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    invoke-virtual {v4, v6, v8, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .end local v4    # "$this$_init__u24lambda_u243\\1":Landroid/widget/LinearLayout$LayoutParams;
    .end local v5    # "$i$a$-apply-ExplorerPanel$5\\1\\69\\0":I
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v1, v3}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 70
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v3, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v3, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    check-cast v3, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 71
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

    check-cast v3, Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 72
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    .line 73
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    check-cast v1, Landroid/view/View;

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v4, 0x0

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v6, -0x1

    invoke-virtual {v3, v6, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v1, v3}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 74
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda6;

    invoke-direct {v3, p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    .line 75
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expandDefaults()V

    .line 76
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild()V

    .line 77
    .end local v0    # "search":Landroid/widget/EditText;
    .end local p1    # "h":Landroid/widget/LinearLayout;
    nop

    .line 24
    return-void
.end method

.method static final _init_$lambda$0(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getMultiSelect()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->setMultiSelect(Z)V

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->updateMultiBtn()V

    .line 56
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getMultiSelect()Z

    move-result v1

    if-eqz v1, :cond_1c

    const-string v1, "Multi-select on: tap objects to add or remove them"

    goto :goto_1e

    :cond_1c
    const-string v1, "Multi-select off"

    :goto_1e
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->toast(Ljava/lang/String;)Z

    .line 57
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$1(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showInsertDialog(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$2(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->collapseAll()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$4(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;Landroid/view/DragEvent;)Z
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p2, "e"    # Landroid/view/DragEvent;

    .line 74
    invoke-static {p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {p0, p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->onDrag(Landroid/view/DragEvent;)Z

    move-result p1

    return p1
.end method

.method public static final synthetic access$getDropTarget$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 23
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dropTarget:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-object v0
.end method

.method public static final synthetic access$getRows$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Ljava/util/List;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 23
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rows:Ljava/util/List;

    return-object v0
.end method

.method public static final synthetic access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lcom/exampletest/mobilestudiotest/core/Studio;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 23
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    return-object v0
.end method

.method public static final synthetic access$onRowClick(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 23
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->onRowClick(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    return-void
.end method

.method public static final synthetic access$setFilter$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Ljava/lang/String;)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 23
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->filter:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$startDrag(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 3
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "v"    # Landroid/view/View;
    .param p2, "r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 23
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->startDrag(Landroid/view/View;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    return-void
.end method

.method public static final synthetic access$toggleExpand(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 23
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->toggleExpand(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    return-void
.end method

.method private final canDropInto(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;)Z
    .registers 13
    .param p1, "target"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "payload"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;

    .line 134
    const/4 v0, 0x0

    if-eqz p2, :cond_3f

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;->getItems()Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_3f

    .line 135
    .local v1, "items":Ljava/util/List;
    move-object v2, v1

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$none\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 338
    .local v3, "$i$f$none\\1\\135":I
    instance-of v4, v2, Ljava/util/Collection;

    const/4 v5, 0x1

    if-eqz v4, :cond_1d

    move-object v4, v2

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_1d

    move v0, v5

    goto :goto_3e

    .line 339
    :cond_1d
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_21
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3d

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\1":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 135
    .local v8, "$i$a$-none-ExplorerPanel$canDropInto$1\\2\\339\\0":I
    if-eq v7, p1, :cond_39

    invoke-virtual {p1, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v9

    if-nez v9, :cond_39

    move v7, v0

    goto :goto_3a

    :cond_39
    move v7, v5

    .line 339
    .end local v7    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-none-ExplorerPanel$canDropInto$1\\2\\339\\0":I
    :goto_3a
    if-eqz v7, :cond_21

    goto :goto_3e

    .line 340
    .end local v6    # "element\\1":Ljava/lang/Object;
    :cond_3d
    move v0, v5

    .line 135
    .end local v2    # "$this$none\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$none\\1\\135":I
    :goto_3e
    return v0

    .line 134
    .end local v1    # "items":Ljava/util/List;
    :cond_3f
    return v0
.end method

.method private final collapseAll()V
    .registers 2

    .line 151
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild()V

    return-void
.end method

.method private final expandAll(Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 8
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 268
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    const/4 v1, 0x0

    .line 269
    .local v1, "$i$a$-synchronized-ExplorerPanel$expandAll$1\\1\\268\\0":I
    :try_start_8
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-interface {v2, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 270
    const/4 v2, 0x0

    .line 271
    .local v2, "n\\1":I
    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1, v4, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_18
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3b

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v4, "d\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v5

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_18

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-interface {v5, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    const/16 v5, 0x1f4

    if-le v2, v5, :cond_18

    .line 272
    .end local v4    # "d\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_3b
    nop

    .end local v1    # "$i$a$-synchronized-ExplorerPanel$expandAll$1\\1\\268\\0":I
    .end local v2    # "n\\1":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3e
    .catchall {:try_start_8 .. :try_end_3e} :catchall_43

    .line 268
    monitor-exit v0

    .line 273
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild()V

    .line 274
    return-void

    .line 268
    :catchall_43
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private final expandDefaults()V
    .registers 6

    .line 147
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    .line 148
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 331
    const/4 v1, 0x0

    .line 148
    .local v1, "$i$a$-synchronized-ExplorerPanel$expandDefaults$1\\1\\148\\0":I
    :try_start_d
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v2

    const-string v3, "Workspace"

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    if-eqz v2, :cond_25

    .line 331
    .local v2, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v3, 0x0

    .line 148
    .local v3, "$i$a$-let-ExplorerPanel$expandDefaults$1$1\\2\\148\\1":I
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-interface {v4, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v4

    .end local v2    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v3    # "$i$a$-let-ExplorerPanel$expandDefaults$1$1\\2\\148\\1":I
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    :try_end_25
    .catchall {:try_start_d .. :try_end_25} :catchall_27

    .end local v1    # "$i$a$-synchronized-ExplorerPanel$expandDefaults$1\\1\\148\\0":I
    :cond_25
    monitor-exit v0

    .line 149
    return-void

    .line 148
    :catchall_27
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private final onDrag(Landroid/view/DragEvent;)Z
    .registers 11
    .param p1, "e"    # Landroid/view/DragEvent;

    .line 99
    invoke-virtual {p1}, Landroid/view/DragEvent;->getLocalState()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;

    const/4 v2, 0x0

    if-eqz v1, :cond_c

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;

    goto :goto_d

    :cond_c
    move-object v0, v2

    .line 100
    .local v0, "payload":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;
    :goto_d
    invoke-virtual {p1}, Landroid/view/DragEvent;->getAction()I

    move-result v1

    const/4 v3, 0x0

    const/4 v4, 0x1

    packed-switch v1, :pswitch_data_152

    :pswitch_16
    goto/16 :goto_151

    .line 109
    :pswitch_18
    iput-boolean v4, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragMoved:Z

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dropTarget:Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v1, :cond_151

    iput-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dropTarget:Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->notifyDataSetChanged()V

    goto/16 :goto_151

    .line 124
    :pswitch_27
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dropTarget:Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v1, :cond_32

    iput-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dropTarget:Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->notifyDataSetChanged()V

    .line 125
    :cond_32
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragRow:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .local v1, "r":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragAnchor:Landroid/view/View;

    .line 126
    .local v3, "a":Landroid/view/View;
    iget-boolean v5, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragMoved:Z

    if-nez v5, :cond_4d

    invoke-virtual {p1}, Landroid/view/DragEvent;->getResult()Z

    move-result v5

    if-nez v5, :cond_4d

    if-eqz v1, :cond_4d

    if-eqz v3, :cond_4d

    invoke-virtual {v3}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v5

    if-eqz v5, :cond_4d

    invoke-direct {p0, v3, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu(Landroid/view/View;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    .line 127
    :cond_4d
    iput-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragRow:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    iput-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragAnchor:Landroid/view/View;

    goto/16 :goto_151

    .line 111
    .end local v1    # "r":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .end local v3    # "a":Landroid/view/View;
    :pswitch_53
    iget-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragMoved:Z

    if-eqz v1, :cond_cc

    if-eqz v0, :cond_cc

    .line 112
    invoke-virtual {p1}, Landroid/view/DragEvent;->getX()F

    move-result v1

    invoke-virtual {p1}, Landroid/view/DragEvent;->getY()F

    move-result v2

    invoke-direct {p0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rowAt(FF)Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    move-result-object v1

    if-eqz v1, :cond_cb

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-eqz v1, :cond_cb

    .line 113
    .local v1, "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-direct {p0, v1, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->canDropInto(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;)Z

    move-result v2

    if-nez v2, :cond_74

    return v3

    .line 114
    :cond_74
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    const/4 v3, 0x0

    .line 115
    .local v3, "$i$a$-synchronized-ExplorerPanel$onDrag$1\\2\\114\\0":I
    :try_start_7c
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v5

    const-string v6, "Reparent"

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->begin(Ljava/lang/String;)V

    .line 116
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;->getItems()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_8f
    :goto_8f
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_af

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v6, "i\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    if-eq v6, v1, :cond_8f

    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v7

    if-nez v7, :cond_8f

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    if-eq v7, v1, :cond_8f

    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v7, v6, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->reparent(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v6    # "i\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_8f

    .line 117
    :cond_af
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->commit()V

    .line 118
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-interface {v5, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_bd
    .catchall {:try_start_7c .. :try_end_bd} :catchall_c8

    .line 114
    .end local v3    # "$i$a$-synchronized-ExplorerPanel$onDrag$1\\2\\114\\0":I
    monitor-exit v2

    .line 120
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;->getItems()Ljava/util/List;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    .line 121
    return v4

    .line 114
    :catchall_c8
    move-exception v3

    monitor-exit v2

    throw v3

    .line 112
    .end local v1    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_cb
    return v3

    .line 111
    :cond_cc
    return v3

    .line 103
    :pswitch_cd
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragStart:Lkotlin/Pair;

    .line 104
    .local v1, "s":Lkotlin/Pair;
    if-nez v1, :cond_e8

    invoke-virtual {p1}, Landroid/view/DragEvent;->getX()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    invoke-virtual {p1}, Landroid/view/DragEvent;->getY()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-static {v3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    iput-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragStart:Lkotlin/Pair;

    goto :goto_120

    .line 105
    :cond_e8
    invoke-virtual {p1}, Landroid/view/DragEvent;->getX()F

    move-result v3

    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    move-result v5

    sub-float/2addr v3, v5

    float-to-double v5, v3

    invoke-virtual {p1}, Landroid/view/DragEvent;->getY()F

    move-result v3

    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F

    move-result v7

    sub-float/2addr v3, v7

    float-to-double v7, v3

    invoke-static {v5, v6, v7, v8}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v5

    double-to-float v3, v5

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    iget v5, v5, Landroid/util/DisplayMetrics;->density:F

    const/high16 v6, 0x41b00000    # 22.0f

    mul-float/2addr v5, v6

    cmpl-float v3, v3, v5

    if-lez v3, :cond_120

    iput-boolean v4, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragMoved:Z

    .line 106
    :cond_120
    :goto_120
    iget-boolean v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragMoved:Z

    if-eqz v3, :cond_141

    invoke-virtual {p1}, Landroid/view/DragEvent;->getX()F

    move-result v3

    invoke-virtual {p1}, Landroid/view/DragEvent;->getY()F

    move-result v5

    invoke-direct {p0, v3, v5}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rowAt(FF)Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    move-result-object v3

    if-eqz v3, :cond_141

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    if-eqz v3, :cond_141

    move-object v5, v3

    .line 331
    .local v5, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v6, 0x0

    .line 106
    .local v6, "$i$a$-takeIf-ExplorerPanel$onDrag$t$1\\1\\106\\0":I
    invoke-direct {p0, v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->canDropInto(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;)Z

    move-result v5

    .end local v5    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v6    # "$i$a$-takeIf-ExplorerPanel$onDrag$t$1\\1\\106\\0":I
    if-eqz v5, :cond_141

    move-object v2, v3

    .line 107
    .local v2, "t":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_141
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dropTarget:Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eq v2, v3, :cond_151

    iput-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dropTarget:Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->notifyDataSetChanged()V

    .end local v1    # "s":Lkotlin/Pair;
    .end local v2    # "t":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_151

    .line 101
    :pswitch_14d
    if-eqz v0, :cond_150

    move v3, v4

    :cond_150
    return v3

    .line 130
    :cond_151
    :goto_151
    return v4

    :pswitch_data_152
    .packed-switch 0x1
        :pswitch_14d
        :pswitch_cd
        :pswitch_53
        :pswitch_27
        :pswitch_16
        :pswitch_18
    .end packed-switch
.end method

.method private final onRowClick(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 9
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 207
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 208
    .local v0, "now":J
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->lastClick:Lkotlin/Pair;

    .line 209
    .local v2, "lc":Lkotlin/Pair;
    if-eqz v2, :cond_3d

    invoke-virtual {v2}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    if-ne v3, v4, :cond_3d

    invoke-virtual {v2}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    sub-long v3, v0, v3

    const-wide/16 v5, 0x15e

    cmp-long v3, v3, v5

    if-gez v3, :cond_3d

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    const-string v4, "LuaSourceContainer"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3d

    .line 210
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->openScript(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const/4 v3, 0x0

    iput-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->lastClick:Lkotlin/Pair;

    return-void

    .line 212
    :cond_3d
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    iput-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->lastClick:Lkotlin/Pair;

    .line 213
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getMultiSelect()Z

    move-result v3

    if-nez v3, :cond_67

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModifierHeld()Z

    move-result v3

    if-nez v3, :cond_67

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    goto :goto_70

    :cond_67
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->toggleSelect(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 214
    :goto_70
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    iput-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rangeAnchor:Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 215
    return-void
.end method

.method private static final rebuild$lambda$19$walk(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Ljava/util/ArrayList;Lcom/exampletest/mobilestudiotest/model/Instance;I)V
    .registers 12
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "out"    # Ljava/util/ArrayList;
    .param p2, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p3, "depth"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;",
            ">;",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "I)V"
        }
    .end annotation

    .line 177
    invoke-direct {p0, p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->visibleChildren(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3f

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 178
    .local v3, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-interface {v1, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    .line 179
    .local v6, "open":Z
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    invoke-direct {p0, v3}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->visibleChildren(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    xor-int/lit8 v5, v1, 0x1

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v7

    move v4, p3

    .end local p3    # "depth":I
    .local v4, "depth":I
    invoke-direct/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;IZZLjava/lang/String;)V

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 180
    if-eqz v6, :cond_3d

    add-int/lit8 p3, v4, 0x1

    invoke-static {p0, p1, v3, p3}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild$lambda$19$walk(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Ljava/util/ArrayList;Lcom/exampletest/mobilestudiotest/model/Instance;I)V

    move p3, v4

    .end local v3    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v6    # "open":Z
    goto :goto_8

    .restart local v3    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v6    # "open":Z
    :cond_3d
    move p3, v4

    goto :goto_8

    .line 182
    .end local v3    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v4    # "depth":I
    .end local v6    # "open":Z
    .restart local p3    # "depth":I
    :cond_3f
    return-void
.end method

.method private final rename(Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 11
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 277
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v8, "getContext(...)"

    invoke-static {v1, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    const/16 v6, 0x1c

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->input$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZILjava/lang/Object;)Landroid/widget/EditText;

    move-result-object v0

    .line 278
    .local v0, "e":Landroid/widget/EditText;
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Dialogs;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->themed(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const-string v2, "Rename"

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    move-object v2, v0

    check-cast v2, Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 279
    const-string v2, "OK"

    check-cast v2, Ljava/lang/CharSequence;

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;

    invoke-direct {v3, p0, p1, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/widget/EditText;)V

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 280
    const-string v2, "Cancel"

    check-cast v2, Ljava/lang/CharSequence;

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 281
    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    invoke-virtual {v0}, Landroid/widget/EditText;->selectAll()V

    .line 282
    return-void
.end method

.method static final rename$lambda$52(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/widget/EditText;Landroid/content/DialogInterface;I)V
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$i"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "$e"    # Landroid/widget/EditText;

    .line 279
    iget-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p4

    const-string v0, "Name"

    invoke-virtual {p3, p1, v0, p4}, Lcom/exampletest/mobilestudiotest/core/Studio;->setProp(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    return-void
.end method

.method private final revealSelection()V
    .registers 10

    .line 191
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v0, :cond_11

    return-void

    .line 192
    .local v0, "first":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_11
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    const/4 v2, 0x0

    .line 193
    .local v2, "$i$a$-synchronized-ExplorerPanel$revealSelection$1\\1\\192\\0":I
    :try_start_19
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    .line 194
    .local v3, "p\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_1d
    if-eqz v3, :cond_2e

    instance-of v4, v3, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-nez v4, :cond_2e

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-interface {v4, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    move-object v3, v4

    goto :goto_1d

    .line 195
    :cond_2e
    nop

    .end local v2    # "$i$a$-synchronized-ExplorerPanel$revealSelection$1\\1\\192\\0":I
    .end local v3    # "p\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_31
    .catchall {:try_start_19 .. :try_end_31} :catchall_82

    .line 192
    monitor-exit v1

    .line 196
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild()V

    .line 197
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rows:Ljava/util/List;

    .local v1, "$this$indexOfFirst\\2":Ljava/util/List;
    const/4 v2, 0x0

    .line 348
    .local v2, "$i$f$indexOfFirst\\2\\197":I
    const/4 v3, 0x0

    .line 349
    .local v3, "index\\2":I
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_3d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_5b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .line 350
    .local v5, "item\\2":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .local v6, "it\\3":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    const/4 v7, 0x0

    .line 197
    .local v7, "$i$a$-indexOfFirst-ExplorerPanel$revealSelection$idx$1\\3\\350\\0":I
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v8

    if-ne v8, v0, :cond_53

    const/4 v8, 0x1

    goto :goto_54

    :cond_53
    const/4 v8, 0x0

    .line 350
    .end local v6    # "it\\3":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .end local v7    # "$i$a$-indexOfFirst-ExplorerPanel$revealSelection$idx$1\\3\\350\\0":I
    :goto_54
    if-eqz v8, :cond_57

    .line 351
    goto :goto_5d

    .line 352
    :cond_57
    nop

    .end local v5    # "item\\2":Ljava/lang/Object;
    add-int/lit8 v3, v3, 0x1

    goto :goto_3d

    .line 354
    :cond_5b
    const/4 v4, -0x1

    move v3, v4

    .line 197
    .end local v1    # "$this$indexOfFirst\\2":Ljava/util/List;
    .end local v2    # "$i$f$indexOfFirst\\2\\197":I
    .end local v3    # "index\\2":I
    :goto_5d
    nop

    .line 198
    .local v3, "idx":I
    if-ltz v3, :cond_81

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type androidx.recyclerview.widget.LinearLayoutManager"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Landroidx/recyclerview/widget/LinearLayoutManager;

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getContext()Landroid/content/Context;

    move-result-object v4

    const-string v5, "getContext(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v5, 0x42700000    # 60.0f

    invoke-virtual {v2, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-virtual {v1, v3, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->scrollToPositionWithOffset(II)V

    .line 199
    :cond_81
    return-void

    .line 192
    .end local v3    # "idx":I
    :catchall_82
    move-exception v2

    monitor-exit v1

    throw v2
.end method

.method private final rowAt(FF)Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .registers 6
    .param p1, "x"    # F
    .param p2, "y"    # F

    .line 82
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->findChildViewUnder(FF)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_a

    const/4 v0, 0x0

    return-object v0

    .line 83
    .local v0, "v":Landroid/view/View;
    :cond_a
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result v1

    .line 84
    .local v1, "pos":I
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rows:Ljava/util/List;

    invoke-static {v2, v1}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    return-object v2
.end method

.method private final selectRange(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 24
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 219
    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rangeAnchor:Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v1, :cond_18

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 331
    .local v1, "$this$selectRange_u24lambda_u2422\\1":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    const/4 v2, 0x0

    .line 219
    .local v2, "$i$a$-run-ExplorerPanel$selectRange$a$1\\1\\219\\0":I
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    return-void

    .line 220
    .end local v2    # "$i$a$-run-ExplorerPanel$selectRange$a$1\\1\\219\\0":I
    .local v1, "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_18
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rows:Ljava/util/List;

    .local v2, "$this$indexOfFirst\\2":Ljava/util/List;
    const/4 v3, 0x0

    .line 355
    .local v3, "$i$f$indexOfFirst\\2\\220":I
    const/4 v4, 0x0

    .line 356
    .local v4, "index\\2":I
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_20
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v7, -0x1

    const/4 v9, 0x1

    if-eqz v6, :cond_40

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 357
    .local v6, "item\\2":Ljava/lang/Object;
    move-object v10, v6

    check-cast v10, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .local v10, "it\\3":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    const/4 v11, 0x0

    .line 220
    .local v11, "$i$a$-indexOfFirst-ExplorerPanel$selectRange$i0$1\\3\\357\\0":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v12

    if-ne v12, v1, :cond_38

    move v10, v9

    goto :goto_39

    :cond_38
    const/4 v10, 0x0

    .line 357
    .end local v10    # "it\\3":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .end local v11    # "$i$a$-indexOfFirst-ExplorerPanel$selectRange$i0$1\\3\\357\\0":I
    :goto_39
    if-eqz v10, :cond_3c

    .line 358
    goto :goto_41

    .line 359
    :cond_3c
    nop

    .end local v6    # "item\\2":Ljava/lang/Object;
    add-int/lit8 v4, v4, 0x1

    goto :goto_20

    .line 361
    :cond_40
    move v4, v7

    .line 220
    .end local v2    # "$this$indexOfFirst\\2":Ljava/util/List;
    .end local v3    # "$i$f$indexOfFirst\\2\\220":I
    .end local v4    # "index\\2":I
    :goto_41
    nop

    .local v4, "i0":I
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rows:Ljava/util/List;

    .local v2, "$this$indexOfFirst\\4":Ljava/util/List;
    const/4 v3, 0x0

    .line 355
    .local v3, "$i$f$indexOfFirst\\4\\220":I
    const/4 v5, 0x0

    .line 356
    .local v5, "index\\4":I
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_4a
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_6d

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .line 357
    .local v10, "item\\4":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .local v11, "it\\5":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    const/4 v12, 0x0

    .line 220
    .local v12, "$i$a$-indexOfFirst-ExplorerPanel$selectRange$i1$1\\5\\357\\0":I
    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v13

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v14

    if-ne v13, v14, :cond_64

    move v11, v9

    goto :goto_65

    :cond_64
    const/4 v11, 0x0

    .line 357
    .end local v11    # "it\\5":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .end local v12    # "$i$a$-indexOfFirst-ExplorerPanel$selectRange$i1$1\\5\\357\\0":I
    :goto_65
    if-eqz v11, :cond_69

    .line 358
    move v7, v5

    goto :goto_6e

    .line 359
    :cond_69
    nop

    .end local v10    # "item\\4":Ljava/lang/Object;
    add-int/lit8 v5, v5, 0x1

    goto :goto_4a

    .line 361
    :cond_6d
    nop

    .line 220
    .end local v2    # "$this$indexOfFirst\\4":Ljava/util/List;
    .end local v3    # "$i$f$indexOfFirst\\4\\220":I
    .end local v5    # "index\\4":I
    :goto_6e
    nop

    .line 221
    .local v7, "i1":I
    if-ltz v4, :cond_149

    if-gez v7, :cond_77

    move-object/from16 v18, v1

    goto/16 :goto_14b

    .line 222
    :cond_77
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rows:Ljava/util/List;

    invoke-static {v4, v7}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v4, v7}, Ljava/lang/Math;->max(II)I

    move-result v5

    add-int/2addr v5, v9

    invoke-interface {v2, v3, v5}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\6":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 362
    .local v3, "$i$f$map\\6\\222":I
    new-instance v5, Ljava/util/ArrayList;

    const/16 v6, 0xa

    invoke-static {v2, v6}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v6

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\7":Ljava/util/Collection;
    move-object v6, v2

    .local v6, "$this$mapTo\\7":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 363
    .local v10, "$i$f$mapTo\\7\\362":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_9c
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_b2

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .line 364
    .local v12, "item\\7":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .local v13, "it\\8":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    const/4 v14, 0x0

    .line 222
    .local v14, "$i$a$-map-ExplorerPanel$selectRange$range$1\\8\\364\\0":I
    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v13

    .line 364
    .end local v13    # "it\\8":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .end local v14    # "$i$a$-map-ExplorerPanel$selectRange$range$1\\8\\364\\0":I
    invoke-interface {v5, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_9c

    .line 365
    .end local v12    # "item\\7":Ljava/lang/Object;
    :cond_b2
    nop

    .end local v5    # "destination\\7":Ljava/util/Collection;
    .end local v6    # "$this$mapTo\\7":Ljava/lang/Iterable;
    .end local v10    # "$i$f$mapTo\\7\\362":I
    check-cast v5, Ljava/util/List;

    .line 362
    nop

    .line 222
    .end local v2    # "$this$map\\6":Ljava/lang/Iterable;
    .end local v3    # "$i$f$map\\6\\222":I
    nop

    .line 223
    .local v5, "range":Ljava/util/List;
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getMultiSelect()Z

    move-result v3

    if-eqz v3, :cond_142

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/util/Collection;

    move-object v6, v5

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$filter\\9":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 366
    .local v10, "$i$f$filter\\9\\223":I
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    check-cast v11, Ljava/util/Collection;

    .local v11, "destination\\10":Ljava/util/Collection;
    move-object v12, v6

    .local v12, "$this$filterTo\\10":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 367
    .local v13, "$i$f$filterTo\\10\\366":I
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_de
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_135

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    .local v15, "element\\10":Ljava/lang/Object;
    move-object v8, v15

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "n\\11":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v16, 0x0

    .line 223
    .local v16, "$i$a$-filter-ExplorerPanel$selectRange$1\\11\\367\\0":I
    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v9

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$none\\12":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 368
    .local v17, "$i$f$none\\12\\223":I
    move-object/from16 v18, v1

    .end local v1    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v18, "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    instance-of v1, v9, Ljava/util/Collection;

    if-eqz v1, :cond_108

    move-object v1, v9

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_108

    const/4 v1, 0x1

    goto :goto_12b

    .line 369
    :cond_108
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_10c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v19

    if-eqz v19, :cond_12a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    move-object/from16 v20, v1

    .local v19, "element\\12":Ljava/lang/Object;
    move-object/from16 v1, v19

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v1, "it\\13":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v21, 0x0

    .line 223
    .local v21, "$i$a$-none-ExplorerPanel$selectRange$1$1\\13\\369\\11":I
    if-ne v1, v8, :cond_122

    const/4 v1, 0x1

    goto :goto_123

    :cond_122
    const/4 v1, 0x0

    .line 369
    .end local v1    # "it\\13":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v21    # "$i$a$-none-ExplorerPanel$selectRange$1$1\\13\\369\\11":I
    :goto_123
    if-eqz v1, :cond_127

    const/4 v1, 0x0

    goto :goto_12b

    :cond_127
    move-object/from16 v1, v20

    goto :goto_10c

    .line 370
    .end local v19    # "element\\12":Ljava/lang/Object;
    :cond_12a
    const/4 v1, 0x1

    .line 223
    .end local v9    # "$this$none\\12":Ljava/lang/Iterable;
    .end local v17    # "$i$f$none\\12\\223":I
    :goto_12b
    nop

    .line 367
    .end local v8    # "n\\11":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v16    # "$i$a$-filter-ExplorerPanel$selectRange$1\\11\\367\\0":I
    if-eqz v1, :cond_131

    invoke-interface {v11, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_131
    move-object/from16 v1, v18

    const/4 v9, 0x1

    goto :goto_de

    .line 371
    .end local v15    # "element\\10":Ljava/lang/Object;
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v1, "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_135
    move-object/from16 v18, v1

    .end local v1    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v11    # "destination\\10":Ljava/util/Collection;
    .end local v12    # "$this$filterTo\\10":Ljava/lang/Iterable;
    .end local v13    # "$i$f$filterTo\\10\\366":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    move-object v1, v11

    check-cast v1, Ljava/util/List;

    .line 366
    nop

    .end local v6    # "$this$filter\\9":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filter\\9\\223":I
    check-cast v1, Ljava/lang/Iterable;

    .line 223
    invoke-static {v3, v1}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1

    goto :goto_145

    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v1    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_142
    move-object/from16 v18, v1

    .end local v1    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    move-object v1, v5

    :goto_145
    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    .line 224
    return-void

    .line 221
    .end local v5    # "range":Ljava/util/List;
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v1    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_149
    move-object/from16 v18, v1

    .end local v1    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_14b
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    return-void
.end method

.method private final showContextMenu(Landroid/view/View;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 20
    .param p1, "anchor"    # Landroid/view/View;
    .param p2, "r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 233
    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$none\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 372
    .local v2, "$i$f$none\\1\\233":I
    instance-of v3, v1, Ljava/util/Collection;

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_1c

    move-object v3, v1

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1c

    move v1, v5

    goto :goto_3c

    .line 373
    :cond_1c
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_20
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3b

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\1":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 233
    .local v8, "$i$a$-none-ExplorerPanel$showContextMenu$1\\2\\373\\0":I
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v9

    if-ne v7, v9, :cond_36

    move v7, v5

    goto :goto_37

    :cond_36
    move v7, v4

    .line 373
    .end local v7    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-none-ExplorerPanel$showContextMenu$1\\2\\373\\0":I
    :goto_37
    if-eqz v7, :cond_20

    move v1, v4

    goto :goto_3c

    .line 374
    .end local v6    # "element\\1":Ljava/lang/Object;
    :cond_3b
    move v1, v5

    .line 233
    .end local v1    # "$this$none\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$none\\1\\233":I
    :goto_3c
    if-eqz v1, :cond_4b

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    .line 234
    :cond_4b
    new-instance v1, Landroid/widget/PopupMenu;

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v6, "getContext(...)"

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->popupContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v2

    move-object/from16 v3, p1

    invoke-direct {v1, v2, v3}, Landroid/widget/PopupMenu;-><init>(Landroid/content/Context;Landroid/view/View;)V

    .line 235
    .local v1, "m":Landroid/widget/PopupMenu;
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    .line 236
    .local v2, "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 237
    .local v6, "items":Ljava/util/ArrayList;
    new-instance v7, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda7;

    invoke-direct {v7, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda7;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const-string v8, "Insert Object\u2026"

    invoke-static {v8, v7}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 238
    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rangeAnchor:Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 239
    .local v7, "ra":Lcom/exampletest/mobilestudiotest/model/Instance;
    if-eqz v7, :cond_aa

    if-eq v7, v2, :cond_aa

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Select from \u201c"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "\u201d to here"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda16;

    move-object/from16 v10, p2

    invoke-direct {v9, v0, v10}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda16;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    invoke-static {v8, v9}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_ac

    :cond_aa
    move-object/from16 v10, p2

    .line 240
    :goto_ac
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v8

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v8}, Ljava/util/Collection;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_c6

    new-instance v8, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda17;

    invoke-direct {v8, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda17;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const-string v9, "Select Children"

    invoke-static {v9, v8}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 241
    :cond_c6
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-le v8, v5, :cond_e0

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda18;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda18;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Select Group (parent Model)"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 245
    :cond_e0
    const-string v5, "LuaSourceContainer"

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_f6

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda19;

    invoke-direct {v5, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda19;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const-string v8, "Open Script"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 246
    :cond_f6
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v5

    if-nez v5, :cond_134

    .line 247
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda20;

    invoke-direct {v5, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda20;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const-string v8, "Rename"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 248
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda21;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda21;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Duplicate"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 249
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda22;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda22;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Copy"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 250
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda23;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda23;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Cut"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 252
    :cond_134
    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getHasClipboard()Z

    move-result v5

    if-eqz v5, :cond_14a

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda24;

    invoke-direct {v5, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda24;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const-string v8, "Paste Into"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 253
    :cond_14a
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v5

    if-nez v5, :cond_1bd

    .line 254
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda8;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda8;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Delete"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 255
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda9;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda9;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Group (Model)"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 256
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v5

    const-string v8, "Model"

    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_185

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v5

    const-string v8, "Folder"

    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_185

    goto :goto_193

    :cond_185
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda10;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda10;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Ungroup"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 257
    :goto_193
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda11;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda11;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Zoom To"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 258
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda12;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda12;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Save to File (.rbxm)\u2026"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 259
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda13;

    invoke-direct {v5, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda13;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V

    const-string v8, "Add to Toolbox"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 261
    :cond_1bd
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v5

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_1d7

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda14;

    invoke-direct {v5, v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda14;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const-string v8, "Expand All"

    invoke-static {v8, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 262
    :cond_1d7
    move-object v5, v6

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$forEachIndexed\\3":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 375
    .local v8, "$i$f$forEachIndexed\\3\\262":I
    const/4 v9, 0x0

    .line 376
    .local v9, "index\\3":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_1e0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_20d

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "item\\3":Ljava/lang/Object;
    add-int/lit8 v13, v9, 0x1

    .end local v9    # "index\\3":I
    .local v13, "index\\3":I
    if-gez v9, :cond_1f1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_1f1
    move-object v14, v12

    check-cast v14, Lkotlin/Pair;

    .local v9, "idx\\4":I
    const/4 v15, 0x0

    .local v15, "$i$a$-forEachIndexed-ExplorerPanel$showContextMenu$19\\4\\376\\0":I
    invoke-virtual {v14}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    .line 262
    .local v14, "label\\4":Ljava/lang/String;
    invoke-virtual {v1}, Landroid/widget/PopupMenu;->getMenu()Landroid/view/Menu;

    move-result-object v0

    move-object/from16 v16, v2

    .end local v2    # "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v16, "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    move-object v2, v14

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v0, v4, v9, v9, v2}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 376
    .end local v9    # "idx\\4":I
    .end local v14    # "label\\4":Ljava/lang/String;
    .end local v15    # "$i$a$-forEachIndexed-ExplorerPanel$showContextMenu$19\\4\\376\\0":I
    move-object/from16 v0, p0

    move v9, v13

    move-object/from16 v2, v16

    .end local v12    # "item\\3":Ljava/lang/Object;
    goto :goto_1e0

    .line 377
    .end local v13    # "index\\3":I
    .end local v16    # "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v2    # "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v9, "index\\3":I
    :cond_20d
    nop

    .line 263
    .end local v5    # "$this$forEachIndexed\\3":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEachIndexed\\3\\262":I
    .end local v9    # "index\\3":I
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda15;

    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda15;-><init>(Ljava/util/ArrayList;)V

    invoke-virtual {v1, v0}, Landroid/widget/PopupMenu;->setOnMenuItemClickListener(Landroid/widget/PopupMenu$OnMenuItemClickListener;)V

    .line 264
    invoke-virtual {v1}, Landroid/widget/PopupMenu;->show()V

    .line 265
    return-void
.end method

.method static final showContextMenu$lambda$29(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 237
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showInsertDialog(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$30(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 239
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->selectRange(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$31(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 240
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->visibleChildren(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$35(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 24
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 242
    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 378
    .local v2, "$i$f$mapNotNull\\1\\242":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 386
    .local v5, "$i$f$mapNotNullTo\\2\\378":I
    move-object v6, v4

    .local v6, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 387
    .local v7, "$i$f$forEach\\3\\386":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_1a
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_94

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\3":Ljava/lang/Object;
    move-object v10, v9

    .local v10, "element\\4":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 386
    .local v11, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\387\\2":I
    move-object v12, v10

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v12, "s\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v13, 0x0

    .line 242
    .local v13, "$i$a$-mapNotNull-ExplorerPanel$showContextMenu$5$models$1\\6\\386\\0":I
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v14

    new-instance v15, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda25;

    invoke-direct {v15}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda25;-><init>()V

    invoke-static {v14, v15}, Lkotlin/sequences/SequencesKt;->generateSequence(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object v14

    .local v14, "$this$lastOrNull\\7":Lkotlin/sequences/Sequence;
    const/4 v15, 0x0

    .line 388
    .local v15, "$i$f$lastOrNull\\7\\242":I
    const/16 v16, 0x0

    .line 389
    .local v16, "last\\7":Ljava/lang/Object;
    invoke-interface {v14}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_3e
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_80

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    .line 390
    .local v18, "element\\7":Ljava/lang/Object;
    move-object/from16 v19, v18

    check-cast v19, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v19, "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v20, 0x0

    .line 242
    .local v20, "$i$a$-lastOrNull-ExplorerPanel$showContextMenu$5$models$1$2\\8\\390\\6":I
    move-object/from16 v21, v1

    .end local v1    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .local v21, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v1

    move/from16 v22, v2

    .end local v2    # "$i$f$mapNotNull\\1\\242":I
    .local v22, "$i$f$mapNotNull\\1\\242":I
    const-string v2, "Model"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_71

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    const/4 v2, 0x1

    if-eqz v1, :cond_6d

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v1

    if-ne v1, v2, :cond_6d

    move v1, v2

    goto :goto_6e

    :cond_6d
    const/4 v1, 0x0

    :goto_6e
    if-eqz v1, :cond_71

    goto :goto_72

    :cond_71
    const/4 v2, 0x0

    .line 390
    .end local v19    # "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v20    # "$i$a$-lastOrNull-ExplorerPanel$showContextMenu$5$models$1$2\\8\\390\\6":I
    :goto_72
    if-eqz v2, :cond_7b

    .line 391
    move-object/from16 v16, v18

    move-object/from16 v1, v21

    move/from16 v2, v22

    .end local v18    # "element\\7":Ljava/lang/Object;
    goto :goto_3e

    .line 390
    .restart local v18    # "element\\7":Ljava/lang/Object;
    :cond_7b
    move-object/from16 v1, v21

    move/from16 v2, v22

    goto :goto_3e

    .line 394
    .end local v18    # "element\\7":Ljava/lang/Object;
    .end local v21    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v22    # "$i$f$mapNotNull\\1\\242":I
    .restart local v1    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .restart local v2    # "$i$f$mapNotNull\\1\\242":I
    :cond_80
    move-object/from16 v21, v1

    move/from16 v22, v2

    .end local v1    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$mapNotNull\\1\\242":I
    .end local v14    # "$this$lastOrNull\\7":Lkotlin/sequences/Sequence;
    .end local v15    # "$i$f$lastOrNull\\7\\242":I
    .end local v16    # "last\\7":Ljava/lang/Object;
    .restart local v21    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .restart local v22    # "$i$f$mapNotNull\\1\\242":I
    move-object/from16 v1, v16

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 242
    nop

    .line 386
    .end local v12    # "s\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v13    # "$i$a$-mapNotNull-ExplorerPanel$showContextMenu$5$models$1\\6\\386\\0":I
    if-eqz v1, :cond_8f

    .line 395
    .local v1, "it\\4":Ljava/lang/Object;
    const/4 v2, 0x0

    .line 386
    .local v2, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\395\\4":I
    invoke-interface {v3, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 387
    .end local v1    # "it\\4":Ljava/lang/Object;
    .end local v2    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\395\\4":I
    .end local v10    # "element\\4":Ljava/lang/Object;
    .end local v11    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\387\\2":I
    :cond_8f
    move-object/from16 v1, v21

    move/from16 v2, v22

    .end local v9    # "element\\3":Ljava/lang/Object;
    goto :goto_1a

    .line 396
    .end local v21    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v22    # "$i$f$mapNotNull\\1\\242":I
    .local v1, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .local v2, "$i$f$mapNotNull\\1\\242":I
    :cond_94
    move-object/from16 v21, v1

    move/from16 v22, v2

    .line 397
    .end local v1    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$mapNotNull\\1\\242":I
    .end local v6    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v7    # "$i$f$forEach\\3\\386":I
    .restart local v21    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .restart local v22    # "$i$f$mapNotNull\\1\\242":I
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v4    # "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapNotNullTo\\2\\378":I
    move-object v1, v3

    check-cast v1, Ljava/util/List;

    .line 378
    nop

    .end local v21    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v22    # "$i$f$mapNotNull\\1\\242":I
    check-cast v1, Ljava/lang/Iterable;

    .line 242
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1

    .line 243
    .local v1, "models":Ljava/util/List;
    move-object v2, v1

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_b1

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    .line 244
    :cond_b1
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method static final showContextMenu$lambda$35$lambda$34$lambda$32(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 2
    .param p0, "it"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 242
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    return-object v0
.end method

.method static final showContextMenu$lambda$36(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 245
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/core/Studio;->openScript(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$37(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 247
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rename(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$38(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 248
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->duplicateSelection()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$39(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 249
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->copySelection()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$40(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 250
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->cutSelection()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$41(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 252
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/core/Studio;->paste(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$42(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 254
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->deleteSelection()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$43(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 255
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->groupSelection()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$44(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 256
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->ungroupSelection()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$45(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 257
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->focusSelection()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$46(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 258
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->actions:Lcom/exampletest/mobilestudiotest/ui/MainActions;

    invoke-interface {v0}, Lcom/exampletest/mobilestudiotest/ui/MainActions;->exportSelection()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$47(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 259
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->actions:Lcom/exampletest/mobilestudiotest/ui/MainActions;

    invoke-interface {v0}, Lcom/exampletest/mobilestudiotest/ui/MainActions;->addSelectionToToolbox()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$48(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 261
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expandAll(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final showContextMenu$lambda$50(Ljava/util/ArrayList;Landroid/view/MenuItem;)Z
    .registers 3
    .param p0, "$items"    # Ljava/util/ArrayList;
    .param p1, "mi"    # Landroid/view/MenuItem;

    .line 263
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkotlin/Pair;

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    const/4 v0, 0x1

    return v0
.end method

.method static final showInsertDialog$lambda$54(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Lkotlin/Unit;
    .registers 9
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$parent"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "cls"    # Ljava/lang/String;

    const-string v0, "cls"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 286
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    const/4 v1, 0x0

    if-eqz p1, :cond_22

    .line 331
    move-object v2, p1

    .local v2, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v3, 0x0

    .line 286
    .local v3, "$i$a$-takeIf-ExplorerPanel$showInsertDialog$1$1\\1\\286\\0":I
    const-string v4, "BasePart"

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1e

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v5, p2, v4}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isA(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1e

    const/4 v4, 0x0

    goto :goto_1f

    :cond_1e
    const/4 v4, 0x1

    .end local v2    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v3    # "$i$a$-takeIf-ExplorerPanel$showInsertDialog$1$1\\1\\286\\0":I
    :goto_1f
    if-eqz v4, :cond_22

    move-object v1, p1

    :cond_22
    invoke-virtual {v0, p2, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->insertObject(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 287
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final startDrag(Landroid/view/View;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 20
    .param p1, "v"    # Landroid/view/View;
    .param p2, "r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 88
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$none\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 332
    .local v3, "$i$f$none\\1\\88":I
    instance-of v4, v0, Ljava/util/Collection;

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_1d

    move-object v4, v0

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_1d

    goto :goto_3d

    .line 333
    :cond_1d
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_21
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_3c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\1":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 88
    .local v9, "$i$a$-none-ExplorerPanel$startDrag$1\\2\\333\\0":I
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v10

    if-ne v8, v10, :cond_37

    move v8, v5

    goto :goto_38

    :cond_37
    move v8, v6

    .line 333
    .end local v8    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-none-ExplorerPanel$startDrag$1\\2\\333\\0":I
    :goto_38
    if-eqz v8, :cond_21

    move v5, v6

    goto :goto_3d

    .line 334
    .end local v7    # "element\\1":Ljava/lang/Object;
    :cond_3c
    nop

    .line 88
    .end local v0    # "$this$none\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$none\\1\\88":I
    :goto_3d
    if-eqz v5, :cond_4c

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    .line 89
    :cond_4c
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 331
    const/4 v0, 0x0

    .line 89
    .local v0, "$i$a$-synchronized-ExplorerPanel$startDrag$items$1\\3\\89\\0":I
    :try_start_54
    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\4":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 335
    .local v5, "$i$f$filter\\4\\89":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\5":Ljava/util/Collection;
    move-object v8, v4

    .local v8, "$this$filterTo\\5":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 336
    .local v9, "$i$f$filterTo\\5\\335":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_6a
    :goto_6a
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_82

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\5":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v12, "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v13, 0x0

    .line 89
    .local v13, "$i$a$-filter-ExplorerPanel$startDrag$items$1$1\\6\\336\\3":I
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v14

    .line 336
    .end local v12    # "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v13    # "$i$a$-filter-ExplorerPanel$startDrag$items$1$1\\6\\336\\3":I
    if-nez v14, :cond_6a

    invoke-interface {v7, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_6a

    .line 337
    .end local v11    # "element\\5":Ljava/lang/Object;
    :cond_82
    nop

    .end local v7    # "destination\\5":Ljava/util/Collection;
    .end local v8    # "$this$filterTo\\5":Ljava/lang/Iterable;
    .end local v9    # "$i$f$filterTo\\5\\335":I
    check-cast v7, Ljava/util/List;
    :try_end_85
    .catchall {:try_start_54 .. :try_end_85} :catchall_d4

    .line 335
    nop

    .line 89
    .end local v4    # "$this$filter\\4":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\4\\89":I
    nop

    .end local v0    # "$i$a$-synchronized-ExplorerPanel$startDrag$items$1\\3\\89\\0":I
    monitor-exit v3

    .line 90
    .local v7, "items":Ljava/util/List;
    move-object/from16 v4, p2

    iput-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragRow:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    iput-object v2, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragAnchor:Landroid/view/View;

    const/4 v0, 0x0

    iput-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragStart:Lkotlin/Pair;

    iput-boolean v6, v1, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->dragMoved:Z

    .line 91
    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_9d

    invoke-direct/range {p0 .. p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu(Landroid/view/View;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    return-void

    .line 92
    :cond_9d
    nop

    .line 93
    :try_start_9e
    const-string v0, "instances"

    check-cast v0, Ljava/lang/CharSequence;

    move-object v8, v7

    check-cast v8, Ljava/lang/Iterable;

    new-instance v14, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda2;

    invoke-direct {v14}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda2;-><init>()V

    const/16 v15, 0x1f

    const/16 v16, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static/range {v8 .. v16}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {v0, v3}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v0

    new-instance v3, Landroid/view/View$DragShadowBuilder;

    invoke-direct {v3, v2}, Landroid/view/View$DragShadowBuilder;-><init>(Landroid/view/View;)V

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;

    invoke-direct {v5, v7}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;-><init>(Ljava/util/List;)V

    invoke-virtual {v2, v0, v3, v5, v6}, Landroid/view/View;->startDragAndDrop(Landroid/content/ClipData;Landroid/view/View$DragShadowBuilder;Ljava/lang/Object;I)Z

    move-result v6
    :try_end_cb
    .catch Ljava/lang/Exception; {:try_start_9e .. :try_end_cb} :catch_cc

    goto :goto_cd

    .line 94
    :catch_cc
    move-exception v0

    .line 92
    :goto_cd
    nop

    .line 95
    .local v6, "ok":Z
    if-nez v6, :cond_d3

    invoke-direct/range {p0 .. p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu(Landroid/view/View;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    .line 96
    :cond_d3
    return-void

    .line 89
    .end local v6    # "ok":Z
    .end local v7    # "items":Ljava/util/List;
    :catchall_d4
    move-exception v0

    move-object/from16 v4, p2

    monitor-exit v3

    throw v0
.end method

.method static final startDrag$lambda$8(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/CharSequence;
    .registers 2
    .param p0, "it"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method private final toggleExpand(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 4
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 227
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getHasChildren()Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 228
    :cond_7
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    goto :goto_26

    :cond_1d
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expanded:Ljava/util/Set;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 229
    :goto_26
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild()V

    .line 230
    return-void
.end method

.method private final updateMultiBtn()V
    .registers 9

    .line 139
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->multiBtn:Landroid/widget/ImageView;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getMultiSelect()Z

    move-result v1

    const-string v2, "getContext(...)"

    if-eqz v1, :cond_30

    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 331
    move-object v3, v1

    .local v3, "$this$updateMultiBtn_u24lambda_u2412\\1":Landroid/graphics/drawable/GradientDrawable;
    const/4 v4, 0x0

    .line 139
    .local v4, "$i$a$-apply-ExplorerPanel$updateMultiBtn$1\\1\\139\\0":I
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getSELECT()I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v2, 0x40800000    # 4.0f

    invoke-virtual {v5, v6, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v3, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v3    # "$this$updateMultiBtn_u24lambda_u2412\\1":Landroid/graphics/drawable/GradientDrawable;
    .end local v4    # "$i$a$-apply-ExplorerPanel$updateMultiBtn$1\\1\\139\\0":I
    check-cast v1, Landroid/graphics/drawable/Drawable;

    goto :goto_44

    .line 140
    :cond_30
    move-object v1, v2

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->rippleBg$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;IFILjava/lang/Object;)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/Drawable;

    .line 139
    :goto_44
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 141
    return-void
.end method

.method private final visibleChildren(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;
    .registers 13
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ")",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 154
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-eqz v0, :cond_59

    .line 155
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->getServiceNames()Ljava/util/List;

    move-result-object v0

    .line 156
    .local v0, "order":Ljava/util/List;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 341
    .local v2, "$i$f$filter\\1\\156":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 342
    .local v5, "$i$f$filterTo\\2\\341":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_1e
    :goto_1e
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_45

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\2":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 156
    .local v9, "$i$a$-filter-ExplorerPanel$visibleChildren$1\\3\\342\\0":I
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->getArchivable()Z

    move-result v10

    if-nez v10, :cond_3e

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v0, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_3e

    const/4 v10, 0x0

    goto :goto_3f

    :cond_3e
    const/4 v10, 0x1

    .line 342
    .end local v8    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-filter-ExplorerPanel$visibleChildren$1\\3\\342\\0":I
    :goto_3f
    if-eqz v10, :cond_1e

    invoke-interface {v3, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1e

    .line 343
    .end local v7    # "element\\2":Ljava/lang/Object;
    :cond_45
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v4    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filterTo\\2\\341":I
    check-cast v3, Ljava/util/List;

    .line 341
    nop

    .end local v1    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\1\\156":I
    check-cast v3, Ljava/lang/Iterable;

    .line 157
    nop

    .local v3, "$this$sortedBy\\4":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 344
    .local v1, "$i$f$sortedBy\\4\\157":I
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$visibleChildren$$inlined$sortedBy$1;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$visibleChildren$$inlined$sortedBy$1;-><init>(Ljava/util/List;)V

    check-cast v2, Ljava/util/Comparator;

    invoke-static {v3, v2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v1

    .line 156
    .end local v1    # "$i$f$sortedBy\\4\\157":I
    .end local v3    # "$this$sortedBy\\4":Ljava/lang/Iterable;
    return-object v1

    .line 160
    .end local v0    # "order":Ljava/util/List;
    :cond_59
    const-string v0, "PartOperation"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_94

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\5":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 345
    .local v1, "$i$f$filter\\5\\160":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\6":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo\\6":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 346
    .local v4, "$i$f$filterTo\\6\\345":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_75
    :goto_75
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_8f

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\6":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 160
    .local v8, "$i$a$-filter-ExplorerPanel$visibleChildren$3\\7\\346\\0":I
    const-string v9, "BasePart"

    invoke-virtual {v7, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v9

    .line 346
    .end local v7    # "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-filter-ExplorerPanel$visibleChildren$3\\7\\346\\0":I
    if-nez v9, :cond_75

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_75

    .line 347
    .end local v6    # "element\\6":Ljava/lang/Object;
    :cond_8f
    nop

    .end local v2    # "destination\\6":Ljava/util/Collection;
    .end local v3    # "$this$filterTo\\6":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterTo\\6\\345":I
    check-cast v2, Ljava/util/List;

    .line 345
    nop

    .line 160
    .end local v0    # "$this$filter\\5":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter\\5\\160":I
    return-object v2

    .line 161
    :cond_94
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    return-object v0
.end method


# virtual methods
.method public final getMultiSelect()Z
    .registers 2

    .line 43
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMultiSelect()Z

    move-result v0

    return v0
.end method

.method public onDirtyChanged()V
    .registers 1

    .line 23
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onDirtyChanged()V

    return-void
.end method

.method public onModelReplaced()V
    .registers 1

    .line 203
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->expandDefaults()V

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild()V

    return-void
.end method

.method public onPlayStateChanged()V
    .registers 1

    .line 23
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onPlayStateChanged()V

    return-void
.end method

.method public onPluginsChanged()V
    .registers 1

    .line 23
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onPluginsChanged()V

    return-void
.end method

.method public onPropsChanged()V
    .registers 1

    .line 23
    invoke-super {p0}, Lcom/exampletest/mobilestudiotest/core/Studio$Listener;->onPropsChanged()V

    return-void
.end method

.method public onSelectionChanged()V
    .registers 1

    .line 202
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->revealSelection()V

    return-void
.end method

.method public onToolChanged()V
    .registers 1

    .line 204
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->updateMultiBtn()V

    return-void
.end method

.method public onTreeChanged()V
    .registers 1

    .line 201
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild()V

    return-void
.end method

.method public final rebuild()V
    .registers 16

    .line 165
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v1, v0

    .line 166
    .local v1, "out":Ljava/util/ArrayList;
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    const/4 v0, 0x0

    .line 167
    .local v0, "$i$a$-synchronized-ExplorerPanel$rebuild$1\\1\\166\\0":I
    :try_start_e
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v3

    .line 168
    .local v3, "root\\1":Lcom/exampletest/mobilestudiotest/model/DataModel;
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->filter:Ljava/lang/String;

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-lez v4, :cond_22

    move v4, v5

    goto :goto_23

    :cond_22
    move v4, v6

    :goto_23
    if-eqz v4, :cond_b9

    .line 169
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->filter:Ljava/lang/String;

    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v4, v7}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    const-string v7, "toLowerCase(...)"

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    .local v4, "f\\1":Ljava/lang/String;
    move-object v7, v3

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    const/4 v8, 0x0

    invoke-static {v7, v8, v5, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3e
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_bf

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object v10, v7

    .line 171
    .local v10, "d\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v7

    const/16 v9, 0x7d0

    if-gt v7, v9, :cond_bf

    .line 172
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v7

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v7, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    const-string v9, "toLowerCase(...)"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v7, Ljava/lang/CharSequence;

    move-object v9, v4

    check-cast v9, Ljava/lang/CharSequence;

    const/4 v11, 0x2

    invoke-static {v7, v9, v6, v11, v8}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_84

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v7

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v7, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    const-string v9, "toLowerCase(...)"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_84

    goto :goto_3e

    .line 173
    :cond_84
    new-instance v9, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v11

    if-eqz v11, :cond_96

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Instance;->fullName()Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_98

    :cond_96
    const-string v11, ""

    :cond_98
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v12, "  \u00b7  "

    invoke-virtual {v7, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-direct/range {v9 .. v14}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;IZZLjava/lang/String;)V

    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3e

    .line 183
    .end local v4    # "f\\1":Ljava/lang/String;
    .end local v10    # "d\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_b9
    move-object v4, v3

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {p0, v1, v4, v6}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild$lambda$19$walk(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Ljava/util/ArrayList;Lcom/exampletest/mobilestudiotest/model/Instance;I)V

    .line 185
    :cond_bf
    nop

    .end local v0    # "$i$a$-synchronized-ExplorerPanel$rebuild$1\\1\\166\\0":I
    .end local v3    # "root\\1":Lcom/exampletest/mobilestudiotest/model/DataModel;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_c2
    .catchall {:try_start_e .. :try_end_c2} :catchall_ce

    .line 166
    monitor-exit v2

    .line 186
    move-object v0, v1

    check-cast v0, Ljava/util/List;

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rows:Ljava/util/List;

    .line 187
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->notifyDataSetChanged()V

    .line 188
    return-void

    .line 166
    :catchall_ce
    move-exception v0

    monitor-exit v2

    throw v0
.end method

.method public final refreshIcons()V
    .registers 2

    .line 144
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->notifyDataSetChanged()V

    return-void
.end method

.method public final setMultiSelect(Z)V
    .registers 3
    .param p1, "v"    # Z

    .line 44
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/core/Studio;->setMultiSelect(Z)V

    return-void
.end method

.method public final showInsertDialog(Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 6
    .param p1, "parent"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 285
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Dialogs;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    const-string v3, "Insert Object"

    invoke-virtual {v0, v1, v3, v2}, Lcom/exampletest/mobilestudiotest/ui/Dialogs;->pickClass(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 288
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel.AnonymousClass4 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$4)
.class public final Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$4;
.super Ljava/lang/Object;
.source "ExplorerPanel.kt"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;-><init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;Lcom/exampletest/mobilestudiotest/ui/MainActions;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\r\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J*\u0010\u0002\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u0007H\u0016J*\u0010\n\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u0007H\u0016J\u0012\u0010\u000b\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u000cH\u0016\u00a8\u0006\r"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/ui/ExplorerPanel$4",
        "Landroid/text/TextWatcher;",
        "beforeTextChanged",
        "",
        "s",
        "",
        "a",
        "",
        "b",
        "c",
        "onTextChanged",
        "afterTextChanged",
        "Landroid/text/Editable;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2
    .param p1, "$receiver"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$4;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .registers 4
    .param p1, "s"    # Landroid/text/Editable;

    .line 67
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$4;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    if-eqz p1, :cond_17

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_17

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_17

    goto :goto_19

    :cond_17
    const-string v1, ""

    :goto_19
    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->access$setFilter$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$4;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rebuild()V

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .registers 5
    .param p1, "s"    # Ljava/lang/CharSequence;
    .param p2, "a"    # I
    .param p3, "b"    # I
    .param p4, "c"    # I

    .line 65
    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .registers 5
    .param p1, "s"    # Ljava/lang/CharSequence;
    .param p2, "a"    # I
    .param p3, "b"    # I
    .param p4, "c"    # I

    .line 66
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel.Adapter (com.exampletest.mobilestudiotest.ui.ExplorerPanel$Adapter)
.class final Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "ExplorerPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Adapter"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nExplorerPanel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ExplorerPanel.kt\ncom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,330:1\n1#2:331\n1761#3,3:332\n*S KotlinDebug\n*F\n+ 1 ExplorerPanel.kt\ncom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter\n*L\n320#1:332,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0003\u0008\u0082\u0004\u0018\u00002\u000c\u0012\u0008\u0012\u00060\u0002R\u00020\u00030\u0001B\u0007\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0008\u0010\u0006\u001a\u00020\u0007H\u0016J\u001c\u0010\u0008\u001a\u00060\u0002R\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0007H\u0016J\u001c\u0010\u000c\u001a\u00020\r2\n\u0010\u000e\u001a\u00060\u0002R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0007H\u0016\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;",
        "Landroidx/recyclerview/widget/RecyclerView$Adapter;",
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;",
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V",
        "getItemCount",
        "",
        "onCreateViewHolder",
        "parent",
        "Landroid/view/ViewGroup;",
        "viewType",
        "onBindViewHolder",
        "",
        "h",
        "position",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 292
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    return-void
.end method

.method static final onBindViewHolder$lambda$6(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)V
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .param p2, "it"    # Landroid/view/View;

    .line 324
    invoke-static {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->access$onRowClick(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    return-void
.end method

.method static final onBindViewHolder$lambda$7(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)V
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .param p2, "it"    # Landroid/view/View;

    .line 325
    invoke-static {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->access$toggleExpand(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    return-void
.end method

.method static final onBindViewHolder$lambda$8(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)Z
    .registers 5
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p1, "$h"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;
    .param p2, "$r"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    .param p3, "it"    # Landroid/view/View;

    .line 326
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-static {p0, v0, p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->access$startDrag(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    const/4 v0, 0x1

    return v0
.end method


# virtual methods
.method public getItemCount()I
    .registers 2

    .line 293
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->access$getRows$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .registers 4
    .param p1, "p0"    # Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .param p2, "p1"    # I

    .line 292
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;

    invoke-virtual {p0, v0, p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->onBindViewHolder(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;I)V

    return-void
.end method

.method public onBindViewHolder(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;I)V
    .registers 13
    .param p1, "h"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;
    .param p2, "position"    # I

    const-string v0, "h"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 315
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->access$getRows$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    .line 316
    .local v0, "r":Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getSpacer()Landroid/view/View;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v4

    check-cast v4, Landroid/view/View;

    const/high16 v5, 0x41600000    # 14.0f

    invoke-virtual {v3, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/view/View;F)I

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getDepth()I

    move-result v4

    mul-int/2addr v3, v4

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v5

    check-cast v5, Landroid/view/View;

    const/high16 v6, 0x40000000    # 2.0f

    invoke-virtual {v4, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/view/View;F)I

    move-result v4

    add-int/2addr v3, v4

    const/4 v4, 0x1

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 317
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getArrow()Landroid/widget/ImageView;

    move-result-object v1

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getHasChildren()Z

    move-result v2

    const/4 v3, 0x0

    const/4 v5, 0x0

    if-eqz v2, :cond_59

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getExpanded()Z

    move-result v6

    const/4 v7, 0x2

    invoke-direct {v2, v6, v5, v7, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;-><init>(ZIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v3, v2

    :cond_59
    check-cast v3, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 318
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getIcon()Landroid/widget/ImageView;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v6, "getContext(...)"

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->icon(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/model/Instance;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 319
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getLabel()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-nez v3, :cond_8e

    move v3, v4

    goto :goto_8f

    :cond_8e
    move v3, v5

    :goto_8f
    if-eqz v3, :cond_95

    .line 331
    const/4 v2, 0x0

    .line 319
    .local v2, "$i$a$-ifEmpty-ExplorerPanel$Adapter$onBindViewHolder$1\\1\\319\\0":I
    nop

    .end local v2    # "$i$a$-ifEmpty-ExplorerPanel$Adapter$onBindViewHolder$1\\1\\319\\0":I
    const-string v2, " "

    :cond_95
    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 320
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$any\\2":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 332
    .local v2, "$i$f$any\\2\\320":I
    instance-of v3, v1, Ljava/util/Collection;

    if-eqz v3, :cond_b6

    move-object v3, v1

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_b6

    move v1, v5

    goto :goto_d6

    .line 333
    :cond_b6
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_ba
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_d5

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 320
    .local v8, "$i$a$-any-ExplorerPanel$Adapter$onBindViewHolder$selected$1\\3\\333\\0":I
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v9

    if-ne v7, v9, :cond_d0

    move v7, v4

    goto :goto_d1

    :cond_d0
    move v7, v5

    .line 333
    .end local v7    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-any-ExplorerPanel$Adapter$onBindViewHolder$selected$1\\3\\333\\0":I
    :goto_d1
    if-eqz v7, :cond_ba

    move v1, v4

    goto :goto_d6

    .line 334
    .end local v6    # "element\\2":Ljava/lang/Object;
    :cond_d5
    move v1, v5

    .line 320
    .end local v1    # "$this$any\\2":Ljava/lang/Iterable;
    .end local v2    # "$i$f$any\\2\\320":I
    :goto_d6
    nop

    .line 321
    .local v1, "selected":Z
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->access$getDropTarget$p(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    if-eq v2, v3, :cond_e4

    move v4, v5

    .line 322
    .local v4, "target":Z
    :cond_e4
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v2

    if-eqz v4, :cond_ee

    const v5, 0x663b8beb

    goto :goto_f6

    :cond_ee
    if-eqz v1, :cond_f6

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getSELECT()I

    move-result v5

    :cond_f6
    :goto_f6
    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 323
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getName()Landroid/widget/TextView;

    move-result-object v2

    if-eqz v1, :cond_108

    if-nez v4, :cond_108

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getSELECT_TEXT()I

    move-result v3

    goto :goto_10e

    :cond_108
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v3

    :goto_10e
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 324
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v2

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda0;

    invoke-direct {v5, v3, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 325
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getArrow()Landroid/widget/ImageView;

    move-result-object v2

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda1;

    invoke-direct {v5, v3, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    invoke-virtual {v2, v5}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 326
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->getRow()Landroid/widget/LinearLayout;

    move-result-object v2

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;

    invoke-direct {v5, v3, p1, v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 327
    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .registers 4
    .param p1, "p0"    # Landroid/view/ViewGroup;
    .param p2, "p1"    # I

    .line 292
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->onCreateViewHolder(Landroid/view/ViewGroup;I)Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    return-object v0
.end method

.method public onCreateViewHolder(Landroid/view/ViewGroup;I)Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;
    .registers 23
    .param p1, "parent"    # Landroid/view/ViewGroup;
    .param p2, "viewType"    # I

    const-string v0, "parent"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 296
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v3

    .line 297
    .local v3, "ctx":Landroid/content/Context;
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v0

    .local v2, "$this$onCreateViewHolder_u24lambda_u240\\1":Landroid/widget/LinearLayout;
    const/4 v4, 0x0

    .line 298
    .local v4, "$i$a$-apply-ExplorerPanel$Adapter$onCreateViewHolder$row$1\\1\\297\\0":I
    const/4 v10, 0x0

    invoke-virtual {v2, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 299
    const/16 v5, 0x10

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 300
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/high16 v11, 0x41e00000    # 28.0f

    invoke-virtual {v5, v3, v11}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setMinimumHeight(I)V

    .line 301
    new-instance v5, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;

    const/4 v6, -0x1

    const/4 v12, -0x2

    invoke-direct {v5, v6, v12}, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;-><init>(II)V

    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 302
    nop

    .line 297
    .end local v2    # "$this$onCreateViewHolder_u24lambda_u240\\1":Landroid/widget/LinearLayout;
    .end local v4    # "$i$a$-apply-ExplorerPanel$Adapter$onCreateViewHolder$row$1\\1\\297\\0":I
    move-object v15, v0

    .line 303
    .local v15, "row":Landroid/widget/LinearLayout;
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, v3}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 304
    .local v0, "spacer":Landroid/view/View;
    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, v3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    move-object v4, v2

    .line 331
    .local v4, "$this$onCreateViewHolder_u24lambda_u241\\2":Landroid/widget/ImageView;
    const/4 v5, 0x0

    .line 304
    .local v5, "$i$a$-apply-ExplorerPanel$Adapter$onCreateViewHolder$arrow$1\\2\\304\\0":I
    sget-object v6, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v6}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .end local v4    # "$this$onCreateViewHolder_u24lambda_u241\\2":Landroid/widget/ImageView;
    .end local v5    # "$i$a$-apply-ExplorerPanel$Adapter$onCreateViewHolder$arrow$1\\2\\304\\0":I
    move-object/from16 v17, v2

    .line 305
    .local v17, "arrow":Landroid/widget/ImageView;
    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, v3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    move-object v4, v2

    .line 331
    .local v4, "$this$onCreateViewHolder_u24lambda_u242\\3":Landroid/widget/ImageView;
    const/4 v5, 0x0

    .line 305
    .local v5, "$i$a$-apply-ExplorerPanel$Adapter$onCreateViewHolder$icon$1\\3\\305\\0":I
    sget-object v6, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v6}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .end local v4    # "$this$onCreateViewHolder_u24lambda_u242\\3":Landroid/widget/ImageView;
    .end local v5    # "$i$a$-apply-ExplorerPanel$Adapter$onCreateViewHolder$icon$1\\3\\305\\0":I
    move-object/from16 v18, v2

    .line 306
    .local v18, "icon":Landroid/widget/ImageView;
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/16 v8, 0x18

    const/4 v9, 0x0

    const-string v4, ""

    const/high16 v5, 0x41500000    # 13.0f

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v2 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v19

    move-object/from16 v2, v19

    .line 331
    .local v2, "$this$onCreateViewHolder_u24lambda_u243\\4":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 306
    .local v4, "$i$a$-apply-ExplorerPanel$Adapter$onCreateViewHolder$name$1\\4\\306\\0":I
    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-virtual {v5, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v7, 0x40800000    # 4.0f

    invoke-virtual {v6, v3, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-virtual {v2, v5, v10, v6, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 307
    .end local v2    # "$this$onCreateViewHolder_u24lambda_u243\\4":Landroid/widget/TextView;
    .end local v4    # "$i$a$-apply-ExplorerPanel$Adapter$onCreateViewHolder$name$1\\4\\306\\0":I
    .local v19, "name":Landroid/widget/TextView;
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x1

    invoke-direct {v2, v10, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v15, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 308
    move-object/from16 v2, v17

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x41a00000    # 20.0f

    invoke-virtual {v5, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v6, v3, v11}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v15, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 309
    move-object/from16 v2, v18

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x41800000    # 16.0f

    invoke-virtual {v5, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7, v3, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v15, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 310
    move-object/from16 v2, v19

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v4, v10, v12, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v15, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 311
    new-instance v13, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;

    move-object/from16 v2, p0

    iget-object v14, v2, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    move-object/from16 v16, v0

    .end local v0    # "spacer":Landroid/view/View;
    .local v16, "spacer":Landroid/view/View;
    invoke-direct/range {v13 .. v19}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;-><init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/widget/LinearLayout;Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/TextView;)V

    return-object v13
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$Adapter$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$Adapter$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;"
    method = "onBindViewHolder$lambda$6"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->onBindViewHolder$lambda$6(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$Adapter$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$Adapter$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;"
    method = "onBindViewHolder$lambda$7"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda1;->f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda1;->f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->onBindViewHolder$lambda$7(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$Adapter$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$Adapter$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;"
    method = "onBindViewHolder$lambda$8"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;

.field public final synthetic f$2:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;->f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;->f$2:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;->f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter$$ExternalSyntheticLambda2;->f$2:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    invoke-static {v0, v1, v2, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Adapter;->onBindViewHolder$lambda$8(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;Landroid/view/View;)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel.DragPayload (com.exampletest.mobilestudiotest.ui.ExplorerPanel$DragPayload)
.class public final Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;
.super Ljava/lang/Object;
.source "ExplorerPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "DragPayload"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0018\u00002\u00020\u0001B\u0015\u0012\u000c\u0010\u0002\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0004\u0008\u0005\u0010\u0006R\u0017\u0010\u0002\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008\u00a8\u0006\t"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;",
        "",
        "items",
        "",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "<init>",
        "(Ljava/util/List;)V",
        "getItems",
        "()Ljava/util/List;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .registers 3
    .param p1, "items"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;)V"
        }
    .end annotation

    const-string v0, "items"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;->items:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final getItems()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 28
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$DragPayload;->items:Ljava/util/List;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel.Row (com.exampletest.mobilestudiotest.ui.ExplorerPanel$Row)
.class final Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;
.super Ljava/lang/Object;
.source "ExplorerPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Row"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u000c\u0008\u0002\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R\u0011\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0012R\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015\u00a8\u0006\u0016"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;",
        "",
        "inst",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "depth",
        "",
        "hasChildren",
        "",
        "expanded",
        "label",
        "",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/model/Instance;IZZLjava/lang/String;)V",
        "getInst",
        "()Lcom/exampletest/mobilestudiotest/model/Instance;",
        "getDepth",
        "()I",
        "getHasChildren",
        "()Z",
        "getExpanded",
        "getLabel",
        "()Ljava/lang/String;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final depth:I

.field private final expanded:Z

.field private final hasChildren:Z

.field private final inst:Lcom/exampletest/mobilestudiotest/model/Instance;

.field private final label:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/model/Instance;IZZLjava/lang/String;)V
    .registers 7
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "depth"    # I
    .param p3, "hasChildren"    # Z
    .param p4, "expanded"    # Z
    .param p5, "label"    # Ljava/lang/String;

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "label"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->inst:Lcom/exampletest/mobilestudiotest/model/Instance;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->depth:I

    iput-boolean p3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->hasChildren:Z

    iput-boolean p4, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->expanded:Z

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->label:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final getDepth()I
    .registers 2

    .line 25
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->depth:I

    return v0
.end method

.method public final getExpanded()Z
    .registers 2

    .line 25
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->expanded:Z

    return v0
.end method

.method public final getHasChildren()Z
    .registers 2

    .line 25
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->hasChildren:Z

    return v0
.end method

.method public final getInst()Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 2

    .line 25
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->inst:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-object v0
.end method

.method public final getLabel()Ljava/lang/String;
    .registers 2

    .line 25
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;->label:Ljava/lang/String;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel.VH (com.exampletest.mobilestudiotest.ui.ExplorerPanel$VH)
.class final Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;
.super Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
.source "ExplorerPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "VH"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u000c\u0008\u0082\u0004\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R\u0011\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0012R\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015\u00a8\u0006\u0016"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;",
        "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;",
        "row",
        "Landroid/widget/LinearLayout;",
        "spacer",
        "Landroid/view/View;",
        "arrow",
        "Landroid/widget/ImageView;",
        "icon",
        "name",
        "Landroid/widget/TextView;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/widget/LinearLayout;Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/TextView;)V",
        "getRow",
        "()Landroid/widget/LinearLayout;",
        "getSpacer",
        "()Landroid/view/View;",
        "getArrow",
        "()Landroid/widget/ImageView;",
        "getIcon",
        "getName",
        "()Landroid/widget/TextView;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final arrow:Landroid/widget/ImageView;

.field private final icon:Landroid/widget/ImageView;

.field private final name:Landroid/widget/TextView;

.field private final row:Landroid/widget/LinearLayout;

.field private final spacer:Landroid/view/View;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/widget/LinearLayout;Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/TextView;)V
    .registers 8
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;
    .param p2, "row"    # Landroid/widget/LinearLayout;
    .param p3, "spacer"    # Landroid/view/View;
    .param p4, "arrow"    # Landroid/widget/ImageView;
    .param p5, "icon"    # Landroid/widget/ImageView;
    .param p6, "name"    # Landroid/widget/TextView;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Landroid/view/View;",
            "Landroid/widget/ImageView;",
            "Landroid/widget/ImageView;",
            "Landroid/widget/TextView;",
            ")V"
        }
    .end annotation

    const-string v0, "row"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "spacer"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "arrow"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "icon"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 290
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->this$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    move-object v0, p2

    check-cast v0, Landroid/view/View;

    invoke-direct {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->row:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->spacer:Landroid/view/View;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->arrow:Landroid/widget/ImageView;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->icon:Landroid/widget/ImageView;

    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->name:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final getArrow()Landroid/widget/ImageView;
    .registers 2

    .line 290
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->arrow:Landroid/widget/ImageView;

    return-object v0
.end method

.method public final getIcon()Landroid/widget/ImageView;
    .registers 2

    .line 290
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->icon:Landroid/widget/ImageView;

    return-object v0
.end method

.method public final getName()Landroid/widget/TextView;
    .registers 2

    .line 290
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->name:Landroid/widget/TextView;

    return-object v0
.end method

.method public final getRow()Landroid/widget/LinearLayout;
    .registers 2

    .line 290
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->row:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method public final getSpacer()Landroid/view/View;
    .registers 2

    .line 290
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$VH;->spacer:Landroid/view/View;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showInsertDialog$lambda$54"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showInsertDialog$lambda$54(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "rename$lambda$52"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/widget/EditText;Landroid/content/DialogInterface;I)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

.field public final synthetic f$2:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/widget/EditText;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;->f$2:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda1;->f$2:Landroid/widget/EditText;

    invoke-static {v0, v1, v2, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->rename$lambda$52(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;Landroid/widget/EditText;Landroid/content/DialogInterface;I)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda10 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda10)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$44"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda10;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda10;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$44(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda11 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda11)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$45"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda11;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda11;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$45(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda12 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda12)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$46"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda12;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda12;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$46(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda13 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda13)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$47"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda13;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda13;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$47(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda14 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda14)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$48"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda14;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda14;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda14;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda14;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$48(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda15 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda15)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/PopupMenu$OnMenuItemClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$50"
    proto = "(Ljava/util/ArrayList;Landroid/view/MenuItem;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/util/ArrayList;


# direct methods
.method public synthetic constructor <init>(Ljava/util/ArrayList;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda15;->f$0:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final onMenuItemClick(Landroid/view/MenuItem;)Z
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda15;->f$0:Ljava/util/ArrayList;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$50(Ljava/util/ArrayList;Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda16 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda16)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$30"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda16;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda16;->f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda16;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda16;->f$1:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$30(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$Row;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda17 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda17)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$31"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda17;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda17;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda17;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda17;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$31(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda18 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda18)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$35"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda18;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda18;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$35(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda19 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda19)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$36"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda19;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda19;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda19;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda19;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$36(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "startDrag$lambda$8"
    proto = "(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/CharSequence;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->startDrag$lambda$8(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/CharSequence;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda20 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda20)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$37"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda20;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda20;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda20;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda20;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$37(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda21 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda21)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$38"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda21;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda21;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$38(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda22 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda22)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$39"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda22;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda22;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$39(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda23 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda23)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$40"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda23;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda23;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$40(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda24 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda24)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda24;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$41"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda24;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda24;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda24;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda24;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$41(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda25 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda25)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda25;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$35$lambda$34$lambda$32"
    proto = "(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$35$lambda$34$lambda$32(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "_init_$lambda$0"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->_init_$lambda$0(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "_init_$lambda$1"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->_init_$lambda$1(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "_init_$lambda$2"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->_init_$lambda$2(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnDragListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "_init_$lambda$4"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;Landroid/view/DragEvent;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final onDrag(Landroid/view/View;Landroid/view/DragEvent;)Z
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->_init_$lambda$4(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Landroid/view/View;Landroid/view/DragEvent;)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$29"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda7;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda7;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$29(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda8 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$42"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$42(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda9 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$$ExternalSyntheticLambda9)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;"
    method = "showContextMenu$lambda$43"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->showContextMenu$lambda$43(Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ExplorerPanel$visibleChildren$$inlined$sortedBy$1 (com.exampletest.mobilestudiotest.ui.ExplorerPanel$visibleChildren$$inlined$sortedBy$1)
.class public final Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$visibleChildren$$inlined$sortedBy$1;
.super Ljava/lang/Object;
.source "Comparisons.kt"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel;->visibleChildren(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Comparator;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nComparisons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Comparisons.kt\nkotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2\n+ 2 ExplorerPanel.kt\ncom/exampletest/mobilestudiotest/ui/ExplorerPanel\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,328:1\n157#2:329\n1#3:330\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $order$inlined:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .registers 2

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$visibleChildren$$inlined$sortedBy$1;->$order$inlined:Ljava/util/List;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 9
    .param p1, "a"    # Ljava/lang/Object;
    .param p2, "b"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)I"
        }
    .end annotation

    .line 102
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v0, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v1, 0x0

    .line 329
    .local v1, "$i$a$-sortedBy-ExplorerPanel$visibleChildren$2\\1\\102\\0":I
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$visibleChildren$$inlined$sortedBy$1;->$order$inlined:Ljava/util/List;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v2

    .line 330
    .local v2, "x\\2":I
    const/4 v3, 0x0

    .line 329
    .local v3, "$i$a$-let-ExplorerPanel$visibleChildren$2$1\\2\\329\\1":I
    const/16 v4, 0x3e7

    if-gez v2, :cond_14

    move v2, v4

    .end local v2    # "x\\2":I
    .end local v3    # "$i$a$-let-ExplorerPanel$visibleChildren$2$1\\2\\329\\1":I
    :cond_14
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    .line 102
    .end local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v1    # "$i$a$-sortedBy-ExplorerPanel$visibleChildren$2\\1\\102\\0":I
    check-cast v2, Ljava/lang/Comparable;

    move-object v0, p2

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v0, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v1, 0x0

    .line 329
    .local v1, "$i$a$-sortedBy-ExplorerPanel$visibleChildren$2\\3\\102\\0":I
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ExplorerPanel$visibleChildren$$inlined$sortedBy$1;->$order$inlined:Ljava/util/List;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v3, v5}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v3

    .line 330
    .local v3, "x\\3":I
    const/4 v5, 0x0

    .line 329
    .local v5, "$i$a$-let-ExplorerPanel$visibleChildren$2$1\\4\\330\\3":I
    if-ltz v3, :cond_2c

    move v4, v3

    .end local v3    # "x\\3":I
    .end local v5    # "$i$a$-let-ExplorerPanel$visibleChildren$2$1\\4\\330\\3":I
    :cond_2c
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    .line 102
    .end local v0    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v1    # "$i$a$-sortedBy-ExplorerPanel$visibleChildren$2\\3\\102\\0":I
    check-cast v3, Ljava/lang/Comparable;

    invoke-static {v2, v3}, Lkotlin/comparisons/ComparisonsKt;->compareValues(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    move-result v0

    return v0
.end method
