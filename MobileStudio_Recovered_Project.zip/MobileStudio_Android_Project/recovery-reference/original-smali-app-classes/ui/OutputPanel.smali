###### Class com.exampletest.mobilestudiotest.ui.OutputPanel (com.exampletest.mobilestudiotest.ui.OutputPanel)
.class public final Lcom/exampletest/mobilestudiotest/ui/OutputPanel;
.super Landroid/widget/LinearLayout;
.source "OutputPanel.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nOutputPanel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OutputPanel.kt\ncom/exampletest/mobilestudiotest/ui/OutputPanel\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,108:1\n1#2:109\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0006\u0008\u0007\u0018\u00002\u00020\u0001:\u0001\u001fB\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0008\u0010\u001b\u001a\u00020\u001aH\u0014J\u0008\u0010\u001c\u001a\u00020\u001aH\u0014J\u0008\u0010\u001d\u001a\u00020\u001aH\u0002J\u0008\u0010\u001e\u001a\u00020\u001aH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0008\u001a\u0012\u0012\u0004\u0012\u00020\n0\tj\u0008\u0012\u0004\u0012\u00020\n`\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u000e\u001a\u00060\u000fR\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0014\u001a\u0012\u0012\u0004\u0012\u00020\u00150\tj\u0008\u0012\u0004\u0012\u00020\u0015`\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0018\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\n\u0012\u0004\u0012\u00020\u001a0\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006 "
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/OutputPanel;",
        "Landroid/widget/LinearLayout;",
        "ctx",
        "Landroid/content/Context;",
        "studio",
        "Lcom/exampletest/mobilestudiotest/core/Studio;",
        "<init>",
        "(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V",
        "entries",
        "Ljava/util/ArrayList;",
        "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
        "Lkotlin/collections/ArrayList;",
        "list",
        "Landroidx/recyclerview/widget/RecyclerView;",
        "adapter",
        "Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;",
        "fmt",
        "Ljava/text/SimpleDateFormat;",
        "pending",
        "",
        "history",
        "",
        "historyIdx",
        "",
        "listener",
        "Lkotlin/Function1;",
        "",
        "onAttachedToWindow",
        "onDetachedFromWindow",
        "schedule",
        "reload",
        "Adapter",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final adapter:Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;

.field private final entries:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private final fmt:Ljava/text/SimpleDateFormat;

.field private final history:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private historyIdx:I

.field private final list:Landroidx/recyclerview/widget/RecyclerView;

.field private final listener:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private pending:Z

.field private final studio:Lcom/exampletest/mobilestudiotest/core/Studio;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V
    .registers 15
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "studio"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    .line 21
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->entries:Ljava/util/ArrayList;

    .line 22
    new-instance v0, Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {v0, p1}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    .line 23
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;-><init>(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;

    .line 24
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "HH:mm:ss.SSS"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->fmt:Ljava/text/SimpleDateFormat;

    .line 26
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->history:Ljava/util/ArrayList;

    .line 29
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->listener:Lkotlin/jvm/functions/Function1;

    .line 31
    nop

    .line 32
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->setOrientation(I)V

    .line 33
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getPANEL()I

    move-result v1

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->setBackgroundColor(I)V

    .line 34
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v4, "Output"

    const/4 v5, 0x0

    move-object v3, p1

    .end local p1    # "ctx":Landroid/content/Context;
    .local v3, "ctx":Landroid/content/Context;
    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general$default(Lcom/exampletest/mobilestudiotest/ui/Icons;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const-string v2, "Output"

    invoke-virtual {v1, v3, v2, p1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->header(Landroid/content/Context;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)Landroid/widget/LinearLayout;

    move-result-object p1

    .line 35
    .local p1, "h":Landroid/widget/LinearLayout;
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const-string v4, "Cleanup"

    const-string v5, "Clr"

    invoke-virtual {v1, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda2;

    invoke-direct {v6}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda2;-><init>()V

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/ImageView;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 36
    move-object v1, p1

    check-cast v1, Landroid/view/View;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 37
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v2, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v2, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    .line 109
    move-object v4, v2

    .local v4, "$this$_init__u24lambda_u242\\1":Landroidx/recyclerview/widget/LinearLayoutManager;
    const/4 v5, 0x0

    .line 37
    .local v5, "$i$a$-apply-OutputPanel$2\\1\\37\\0":I
    invoke-virtual {v4, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->setStackFromEnd(Z)V

    .end local v4    # "$this$_init__u24lambda_u242\\1":Landroidx/recyclerview/widget/LinearLayoutManager;
    .end local v5    # "$i$a$-apply-OutputPanel$2\\1\\37\\0":I
    check-cast v2, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 38
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;

    check-cast v1, Landroidx/recyclerview/widget/RecyclerView$Adapter;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 39
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    .line 40
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    check-cast v0, Landroid/view/View;

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v2, -0x1

    const/4 v10, 0x0

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-virtual {v1, v2, v10, v11}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 42
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .line 109
    .local v1, "$this$_init__u24lambda_u243\\2":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 42
    .local v2, "$i$a$-apply-OutputPanel$bar$1\\2\\42\\0":I
    invoke-virtual {v1, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getHEADER()I

    move-result v4

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 43
    .end local v1    # "$this$_init__u24lambda_u243\\2":Landroid/widget/LinearLayout;
    .end local v2    # "$i$a$-apply-OutputPanel$bar$1\\2\\42\\0":I
    .local v0, "bar":Landroid/widget/LinearLayout;
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/16 v8, 0x18

    const-string v4, ""

    const-string v5, "Run a command (Lua)"

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v2 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->input$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZILjava/lang/Object;)Landroid/widget/EditText;

    move-result-object v1

    .line 44
    .local v1, "cmd":Landroid/widget/EditText;
    sget-object v2, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setTypeface(Landroid/graphics/Typeface;)V

    .line 45
    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setTextSize(F)V

    .line 46
    const/4 v2, 0x2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setImeOptions(I)V

    .line 54
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda3;

    invoke-direct {v2, v1, p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda3;-><init>(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    .line 57
    move-object v2, v1

    check-cast v2, Landroid/view/View;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v5, -0x2

    invoke-virtual {v4, v10, v5, v11}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 58
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const-string v5, "Back"

    const-string v6, "Prev"

    invoke-virtual {v4, v3, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda4;

    invoke-direct {v6, p0, v1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/widget/EditText;)V

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/ImageView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 61
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    const-string v5, "RunScript"

    const-string v6, "Run"

    invoke-virtual {v4, v3, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/Icons;->general(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda5;

    invoke-direct {v6, v1, p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda5;-><init>(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V

    const/4 v5, 0x0

    invoke-static/range {v2 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/ImageView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 62
    move-object v2, v0

    check-cast v2, Landroid/view/View;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v8, 0x4

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v2, v4}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 63
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->reload()V

    .line 64
    .end local v0    # "bar":Landroid/widget/LinearLayout;
    .end local v1    # "cmd":Landroid/widget/EditText;
    .end local p1    # "h":Landroid/widget/LinearLayout;
    nop

    .line 20
    return-void
.end method

.method static final _init_$lambda$1(Landroid/view/View;)Lkotlin/Unit;
    .registers 2
    .param p0, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->clear()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$4(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .registers 8
    .param p0, "$cmd"    # Landroid/widget/EditText;
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;
    .param p3, "id"    # I
    .param p4, "ev"    # Landroid/view/KeyEvent;

    .line 55
    const/4 p2, 0x2

    const/4 v0, 0x1

    if-eq p3, p2, :cond_1c

    const/4 p2, 0x0

    if-eqz p4, :cond_11

    invoke-virtual {p4}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v1

    const/16 v2, 0x42

    if-ne v1, v2, :cond_11

    move v1, v0

    goto :goto_12

    :cond_11
    move v1, p2

    :goto_12
    if-eqz v1, :cond_1a

    invoke-virtual {p4}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    if-eqz v1, :cond_1c

    :cond_1a
    move v0, p2

    goto :goto_1f

    :cond_1c
    invoke-static {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->_init_$run(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V

    :goto_1f
    return v0
.end method

.method static final _init_$lambda$5(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/widget/EditText;Landroid/view/View;)Lkotlin/Unit;
    .registers 5
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;
    .param p1, "$cmd"    # Landroid/widget/EditText;
    .param p2, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->history:Ljava/util/ArrayList;

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_32

    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->historyIdx:I

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->historyIdx:I

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->history:Ljava/util/ArrayList;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->historyIdx:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-interface {v0}, Landroid/text/Editable;->length()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setSelection(I)V

    .line 60
    :cond_32
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$6(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/view/View;)Lkotlin/Unit;
    .registers 4
    .param p0, "$cmd"    # Landroid/widget/EditText;
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;
    .param p2, "it"    # Landroid/view/View;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    invoke-static {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->_init_$run(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final _init_$run(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V
    .registers 4
    .param p0, "cmd"    # Landroid/widget/EditText;
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    .line 48
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 49
    .local v0, "code":Ljava/lang/String;
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_12

    return-void

    .line 50
    :cond_12
    iget-object v1, p1, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->history:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p1, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->history:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    iput v1, p1, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->historyIdx:I

    .line 51
    const-string v1, ""

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {p0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 52
    iget-object v1, p1, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->runCommand(Ljava/lang/String;)V

    .line 53
    return-void
.end method

.method public static final synthetic access$getEntries$p(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)Ljava/util/ArrayList;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    .line 19
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->entries:Ljava/util/ArrayList;

    return-object v0
.end method

.method public static final synthetic access$getFmt$p(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)Ljava/text/SimpleDateFormat;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    .line 19
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->fmt:Ljava/text/SimpleDateFormat;

    return-object v0
.end method

.method static final listener$lambda$0(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;)Lkotlin/Unit;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;
    .param p1, "it"    # Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;

    .line 29
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->schedule()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final reload()V
    .registers 3

    .line 76
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->entries:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 77
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->entries:Ljava/util/ArrayList;

    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->snapshot()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 78
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->adapter:Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;->notifyDataSetChanged()V

    .line 79
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->entries:Ljava/util/ArrayList;

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2e

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->list:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->entries:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    .line 80
    :cond_2e
    return-void
.end method

.method private final schedule()V
    .registers 4

    .line 70
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->pending:Z

    if-eqz v0, :cond_5

    return-void

    .line 71
    :cond_5
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->pending:Z

    .line 72
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V

    const-wide/16 v1, 0x64

    invoke-virtual {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 73
    return-void
.end method

.method static final schedule$lambda$7(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    .line 72
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->pending:Z

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->reload()V

    return-void
.end method


# virtual methods
.method protected onAttachedToWindow()V
    .registers 3

    .line 66
    invoke-super {p0}, Landroid/widget/LinearLayout;->onAttachedToWindow()V

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->getListeners()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->listener:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->reload()V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 3

    .line 67
    invoke-super {p0}, Landroid/widget/LinearLayout;->onDetachedFromWindow()V

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->getListeners()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->listener:Lkotlin/jvm/functions/Function1;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel.Adapter (com.exampletest.mobilestudiotest.ui.OutputPanel$Adapter)
.class final Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "OutputPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/OutputPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Adapter"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
        "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0003\u0008\u0082\u0004\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0003\u0010\u0004J\u0008\u0010\u0005\u001a\u00020\u0006H\u0016J\u0018\u0010\u0007\u001a\u00020\u00022\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0006H\u0016J\u0018\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u0006H\u0016\u00a8\u0006\u000f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;",
        "Landroidx/recyclerview/widget/RecyclerView$Adapter;",
        "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V",
        "getItemCount",
        "",
        "onCreateViewHolder",
        "parent",
        "Landroid/view/ViewGroup;",
        "viewType",
        "onBindViewHolder",
        "",
        "h",
        "position",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V
    .registers 2
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/OutputPanel;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 82
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    return-void
.end method


# virtual methods
.method public getItemCount()I
    .registers 2

    .line 83
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->access$getEntries$p(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .registers 9
    .param p1, "h"    # Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .param p2, "position"    # I

    const-string v0, "h"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->access$getEntries$p(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const-string v1, "get(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;

    .line 97
    .local v0, "e":Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;
    iget-object v1, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    const-string v2, "null cannot be cast to non-null type android.widget.TextView"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Landroid/widget/TextView;

    .line 98
    .local v1, "t":Landroid/widget/TextView;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;->this$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->access$getFmt$p(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)Ljava/text/SimpleDateFormat;

    move-result-object v2

    new-instance v3, Ljava/util/Date;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->getTime()J

    move-result-wide v4

    invoke-direct {v3, v4, v5}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v2, v3}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->getText()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "  "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 99
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->getLevel()Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    move-result-object v2

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ordinal()I

    move-result v2

    aget v2, v3, v2

    packed-switch v2, :pswitch_data_7c

    new-instance v2, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v2}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v2

    .line 103
    :pswitch_67
    const v2, -0xaaab

    goto :goto_78

    .line 102
    :pswitch_6b
    const/16 v2, -0x5b00

    goto :goto_78

    .line 101
    :pswitch_6e
    const v2, -0x934901

    goto :goto_78

    .line 100
    :pswitch_72
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getTEXT()I

    move-result v2

    .line 99
    :goto_78
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 105
    return-void

    :pswitch_data_7c
    .packed-switch 0x1
        :pswitch_72
        :pswitch_6e
        :pswitch_6b
        :pswitch_67
    .end packed-switch
.end method

.method public onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .registers 13
    .param p1, "parent"    # Landroid/view/ViewGroup;
    .param p2, "viewType"    # I

    const-string v0, "parent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v0, "getContext(...)"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v7, 0x18

    const/4 v8, 0x0

    const-string v3, ""

    const/high16 v4, 0x41400000    # 12.0f

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v1

    move-object v2, v1

    .local v2, "$this$onCreateViewHolder_u24lambda_u240\\1":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 86
    .local v3, "$i$a$-apply-OutputPanel$Adapter$onCreateViewHolder$t$1\\1\\85\\0":I
    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 87
    sget-object v4, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 88
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v6, 0x41000000    # 8.0f

    invoke-virtual {v4, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-virtual {v5, v7, v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v9

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v7, v9, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v9

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v7, v9, v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {v2, v4, v5, v6, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 89
    const/4 v0, 0x1

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextIsSelectable(Z)V

    .line 90
    new-instance v0, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;

    const/4 v4, -0x1

    const/4 v5, -0x2

    invoke-direct {v0, v4, v5}, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;-><init>(II)V

    check-cast v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 91
    nop

    .line 85
    .end local v2    # "$this$onCreateViewHolder_u24lambda_u240\\1":Landroid/widget/TextView;
    .end local v3    # "$i$a$-apply-OutputPanel$Adapter$onCreateViewHolder$t$1\\1\\85\\0":I
    nop

    .line 92
    .local v1, "t":Landroid/widget/TextView;
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter$onCreateViewHolder$1;

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter$onCreateViewHolder$1;-><init>(Landroid/widget/TextView;)V

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel.Adapter.WhenMappings (com.exampletest.mobilestudiotest.ui.OutputPanel$Adapter$WhenMappings)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter$WhenMappings;
.super Ljava/lang/Object;
.source "OutputPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1019
    name = "WhenMappings"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    invoke-static {}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->values()[Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_7
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->PRINT:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_10} :catch_11

    goto :goto_12

    :catch_11
    move-exception v1

    :goto_12
    :try_start_12
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->INFO:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_1b} :catch_1c

    goto :goto_1d

    :catch_1c
    move-exception v1

    :goto_1d
    :try_start_1d
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->WARN:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_26
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1d .. :try_end_26} :catch_27

    goto :goto_28

    :catch_27
    move-exception v1

    :goto_28
    :try_start_28
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ERROR:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_31
    .catch Ljava/lang/NoSuchFieldError; {:try_start_28 .. :try_end_31} :catch_32

    goto :goto_33

    :catch_32
    move-exception v1

    :goto_33
    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter$WhenMappings;->$EnumSwitchMapping$0:[I

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel$Adapter$onCreateViewHolder$1 (com.exampletest.mobilestudiotest.ui.OutputPanel$Adapter$onCreateViewHolder$1)
.class public final Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter$onCreateViewHolder$1;
.super Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
.source "OutputPanel.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/OutputPanel$Adapter;->onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/ui/OutputPanel$Adapter$onCreateViewHolder$1",
        "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method constructor <init>(Landroid/widget/TextView;)V
    .registers 3
    .param p1, "$t"    # Landroid/widget/TextView;

    .line 92
    move-object v0, p1

    check-cast v0, Landroid/view/View;

    invoke-direct {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/OutputPanel;"
    method = "schedule$lambda$7"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->schedule$lambda$7(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/OutputPanel;"
    method = "listener$lambda$0"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    check-cast p1, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->listener$lambda$0(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/OutputPanel;"
    method = "_init_$lambda$1"
    proto = "(Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Landroid/view/View;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->_init_$lambda$1(Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/TextView$OnEditorActionListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/OutputPanel;"
    method = "_init_$lambda$4"
    proto = "(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda3;->f$0:Landroid/widget/EditText;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda3;->f$1:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    return-void
.end method


# virtual methods
.method public final onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda3;->f$0:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda3;->f$1:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    invoke-static {v0, v1, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->_init_$lambda$4(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/OutputPanel;"
    method = "_init_$lambda$5"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/widget/EditText;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

.field public final synthetic f$1:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/widget/EditText;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda4;->f$1:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda4;->f$1:Landroid/widget/EditText;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->_init_$lambda$5(Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/widget/EditText;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.ui.OutputPanel$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/OutputPanel;"
    method = "_init_$lambda$6"
    proto = "(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/view/View;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda5;->f$0:Landroid/widget/EditText;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda5;->f$1:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda5;->f$0:Landroid/widget/EditText;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/OutputPanel$$ExternalSyntheticLambda5;->f$1:Lcom/exampletest/mobilestudiotest/ui/OutputPanel;

    check-cast p1, Landroid/view/View;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/ui/OutputPanel;->_init_$lambda$6(Landroid/widget/EditText;Lcom/exampletest/mobilestudiotest/ui/OutputPanel;Landroid/view/View;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
