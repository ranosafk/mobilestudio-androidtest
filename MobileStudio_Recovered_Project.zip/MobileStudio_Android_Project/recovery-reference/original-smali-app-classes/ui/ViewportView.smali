###### Class com.exampletest.mobilestudiotest.ui.ViewportView (com.exampletest.mobilestudiotest.ui.ViewportView)
.class public final Lcom/exampletest/mobilestudiotest/ui/ViewportView;
.super Landroid/widget/FrameLayout;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0005\u0008\u0007\u0018\u0000 %2\u00020\u0001:\u0003$%&B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0006\u0010!\u001a\u00020\"J\u0006\u0010#\u001a\u00020\"R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0008\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u0011\u0010\u000c\u001a\u00020\r\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u000fR\u0011\u0010\u0010\u001a\u00020\u0011\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0013R\u0015\u0010\u0014\u001a\u00060\u0015R\u00020\u0000\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0017R\u0011\u0010\u0018\u001a\u00020\u0019\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001a\u0010\u001bR\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001dX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\'"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "Landroid/widget/FrameLayout;",
        "ctx",
        "Landroid/content/Context;",
        "studio",
        "Lcom/exampletest/mobilestudiotest/core/Studio;",
        "<init>",
        "(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V",
        "gl",
        "Landroid/opengl/GLSurfaceView;",
        "getGl",
        "()Landroid/opengl/GLSurfaceView;",
        "renderer",
        "Lcom/exampletest/mobilestudiotest/render/SceneRenderer;",
        "getRenderer",
        "()Lcom/exampletest/mobilestudiotest/render/SceneRenderer;",
        "gui",
        "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;",
        "getGui",
        "()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;",
        "controls",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "getControls",
        "()Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "hud",
        "Lcom/exampletest/mobilestudiotest/ui/PlayHud;",
        "getHud",
        "()Lcom/exampletest/mobilestudiotest/ui/PlayHud;",
        "lastOverlay",
        "",
        "lastControls",
        "hudPosted",
        "",
        "onResume",
        "",
        "onPause",
        "MsaaConfigChooser",
        "Companion",
        "TouchLayer",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;

.field private static volatile depthBits:I


# instance fields
.field private final controls:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

.field private final gl:Landroid/opengl/GLSurfaceView;

.field private final gui:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

.field private final hud:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

.field private hudPosted:Z

.field private lastControls:J

.field private lastOverlay:J

.field private final renderer:Lcom/exampletest/mobilestudiotest/render/SceneRenderer;

.field private final studio:Lcom/exampletest/mobilestudiotest/core/Studio;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->Companion:Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;

    .line 100
    const/16 v0, 0x10

    sput v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->depthBits:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V
    .registers 6
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "studio"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    .line 33
    new-instance v0, Landroid/opengl/GLSurfaceView;

    invoke-direct {v0, p1}, Landroid/opengl/GLSurfaceView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    .line 34
    new-instance v0, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;-><init>(Lcom/exampletest/mobilestudiotest/core/Studio;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->renderer:Lcom/exampletest/mobilestudiotest/render/SceneRenderer;

    .line 35
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-direct {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;-><init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gui:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    .line 36
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {v0, p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->controls:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    .line 37
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-direct {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;-><init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->hud:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 42
    nop

    .line 43
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/opengl/GLSurfaceView;->setEGLContextClientVersion(I)V

    .line 44
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;-><init>()V

    check-cast v1, Landroid/opengl/GLSurfaceView$EGLConfigChooser;

    invoke-virtual {v0, v1}, Landroid/opengl/GLSurfaceView;->setEGLConfigChooser(Landroid/opengl/GLSurfaceView$EGLConfigChooser;)V

    .line 45
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/opengl/GLSurfaceView;->setPreserveEGLContextOnPause(Z)V

    .line 46
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->renderer:Lcom/exampletest/mobilestudiotest/render/SceneRenderer;

    check-cast v2, Landroid/opengl/GLSurfaceView$Renderer;

    invoke-virtual {v0, v2}, Landroid/opengl/GLSurfaceView;->setRenderer(Landroid/opengl/GLSurfaceView$Renderer;)V

    .line 47
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v0, v1}, Landroid/opengl/GLSurfaceView;->setRenderMode(I)V

    .line 48
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    check-cast v0, Landroid/view/View;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 49
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gui:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    check-cast v0, Landroid/view/View;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 50
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->controls:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    check-cast v0, Landroid/view/View;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 51
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->hud:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    check-cast v0, Landroid/view/View;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 52
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->renderer:Lcom/exampletest/mobilestudiotest/render/SceneRenderer;

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->setOnFrame(Lkotlin/jvm/functions/Function0;)V

    .line 64
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->renderer:Lcom/exampletest/mobilestudiotest/render/SceneRenderer;

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->setSurfacePainter(Lkotlin/jvm/functions/Function4;)V

    .line 65
    nop

    .line 32
    return-void
.end method

.method static final _init_$lambda$1(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lkotlin/Unit;
    .registers 10
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 53
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 54
    .local v0, "now":J
    iget-wide v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->lastOverlay:J

    sub-long v2, v0, v2

    const-wide/16 v4, 0x21

    cmp-long v2, v2, v4

    if-lez v2, :cond_98

    .line 55
    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->lastOverlay:J

    .line 56
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v2

    const-string v3, "CoreGui"

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_30

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v2

    if-eqz v2, :cond_30

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    xor-int/2addr v2, v4

    if-ne v2, v4, :cond_30

    move v3, v4

    .line 57
    .local v3, "core":Z
    :cond_30
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gui:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->getHasContent()Z

    move-result v2

    if-nez v2, :cond_59

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v2

    if-nez v2, :cond_59

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPluginWidgets()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_59

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gui:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->getSelectedGui()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    if-nez v2, :cond_59

    if-nez v3, :cond_59

    goto :goto_5e

    :cond_59
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gui:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->postInvalidate()V

    .line 60
    :goto_5e
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v2

    if-nez v2, :cond_79

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->controls:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getBusy()Z

    move-result v2

    if-nez v2, :cond_79

    iget-wide v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->lastControls:J

    sub-long v5, v0, v5

    const-wide/16 v7, 0x1f4

    cmp-long v2, v5, v7

    if-gtz v2, :cond_79

    goto :goto_80

    :cond_79
    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->lastControls:J

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->controls:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->postInvalidate()V

    .line 61
    :goto_80
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v2

    if-eqz v2, :cond_98

    iget-boolean v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->hudPosted:Z

    if-nez v2, :cond_98

    iput-boolean v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->hudPosted:Z

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->hud:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda2;

    invoke-direct {v4, p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->post(Ljava/lang/Runnable;)Z

    .line 63
    .end local v3    # "core":Z
    :cond_98
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method static final _init_$lambda$2(Lcom/exampletest/mobilestudiotest/ui/ViewportView;Lcom/exampletest/mobilestudiotest/model/Instance;FFLandroid/graphics/Bitmap;)Lkotlin/Unit;
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;
    .param p1, "g"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "w"    # F
    .param p3, "h"    # F
    .param p4, "bmp"    # Landroid/graphics/Bitmap;

    const-string v0, "g"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bmp"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gui:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->renderSurface(Lcom/exampletest/mobilestudiotest/model/Instance;FFLandroid/graphics/Bitmap;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$getDepthBits$cp()I
    .registers 1

    .line 31
    sget v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->depthBits:I

    return v0
.end method

.method public static final synthetic access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 31
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    return-object v0
.end method

.method public static final synthetic access$setDepthBits$cp(I)V
    .registers 1
    .param p0, "<set-?>"    # I

    .line 31
    sput p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->depthBits:I

    return-void
.end method

.method static final lambda$1$lambda$0(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 61
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->hudPosted:Z

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->hud:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->onFrame()V

    return-void
.end method


# virtual methods
.method public final getControls()Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .registers 2

    .line 36
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->controls:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    return-object v0
.end method

.method public final getGl()Landroid/opengl/GLSurfaceView;
    .registers 2

    .line 33
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    return-object v0
.end method

.method public final getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;
    .registers 2

    .line 35
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gui:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    return-object v0
.end method

.method public final getHud()Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .registers 2

    .line 37
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->hud:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-object v0
.end method

.method public final getRenderer()Lcom/exampletest/mobilestudiotest/render/SceneRenderer;
    .registers 2

    .line 34
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->renderer:Lcom/exampletest/mobilestudiotest/render/SceneRenderer;

    return-object v0
.end method

.method public final onPause()V
    .registers 2

    .line 68
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v0}, Landroid/opengl/GLSurfaceView;->onPause()V

    return-void
.end method

.method public final onResume()V
    .registers 2

    .line 67
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->gl:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v0}, Landroid/opengl/GLSurfaceView;->onResume()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.Companion (com.exampletest.mobilestudiotest.ui.ViewportView$Companion)
.class public final Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;
.super Ljava/lang/Object;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0005\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\"\u0004\u0008\u0008\u0010\t\u00a8\u0006\n"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;",
        "",
        "<init>",
        "()V",
        "depthBits",
        "",
        "getDepthBits",
        "()I",
        "setDepthBits",
        "(I)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 98
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final getDepthBits()I
    .registers 2

    .line 100
    invoke-static {}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getDepthBits$cp()I

    move-result v0

    return v0
.end method

.method public final setDepthBits(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 100
    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$setDepthBits$cp(I)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.MsaaConfigChooser (com.exampletest.mobilestudiotest.ui.ViewportView$MsaaConfigChooser)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;
.super Ljava/lang/Object;
.source "ViewportView.kt"

# interfaces
.implements Landroid/opengl/GLSurfaceView$EGLConfigChooser;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "MsaaConfigChooser"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nViewportView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ViewportView.kt\ncom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,926:1\n1310#2,2:927\n*S KotlinDebug\n*F\n+ 1 ViewportView.kt\ncom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser\n*L\n88#1:927,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0008\u0002\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\tH\u0016\u00a8\u0006\n"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;",
        "Landroid/opengl/GLSurfaceView$EGLConfigChooser;",
        "<init>",
        "()V",
        "chooseConfig",
        "Ljavax/microedition/khronos/egl/EGLConfig;",
        "egl",
        "Ljavax/microedition/khronos/egl/EGL10;",
        "display",
        "Ljavax/microedition/khronos/egl/EGLDisplay;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 76
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final chooseConfig$pick(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;II)Ljavax/microedition/khronos/egl/EGLConfig;
    .registers 18
    .param p0, "$egl"    # Ljavax/microedition/khronos/egl/EGL10;
    .param p1, "$display"    # Ljavax/microedition/khronos/egl/EGLDisplay;
    .param p2, "samples"    # I
    .param p3, "depth"    # I

    .line 79
    const/16 v0, 0xc

    new-array v0, v0, [Ljava/lang/Integer;

    const/16 v1, 0x3024

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    const/16 v1, 0x8

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x1

    aput-object v3, v0, v4

    const/16 v5, 0x3023

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v6, 0x2

    aput-object v5, v0, v6

    const/4 v5, 0x3

    aput-object v3, v0, v5

    const/16 v7, 0x3022

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v8, 0x4

    aput-object v7, v0, v8

    const/4 v7, 0x5

    aput-object v3, v0, v7

    const/16 v7, 0x3021

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v9, 0x6

    aput-object v7, v0, v9

    const/4 v7, 0x7

    aput-object v3, v0, v7

    .line 80
    const/16 v3, 0x3025

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v0, v1

    .line 79
    nop

    .line 80
    invoke-static/range {p3 .. p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/16 v3, 0x9

    aput-object v1, v0, v3

    .line 79
    nop

    .line 80
    const/16 v1, 0x3040

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/16 v3, 0xa

    aput-object v1, v0, v3

    .line 79
    nop

    .line 80
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/16 v3, 0xb

    aput-object v1, v0, v3

    .line 79
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->mutableListOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .line 81
    .local v0, "attrs":Ljava/util/List;
    if-lez p2, :cond_8f

    move-object v1, v0

    check-cast v1, Ljava/util/Collection;

    new-array v3, v8, [Ljava/lang/Integer;

    const/16 v7, 0x3032

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v3, v2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v3, v4

    const/16 v7, 0x3031

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v3, v6

    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v3, v5

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v1, v3}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .line 82
    :cond_8f
    move-object v1, v0

    check-cast v1, Ljava/util/Collection;

    const/16 v3, 0x3038

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 83
    move-object v1, v0

    check-cast v1, Ljava/util/Collection;

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->toIntArray(Ljava/util/Collection;)[I

    move-result-object v7

    .line 84
    .local v7, "arr":[I
    new-array v10, v4, [I

    .line 85
    .local v10, "n":[I
    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v5, p0

    move-object v6, p1

    invoke-interface/range {v5 .. v10}, Ljavax/microedition/khronos/egl/EGL10;->eglChooseConfig(Ljavax/microedition/khronos/egl/EGLDisplay;[I[Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    move-result v1

    const/4 v3, 0x0

    if-eqz v1, :cond_d6

    aget v1, v10, v2

    if-lez v1, :cond_d6

    .line 86
    aget v1, v10, v2

    new-array v8, v1, [Ljavax/microedition/khronos/egl/EGLConfig;

    .line 87
    .local v8, "configs":[Ljavax/microedition/khronos/egl/EGLConfig;
    aget v9, v10, v2

    move-object v5, p0

    move-object v6, p1

    invoke-interface/range {v5 .. v10}, Ljavax/microedition/khronos/egl/EGL10;->eglChooseConfig(Ljavax/microedition/khronos/egl/EGLDisplay;[I[Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    .line 88
    move-object v1, v8

    .local v1, "$this$firstOrNull\\1":[Ljava/lang/Object;
    const/4 v5, 0x0

    .line 927
    .local v5, "$i$f$firstOrNull\\1\\88":I
    array-length v6, v1

    move v9, v2

    :goto_c2
    if-ge v9, v6, :cond_d4

    aget-object v11, v1, v9

    .local v11, "element\\1":Ljava/lang/Object;
    move-object v12, v11

    .local v12, "it\\2":Ljavax/microedition/khronos/egl/EGLConfig;
    const/4 v13, 0x0

    .line 88
    .local v13, "$i$a$-firstOrNull-ViewportView$MsaaConfigChooser$chooseConfig$pick$1\\2\\927\\0":I
    if-eqz v12, :cond_cc

    move v12, v4

    goto :goto_cd

    :cond_cc
    move v12, v2

    .line 927
    .end local v12    # "it\\2":Ljavax/microedition/khronos/egl/EGLConfig;
    .end local v13    # "$i$a$-firstOrNull-ViewportView$MsaaConfigChooser$chooseConfig$pick$1\\2\\927\\0":I
    :goto_cd
    if-eqz v12, :cond_d1

    move-object v3, v11

    goto :goto_d5

    .end local v11    # "element\\1":Ljava/lang/Object;
    :cond_d1
    add-int/lit8 v9, v9, 0x1

    goto :goto_c2

    .line 928
    :cond_d4
    nop

    .line 88
    .end local v1    # "$this$firstOrNull\\1":[Ljava/lang/Object;
    .end local v5    # "$i$f$firstOrNull\\1\\88":I
    :goto_d5
    return-object v3

    .line 85
    .end local v8    # "configs":[Ljavax/microedition/khronos/egl/EGLConfig;
    :cond_d6
    return-object v3
.end method


# virtual methods
.method public chooseConfig(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;)Ljavax/microedition/khronos/egl/EGLConfig;
    .registers 8
    .param p1, "egl"    # Ljavax/microedition/khronos/egl/EGL10;
    .param p2, "display"    # Ljavax/microedition/khronos/egl/EGLDisplay;

    const-string v0, "egl"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "display"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    const/4 v0, 0x4

    const/16 v1, 0x18

    invoke-static {p1, p2, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;->chooseConfig$pick(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;II)Ljavax/microedition/khronos/egl/EGLConfig;

    move-result-object v2

    const/4 v3, 0x0

    if-nez v2, :cond_42

    const/4 v2, 0x2

    invoke-static {p1, p2, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;->chooseConfig$pick(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;II)Ljavax/microedition/khronos/egl/EGLConfig;

    move-result-object v4

    if-nez v4, :cond_41

    invoke-static {p1, p2, v3, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;->chooseConfig$pick(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;II)Ljavax/microedition/khronos/egl/EGLConfig;

    move-result-object v1

    if-nez v1, :cond_3f

    const/16 v1, 0x10

    invoke-static {p1, p2, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;->chooseConfig$pick(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;II)Ljavax/microedition/khronos/egl/EGLConfig;

    move-result-object v0

    if-nez v0, :cond_3d

    invoke-static {p1, p2, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;->chooseConfig$pick(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;II)Ljavax/microedition/khronos/egl/EGLConfig;

    move-result-object v2

    if-nez v2, :cond_42

    invoke-static {p1, p2, v3, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$MsaaConfigChooser;->chooseConfig$pick(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;II)Ljavax/microedition/khronos/egl/EGLConfig;

    move-result-object v2

    if-nez v2, :cond_42

    .line 91
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "No suitable EGL config"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 90
    :cond_3d
    move-object v2, v0

    goto :goto_42

    :cond_3f
    move-object v2, v1

    goto :goto_42

    :cond_41
    move-object v2, v4

    .line 92
    .local v2, "c":Ljavax/microedition/khronos/egl/EGLConfig;
    :cond_42
    :goto_42
    const/4 v0, 0x1

    new-array v0, v0, [I

    .line 93
    .local v0, "v":[I
    const/16 v1, 0x3025

    invoke-interface {p1, p2, v2, v1, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglGetConfigAttrib(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    move-result v1

    if-eqz v1, :cond_54

    sget-object v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->Companion:Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;

    aget v3, v0, v3

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$Companion;->setDepthBits(I)V

    .line 94
    :cond_54
    return-object v2
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer)
.class public final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.super Landroid/view/View;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "TouchLayer"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Sink;,
        Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nViewportView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ViewportView.kt\ncom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,926:1\n1#2:927\n1761#3,3:928\n1878#3,3:931\n808#3,11:934\n295#3,2:945\n2746#3,3:947\n1788#3,4:950\n2746#3,3:954\n774#3:957\n865#3,2:958\n808#3,11:960\n2746#3,3:971\n774#3:974\n865#3:975\n2746#3,3:976\n866#3:979\n1563#3:980\n1634#3,3:981\n1869#3,2:984\n1878#3,3:986\n1878#3,3:989\n1878#3,3:992\n1878#3,3:995\n1878#3,3:998\n1761#3,3:1001\n774#3:1004\n865#3,2:1005\n1563#3:1007\n1634#3,3:1008\n1869#3,2:1011\n1878#3,3:1013\n1878#3,3:1016\n*S KotlinDebug\n*F\n+ 1 ViewportView.kt\ncom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer\n*L\n150#1:928,3\n253#1:931,3\n282#1:934,11\n382#1:945,2\n416#1:947,3\n514#1:950,4\n543#1:954,3\n601#1:957\n601#1:958,2\n608#1:960,11\n639#1:971,3\n681#1:974\n681#1:975\n681#1:976,3\n681#1:979\n716#1:980\n716#1:981,3\n725#1:984,2\n750#1:986,3\n756#1:989,3\n761#1:992,3\n780#1:995,3\n790#1:998,3\n867#1:1001,3\n869#1:1004\n869#1:1005,2\n872#1:1007\n872#1:1008,3\n879#1:1011,2\n909#1:1013,3\n916#1:1016,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00b6\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0006\n\u0002\u0010\u0014\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0008\u000f\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0010\n\u0002\u0018\u0002\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010 \n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0011\u0008\u0086\u0004\u0018\u00002\u00020\u0001:\u000fstuvwxyz{|}~\u007f\u0080\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0010\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020.H\u0014J\u0010\u0010/\u001a\u00020,2\u0006\u0010-\u001a\u00020.H\u0002J\u0018\u00100\u001a\u00020,2\u0006\u0010-\u001a\u00020.2\u0006\u00101\u001a\u000202H\u0002J\u0010\u00103\u001a\u00020,2\u0006\u0010-\u001a\u00020.H\u0002J8\u00104\u001a\u00020,2\u0006\u00105\u001a\u00020.2\u0006\u00106\u001a\u00020\u001b2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u00072\u0006\u0010:\u001a\u00020\u0012H\u0002J8\u0010;\u001a\u00020,2\u0006\u00105\u001a\u00020.2\u0006\u00106\u001a\u00020\u001b2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u00072\u0006\u0010:\u001a\u00020\u0012H\u0002J8\u0010<\u001a\u00020,2\u0006\u00105\u001a\u00020.2\u0006\u00106\u001a\u00020\u001b2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u00072\u0006\u0010:\u001a\u00020\u0012H\u0002J@\u0010=\u001a\u00020,2\u0006\u00105\u001a\u00020.2\u0006\u00106\u001a\u00020\u001b2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u00072\u0006\u0010>\u001a\u00020\u00122\u0006\u0010:\u001a\u00020\u0012H\u0002J@\u0010?\u001a\u00020,2\u0006\u00105\u001a\u00020.2\u0006\u00106\u001a\u00020\u001b2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u00072\u0006\u0010@\u001a\u00020\u001b2\u0006\u0010:\u001a\u00020\u0012H\u0002J\u0010\u0010A\u001a\u00020\u00122\u0006\u0010B\u001a\u00020CH\u0017J \u0010F\u001a\u00020,2\u0006\u0010G\u001a\u00020\r2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0002J(\u0010H\u001a\u00020,2\u000e\u0010I\u001a\n0\u000eR\u00060\u0000R\u00020\u000f2\u0006\u0010J\u001a\u00020\u00072\u0006\u0010K\u001a\u00020\u0007H\u0002J(\u0010>\u001a\u00020,2\u0006\u0010G\u001a\u00020\r2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u00072\u0006\u0010L\u001a\u00020\u0012H\u0002J\u0018\u0010M\u001a\u00020,2\u000e\u0010I\u001a\n0NR\u00060\u0000R\u00020\u000fH\u0002J\u0018\u0010O\u001a\u00020,2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0002J\u0018\u0010P\u001a\u00020,2\u0006\u00106\u001a\u00020\u001b2\u0006\u0010F\u001a\u00020\u0012H\u0002J\u0008\u0010Q\u001a\u00020,H\u0002J\u0008\u0010R\u001a\u00020,H\u0002J\u0010\u0010S\u001a\u00020T2\u0006\u0010U\u001a\u00020TH\u0002J\u0018\u0010V\u001a\u00020,2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0002J\u0018\u0010W\u001a\u00020,2\u000e\u0010X\u001a\n0YR\u00060\u0000R\u00020\u000fH\u0002J/\u0010Z\u001a\u0004\u0018\u00010\u00072\u0006\u0010[\u001a\u00020\\2\u0006\u0010]\u001a\u00020\\2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0002\u00a2\u0006\u0002\u0010^J*\u0010_\u001a\u000c\u0018\u00010`R\u00060\u0000R\u00020\u000f2\u0006\u0010G\u001a\u00020\r2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0002J\u0018\u0010a\u001a\u00020\u00072\u0006\u0010b\u001a\u00020\u00072\u0006\u0010c\u001a\u00020\u0007H\u0002J\u0016\u0010d\u001a\u00020\u00122\u000c\u0010e\u001a\u0008\u0012\u0004\u0012\u00020T0fH\u0002J\u0018\u0010g\u001a\u00020,2\u000e\u0010I\u001a\n0`R\u00060\u0000R\u00020\u000fH\u0002J\u0018\u0010h\u001a\u00020,2\u000e\u0010I\u001a\n0`R\u00060\u0000R\u00020\u000fH\u0002J\u0012\u0010i\u001a\u0004\u0018\u00010j2\u0006\u0010k\u001a\u00020TH\u0002J*\u0010l\u001a\u000c\u0018\u00010mR\u00060\u0000R\u00020\u000f2\u0006\u0010G\u001a\u00020\r2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0002J\u0018\u0010n\u001a\u00020,2\u000e\u0010I\u001a\n0mR\u00060\u0000R\u00020\u000fH\u0002J*\u0010o\u001a\u000c\u0018\u00010pR\u00060\u0000R\u00020\u000f2\u0006\u0010G\u001a\u00020\r2\u0006\u00107\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0007H\u0002J\u0018\u0010q\u001a\u00020,2\u000e\u0010I\u001a\n0pR\u00060\u0000R\u00020\u000fH\u0002J\u0018\u0010r\u001a\u00020,2\u000e\u0010I\u001a\n0pR\u00060\u0000R\u00020\u000fH\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R:\u0010\u000b\u001a.\u0012\u0004\u0012\u00020\r\u0012\u000c\u0012\n0\u000eR\u00060\u0000R\u00020\u000f0\u000cj\u0016\u0012\u0004\u0012\u00020\r\u0012\u000c\u0012\n0\u000eR\u00060\u0000R\u00020\u000f`\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0011\u001a\u00020\u00128F\u00a2\u0006\u0006\u001a\u0004\u0008\u0013\u0010\u0014R\u000e\u0010\u0015\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u000e\u00a2\u0006\u0002\n\u0000R*\u0010\u001a\u001a\u001e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001c0\u000cj\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001c`\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001e\u001a\u00020\u00078BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u001f\u0010 R\u0014\u0010!\u001a\u00020\u00078BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\"\u0010 R\u0014\u0010#\u001a\u00020\u00078BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008$\u0010 R\u000e\u0010%\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\'\u001a\u00020\u00128BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008(\u0010\u0014R\u0014\u0010)\u001a\u00020\u00128BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008*\u0010\u0014R\u0014\u0010D\u001a\u00020\u00128BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008E\u0010\u0014\u00a8\u0006\u0081\u0001"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Landroid/view/View;",
        "ctx",
        "Landroid/content/Context;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView;Landroid/content/Context;)V",
        "d",
        "",
        "paint",
        "Landroid/graphics/Paint;",
        "text",
        "ptrs",
        "Ljava/util/HashMap;",
        "",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "Lkotlin/collections/HashMap;",
        "busy",
        "",
        "getBusy",
        "()Z",
        "joyX",
        "joyY",
        "pinchDist",
        "pinchMid",
        "",
        "buttons",
        "",
        "Landroid/graphics/RectF;",
        "jumpDown",
        "joyR",
        "getJoyR",
        "()F",
        "defaultJoyX",
        "getDefaultJoyX",
        "defaultJoyY",
        "getDefaultJoyY",
        "joyCx",
        "joyCy",
        "activeJoy",
        "getActiveJoy",
        "fixedStick",
        "getFixedStick",
        "onDraw",
        "",
        "canvas",
        "Landroid/graphics/Canvas;",
        "drawThumbstick",
        "drawPlayControls",
        "play",
        "Lcom/exampletest/mobilestudiotest/engine/PlaySession;",
        "drawEditControls",
        "insideIconButton",
        "c",
        "name",
        "x",
        "y",
        "r",
        "active",
        "boxIconButton",
        "multiIconButton",
        "arrowButton",
        "up",
        "circleButton",
        "label",
        "onTouchEvent",
        "e",
        "Landroid/view/MotionEvent;",
        "additive",
        "getAdditive",
        "down",
        "id",
        "move",
        "p",
        "nx",
        "ny",
        "cancel",
        "finishGuiDrag",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;",
        "setJoy",
        "pressButton",
        "resetPinch",
        "camGesture",
        "selectTarget",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "part",
        "tap",
        "finishBox",
        "b",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;",
        "axisParam",
        "center",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "axis",
        "(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FF)Ljava/lang/Float;",
        "tryStartDrag",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;",
        "snap",
        "v",
        "step",
        "overlapsOthers",
        "parts",
        "",
        "updateDrag",
        "finishDrag",
        "runtimeFor",
        "Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;",
        "a",
        "tryStartAdorn",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;",
        "dragAdorn",
        "tryStartPartDrag",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;",
        "updatePartDrag",
        "finishPartDrag",
        "Ptr",
        "Joy",
        "Btn",
        "Cam",
        "GuiPress",
        "GuiScroll",
        "GuiDrag",
        "Sink",
        "PluginWheel",
        "Drag",
        "PartDrag",
        "BoxSel",
        "PluginPtr",
        "AdornDrag",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final buttons:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Landroid/graphics/RectF;",
            ">;"
        }
    .end annotation
.end field

.field private final d:F

.field private joyCx:F

.field private joyCy:F

.field private joyX:F

.field private joyY:F

.field private jumpDown:Z

.field private final paint:Landroid/graphics/Paint;

.field private pinchDist:F

.field private pinchMid:[F

.field private final ptrs:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
            ">;"
        }
    .end annotation
.end field

.field private final text:Landroid/graphics/Paint;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;Landroid/content/Context;)V
    .registers 8
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;
    .param p2, "ctx"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    const-string v0, "ctx"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 103
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 104
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    .line 105
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    .line 106
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    .line 927
    move-object v2, v0

    .local v2, "$this$text_u24lambda_u240\\1":Landroid/graphics/Paint;
    const/4 v3, 0x0

    .line 106
    .local v3, "$i$a$-apply-ViewportView$TouchLayer$text$1\\1\\106\\0":I
    const/4 v4, -0x1

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v4, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    invoke-virtual {v2, v1}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .end local v2    # "$this$text_u24lambda_u240\\1":Landroid/graphics/Paint;
    .end local v3    # "$i$a$-apply-ViewportView$TouchLayer$text$1\\1\\106\\0":I
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    .line 136
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    .line 141
    const/4 v0, 0x2

    new-array v0, v0, [F

    fill-array-data v0, :array_4a

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchMid:[F

    .line 142
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    .line 103
    return-void

    :array_4a
    .array-data 4
        0x0
        0x0
    .end array-data
.end method

.method public static final synthetic access$overlapsOthers(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;Ljava/util/List;)Z
    .registers 3
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p1, "parts"    # Ljava/util/List;

    .line 103
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->overlapsOthers(Ljava/util/List;)Z

    move-result v0

    return v0
.end method

.method private final arrowButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZZ)V
    .registers 16
    .param p1, "c"    # Landroid/graphics/Canvas;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "r"    # F
    .param p6, "up"    # Z
    .param p7, "active"    # Z

    .line 334
    const-string v6, ""

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v7, p7

    .end local p1    # "c":Landroid/graphics/Canvas;
    .end local p2    # "name":Ljava/lang/String;
    .end local p3    # "x":F
    .end local p4    # "y":F
    .end local p5    # "r":F
    .end local p7    # "active":Z
    .local v1, "c":Landroid/graphics/Canvas;
    .local v2, "name":Ljava/lang/String;
    .local v3, "x":F
    .local v4, "y":F
    .local v5, "r":F
    .local v7, "active":Z
    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->circleButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFLjava/lang/String;Z)V

    .line 335
    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/high16 p2, 0x40600000    # 3.5f

    iget p3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr p3, p2

    invoke-virtual {p1, p3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p2, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 336
    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 337
    const p1, 0x3ec28f5c    # 0.38f

    mul-float p5, v5, p1

    .line 338
    .local p5, "s":F
    const p1, 0x3f19999a    # 0.6f

    const/high16 p2, 0x3f000000    # 0.5f

    if-eqz p6, :cond_5a

    new-instance p3, Landroid/graphics/Path;

    invoke-direct {p3}, Landroid/graphics/Path;-><init>()V

    move-object p4, p3

    .line 927
    .local p4, "$this$arrowButton_u24lambda_u2410\\1":Landroid/graphics/Path;
    const/4 p7, 0x0

    .line 338
    .local p7, "$i$a$-apply-ViewportView$TouchLayer$arrowButton$p$1\\1\\338\\0":I
    sub-float v0, v3, p5

    mul-float v6, p5, p2

    add-float/2addr v6, v4

    invoke-virtual {p4, v0, v6}, Landroid/graphics/Path;->moveTo(FF)V

    mul-float/2addr p1, p5

    sub-float p1, v4, p1

    invoke-virtual {p4, v3, p1}, Landroid/graphics/Path;->lineTo(FF)V

    add-float p1, v3, p5

    mul-float/2addr p2, p5

    add-float/2addr p2, v4

    invoke-virtual {p4, p1, p2}, Landroid/graphics/Path;->lineTo(FF)V

    .end local p4    # "$this$arrowButton_u24lambda_u2410\\1":Landroid/graphics/Path;
    .end local p7    # "$i$a$-apply-ViewportView$TouchLayer$arrowButton$p$1\\1\\338\\0":I
    goto :goto_77

    .line 339
    :cond_5a
    new-instance p3, Landroid/graphics/Path;

    invoke-direct {p3}, Landroid/graphics/Path;-><init>()V

    move-object p4, p3

    .line 927
    .local p4, "$this$arrowButton_u24lambda_u2411\\2":Landroid/graphics/Path;
    const/4 p7, 0x0

    .line 339
    .local p7, "$i$a$-apply-ViewportView$TouchLayer$arrowButton$p$2\\2\\339\\0":I
    sub-float v0, v3, p5

    mul-float v6, p5, p2

    sub-float v6, v4, v6

    invoke-virtual {p4, v0, v6}, Landroid/graphics/Path;->moveTo(FF)V

    mul-float/2addr p1, p5

    add-float/2addr p1, v4

    invoke-virtual {p4, v3, p1}, Landroid/graphics/Path;->lineTo(FF)V

    add-float p1, v3, p5

    mul-float/2addr p2, p5

    sub-float p2, v4, p2

    invoke-virtual {p4, p1, p2}, Landroid/graphics/Path;->lineTo(FF)V

    .line 338
    .end local p4    # "$this$arrowButton_u24lambda_u2411\\2":Landroid/graphics/Path;
    .end local p7    # "$i$a$-apply-ViewportView$TouchLayer$arrowButton$p$2\\2\\339\\0":I
    :goto_77
    nop

    .line 340
    .local p3, "p":Landroid/graphics/Path;
    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, p3, p1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 341
    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 342
    return-void
.end method

.method private final axisParam(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FF)Ljava/lang/Float;
    .registers 12
    .param p1, "center"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "axis"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "x"    # F
    .param p4, "y"    # F

    .line 690
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v0

    invoke-virtual {v0, p3, p4}, Lcom/exampletest/mobilestudiotest/render/ViewState;->screenRay(FF)Lkotlin/Pair;

    move-result-object v0

    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v1, "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 691
    .local v0, "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    .line 692
    .local v2, "w0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p2, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v3

    .line 693
    .local v3, "b":F
    const/high16 v4, 0x3f800000    # 1.0f

    mul-float v5, v3, v3

    sub-float/2addr v4, v5

    .line 694
    .local v4, "denom":F
    const v5, 0x3ca3d70a    # 0.02f

    cmpg-float v5, v4, v5

    if-gez v5, :cond_30

    const/4 v5, 0x0

    return-object v5

    .line 695
    :cond_30
    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v5

    mul-float/2addr v5, v3

    invoke-virtual {p2, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v6

    sub-float/2addr v5, v6

    div-float/2addr v5, v4

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    return-object v5
.end method

.method private final boxIconButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZ)V
    .registers 16
    .param p1, "c"    # Landroid/graphics/Canvas;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "r"    # F
    .param p6, "active"    # Z

    .line 316
    const-string v6, ""

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v7, p6

    .end local p1    # "c":Landroid/graphics/Canvas;
    .end local p2    # "name":Ljava/lang/String;
    .end local p3    # "x":F
    .end local p4    # "y":F
    .end local p5    # "r":F
    .end local p6    # "active":Z
    .local v1, "c":Landroid/graphics/Canvas;
    .local v2, "name":Ljava/lang/String;
    .local v3, "x":F
    .local v4, "y":F
    .local v5, "r":F
    .local v7, "active":Z
    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->circleButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFLjava/lang/String;Z)V

    .line 317
    .end local v1    # "c":Landroid/graphics/Canvas;
    .restart local p1    # "c":Landroid/graphics/Canvas;
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/high16 p3, 0x40000000    # 2.0f

    iget p4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr p4, p3

    invoke-virtual {p2, p4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/4 p3, -0x1

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 318
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    new-instance p3, Landroid/graphics/DashPathEffect;

    const/high16 p4, 0x40800000    # 4.0f

    iget p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr p5, p4

    const/high16 p4, 0x40400000    # 3.0f

    iget p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr p6, p4

    const/4 p4, 0x2

    new-array p4, p4, [F

    const/4 v0, 0x0

    aput p5, p4, v0

    const/4 p5, 0x1

    aput p6, p4, p5

    const/4 p5, 0x0

    invoke-direct {p3, p4, p5}, Landroid/graphics/DashPathEffect;-><init>([FF)V

    check-cast p3, Landroid/graphics/PathEffect;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 319
    const p2, 0x3ee66666    # 0.45f

    mul-float p5, v5, p2

    sub-float p3, v3, p5

    const p4, 0x3ec28f5c    # 0.38f

    mul-float p5, v5, p4

    sub-float p5, v4, p5

    mul-float/2addr p2, v5

    add-float/2addr p2, v3

    mul-float/2addr p4, v5

    add-float/2addr p4, v4

    iget-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    move v8, p4

    move p4, p2

    move p2, p3

    move p3, p5

    move p5, v8

    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 320
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/4 p3, 0x0

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 321
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 322
    return-void
.end method

.method private final camGesture()V
    .registers 23

    .line 601
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const-string v2, "<get-values>(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 957
    .local v2, "$i$f$filter\\1\\601":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v4, v0

    .local v4, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 958
    .local v5, "$i$f$filterTo\\2\\957":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_1d
    :goto_1d
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v7, :cond_41

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\2":Ljava/lang/Object;
    move-object v10, v7

    check-cast v10, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    .local v10, "it\\3":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    const/4 v11, 0x0

    .line 601
    .local v11, "$i$a$-filter-ViewportView$TouchLayer$camGesture$cams$1\\3\\958\\0":I
    instance-of v12, v10, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    if-nez v12, :cond_3a

    instance-of v12, v10, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;

    if-nez v12, :cond_3a

    instance-of v12, v10, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    if-nez v12, :cond_3a

    goto :goto_3b

    :cond_3a
    move v8, v9

    .line 958
    .end local v10    # "it\\3":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    .end local v11    # "$i$a$-filter-ViewportView$TouchLayer$camGesture$cams$1\\3\\958\\0":I
    :goto_3b
    if-eqz v8, :cond_1d

    invoke-interface {v3, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1d

    .line 959
    .end local v7    # "element\\2":Ljava/lang/Object;
    :cond_41
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v4    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filterTo\\2\\957":I
    check-cast v3, Ljava/util/List;

    .line 957
    nop

    .line 601
    .end local v0    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\1\\601":I
    nop

    .line 602
    .local v3, "cams":Ljava/util/List;
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x2

    if-ge v0, v2, :cond_4e

    return-void

    .line 604
    :cond_4e
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_52
    :goto_52
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_c9

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const-string v5, "next(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    .line 605
    .local v4, "c":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    instance-of v5, v4, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;

    if-eqz v5, :cond_9f

    iget-object v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v5, Ljava/util/Map;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getId()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-instance v7, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getId()I

    move-result v10

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v11

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v12

    invoke-direct {v7, v1, v10, v11, v12}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    move-object v10, v7

    .line 927
    .local v10, "it\\4":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
    const/4 v11, 0x0

    .line 605
    .local v11, "$i$a$-also-ViewportView$TouchLayer$camGesture$1\\4\\605\\0":I
    invoke-virtual {v10, v9}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->setMoved(Z)V

    .end local v10    # "it\\4":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
    .end local v11    # "$i$a$-also-ViewportView$TouchLayer$camGesture$1\\4\\605\\0":I
    invoke-interface {v5, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    const-string v6, "Button1Up"

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v7

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v10

    invoke-virtual {v5, v6, v7, v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->pluginMouseEvent(Ljava/lang/String;FF)Z

    .line 606
    :cond_9f
    instance-of v5, v4, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    if-eqz v5, :cond_52

    iget-object v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v5, Ljava/util/Map;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getId()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-instance v7, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getId()I

    move-result v10

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v11

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v12

    invoke-direct {v7, v1, v10, v11, v12}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    move-object v10, v7

    .line 927
    .local v10, "it\\5":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
    const/4 v11, 0x0

    .line 606
    .local v11, "$i$a$-also-ViewportView$TouchLayer$camGesture$2\\5\\606\\0":I
    invoke-virtual {v10, v9}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->setMoved(Z)V

    .end local v10    # "it\\5":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
    .end local v11    # "$i$a$-also-ViewportView$TouchLayer$camGesture$2\\5\\606\\0":I
    invoke-interface {v5, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_52

    .line 608
    .end local v4    # "c":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    :cond_c9
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const-string v4, "<get-values>(...)"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filterIsInstance\\6":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 960
    .local v4, "$i$f$filterIsInstance\\6\\608":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\7":Ljava/util/Collection;
    move-object v6, v0

    .local v6, "$this$filterIsInstanceTo\\7":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 969
    .local v7, "$i$f$filterIsInstanceTo\\7\\960":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_e4
    :goto_e4
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_f6

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\7":Ljava/lang/Object;
    instance-of v12, v11, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    if-eqz v12, :cond_e4

    invoke-interface {v5, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_e4

    .line 970
    .end local v11    # "element\\7":Ljava/lang/Object;
    :cond_f6
    nop

    .end local v5    # "destination\\7":Ljava/util/Collection;
    .end local v6    # "$this$filterIsInstanceTo\\7":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filterIsInstanceTo\\7\\960":I
    check-cast v5, Ljava/util/List;

    .line 960
    nop

    .line 608
    .end local v0    # "$this$filterIsInstance\\6":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterIsInstance\\6\\608":I
    nop

    .line 609
    .local v5, "pair":Ljava/util/List;
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v0

    if-ge v0, v2, :cond_102

    return-void

    .line 610
    :cond_102
    invoke-interface {v5, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    .local v4, "a":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
    invoke-interface {v5, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    .line 611
    .local v6, "b":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
    invoke-virtual {v4, v9}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->setMoved(Z)V

    invoke-virtual {v6, v9}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->setMoved(Z)V

    .line 612
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getX()F

    move-result v0

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getX()F

    move-result v7

    sub-float/2addr v0, v7

    float-to-double v10, v0

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getY()F

    move-result v0

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getY()F

    move-result v7

    sub-float/2addr v0, v7

    float-to-double v12, v0

    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v10

    double-to-float v7, v10

    .line 613
    .local v7, "dist":F
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getX()F

    move-result v0

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getX()F

    move-result v10

    add-float/2addr v0, v10

    const/high16 v10, 0x40000000    # 2.0f

    div-float v11, v0, v10

    .local v11, "mx":F
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getY()F

    move-result v0

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getY()F

    move-result v12

    add-float/2addr v0, v12

    div-float v10, v0, v10

    .line 614
    .local v10, "my":F
    iget v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchDist:F

    const/4 v12, 0x0

    cmpl-float v0, v0, v12

    if-lez v0, :cond_1fb

    .line 615
    iget v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchDist:F

    div-float v12, v7, v0

    .line 616
    .local v12, "zoom":F
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchMid:[F

    aget v0, v0, v8

    sub-float v13, v11, v0

    .local v13, "pdx":F
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchMid:[F

    aget v0, v0, v9

    sub-float v14, v10, v0

    .line 617
    .local v14, "pdy":F
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v15

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v15

    const/16 v16, 0x0

    .line 618
    .local v16, "$i$a$-synchronized-ViewportView$TouchLayer$camGesture$3\\8\\617\\0":I
    :try_start_16d
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v17
    :try_end_175
    .catchall {:try_start_16d .. :try_end_175} :catchall_1f6

    move-object/from16 v18, v17

    .line 619
    .local v18, "play\\8":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    if-eqz v18, :cond_18b

    move-object/from16 v0, v18

    .end local v18    # "play\\8":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .local v0, "play\\8":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :try_start_17b
    invoke-virtual {v0, v12}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->cameraZoom(F)V
    :try_end_17e
    .catchall {:try_start_17b .. :try_end_17e} :catchall_187

    move-object/from16 v17, v0

    move-object/from16 v21, v3

    move/from16 v18, v8

    move/from16 v20, v9

    goto :goto_1ef

    .line 617
    .end local v0    # "play\\8":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$camGesture$3\\8\\617\\0":I
    :catchall_187
    move-exception v0

    move-object/from16 v21, v3

    goto :goto_1f9

    .line 621
    .restart local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$camGesture$3\\8\\617\\0":I
    .restart local v18    # "play\\8":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :cond_18b
    move-object/from16 v17, v18

    .end local v18    # "play\\8":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .local v17, "play\\8":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :try_start_18d
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCamera()Lcom/exampletest/mobilestudiotest/render/FlyCamera;

    move-result-object v18

    move-object/from16 v19, v18

    .line 622
    .local v19, "cam\\8":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getFlySpeed()F

    move-result v0

    move/from16 v18, v8

    const/high16 v8, 0x41000000    # 8.0f

    invoke-static {v0, v8}, Lkotlin/ranges/RangesKt;->coerceAtMost(FF)F

    move-result v0

    const v8, 0x3da3d70a    # 0.08f

    mul-float/2addr v0, v8

    .line 623
    .local v0, "speed\\8":F
    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getPos()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    move/from16 v20, v9

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getForward()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    iget v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchDist:F

    sub-float v2, v7, v2

    mul-float/2addr v2, v0

    invoke-virtual {v9, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v8, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    move-object/from16 v8, v19

    .end local v19    # "cam\\8":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .local v8, "cam\\8":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    invoke-virtual {v8, v2}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->setPos(Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    .line 624
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getPos()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getRight()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    move/from16 v19, v0

    .end local v0    # "speed\\8":F
    .local v19, "speed\\8":F
    neg-float v0, v13

    mul-float v0, v0, v19

    invoke-virtual {v9, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getUp()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9
    :try_end_1dc
    .catchall {:try_start_18d .. :try_end_1dc} :catchall_1f6

    move-object/from16 v21, v3

    .end local v3    # "cams":Ljava/util/List;
    .local v21, "cams":Ljava/util/List;
    mul-float v3, v14, v19

    :try_start_1e0
    invoke-virtual {v9, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v8, v0}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->setPos(Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    .line 626
    .end local v8    # "cam\\8":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v19    # "speed\\8":F
    :goto_1ef
    nop

    .end local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$camGesture$3\\8\\617\\0":I
    .end local v17    # "play\\8":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1f2
    .catchall {:try_start_1e0 .. :try_end_1f2} :catchall_1f4

    .line 617
    monitor-exit v15

    goto :goto_201

    :catchall_1f4
    move-exception v0

    goto :goto_1f9

    .end local v21    # "cams":Ljava/util/List;
    .restart local v3    # "cams":Ljava/util/List;
    :catchall_1f6
    move-exception v0

    move-object/from16 v21, v3

    .end local v3    # "cams":Ljava/util/List;
    .restart local v21    # "cams":Ljava/util/List;
    :goto_1f9
    monitor-exit v15

    throw v0

    .line 614
    .end local v12    # "zoom":F
    .end local v13    # "pdx":F
    .end local v14    # "pdy":F
    .end local v21    # "cams":Ljava/util/List;
    .restart local v3    # "cams":Ljava/util/List;
    :cond_1fb
    move-object/from16 v21, v3

    move/from16 v18, v8

    move/from16 v20, v9

    .line 628
    .end local v3    # "cams":Ljava/util/List;
    .restart local v21    # "cams":Ljava/util/List;
    :goto_201
    iput v7, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchDist:F

    .line 629
    const/4 v0, 0x2

    new-array v0, v0, [F

    aput v11, v0, v18

    aput v10, v0, v20

    iput-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchMid:[F

    .line 630
    return-void
.end method

.method private final circleButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFLjava/lang/String;Z)V
    .registers 14
    .param p1, "c"    # Landroid/graphics/Canvas;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "r"    # F
    .param p6, "label"    # Ljava/lang/String;
    .param p7, "active"    # Z

    .line 345
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 346
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    if-eqz p7, :cond_f

    const v1, -0x33f4a551    # -3.6530876E7f

    goto :goto_11

    :cond_f
    const/high16 v1, 0x59000000

    :goto_11
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 347
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p3, p4, p5, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 348
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/high16 v1, 0x40200000    # 2.5f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v2, v1

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const v1, -0x33000001    # -1.3421772E8f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 349
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p3, p4, p5, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 350
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 351
    move-object v0, p6

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-lez v0, :cond_49

    const/4 v0, 0x1

    goto :goto_4a

    :cond_49
    const/4 v0, 0x0

    :goto_4a
    if-eqz v0, :cond_6e

    .line 352
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const v1, 0x3f0ccccd    # 0.55f

    mul-float/2addr v1, p5

    const/high16 v2, 0x41900000    # 18.0f

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v2

    invoke-static {v1, v3}, Lkotlin/ranges/RangesKt;->coerceAtMost(FF)F

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 353
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v0}, Landroid/graphics/Paint;->getTextSize()F

    move-result v0

    const v1, 0x3eb851ec    # 0.36f

    mul-float/2addr v0, v1

    add-float/2addr v0, p4

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {p1, p6, p3, v0, v1}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 355
    :cond_6e
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    new-instance v1, Landroid/graphics/RectF;

    sub-float v2, p3, p5

    sub-float v3, p4, p5

    add-float v4, p3, p5

    add-float v5, p4, p5

    invoke-direct {v1, v2, v3, v4, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-interface {v0, p2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 356
    return-void
.end method

.method private final down(IFF)V
    .registers 18
    .param p1, "id"    # I
    .param p2, "x"    # F
    .param p3, "y"    # F

    .line 380
    move/from16 v3, p2

    move/from16 v4, p3

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v7

    .line 382
    .local v7, "playing":Z
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    const-string v1, "<get-entries>(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 945
    .local v1, "$i$f$firstOrNull\\1\\382":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_20
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_3c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\1":Ljava/lang/Object;
    move-object v8, v5

    check-cast v8, Ljava/util/Map$Entry;

    .local v8, "it\\2":Ljava/util/Map$Entry;
    const/4 v9, 0x0

    .line 382
    .local v9, "$i$a$-firstOrNull-ViewportView$TouchLayer$down$1\\2\\945\\0":I
    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/graphics/RectF;

    invoke-virtual {v10, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v8

    .line 945
    .end local v8    # "it\\2":Ljava/util/Map$Entry;
    .end local v9    # "$i$a$-firstOrNull-ViewportView$TouchLayer$down$1\\2\\945\\0":I
    if-eqz v8, :cond_20

    goto :goto_3d

    .line 946
    .end local v5    # "element\\1":Ljava/lang/Object;
    :cond_3c
    move-object v5, v6

    .line 382
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\382":I
    :goto_3d
    check-cast v5, Ljava/util/Map$Entry;

    const/4 v8, 0x1

    if-eqz v5, :cond_66

    const/4 v6, 0x0

    .local v6, "$i$a$-let-ViewportView$TouchLayer$down$2\\3\\382\\0":I
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "component1(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v5, v0

    check-cast v5, Ljava/lang/String;

    .line 383
    .local v5, "name\\3":Ljava/lang/String;
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    move-object v9, v0

    check-cast v9, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;

    move-object v1, p0

    move v2, p1

    invoke-direct/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLjava/lang/String;)V

    invoke-interface {v9, v10, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 384
    invoke-direct {p0, v5, v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pressButton(Ljava/lang/String;Z)V

    .line 385
    return-void

    .line 387
    .end local v5    # "name\\3":Ljava/lang/String;
    .end local v6    # "$i$a$-let-ViewportView$TouchLayer$down$2\\3\\382\\0":I
    :cond_66
    const/4 v0, 0x0

    if-eqz v7, :cond_d2

    .line 388
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v2

    invoke-virtual {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->buttonAt(FF)Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v5

    .line 389
    .local v5, "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    if-eqz v5, :cond_9d

    .line 390
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    move-object v8, v0

    check-cast v8, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v2

    invoke-virtual {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scrollAt(FF)Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    move-result-object v6

    move-object v1, p0

    move v2, p1

    invoke-direct/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V

    move-object v6, v5

    .end local v5    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .local v6, "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    invoke-interface {v8, v9, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 391
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {v0, v6, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->press(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;FF)V

    .line 392
    return-void

    .line 394
    .end local v6    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .restart local v5    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    :cond_9d
    move-object v6, v5

    .end local v5    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .restart local v6    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v2

    invoke-virtual {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scrollAt(FF)Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    move-result-object v5

    if-eqz v5, :cond_bf

    .line 927
    .local v5, "it\\4":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    const/4 v8, 0x0

    .line 394
    .local v8, "$i$a$-let-ViewportView$TouchLayer$down$3\\4\\394\\0":I
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    move-object v9, v0

    check-cast v9, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;

    move-object v1, p0

    move v2, p1

    invoke-direct/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V

    invoke-interface {v9, v10, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 395
    .end local v5    # "it\\4":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    .end local v8    # "$i$a$-let-ViewportView$TouchLayer$down$3\\4\\394\\0":I
    :cond_bf
    invoke-direct/range {p0 .. p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tryStartAdorn(IFF)Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    move-result-object v2

    if-eqz v2, :cond_2a3

    .line 927
    .local v2, "it\\5":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;
    const/4 v0, 0x0

    .line 395
    .local v0, "$i$a$-let-ViewportView$TouchLayer$down$4\\5\\395\\0":I
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v5, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v5, v8, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 398
    .end local v0    # "$i$a$-let-ViewportView$TouchLayer$down$4\\5\\395\\0":I
    .end local v2    # "it\\5":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;
    .end local v6    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    :cond_d2
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v2

    invoke-virtual {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->buttonAt(FF)Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v5

    .line 399
    .local v5, "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    if-eqz v5, :cond_11f

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;->getKind()I

    move-result v2

    const/4 v9, 0x4

    if-eq v2, v9, :cond_f7

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v2

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v9

    invoke-virtual {v2, v9}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->isPluginUi(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v2

    if-nez v2, :cond_f7

    move-object v10, v5

    goto :goto_120

    .line 400
    :cond_f7
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    move-object v8, v0

    check-cast v8, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v2

    invoke-virtual {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scrollAt(FF)Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    move-result-object v6

    move-object v1, p0

    move v2, p1

    invoke-direct/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V

    move-object v10, v5

    .end local v5    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .local v10, "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    invoke-interface {v8, v9, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {v0, v10, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->press(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;FF)V

    return-void

    .line 399
    .end local v10    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .restart local v5    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    :cond_11f
    move-object v10, v5

    .line 402
    .end local v5    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .restart local v10    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    :goto_120
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v2

    invoke-virtual {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scrollAt(FF)Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    move-result-object v2

    if-eqz v2, :cond_158

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    move-object v9, v2

    .line 927
    .local v9, "it\\6":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    const/4 v11, 0x0

    .line 402
    .local v11, "$i$a$-takeIf-ViewportView$TouchLayer$down$5\\6\\402\\0":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v5

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v12

    invoke-virtual {v5, v12}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->isPluginUi(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v5

    .end local v9    # "it\\6":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    .end local v11    # "$i$a$-takeIf-ViewportView$TouchLayer$down$5\\6\\402\\0":I
    if-eqz v5, :cond_140

    move-object v5, v2

    goto :goto_141

    :cond_140
    move-object v5, v6

    :goto_141
    if-eqz v5, :cond_158

    .line 927
    .local v5, "it\\7":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    const/4 v6, 0x0

    .line 402
    .local v6, "$i$a$-let-ViewportView$TouchLayer$down$6\\7\\402\\0":I
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    move-object v8, v0

    check-cast v8, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;

    move-object v1, p0

    move v2, p1

    invoke-direct/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V

    invoke-interface {v8, v9, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 403
    .end local v5    # "it\\7":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    .end local v6    # "$i$a$-let-ViewportView$TouchLayer$down$6\\7\\402\\0":I
    :cond_158
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v2

    invoke-virtual {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->pluginUiAt(FF)Z

    move-result v2

    if-eqz v2, :cond_1a0

    .line 405
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {v0, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->pluginFrameAt(FF)Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v5

    if-eqz v5, :cond_18f

    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 927
    .local v5, "f\\8":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    const/4 v9, 0x0

    .line 405
    .local v9, "$i$a$-let-ViewportView$TouchLayer$down$7\\8\\405\\0":I
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    move-object v11, v0

    check-cast v11, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    const/4 v6, 0x0

    move-object v1, p0

    move v2, p1

    invoke-direct/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V

    invoke-interface {v11, v12, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {v0, v5, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->press(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;FF)V

    return-void

    .line 406
    .end local v5    # "f\\8":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .end local v9    # "$i$a$-let-ViewportView$TouchLayer$down$7\\8\\405\\0":I
    :cond_18f
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;

    invoke-direct {v6, p0, p1, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    invoke-interface {v0, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 409
    :cond_1a0
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->getSelectedGui()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    if-eqz v5, :cond_1df

    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    move-object v9, v5

    .local v9, "sel\\9":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v11, 0x0

    .line 410
    .local v11, "$i$a$-let-ViewportView$TouchLayer$down$8\\9\\409\\0":I
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v5

    invoke-virtual {v5, v9, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->handleAt(Lcom/exampletest/mobilestudiotest/model/Instance;FF)Ljava/lang/Integer;

    move-result-object v12

    .line 411
    .local v12, "h\\9":Ljava/lang/Integer;
    if-eqz v12, :cond_1dd

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v5

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-virtual {v5, v9, v6}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->beginDrag(Lcom/exampletest/mobilestudiotest/model/Instance;I)Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;

    move-result-object v5

    if-eqz v5, :cond_1dd

    .line 927
    .local v5, "st\\10":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;
    const/4 v6, 0x0

    .line 411
    .local v6, "$i$a$-let-ViewportView$TouchLayer$down$8$1\\10\\411\\9":I
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    move-object v8, v0

    check-cast v8, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    move-object v1, p0

    move v2, p1

    invoke-direct/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;)V

    invoke-interface {v8, v13, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 412
    .end local v5    # "st\\10":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;
    .end local v6    # "$i$a$-let-ViewportView$TouchLayer$down$8$1\\10\\411\\9":I
    :cond_1dd
    nop

    .line 409
    .end local v9    # "sel\\9":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v11    # "$i$a$-let-ViewportView$TouchLayer$down$8\\9\\409\\0":I
    .end local v12    # "h\\9":Ljava/lang/Integer;
    nop

    .line 414
    :cond_1df
    invoke-direct/range {p0 .. p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tryStartAdorn(IFF)Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    move-result-object v5

    if-eqz v5, :cond_1f2

    .line 927
    .local v5, "it\\11":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;
    const/4 v0, 0x0

    .line 414
    .local v0, "$i$a$-let-ViewportView$TouchLayer$down$9\\11\\414\\0":I
    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v6, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v6, v8, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 416
    .end local v0    # "$i$a$-let-ViewportView$TouchLayer$down$9\\11\\414\\0":I
    .end local v5    # "it\\11":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;
    :cond_1f2
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getActivePlugin()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    if-eqz v5, :cond_251

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v5}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v5

    const-string v6, "<get-values>(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$none\\12":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 947
    .local v6, "$i$f$none\\12\\416":I
    move-object v9, v5

    check-cast v9, Ljava/util/Collection;

    invoke-interface {v9}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_217

    move v5, v8

    goto :goto_230

    .line 948
    :cond_217
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_21b
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_22f

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\12":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    .local v12, "it\\13":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    const/4 v13, 0x0

    .line 416
    .local v13, "$i$a$-none-ViewportView$TouchLayer$down$10\\13\\948\\0":I
    instance-of v12, v12, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;

    .line 948
    .end local v12    # "it\\13":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    .end local v13    # "$i$a$-none-ViewportView$TouchLayer$down$10\\13\\948\\0":I
    if-eqz v12, :cond_21b

    move v5, v0

    goto :goto_230

    .line 949
    .end local v11    # "element\\12":Ljava/lang/Object;
    :cond_22f
    move v5, v8

    .line 416
    .end local v5    # "$this$none\\12":Ljava/lang/Iterable;
    .end local v6    # "$i$f$none\\12\\416":I
    :goto_230
    if-eqz v5, :cond_251

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    const-string v6, "Button1Down"

    invoke-virtual {v5, v6, v3, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->pluginMouseEvent(Ljava/lang/String;FF)Z

    move-result v5

    if-eqz v5, :cond_251

    .line 417
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;

    invoke-direct {v6, p0, p1, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    invoke-interface {v0, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 420
    :cond_251
    invoke-direct/range {p0 .. p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tryStartDrag(IFF)Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;

    move-result-object v5

    if-eqz v5, :cond_264

    .line 927
    .local v5, "it\\14":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;
    const/4 v0, 0x0

    .line 420
    .local v0, "$i$a$-let-ViewportView$TouchLayer$down$11\\14\\420\\0":I
    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v6, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v6, v8, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 421
    .end local v0    # "$i$a$-let-ViewportView$TouchLayer$down$11\\14\\420\\0":I
    .end local v5    # "it\\14":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;
    :cond_264
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getBoxSelect()Z

    move-result v5

    if-eqz v5, :cond_290

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v5}, Ljava/util/HashMap;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_290

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    move-object v6, v0

    check-cast v6, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getAdditive()Z

    move-result v5

    move-object v1, p0

    move v2, p1

    invoke-direct/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFZ)V

    invoke-interface {v6, v8, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 422
    :cond_290
    invoke-direct/range {p0 .. p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tryStartPartDrag(IFF)Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    move-result-object v5

    if-eqz v5, :cond_2a3

    .line 927
    .local v5, "it\\15":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;
    const/4 v0, 0x0

    .line 422
    .local v0, "$i$a$-let-ViewportView$TouchLayer$down$12\\15\\422\\0":I
    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v6, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v6, v8, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 425
    .end local v0    # "$i$a$-let-ViewportView$TouchLayer$down$12\\15\\422\\0":I
    .end local v5    # "it\\15":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;
    .end local v10    # "hit":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    :cond_2a3
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getFixedStick()Z

    move-result v5

    if-eqz v5, :cond_2ca

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getDefaultJoyX()F

    move-result v5

    sub-float v5, v3, v5

    float-to-double v5, v5

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getDefaultJoyY()F

    move-result v9

    sub-float v9, v4, v9

    float-to-double v9, v9

    invoke-static {v5, v6, v9, v10}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v5

    double-to-float v5, v5

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v6

    const v9, 0x3fcccccd    # 1.6f

    mul-float/2addr v6, v9

    cmpg-float v5, v5, v6

    if-gez v5, :cond_2e5

    move v0, v8

    goto :goto_2e5

    .line 426
    :cond_2ca
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v5

    int-to-float v5, v5

    const v6, 0x3ecccccd    # 0.4f

    mul-float/2addr v5, v6

    cmpg-float v5, v3, v5

    if-gez v5, :cond_2e5

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v5

    int-to-float v5, v5

    const v6, 0x3eb33333    # 0.35f

    mul-float/2addr v5, v6

    cmpl-float v5, v4, v5

    if-lez v5, :cond_2e5

    move v0, v8

    .line 425
    :cond_2e5
    :goto_2e5
    move v5, v0

    .line 427
    .local v5, "inStickArea":Z
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getActiveJoy()Z

    move-result v0

    if-nez v0, :cond_335

    if-eqz v5, :cond_335

    if-eqz v7, :cond_2fc

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {v0, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->blocksAt(FF)Z

    move-result v0

    if-nez v0, :cond_335

    .line 428
    :cond_2fc
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getFixedStick()Z

    move-result v0

    if-nez v0, :cond_321

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v0

    const v6, 0x3f19999a    # 0.6f

    mul-float/2addr v0, v6

    invoke-static {v3, v0}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCx:F

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v0

    int-to-float v0, v0

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v8

    mul-float/2addr v8, v6

    sub-float/2addr v0, v8

    invoke-static {v4, v0}, Lkotlin/ranges/RangesKt;->coerceAtMost(FF)F

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCy:F

    .line 429
    :cond_321
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-instance v8, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;

    invoke-direct {v8, p0, p1, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    invoke-interface {v0, v6, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-direct {p0, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->setJoy(FF)V

    return-void

    .line 431
    :cond_335
    if-eqz v7, :cond_354

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {v0, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->blocksAt(FF)Z

    move-result v0

    if-eqz v0, :cond_354

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-instance v8, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Sink;

    invoke-direct {v8, p0, p1, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Sink;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    invoke-interface {v0, v6, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 432
    :cond_354
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    invoke-direct {v0, p0, p1, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    move-object v6, v0

    .line 433
    .local v6, "cam":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v0, v9, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 434
    if-eqz v7, :cond_38c

    .line 436
    invoke-virtual {v6, v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->setPlayDown(Z)V

    .line 437
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v8

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v8

    .line 927
    const/4 v9, 0x0

    .line 437
    .local v9, "$i$a$-synchronized-ViewportView$TouchLayer$down$13\\16\\437\\0":I
    :try_start_378
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_387

    invoke-virtual {v0, v3, v4}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->pointerDown(FF)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_387
    .catchall {:try_start_378 .. :try_end_387} :catchall_389

    .end local v9    # "$i$a$-synchronized-ViewportView$TouchLayer$down$13\\16\\437\\0":I
    :cond_387
    monitor-exit v8

    goto :goto_399

    :catchall_389
    move-exception v0

    monitor-exit v8

    throw v0

    .line 440
    :cond_38c
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    new-instance v8, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;

    invoke-direct {v8, p0, p1, v6, v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;ILcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    .line 447
    nop

    .line 440
    const-wide/16 v9, 0x1a4

    invoke-virtual {p0, v8, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 449
    :goto_399
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->resetPinch()V

    .line 450
    return-void
.end method

.method static final down$lambda$27(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;ILcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 13
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p1, "$id"    # I
    .param p2, "$cam"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
    .param p3, "this$1"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 441
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    .line 442
    .local v0, "p":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    if-ne v0, p2, :cond_5d

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getMoved()Z

    move-result v1

    if-nez v1, :cond_5d

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->size()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_5d

    invoke-static {p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v1

    if-nez v1, :cond_5d

    .line 443
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v1, Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getX()F

    move-result v6

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getY()F

    move-result v7

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getAdditive()Z

    move-result v8

    move-object v4, p0

    move v5, p1

    .end local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .end local p1    # "$id":I
    .local v4, "this$0":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .local v5, "$id":I
    invoke-direct/range {v3 .. v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFZ)V

    move-object p0, v3

    .line 927
    .local p0, "it\\1":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;
    const/4 p1, 0x0

    .line 443
    .local p1, "$i$a$-also-ViewportView$TouchLayer$down$14$1\\1\\443\\0":I
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getX()F

    move-result v6

    invoke-virtual {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->setX(F)V

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getY()F

    move-result v6

    invoke-virtual {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->setY(F)V

    .end local p0    # "it\\1":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;
    .end local p1    # "$i$a$-also-ViewportView$TouchLayer$down$14$1\\1\\443\\0":I
    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 444
    const/4 p0, 0x0

    invoke-virtual {v4, p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->performHapticFeedback(I)Z

    .line 445
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->invalidate()V

    goto :goto_5f

    .line 442
    .end local v4    # "this$0":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .end local v5    # "$id":I
    .local p0, "this$0":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .local p1, "$id":I
    :cond_5d
    move-object v4, p0

    move v5, p1

    .line 447
    .end local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .end local p1    # "$id":I
    .restart local v4    # "this$0":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .restart local v5    # "$id":I
    :goto_5f
    return-void
.end method

.method private final dragAdorn(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;)V
    .registers 19
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    .line 835
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v2

    const/4 v3, 0x0

    .line 836
    .local v3, "$i$a$-synchronized-ViewportView$TouchLayer$dragAdorn$1\\1\\835\\0":I
    :try_start_10
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getAdorn()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "Handles"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v4, :cond_e5

    .line 837
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getTip()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getBase()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getTip()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    move-result-object v8

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getX()F

    move-result v9

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getY()F

    move-result v10

    invoke-direct {v1, v4, v8, v9, v10}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->axisParam(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FF)Ljava/lang/Float;

    move-result-object v4

    .line 838
    .local v4, "t\\1":Ljava/lang/Float;
    if-eqz v4, :cond_55

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getAxis0()Ljava/lang/Float;

    move-result-object v8

    if-eqz v8, :cond_55

    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    move-result v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getAxis0()Ljava/lang/Float;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Float;->floatValue()F

    move-result v8

    sub-float/2addr v0, v8

    goto :goto_c1

    .line 840
    :cond_55
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v8

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getTip()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getBase()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v8
    :try_end_69
    .catchall {:try_start_10 .. :try_end_69} :catchall_19d

    if-nez v8, :cond_6d

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$dragAdorn$1\\1\\835\\0":I
    .end local v4    # "t\\1":Ljava/lang/Float;
    monitor-exit v2

    return-void

    .line 841
    .restart local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$dragAdorn$1\\1\\835\\0":I
    .restart local v4    # "t\\1":Ljava/lang/Float;
    .local v8, "c0\\1":[F
    :cond_6d
    :try_start_6d
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getTip()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getBase()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getTip()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    move-result-object v10

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v0, v9}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v0
    :try_end_8d
    .catchall {:try_start_6d .. :try_end_8d} :catchall_19d

    if-nez v0, :cond_91

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$dragAdorn$1\\1\\835\\0":I
    .end local v4    # "t\\1":Ljava/lang/Float;
    .end local v8    # "c0\\1":[F
    monitor-exit v2

    return-void

    .line 842
    .local v0, "c1\\1":[F
    .restart local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$dragAdorn$1\\1\\835\\0":I
    .restart local v4    # "t\\1":Ljava/lang/Float;
    .restart local v8    # "c0\\1":[F
    :cond_91
    :try_start_91
    aget v9, v0, v6

    aget v10, v8, v6

    sub-float/2addr v9, v10

    .local v9, "sx\\1":F
    aget v10, v0, v7

    aget v11, v8, v7

    sub-float/2addr v10, v11

    .local v10, "sy\\1":F
    float-to-double v11, v9

    float-to-double v13, v10

    invoke-static {v11, v12, v13, v14}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v11

    double-to-float v11, v11

    const/high16 v12, 0x3f000000    # 0.5f

    invoke-static {v11, v12}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v11

    .line 843
    .local v11, "len\\1":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getX()F

    move-result v12

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getX0()F

    move-result v13

    sub-float/2addr v12, v13

    mul-float/2addr v12, v9

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getY()F

    move-result v13

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getY0()F

    move-result v14

    sub-float/2addr v13, v14

    mul-float/2addr v13, v10

    add-float/2addr v12, v13

    mul-float v13, v11, v11

    div-float/2addr v12, v13

    move v0, v12

    .line 838
    .end local v0    # "c1\\1":[F
    .end local v8    # "c0\\1":[F
    .end local v9    # "sx\\1":F
    .end local v10    # "sy\\1":F
    .end local v11    # "len\\1":F
    :goto_c1
    nop

    .line 845
    .local v0, "dist\\1":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getRt()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    move-result-object v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getAdorn()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v9

    const-string v10, "MouseDrag"

    new-array v5, v5, [Lorg/luaj/vm2/LuaValue;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getArg()Lorg/luaj/vm2/LuaValue;

    move-result-object v11

    aput-object v11, v5, v6

    float-to-double v11, v0

    invoke-static {v11, v12}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v6

    const-string v11, "valueOf(...)"

    invoke-static {v6, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    aput-object v6, v5, v7

    invoke-virtual {v8, v9, v10, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .end local v0    # "dist\\1":F
    .end local v4    # "t\\1":Ljava/lang/Float;
    goto/16 :goto_198

    .line 848
    :cond_e5
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getTip()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    move-result-object v8

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getBase()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual {v4, v8}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v4
    :try_end_f9
    .catchall {:try_start_91 .. :try_end_f9} :catchall_19d

    if-nez v4, :cond_fd

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$dragAdorn$1\\1\\835\\0":I
    monitor-exit v2

    return-void

    .line 849
    .restart local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$dragAdorn$1\\1\\835\\0":I
    .local v4, "c\\1":[F
    :cond_fd
    :try_start_fd
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getY0()F

    move-result v8

    aget v9, v4, v7

    sub-float/2addr v8, v9

    float-to-double v8, v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getX0()F

    move-result v10

    aget v11, v4, v6

    sub-float/2addr v10, v11

    float-to-double v10, v10

    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v8

    double-to-float v8, v8

    .local v8, "a0\\1":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getY()F

    move-result v9

    aget v10, v4, v7

    sub-float/2addr v9, v10

    float-to-double v9, v9

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getX()F

    move-result v11

    aget v12, v4, v6

    sub-float/2addr v11, v12

    float-to-double v11, v11

    invoke-static {v9, v10, v11, v12}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v9

    double-to-float v9, v9

    .line 850
    .local v9, "a1\\1":F
    sub-float v10, v9, v8

    .line 851
    .local v10, "delta\\1":F
    :goto_129
    float-to-double v11, v10

    const-wide v13, 0x400921fb54442d18L    # Math.PI

    cmpl-double v11, v11, v13

    const v12, 0x40c90fdb

    if-lez v11, :cond_138

    sub-float/2addr v10, v12

    goto :goto_129

    .line 852
    :cond_138
    :goto_138
    float-to-double v13, v10

    const-wide v15, -0x3ff6de04abbbd2e8L    # -3.141592653589793

    cmpg-double v11, v13, v15

    if-gez v11, :cond_144

    add-float/2addr v10, v12

    goto :goto_138

    .line 853
    :cond_144
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getTip()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    move-result-object v11

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCamera()Lcom/exampletest/mobilestudiotest/render/FlyCamera;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getForward()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v11, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v0

    const/4 v11, 0x0

    cmpl-float v0, v0, v11

    if-lez v0, :cond_164

    const/high16 v0, 0x3f800000    # 1.0f

    goto :goto_166

    :cond_164
    const/high16 v0, -0x40800000    # -1.0f

    .line 854
    .local v0, "sign\\1":F
    :goto_166
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getRt()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    move-result-object v11

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getAdorn()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v12

    const-string v13, "MouseDrag"

    const/4 v14, 0x3

    new-array v14, v14, [Lorg/luaj/vm2/LuaValue;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getArg()Lorg/luaj/vm2/LuaValue;

    move-result-object v15

    aput-object v15, v14, v6

    mul-float v6, v10, v0

    move v15, v5

    float-to-double v5, v6

    invoke-static {v5, v6}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v5

    const-string v6, "valueOf(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    aput-object v5, v14, v7

    const-wide/16 v5, 0x0

    invoke-static {v5, v6}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v5

    const-string v6, "valueOf(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    aput-object v5, v14, v15

    invoke-virtual {v11, v12, v13, v14}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .line 856
    .end local v0    # "sign\\1":F
    .end local v4    # "c\\1":[F
    .end local v8    # "a0\\1":F
    .end local v9    # "a1\\1":F
    .end local v10    # "delta\\1":F
    :goto_198
    nop

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$dragAdorn$1\\1\\835\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_19b
    .catchall {:try_start_fd .. :try_end_19b} :catchall_19d

    .line 835
    monitor-exit v2

    .line 857
    return-void

    .line 835
    :catchall_19d
    move-exception v0

    monitor-exit v2

    throw v0
.end method

.method private final drawEditControls(Landroid/graphics/Canvas;)V
    .registers 16
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 272
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->drawThumbstick(Landroid/graphics/Canvas;)V

    .line 273
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x41f00000    # 30.0f

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v2

    sub-float/2addr v1, v3

    const/high16 v2, 0x42080000    # 34.0f

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v2

    sub-float v3, v1, v3

    .line 274
    .local v3, "bx":F
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v1

    int-to-float v1, v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v8, 0x432a0000    # 170.0f

    mul-float/2addr v2, v8

    sub-float v4, v1, v2

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v9, 0x42000000    # 32.0f

    mul-float v5, v1, v9

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getFlyUp()Z

    move-result v7

    const-string v2, "up"

    const/4 v6, 0x1

    move-object v0, p0

    move-object v1, p1

    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->arrowButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZZ)V

    .line 275
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v1

    int-to-float v1, v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v10, 0x42b40000    # 90.0f

    mul-float/2addr v2, v10

    sub-float v4, v1, v2

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v1, v9

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getFlyDown()Z

    move-result v7

    const-string v2, "down"

    const/4 v6, 0x0

    move-object v1, p1

    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->arrowButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZZ)V

    .line 276
    move v9, v3

    .end local v3    # "bx":F
    .local v9, "bx":F
    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v11, 0x42a00000    # 80.0f

    mul-float/2addr v1, v11

    sub-float v3, v9, v1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v1

    int-to-float v1, v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v2, v10

    sub-float v4, v1, v2

    const/high16 v1, 0x41d00000    # 26.0f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v2, v1

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getFlySpeed()F

    move-result v1

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x4

    invoke-static {v1, v2}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "x"

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    const-string v2, "speed"

    move-object v1, p1

    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->circleButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFLjava/lang/String;Z)V

    .line 278
    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v1, v11

    sub-float v3, v9, v1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v1

    int-to-float v1, v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v2, v8

    sub-float v4, v1, v2

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v7, 0x41c00000    # 24.0f

    mul-float v5, v1, v7

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getBoxSelect()Z

    move-result v6

    const-string v2, "boxsel"

    move-object v1, p1

    invoke-direct/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->boxIconButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZ)V

    .line 279
    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v1, v11

    sub-float v3, v9, v1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x436a0000    # 234.0f

    iget v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v4, v2

    sub-float v4, v1, v4

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v1, v7

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMultiSelect()Z

    move-result v1

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-nez v1, :cond_f5

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModifierHeld()Z

    move-result v1

    if-nez v1, :cond_f5

    move v6, v10

    goto :goto_f6

    :cond_f5
    move v6, v11

    :goto_f6
    const-string v2, "multisel"

    move-object v0, p0

    move-object v1, p1

    invoke-direct/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->multiIconButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZ)V

    .line 280
    const/high16 v1, 0x43100000    # 144.0f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v2, v1

    sub-float v3, v9, v2

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v1

    int-to-float v1, v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v2, v8

    sub-float v4, v1, v2

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v1, v7

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelectInsideModels()Z

    move-result v6

    const-string v2, "insidesel"

    move-object v1, p1

    invoke-direct/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->insideIconButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZ)V

    .line 282
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v2

    const-string v3, "<get-values>(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$filterIsInstance\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 934
    .local v3, "$i$f$filterIsInstance\\1\\282":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$filterIsInstanceTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 943
    .local v6, "$i$f$filterIsInstanceTo\\2\\934":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_13d
    :goto_13d
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_14f

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\2":Ljava/lang/Object;
    instance-of v13, v12, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    if-eqz v13, :cond_13d

    invoke-interface {v4, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_13d

    .line 944
    .end local v12    # "element\\2":Ljava/lang/Object;
    :cond_14f
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$filterIsInstanceTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterIsInstanceTo\\2\\934":I
    check-cast v4, Ljava/util/List;

    .line 934
    nop

    .line 282
    .end local v2    # "$this$filterIsInstance\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filterIsInstance\\1\\282":I
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    if-eqz v2, :cond_1cc

    .local v2, "b\\3":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;
    const/4 v3, 0x0

    .line 283
    .local v3, "$i$a$-let-ViewportView$TouchLayer$drawEditControls$1\\3\\282\\0":I
    new-instance v4, Landroid/graphics/RectF;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getX0()F

    move-result v5

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getX()F

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->min(FF)F

    move-result v5

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getY0()F

    move-result v6

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getY()F

    move-result v8

    invoke-static {v6, v8}, Ljava/lang/Math;->min(FF)F

    move-result v6

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getX0()F

    move-result v8

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getX()F

    move-result v12

    invoke-static {v8, v12}, Ljava/lang/Math;->max(FF)F

    move-result v8

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getY0()F

    move-result v12

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getY()F

    move-result v13

    invoke-static {v12, v13}, Ljava/lang/Math;->max(FF)F

    move-result v12

    invoke-direct {v4, v5, v6, v8, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 284
    .local v4, "r\\3":Landroid/graphics/RectF;
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const v6, 0x2e1a9fff

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 285
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 286
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/high16 v6, 0x3fc00000    # 1.5f

    iget v8, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v8, v6

    invoke-virtual {v5, v8}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const v6, -0xe56001

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 287
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 288
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 289
    nop

    .line 282
    .end local v2    # "b\\3":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;
    .end local v3    # "$i$a$-let-ViewportView$TouchLayer$drawEditControls$1\\3\\282\\0":I
    .end local v4    # "r\\3":Landroid/graphics/RectF;
    nop

    .line 291
    :cond_1cc
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getActivePlugin()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    if-eqz v2, :cond_26a

    .local v2, "p\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v3, 0x0

    .line 292
    .local v3, "$i$a$-let-ViewportView$TouchLayer$drawEditControls$2\\4\\291\\0":I
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/high16 v5, 0x41400000    # 12.0f

    iget v6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v5

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v4, v10}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 293
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " is active  \u2715"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 294
    .local v4, "label\\4":Ljava/lang/String;
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v5

    iget v6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v7

    add-float/2addr v5, v6

    .line 295
    .local v5, "w\\4":F
    new-instance v6, Landroid/graphics/RectF;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v7

    int-to-float v7, v7

    const/high16 v8, 0x40000000    # 2.0f

    div-float/2addr v7, v8

    div-float v10, v5, v8

    sub-float/2addr v7, v10

    const/high16 v10, 0x41000000    # 8.0f

    iget v12, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v12, v10

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v10

    int-to-float v10, v10

    div-float/2addr v10, v8

    div-float v8, v5, v8

    add-float/2addr v10, v8

    const/high16 v8, 0x42100000    # 36.0f

    iget v13, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v13, v8

    invoke-direct {v6, v7, v12, v10, v13}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 296
    .local v6, "r\\4":Landroid/graphics/RectF;
    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const v8, -0x33f4a551    # -3.6530876E7f

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    iget v7, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v8, 0x41600000    # 14.0f

    mul-float/2addr v7, v8

    iget v10, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v10, v8

    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v6, v7, v10, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 297
    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v8, -0x1

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v6}, Landroid/graphics/RectF;->centerX()F

    move-result v7

    invoke-virtual {v6}, Landroid/graphics/RectF;->centerY()F

    move-result v8

    const/high16 v10, 0x40900000    # 4.5f

    iget v12, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v12, v10

    add-float/2addr v8, v12

    iget-object v10, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v7, v8, v10}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 298
    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v11}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 299
    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    check-cast v7, Ljava/util/Map;

    const-string v8, "plugin_off"

    invoke-interface {v7, v8, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 300
    nop

    .line 291
    .end local v2    # "p\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v3    # "$i$a$-let-ViewportView$TouchLayer$drawEditControls$2\\4\\291\\0":I
    .end local v4    # "label\\4":Ljava/lang/String;
    .end local v5    # "w\\4":F
    .end local v6    # "r\\4":Landroid/graphics/RectF;
    nop

    .line 301
    :cond_26a
    return-void
.end method

.method private final drawPlayControls(Landroid/graphics/Canvas;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V
    .registers 36
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "play"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    .line 185
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->drawThumbstick(Landroid/graphics/Canvas;)V

    .line 187
    const/high16 v0, 0x42200000    # 40.0f

    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v11, v3, v0

    .line 188
    .local v11, "jr":F
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v0

    int-to-float v0, v0

    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v4, 0x42080000    # 34.0f

    mul-float/2addr v3, v4

    sub-float/2addr v0, v3

    sub-float v12, v0, v11

    .local v12, "jx":F
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v0

    int-to-float v0, v0

    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v4

    sub-float/2addr v0, v3

    sub-float v13, v0, v11

    .line 189
    .local v13, "jy":F
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 190
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    iget-boolean v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->jumpDown:Z

    if-eqz v3, :cond_36

    const v3, -0x4c000001

    goto :goto_38

    :cond_36
    const/high16 v3, 0x4d000000    # 1.3421773E8f

    :goto_38
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 191
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v12, v13, v11, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 192
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v14, 0x40400000    # 3.0f

    mul-float/2addr v3, v14

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const v3, -0x19000001

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 193
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v12, v13, v11, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 194
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    iget v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v15, 0x40900000    # 4.5f

    mul-float/2addr v5, v15

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 195
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    iget-boolean v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->jumpDown:Z

    const v16, -0xcccccd

    if-eqz v5, :cond_82

    move/from16 v5, v16

    goto :goto_83

    :cond_82
    const/4 v5, -0x1

    :goto_83
    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 196
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    move-object v5, v0

    .line 927
    .local v5, "$this$drawPlayControls_u24lambda_u242\\1":Landroid/graphics/Path;
    const/4 v7, 0x0

    .line 196
    .local v7, "$i$a$-apply-ViewportView$TouchLayer$drawPlayControls$chev$1\\1\\196\\0":I
    iget v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v17, 0x41500000    # 13.0f

    mul-float v8, v8, v17

    sub-float v8, v12, v8

    iget v9, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v18, 0x40c00000    # 6.0f

    mul-float v9, v9, v18

    add-float/2addr v9, v13

    invoke-virtual {v5, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v8, 0x40e00000    # 7.0f

    iget v9, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v9, v8

    sub-float v8, v13, v9

    invoke-virtual {v5, v12, v8}, Landroid/graphics/Path;->lineTo(FF)V

    iget v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v8, v8, v17

    add-float/2addr v8, v12

    iget v9, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v9, v9, v18

    add-float/2addr v9, v13

    invoke-virtual {v5, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 197
    .end local v7    # "$i$a$-apply-ViewportView$TouchLayer$drawPlayControls$chev$1\\1\\196\\0":I
    .local v5, "chev":Landroid/graphics/Path;
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v5, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 198
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v7, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 199
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    const-string v7, "jump"

    new-instance v8, Landroid/graphics/RectF;

    const v9, 0x3f933333    # 1.15f

    mul-float v10, v11, v9

    sub-float v10, v12, v10

    mul-float v19, v11, v9

    sub-float v4, v13, v19

    mul-float v19, v11, v9

    add-float v6, v12, v19

    mul-float/2addr v9, v11

    add-float/2addr v9, v13

    invoke-direct {v8, v10, v4, v6, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-interface {v0, v7, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 201
    sub-float v0, v13, v11

    const/high16 v4, 0x42380000    # 46.0f

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v4

    sub-float/2addr v0, v6

    .line 203
    .local v0, "ay":F
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getShiftLockAllowed()Z

    move-result v4

    const/high16 v19, 0x41300000    # 11.0f

    const/high16 v22, 0x41400000    # 12.0f

    const/high16 v23, 0x41000000    # 8.0f

    const/high16 v24, 0x40b00000    # 5.5f

    const/high16 v25, 0x41200000    # 10.0f

    const/high16 v26, 0x40000000    # 2.0f

    if-eqz v4, :cond_1fd

    .line 204
    const/high16 v4, 0x41c00000    # 24.0f

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v4, v6

    .line 205
    .local v4, "sr":F
    sub-float v6, v12, v11

    iget v7, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v7, v7, v22

    sub-float/2addr v6, v7

    sub-float/2addr v6, v4

    .local v6, "sx":F
    sub-float v7, v13, v11

    iget v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v8, v8, v25

    sub-float/2addr v7, v8

    .line 206
    .local v7, "sy":F
    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 207
    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getShiftLock()Z

    move-result v9

    if-eqz v9, :cond_122

    const v9, -0x19ff5d01

    goto :goto_124

    :cond_122
    const/high16 v9, 0x4d000000    # 1.3421773E8f

    :goto_124
    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 208
    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v6, v7, v4, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 209
    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    iget v9, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v9, v9, v26

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v8, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 210
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v6, v7, v4, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 212
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const v8, 0x400ccccd    # 2.2f

    iget v9, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v9, v8

    invoke-virtual {v3, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 213
    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v3, v3, v24

    sub-float v3, v6, v3

    iget v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v8, v8, v19

    sub-float v8, v7, v8

    iget v9, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v9, v9, v24

    add-float/2addr v9, v6

    const/high16 v20, 0x3f800000    # 1.0f

    iget v10, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v10, v10, v20

    add-float/2addr v10, v7

    move-object/from16 v20, v5

    move v5, v9

    .end local v5    # "chev":Landroid/graphics/Path;
    .local v20, "chev":Landroid/graphics/Path;
    const/4 v9, 0x0

    move/from16 v27, v6

    move v6, v10

    .end local v6    # "sx":F
    .local v27, "sx":F
    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    move/from16 v28, v7

    .end local v7    # "sy":F
    .local v28, "sy":F
    const/high16 v7, 0x43340000    # 180.0f

    move/from16 v29, v4

    move v4, v8

    .end local v4    # "sr":F
    .local v29, "sr":F
    const/high16 v8, 0x43340000    # 180.0f

    move/from16 v21, v14

    move/from16 v14, v27

    move/from16 v27, v15

    const/4 v15, -0x1

    .end local v27    # "sx":F
    .local v14, "sx":F
    invoke-virtual/range {v2 .. v10}, Landroid/graphics/Canvas;->drawArc(FFFFFFZLandroid/graphics/Paint;)V

    .line 214
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 215
    iget v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v2, v2, v23

    sub-float v3, v14, v2

    const/high16 v2, 0x40800000    # 4.0f

    iget v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v4, v2

    sub-float v4, v28, v4

    iget v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v2, v2, v23

    add-float v5, v14, v2

    const/high16 v2, 0x41100000    # 9.0f

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v2

    add-float v6, v28, v6

    iget v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v10, 0x40200000    # 2.5f

    mul-float v7, v2, v10

    iget v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v8, v2, v10

    iget-object v9, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    move-object/from16 v2, p1

    invoke-virtual/range {v2 .. v9}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 216
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getShiftLock()Z

    move-result v4

    if-eqz v4, :cond_1c7

    const v16, -0xff5d01

    :cond_1c7
    move/from16 v4, v16

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 217
    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v10

    add-float v7, v28, v3

    const v3, 0x3fe66666    # 1.8f

    iget v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v4, v3

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v14, v7, v4, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 218
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    check-cast v3, Ljava/util/Map;

    const-string v4, "shiftlock"

    new-instance v5, Landroid/graphics/RectF;

    const v6, 0x3f99999a    # 1.2f

    mul-float v7, v29, v6

    sub-float v7, v14, v7

    mul-float v8, v29, v6

    sub-float v8, v28, v8

    mul-float v9, v29, v6

    add-float/2addr v9, v14

    mul-float v6, v6, v29

    add-float v6, v28, v6

    invoke-direct {v5, v7, v8, v9, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-interface {v3, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_204

    .line 203
    .end local v14    # "sx":F
    .end local v20    # "chev":Landroid/graphics/Path;
    .end local v28    # "sy":F
    .end local v29    # "sr":F
    .restart local v5    # "chev":Landroid/graphics/Path;
    :cond_1fd
    move-object/from16 v20, v5

    move/from16 v21, v14

    move/from16 v27, v15

    const/4 v15, -0x1

    .line 220
    .end local v5    # "chev":Landroid/graphics/Path;
    .restart local v20    # "chev":Landroid/graphics/Path;
    :goto_204
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getActions()Ljava/util/LinkedHashMap;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v9

    move v5, v0

    .end local v0    # "ay":F
    .local v5, "ay":F
    :goto_211
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_253

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const-string v3, "next(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ActionButton;

    .line 221
    .local v0, "a":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ActionButton;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ActionButton;->getName()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "action:"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/high16 v4, 0x41e00000    # 28.0f

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ActionButton;->getTitle()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    invoke-static {v4, v7}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    move v4, v12

    .end local v12    # "jx":F
    .local v4, "jx":F
    invoke-direct/range {v1 .. v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->circleButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFLjava/lang/String;Z)V

    .line 222
    const/high16 v3, 0x42840000    # 66.0f

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v3

    sub-float/2addr v5, v6

    .end local v0    # "a":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ActionButton;
    goto :goto_211

    .line 224
    .end local v4    # "jx":F
    .restart local v12    # "jx":F
    :cond_253
    move v4, v12

    .end local v12    # "jx":F
    .restart local v4    # "jx":F
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getActivePrompt()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    if-eqz v0, :cond_3e9

    .local v0, "pr\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v7, 0x0

    .line 225
    .local v7, "$i$a$-let-ViewportView$TouchLayer$drawPlayControls$1\\2\\224\\0":I
    const-string v8, "ActionText"

    invoke-virtual {v0, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    instance-of v9, v8, Ljava/lang/String;

    if-eqz v9, :cond_268

    check-cast v8, Ljava/lang/String;

    goto :goto_269

    :cond_268
    const/4 v8, 0x0

    :goto_269
    if-eqz v8, :cond_280

    check-cast v8, Ljava/lang/CharSequence;

    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v9

    if-nez v9, :cond_275

    const/4 v9, 0x1

    goto :goto_276

    :cond_275
    const/4 v9, 0x0

    :goto_276
    if-eqz v9, :cond_27b

    .line 927
    const/4 v8, 0x0

    .line 225
    .local v8, "$i$a$-ifEmpty-ViewportView$TouchLayer$drawPlayControls$1$action$1\\3\\225\\2":I
    const-string v8, "Interact"

    .end local v8    # "$i$a$-ifEmpty-ViewportView$TouchLayer$drawPlayControls$1$action$1\\3\\225\\2":I
    :cond_27b
    check-cast v8, Ljava/lang/String;

    if-eqz v8, :cond_280

    goto :goto_282

    :cond_280
    const-string v8, "Interact"

    .line 226
    .local v8, "action\\2":Ljava/lang/String;
    :goto_282
    const-string v9, "ObjectText"

    invoke-virtual {v0, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    instance-of v10, v9, Ljava/lang/String;

    if-eqz v10, :cond_28f

    check-cast v9, Ljava/lang/String;

    goto :goto_290

    :cond_28f
    const/4 v9, 0x0

    :goto_290
    if-nez v9, :cond_294

    const-string v9, ""

    .line 227
    .local v9, "obj\\2":Ljava/lang/String;
    :cond_294
    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    iget v12, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v14, 0x41700000    # 15.0f

    mul-float/2addr v12, v14

    invoke-virtual {v10, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 228
    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v10, v8}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v10

    iget-object v12, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v12, v9}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v12

    const v16, 0x3f4ccccd    # 0.8f

    mul-float v12, v12, v16

    invoke-static {v10, v12}, Ljava/lang/Math;->max(FF)F

    move-result v10

    const/high16 v16, 0x42a80000    # 84.0f

    iget v12, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v12, v12, v16

    add-float/2addr v10, v12

    .line 229
    .local v10, "w\\2":F
    new-instance v12, Landroid/graphics/RectF;

    move/from16 v16, v14

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v14

    int-to-float v14, v14

    div-float v14, v14, v26

    div-float v28, v10, v26

    sub-float v14, v14, v28

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v6

    int-to-float v6, v6

    const v29, 0x3f147ae1    # 0.58f

    mul-float v6, v6, v29

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v3

    int-to-float v3, v3

    div-float v3, v3, v26

    div-float v30, v10, v26

    add-float v3, v3, v30

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v15

    int-to-float v15, v15

    const v31, 0x3f147ae1    # 0.58f

    mul-float v15, v15, v31

    const/high16 v31, 0x42600000    # 56.0f

    move-object/from16 v32, v0

    .end local v0    # "pr\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v32, "pr\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v0, v0, v31

    add-float/2addr v15, v0

    invoke-direct {v12, v14, v6, v3, v15}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 230
    .local v12, "r\\2":Landroid/graphics/RectF;
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/high16 v3, -0x4d000000

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    iget v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v0, v0, v25

    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v3, v3, v25

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v12, v0, v3, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 231
    iget v0, v12, Landroid/graphics/RectF;->left:F

    const/high16 v3, 0x41f00000    # 30.0f

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v3

    add-float/2addr v0, v6

    .line 232
    .local v0, "kc\\2":F
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v6, v6, v26

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/4 v15, -0x1

    invoke-virtual {v3, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 233
    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    const/high16 v6, 0x41800000    # 16.0f

    iget v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v14, v6

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v0, v3, v14, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 234
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v6, v6, v17

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    const-string v3, "Tap"

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    iget v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v14, v14, v27

    add-float/2addr v6, v14

    iget-object v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v2, v3, v0, v6, v14}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 235
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 236
    move-object v3, v9

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_366

    const/4 v3, 0x1

    goto :goto_367

    :cond_366
    const/4 v3, 0x0

    :goto_367
    const/high16 v6, 0x41d00000    # 26.0f

    if-eqz v3, :cond_3bc

    .line 237
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    iget v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v14, v14, v22

    invoke-virtual {v3, v14}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const v14, -0x333334

    invoke-virtual {v3, v14}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v14, 0x0

    invoke-virtual {v3, v14}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 238
    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v6

    add-float/2addr v3, v0

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v14

    iget v15, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v15, v15, v18

    sub-float/2addr v14, v15

    iget-object v15, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v2, v9, v3, v14, v15}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 239
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    iget v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v14, v14, v16

    invoke-virtual {v3, v14}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v15, -0x1

    invoke-virtual {v3, v15}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v14, 0x1

    invoke-virtual {v3, v14}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 240
    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v6

    add-float/2addr v3, v0

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    iget v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v14, v14, v17

    add-float/2addr v6, v14

    iget-object v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v2, v8, v3, v6, v14}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    goto :goto_3d7

    .line 242
    :cond_3bc
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    iget v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v14, v14, v16

    invoke-virtual {v3, v14}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 243
    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v6

    add-float/2addr v3, v0

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    iget v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v14, v14, v24

    add-float/2addr v6, v14

    iget-object v14, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v2, v8, v3, v6, v14}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 245
    :goto_3d7
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 246
    iget-object v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    check-cast v3, Ljava/util/Map;

    const-string v6, "prompt"

    invoke-interface {v3, v6, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    nop

    .line 224
    .end local v0    # "kc\\2":F
    .end local v7    # "$i$a$-let-ViewportView$TouchLayer$drawPlayControls$1\\2\\224\\0":I
    .end local v8    # "action\\2":Ljava/lang/String;
    .end local v9    # "obj\\2":Ljava/lang/String;
    .end local v10    # "w\\2":F
    .end local v12    # "r\\2":Landroid/graphics/RectF;
    .end local v32    # "pr\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    nop

    .line 248
    :cond_3e9
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getCoreBackpack()Z

    move-result v0

    if-eqz v0, :cond_404

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v3

    monitor-enter v3

    .line 927
    const/4 v0, 0x0

    .line 248
    .local v0, "$i$a$-synchronized-ViewportView$TouchLayer$drawPlayControls$tools$1\\4\\248\\0":I
    :try_start_3fb
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->backpackTools()Ljava/util/List;

    move-result-object v6
    :try_end_3ff
    .catchall {:try_start_3fb .. :try_end_3ff} :catchall_401

    .end local v0    # "$i$a$-synchronized-ViewportView$TouchLayer$drawPlayControls$tools$1\\4\\248\\0":I
    monitor-exit v3

    goto :goto_408

    :catchall_401
    move-exception v0

    monitor-exit v3

    throw v0

    :cond_404
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v6

    .line 249
    .local v6, "tools":Ljava/util/List;
    :goto_408
    move-object v0, v6

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_559

    .line 250
    const/high16 v0, 0x42680000    # 58.0f

    iget v3, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v0

    .line 251
    .local v3, "slot":F
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v0

    int-to-float v0, v0

    iget v7, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v7, v7, v18

    add-float/2addr v7, v3

    mul-float/2addr v0, v7

    iget v7, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v7, v7, v18

    sub-float/2addr v0, v7

    .line 252
    .local v0, "total":F
    const/4 v7, 0x0

    .local v7, "x":F
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v8

    int-to-float v8, v8

    div-float v8, v8, v26

    div-float v9, v0, v26

    sub-float/2addr v8, v9

    .line 253
    .end local v7    # "x":F
    .local v8, "x":F
    move-object v7, v6

    check-cast v7, Ljava/lang/Iterable;

    .local v7, "$this$forEachIndexed\\5":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 931
    .local v9, "$i$f$forEachIndexed\\5\\253":I
    const/4 v10, 0x0

    .line 932
    .local v10, "index\\5":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_43a
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_54e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "item\\5":Ljava/lang/Object;
    add-int/lit8 v15, v10, 0x1

    .end local v10    # "index\\5":I
    .local v15, "index\\5":I
    if-gez v10, :cond_44b

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_44b
    move/from16 v16, v0

    .end local v0    # "total":F
    .local v16, "total":F
    move-object v0, v14

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v0, "t\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v10, "i\\6":I
    const/16 v22, 0x0

    .line 254
    .local v22, "$i$a$-forEachIndexed-ViewportView$TouchLayer$drawPlayControls$2\\6\\932\\0":I
    move/from16 v24, v3

    .end local v3    # "slot":F
    .local v24, "slot":F
    new-instance v3, Landroid/graphics/RectF;

    move/from16 v26, v4

    .end local v4    # "jx":F
    .local v26, "jx":F
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v4

    int-to-float v4, v4

    sub-float v4, v4, v24

    move/from16 v27, v4

    iget v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v4, v4, v25

    sub-float v4, v27, v4

    move/from16 v27, v5

    .end local v5    # "ay":F
    .local v27, "ay":F
    add-float v5, v8, v24

    move-object/from16 v30, v6

    .end local v6    # "tools":Ljava/util/List;
    .local v30, "tools":Ljava/util/List;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v6

    int-to-float v6, v6

    move/from16 v31, v6

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v6, v6, v25

    sub-float v6, v31, v6

    invoke-direct {v3, v8, v4, v5, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 255
    .local v3, "r\\6":Landroid/graphics/RectF;
    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/high16 v5, -0x67000000

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 256
    iget v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v4, v4, v18

    iget v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v5, v18

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v3, v4, v5, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 257
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getEquipped()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    if-ne v4, v0, :cond_4c3

    .line 258
    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    iget v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v5, v21

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const v5, -0xff5d01

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 259
    iget v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v4, v4, v18

    iget v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v5, v18

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v3, v4, v5, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 261
    :cond_4c3
    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    iget v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v5, v19

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 262
    add-int/lit8 v4, v10, 0x1

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    iget v6, v3, Landroid/graphics/RectF;->left:F

    const/high16 v29, 0x40a00000    # 5.0f

    iget v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v5, v5, v29

    add-float/2addr v6, v5

    iget v5, v3, Landroid/graphics/RectF;->top:F

    move-object/from16 v29, v0

    .end local v0    # "t\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v29, "t\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v0, v0, v17

    add-float/2addr v5, v0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v2, v4, v6, v5, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 263
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v4, 0x1

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 264
    invoke-virtual/range {v29 .. v29}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    const/16 v5, 0x9

    invoke-static {v0, v5}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    iget v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v4, v4, v23

    add-float/2addr v6, v4

    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {v2, v0, v5, v6, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 265
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "tool:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 266
    iget v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float v0, v0, v18

    add-float v0, v24, v0

    add-float/2addr v8, v0

    .line 267
    nop

    .line 932
    .end local v3    # "r\\6":Landroid/graphics/RectF;
    .end local v10    # "i\\6":I
    .end local v22    # "$i$a$-forEachIndexed-ViewportView$TouchLayer$drawPlayControls$2\\6\\932\\0":I
    .end local v29    # "t\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    move v10, v15

    move/from16 v0, v16

    move/from16 v3, v24

    move/from16 v4, v26

    move/from16 v5, v27

    move-object/from16 v6, v30

    .end local v14    # "item\\5":Ljava/lang/Object;
    goto/16 :goto_43a

    .line 933
    .end local v15    # "index\\5":I
    .end local v16    # "total":F
    .end local v24    # "slot":F
    .end local v26    # "jx":F
    .end local v27    # "ay":F
    .end local v30    # "tools":Ljava/util/List;
    .local v0, "total":F
    .local v3, "slot":F
    .restart local v4    # "jx":F
    .restart local v5    # "ay":F
    .restart local v6    # "tools":Ljava/util/List;
    .local v10, "index\\5":I
    :cond_54e
    move/from16 v16, v0

    move/from16 v24, v3

    move/from16 v26, v4

    move/from16 v27, v5

    move-object/from16 v30, v6

    .end local v0    # "total":F
    .end local v3    # "slot":F
    .end local v4    # "jx":F
    .end local v5    # "ay":F
    .end local v6    # "tools":Ljava/util/List;
    .restart local v16    # "total":F
    .restart local v24    # "slot":F
    .restart local v26    # "jx":F
    .restart local v27    # "ay":F
    .restart local v30    # "tools":Ljava/util/List;
    goto :goto_55f

    .line 249
    .end local v7    # "$this$forEachIndexed\\5":Ljava/lang/Iterable;
    .end local v8    # "x":F
    .end local v9    # "$i$f$forEachIndexed\\5\\253":I
    .end local v10    # "index\\5":I
    .end local v16    # "total":F
    .end local v24    # "slot":F
    .end local v26    # "jx":F
    .end local v27    # "ay":F
    .end local v30    # "tools":Ljava/util/List;
    .restart local v4    # "jx":F
    .restart local v5    # "ay":F
    .restart local v6    # "tools":Ljava/util/List;
    :cond_559
    move/from16 v26, v4

    move/from16 v27, v5

    move-object/from16 v30, v6

    .line 269
    .end local v4    # "jx":F
    .end local v5    # "ay":F
    .end local v6    # "tools":Ljava/util/List;
    .restart local v26    # "jx":F
    .restart local v27    # "ay":F
    .restart local v30    # "tools":Ljava/util/List;
    :goto_55f
    return-void
.end method

.method private final drawThumbstick(Landroid/graphics/Canvas;)V
    .registers 7
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 172
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getActiveJoy()Z

    move-result v0

    .line 173
    .local v0, "active":Z
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 174
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    if-eqz v0, :cond_12

    const/high16 v2, 0x4d000000    # 1.3421773E8f

    goto :goto_14

    :cond_12
    const/high16 v2, 0x26000000

    :goto_14
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 175
    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCx:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCy:F

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v3

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 176
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/high16 v2, 0x40000000    # 2.0f

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v2

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 177
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    if-eqz v0, :cond_3d

    const v2, -0x4c000001

    goto :goto_40

    :cond_3d
    const v2, 0x4dffffff    # 5.3687088E8f

    :goto_40
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 178
    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCx:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCy:F

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v3

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 179
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 180
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    if-eqz v0, :cond_5f

    const v2, -0x26000001

    goto :goto_62

    :cond_5f
    const v2, 0x66ffffff

    :goto_62
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 181
    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCx:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyX:F

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v3

    mul-float/2addr v2, v3

    add-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCy:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyY:F

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v4

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v3

    const v4, 0x3ed70a3d    # 0.42f

    mul-float/2addr v3, v4

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 182
    return-void
.end method

.method private final finishBox(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;)V
    .registers 27
    .param p1, "b"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    .line 663
    move-object/from16 v1, p0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getX0()F

    move-result v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getX()F

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->min(FF)F

    move-result v2

    .local v2, "l":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getX0()F

    move-result v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getX()F

    move-result v3

    invoke-static {v0, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    .local v3, "r":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getY0()F

    move-result v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getY()F

    move-result v4

    invoke-static {v0, v4}, Ljava/lang/Math;->min(FF)F

    move-result v4

    .local v4, "t":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getY0()F

    move-result v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getY()F

    move-result v5

    invoke-static {v0, v5}, Ljava/lang/Math;->max(FF)F

    move-result v5

    .line 664
    .local v5, "bt":F
    sub-float v0, v3, v2

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v7, 0x40c00000    # 6.0f

    mul-float/2addr v6, v7

    cmpg-float v0, v0, v6

    if-gez v0, :cond_47

    sub-float v0, v5, v4

    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v7

    cmpg-float v0, v0, v6

    if-gez v0, :cond_47

    return-void

    .line 665
    :cond_47
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v6, v0

    .line 666
    .local v6, "picked":Ljava/util/ArrayList;
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v7

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v7

    const/4 v8, 0x0

    .line 667
    .local v8, "$i$a$-synchronized-ViewportView$TouchLayer$finishBox$1\\1\\666\\0":I
    :try_start_5b
    new-instance v9, Ljava/util/IdentityHashMap;

    invoke-direct {v9}, Ljava/util/IdentityHashMap;-><init>()V

    check-cast v9, Ljava/util/Map;

    invoke-static {v9}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v9

    .line 668
    .local v9, "seen\\1":Ljava/util/Set;
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v10

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->renderParts()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_72
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11
    :try_end_76
    .catchall {:try_start_5b .. :try_end_76} :catchall_249

    const/4 v12, 0x0

    const/4 v13, 0x1

    if-eqz v11, :cond_149

    :try_start_7a
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 669
    .local v11, "p\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const-string v14, "Locked"

    invoke-virtual {v11, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v14

    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v15

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_13a

    .line 670
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v14

    sget-object v15, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v15, v11}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v15

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v15

    invoke-virtual {v14, v15}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v14

    if-nez v14, :cond_a9

    goto :goto_72

    .line 671
    .local v14, "s\\1":[F
    :cond_a9
    aget v15, v14, v12

    cmpg-float v15, v15, v2

    if-ltz v15, :cond_134

    aget v12, v14, v12

    cmpl-float v12, v12, v3

    if-gtz v12, :cond_134

    aget v12, v14, v13

    cmpg-float v12, v12, v4

    if-ltz v12, :cond_134

    aget v12, v14, v13

    cmpl-float v12, v12, v5

    if-lez v12, :cond_c2

    goto :goto_72

    .line 672
    :cond_c2
    array-length v12, v14
    :try_end_c3
    .catchall {:try_start_7a .. :try_end_c3} :catchall_140

    const/4 v13, 0x2

    if-le v12, v13, :cond_d8

    :try_start_c6
    aget v12, v14, v13
    :try_end_c8
    .catchall {:try_start_c6 .. :try_end_c8} :catchall_cf

    const/high16 v13, 0x3f800000    # 1.0f

    cmpl-float v12, v12, v13

    if-lez v12, :cond_d8

    goto :goto_72

    .line 666
    .end local v8    # "$i$a$-synchronized-ViewportView$TouchLayer$finishBox$1\\1\\666\\0":I
    .end local v9    # "seen\\1":Ljava/util/Set;
    .end local v11    # "p\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "s\\1":[F
    :catchall_cf
    move-exception v0

    move/from16 v17, v2

    move/from16 v20, v3

    move/from16 v21, v4

    goto/16 :goto_250

    .line 674
    .restart local v8    # "$i$a$-synchronized-ViewportView$TouchLayer$finishBox$1\\1\\666\\0":I
    .restart local v9    # "seen\\1":Ljava/util/Set;
    .restart local v11    # "p\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v14    # "s\\1":[F
    :cond_d8
    move-object v12, v11

    .line 675
    .local v12, "top\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    :try_start_d9
    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v13

    .line 676
    .local v13, "a\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v15

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v15

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getWorkspace()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v15

    .line 677
    .local v15, "ws\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelectInsideModels()Z

    move-result v16

    if-nez v16, :cond_11a

    :goto_f3
    if-eqz v13, :cond_11a

    if-eq v13, v15, :cond_11a

    move-object/from16 v16, v0

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0
    :try_end_fd
    .catchall {:try_start_d9 .. :try_end_fd} :catchall_140

    move/from16 v17, v2

    .end local v2    # "l":F
    .local v17, "l":F
    :try_start_ff
    const-string v2, "Model"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_10f

    const-string v0, "PartOperation"

    invoke-virtual {v13, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_110

    :cond_10f
    move-object v12, v13

    :cond_110
    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    move-object v13, v0

    move-object/from16 v0, v16

    move/from16 v2, v17

    goto :goto_f3

    .end local v17    # "l":F
    .restart local v2    # "l":F
    :cond_11a
    move-object/from16 v16, v0

    move/from16 v17, v2

    .line 678
    .end local v2    # "l":F
    .restart local v17    # "l":F
    invoke-interface {v9, v12}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_127

    invoke-virtual {v6, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_127
    .catchall {:try_start_ff .. :try_end_127} :catchall_12d

    :cond_127
    move-object/from16 v0, v16

    move/from16 v2, v17

    goto/16 :goto_72

    .line 666
    .end local v8    # "$i$a$-synchronized-ViewportView$TouchLayer$finishBox$1\\1\\666\\0":I
    .end local v9    # "seen\\1":Ljava/util/Set;
    .end local v11    # "p\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v12    # "top\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v13    # "a\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "s\\1":[F
    .end local v15    # "ws\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    :catchall_12d
    move-exception v0

    move/from16 v20, v3

    move/from16 v21, v4

    goto/16 :goto_250

    .line 671
    .end local v17    # "l":F
    .restart local v2    # "l":F
    .restart local v8    # "$i$a$-synchronized-ViewportView$TouchLayer$finishBox$1\\1\\666\\0":I
    .restart local v9    # "seen\\1":Ljava/util/Set;
    .restart local v11    # "p\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v14    # "s\\1":[F
    :cond_134
    move-object/from16 v16, v0

    move/from16 v17, v2

    .end local v2    # "l":F
    .restart local v17    # "l":F
    goto/16 :goto_72

    .line 669
    .end local v14    # "s\\1":[F
    .end local v17    # "l":F
    .restart local v2    # "l":F
    :cond_13a
    move-object/from16 v16, v0

    move/from16 v17, v2

    .end local v2    # "l":F
    .restart local v17    # "l":F
    goto/16 :goto_72

    .line 666
    .end local v8    # "$i$a$-synchronized-ViewportView$TouchLayer$finishBox$1\\1\\666\\0":I
    .end local v9    # "seen\\1":Ljava/util/Set;
    .end local v11    # "p\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v17    # "l":F
    .restart local v2    # "l":F
    :catchall_140
    move-exception v0

    move/from16 v17, v2

    move/from16 v20, v3

    move/from16 v21, v4

    .end local v2    # "l":F
    .restart local v17    # "l":F
    goto/16 :goto_250

    .line 680
    .end local v17    # "l":F
    .restart local v2    # "l":F
    .restart local v8    # "$i$a$-synchronized-ViewportView$TouchLayer$finishBox$1\\1\\666\\0":I
    .restart local v9    # "seen\\1":Ljava/util/Set;
    :cond_149
    move/from16 v17, v2

    .end local v2    # "l":F
    .end local v8    # "$i$a$-synchronized-ViewportView$TouchLayer$finishBox$1\\1\\666\\0":I
    .end local v9    # "seen\\1":Ljava/util/Set;
    .restart local v17    # "l":F
    :try_start_14b
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_14d
    .catchall {:try_start_14b .. :try_end_14d} :catchall_243

    .line 666
    monitor-exit v7

    .line 681
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->getAdditive()Z

    move-result v0

    if-eqz v0, :cond_1f3

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    move-object v7, v6

    check-cast v7, Ljava/lang/Iterable;

    .local v7, "$this$filter\\2":Ljava/lang/Iterable;
    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    const/4 v9, 0x0

    .line 974
    .local v9, "$i$f$filter\\2\\681":I
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    check-cast v10, Ljava/util/Collection;

    .local v10, "destination\\3":Ljava/util/Collection;
    move-object v11, v7

    .local v11, "$this$filterTo\\3":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 975
    .local v14, "$i$f$filterTo\\3\\974":I
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_17f
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_1e1

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\3":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v13, "n\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v18, 0x0

    .line 681
    .local v18, "$i$a$-filter-ViewportView$TouchLayer$finishBox$2\\4\\975\\0":I
    invoke-static {v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v19

    move/from16 v20, v3

    .end local v3    # "r":F
    .local v20, "r":F
    move-object/from16 v3, v19

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$none\\5":Ljava/lang/Iterable;
    const/16 v19, 0x0

    .line 976
    .local v19, "$i$f$none\\5\\681":I
    move/from16 v21, v4

    .end local v4    # "t":F
    .local v21, "t":F
    instance-of v4, v3, Ljava/util/Collection;

    if-eqz v4, :cond_1af

    move-object v4, v3

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_1af

    const/4 v3, 0x1

    goto :goto_1d4

    .line 977
    :cond_1af
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1b3
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v22

    if-eqz v22, :cond_1d1

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v22

    move-object/from16 v23, v3

    .end local v3    # "$this$none\\5":Ljava/lang/Iterable;
    .local v22, "element\\5":Ljava/lang/Object;
    .local v23, "$this$none\\5":Ljava/lang/Iterable;
    move-object/from16 v3, v22

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v3, "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v24, 0x0

    .line 681
    .local v24, "$i$a$-none-ViewportView$TouchLayer$finishBox$2$1\\6\\977\\4":I
    if-ne v3, v13, :cond_1c9

    const/4 v3, 0x1

    goto :goto_1ca

    :cond_1c9
    const/4 v3, 0x0

    .line 977
    .end local v3    # "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v24    # "$i$a$-none-ViewportView$TouchLayer$finishBox$2$1\\6\\977\\4":I
    :goto_1ca
    if-eqz v3, :cond_1ce

    const/4 v3, 0x0

    goto :goto_1d4

    :cond_1ce
    move-object/from16 v3, v23

    goto :goto_1b3

    .line 978
    .end local v22    # "element\\5":Ljava/lang/Object;
    .end local v23    # "$this$none\\5":Ljava/lang/Iterable;
    .local v3, "$this$none\\5":Ljava/lang/Iterable;
    :cond_1d1
    move-object/from16 v23, v3

    .end local v3    # "$this$none\\5":Ljava/lang/Iterable;
    .restart local v23    # "$this$none\\5":Ljava/lang/Iterable;
    const/4 v3, 0x1

    .line 681
    .end local v19    # "$i$f$none\\5\\681":I
    .end local v23    # "$this$none\\5":Ljava/lang/Iterable;
    :goto_1d4
    nop

    .line 975
    .end local v13    # "n\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v18    # "$i$a$-filter-ViewportView$TouchLayer$finishBox$2\\4\\975\\0":I
    if-eqz v3, :cond_1da

    invoke-interface {v10, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_1da
    move/from16 v3, v20

    move/from16 v4, v21

    const/4 v12, 0x0

    const/4 v13, 0x1

    goto :goto_17f

    .line 979
    .end local v12    # "element\\3":Ljava/lang/Object;
    .end local v20    # "r":F
    .end local v21    # "t":F
    .local v3, "r":F
    .restart local v4    # "t":F
    :cond_1e1
    move/from16 v20, v3

    move/from16 v21, v4

    .end local v3    # "r":F
    .end local v4    # "t":F
    .end local v10    # "destination\\3":Ljava/util/Collection;
    .end local v11    # "$this$filterTo\\3":Ljava/lang/Iterable;
    .end local v14    # "$i$f$filterTo\\3\\974":I
    .restart local v20    # "r":F
    .restart local v21    # "t":F
    move-object v3, v10

    check-cast v3, Ljava/util/List;

    .line 974
    nop

    .end local v7    # "$this$filter\\2":Ljava/lang/Iterable;
    .end local v9    # "$i$f$filter\\2\\681":I
    check-cast v3, Ljava/lang/Iterable;

    .line 681
    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    goto :goto_203

    .line 682
    .end local v20    # "r":F
    .end local v21    # "t":F
    .restart local v3    # "r":F
    .restart local v4    # "t":F
    :cond_1f3
    move/from16 v20, v3

    move/from16 v21, v4

    .end local v3    # "r":F
    .end local v4    # "t":F
    .restart local v20    # "r":F
    .restart local v21    # "t":F
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    move-object v2, v6

    check-cast v2, Ljava/util/List;

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    .line 683
    :goto_203
    move-object v0, v6

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_242

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v2

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x1

    if-ne v3, v4, :cond_220

    const-string v3, ""

    goto :goto_222

    :cond_220
    const-string v3, "s"

    :goto_222
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Selected "

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " object"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->toast(Ljava/lang/String;)Z

    .line 684
    :cond_242
    return-void

    .line 666
    .end local v20    # "r":F
    .end local v21    # "t":F
    .restart local v3    # "r":F
    .restart local v4    # "t":F
    :catchall_243
    move-exception v0

    move/from16 v20, v3

    move/from16 v21, v4

    .end local v3    # "r":F
    .end local v4    # "t":F
    .restart local v20    # "r":F
    .restart local v21    # "t":F
    goto :goto_250

    .end local v17    # "l":F
    .end local v20    # "r":F
    .end local v21    # "t":F
    .restart local v2    # "l":F
    .restart local v3    # "r":F
    .restart local v4    # "t":F
    :catchall_249
    move-exception v0

    move/from16 v17, v2

    move/from16 v20, v3

    move/from16 v21, v4

    .end local v2    # "l":F
    .end local v3    # "r":F
    .end local v4    # "t":F
    .restart local v17    # "l":F
    .restart local v20    # "r":F
    .restart local v21    # "t":F
    :goto_250
    monitor-exit v7

    throw v0
.end method

.method private final finishDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;)V
    .registers 22
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;

    .line 788
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v2

    const/4 v3, 0x0

    .line 789
    .local v3, "$i$a$-synchronized-ViewportView$TouchLayer$finishDrag$1\\1\\788\\0":I
    :try_start_10
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getTool()Lcom/exampletest/mobilestudiotest/core/Tool;

    move-result-object v5

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Tool;->ordinal()I

    move-result v5

    aget v5, v6, v5

    packed-switch v5, :pswitch_data_fa

    const-string v5, "Rotate"

    goto :goto_2f

    :pswitch_2a
    const-string v5, "Resize"

    goto :goto_2f

    :pswitch_2d
    const-string v5, "Move"

    :goto_2f
    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->begin(Ljava/lang/String;)V

    .line 790
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getParts()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$forEachIndexed\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 998
    .local v5, "$i$f$forEachIndexed\\2\\790":I
    const/4 v6, 0x0

    .line 999
    .local v6, "index\\2":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_3e
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_de

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "item\\2":Ljava/lang/Object;
    add-int/lit8 v9, v6, 0x1

    .end local v6    # "index\\2":I
    .local v9, "index\\2":I
    if-gez v6, :cond_4f

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_4f
    move-object v10, v8

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v6, "i\\3":I
    move-object v12, v10

    .local v12, "part\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v10, 0x0

    .line 791
    .local v10, "$i$a$-forEachIndexed-ViewportView$TouchLayer$finishDrag$1$1\\3\\999\\1":I
    sget-object v11, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v11, v12}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v15

    .line 792
    .local v15, "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartCf()Ljava/util/List;

    move-result-object v11

    invoke-interface {v11, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-static {v15, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_92

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v11

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v11

    move-object v13, v11

    new-instance v11, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;

    move-object v14, v13

    const-string v13, "CFrame"

    move-object/from16 v17, v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartCf()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/16 v16, 0x1

    move-object/from16 v19, v14

    move-object v14, v0

    move-object/from16 v0, v19

    invoke-direct/range {v11 .. v16}, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Z)V

    move-object/from16 v18, v15

    .end local v15    # "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v18, "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    check-cast v11, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;

    invoke-virtual {v0, v11}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->record(Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;)V

    goto :goto_96

    .end local v18    # "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .restart local v15    # "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    :cond_92
    move-object/from16 v17, v0

    move-object/from16 v18, v15

    .line 793
    .end local v15    # "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .restart local v18    # "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    :goto_96
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v0

    const-string v11, "size"

    invoke-virtual {v0, v11}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a5

    const-string v0, "size"

    goto :goto_a7

    :cond_a5
    const-string v0, "Size"

    :goto_a7
    move-object v13, v0

    .line 794
    .local v13, "key\\3":Ljava/lang/String;
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, v12}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v15

    .line 795
    .local v15, "s\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartSize()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v15, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_d8

    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v0

    new-instance v11, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartSize()Ljava/util/List;

    move-result-object v14

    invoke-interface {v14, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    const/16 v16, 0x1

    invoke-direct/range {v11 .. v16}, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Z)V

    check-cast v11, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;

    invoke-virtual {v0, v11}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->record(Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;)V

    .line 796
    :cond_d8
    nop

    .line 999
    .end local v6    # "i\\3":I
    .end local v10    # "$i$a$-forEachIndexed-ViewportView$TouchLayer$finishDrag$1$1\\3\\999\\1":I
    .end local v12    # "part\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v13    # "key\\3":Ljava/lang/String;
    .end local v15    # "s\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v18    # "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    move v6, v9

    move-object/from16 v0, v17

    .end local v8    # "item\\2":Ljava/lang/Object;
    goto/16 :goto_3e

    .line 1000
    .end local v9    # "index\\2":I
    .local v6, "index\\2":I
    :cond_de
    move-object/from16 v17, v0

    .line 797
    .end local v4    # "$this$forEachIndexed\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$forEachIndexed\\2\\790":I
    .end local v6    # "index\\2":I
    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->commit()V

    .line 798
    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->markDirty()V

    .line 799
    nop

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$finishDrag$1\\1\\788\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_f5
    .catchall {:try_start_10 .. :try_end_f5} :catchall_f7

    .line 788
    monitor-exit v2

    .line 800
    return-void

    .line 788
    :catchall_f7
    move-exception v0

    monitor-exit v2

    throw v0

    :pswitch_data_fa
    .packed-switch 0x1
        :pswitch_2d
        :pswitch_2a
    .end packed-switch
.end method

.method private final finishGuiDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;)V
    .registers 19
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    .line 551
    move-object/from16 v1, p0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->getState()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;

    move-result-object v2

    .line 552
    .local v2, "s":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v3

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v3

    const/4 v4, 0x0

    .line 553
    .local v4, "$i$a$-synchronized-ViewportView$TouchLayer$finishGuiDrag$1\\1\\552\\0":I
    :try_start_14
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v5

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getHandle()I

    move-result v6

    const/4 v7, -0x1

    if-ne v6, v7, :cond_26

    const-string v6, "Move GUI"

    goto :goto_28

    :cond_26
    const-string v6, "Resize GUI"

    :goto_28
    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->begin(Ljava/lang/String;)V

    .line 554
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    const-string v6, "Position"

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    move-object v10, v5

    .local v10, "pos\\1":Ljava/lang/Object;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    const-string v6, "Size"

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    move-object v15, v5

    .line 555
    .local v15, "size\\1":Ljava/lang/Object;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getPos()Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v5

    invoke-static {v10, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_68

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v5

    new-instance v6, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    const-string v8, "Position"

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getPos()Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v9

    const/4 v11, 0x1

    invoke-direct/range {v6 .. v11}, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Z)V

    check-cast v6, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->record(Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;)V

    .line 556
    :cond_68
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getSize()Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v5

    invoke-static {v15, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_90

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v5

    new-instance v11, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getInst()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v12

    const-string v13, "Size"

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;->getSize()Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v14

    const/16 v16, 0x1

    invoke-direct/range {v11 .. v16}, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Z)V

    check-cast v11, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;

    invoke-virtual {v5, v11}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->record(Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;)V

    .line 557
    :cond_90
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->commit()V

    .line 558
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->markDirty()V

    .line 559
    nop

    .end local v4    # "$i$a$-synchronized-ViewportView$TouchLayer$finishGuiDrag$1\\1\\552\\0":I
    .end local v10    # "pos\\1":Ljava/lang/Object;
    .end local v15    # "size\\1":Ljava/lang/Object;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_a5
    .catchall {:try_start_14 .. :try_end_a5} :catchall_a7

    .line 552
    monitor-exit v3

    .line 560
    return-void

    .line 552
    :catchall_a7
    move-exception v0

    monitor-exit v3

    throw v0
.end method

.method private final finishPartDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;)V
    .registers 21
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    .line 914
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v2

    const/4 v3, 0x0

    .line 915
    .local v3, "$i$a$-synchronized-ViewportView$TouchLayer$finishPartDrag$1\\1\\914\\0":I
    :try_start_10
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v4

    const-string v5, "Drag"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->begin(Ljava/lang/String;)V

    .line 916
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getParts()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$forEachIndexed\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1016
    .local v5, "$i$f$forEachIndexed\\2\\916":I
    const/4 v6, 0x0

    .line 1017
    .local v6, "index\\2":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_29
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_82

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "item\\2":Ljava/lang/Object;
    add-int/lit8 v9, v6, 0x1

    .end local v6    # "index\\2":I
    .local v9, "index\\2":I
    if-gez v6, :cond_3a

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_3a
    move-object v10, v8

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v6, "i\\3":I
    move-object v12, v10

    .local v12, "part\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v10, 0x0

    .line 917
    .local v10, "$i$a$-forEachIndexed-ViewportView$TouchLayer$finishPartDrag$1$1\\3\\1017\\1":I
    sget-object v11, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v11, v12}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v15

    .line 918
    .local v15, "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getStartCf()Ljava/util/List;

    move-result-object v11

    invoke-interface {v11, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    invoke-static {v15, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_7b

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v11

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v11

    move-object v13, v11

    new-instance v11, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;

    move-object v14, v13

    const-string v13, "CFrame"

    move-object/from16 v17, v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getStartCf()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/16 v16, 0x1

    move-object/from16 v18, v14

    move-object v14, v0

    move-object/from16 v0, v18

    invoke-direct/range {v11 .. v16}, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op$Prop;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Z)V

    check-cast v11, Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;

    invoke-virtual {v0, v11}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->record(Lcom/exampletest/mobilestudiotest/core/UndoManager$Op;)V

    goto :goto_7d

    :cond_7b
    move-object/from16 v17, v0

    .line 919
    :goto_7d
    nop

    .line 1017
    .end local v6    # "i\\3":I
    .end local v10    # "$i$a$-forEachIndexed-ViewportView$TouchLayer$finishPartDrag$1$1\\3\\1017\\1":I
    .end local v12    # "part\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v15    # "cf\\3":Lcom/exampletest/mobilestudiotest/model/CFrame;
    move v6, v9

    move-object/from16 v0, v17

    .end local v8    # "item\\2":Ljava/lang/Object;
    goto :goto_29

    .line 1018
    .end local v9    # "index\\2":I
    .local v6, "index\\2":I
    :cond_82
    move-object/from16 v17, v0

    .line 920
    .end local v4    # "$this$forEachIndexed\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$forEachIndexed\\2\\916":I
    .end local v6    # "index\\2":I
    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getUndo()Lcom/exampletest/mobilestudiotest/core/UndoManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/UndoManager;->commit()V

    .line 921
    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->markDirty()V

    .line 922
    nop

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$finishPartDrag$1\\1\\914\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_99
    .catchall {:try_start_10 .. :try_end_99} :catchall_9b

    .line 914
    monitor-exit v2

    .line 923
    return-void

    .line 914
    :catchall_9b
    move-exception v0

    monitor-exit v2

    throw v0
.end method

.method private final getActiveJoy()Z
    .registers 8

    .line 150
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const-string v1, "<get-values>(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 928
    .local v1, "$i$f$any\\1\\150":I
    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_19

    goto :goto_32

    .line 929
    :cond_19
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1d
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_31

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\1":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    .local v5, "it\\2":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    const/4 v6, 0x0

    .line 150
    .local v6, "$i$a$-any-ViewportView$TouchLayer$activeJoy$1\\2\\929\\0":I
    instance-of v5, v5, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;

    .line 929
    .end local v5    # "it\\2":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    .end local v6    # "$i$a$-any-ViewportView$TouchLayer$activeJoy$1\\2\\929\\0":I
    if-eqz v5, :cond_1d

    const/4 v3, 0x1

    goto :goto_32

    .line 930
    .end local v4    # "element\\1":Ljava/lang/Object;
    :cond_31
    nop

    .line 150
    .end local v0    # "$this$any\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$any\\1\\150":I
    :goto_32
    return v3
.end method

.method private final getAdditive()Z
    .registers 2

    .line 377
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMultiSelect()Z

    move-result v0

    if-nez v0, :cond_1a

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModifierHeld()Z

    move-result v0

    if-nez v0, :cond_1a

    const/4 v0, 0x0

    goto :goto_1b

    :cond_1a
    const/4 v0, 0x1

    :goto_1b
    return v0
.end method

.method private final getDefaultJoyX()F
    .registers 3

    .line 146
    const/high16 v0, 0x42200000    # 40.0f

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v1, v0

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v0

    add-float/2addr v1, v0

    return v1
.end method

.method private final getDefaultJoyY()F
    .registers 4

    .line 147
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x42200000    # 40.0f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v2, v1

    sub-float/2addr v0, v2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v1

    sub-float/2addr v0, v1

    return v0
.end method

.method private final getFixedStick()Z
    .registers 3

    .line 151
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_1c

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Settings;->getMovementMode()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Thumbstick"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1c

    const/4 v0, 0x1

    goto :goto_1d

    :cond_1c
    const/4 v0, 0x0

    :goto_1d
    return v0
.end method

.method private final getJoyR()F
    .registers 3

    .line 145
    const/high16 v0, 0x42600000    # 56.0f

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v1, v0

    return v1
.end method

.method private final insideIconButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZ)V
    .registers 16
    .param p1, "c"    # Landroid/graphics/Canvas;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "r"    # F
    .param p6, "active"    # Z

    .line 305
    const-string v6, ""

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v7, p6

    .end local p1    # "c":Landroid/graphics/Canvas;
    .end local p2    # "name":Ljava/lang/String;
    .end local p3    # "x":F
    .end local p4    # "y":F
    .end local p5    # "r":F
    .end local p6    # "active":Z
    .local v1, "c":Landroid/graphics/Canvas;
    .local v2, "name":Ljava/lang/String;
    .local v3, "x":F
    .local v4, "y":F
    .local v5, "r":F
    .local v7, "active":Z
    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->circleButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFLjava/lang/String;Z)V

    .line 306
    .end local v1    # "c":Landroid/graphics/Canvas;
    .restart local p1    # "c":Landroid/graphics/Canvas;
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const p3, 0x3fcccccd    # 1.6f

    iget p4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr p4, p3

    invoke-virtual {p2, p4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/4 p3, -0x1

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 307
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    new-instance p3, Landroid/graphics/DashPathEffect;

    const/high16 p4, 0x40400000    # 3.0f

    iget p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr p5, p4

    const/high16 p4, 0x40200000    # 2.5f

    iget p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr p6, p4

    const/4 p4, 0x2

    new-array p4, p4, [F

    const/4 v0, 0x0

    aput p5, p4, v0

    const/4 p5, 0x1

    aput p6, p4, p5

    const/4 p5, 0x0

    invoke-direct {p3, p4, p5}, Landroid/graphics/DashPathEffect;-><init>([FF)V

    check-cast p3, Landroid/graphics/PathEffect;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 308
    const/high16 p2, 0x3f000000    # 0.5f

    mul-float p5, v5, p2

    sub-float p3, v3, p5

    const p4, 0x3ed70a3d    # 0.42f

    mul-float p5, v5, p4

    sub-float p5, v4, p5

    mul-float/2addr p2, v5

    add-float/2addr p2, v3

    mul-float/2addr p4, v5

    add-float/2addr p4, v4

    iget-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    move v8, p4

    move p4, p2

    move p2, p3

    move p3, p5

    move p5, v8

    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 309
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/4 p3, 0x0

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 310
    const p2, 0x3da3d70a    # 0.08f

    mul-float p5, v5, p2

    sub-float p2, v3, p5

    const v0, 0x3e4ccccd    # 0.2f

    mul-float p5, v5, v0

    sub-float p3, v4, p5

    const p4, 0x3e99999a    # 0.3f

    mul-float p5, v5, p4

    add-float p4, v3, p5

    mul-float p5, v5, v0

    add-float/2addr p5, v4

    iget-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 311
    const p2, 0x3eae147b    # 0.34f

    mul-float p5, v5, p2

    sub-float p2, v3, p5

    const p3, 0x3d4ccccd    # 0.05f

    mul-float p5, v5, p3

    sub-float p3, v4, p5

    const p4, 0x3e23d70a    # 0.16f

    mul-float p5, v5, p4

    sub-float p4, v3, p5

    mul-float p5, v5, v0

    add-float/2addr p5, v4

    iget-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    .line 927
    move-object v0, p6

    .local v0, "$this$insideIconButton_u24lambda_u249\\1":Landroid/graphics/Paint;
    const/4 v1, 0x0

    .line 311
    .local v1, "$i$a$-apply-ViewportView$TouchLayer$insideIconButton$1\\1\\311\\0":I
    const/16 v6, 0x78

    invoke-virtual {v0, v6}, Landroid/graphics/Paint;->setAlpha(I)V

    .end local v0    # "$this$insideIconButton_u24lambda_u249\\1":Landroid/graphics/Paint;
    .end local v1    # "$i$a$-apply-ViewportView$TouchLayer$insideIconButton$1\\1\\311\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 312
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/16 p3, 0xff

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 313
    return-void
.end method

.method private final move(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;FF)V
    .registers 14
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    .param p2, "nx"    # F
    .param p3, "ny"    # F

    .line 453
    nop

    .line 454
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;

    if-eqz v0, :cond_10

    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->setJoy(FF)V

    goto/16 :goto_39f

    .line 455
    :cond_10
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;

    if-eqz v0, :cond_22

    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->updateDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;)V

    goto/16 :goto_39f

    .line 456
    :cond_22
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    const/4 v1, 0x1

    if-eqz v0, :cond_69

    .line 457
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    .line 458
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getActive()Z

    move-result v0

    if-nez v0, :cond_58

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v0

    sub-float v0, p2, v0

    float-to-double v2, v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v0

    sub-float v0, p3, v0

    float-to-double v4, v0

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v2

    double-to-float v0, v2

    const/high16 v2, 0x41000000    # 8.0f

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v2

    cmpl-float v0, v0, v3

    if-lez v0, :cond_58

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->setActive(Z)V

    .line 459
    :cond_58
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getActive()Z

    move-result v0

    if-eqz v0, :cond_39f

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->updatePartDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;)V

    goto/16 :goto_39f

    .line 461
    :cond_69
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    if-eqz v0, :cond_75

    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    goto/16 :goto_39f

    .line 462
    :cond_75
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    if-eqz v0, :cond_87

    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->dragAdorn(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;)V

    goto/16 :goto_39f

    .line 463
    :cond_87
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;

    const/high16 v2, 0x40c00000    # 6.0f

    if-eqz v0, :cond_c8

    .line 464
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v0

    sub-float v0, p2, v0

    float-to-double v3, v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v0

    sub-float v0, p3, v0

    float-to-double v5, v0

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v3

    double-to-float v0, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v2

    cmpl-float v0, v0, v3

    if-lez v0, :cond_ad

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;->setMoved(Z)V

    .line 465
    :cond_ad
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    .line 466
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->size()I

    move-result v0

    if-ne v0, v1, :cond_39f

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    const-string v1, "Move"

    invoke-virtual {v0, v1, p2, p3}, Lcom/exampletest/mobilestudiotest/core/Studio;->pluginMouseEvent(Ljava/lang/String;FF)Z

    goto/16 :goto_39f

    .line 468
    :cond_c8
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    if-eqz v0, :cond_122

    .line 469
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    .line 470
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->getActive()Z

    move-result v0

    if-nez v0, :cond_fb

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v0

    sub-float v0, p2, v0

    float-to-double v3, v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v0

    sub-float v0, p3, v0

    float-to-double v5, v0

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v3

    double-to-float v0, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v2

    cmpl-float v0, v0, v3

    if-lez v0, :cond_fb

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->setActive(Z)V

    .line 471
    :cond_fb
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->getActive()Z

    move-result v0

    if-eqz v0, :cond_39f

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->getState()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;

    move-result-object v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v2

    sub-float v2, p2, v2

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v3

    sub-float v3, p3, v3

    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->dragTo(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;FF)V

    goto/16 :goto_39f

    .line 473
    :cond_122
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;

    if-eqz v0, :cond_14a

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;->getScroll()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    move-result-object v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v2

    sub-float v2, p2, v2

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v3

    sub-float v3, p3, v3

    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scrollBy(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;FF)V

    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    goto/16 :goto_39f

    .line 474
    :cond_14a
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;

    if-eqz v0, :cond_1af

    .line 476
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->getAcc()F

    move-result v2

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v3

    sub-float v3, p3, v3

    add-float/2addr v2, v3

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->setAcc(F)V

    .line 477
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    .line 478
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->guiUnit()F

    move-result v0

    const/high16 v2, 0x41900000    # 18.0f

    mul-float/2addr v0, v2

    .line 479
    .local v0, "step":F
    :goto_172
    move-object v2, p1

    check-cast v2, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->getAcc()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    cmpl-float v2, v2, v0

    if-ltz v2, :cond_39f

    .line 480
    move-object v2, p1

    check-cast v2, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->getAcc()F

    move-result v2

    const/4 v3, 0x0

    cmpl-float v2, v2, v3

    if-lez v2, :cond_18f

    move v2, v1

    goto :goto_190

    :cond_18f
    const/4 v2, -0x1

    .line 481
    .local v2, "z":I
    :goto_190
    move-object v3, p1

    check-cast v3, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->getAcc()F

    move-result v4

    int-to-float v5, v2

    mul-float/2addr v5, v0

    sub-float/2addr v4, v5

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->setAcc(F)V

    .line 482
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v3

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v4

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v5

    invoke-virtual {v3, v4, v5, v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->pluginWheel(FFI)V

    .end local v2    # "z":I
    goto :goto_172

    .line 485
    .end local v0    # "step":F
    :cond_1af
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    const/4 v2, 0x0

    if-eqz v0, :cond_2e9

    .line 486
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getCancelled()Z

    move-result v0

    if-nez v0, :cond_2bc

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v0

    sub-float v0, p2, v0

    float-to-double v3, v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v0

    sub-float v0, p3, v0

    float-to-double v5, v0

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v3

    double-to-float v0, v3

    const/high16 v3, 0x41400000    # 12.0f

    iget v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v4, v3

    cmpl-float v0, v0, v4

    if-lez v0, :cond_2bc

    .line 487
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getScroll()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    move-result-object v8

    .line 488
    .local v8, "s":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    if-eqz v8, :cond_235

    .line 490
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->setCancelled(Z)V

    .line 491
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getHit()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v1

    invoke-virtual {v0, v1, p2, p3, v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->release(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;FFZ)V

    .line 492
    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getId()I

    move-result v5

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v6

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v7

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V

    .line 493
    .local v3, "g":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getId()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 494
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v1

    sub-float v1, p2, v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v2

    sub-float v2, p3, v2

    invoke-virtual {v0, v8, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->scrollBy(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;FF)V

    .line 495
    invoke-virtual {v3, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;->setX(F)V

    invoke-virtual {v3, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;->setY(F)V

    .line 496
    return-void

    .line 498
    .end local v3    # "g":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;
    :cond_235
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v0

    if-nez v0, :cond_2bc

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v0

    sub-float v0, p3, v0

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v3

    sub-float v3, p2, v3

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    cmpl-float v0, v0, v3

    if-lez v0, :cond_2bc

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    move-object v3, p1

    check-cast v3, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getHit()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v3

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v4

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v5

    invoke-virtual {v0, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->canWheel(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;FF)Z

    move-result v0

    if-eqz v0, :cond_2bc

    .line 500
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->setCancelled(Z)V

    .line 501
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getHit()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v1

    invoke-virtual {v0, v1, p2, p3, v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->release(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;FFZ)V

    .line 502
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getId()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getId()I

    move-result v3

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v4

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v5

    invoke-direct {v2, p0, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    move-object v3, v2

    .line 927
    .local v3, "it\\1":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;
    const/4 v4, 0x0

    .line 502
    .local v4, "$i$a$-also-ViewportView$TouchLayer$move$1\\1\\502\\0":I
    invoke-virtual {v3, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->setX(F)V

    invoke-virtual {v3, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->setY(F)V

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v5

    sub-float v5, p3, v5

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->setAcc(F)V

    .end local v3    # "it\\1":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;
    .end local v4    # "$i$a$-also-ViewportView$TouchLayer$move$1\\1\\502\\0":I
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 503
    return-void

    .line 506
    .end local v8    # "s":Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    :cond_2bc
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    .line 508
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getCancelled()Z

    move-result v0

    if-nez v0, :cond_39f

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v0

    if-nez v0, :cond_39f

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getHit()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v1

    invoke-virtual {v0, v1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->pluginPointerMove(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;FF)V

    goto/16 :goto_39f

    .line 510
    :cond_2e9
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    if-eqz v0, :cond_399

    .line 511
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v0

    sub-float v3, p2, v0

    .local v3, "dx":F
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v0

    sub-float v4, p3, v0

    .line 512
    .local v4, "dy":F
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX0()F

    move-result v0

    sub-float v0, p2, v0

    float-to-double v5, v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY0()F

    move-result v0

    sub-float v0, p3, v0

    float-to-double v7, v0

    invoke-static {v5, v6, v7, v8}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v5

    double-to-float v0, v5

    const/high16 v5, 0x41200000    # 10.0f

    iget v6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v6, v5

    cmpl-float v0, v0, v6

    if-lez v0, :cond_31b

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->setMoved(Z)V

    .line 513
    :cond_31b
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    .line 514
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const-string v5, "<get-values>(...)"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$count\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 950
    .local v5, "$i$f$count\\2\\514":I
    move-object v6, v0

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_339

    goto :goto_359

    .line 951
    :cond_339
    const/4 v2, 0x0

    .line 952
    .local v2, "count\\2":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_33e
    :goto_33e
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_358

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\2":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    .local v8, "it\\3":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    const/4 v9, 0x0

    .line 514
    .local v9, "$i$a$-count-ViewportView$TouchLayer$move$2\\3\\952\\0":I
    instance-of v8, v8, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    .line 952
    .end local v8    # "it\\3":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    .end local v9    # "$i$a$-count-ViewportView$TouchLayer$move$2\\3\\952\\0":I
    if-eqz v8, :cond_33e

    add-int/lit8 v2, v2, 0x1

    if-gez v2, :cond_33e

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v7    # "element\\2":Ljava/lang/Object;
    goto :goto_33e

    .line 953
    :cond_358
    nop

    .line 514
    .end local v0    # "$this$count\\2":Ljava/lang/Iterable;
    .end local v2    # "count\\2":I
    .end local v5    # "$i$f$count\\2\\514":I
    :goto_359
    if-ne v2, v1, :cond_39f

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getMoved()Z

    move-result v0

    if-eqz v0, :cond_39f

    .line 515
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v1

    const/4 v2, 0x0

    .line 516
    .local v2, "$i$a$-synchronized-ViewportView$TouchLayer$move$3\\4\\515\\0":I
    :try_start_372
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v5

    .line 517
    .local v5, "play\\4":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    if-eqz v5, :cond_383

    invoke-virtual {v5, v3, v4}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->cameraDrag(FF)V

    invoke-virtual {v5, p2, p3}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->pointerMove(FF)V

    goto :goto_391

    :cond_383
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    neg-float v6, v3

    const v7, 0x3ba3d70a    # 0.005f

    mul-float/2addr v6, v7

    neg-float v8, v4

    mul-float/2addr v8, v7

    invoke-virtual {v0, v6, v8}, Lcom/exampletest/mobilestudiotest/core/Studio;->rotateEditCamera(FF)V

    .line 518
    :goto_391
    nop

    .end local v2    # "$i$a$-synchronized-ViewportView$TouchLayer$move$3\\4\\515\\0":I
    .end local v5    # "play\\4":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_394
    .catchall {:try_start_372 .. :try_end_394} :catchall_396

    .line 515
    monitor-exit v1

    goto :goto_39f

    :catchall_396
    move-exception v0

    monitor-exit v1

    throw v0

    .line 521
    .end local v3    # "dx":F
    .end local v4    # "dy":F
    :cond_399
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setX(F)V

    invoke-virtual {p1, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->setY(F)V

    .line 523
    :cond_39f
    :goto_39f
    return-void
.end method

.method private final multiIconButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFZ)V
    .registers 15
    .param p1, "c"    # Landroid/graphics/Canvas;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "r"    # F
    .param p6, "active"    # Z

    .line 325
    const-string v6, ""

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v7, p6

    .end local p1    # "c":Landroid/graphics/Canvas;
    .end local p2    # "name":Ljava/lang/String;
    .end local p3    # "x":F
    .end local p4    # "y":F
    .end local p5    # "r":F
    .end local p6    # "active":Z
    .local v1, "c":Landroid/graphics/Canvas;
    .local v2, "name":Ljava/lang/String;
    .local v3, "x":F
    .local v4, "y":F
    .local v5, "r":F
    .local v7, "active":Z
    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->circleButton(Landroid/graphics/Canvas;Ljava/lang/String;FFFLjava/lang/String;Z)V

    .line 326
    .end local v1    # "c":Landroid/graphics/Canvas;
    .restart local p1    # "c":Landroid/graphics/Canvas;
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/high16 p3, 0x40000000    # 2.0f

    iget p4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr p4, p3

    invoke-virtual {p2, p4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    const/4 p3, -0x1

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 327
    const p2, 0x3ea3d70a    # 0.32f

    mul-float v0, v5, p2

    .line 328
    .local v0, "s":F
    const v1, 0x3fb33333    # 1.4f

    mul-float p2, v0, v1

    sub-float p2, v3, p2

    mul-float p3, v0, v1

    sub-float p3, v4, p3

    const v6, 0x3ecccccd    # 0.4f

    mul-float p4, v0, v6

    add-float/2addr p4, v3

    mul-float p5, v0, v6

    add-float/2addr p5, v4

    iget-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 329
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    sget-object p3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 330
    mul-float p2, v0, v6

    sub-float p2, v3, p2

    mul-float/2addr v6, v0

    sub-float p3, v4, v6

    mul-float p4, v0, v1

    add-float/2addr p4, v3

    mul-float/2addr v1, v0

    add-float p5, v4, v1

    iget-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->paint:Landroid/graphics/Paint;

    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 331
    return-void
.end method

.method private final overlapsOthers(Ljava/util/List;)Z
    .registers 18
    .param p1, "parts"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;)Z"
        }
    .end annotation

    .line 725
    new-instance v0, Ljava/util/IdentityHashMap;

    invoke-direct {v0}, Ljava/util/IdentityHashMap;-><init>()V

    check-cast v0, Ljava/util/Map;

    invoke-static {v0}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v0

    move-object v1, v0

    .line 927
    .local v1, "s\\1":Ljava/util/Set;
    const/4 v2, 0x0

    .line 725
    .local v2, "$i$a$-also-ViewportView$TouchLayer$overlapsOthers$moved$1\\1\\725\\0":I
    move-object/from16 v3, p1

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$forEach\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 984
    .local v4, "$i$f$forEach\\2\\725":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_16
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_29

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 725
    .local v8, "$i$a$-forEach-ViewportView$TouchLayer$overlapsOthers$moved$1$1\\3\\984\\1":I
    invoke-interface {v1, v7}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 984
    .end local v7    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-forEach-ViewportView$TouchLayer$overlapsOthers$moved$1$1\\3\\984\\1":I
    nop

    .end local v6    # "element\\2":Ljava/lang/Object;
    goto :goto_16

    .line 985
    :cond_29
    nop

    .line 725
    .end local v3    # "$this$forEach\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$forEach\\2\\725":I
    nop

    .line 726
    .end local v1    # "s\\1":Ljava/util/Set;
    .end local v2    # "$i$a$-also-ViewportView$TouchLayer$overlapsOthers$moved$1\\1\\725\\0":I
    .local v0, "moved":Ljava/util/Set;
    move-object/from16 v1, p0

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->renderParts()Ljava/util/List;

    move-result-object v2

    .line 727
    .local v2, "all":Ljava/util/List;
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_3b
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_c6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 728
    .local v4, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v6, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v6, v4}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v6

    invoke-virtual {v6}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v7

    move-object v9, v7

    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v9, "a":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v6}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v6

    move-object v10, v6

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 729
    .local v10, "b":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v6, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {v6, v4, v8, v7, v8}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->shapeOf$default(Lcom/exampletest/mobilestudiotest/engine/Geometry;Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/engine/ConvexShape;

    move-result-object v6

    .line 730
    .local v6, "shape":Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_68
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_3b

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    move-object v14, v8

    check-cast v14, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 731
    .local v14, "o":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-interface {v0, v14}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_68

    const-string v8, "CanCollide"

    invoke-virtual {v14, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    invoke-static {v8, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_68

    .line 732
    sget-object v8, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v8, v14}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v8

    invoke-virtual {v8}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v11, "oa":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v8}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v8

    move-object v12, v8

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 733
    .local v12, "ob":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v8, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    const v13, -0x430a3d71    # -0.03f

    invoke-virtual/range {v8 .. v13}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;F)Z

    move-result v8

    if-eqz v8, :cond_68

    .line 734
    sget-object v8, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v8, v6, v9, v10, v14}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->contact(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v8

    if-eqz v8, :cond_68

    invoke-virtual {v8}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_68

    .line 735
    .local v8, "push":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v13

    const v15, 0x3cf5c28f    # 0.03f

    cmpl-float v13, v13, v15

    if-lez v13, :cond_68

    const/4 v3, 0x1

    return v3

    .line 738
    .end local v4    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v6    # "shape":Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    .end local v8    # "push":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "a":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v10    # "b":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "oa":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v12    # "ob":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v14    # "o":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_c6
    return v5
.end method

.method private final pressButton(Ljava/lang/String;Z)V
    .registers 9
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "down"    # Z

    .line 578
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    .line 579
    .local v0, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    nop

    .line 580
    const-string v1, "up"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1e

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1, p2}, Lcom/exampletest/mobilestudiotest/core/Studio;->setFlyUp(Z)V

    goto/16 :goto_182

    .line 581
    :cond_1e
    const-string v1, "down"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_31

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1, p2}, Lcom/exampletest/mobilestudiotest/core/Studio;->setFlyDown(Z)V

    goto/16 :goto_182

    .line 582
    :cond_31
    const-string v1, "speed"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_45

    if-eqz p2, :cond_45

    new-instance v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)V

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_182

    .line 583
    :cond_45
    const-string v1, "boxsel"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5b

    if-eqz p2, :cond_5b

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda3;

    invoke-direct {v2, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda3;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    invoke-virtual {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_182

    .line 584
    :cond_5b
    const-string v1, "multisel"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_71

    if-eqz p2, :cond_71

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda4;

    invoke-direct {v2, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    invoke-virtual {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_182

    .line 585
    :cond_71
    const-string v1, "insidesel"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_87

    if-eqz p2, :cond_87

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda5;

    invoke-direct {v2, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda5;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    invoke-virtual {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_182

    .line 586
    :cond_87
    const-string v1, "plugin_off"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_af

    if-eqz p2, :cond_af

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v1

    .line 927
    const/4 v4, 0x0

    .line 586
    .local v4, "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$5\\1\\586\\0":I
    :try_start_a0
    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->deactivatePlugin(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v4    # "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$5\\1\\586\\0":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_a9
    .catchall {:try_start_a0 .. :try_end_a9} :catchall_ac

    monitor-exit v1

    goto/16 :goto_182

    :catchall_ac
    move-exception v2

    monitor-exit v1

    throw v2

    .line 587
    :cond_af
    const-string v1, "jump"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d3

    iput-boolean p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->jumpDown:Z

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 927
    const/4 v2, 0x0

    .line 587
    .local v2, "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$6\\2\\587\\0":I
    if-eqz v0, :cond_d0

    :try_start_c7
    invoke-virtual {v0, p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->setJumpHeld(Z)V

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_cc
    .catchall {:try_start_c7 .. :try_end_cc} :catchall_cd

    goto :goto_d0

    .end local v2    # "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$6\\2\\587\\0":I
    :catchall_cd
    move-exception v2

    monitor-exit v1

    throw v2

    :cond_d0
    :goto_d0
    monitor-exit v1

    goto/16 :goto_182

    .line 588
    :cond_d3
    const-string v1, "shiftlock"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_f7

    if-eqz p2, :cond_f7

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 927
    const/4 v2, 0x0

    .line 588
    .local v2, "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$7\\3\\588\\0":I
    if-eqz v0, :cond_f4

    :try_start_eb
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->toggleShiftLock()V

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_f0
    .catchall {:try_start_eb .. :try_end_f0} :catchall_f1

    goto :goto_f4

    .end local v2    # "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$7\\3\\588\\0":I
    :catchall_f1
    move-exception v2

    monitor-exit v1

    throw v2

    :cond_f4
    :goto_f4
    monitor-exit v1

    goto/16 :goto_182

    .line 589
    :cond_f7
    const-string v1, "prompt"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_11a

    if-eqz p2, :cond_11a

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 927
    const/4 v2, 0x0

    .line 589
    .local v2, "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$8\\4\\589\\0":I
    if-eqz v0, :cond_118

    :try_start_10f
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->triggerPrompt()V

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_114
    .catchall {:try_start_10f .. :try_end_114} :catchall_115

    goto :goto_118

    .end local v2    # "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$8\\4\\589\\0":I
    :catchall_115
    move-exception v2

    monitor-exit v1

    throw v2

    :cond_118
    :goto_118
    monitor-exit v1

    goto :goto_182

    .line 590
    :cond_11a
    const-string v1, "action:"

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p1, v1, v3, v4, v2}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_145

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 927
    const/4 v2, 0x0

    .line 590
    .local v2, "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$9\\5\\590\\0":I
    if-eqz v0, :cond_143

    :try_start_132
    const-string v3, "action:"

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {p1, v3}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3, p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->pressAction(Ljava/lang/String;Z)V

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_13f
    .catchall {:try_start_132 .. :try_end_13f} :catchall_140

    goto :goto_143

    .end local v2    # "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$9\\5\\590\\0":I
    :catchall_140
    move-exception v2

    monitor-exit v1

    throw v2

    :cond_143
    :goto_143
    monitor-exit v1

    goto :goto_182

    .line 591
    :cond_145
    const-string v1, "tool:"

    invoke-static {p1, v1, v3, v4, v2}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    if-eqz p2, :cond_182

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    const/4 v2, 0x0

    .line 592
    .local v2, "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$10\\6\\591\\0":I
    :try_start_15b
    const-string v3, "tool:"

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {p1, v3}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    .line 593
    .local v3, "i\\6":I
    if-eqz v0, :cond_17d

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->backpackTools()Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_17d

    invoke-static {v4, v3}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v4, :cond_17d

    .line 927
    .local v4, "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v5, 0x0

    .line 593
    .local v5, "$i$a$-let-ViewportView$TouchLayer$pressButton$10$1\\7\\593\\6":I
    invoke-virtual {v0, v4}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->toggleTool(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v4    # "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v5    # "$i$a$-let-ViewportView$TouchLayer$pressButton$10$1\\7\\593\\6":I
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_17d
    .catchall {:try_start_15b .. :try_end_17d} :catchall_17f

    .line 591
    .end local v2    # "$i$a$-synchronized-ViewportView$TouchLayer$pressButton$10\\6\\591\\0":I
    .end local v3    # "i\\6":I
    :cond_17d
    monitor-exit v1

    goto :goto_182

    :catchall_17f
    move-exception v2

    monitor-exit v1

    throw v2

    .line 596
    :cond_182
    :goto_182
    return-void
.end method

.method static final pressButton$lambda$36(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)V
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    .line 582
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/SettingsDialog;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/SettingsDialog;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda6;

    invoke-direct {v2, p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)V

    invoke-virtual {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/SettingsDialog;->pickFlySpeed(Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method static final pressButton$lambda$36$lambda$35(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    .line 582
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->invalidate()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final pressButton$lambda$37(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 583
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getBoxSelect()Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->setBoxSelect(Z)V

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getBoxSelect()Z

    move-result v1

    if-eqz v1, :cond_22

    const-string v1, "Box select: drag to select (long-press works any time)"

    goto :goto_24

    :cond_22
    const-string v1, "Box select off"

    :goto_24
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->toast(Ljava/lang/String;)Z

    return-void
.end method

.method static final pressButton$lambda$38(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 584
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMultiSelect()Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->setMultiSelect(Z)V

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMultiSelect()Z

    move-result v1

    if-eqz v1, :cond_22

    const-string v1, "Multi-select: taps add or remove"

    goto :goto_24

    :cond_22
    const-string v1, "Multi-select off"

    :goto_24
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->toast(Ljava/lang/String;)Z

    return-void
.end method

.method static final pressButton$lambda$39(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 585
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelectInsideModels()Z

    move-result v1

    xor-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->setSelectInsideModels(Z)V

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelectInsideModels()Z

    move-result v1

    if-eqz v1, :cond_22

    const-string v1, "Select inside models: taps pick single parts in groups"

    goto :goto_24

    :cond_22
    const-string v1, "Taps select whole models again"

    :goto_24
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->toast(Ljava/lang/String;)Z

    return-void
.end method

.method private final resetPinch()V
    .registers 2

    .line 598
    const/4 v0, 0x0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pinchDist:F

    return-void
.end method

.method private final runtimeFor(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;
    .registers 6
    .param p1, "a"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 805
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->root()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return-object v1

    .line 806
    .local v0, "root":Lcom/exampletest/mobilestudiotest/model/DataModel;
    :cond_8
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v2

    .line 807
    .local v2, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    nop

    .line 808
    if-eqz v2, :cond_20

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v3

    if-ne v0, v3, :cond_20

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getRt()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    move-result-object v1

    goto :goto_38

    .line 809
    :cond_20
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getEditModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v3

    if-ne v0, v3, :cond_37

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getEditRuntime()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    move-result-object v1

    goto :goto_38

    .line 810
    :cond_37
    nop

    .line 807
    :goto_38
    return-object v1
.end method

.method private final selectTarget(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 13
    .param p1, "part"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 634
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelectInsideModels()Z

    move-result v0

    if-eqz v0, :cond_d

    return-object p1

    .line 635
    :cond_d
    const/4 v0, 0x0

    .line 636
    .local v0, "top":Ljava/lang/Object;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    .line 637
    .local v1, "a":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getWorkspace()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    .line 638
    .local v2, "ws":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_20
    if-eqz v1, :cond_3f

    if-eq v1, v2, :cond_3f

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "Model"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_39

    const-string v3, "PartOperation"

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_39

    goto :goto_3a

    :cond_39
    move-object v0, v1

    :goto_3a
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    goto :goto_20

    .line 639
    :cond_3f
    if-eqz v0, :cond_7e

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$none\\1":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 971
    .local v4, "$i$f$none\\1\\639":I
    instance-of v5, v3, Ljava/util/Collection;

    const/4 v6, 0x1

    if-eqz v5, :cond_5d

    move-object v5, v3

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_5d

    goto :goto_7a

    .line 972
    :cond_5d
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_61
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_79

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\1":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 639
    .local v9, "$i$a$-none-ViewportView$TouchLayer$selectTarget$1\\2\\972\\0":I
    const/4 v10, 0x0

    if-ne v8, v0, :cond_74

    move v8, v6

    goto :goto_75

    :cond_74
    move v8, v10

    .line 972
    .end local v8    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-none-ViewportView$TouchLayer$selectTarget$1\\2\\972\\0":I
    :goto_75
    if-eqz v8, :cond_61

    move v6, v10

    goto :goto_7a

    .line 973
    .end local v7    # "element\\1":Ljava/lang/Object;
    :cond_79
    nop

    .line 639
    .end local v3    # "$this$none\\1":Ljava/lang/Iterable;
    .end local v4    # "$i$f$none\\1\\639":I
    :goto_7a
    if-eqz v6, :cond_7e

    move-object v3, v0

    goto :goto_7f

    :cond_7e
    move-object v3, p1

    :goto_7f
    return-object v3
.end method

.method private final setJoy(FF)V
    .registers 9
    .param p1, "x"    # F
    .param p2, "y"    # F

    .line 563
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCx:F

    sub-float v0, p1, v0

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v1

    div-float/2addr v0, v1

    .local v0, "dx":F
    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCy:F

    sub-float v1, p2, v1

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v2

    div-float/2addr v1, v2

    .line 564
    .local v1, "dy":F
    float-to-double v2, v0

    float-to-double v4, v1

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v2

    double-to-float v2, v2

    .line 565
    .local v2, "m":F
    const/high16 v3, 0x3f800000    # 1.0f

    cmpl-float v4, v2, v3

    if-lez v4, :cond_3e

    .line 567
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getFixedStick()Z

    move-result v4

    if-nez v4, :cond_3c

    .line 568
    sub-float v3, v2, v3

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getJoyR()F

    move-result v4

    mul-float/2addr v3, v4

    .line 569
    .local v3, "over":F
    iget v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCx:F

    div-float v5, v0, v2

    mul-float/2addr v5, v3

    add-float/2addr v4, v5

    iput v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCx:F

    iget v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCy:F

    div-float v5, v1, v2

    mul-float/2addr v5, v3

    add-float/2addr v4, v5

    iput v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCy:F

    .line 571
    .end local v3    # "over":F
    :cond_3c
    div-float/2addr v0, v2

    div-float/2addr v1, v2

    .line 573
    :cond_3e
    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyX:F

    iput v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyY:F

    .line 574
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v3

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->setMoveX(F)V

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v3

    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->setMoveY(F)V

    .line 575
    return-void
.end method

.method private final snap(FF)F
    .registers 4
    .param p1, "v"    # F
    .param p2, "step"    # F

    .line 721
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSnapEnabled()Z

    move-result v0

    if-eqz v0, :cond_1a

    const/4 v0, 0x0

    cmpl-float v0, p2, v0

    if-lez v0, :cond_1a

    div-float v0, p1, p2

    invoke-static {v0}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v0

    int-to-float v0, v0

    mul-float/2addr v0, p2

    goto :goto_1b

    :cond_1a
    move v0, p1

    :goto_1b
    return v0
.end method

.method private final tap(FF)V
    .registers 15
    .param p1, "x"    # F
    .param p2, "y"    # F

    .line 643
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->tap(FF)Z

    move-result v0

    if-eqz v0, :cond_d

    return-void

    .line 644
    :cond_d
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v1

    .line 645
    .local v1, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    if-eqz v1, :cond_2f

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    monitor-enter v2

    .line 927
    const/4 v0, 0x0

    .line 645
    .local v0, "$i$a$-synchronized-ViewportView$TouchLayer$tap$1\\1\\645\\0":I
    :try_start_25
    invoke-virtual {v1, p1, p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->tap(FF)V

    .end local v0    # "$i$a$-synchronized-ViewportView$TouchLayer$tap$1\\1\\645\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2a
    .catchall {:try_start_25 .. :try_end_2a} :catchall_2c

    monitor-exit v2

    return-void

    :catchall_2c
    move-exception v0

    monitor-exit v2

    throw v0

    .line 646
    :cond_2f
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getActivePlugin()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    if-eqz v0, :cond_56

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPluginMice()Ljava/util/IdentityHashMap;

    move-result-object v0

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getActivePlugin()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/IdentityHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_56

    return-void

    .line 647
    :cond_56
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->pick(FF)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    if-eqz v0, :cond_7b

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    .line 927
    .local v0, "g\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v3, 0x0

    .line 647
    .local v3, "$i$a$-let-ViewportView$TouchLayer$tap$2\\2\\647\\0":I
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getAdditive()Z

    move-result v4

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    if-eqz v4, :cond_73

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->toggleSelect(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    goto :goto_7a

    :cond_73
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    :goto_7a
    return-void

    .line 648
    .end local v0    # "g\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v3    # "$i$a$-let-ViewportView$TouchLayer$tap$2\\2\\647\\0":I
    :cond_7b
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v2

    const/4 v3, 0x0

    .line 649
    .local v3, "$i$a$-synchronized-ViewportView$TouchLayer$tap$target$1\\3\\648\\0":I
    :try_start_89
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v4

    invoke-virtual {v4, p1, p2}, Lcom/exampletest/mobilestudiotest/render/ViewState;->screenRay(FF)Lkotlin/Pair;

    move-result-object v4

    invoke-virtual {v4}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-object v8, v5

    .local v8, "o\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v4}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v4

    move-object v9, v4

    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 650
    .local v9, "dir\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v6, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->renderParts()Ljava/util/List;

    move-result-object v7

    new-instance v11, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda8;

    invoke-direct {v11}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda8;-><init>()V

    const v10, 0x459c4000    # 5000.0f

    invoke-virtual/range {v6 .. v11}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->raycast(Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FLkotlin/jvm/functions/Function1;)Lcom/exampletest/mobilestudiotest/engine/RayHit;

    move-result-object v0

    .line 651
    .local v0, "hit\\3":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    if-eqz v0, :cond_c7

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    if-eqz v4, :cond_c7

    .line 927
    .local v4, "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v5, 0x0

    .line 651
    .local v5, "$i$a$-let-ViewportView$TouchLayer$tap$target$1$1\\4\\651\\3":I
    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->selectTarget(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6
    :try_end_c6
    .catchall {:try_start_89 .. :try_end_c6} :catchall_fe

    .end local v4    # "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v5    # "$i$a$-let-ViewportView$TouchLayer$tap$target$1$1\\4\\651\\3":I
    goto :goto_c8

    :cond_c7
    const/4 v6, 0x0

    .line 648
    .end local v0    # "hit\\3":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$tap$target$1\\3\\648\\0":I
    .end local v8    # "o\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "dir\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :goto_c8
    monitor-exit v2

    .line 653
    .local v6, "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    nop

    .line 654
    if-nez v6, :cond_e0

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getAdditive()Z

    move-result v0

    if-nez v0, :cond_fd

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    goto :goto_fd

    .line 655
    :cond_e0
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getAdditive()Z

    move-result v0

    if-eqz v0, :cond_f0

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/core/Studio;->toggleSelect(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    goto :goto_fd

    .line 656
    :cond_f0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->select(Ljava/util/List;)V

    .line 658
    :cond_fd
    :goto_fd
    return-void

    .line 648
    .end local v6    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    :catchall_fe
    move-exception v0

    monitor-exit v2

    throw v0
.end method

.method static final tap$lambda$56$lambda$54(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 4
    .param p0, "it"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 650
    const-string v0, "Locked"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    xor-int/2addr v0, v1

    return v0
.end method

.method private final tryStartAdorn(IFF)Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;
    .registers 23
    .param p1, "id"    # I
    .param p2, "x"    # F
    .param p3, "y"    # F

    .line 814
    move-object/from16 v1, p0

    move/from16 v3, p2

    move/from16 v4, p3

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v10

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v10

    const/4 v11, 0x0

    .line 815
    .local v11, "$i$a$-synchronized-ViewportView$TouchLayer$tryStartAdorn$1\\1\\814\\0":I
    const/4 v2, 0x0

    .line 816
    .local v2, "best\\1":Lkotlin/Pair;
    :try_start_15
    iget v5, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v6, 0x42080000    # 34.0f

    mul-float/2addr v5, v6

    .line 817
    .local v5, "bd\\1":F
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/core/Studio;->renderAdornments()Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    move-object v12, v2

    move v13, v5

    .end local v2    # "best\\1":Lkotlin/Pair;
    .end local v5    # "bd\\1":F
    .local v12, "best\\1":Lkotlin/Pair;
    .local v13, "bd\\1":F
    :goto_28
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v7, 0x0

    if-eqz v2, :cond_b6

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 818
    .local v2, "a\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v8, Lcom/exampletest/mobilestudiotest/render/AdornHandles;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/AdornHandles;

    invoke-virtual {v8, v2}, Lcom/exampletest/mobilestudiotest/render/AdornHandles;->isHandles(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v8

    if-eqz v8, :cond_b0

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v8

    if-nez v8, :cond_48

    move-object/from16 v18, v6

    goto/16 :goto_b2

    .line 819
    :cond_48
    sget-object v8, Lcom/exampletest/mobilestudiotest/render/AdornHandles;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/AdornHandles;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v9

    invoke-virtual {v8, v2, v9}, Lcom/exampletest/mobilestudiotest/render/AdornHandles;->tips(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/render/ViewState;)Ljava/util/List;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_5a
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_ac

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    .line 820
    .local v9, "t\\1":Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v14

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getTip()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v15

    invoke-virtual {v14, v15}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v14

    if-nez v14, :cond_7f

    move-object/from16 v18, v6

    move/from16 v16, v7

    move-object/from16 v17, v8

    goto :goto_a4

    .line 821
    .local v14, "s\\1":[F
    :cond_7f
    aget v15, v14, v7

    sub-float/2addr v15, v3

    move/from16 v16, v7

    move-object/from16 v17, v8

    float-to-double v7, v15

    aget v15, v14, v5

    sub-float/2addr v15, v4

    move-object/from16 v18, v6

    float-to-double v5, v15

    invoke-static {v7, v8, v5, v6}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v5

    double-to-float v5, v5

    .line 822
    .local v5, "dd\\1":F
    cmpg-float v6, v5, v13

    if-gez v6, :cond_a4

    move v13, v5

    invoke-static {v2, v9}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6
    :try_end_9b
    .catchall {:try_start_15 .. :try_end_9b} :catchall_151

    move-object v12, v6

    move/from16 v7, v16

    move-object/from16 v8, v17

    move-object/from16 v6, v18

    const/4 v5, 0x1

    .end local v5    # "dd\\1":F
    .end local v9    # "t\\1":Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;
    .end local v14    # "s\\1":[F
    goto :goto_5a

    .line 819
    :cond_a4
    :goto_a4
    move/from16 v7, v16

    move-object/from16 v8, v17

    move-object/from16 v6, v18

    const/4 v5, 0x1

    goto :goto_5a

    :cond_ac
    move-object/from16 v18, v6

    goto/16 :goto_28

    .line 818
    :cond_b0
    move-object/from16 v18, v6

    .line 817
    .end local v2    # "a\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_b2
    move-object/from16 v6, v18

    goto/16 :goto_28

    .line 825
    :cond_b6
    move/from16 v16, v7

    const/4 v0, 0x0

    if-nez v12, :cond_bd

    .end local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartAdorn$1\\1\\814\\0":I
    .end local v12    # "best\\1":Lkotlin/Pair;
    .end local v13    # "bd\\1":F
    monitor-exit v10

    return-object v0

    .restart local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartAdorn$1\\1\\814\\0":I
    .restart local v12    # "best\\1":Lkotlin/Pair;
    .restart local v13    # "bd\\1":F
    :cond_bd
    :try_start_bd
    invoke-virtual {v12}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v2

    move-object v5, v2

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v5, "a\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v12}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    .line 826
    .local v6, "t\\1":Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;
    invoke-direct {v1, v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->runtimeFor(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    move-result-object v8
    :try_end_cf
    .catchall {:try_start_bd .. :try_end_cf} :catchall_151

    if-nez v8, :cond_d3

    .end local v5    # "a\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v6    # "t\\1":Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;
    .end local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartAdorn$1\\1\\814\\0":I
    .end local v12    # "best\\1":Lkotlin/Pair;
    .end local v13    # "bd\\1":F
    monitor-exit v10

    return-object v0

    .line 827
    .restart local v5    # "a\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v6    # "t\\1":Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;
    .local v8, "rt\\1":Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;
    .restart local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartAdorn$1\\1\\814\\0":I
    .restart local v12    # "best\\1":Lkotlin/Pair;
    .restart local v13    # "bd\\1":F
    :cond_d3
    :try_start_d3
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    move-object v14, v2

    .line 828
    .local v14, "lt\\1":Lcom/exampletest/mobilestudiotest/lua/LuaTypes;
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    const-string v7, "Handles"

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_103

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    const-string v7, "NormalId"

    sget-object v9, Lcom/exampletest/mobilestudiotest/render/AdornHandles;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/AdornHandles;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/AdornHandles;->getNORMAL_NAMES()Ljava/util/List;

    move-result-object v9

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getId()I

    move-result v15

    invoke-interface {v9, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getId()I

    move-result v15

    invoke-direct {v2, v7, v9, v15}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v14, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    move-object v9, v2

    goto :goto_123

    .line 829
    :cond_103
    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    const-string v7, "Axis"

    sget-object v9, Lcom/exampletest/mobilestudiotest/render/AdornHandles;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/AdornHandles;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/AdornHandles;->getAXIS_NAMES()Ljava/util/List;

    move-result-object v9

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getId()I

    move-result v15

    invoke-interface {v9, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getId()I

    move-result v15

    invoke-direct {v2, v7, v9, v15}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v14, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    move-object v9, v2

    .line 828
    :goto_123
    nop

    .line 830
    .local v9, "arg\\1":Lorg/luaj/vm2/LuaValue;
    const-string v2, "MouseButton1Down"

    const/4 v7, 0x1

    new-array v7, v7, [Lorg/luaj/vm2/LuaValue;

    aput-object v9, v7, v16

    invoke-virtual {v8, v5, v2, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .line 831
    move-object v2, v0

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v7

    const-string v15, "Handles"

    invoke-static {v7, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_149

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getBase()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    invoke-direct {v1, v2, v7, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->axisParam(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FF)Ljava/lang/Float;

    move-result-object v2

    :cond_149
    move-object v7, v2

    move/from16 v2, p1

    invoke-direct/range {v0 .. v9}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;Ljava/lang/Float;Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lorg/luaj/vm2/LuaValue;)V
    :try_end_14f
    .catchall {:try_start_d3 .. :try_end_14f} :catchall_151

    .line 814
    .end local v5    # "a\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v6    # "t\\1":Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;
    .end local v8    # "rt\\1":Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;
    .end local v9    # "arg\\1":Lorg/luaj/vm2/LuaValue;
    .end local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartAdorn$1\\1\\814\\0":I
    .end local v12    # "best\\1":Lkotlin/Pair;
    .end local v13    # "bd\\1":F
    .end local v14    # "lt\\1":Lcom/exampletest/mobilestudiotest/lua/LuaTypes;
    monitor-exit v10

    .line 832
    return-object v0

    .line 814
    :catchall_151
    move-exception v0

    monitor-exit v10

    throw v0
.end method

.method private final tryStartDrag(IFF)Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;
    .registers 35
    .param p1, "id"    # I
    .param p2, "x"    # F
    .param p3, "y"    # F

    .line 699
    move-object/from16 v1, p0

    move/from16 v3, p2

    move/from16 v4, p3

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v15

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v15

    const/16 v16, 0x0

    .line 700
    .local v16, "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    :try_start_15
    sget-object v2, Lcom/exampletest/mobilestudiotest/render/Handles;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/Handles;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/render/Handles;->compute(Lcom/exampletest/mobilestudiotest/core/Studio;)Lcom/exampletest/mobilestudiotest/render/HandleSet;

    move-result-object v2
    :try_end_1f
    .catchall {:try_start_15 .. :try_end_1f} :catchall_1a2

    const/4 v5, 0x0

    if-nez v2, :cond_24

    .end local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    monitor-exit v15

    return-object v5

    .restart local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    :cond_24
    move-object/from16 v17, v2

    .line 701
    .local v17, "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    const/4 v2, 0x0

    .local v2, "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    :try_start_27
    iget v6, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    const/high16 v7, 0x42200000    # 40.0f

    mul-float/2addr v6, v7

    .line 702
    .local v6, "bd\\1":F
    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/render/HandleSet;->getHandles()Ljava/util/List;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    move-object/from16 v18, v2

    move/from16 v19, v6

    .end local v2    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v6    # "bd\\1":F
    .local v18, "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .local v19, "bd\\1":F
    :cond_38
    :goto_38
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x0

    const/4 v8, 0x1

    if-eqz v2, :cond_6f

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/render/Handle;

    .line 703
    .local v2, "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v9

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Handle;->getTip()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v9

    if-nez v9, :cond_59

    goto :goto_38

    .line 704
    .local v9, "s\\1":[F
    :cond_59
    aget v6, v9, v6

    sub-float/2addr v6, v3

    float-to-double v10, v6

    aget v6, v9, v8

    sub-float/2addr v6, v4

    float-to-double v12, v6

    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v10
    :try_end_65
    .catchall {:try_start_27 .. :try_end_65} :catchall_1a2

    double-to-float v6, v10

    .line 705
    .local v6, "dd\\1":F
    cmpg-float v8, v6, v19

    if-gez v8, :cond_38

    move/from16 v19, v6

    move-object/from16 v18, v2

    .end local v2    # "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v6    # "dd\\1":F
    .end local v9    # "s\\1":[F
    goto :goto_38

    .line 707
    :cond_6f
    if-nez v18, :cond_73

    .end local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .end local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .end local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v19    # "bd\\1":F
    monitor-exit v15

    return-object v5

    .restart local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .restart local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .restart local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .restart local v19    # "bd\\1":F
    :cond_73
    move-object v2, v5

    move-object/from16 v5, v18

    .line 708
    .local v5, "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    :try_start_76
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v7

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/core/Studio;->selectedParts()Ljava/util/List;

    move-result-object v7

    .line 709
    .local v7, "parts\\1":Ljava/util/List;
    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/render/HandleSet;->getTool()Lcom/exampletest/mobilestudiotest/core/Tool;

    move-result-object v9

    sget-object v10, Lcom/exampletest/mobilestudiotest/core/Tool;->SCALE:Lcom/exampletest/mobilestudiotest/core/Tool;

    if-ne v9, v10, :cond_8e

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v9
    :try_end_8a
    .catchall {:try_start_76 .. :try_end_8a} :catchall_1a2

    if-eq v9, v8, :cond_8e

    .end local v5    # "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v7    # "parts\\1":Ljava/util/List;
    .end local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .end local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .end local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v19    # "bd\\1":F
    monitor-exit v15

    return-object v2

    .line 710
    .restart local v5    # "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .restart local v7    # "parts\\1":Ljava/util/List;
    .restart local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .restart local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .restart local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .restart local v19    # "bd\\1":F
    :cond_8e
    :try_start_8e
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v9

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/render/HandleSet;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v9
    :try_end_9e
    .catchall {:try_start_8e .. :try_end_9e} :catchall_1a2

    if-nez v9, :cond_a2

    .end local v5    # "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v7    # "parts\\1":Ljava/util/List;
    .end local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .end local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .end local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v19    # "bd\\1":F
    monitor-exit v15

    return-object v2

    .restart local v5    # "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .restart local v7    # "parts\\1":Ljava/util/List;
    .restart local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .restart local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .restart local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .restart local v19    # "bd\\1":F
    :cond_a2
    move-object/from16 v20, v9

    .line 711
    .local v20, "c0\\1":[F
    :try_start_a4
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v0

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/render/HandleSet;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/Handle;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v0, v9}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v0
    :try_end_bc
    .catchall {:try_start_a4 .. :try_end_bc} :catchall_1a2

    if-nez v0, :cond_c0

    .end local v5    # "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v7    # "parts\\1":Ljava/util/List;
    .end local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .end local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .end local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v19    # "bd\\1":F
    .end local v20    # "c0\\1":[F
    monitor-exit v15

    return-object v2

    .restart local v5    # "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .restart local v7    # "parts\\1":Ljava/util/List;
    .restart local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .restart local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .restart local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .restart local v19    # "bd\\1":F
    .restart local v20    # "c0\\1":[F
    :cond_c0
    move-object/from16 v21, v0

    .line 712
    .local v21, "c1\\1":[F
    :try_start_c2
    aget v0, v21, v6

    aget v9, v20, v6

    sub-float/2addr v0, v9

    .local v0, "sx\\1":F
    aget v9, v21, v8

    aget v10, v20, v8

    sub-float/2addr v9, v10

    .line 713
    .local v9, "sy\\1":F
    float-to-double v10, v0

    float-to-double v12, v9

    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v10

    double-to-float v10, v10

    .line 714
    .local v10, "len\\1":F
    const/high16 v11, 0x3f000000    # 0.5f

    cmpg-float v11, v10, v11

    if-gez v11, :cond_de

    const/4 v0, 0x0

    const/high16 v9, -0x40800000    # -1.0f

    const/high16 v10, 0x3f800000    # 1.0f

    :cond_de
    move/from16 v22, v0

    move/from16 v23, v9

    .line 715
    .end local v0    # "sx\\1":F
    .end local v9    # "sy\\1":F
    .local v22, "sx\\1":F
    .local v23, "sy\\1":F
    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/render/HandleSet;->getTool()Lcom/exampletest/mobilestudiotest/core/Tool;

    move-result-object v0

    sget-object v9, Lcom/exampletest/mobilestudiotest/core/Tool;->ROTATE:Lcom/exampletest/mobilestudiotest/core/Tool;

    if-eq v0, v9, :cond_f8

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/render/HandleSet;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/Handle;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-direct {v1, v0, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->axisParam(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FF)Ljava/lang/Float;

    move-result-object v0

    move-object v14, v0

    goto :goto_f9

    :cond_f8
    move-object v14, v2

    .line 716
    .local v14, "t0\\1":Ljava/lang/Float;
    :goto_f9
    move v0, v6

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/render/HandleSet;->getTool()Lcom/exampletest/mobilestudiotest/core/Tool;

    move-result-object v6

    move-object v2, v7

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\2":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 980
    .local v9, "$i$f$map\\2\\716":I
    new-instance v11, Ljava/util/ArrayList;

    const/16 v12, 0xa

    invoke-static {v2, v12}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v13

    invoke-direct {v11, v13}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v11, Ljava/util/Collection;

    .local v11, "destination\\3":Ljava/util/Collection;
    move-object v13, v2

    .local v13, "$this$mapTo\\3":Ljava/lang/Iterable;
    const/16 v24, 0x0

    .line 981
    .local v24, "$i$f$mapTo\\3\\980":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v25

    :goto_116
    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->hasNext()Z

    move-result v26

    if-eqz v26, :cond_13c

    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v26

    .line 982
    .local v26, "item\\3":Ljava/lang/Object;
    move-object/from16 v27, v26

    check-cast v27, Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object/from16 v28, v27

    .local v28, "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v27, 0x0

    .line 716
    .local v27, "$i$a$-map-ViewportView$TouchLayer$tryStartDrag$1$1\\4\\982\\1":I
    move/from16 v29, v0

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    move/from16 v30, v8

    move-object/from16 v8, v28

    .end local v28    # "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v8, "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v0, v8}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    .line 982
    .end local v8    # "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v27    # "$i$a$-map-ViewportView$TouchLayer$tryStartDrag$1$1\\4\\982\\1":I
    invoke-interface {v11, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move/from16 v0, v29

    move/from16 v8, v30

    goto :goto_116

    .line 983
    .end local v26    # "item\\3":Ljava/lang/Object;
    :cond_13c
    move/from16 v29, v0

    move/from16 v30, v8

    .end local v11    # "destination\\3":Ljava/util/Collection;
    .end local v13    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .end local v24    # "$i$f$mapTo\\3\\980":I
    move-object v8, v11

    check-cast v8, Ljava/util/List;

    .line 980
    nop

    .line 716
    .end local v2    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v9    # "$i$f$map\\2\\716":I
    move-object v0, v7

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$map\\5":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 980
    .local v2, "$i$f$map\\5\\716":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-static {v0, v12}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v11

    invoke-direct {v9, v11}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination\\6":Ljava/util/Collection;
    move-object v11, v0

    .local v11, "$this$mapTo\\6":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 981
    .local v12, "$i$f$mapTo\\6\\980":I
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_159
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v24

    if-eqz v24, :cond_17d

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v24

    .line 982
    .local v24, "item\\6":Ljava/lang/Object;
    move-object/from16 v25, v24

    check-cast v25, Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object/from16 v26, v25

    .local v26, "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v25, 0x0

    .line 716
    .local v25, "$i$a$-map-ViewportView$TouchLayer$tryStartDrag$1$2\\7\\982\\1":I
    move-object/from16 v27, v0

    .end local v0    # "$this$map\\5":Ljava/lang/Iterable;
    .local v27, "$this$map\\5":Ljava/lang/Iterable;
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    move-object/from16 v1, v26

    .end local v26    # "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v1, "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .line 982
    .end local v1    # "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v25    # "$i$a$-map-ViewportView$TouchLayer$tryStartDrag$1$2\\7\\982\\1":I
    invoke-interface {v9, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, p0

    move-object/from16 v0, v27

    goto :goto_159

    .line 983
    .end local v24    # "item\\6":Ljava/lang/Object;
    .end local v27    # "$this$map\\5":Ljava/lang/Iterable;
    .restart local v0    # "$this$map\\5":Ljava/lang/Iterable;
    :cond_17d
    move-object/from16 v27, v0

    .end local v0    # "$this$map\\5":Ljava/lang/Iterable;
    .end local v9    # "destination\\6":Ljava/util/Collection;
    .end local v11    # "$this$mapTo\\6":Ljava/lang/Iterable;
    .end local v12    # "$i$f$mapTo\\6\\980":I
    .restart local v27    # "$this$map\\5":Ljava/lang/Iterable;
    check-cast v9, Ljava/util/List;

    .line 980
    nop

    .line 717
    .end local v2    # "$i$f$map\\5\\716":I
    .end local v27    # "$this$map\\5":Ljava/lang/Iterable;
    div-float v0, v22, v10

    div-float v1, v23, v10

    const/4 v2, 0x2

    new-array v11, v2, [F

    aput v0, v11, v29

    aput v1, v11, v30

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/render/HandleSet;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v12

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/Handle;->getIndex()I

    move-result v0

    rem-int/lit8 v13, v0, 0x3

    .line 716
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;

    move-object/from16 v1, p0

    move/from16 v2, p1

    invoke-direct/range {v0 .. v14}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/render/Handle;Lcom/exampletest/mobilestudiotest/core/Tool;Ljava/util/List;Ljava/util/List;Ljava/util/List;F[FLcom/exampletest/mobilestudiotest/model/Vector3;ILjava/lang/Float;)V
    :try_end_1a0
    .catchall {:try_start_c2 .. :try_end_1a0} :catchall_1a2

    .end local v5    # "h\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v7    # "parts\\1":Ljava/util/List;
    .end local v10    # "len\\1":F
    .end local v14    # "t0\\1":Ljava/lang/Float;
    .end local v16    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartDrag$1\\1\\699\\0":I
    .end local v17    # "hs\\1":Lcom/exampletest/mobilestudiotest/render/HandleSet;
    .end local v18    # "best\\1":Lcom/exampletest/mobilestudiotest/render/Handle;
    .end local v19    # "bd\\1":F
    .end local v20    # "c0\\1":[F
    .end local v21    # "c1\\1":[F
    .end local v22    # "sx\\1":F
    .end local v23    # "sy\\1":F
    monitor-exit v15

    return-object v0

    :catchall_1a2
    move-exception v0

    monitor-exit v15

    throw v0
.end method

.method private final tryStartPartDrag(IFF)Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;
    .registers 27
    .param p1, "id"    # I
    .param p2, "x"    # F
    .param p3, "y"    # F

    .line 862
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getTool()Lcom/exampletest/mobilestudiotest/core/Tool;

    move-result-object v0

    sget-object v2, Lcom/exampletest/mobilestudiotest/core/Tool;->ROTATE:Lcom/exampletest/mobilestudiotest/core/Tool;

    const/4 v3, 0x0

    if-ne v0, v2, :cond_20

    sget-object v0, Lcom/exampletest/mobilestudiotest/render/Handles;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/Handles;

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/render/Handles;->compute(Lcom/exampletest/mobilestudiotest/core/Studio;)Lcom/exampletest/mobilestudiotest/render/HandleSet;

    move-result-object v0

    if-nez v0, :cond_20

    return-object v3

    .line 863
    :cond_20
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v10

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v10

    const/4 v11, 0x0

    .line 864
    .local v11, "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    :try_start_2e
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v2

    move/from16 v4, p2

    move/from16 v5, p3

    invoke-virtual {v2, v4, v5}, Lcom/exampletest/mobilestudiotest/render/ViewState;->screenRay(FF)Lkotlin/Pair;

    move-result-object v2

    invoke-virtual {v2}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-object v14, v6

    .local v14, "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v2

    move-object v15, v2

    check-cast v15, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 865
    .local v15, "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v12, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->renderParts()Ljava/util/List;

    move-result-object v13

    new-instance v17, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda0;

    invoke-direct/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda0;-><init>()V

    const v16, 0x459c4000    # 5000.0f

    invoke-virtual/range {v12 .. v17}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->raycast(Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FLkotlin/jvm/functions/Function1;)Lcom/exampletest/mobilestudiotest/engine/RayHit;

    move-result-object v2
    :try_end_62
    .catchall {:try_start_2e .. :try_end_62} :catchall_1e4

    if-nez v2, :cond_66

    .end local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .end local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    monitor-exit v10

    return-object v3

    .restart local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .restart local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_66
    move-object v12, v2

    .line 866
    .local v12, "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    :try_start_67
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSelection()Ljava/util/ArrayList;

    move-result-object v2

    move-object v13, v2

    .line 867
    .local v13, "sel\\1":Ljava/util/ArrayList;
    move-object v2, v13

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$any\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1001
    .local v6, "$i$f$any\\2\\867":I
    instance-of v7, v2, Ljava/util/Collection;

    if-eqz v7, :cond_87

    move-object v7, v2

    check-cast v7, Ljava/util/Collection;

    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_87

    move-object/from16 v19, v3

    const/4 v2, 0x0

    const/16 v20, 0x1

    goto :goto_ba

    .line 1002
    :cond_87
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_8b
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_b5

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    .local v16, "element\\2":Ljava/lang/Object;
    move-object/from16 v17, v16

    check-cast v17, Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object/from16 v18, v17

    .local v18, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v17, 0x0

    .line 867
    .local v17, "$i$a$-any-ViewportView$TouchLayer$tryStartPartDrag$1$selected$1\\3\\1002\\1":I
    move-object/from16 v19, v3

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    move-object/from16 v8, v18

    const/16 v20, 0x1

    .end local v18    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v8, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    if-ne v8, v3, :cond_ac

    move/from16 v3, v20

    goto :goto_ad

    :cond_ac
    const/4 v3, 0x0

    .line 1002
    .end local v8    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v17    # "$i$a$-any-ViewportView$TouchLayer$tryStartPartDrag$1$selected$1\\3\\1002\\1":I
    :goto_ad
    if-eqz v3, :cond_b2

    move/from16 v2, v20

    goto :goto_ba

    :cond_b2
    move-object/from16 v3, v19

    goto :goto_8b

    .line 1003
    .end local v16    # "element\\2":Ljava/lang/Object;
    :cond_b5
    move-object/from16 v19, v3

    const/16 v20, 0x1

    const/4 v2, 0x0

    .line 867
    .end local v2    # "$this$any\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$any\\2\\867":I
    :goto_ba
    if-nez v2, :cond_100

    move-object v2, v13

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$any\\4":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1001
    .local v3, "$i$f$any\\4\\867":I
    instance-of v6, v2, Ljava/util/Collection;

    if-eqz v6, :cond_cf

    move-object v6, v2

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_cf

    const/4 v9, 0x0

    goto :goto_fc

    .line 1002
    :cond_cf
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_d3
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_fb

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\4":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "s\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v16, 0x0

    .line 867
    .local v16, "$i$a$-any-ViewportView$TouchLayer$tryStartPartDrag$1$selected$2\\5\\1002\\1":I
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v17

    if-nez v17, :cond_f5

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v9

    invoke-virtual {v9, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v9
    :try_end_f0
    .catchall {:try_start_67 .. :try_end_f0} :catchall_1e4

    if-eqz v9, :cond_f5

    move/from16 v8, v20

    goto :goto_f6

    :cond_f5
    const/4 v8, 0x0

    .line 1002
    .end local v8    # "s\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v16    # "$i$a$-any-ViewportView$TouchLayer$tryStartPartDrag$1$selected$2\\5\\1002\\1":I
    :goto_f6
    if-eqz v8, :cond_d3

    move/from16 v9, v20

    goto :goto_fc

    .line 1003
    .end local v7    # "element\\4":Ljava/lang/Object;
    :cond_fb
    const/4 v9, 0x0

    .line 867
    .end local v2    # "$this$any\\4":Ljava/lang/Iterable;
    .end local v3    # "$i$f$any\\4\\867":I
    :goto_fc
    if-nez v9, :cond_100

    const/4 v9, 0x0

    goto :goto_102

    :cond_100
    move/from16 v9, v20

    :goto_102
    move/from16 v16, v9

    .line 868
    .local v16, "selected\\1":Z
    if-nez v16, :cond_108

    .end local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .end local v12    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .end local v13    # "sel\\1":Ljava/util/ArrayList;
    .end local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v16    # "selected\\1":Z
    monitor-exit v10

    return-object v19

    .line 869
    .restart local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .restart local v12    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .restart local v13    # "sel\\1":Ljava/util/ArrayList;
    .restart local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v16    # "selected\\1":Z
    :cond_108
    :try_start_108
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->selectedParts()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\6":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1004
    .local v2, "$i$f$filter\\6\\869":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\7":Ljava/util/Collection;
    move-object v6, v0

    .local v6, "$this$filterTo\\7":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1005
    .local v7, "$i$f$filterTo\\7\\1004":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_120
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_150

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\7":Ljava/lang/Object;
    move-object/from16 v17, v9

    check-cast v17, Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object/from16 v18, v17

    .local v18, "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v17, 0x0

    .line 869
    .local v17, "$i$a$-filter-ViewportView$TouchLayer$tryStartPartDrag$1$parts$1\\8\\1005\\1":I
    move-object/from16 v21, v0

    .end local v0    # "$this$filter\\6":Ljava/lang/Iterable;
    .local v21, "$this$filter\\6":Ljava/lang/Iterable;
    const-string v0, "Locked"

    move-object/from16 v1, v18

    .end local v18    # "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v1, "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v18, v1

    .end local v1    # "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v18    # "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-static/range {v20 .. v20}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    .line 1005
    .end local v17    # "$i$a$-filter-ViewportView$TouchLayer$tryStartPartDrag$1$parts$1\\8\\1005\\1":I
    .end local v18    # "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    if-nez v0, :cond_14b

    invoke-interface {v3, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_14b
    move-object/from16 v1, p0

    move-object/from16 v0, v21

    goto :goto_120

    .line 1006
    .end local v9    # "element\\7":Ljava/lang/Object;
    .end local v21    # "$this$filter\\6":Ljava/lang/Iterable;
    .restart local v0    # "$this$filter\\6":Ljava/lang/Iterable;
    :cond_150
    move-object/from16 v21, v0

    .end local v0    # "$this$filter\\6":Ljava/lang/Iterable;
    .end local v3    # "destination\\7":Ljava/util/Collection;
    .end local v6    # "$this$filterTo\\7":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filterTo\\7\\1004":I
    .restart local v21    # "$this$filter\\6":Ljava/lang/Iterable;
    move-object v0, v3

    check-cast v0, Ljava/util/List;

    .line 1004
    nop

    .line 869
    .end local v2    # "$i$f$filter\\6\\869":I
    .end local v21    # "$this$filter\\6":Ljava/lang/Iterable;
    nop

    .line 870
    .local v0, "parts\\1":Ljava/util/List;
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1
    :try_end_15b
    .catchall {:try_start_108 .. :try_end_15b} :catchall_1e4

    if-eqz v1, :cond_15f

    .end local v0    # "parts\\1":Ljava/util/List;
    .end local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .end local v12    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .end local v13    # "sel\\1":Ljava/util/ArrayList;
    .end local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v16    # "selected\\1":Z
    monitor-exit v10

    return-object v19

    .line 871
    .restart local v0    # "parts\\1":Ljava/util/List;
    .restart local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .restart local v12    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .restart local v13    # "sel\\1":Ljava/util/ArrayList;
    .restart local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v16    # "selected\\1":Z
    :cond_15f
    :try_start_15f
    sget-object v1, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->boundsOf(Ljava/util/List;)Lkotlin/Pair;

    move-result-object v1
    :try_end_165
    .catchall {:try_start_15f .. :try_end_165} :catchall_1e4

    if-nez v1, :cond_169

    .end local v0    # "parts\\1":Ljava/util/List;
    .end local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .end local v12    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .end local v13    # "sel\\1":Ljava/util/ArrayList;
    .end local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v16    # "selected\\1":Z
    monitor-exit v10

    return-object v19

    .restart local v0    # "parts\\1":Ljava/util/List;
    .restart local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .restart local v12    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .restart local v13    # "sel\\1":Ljava/util/ArrayList;
    .restart local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v16    # "selected\\1":Z
    :cond_169
    :try_start_169
    invoke-virtual {v1}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v2, "a\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v1}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 872
    .local v1, "b\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object v3, v0

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$map\\9":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1007
    .local v6, "$i$f$map\\9\\872":I
    new-instance v7, Ljava/util/ArrayList;

    const/16 v8, 0xa

    invoke-static {v3, v8}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\10":Ljava/util/Collection;
    move-object v8, v3

    .local v8, "$this$mapTo\\10":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1008
    .local v9, "$i$f$mapTo\\10\\1007":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_18c
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_1b2

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    .line 1009
    .local v18, "item\\10":Ljava/lang/Object;
    move-object/from16 v19, v18

    check-cast v19, Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object/from16 v20, v19

    .local v20, "it\\11":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v19, 0x0

    .line 872
    .local v19, "$i$a$-map-ViewportView$TouchLayer$tryStartPartDrag$1$1\\11\\1009\\1":I
    move-object/from16 v21, v0

    .end local v0    # "parts\\1":Ljava/util/List;
    .local v21, "parts\\1":Ljava/util/List;
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    move-object/from16 v22, v3

    move-object/from16 v3, v20

    .end local v20    # "it\\11":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v3, "it\\11":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v22, "$this$map\\9":Ljava/lang/Iterable;
    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    .line 1009
    .end local v3    # "it\\11":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v19    # "$i$a$-map-ViewportView$TouchLayer$tryStartPartDrag$1$1\\11\\1009\\1":I
    invoke-interface {v7, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, v21

    move-object/from16 v3, v22

    goto :goto_18c

    .line 1010
    .end local v18    # "item\\10":Ljava/lang/Object;
    .end local v21    # "parts\\1":Ljava/util/List;
    .end local v22    # "$this$map\\9":Ljava/lang/Iterable;
    .restart local v0    # "parts\\1":Ljava/util/List;
    .local v3, "$this$map\\9":Ljava/lang/Iterable;
    :cond_1b2
    move-object/from16 v21, v0

    move-object/from16 v22, v3

    .end local v0    # "parts\\1":Ljava/util/List;
    .end local v3    # "$this$map\\9":Ljava/lang/Iterable;
    .end local v7    # "destination\\10":Ljava/util/Collection;
    .end local v8    # "$this$mapTo\\10":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapTo\\10\\1007":I
    .restart local v21    # "parts\\1":Ljava/util/List;
    .restart local v22    # "$this$map\\9":Ljava/lang/Iterable;
    move-object v0, v7

    check-cast v0, Ljava/util/List;

    .line 1007
    nop

    .line 872
    .end local v6    # "$i$f$map\\9\\872":I
    .end local v22    # "$this$map\\9":Ljava/lang/Iterable;
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/high16 v6, 0x40000000    # 2.0f

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    move-object v6, v0

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    move-object/from16 v18, v1

    move-object/from16 v17, v2

    move v3, v4

    move v4, v5

    move-object/from16 v5, v21

    move-object/from16 v1, p0

    move/from16 v2, p1

    .end local v1    # "b\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v2    # "a\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v21    # "parts\\1":Ljava/util/List;
    .local v5, "parts\\1":Ljava/util/List;
    .local v17, "a\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v18, "b\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-direct/range {v0 .. v9}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLjava/util/List;Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V
    :try_end_1e2
    .catchall {:try_start_169 .. :try_end_1e2} :catchall_1e4

    .end local v5    # "parts\\1":Ljava/util/List;
    .end local v11    # "$i$a$-synchronized-ViewportView$TouchLayer$tryStartPartDrag$1\\1\\863\\0":I
    .end local v12    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .end local v13    # "sel\\1":Ljava/util/ArrayList;
    .end local v14    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v15    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v16    # "selected\\1":Z
    .end local v17    # "a\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v18    # "b\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    monitor-exit v10

    return-object v0

    :catchall_1e4
    move-exception v0

    monitor-exit v10

    throw v0
.end method

.method static final tryStartPartDrag$lambda$80$lambda$75(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 4
    .param p0, "it"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 865
    const-string v0, "Locked"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    xor-int/2addr v0, v1

    return v0
.end method

.method private final up(IFFZ)V
    .registers 14
    .param p1, "id"    # I
    .param p2, "x"    # F
    .param p3, "y"    # F
    .param p4, "cancel"    # Z

    .line 526
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    if-nez v0, :cond_f

    return-void

    .line 527
    .local v0, "p":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    :cond_f
    nop

    .line 528
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;

    if-eqz v1, :cond_2d

    const/4 v1, 0x0

    iput v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyX:F

    iput v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyY:F

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->setMoveX(F)V

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->setMoveY(F)V

    goto/16 :goto_1b6

    .line 529
    :cond_2d
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;

    const/4 v2, 0x0

    if-eqz v1, :cond_3e

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pressButton(Ljava/lang/String;Z)V

    goto/16 :goto_1b6

    .line 530
    :cond_3e
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;

    if-eqz v1, :cond_4a

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->finishDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;)V

    goto/16 :goto_1b6

    .line 531
    :cond_4a
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    if-eqz v1, :cond_66

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getActive()Z

    move-result v1

    if-eqz v1, :cond_5f

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->finishPartDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;)V

    goto/16 :goto_1b6

    :cond_5f
    if-nez p4, :cond_1b6

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tap(FF)V

    goto/16 :goto_1b6

    .line 532
    :cond_66
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    if-eqz v1, :cond_74

    if-nez p4, :cond_1b6

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->finishBox(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;)V

    goto/16 :goto_1b6

    .line 533
    :cond_74
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    const/4 v3, 0x1

    if-eqz v1, :cond_ab

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 927
    const/4 v4, 0x0

    .line 533
    .local v4, "$i$a$-synchronized-ViewportView$TouchLayer$up$1\\1\\533\\0":I
    :try_start_85
    move-object v5, v0

    check-cast v5, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getRt()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    move-result-object v5

    move-object v6, v0

    check-cast v6, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getAdorn()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6

    const-string v7, "MouseButton1Up"

    new-array v3, v3, [Lorg/luaj/vm2/LuaValue;

    move-object v8, v0

    check-cast v8, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->getArg()Lorg/luaj/vm2/LuaValue;

    move-result-object v8

    aput-object v8, v3, v2

    invoke-virtual {v5, v6, v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .end local v4    # "$i$a$-synchronized-ViewportView$TouchLayer$up$1\\1\\533\\0":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_a5
    .catchall {:try_start_85 .. :try_end_a5} :catchall_a8

    monitor-exit v1

    goto/16 :goto_1b6

    :catchall_a8
    move-exception v2

    monitor-exit v1

    throw v2

    .line 534
    :cond_ab
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;

    if-eqz v1, :cond_cc

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    const-string v2, "Button1Up"

    if-eqz p4, :cond_be

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v3

    goto :goto_bf

    :cond_be
    move v3, p2

    :goto_bf
    if-eqz p4, :cond_c6

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v4

    goto :goto_c7

    :cond_c6
    move v4, p3

    :goto_c7
    invoke-virtual {v1, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->pluginMouseEvent(Ljava/lang/String;FF)Z

    goto/16 :goto_1b6

    .line 535
    :cond_cc
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    if-eqz v1, :cond_f1

    .line 536
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->endDrag()V

    .line 537
    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->getActive()Z

    move-result v1

    if-eqz v1, :cond_ea

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->finishGuiDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;)V

    goto/16 :goto_1b6

    .line 538
    :cond_ea
    if-nez p4, :cond_1b6

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tap(FF)V

    goto/16 :goto_1b6

    .line 540
    :cond_f1
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    if-eqz v1, :cond_124

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getCancelled()Z

    move-result v1

    if-nez v1, :cond_1b6

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getGui()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;

    move-result-object v1

    move-object v4, v0

    check-cast v4, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getHit()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v4

    if-nez p4, :cond_11f

    move-object v5, v0

    check-cast v5, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->getHit()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;->getRect()Landroid/graphics/RectF;

    move-result-object v5

    invoke-virtual {v5, p2, p3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_11f

    move v2, v3

    :cond_11f
    invoke-virtual {v1, v4, p2, p3, v2}, Lcom/exampletest/mobilestudiotest/ui/GuiOverlay;->release(Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;FFZ)V

    goto/16 :goto_1b6

    .line 541
    :cond_124
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    if-eqz v1, :cond_1b6

    .line 542
    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getPlayDown()Z

    move-result v1

    if-eqz v1, :cond_163

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v1

    .line 927
    const/4 v5, 0x0

    .line 542
    .local v5, "$i$a$-synchronized-ViewportView$TouchLayer$up$2\\2\\542\\0":I
    :try_start_13f
    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v4

    if-eqz v4, :cond_15e

    if-eqz p4, :cond_150

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getX()F

    move-result v6

    goto :goto_151

    :cond_150
    move v6, p2

    :goto_151
    if-eqz p4, :cond_158

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getY()F

    move-result v7

    goto :goto_159

    :cond_158
    move v7, p3

    :goto_159
    invoke-virtual {v4, v6, v7}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->pointerUp(FF)V

    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_15e
    .catchall {:try_start_13f .. :try_end_15e} :catchall_160

    .end local v5    # "$i$a$-synchronized-ViewportView$TouchLayer$up$2\\2\\542\\0":I
    :cond_15e
    monitor-exit v1

    goto :goto_163

    :catchall_160
    move-exception v2

    monitor-exit v1

    throw v2

    .line 543
    :cond_163
    :goto_163
    if-nez p4, :cond_1b3

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->getMoved()Z

    move-result v1

    if-nez v1, :cond_1b3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->getT0()J

    move-result-wide v6

    sub-long/2addr v4, v6

    const-wide/16 v6, 0x190

    cmp-long v1, v4, v6

    if-gez v1, :cond_1b3

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v1

    const-string v4, "<get-values>(...)"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$none\\3":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 954
    .local v4, "$i$f$none\\3\\543":I
    move-object v5, v1

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_196

    move v2, v3

    goto :goto_1ae

    .line 955
    :cond_196
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_19a
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1ad

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\3":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    .local v7, "it\\4":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    const/4 v8, 0x0

    .line 543
    .local v8, "$i$a$-none-ViewportView$TouchLayer$up$3\\4\\955\\0":I
    instance-of v7, v7, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    .line 955
    .end local v7    # "it\\4":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    .end local v8    # "$i$a$-none-ViewportView$TouchLayer$up$3\\4\\955\\0":I
    if-eqz v7, :cond_19a

    goto :goto_1ae

    .line 956
    .end local v6    # "element\\3":Ljava/lang/Object;
    :cond_1ad
    move v2, v3

    .line 543
    .end local v1    # "$this$none\\3":Ljava/lang/Iterable;
    .end local v4    # "$i$f$none\\3\\543":I
    :goto_1ae
    if-eqz v2, :cond_1b3

    invoke-direct {p0, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tap(FF)V

    .line 544
    :cond_1b3
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->resetPinch()V

    .line 548
    :cond_1b6
    :goto_1b6
    return-void
.end method

.method private final updateDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;)V
    .registers 33
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;

    .line 742
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v2

    const/4 v3, 0x0

    .line 744
    .local v3, "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    :try_start_10
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getT0Axis()Ljava/lang/Float;

    move-result-object v4

    if-eqz v4, :cond_2f

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getHandle()Lcom/exampletest/mobilestudiotest/render/Handle;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/render/Handle;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getX()F

    move-result v6

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getY()F

    move-result v7

    invoke-direct {v1, v4, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->axisParam(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FF)Ljava/lang/Float;

    move-result-object v4

    goto :goto_30

    :cond_2f
    const/4 v4, 0x0

    .line 745
    .local v4, "t\\1":Ljava/lang/Float;
    :goto_30
    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v4, :cond_50

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getT0Axis()Ljava/lang/Float;

    move-result-object v7

    if-eqz v7, :cond_50

    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    move-result v7

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getT0Axis()Ljava/lang/Float;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Float;->floatValue()F

    move-result v8

    sub-float/2addr v7, v8

    const/high16 v8, -0x3b060000    # -2000.0f

    const/high16 v9, 0x44fa0000    # 2000.0f

    invoke-static {v7, v8, v9}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v7

    goto :goto_76

    .line 746
    :cond_50
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getX()F

    move-result v7

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getX0()F

    move-result v8

    sub-float/2addr v7, v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getScreenDir()[F

    move-result-object v8

    aget v8, v8, v5

    mul-float/2addr v7, v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getY()F

    move-result v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getY0()F

    move-result v9

    sub-float/2addr v8, v9

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getScreenDir()[F

    move-result-object v9

    aget v9, v9, v6

    mul-float/2addr v8, v9

    add-float/2addr v7, v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getPxPerStud()F

    move-result v8

    div-float/2addr v7, v8

    .line 745
    :goto_76
    nop

    .line 747
    .local v7, "studs\\1":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getTool()Lcom/exampletest/mobilestudiotest/core/Tool;

    move-result-object v8

    sget-object v9, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/core/Tool;->ordinal()I

    move-result v8

    aget v8, v9, v8

    const/high16 v9, 0x40000000    # 2.0f

    const/4 v10, 0x0

    packed-switch v8, :pswitch_data_392

    move/from16 v21, v3

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .local v21, "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    goto/16 :goto_38a

    .line 776
    .end local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .restart local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    :pswitch_8d
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getX()F

    move-result v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getX0()F

    move-result v9

    sub-float/2addr v8, v9

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getScreenDir()[F

    move-result-object v9

    aget v5, v9, v5

    mul-float/2addr v8, v5

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getY()F

    move-result v5

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getY0()F

    move-result v9

    sub-float/2addr v5, v9

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getScreenDir()[F

    move-result-object v9

    aget v6, v9, v6

    mul-float/2addr v5, v6

    add-float/2addr v8, v5

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getPxPerStud()F

    move-result v5

    div-float/2addr v8, v5

    const/high16 v5, 0x41400000    # 12.0f

    mul-float/2addr v8, v5

    .line 778
    .local v8, "raw\\1":F
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnapEnabled()Z

    move-result v5

    if-eqz v5, :cond_e5

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnap()F

    move-result v5

    cmpl-float v5, v5, v10

    if-lez v5, :cond_e5

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnap()F

    move-result v5

    div-float v5, v8, v5

    invoke-static {v5}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v5

    int-to-float v5, v5

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnap()F

    move-result v0

    mul-float/2addr v5, v0

    goto :goto_e6

    :cond_e5
    move v5, v8

    .line 779
    .local v5, "deg\\1":F
    :goto_e6
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->at(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    sget-object v6, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getHandle()Lcom/exampletest/mobilestudiotest/render/Handle;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/Handle;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    float-to-double v10, v5

    invoke-static {v10, v11}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v10

    double-to-float v10, v10

    invoke-virtual {v6, v9, v10}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromAxisAngle(Lcom/exampletest/mobilestudiotest/model/Vector3;F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v6

    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    sget-object v6, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v6, v9}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->at(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v6

    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    .line 780
    .local v0, "rot\\1":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getParts()Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$forEachIndexed\\9":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 995
    .local v9, "$i$f$forEachIndexed\\9\\780":I
    const/4 v10, 0x0

    .line 996
    .local v10, "index\\9":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_126
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_15f

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "item\\9":Ljava/lang/Object;
    add-int/lit8 v13, v10, 0x1

    .end local v10    # "index\\9":I
    .local v13, "index\\9":I
    if-gez v10, :cond_137

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_137
    move-object v14, v12

    check-cast v14, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v10, "i\\10":I
    move-object v15, v14

    .local v15, "part\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v14, 0x0

    .line 780
    .local v14, "$i$a$-forEachIndexed-ViewportView$TouchLayer$updateDrag$1$4\\10\\996\\1":I
    const-string v16, "CFrame"

    move/from16 v21, v3

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .restart local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartCf()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/CFrame;->orthonormalize()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v17

    const/16 v19, 0x4

    const/16 v20, 0x0

    const/16 v18, 0x0

    invoke-static/range {v15 .. v20}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 996
    .end local v10    # "i\\10":I
    .end local v14    # "$i$a$-forEachIndexed-ViewportView$TouchLayer$updateDrag$1$4\\10\\996\\1":I
    .end local v15    # "part\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    move v10, v13

    move/from16 v3, v21

    .end local v12    # "item\\9":Ljava/lang/Object;
    goto :goto_126

    .line 997
    .end local v13    # "index\\9":I
    .end local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .restart local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .local v10, "index\\9":I
    :cond_15f
    move/from16 v21, v3

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .restart local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    goto/16 :goto_38a

    .line 765
    .end local v0    # "rot\\1":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v5    # "deg\\1":F
    .end local v6    # "$this$forEachIndexed\\9":Ljava/lang/Iterable;
    .end local v8    # "raw\\1":F
    .end local v9    # "$i$f$forEachIndexed\\9\\780":I
    .end local v10    # "index\\9":I
    .end local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .restart local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    :pswitch_163
    move/from16 v21, v3

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .restart local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getParts()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object v10, v3

    .line 766
    .local v10, "part\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v0

    invoke-direct {v1, v7, v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->snap(FF)F

    move-result v0

    .line 767
    .local v0, "dd\\1":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartSize()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 768
    .local v3, "s0\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v8

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v11

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v12

    const/4 v13, 0x3

    new-array v13, v13, [F

    aput v8, v13, v5

    aput v11, v13, v6

    const/4 v8, 0x2

    aput v12, v13, v8

    move-object/from16 v16, v13

    .line 769
    .local v16, "comps\\1":[F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getLocalAxis()I

    move-result v11

    aget v11, v16, v11

    move/from16 v17, v11

    .line 770
    .local v17, "old\\1":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getLocalAxis()I

    move-result v11

    add-float v12, v17, v0

    const v13, 0x3d4ccccd    # 0.05f

    invoke-static {v12, v13}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v12

    aput v12, v16, v11

    .line 771
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getLocalAxis()I

    move-result v11

    aget v11, v16, v11

    sub-float v18, v11, v17

    .line 772
    .local v18, "applied\\1":F
    sget-object v11, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    new-instance v12, Lcom/exampletest/mobilestudiotest/model/Vector3;

    aget v13, v16, v5

    aget v6, v16, v6

    aget v8, v16, v8

    invoke-direct {v12, v13, v6, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v11, v10, v12}, Lcom/exampletest/mobilestudiotest/model/PartData;->setSize(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    .line 773
    const-string v11, "CFrame"

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartCf()Ljava/util/List;

    move-result-object v6

    invoke-interface {v6, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getHandle()Lcom/exampletest/mobilestudiotest/render/Handle;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/render/Handle;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    div-float v8, v18, v9

    invoke-virtual {v6, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v12

    const/4 v14, 0x4

    const/4 v15, 0x0

    const/4 v13, 0x0

    invoke-static/range {v10 .. v15}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .end local v0    # "dd\\1":F
    .end local v3    # "s0\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v10    # "part\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v16    # "comps\\1":[F
    .end local v17    # "old\\1":F
    .end local v18    # "applied\\1":F
    goto/16 :goto_38a

    .line 749
    .end local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .local v3, "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    :pswitch_1f3
    move/from16 v21, v3

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    .restart local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    const/4 v3, 0x0

    .local v3, "dd\\1":F
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v8

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v8

    invoke-direct {v1, v7, v8}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->snap(FF)F

    move-result v8

    .line 750
    .end local v3    # "dd\\1":F
    .local v8, "dd\\1":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getParts()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$forEachIndexed\\2":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 986
    .local v11, "$i$f$forEachIndexed\\2\\750":I
    const/4 v12, 0x0

    .line 987
    .local v12, "index\\2":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_20e
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_250

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "item\\2":Ljava/lang/Object;
    add-int/lit8 v15, v12, 0x1

    .end local v12    # "index\\2":I
    .local v15, "index\\2":I
    if-gez v12, :cond_21f

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_21f
    move-object/from16 v16, v14

    check-cast v16, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v12, "i\\3":I
    move-object/from16 v22, v16

    .local v22, "part\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v16, 0x0

    .line 750
    .local v16, "$i$a$-forEachIndexed-ViewportView$TouchLayer$updateDrag$1$1\\3\\987\\1":I
    const-string v23, "CFrame"

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartCf()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getHandle()Lcom/exampletest/mobilestudiotest/render/Handle;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Lcom/exampletest/mobilestudiotest/render/Handle;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v24

    const/16 v26, 0x4

    const/16 v27, 0x0

    const/16 v25, 0x0

    invoke-static/range {v22 .. v27}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 987
    .end local v12    # "i\\3":I
    .end local v16    # "$i$a$-forEachIndexed-ViewportView$TouchLayer$updateDrag$1$1\\3\\987\\1":I
    .end local v22    # "part\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    move v12, v15

    const/4 v5, 0x0

    const/4 v6, 0x1

    .end local v14    # "item\\2":Ljava/lang/Object;
    goto :goto_20e

    .line 988
    .end local v15    # "index\\2":I
    .local v12, "index\\2":I
    :cond_250
    nop

    .line 752
    .end local v3    # "$this$forEachIndexed\\2":Ljava/lang/Iterable;
    .end local v11    # "$i$f$forEachIndexed\\2\\750":I
    .end local v12    # "index\\2":I
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCollisionsEnabled()Z

    move-result v3

    if-eqz v3, :cond_38a

    cmpg-float v3, v8, v10

    if-nez v3, :cond_261

    const/4 v6, 0x1

    goto :goto_262

    :cond_261
    const/4 v6, 0x0

    :goto_262
    if-nez v6, :cond_38a

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartedOverlapping()Z

    move-result v3

    if-nez v3, :cond_38a

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getParts()Ljava/util/List;

    move-result-object v3

    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->overlapsOthers(Ljava/util/List;)Z

    move-result v3

    if-eqz v3, :cond_38a

    .line 753
    const/4 v3, 0x0

    .local v3, "lo\\1":F
    const/4 v5, 0x0

    .local v5, "hi\\1":F
    const/high16 v5, 0x3f800000    # 1.0f

    .line 754
    move v6, v5

    const/4 v5, 0x0

    .end local v5    # "hi\\1":F
    .local v6, "hi\\1":F
    :goto_27a
    const/16 v11, 0xa

    if-ge v5, v11, :cond_305

    move v11, v5

    .local v11, "it\\4":I
    const/4 v12, 0x0

    .line 755
    .local v12, "$i$a$-repeat-ViewportView$TouchLayer$updateDrag$1$2\\4\\754\\1":I
    add-float v13, v3, v6

    div-float/2addr v13, v9

    .line 756
    .local v13, "mid\\4":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getParts()Ljava/util/List;

    move-result-object v14

    check-cast v14, Ljava/lang/Iterable;

    .local v14, "$this$forEachIndexed\\5":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 989
    .local v15, "$i$f$forEachIndexed\\5\\756":I
    const/16 v16, 0x0

    .line 990
    .local v16, "index\\5":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_290
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_2e3

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    .local v18, "item\\5":Ljava/lang/Object;
    add-int/lit8 v19, v16, 0x1

    .end local v16    # "index\\5":I
    .local v19, "index\\5":I
    if-gez v16, :cond_2a1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_2a1
    move-object/from16 v20, v18

    check-cast v20, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v16, "i\\6":I
    move-object/from16 v22, v20

    .local v22, "part\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v20, 0x0

    .line 756
    .local v20, "$i$a$-forEachIndexed-ViewportView$TouchLayer$updateDrag$1$2$1\\6\\990\\4":I
    const-string v23, "CFrame"

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartCf()Ljava/util/List;

    move-result-object v9

    move/from16 v28, v10

    move/from16 v10, v16

    .end local v16    # "i\\6":I
    .local v10, "i\\6":I
    invoke-interface {v9, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getHandle()Lcom/exampletest/mobilestudiotest/render/Handle;

    move-result-object v16

    move-object/from16 v29, v0

    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/render/Handle;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    move/from16 v30, v3

    .end local v3    # "lo\\1":F
    .local v30, "lo\\1":F
    mul-float v3, v8, v13

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v9, v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v24

    const/16 v26, 0x4

    const/16 v27, 0x0

    const/16 v25, 0x0

    invoke-static/range {v22 .. v27}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 990
    .end local v10    # "i\\6":I
    .end local v20    # "$i$a$-forEachIndexed-ViewportView$TouchLayer$updateDrag$1$2$1\\6\\990\\4":I
    .end local v22    # "part\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    move/from16 v16, v19

    move/from16 v10, v28

    move-object/from16 v0, v29

    move/from16 v3, v30

    const/high16 v9, 0x40000000    # 2.0f

    .end local v18    # "item\\5":Ljava/lang/Object;
    goto :goto_290

    .line 991
    .end local v19    # "index\\5":I
    .end local v30    # "lo\\1":F
    .restart local v3    # "lo\\1":F
    .local v16, "index\\5":I
    :cond_2e3
    move-object/from16 v29, v0

    move/from16 v30, v3

    move/from16 v28, v10

    .line 757
    .end local v3    # "lo\\1":F
    .end local v14    # "$this$forEachIndexed\\5":Ljava/lang/Iterable;
    .end local v15    # "$i$f$forEachIndexed\\5\\756":I
    .end local v16    # "index\\5":I
    .restart local v30    # "lo\\1":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getParts()Ljava/util/List;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->overlapsOthers(Ljava/util/List;)Z

    move-result v0

    if-eqz v0, :cond_2f8

    move v0, v13

    move v6, v0

    move/from16 v3, v30

    .end local v6    # "hi\\1":F
    .local v0, "hi\\1":F
    goto :goto_2fa

    .end local v0    # "hi\\1":F
    .restart local v6    # "hi\\1":F
    :cond_2f8
    move v0, v13

    move v3, v0

    .line 758
    .end local v30    # "lo\\1":F
    .restart local v3    # "lo\\1":F
    :goto_2fa
    nop

    .line 754
    .end local v11    # "it\\4":I
    .end local v12    # "$i$a$-repeat-ViewportView$TouchLayer$updateDrag$1$2\\4\\754\\1":I
    .end local v13    # "mid\\4":F
    add-int/lit8 v5, v5, 0x1

    move/from16 v10, v28

    move-object/from16 v0, v29

    const/high16 v9, 0x40000000    # 2.0f

    goto/16 :goto_27a

    .line 759
    :cond_305
    move-object/from16 v29, v0

    move/from16 v30, v3

    move/from16 v28, v10

    .end local v3    # "lo\\1":F
    .restart local v30    # "lo\\1":F
    mul-float v8, v8, v30

    .line 760
    invoke-static/range {v29 .. v29}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSnapEnabled()Z

    move-result v0

    if-eqz v0, :cond_33b

    invoke-static/range {v29 .. v29}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v0

    cmpl-float v0, v0, v28

    if-lez v0, :cond_33b

    invoke-static/range {v29 .. v29}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v0

    div-float v0, v8, v0

    invoke-static {v0}, Lkotlin/math/MathKt;->truncate(F)F

    move-result v0

    invoke-static/range {v29 .. v29}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v3

    mul-float v8, v0, v3

    .line 761
    :cond_33b
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getParts()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 992
    .local v3, "$i$f$forEachIndexed\\7\\761":I
    const/4 v5, 0x0

    .line 993
    .local v5, "index\\7":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_347
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_388

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "item\\7":Ljava/lang/Object;
    add-int/lit8 v11, v5, 0x1

    .end local v5    # "index\\7":I
    .local v11, "index\\7":I
    if-gez v5, :cond_358

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_358
    move-object v12, v10

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v5, "i\\8":I
    move-object v13, v12

    .local v13, "part\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v12, 0x0

    .line 761
    .local v12, "$i$a$-forEachIndexed-ViewportView$TouchLayer$updateDrag$1$3\\8\\993\\1":I
    const-string v14, "CFrame"

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getStartCf()Ljava/util/List;

    move-result-object v15

    invoke-interface {v15, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->getHandle()Lcom/exampletest/mobilestudiotest/render/Handle;

    move-result-object v16

    move-object/from16 v19, v0

    .end local v0    # "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    .local v19, "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/render/Handle;->getAxis()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v15, v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v15

    const/16 v17, 0x4

    const/16 v18, 0x0

    const/16 v16, 0x0

    invoke-static/range {v13 .. v18}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 993
    .end local v5    # "i\\8":I
    .end local v12    # "$i$a$-forEachIndexed-ViewportView$TouchLayer$updateDrag$1$3\\8\\993\\1":I
    .end local v13    # "part\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    move v5, v11

    move-object/from16 v0, v19

    .end local v10    # "item\\7":Ljava/lang/Object;
    goto :goto_347

    .line 994
    .end local v11    # "index\\7":I
    .end local v19    # "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    .restart local v0    # "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    .local v5, "index\\7":I
    :cond_388
    move-object/from16 v19, v0

    .line 784
    .end local v0    # "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    .end local v3    # "$i$f$forEachIndexed\\7\\761":I
    .end local v5    # "index\\7":I
    .end local v6    # "hi\\1":F
    .end local v8    # "dd\\1":F
    .end local v30    # "lo\\1":F
    :cond_38a
    :goto_38a
    nop

    .end local v4    # "t\\1":Ljava/lang/Float;
    .end local v7    # "studs\\1":F
    .end local v21    # "$i$a$-synchronized-ViewportView$TouchLayer$updateDrag$1\\1\\742\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_38d
    .catchall {:try_start_10 .. :try_end_38d} :catchall_38f

    .line 742
    monitor-exit v2

    .line 785
    return-void

    .line 742
    :catchall_38f
    move-exception v0

    monitor-exit v2

    throw v0

    :pswitch_data_392
    .packed-switch 0x1
        :pswitch_1f3
        :pswitch_163
        :pswitch_8d
    .end packed-switch
.end method

.method private final updatePartDrag(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;)V
    .registers 29
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;

    .line 877
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v2

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    monitor-enter v2

    const/4 v3, 0x0

    .line 878
    .local v3, "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    :try_start_10
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getX()F

    move-result v5

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getY()F

    move-result v6

    invoke-virtual {v4, v5, v6}, Lcom/exampletest/mobilestudiotest/render/ViewState;->screenRay(FF)Lkotlin/Pair;

    move-result-object v4

    invoke-virtual {v4}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-object v8, v5

    .local v8, "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v4}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v4

    move-object v9, v4

    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 879
    .local v9, "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v4, Ljava/util/IdentityHashMap;

    invoke-direct {v4}, Ljava/util/IdentityHashMap;-><init>()V

    check-cast v4, Ljava/util/Map;

    invoke-static {v4}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v4

    move-object v5, v4

    .line 927
    .local v5, "s\\2":Ljava/util/Set;
    const/4 v6, 0x0

    .line 879
    .local v6, "$i$a$-also-ViewportView$TouchLayer$updatePartDrag$1$dragged$1\\2\\879\\1":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getParts()Ljava/util/List;

    move-result-object v7

    check-cast v7, Ljava/lang/Iterable;

    .local v7, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1011
    .local v10, "$i$f$forEach\\3\\879":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_4a
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_5d

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\3":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v13, "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v14, 0x0

    .line 879
    .local v14, "$i$a$-forEach-ViewportView$TouchLayer$updatePartDrag$1$dragged$1$1\\4\\1011\\2":I
    invoke-interface {v5, v13}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 1011
    nop

    .end local v12    # "element\\3":Ljava/lang/Object;
    .end local v13    # "it\\4":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "$i$a$-forEach-ViewportView$TouchLayer$updatePartDrag$1$dragged$1$1\\4\\1011\\2":I
    goto :goto_4a

    .line 1012
    :cond_5d
    nop

    .line 879
    .end local v7    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v10    # "$i$f$forEach\\3\\879":I
    nop

    .line 880
    .end local v5    # "s\\2":Ljava/util/Set;
    .end local v6    # "$i$a$-also-ViewportView$TouchLayer$updatePartDrag$1$dragged$1\\2\\879\\1":I
    .local v4, "dragged\\1":Ljava/util/Set;
    sget-object v6, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->renderParts()Ljava/util/List;

    move-result-object v7

    new-instance v11, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda7;

    invoke-direct {v11, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda7;-><init>(Ljava/util/Set;)V

    const v10, 0x459c4000    # 5000.0f

    invoke-virtual/range {v6 .. v11}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->raycast(Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FLkotlin/jvm/functions/Function1;)Lcom/exampletest/mobilestudiotest/engine/RayHit;

    move-result-object v5

    .line 881
    .local v5, "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getGrab()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    .line 882
    .local v6, "grabOff\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v7, 0x0

    if-eqz v5, :cond_1bc

    .line 884
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getNormal()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    .line 885
    .local v10, "n\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;->abs()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    .line 886
    .local v11, "ax\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v12

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v13

    cmpl-float v12, v12, v13

    const/4 v13, 0x2

    const/4 v14, 0x1

    if-ltz v12, :cond_a8

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v12

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v15

    cmpl-float v12, v12, v15

    if-ltz v12, :cond_a8

    move v12, v14

    goto :goto_b7

    :cond_a8
    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v12

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v15

    cmpl-float v12, v12, v15

    if-ltz v12, :cond_b6

    const/4 v12, 0x0

    goto :goto_b7

    :cond_b6
    move v12, v13

    .line 887
    .local v12, "axis\\1":I
    :goto_b7
    invoke-virtual {v10, v12}, Lcom/exampletest/mobilestudiotest/model/Vector3;->get(I)F

    move-result v15

    cmpl-float v15, v15, v7

    if-ltz v15, :cond_c2

    const/high16 v15, 0x3f800000    # 1.0f

    goto :goto_c4

    :cond_c2
    const/high16 v15, -0x40800000    # -1.0f

    .line 888
    .local v15, "sign\\1":F
    :goto_c4
    move/from16 v16, v7

    new-instance v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v12, :cond_cd

    move/from16 v18, v16

    goto :goto_d3

    :cond_cd
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v17

    move/from16 v18, v17

    :goto_d3
    if-ne v12, v14, :cond_d8

    move/from16 v14, v16

    goto :goto_de

    :cond_d8
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v17

    move/from16 v14, v17

    :goto_de
    if-ne v12, v13, :cond_e3

    move/from16 v13, v16

    goto :goto_e9

    :cond_e3
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v17

    move/from16 v13, v17

    :goto_e9
    move-object/from16 v17, v0

    move/from16 v0, v18

    invoke-direct {v7, v0, v14, v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 889
    .local v7, "offPlane\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v12, :cond_fe

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getHalf()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v13

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v13

    mul-float/2addr v13, v15

    goto :goto_100

    :cond_fe
    move/from16 v13, v16

    :goto_100
    const/4 v14, 0x1

    if-ne v12, v14, :cond_10d

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getHalf()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v14

    mul-float/2addr v14, v15

    goto :goto_10f

    :cond_10d
    move/from16 v14, v16

    :goto_10f
    move/from16 v18, v3

    const/4 v3, 0x2

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .local v18, "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    if-ne v12, v3, :cond_11e

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getHalf()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    mul-float/2addr v3, v15

    goto :goto_120

    :cond_11e
    move/from16 v3, v16

    :goto_120
    invoke-direct {v0, v13, v14, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 890
    .local v0, "lift\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3, v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    .line 892
    .local v3, "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v13

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSnapEnabled()Z

    move-result v13

    if-eqz v13, :cond_1af

    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v13

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v13

    cmpl-float v13, v13, v16

    if-lez v13, :cond_1af

    .line 893
    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v13

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v13

    .line 895
    .local v13, "s\\1":F
    new-instance v14, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v12, :cond_15c

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v16

    move-object/from16 v21, v0

    move-object/from16 v22, v3

    move/from16 v0, v16

    goto :goto_172

    :cond_15c
    move-object/from16 v21, v0

    .end local v0    # "lift\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v21, "lift\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v0

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getHalf()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v16

    move-object/from16 v22, v3

    .end local v3    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v22, "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    invoke-static {v1, v13, v0, v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->updatePartDrag$lambda$85$sn(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;FFF)F

    move-result v16

    move/from16 v0, v16

    :goto_172
    const/4 v3, 0x1

    if-ne v12, v3, :cond_17c

    invoke-virtual/range {v22 .. v22}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    move-object/from16 v19, v4

    goto :goto_18e

    :cond_17c
    invoke-virtual/range {v22 .. v22}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getHalf()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v16

    move-object/from16 v19, v4

    .end local v4    # "dragged\\1":Ljava/util/Set;
    .local v19, "dragged\\1":Ljava/util/Set;
    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    invoke-static {v1, v13, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->updatePartDrag$lambda$85$sn(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;FFF)F

    move-result v3

    :goto_18e
    const/4 v4, 0x2

    if-ne v12, v4, :cond_198

    invoke-virtual/range {v22 .. v22}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    move-object/from16 v20, v5

    goto :goto_1aa

    :cond_198
    invoke-virtual/range {v22 .. v22}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getHalf()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v16

    move-object/from16 v20, v5

    .end local v5    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .local v20, "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    invoke-static {v1, v13, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->updatePartDrag$lambda$85$sn(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;FFF)F

    move-result v4

    :goto_1aa
    invoke-direct {v14, v0, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    move-object v3, v14

    .end local v22    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v3    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    goto :goto_1b9

    .line 892
    .end local v13    # "s\\1":F
    .end local v19    # "dragged\\1":Ljava/util/Set;
    .end local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .end local v21    # "lift\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v0    # "lift\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v4    # "dragged\\1":Ljava/util/Set;
    .restart local v5    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    :cond_1af
    move-object/from16 v21, v0

    move-object/from16 v22, v3

    move-object/from16 v19, v4

    move-object/from16 v20, v5

    .line 897
    .end local v0    # "lift\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v3    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v4    # "dragged\\1":Ljava/util/Set;
    .end local v5    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .restart local v19    # "dragged\\1":Ljava/util/Set;
    .restart local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .restart local v21    # "lift\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v22    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object/from16 v3, v22

    .end local v22    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v3    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :goto_1b9
    nop

    .end local v3    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v7    # "offPlane\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v10    # "n\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "ax\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v12    # "axis\\1":I
    .end local v15    # "sign\\1":F
    .end local v21    # "lift\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    goto/16 :goto_23c

    .line 900
    .end local v18    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .end local v19    # "dragged\\1":Ljava/util/Set;
    .end local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .local v3, "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .restart local v4    # "dragged\\1":Ljava/util/Set;
    .restart local v5    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    :cond_1bc
    move-object/from16 v17, v0

    move/from16 v18, v3

    move-object/from16 v19, v4

    move-object/from16 v20, v5

    move/from16 v16, v7

    .end local v3    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .end local v4    # "dragged\\1":Ljava/util/Set;
    .end local v5    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .restart local v18    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .restart local v19    # "dragged\\1":Ljava/util/Set;
    .restart local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0
    :try_end_1ce
    .catchall {:try_start_10 .. :try_end_1ce} :catchall_289

    const v3, 0x38d1b717    # 1.0E-4f

    cmpg-float v0, v0, v3

    if-gez v0, :cond_1d7

    .end local v6    # "grabOff\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v18    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .end local v19    # "dragged\\1":Ljava/util/Set;
    .end local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    monitor-exit v2

    return-void

    .line 901
    .restart local v6    # "grabOff\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v8    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v9    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v18    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .restart local v19    # "dragged\\1":Ljava/util/Set;
    .restart local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    :cond_1d7
    :try_start_1d7
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getGrab()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v0

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    sub-float/2addr v0, v3

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3
    :try_end_1e8
    .catchall {:try_start_1d7 .. :try_end_1e8} :catchall_289

    div-float/2addr v0, v3

    .line 902
    .local v0, "tt\\1":F
    cmpg-float v3, v0, v16

    if-gez v3, :cond_1ef

    .end local v0    # "tt\\1":F
    .end local v6    # "grabOff\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v18    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .end local v19    # "dragged\\1":Ljava/util/Set;
    .end local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    monitor-exit v2

    return-void

    .line 903
    .restart local v0    # "tt\\1":F
    .restart local v6    # "grabOff\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v8    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v9    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v18    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .restart local v19    # "dragged\\1":Ljava/util/Set;
    .restart local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    :cond_1ef
    :try_start_1ef
    invoke-virtual {v9, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v8, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    .line 904
    .local v3, "hp\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    .line 905
    .local v4, "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSnapEnabled()Z

    move-result v5

    if-eqz v5, :cond_23b

    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v5

    cmpl-float v5, v5, v16

    if-lez v5, :cond_23b

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v7

    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v10

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v10

    invoke-direct {v1, v7, v10}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->snap(FF)F

    move-result v7

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v10

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v11

    invoke-static/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v12

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v12

    invoke-direct {v1, v11, v12}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->snap(FF)F

    move-result v11

    invoke-direct {v5, v7, v10, v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    move-object v4, v5

    .line 906
    :cond_23b
    move-object v3, v4

    .line 882
    .end local v0    # "tt\\1":F
    .end local v3    # "hp\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v4    # "c\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :goto_23c
    nop

    .line 908
    .local v3, "target\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .line 909
    .local v0, "delta\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getParts()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$forEachIndexed\\5":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1013
    .local v5, "$i$f$forEachIndexed\\5\\909":I
    const/4 v7, 0x0

    .line 1014
    .local v7, "index\\5":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_251
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_283

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "item\\5":Ljava/lang/Object;
    add-int/lit8 v12, v7, 0x1

    .end local v7    # "index\\5":I
    .local v12, "index\\5":I
    if-gez v7, :cond_262

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_262
    move-object v13, v11

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "i\\6":I
    move-object/from16 v21, v13

    .local v21, "part\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v13, 0x0

    .line 909
    .local v13, "$i$a$-forEachIndexed-ViewportView$TouchLayer$updatePartDrag$1$1\\6\\1014\\1":I
    const-string v22, "CFrame"

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->getStartCf()Ljava/util/List;

    move-result-object v14

    invoke-interface {v14, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v14, v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v23

    const/16 v25, 0x4

    const/16 v26, 0x0

    const/16 v24, 0x0

    invoke-static/range {v21 .. v26}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 1014
    .end local v7    # "i\\6":I
    .end local v13    # "$i$a$-forEachIndexed-ViewportView$TouchLayer$updatePartDrag$1$1\\6\\1014\\1":I
    .end local v21    # "part\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    move v7, v12

    .end local v11    # "item\\5":Ljava/lang/Object;
    goto :goto_251

    .line 1015
    .end local v12    # "index\\5":I
    .local v7, "index\\5":I
    :cond_283
    nop

    .line 910
    .end local v4    # "$this$forEachIndexed\\5":Ljava/lang/Iterable;
    .end local v5    # "$i$f$forEachIndexed\\5\\909":I
    .end local v7    # "index\\5":I
    nop

    .end local v0    # "delta\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v3    # "target\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v6    # "grabOff\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "o\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "dir\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v18    # "$i$a$-synchronized-ViewportView$TouchLayer$updatePartDrag$1\\1\\877\\0":I
    .end local v19    # "dragged\\1":Ljava/util/Set;
    .end local v20    # "hit\\1":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_287
    .catchall {:try_start_1ef .. :try_end_287} :catchall_289

    .line 877
    monitor-exit v2

    .line 911
    return-void

    .line 877
    :catchall_289
    move-exception v0

    monitor-exit v2

    throw v0
.end method

.method static final updatePartDrag$lambda$85$lambda$83(Ljava/util/Set;Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 4
    .param p0, "$dragged"    # Ljava/util/Set;
    .param p1, "it"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 880
    invoke-interface {p0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1a

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->transparency(Lcom/exampletest/mobilestudiotest/model/Instance;)F

    move-result v0

    const v1, 0x3f7d70a4    # 0.99f

    cmpg-float v0, v0, v1

    if-gez v0, :cond_1a

    const/4 v0, 0x1

    goto :goto_1b

    :cond_1a
    const/4 v0, 0x0

    :goto_1b
    return v0
.end method

.method private static final updatePartDrag$lambda$85$sn(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;FFF)F
    .registers 5
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p1, "s"    # F
    .param p2, "v"    # F
    .param p3, "h"    # F

    .line 894
    sub-float v0, p2, p3

    invoke-direct {p0, v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->snap(FF)F

    move-result v0

    add-float/2addr v0, p3

    return v0
.end method


# virtual methods
.method public final getBusy()Z
    .registers 2

    .line 138
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_24

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getFlyUp()Z

    move-result v0

    if-nez v0, :cond_24

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getFlyDown()Z

    move-result v0

    if-nez v0, :cond_24

    const/4 v0, 0x0

    goto :goto_25

    :cond_24
    const/4 v0, 0x1

    :goto_25
    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 8
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    const-string v0, "canvas"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 154
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->buttons:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    .line 155
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    .line 156
    .local v0, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getActiveJoy()Z

    move-result v1

    if-eqz v1, :cond_21

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getFixedStick()Z

    move-result v1

    if-nez v1, :cond_21

    goto :goto_2d

    :cond_21
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getDefaultJoyX()F

    move-result v1

    iput v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCx:F

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getDefaultJoyY()F

    move-result v1

    iput v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->joyCy:F

    .line 157
    :goto_2d
    if-eqz v0, :cond_33

    invoke-direct {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->drawPlayControls(Landroid/graphics/Canvas;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V

    goto :goto_36

    :cond_33
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->drawEditControls(Landroid/graphics/Canvas;)V

    .line 158
    :goto_36
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->getShowFps()Z

    move-result v1

    if-eqz v1, :cond_ac

    .line 159
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/high16 v2, 0x41300000    # 11.0f

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v3, v2

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 160
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 161
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const v2, -0x66000001

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 162
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 163
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->getRenderer()Lcom/exampletest/mobilestudiotest/render/SceneRenderer;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/SceneRenderer;->getFps()F

    move-result v1

    invoke-static {v1}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " FPS"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getWidth()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x41000000    # 8.0f

    iget v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v4, v3

    sub-float/2addr v2, v4

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->getHeight()I

    move-result v3

    int-to-float v3, v3

    const/high16 v4, 0x40c00000    # 6.0f

    iget v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->d:F

    mul-float/2addr v5, v4

    sub-float/2addr v3, v5

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 164
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 165
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v2, -0x1

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 166
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->text:Landroid/graphics/Paint;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 168
    :cond_ac
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 9
    .param p1, "e"    # Landroid/view/MotionEvent;

    const-string v0, "e"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 360
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v0

    .line 361
    .local v0, "idx":I
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v2, 0x1

    packed-switch v1, :pswitch_data_8c

    :pswitch_11
    goto/16 :goto_88

    .line 371
    :pswitch_13
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    const-string v3, "<get-keys>(...)"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_28
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_88

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    .local v3, "id":I
    const/4 v4, 0x0

    invoke-direct {p0, v3, v4, v4, v2}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->up(IFFZ)V

    .end local v3    # "id":I
    goto :goto_28

    .line 364
    :pswitch_3d
    const/4 v1, 0x0

    .local v1, "i":I
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v3

    :goto_42
    if-ge v1, v3, :cond_64

    .line 365
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->ptrs:Ljava/util/HashMap;

    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;

    if-eqz v4, :cond_61

    .line 366
    .local v4, "p":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getX(I)F

    move-result v5

    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getY(I)F

    move-result v6

    invoke-direct {p0, v4, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->move(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;FF)V

    .line 364
    .end local v4    # "p":Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
    :cond_61
    add-int/lit8 v1, v1, 0x1

    goto :goto_42

    .line 368
    .end local v1    # "i":I
    :cond_64
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->camGesture()V

    goto :goto_88

    .line 370
    :pswitch_68
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v1

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v3

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v4

    const/4 v5, 0x0

    invoke-direct {p0, v1, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->up(IFFZ)V

    goto :goto_88

    .line 362
    :pswitch_79
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v1

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v3

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v4

    invoke-direct {p0, v1, v3, v4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->down(IFF)V

    .line 373
    :cond_88
    :goto_88
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->invalidate()V

    .line 374
    return v2

    :pswitch_data_8c
    .packed-switch 0x0
        :pswitch_79
        :pswitch_68
        :pswitch_3d
        :pswitch_13
        :pswitch_11
        :pswitch_79
        :pswitch_68
    .end packed-switch
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.AdornDrag (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$AdornDrag)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "AdornDrag"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u000e\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003BI\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\u000c\u0012\u0008\u0010\r\u001a\u0004\u0018\u00010\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u000f\u0012\u0006\u0010\u0010\u001a\u00020\u0011\u00a2\u0006\u0004\u0008\u0012\u0010\u0013R\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0011\u0010\u000b\u001a\u00020\u000c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0017R\u0015\u0010\r\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\n\n\u0002\u0010\u001a\u001a\u0004\u0008\u0018\u0010\u0019R\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001b\u0010\u001cR\u0011\u0010\u0010\u001a\u00020\u0011\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u001e\u00a8\u0006\u001f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "adorn",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "tip",
        "Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;",
        "axis0",
        "rt",
        "Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;",
        "arg",
        "Lorg/luaj/vm2/LuaValue;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;Ljava/lang/Float;Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lorg/luaj/vm2/LuaValue;)V",
        "getAdorn",
        "()Lcom/exampletest/mobilestudiotest/model/Instance;",
        "getTip",
        "()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;",
        "getAxis0",
        "()Ljava/lang/Float;",
        "Ljava/lang/Float;",
        "getRt",
        "()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;",
        "getArg",
        "()Lorg/luaj/vm2/LuaValue;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final adorn:Lcom/exampletest/mobilestudiotest/model/Instance;

.field private final arg:Lorg/luaj/vm2/LuaValue;

.field private final axis0:Ljava/lang/Float;

.field private final rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

.field private final tip:Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;Ljava/lang/Float;Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lorg/luaj/vm2/LuaValue;)V
    .registers 11
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "adorn"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p6, "tip"    # Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;
    .param p7, "axis0"    # Ljava/lang/Float;
    .param p8, "rt"    # Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;
    .param p9, "arg"    # Lorg/luaj/vm2/LuaValue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;",
            "Ljava/lang/Float;",
            "Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;",
            "Lorg/luaj/vm2/LuaValue;",
            ")V"
        }
    .end annotation

    const-string v0, "adorn"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "tip"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "rt"

    invoke-static {p8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "arg"

    invoke-static {p9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    .line 134
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    .line 133
    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->adorn:Lcom/exampletest/mobilestudiotest/model/Instance;

    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->tip:Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    iput-object p7, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->axis0:Ljava/lang/Float;

    .line 134
    iput-object p8, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    iput-object p9, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->arg:Lorg/luaj/vm2/LuaValue;

    .line 133
    return-void
.end method


# virtual methods
.method public final getAdorn()Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 2

    .line 133
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->adorn:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-object v0
.end method

.method public final getArg()Lorg/luaj/vm2/LuaValue;
    .registers 2

    .line 134
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->arg:Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method public final getAxis0()Ljava/lang/Float;
    .registers 2

    .line 133
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->axis0:Ljava/lang/Float;

    return-object v0
.end method

.method public final getRt()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;
    .registers 2

    .line 134
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    return-object v0
.end method

.method public final getTip()Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;
    .registers 2

    .line 133
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$AdornDrag;->tip:Lcom/exampletest/mobilestudiotest/render/AdornHandles$Tip;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.BoxSel (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$BoxSel)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "BoxSel"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\'\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000e\u00a8\u0006\u000f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "additive",
        "",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFZ)V",
        "getAdditive",
        "()Z",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final additive:Z

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFZ)V
    .registers 6
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "additive"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFFZ)V"
        }
    .end annotation

    .line 129
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    iput-boolean p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->additive:Z

    return-void
.end method


# virtual methods
.method public final getAdditive()Z
    .registers 2

    .line 129
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$BoxSel;->additive:Z

    return v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.Btn (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$Btn)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Btn"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0005\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\'\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000e\u00a8\u0006\u000f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "name",
        "",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLjava/lang/String;)V",
        "getName",
        "()Ljava/lang/String;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final name:Ljava/lang/String;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLjava/lang/String;)V
    .registers 7
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "name"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const-string v0, "name"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;->name:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final getName()Ljava/lang/String;
    .registers 2

    .line 110
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Btn;->name:Ljava/lang/String;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.Cam (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$Cam)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Cam"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0004\n\u0002\u0010\u000b\n\u0002\u0008\u0008\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\u001f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u000cX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\r\u0010\u000e\"\u0004\u0008\u000f\u0010\u0010R\u001a\u0010\u0011\u001a\u00020\u000cX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0012\u0010\u000e\"\u0004\u0008\u0013\u0010\u0010\u00a8\u0006\u0014"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V",
        "moved",
        "",
        "getMoved",
        "()Z",
        "setMoved",
        "(Z)V",
        "playDown",
        "getPlayDown",
        "setPlayDown",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private moved:Z

.field private playDown:Z

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V
    .registers 5
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)V"
        }
    .end annotation

    .line 111
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    return-void
.end method


# virtual methods
.method public final getMoved()Z
    .registers 2

    .line 111
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->moved:Z

    return v0
.end method

.method public final getPlayDown()Z
    .registers 2

    .line 111
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->playDown:Z

    return v0
.end method

.method public final setMoved(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 111
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->moved:Z

    return-void
.end method

.method public final setPlayDown(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 111
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;->playDown:Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.Drag (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$Drag)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Drag"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0014\n\u0002\u0008\u0019\n\u0002\u0010\u000b\n\u0002\u0008\u0003\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\u0083\u0001\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\u000c\u0012\u000c\u0010\r\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u000e\u0012\u000c\u0010\u0010\u001a\u0008\u0012\u0004\u0012\u00020\u00110\u000e\u0012\u000c\u0010\u0012\u001a\u0008\u0012\u0004\u0012\u00020\u00130\u000e\u0012\u0006\u0010\u0014\u001a\u00020\u0007\u0012\u0006\u0010\u0015\u001a\u00020\u0016\u0012\u0006\u0010\u0017\u001a\u00020\u0013\u0012\u0006\u0010\u0018\u001a\u00020\u0005\u0012\u0008\u0010\u0019\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\u0004\u0008\u001a\u0010\u001bR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001c\u0010\u001dR\u0011\u0010\u000b\u001a\u00020\u000c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001e\u0010\u001fR\u0017\u0010\r\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008 \u0010!R\u0017\u0010\u0010\u001a\u0008\u0012\u0004\u0012\u00020\u00110\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\"\u0010!R\u0017\u0010\u0012\u001a\u0008\u0012\u0004\u0012\u00020\u00130\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008#\u0010!R\u0011\u0010\u0014\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008$\u0010%R\u0011\u0010\u0015\u001a\u00020\u0016\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008&\u0010\'R\u0011\u0010\u0017\u001a\u00020\u0013\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008(\u0010)R\u0011\u0010\u0018\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008*\u0010+R\u0015\u0010\u0019\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\n\n\u0002\u0010.\u001a\u0004\u0008,\u0010-R\u0011\u0010/\u001a\u000200\u00a2\u0006\u0008\n\u0000\u001a\u0004\u00081\u00102\u00a8\u00063"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "handle",
        "Lcom/exampletest/mobilestudiotest/render/Handle;",
        "tool",
        "Lcom/exampletest/mobilestudiotest/core/Tool;",
        "parts",
        "",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "startCf",
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "startSize",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "pxPerStud",
        "screenDir",
        "",
        "center",
        "localAxis",
        "t0Axis",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/render/Handle;Lcom/exampletest/mobilestudiotest/core/Tool;Ljava/util/List;Ljava/util/List;Ljava/util/List;F[FLcom/exampletest/mobilestudiotest/model/Vector3;ILjava/lang/Float;)V",
        "getHandle",
        "()Lcom/exampletest/mobilestudiotest/render/Handle;",
        "getTool",
        "()Lcom/exampletest/mobilestudiotest/core/Tool;",
        "getParts",
        "()Ljava/util/List;",
        "getStartCf",
        "getStartSize",
        "getPxPerStud",
        "()F",
        "getScreenDir",
        "()[F",
        "getCenter",
        "()Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "getLocalAxis",
        "()I",
        "getT0Axis",
        "()Ljava/lang/Float;",
        "Ljava/lang/Float;",
        "startedOverlapping",
        "",
        "getStartedOverlapping",
        "()Z",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final center:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private final handle:Lcom/exampletest/mobilestudiotest/render/Handle;

.field private final localAxis:I

.field private final parts:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation
.end field

.field private final pxPerStud:F

.field private final screenDir:[F

.field private final startCf:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/CFrame;",
            ">;"
        }
    .end annotation
.end field

.field private final startSize:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            ">;"
        }
    .end annotation
.end field

.field private final startedOverlapping:Z

.field private final t0Axis:Ljava/lang/Float;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

.field private final tool:Lcom/exampletest/mobilestudiotest/core/Tool;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/render/Handle;Lcom/exampletest/mobilestudiotest/core/Tool;Ljava/util/List;Ljava/util/List;Ljava/util/List;F[FLcom/exampletest/mobilestudiotest/model/Vector3;ILjava/lang/Float;)V
    .registers 27
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "handle"    # Lcom/exampletest/mobilestudiotest/render/Handle;
    .param p6, "tool"    # Lcom/exampletest/mobilestudiotest/core/Tool;
    .param p7, "parts"    # Ljava/util/List;
    .param p8, "startCf"    # Ljava/util/List;
    .param p9, "startSize"    # Ljava/util/List;
    .param p10, "pxPerStud"    # F
    .param p11, "screenDir"    # [F
    .param p12, "center"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p13, "localAxis"    # I
    .param p14, "t0Axis"    # Ljava/lang/Float;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF",
            "Lcom/exampletest/mobilestudiotest/render/Handle;",
            "Lcom/exampletest/mobilestudiotest/core/Tool;",
            "Ljava/util/List<",
            "+",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/CFrame;",
            ">;",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            ">;F[F",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "I",
            "Ljava/lang/Float;",
            ")V"
        }
    .end annotation

    move-object/from16 v0, p5

    move-object/from16 v1, p6

    move-object/from16 v2, p7

    move-object/from16 v3, p8

    move-object/from16 v4, p9

    move-object/from16 v5, p11

    move-object/from16 v6, p12

    const-string v7, "handle"

    invoke-static {v0, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "tool"

    invoke-static {v1, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "parts"

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "startCf"

    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "startSize"

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "screenDir"

    invoke-static {v5, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "center"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 119
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    .line 121
    invoke-direct/range {p0 .. p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    .line 119
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->handle:Lcom/exampletest/mobilestudiotest/render/Handle;

    iput-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->tool:Lcom/exampletest/mobilestudiotest/core/Tool;

    iput-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->parts:Ljava/util/List;

    .line 120
    iput-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->startCf:Ljava/util/List;

    iput-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->startSize:Ljava/util/List;

    move/from16 v7, p10

    iput v7, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->pxPerStud:F

    iput-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->screenDir:[F

    .line 121
    iput-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->center:Lcom/exampletest/mobilestudiotest/model/Vector3;

    move/from16 v8, p13

    iput v8, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->localAxis:I

    move-object/from16 v9, p14

    iput-object v9, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->t0Axis:Ljava/lang/Float;

    .line 123
    iget-object v10, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->tool:Lcom/exampletest/mobilestudiotest/core/Tool;

    sget-object v11, Lcom/exampletest/mobilestudiotest/core/Tool;->MOVE:Lcom/exampletest/mobilestudiotest/core/Tool;

    if-ne v10, v11, :cond_70

    iget-object v10, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    iget-object v10, v10, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v10}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v10

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCollisionsEnabled()Z

    move-result v10

    if-eqz v10, :cond_70

    iget-object v10, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    iget-object v11, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->parts:Ljava/util/List;

    invoke-static {v10, v11}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->access$overlapsOthers(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;Ljava/util/List;)Z

    move-result v10

    if-eqz v10, :cond_70

    const/4 v10, 0x1

    goto :goto_71

    :cond_70
    const/4 v10, 0x0

    :goto_71
    iput-boolean v10, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->startedOverlapping:Z

    .line 119
    return-void
.end method


# virtual methods
.method public final getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 121
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->center:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public final getHandle()Lcom/exampletest/mobilestudiotest/render/Handle;
    .registers 2

    .line 119
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->handle:Lcom/exampletest/mobilestudiotest/render/Handle;

    return-object v0
.end method

.method public final getLocalAxis()I
    .registers 2

    .line 121
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->localAxis:I

    return v0
.end method

.method public final getParts()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 119
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->parts:Ljava/util/List;

    return-object v0
.end method

.method public final getPxPerStud()F
    .registers 2

    .line 120
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->pxPerStud:F

    return v0
.end method

.method public final getScreenDir()[F
    .registers 2

    .line 120
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->screenDir:[F

    return-object v0
.end method

.method public final getStartCf()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/CFrame;",
            ">;"
        }
    .end annotation

    .line 120
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->startCf:Ljava/util/List;

    return-object v0
.end method

.method public final getStartSize()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            ">;"
        }
    .end annotation

    .line 120
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->startSize:Ljava/util/List;

    return-object v0
.end method

.method public final getStartedOverlapping()Z
    .registers 2

    .line 123
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->startedOverlapping:Z

    return v0
.end method

.method public final getT0Axis()Ljava/lang/Float;
    .registers 2

    .line 121
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->t0Axis:Ljava/lang/Float;

    return-object v0
.end method

.method public final getTool()Lcom/exampletest/mobilestudiotest/core/Tool;
    .registers 2

    .line 119
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Drag;->tool:Lcom/exampletest/mobilestudiotest/core/Tool;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.GuiDrag (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$GuiDrag)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "GuiDrag"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\'\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012\"\u0004\u0008\u0013\u0010\u0014\u00a8\u0006\u0015"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "state",
        "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;)V",
        "getState",
        "()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;",
        "active",
        "",
        "getActive",
        "()Z",
        "setActive",
        "(Z)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private active:Z

.field private final state:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;)V
    .registers 7
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "state"    # Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF",
            "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;",
            ")V"
        }
    .end annotation

    const-string v0, "state"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 114
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->state:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;

    return-void
.end method


# virtual methods
.method public final getActive()Z
    .registers 2

    .line 114
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->active:Z

    return v0
.end method

.method public final getState()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;
    .registers 2

    .line 114
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->state:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$DragState;

    return-object v0
.end method

.method public final setActive(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 114
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiDrag;->active:Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.GuiPress (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$GuiPress)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "GuiPress"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B1\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0008\u0010\u000b\u001a\u0004\u0018\u00010\u000c\u00a2\u0006\u0004\u0008\r\u0010\u000eR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\u000c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R\u001a\u0010\u0013\u001a\u00020\u0014X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0015\u0010\u0016\"\u0004\u0008\u0017\u0010\u0018\u00a8\u0006\u0019"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "hit",
        "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;",
        "scroll",
        "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V",
        "getHit",
        "()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;",
        "getScroll",
        "()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;",
        "cancelled",
        "",
        "getCancelled",
        "()Z",
        "setCancelled",
        "(Z)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private cancelled:Z

.field private final hit:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

.field private final scroll:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V
    .registers 8
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "hit"    # Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .param p6, "scroll"    # Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF",
            "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;",
            "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;",
            ")V"
        }
    .end annotation

    const-string v0, "hit"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 112
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->hit:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->scroll:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    return-void
.end method


# virtual methods
.method public final getCancelled()Z
    .registers 2

    .line 112
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->cancelled:Z

    return v0
.end method

.method public final getHit()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;
    .registers 2

    .line 112
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->hit:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Hit;

    return-object v0
.end method

.method public final getScroll()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    .registers 2

    .line 112
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->scroll:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    return-object v0
.end method

.method public final setCancelled(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 112
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiPress;->cancelled:Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.GuiScroll (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$GuiScroll)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "GuiScroll"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\'\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000e\u00a8\u0006\u000f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "scroll",
        "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V",
        "getScroll",
        "()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final scroll:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;)V
    .registers 7
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "scroll"    # Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF",
            "Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;",
            ")V"
        }
    .end annotation

    const-string v0, "scroll"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 113
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;->scroll:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    return-void
.end method


# virtual methods
.method public final getScroll()Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;
    .registers 2

    .line 113
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$GuiScroll;->scroll:Lcom/exampletest/mobilestudiotest/ui/GuiOverlay$Scroll;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.Joy (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$Joy)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Joy"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0004\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\u001f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\t\u0010\n\u00a8\u0006\u000b"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V
    .registers 5
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)V"
        }
    .end annotation

    .line 109
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Joy;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.PartDrag (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$PartDrag)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "PartDrag"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003BS\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u000c\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\n\u0012\u000c\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\r0\n\u0012\u0006\u0010\u000e\u001a\u00020\u000f\u0012\u0006\u0010\u0010\u001a\u00020\u000f\u0012\u0006\u0010\u0011\u001a\u00020\u000f\u00a2\u0006\u0004\u0008\u0012\u0010\u0013R\u0017\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0017\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\r0\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0015R\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0017\u0010\u0018R\u0011\u0010\u0010\u001a\u00020\u000f\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0019\u0010\u0018R\u0011\u0010\u0011\u001a\u00020\u000f\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001a\u0010\u0018R\u001a\u0010\u001b\u001a\u00020\u001cX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001d\u0010\u001e\"\u0004\u0008\u001f\u0010 \u00a8\u0006!"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "parts",
        "",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "startCf",
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "grab",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "center",
        "half",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLjava/util/List;Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V",
        "getParts",
        "()Ljava/util/List;",
        "getStartCf",
        "getGrab",
        "()Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "getCenter",
        "getHalf",
        "active",
        "",
        "getActive",
        "()Z",
        "setActive",
        "(Z)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private active:Z

.field private final center:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private final grab:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private final half:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private final parts:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation
.end field

.field private final startCf:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/CFrame;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFFLjava/util/List;Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V
    .registers 11
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "parts"    # Ljava/util/List;
    .param p6, "startCf"    # Ljava/util/List;
    .param p7, "grab"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p8, "center"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p9, "half"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF",
            "Ljava/util/List<",
            "+",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/CFrame;",
            ">;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            ")V"
        }
    .end annotation

    const-string v0, "parts"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "startCf"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "grab"

    invoke-static {p7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "center"

    invoke-static {p8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "half"

    invoke-static {p9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 126
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    .line 127
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    .line 126
    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->parts:Ljava/util/List;

    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->startCf:Ljava/util/List;

    .line 127
    iput-object p7, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->grab:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iput-object p8, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->center:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iput-object p9, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->half:Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 126
    return-void
.end method


# virtual methods
.method public final getActive()Z
    .registers 2

    .line 127
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->active:Z

    return v0
.end method

.method public final getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 127
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->center:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public final getGrab()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 127
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->grab:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public final getHalf()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 127
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->half:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public final getParts()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 126
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->parts:Ljava/util/List;

    return-object v0
.end method

.method public final getStartCf()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/CFrame;",
            ">;"
        }
    .end annotation

    .line 126
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->startCf:Ljava/util/List;

    return-object v0
.end method

.method public final setActive(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 127
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PartDrag;->active:Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.PluginPtr (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$PluginPtr)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "PluginPtr"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0004\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\u001f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u000cX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\r\u0010\u000e\"\u0004\u0008\u000f\u0010\u0010\u00a8\u0006\u0011"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V",
        "moved",
        "",
        "getMoved",
        "()Z",
        "setMoved",
        "(Z)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private moved:Z

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V
    .registers 5
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)V"
        }
    .end annotation

    .line 131
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    return-void
.end method


# virtual methods
.method public final getMoved()Z
    .registers 2

    .line 131
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;->moved:Z

    return v0
.end method

.method public final setMoved(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 131
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginPtr;->moved:Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.PluginWheel (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$PluginWheel)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "PluginWheel"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\t\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\u001f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000c\u0010\r\"\u0004\u0008\u000e\u0010\u000f\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V",
        "acc",
        "getAcc",
        "()F",
        "setAcc",
        "(F)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private acc:F

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V
    .registers 5
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)V"
        }
    .end annotation

    .line 117
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    return-void
.end method


# virtual methods
.method public final getAcc()F
    .registers 2

    .line 117
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->acc:F

    return v0
.end method

.method public final setAcc(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 117
    iput p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$PluginWheel;->acc:F

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.Ptr (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$Ptr)
.class abstract Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.super Ljava/lang/Object;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x402
    name = "Ptr"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u000c\n\u0002\u0010\t\n\u0002\u0008\u0007\u0008\u00a2\u0004\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0007\u0010\u0008R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000b\u0010\u000c\"\u0004\u0008\r\u0010\u000eR\u001a\u0010\u0006\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000f\u0010\u000c\"\u0004\u0008\u0010\u0010\u000eR\u0011\u0010\u0011\u001a\u00020\u0012\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u000cR\u0011\u0010\u0017\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0018\u0010\u000c\u00a8\u0006\u0019"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "",
        "id",
        "",
        "x",
        "",
        "y",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V",
        "getId",
        "()I",
        "getX",
        "()F",
        "setX",
        "(F)V",
        "getY",
        "setY",
        "t0",
        "",
        "getT0",
        "()J",
        "x0",
        "getX0",
        "y0",
        "getY0",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final id:I

.field private final t0:J

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

.field private x:F

.field private final x0:F

.field private y:F

.field private final y0:F


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V
    .registers 7
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)V"
        }
    .end annotation

    .line 108
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->id:I

    iput p3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->x:F

    iput p4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->y:F

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->t0:J

    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->x:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->x0:F

    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->y:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->y0:F

    return-void
.end method


# virtual methods
.method public final getId()I
    .registers 2

    .line 108
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->id:I

    return v0
.end method

.method public final getT0()J
    .registers 3

    .line 108
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->t0:J

    return-wide v0
.end method

.method public final getX()F
    .registers 2

    .line 108
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->x:F

    return v0
.end method

.method public final getX0()F
    .registers 2

    .line 108
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->x0:F

    return v0
.end method

.method public final getY()F
    .registers 2

    .line 108
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->y:F

    return v0
.end method

.method public final getY0()F
    .registers 2

    .line 108
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->y0:F

    return v0
.end method

.method public final setX(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 108
    iput p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->x:F

    return-void
.end method

.method public final setY(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 108
    iput p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;->y:F

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.Sink (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$Sink)
.class final Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Sink;
.super Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Sink"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0004\u0008\u0082\u0004\u0018\u00002\n0\u0001R\u00060\u0002R\u00020\u0003B\u001f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\t\u0010\n\u00a8\u0006\u000b"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Sink;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;",
        "Lcom/exampletest/mobilestudiotest/ui/ViewportView;",
        "id",
        "",
        "x",
        "",
        "y",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V
    .registers 5
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
    .param p2, "id"    # I
    .param p3, "x"    # F
    .param p4, "y"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)V"
        }
    .end annotation

    .line 115
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Sink;->this$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Ptr;-><init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;IFF)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView.TouchLayer.WhenMappings (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$WhenMappings)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$WhenMappings;
.super Ljava/lang/Object;
.source "ViewportView.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1019
    name = "WhenMappings"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    invoke-static {}, Lcom/exampletest/mobilestudiotest/core/Tool;->values()[Lcom/exampletest/mobilestudiotest/core/Tool;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_7
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Tool;->MOVE:Lcom/exampletest/mobilestudiotest/core/Tool;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Tool;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_10} :catch_11

    goto :goto_12

    :catch_11
    move-exception v1

    :goto_12
    :try_start_12
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Tool;->SCALE:Lcom/exampletest/mobilestudiotest/core/Tool;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Tool;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_1b} :catch_1c

    goto :goto_1d

    :catch_1c
    move-exception v1

    :goto_1d
    :try_start_1d
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Tool;->ROTATE:Lcom/exampletest/mobilestudiotest/core/Tool;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Tool;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_26
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1d .. :try_end_26} :catch_27

    goto :goto_28

    :catch_27
    move-exception v1

    :goto_28
    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$WhenMappings;->$EnumSwitchMapping$0:[I

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "tryStartPartDrag$lambda$80$lambda$75"
    proto = "(Lcom/exampletest/mobilestudiotest/model/Instance;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tryStartPartDrag$lambda$80$lambda$75(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "down$lambda$27"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;ILcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

.field public final synthetic f$1:I

.field public final synthetic f$2:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

.field public final synthetic f$3:Lcom/exampletest/mobilestudiotest/ui/ViewportView;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;ILcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;->f$1:I

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;->f$2:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;->f$3:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;->f$1:I

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;->f$2:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda1;->f$3:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->down$lambda$27(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;ILcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$Cam;Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "pressButton$lambda$36"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pressButton$lambda$36(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "pressButton$lambda$37"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pressButton$lambda$37(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "pressButton$lambda$38"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pressButton$lambda$38(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "pressButton$lambda$39"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pressButton$lambda$39(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "pressButton$lambda$36$lambda$35"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->pressButton$lambda$36$lambda$35(Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "updatePartDrag$lambda$85$lambda$83"
    proto = "(Ljava/util/Set;Lcom/exampletest/mobilestudiotest/model/Instance;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/util/Set;


# direct methods
.method public synthetic constructor <init>(Ljava/util/Set;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda7;->f$0:Ljava/util/Set;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda7;->f$0:Ljava/util/Set;

    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->updatePartDrag$lambda$85$lambda$83(Ljava/util/Set;Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda8 (com.exampletest.mobilestudiotest.ui.ViewportView$TouchLayer$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;"
    method = "tap$lambda$56$lambda$54"
    proto = "(Lcom/exampletest/mobilestudiotest/model/Instance;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/ViewportView$TouchLayer;->tap$lambda$56$lambda$54(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.ViewportView$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView;"
    method = "_init_$lambda$1"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->_init_$lambda$1(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.ViewportView$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView;"
    method = "_init_$lambda$2"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView;Lcom/exampletest/mobilestudiotest/model/Instance;FFLandroid/graphics/Bitmap;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    check-cast p2, Ljava/lang/Float;

    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    move-result p2

    check-cast p3, Ljava/lang/Float;

    invoke-virtual {p3}, Ljava/lang/Float;->floatValue()F

    move-result p3

    check-cast p4, Landroid/graphics/Bitmap;

    invoke-static {v0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->_init_$lambda$2(Lcom/exampletest/mobilestudiotest/ui/ViewportView;Lcom/exampletest/mobilestudiotest/model/Instance;FFLandroid/graphics/Bitmap;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.ViewportView$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.ViewportView$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/ViewportView;"
    method = "lambda$1$lambda$0"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/ViewportView$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/ViewportView;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/ViewportView;->lambda$1$lambda$0(Lcom/exampletest/mobilestudiotest/ui/ViewportView;)V

    return-void
.end method
