###### Class com.exampletest.mobilestudiotest.ui.PlayHud (com.exampletest.mobilestudiotest.ui.PlayHud)
.class public final Lcom/exampletest/mobilestudiotest/ui/PlayHud;
.super Landroid/widget/FrameLayout;
.source "PlayHud.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;,
        Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;,
        Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPlayHud.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlayHud.kt\ncom/exampletest/mobilestudiotest/ui/PlayHud\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,512:1\n1#2:513\n1878#3,3:514\n1878#3,3:517\n*S KotlinDebug\n*F\n+ 1 PlayHud.kt\ncom/exampletest/mobilestudiotest/ui/PlayHud\n*L\n386#1:514,3\n379#1:517,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0082\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u000e\u0008\u0007\u0018\u00002\u00020\u0001:\u0003DEFB\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\tH\u0002J\u0008\u0010$\u001a\u00020%H\u0002J\u0008\u0010&\u001a\u00020%H\u0002J\u0006\u0010\'\u001a\u00020%J\u0008\u0010(\u001a\u00020%H\u0002J\u0006\u0010)\u001a\u00020%J\u0006\u0010*\u001a\u00020%J\u0006\u0010+\u001a\u00020%J\u0006\u0010,\u001a\u00020\u001fJ\u0006\u0010-\u001a\u00020%J\u0008\u0010.\u001a\u00020%H\u0002J,\u0010/\u001a\u0002002\u0006\u00101\u001a\u0002022\u0006\u00103\u001a\u00020\t2\u0008\u0008\u0002\u00104\u001a\u00020\u000b2\u0008\u0008\u0002\u00105\u001a\u00020\u001fH\u0002J&\u00106\u001a\u0002002\u0006\u00101\u001a\u0002022\u0006\u00107\u001a\u00020\u001f2\u000c\u00108\u001a\u0008\u0012\u0004\u0012\u00020%09H\u0002J\u0008\u0010:\u001a\u00020%H\u0002J6\u0010;\u001a\u00020%2\u0006\u0010<\u001a\u00020\u00012\u0006\u0010=\u001a\u0002022\u0006\u0010>\u001a\u0002022\u0006\u0010?\u001a\u0002022\u000c\u0010@\u001a\u0008\u0012\u0004\u0012\u00020%09H\u0002J\u0008\u0010A\u001a\u00020\u001dH\u0002J\u0008\u0010B\u001a\u00020\u001dH\u0002J\u0008\u0010C\u001a\u00020\u001dH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0010\u001a\u00060\u0011R\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0012\u001a\u00060\u0013R\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0014\u001a\u00060\u0013R\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0015\u001a\u00060\u0013R\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0018\u001a\u00060\u0019R\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u001dX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006G"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PlayHud;",
        "Landroid/widget/FrameLayout;",
        "ctx",
        "Landroid/content/Context;",
        "studio",
        "Lcom/exampletest/mobilestudiotest/core/Studio;",
        "<init>",
        "(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V",
        "d",
        "",
        "dp",
        "",
        "v",
        "bold",
        "Landroid/graphics/Typeface;",
        "regular",
        "layer",
        "Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;",
        "menuBtn",
        "Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;",
        "chatBtn",
        "listBtn",
        "chatBox",
        "Landroid/widget/LinearLayout;",
        "chatLog",
        "Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;",
        "chatBar",
        "Landroid/widget/EditText;",
        "menu",
        "Landroid/view/View;",
        "chatOpen",
        "",
        "playerListOpen",
        "lastChatActivity",
        "",
        "seenChat",
        "send",
        "",
        "hideKeyboard",
        "onPlayStateChanged",
        "updateChatVisibility",
        "onFrame",
        "togglePlayerList",
        "focusChat",
        "handleBack",
        "toggleMenu",
        "closeMenu",
        "label",
        "Landroid/widget/TextView;",
        "s",
        "",
        "size",
        "color",
        "b",
        "pill",
        "primary",
        "onClick",
        "Lkotlin/Function0;",
        "openMenu",
        "confirmPage",
        "root",
        "title",
        "msg",
        "ok",
        "onOk",
        "peoplePage",
        "settingsPage",
        "helpPage",
        "TopButton",
        "ChatLog",
        "Layer",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final bold:Landroid/graphics/Typeface;

.field private final chatBar:Landroid/widget/EditText;

.field private final chatBox:Landroid/widget/LinearLayout;

.field private final chatBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

.field private final chatLog:Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;

.field private chatOpen:Z

.field private final d:F

.field private lastChatActivity:J

.field private final layer:Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;

.field private final listBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

.field private menu:Landroid/view/View;

.field private final menuBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

.field private playerListOpen:Z

.field private final regular:Landroid/graphics/Typeface;

.field private seenChat:I

.field private final studio:Lcom/exampletest/mobilestudiotest/core/Studio;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Studio;)V
    .registers 16
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "studio"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    .line 43
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->d:F

    .line 45
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

    const-string v1, "BuilderSans"

    const/16 v2, 0x2bc

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily(Ljava/lang/String;IZ)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->bold:Landroid/graphics/Typeface;

    .line 46
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Fonts;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Fonts;

    const/16 v2, 0x190

    invoke-virtual {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/Fonts;->forFamily(Ljava/lang/String;IZ)Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/Fonts$Face;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->regular:Landroid/graphics/Typeface;

    .line 48
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;

    invoke-direct {v0, p0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->layer:Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;

    .line 49
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    invoke-direct {v0, p0, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;I)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->menuBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    .line 50
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    const/4 v1, 0x1

    invoke-direct {v0, p0, p1, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;I)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    .line 51
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;I)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->listBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    .line 52
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    .line 53
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;

    invoke-direct {v0, p0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatLog:Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;

    .line 56
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatOpen:Z

    .line 57
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->playerListOpen:Z

    .line 59
    const/4 v0, -0x1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->seenChat:I

    .line 61
    nop

    .line 62
    const/16 v2, 0x8

    invoke-virtual {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->setVisibility(I)V

    .line 63
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->layer:Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v4, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v2, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 64
    const/high16 v2, 0x41000000    # 8.0f

    invoke-direct {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v4

    .line 65
    .local v4, "top":I
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->menuBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    check-cast v5, Landroid/view/View;

    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    const/high16 v7, 0x42200000    # 40.0f

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v9

    invoke-direct {v6, v8, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 513
    move-object v8, v6

    .local v8, "$this$_init__u24lambda_u240\\1":Landroid/widget/FrameLayout$LayoutParams;
    const/4 v9, 0x0

    .line 65
    .local v9, "$i$a$-apply-PlayHud$1\\1\\65\\0":I
    const/high16 v10, 0x41400000    # 12.0f

    invoke-direct {p0, v10}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v11

    iput v11, v8, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iput v4, v8, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .end local v8    # "$this$_init__u24lambda_u240\\1":Landroid/widget/FrameLayout$LayoutParams;
    .end local v9    # "$i$a$-apply-PlayHud$1\\1\\65\\0":I
    sget-object v8, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 66
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    check-cast v5, Landroid/view/View;

    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v9

    invoke-direct {v6, v8, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 513
    move-object v8, v6

    .local v8, "$this$_init__u24lambda_u241\\2":Landroid/widget/FrameLayout$LayoutParams;
    const/4 v9, 0x0

    .line 66
    .local v9, "$i$a$-apply-PlayHud$2\\2\\66\\0":I
    const/high16 v11, 0x42700000    # 60.0f

    invoke-direct {p0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v11

    iput v11, v8, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iput v4, v8, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .end local v8    # "$this$_init__u24lambda_u241\\2":Landroid/widget/FrameLayout$LayoutParams;
    .end local v9    # "$i$a$-apply-PlayHud$2\\2\\66\\0":I
    sget-object v8, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 67
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->listBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    check-cast v5, Landroid/view/View;

    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v7

    const v9, 0x800005

    invoke-direct {v6, v8, v7, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 513
    move-object v7, v6

    .local v7, "$this$_init__u24lambda_u242\\3":Landroid/widget/FrameLayout$LayoutParams;
    const/4 v8, 0x0

    .line 67
    .local v8, "$i$a$-apply-PlayHud$3\\3\\67\\0":I
    invoke-direct {p0, v10}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v9

    iput v9, v7, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    iput v4, v7, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .end local v7    # "$this$_init__u24lambda_u242\\3":Landroid/widget/FrameLayout$LayoutParams;
    .end local v8    # "$i$a$-apply-PlayHud$3\\3\\67\\0":I
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v5, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 68
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->menuBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda4;

    invoke-direct {v6, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 69
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda5;

    invoke-direct {v6, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda5;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 70
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->listBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda6;

    invoke-direct {v6, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 72
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    invoke-virtual {v5, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 73
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 513
    move-object v7, v6

    .local v7, "$this$_init__u24lambda_u246\\4":Landroid/graphics/drawable/GradientDrawable;
    const/4 v8, 0x0

    .line 73
    .local v8, "$i$a$-apply-PlayHud$7\\4\\73\\0":I
    const/high16 v9, 0x4d000000    # 1.3421773E8f

    invoke-virtual {v7, v9}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-direct {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v7, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v7    # "$this$_init__u24lambda_u246\\4":Landroid/graphics/drawable/GradientDrawable;
    .end local v8    # "$i$a$-apply-PlayHud$7\\4\\73\\0":I
    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 74
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    const/high16 v5, 0x40c00000    # 6.0f

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v7

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v9

    invoke-virtual {v2, v6, v7, v8, v9}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 75
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatLog:Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;

    check-cast v6, Landroid/view/View;

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v7, v0, v3, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v7, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 76
    new-instance v2, Landroid/widget/EditText;

    invoke-direct {v2, p1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v6, v2

    .local v6, "$this$_init__u24lambda_u2410\\5":Landroid/widget/EditText;
    const/4 v7, 0x0

    .line 77
    .local v7, "$i$a$-apply-PlayHud$8\\5\\76\\0":I
    const-string v8, "Tap here to chat"

    check-cast v8, Ljava/lang/CharSequence;

    invoke-virtual {v6, v8}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 78
    const v8, -0x4c000001

    invoke-virtual {v6, v8}, Landroid/widget/EditText;->setHintTextColor(I)V

    invoke-virtual {v6, v0}, Landroid/widget/EditText;->setTextColor(I)V

    .line 79
    const/high16 v8, 0x41600000    # 14.0f

    invoke-virtual {v6, v8}, Landroid/widget/EditText;->setTextSize(F)V

    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->regular:Landroid/graphics/Typeface;

    invoke-virtual {v6, v8}, Landroid/widget/EditText;->setTypeface(Landroid/graphics/Typeface;)V

    .line 80
    invoke-virtual {v6, v1}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 81
    const v8, 0x10000004

    invoke-virtual {v6, v8}, Landroid/widget/EditText;->setImeOptions(I)V

    .line 82
    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 513
    move-object v9, v8

    .local v9, "$this$lambda_u2410_u24lambda_u247\\6":Landroid/graphics/drawable/GradientDrawable;
    const/4 v11, 0x0

    .line 82
    .local v11, "$i$a$-apply-PlayHud$8$1\\6\\82\\5":I
    const/high16 v12, 0x66000000

    invoke-virtual {v9, v12}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v9, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v9    # "$this$lambda_u2410_u24lambda_u247\\6":Landroid/graphics/drawable/GradientDrawable;
    .end local v11    # "$i$a$-apply-PlayHud$8$1\\6\\82\\5":I
    check-cast v8, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v6, v8}, Landroid/widget/EditText;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 83
    const/high16 v5, 0x41200000    # 10.0f

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    const/high16 v9, 0x40e00000    # 7.0f

    invoke-direct {p0, v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v11

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    invoke-direct {p0, v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v9

    invoke-virtual {v6, v8, v11, v5, v9}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 84
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda7;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda7;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    invoke-virtual {v6, v5}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    .line 87
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda8;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda8;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    invoke-virtual {v6, v5}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 88
    nop

    .line 76
    .end local v6    # "$this$_init__u24lambda_u2410\\5":Landroid/widget/EditText;
    .end local v7    # "$i$a$-apply-PlayHud$8\\5\\76\\0":I
    iput-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    .line 89
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    check-cast v5, Landroid/view/View;

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x2

    invoke-direct {v6, v0, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 513
    move-object v0, v6

    .local v0, "$this$_init__u24lambda_u2411\\7":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v7, 0x0

    .line 89
    .local v7, "$i$a$-apply-PlayHud$9\\7\\89\\0":I
    const/high16 v8, 0x40800000    # 4.0f

    invoke-direct {p0, v8}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    iput v8, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .end local v0    # "$this$_init__u24lambda_u2411\\7":Landroid/widget/LinearLayout$LayoutParams;
    .end local v7    # "$i$a$-apply-PlayHud$9\\7\\89\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 90
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->smallestScreenWidthDp:I

    const/16 v2, 0x258

    if-ge v0, v2, :cond_1f6

    move v3, v1

    .line 91
    .local v3, "phone":Z
    :cond_1f6
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    check-cast v0, Landroid/view/View;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    if-eqz v3, :cond_201

    const/high16 v2, 0x43870000    # 270.0f

    goto :goto_203

    :cond_201
    const/high16 v2, 0x43a50000    # 330.0f

    :goto_203
    invoke-direct {p0, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v2

    if-eqz v3, :cond_20c

    const/high16 v5, 0x43020000    # 130.0f

    goto :goto_20e

    :cond_20c
    const/high16 v5, 0x43250000    # 165.0f

    :goto_20e
    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    invoke-direct {v1, v2, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 513
    move-object v2, v1

    .local v2, "$this$_init__u24lambda_u2412\\8":Landroid/widget/FrameLayout$LayoutParams;
    const/4 v5, 0x0

    .line 91
    .local v5, "$i$a$-apply-PlayHud$10\\8\\91\\0":I
    invoke-direct {p0, v10}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    iput v6, v2, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    const/high16 v6, 0x42600000    # 56.0f

    invoke-direct {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    iput v6, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .end local v2    # "$this$_init__u24lambda_u2412\\8":Landroid/widget/FrameLayout$LayoutParams;
    .end local v5    # "$i$a$-apply-PlayHud$10\\8\\91\\0":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 92
    .end local v3    # "phone":Z
    .end local v4    # "top":I
    nop

    .line 42
    return-void
.end method

.method static final _init_$lambda$3(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "it"    # Landroid/view/View;

    .line 68
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->toggleMenu()V

    return-void
.end method

.method static final _init_$lambda$4(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "it"    # Landroid/view/View;

    .line 69
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatOpen:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatOpen:Z

    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatOpen:Z

    if-nez v0, :cond_d

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->hideKeyboard()V

    :cond_d
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->updateChatVisibility()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->lastChatActivity:J

    return-void
.end method

.method static final _init_$lambda$5(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "it"    # Landroid/view/View;

    .line 70
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->togglePlayerList()V

    return-void
.end method

.method public static final synthetic access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I
    .registers 3
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "v"    # F

    .line 41
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v0

    return v0
.end method

.method public static final synthetic access$getBold$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Landroid/graphics/Typeface;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 41
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->bold:Landroid/graphics/Typeface;

    return-object v0
.end method

.method public static final synthetic access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 41
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->d:F

    return v0
.end method

.method public static final synthetic access$getPlayerListOpen$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Z
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 41
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->playerListOpen:Z

    return v0
.end method

.method public static final synthetic access$getRegular$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Landroid/graphics/Typeface;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 41
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->regular:Landroid/graphics/Typeface;

    return-object v0
.end method

.method public static final synthetic access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lcom/exampletest/mobilestudiotest/core/Studio;
    .registers 2
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 41
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    return-object v0
.end method

.method private final closeMenu()V
    .registers 3

    .line 356
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->menu:Landroid/view/View;

    if-eqz v0, :cond_8

    .line 513
    .local v0, "it\\1":Landroid/view/View;
    const/4 v1, 0x0

    .line 356
    .local v1, "$i$a$-let-PlayHud$closeMenu$1\\1\\356\\0":I
    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->removeView(Landroid/view/View;)V

    .end local v0    # "it\\1":Landroid/view/View;
    .end local v1    # "$i$a$-let-PlayHud$closeMenu$1\\1\\356\\0":I
    :cond_8
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->menu:Landroid/view/View;

    return-void
.end method

.method private final confirmPage(Landroid/widget/FrameLayout;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .registers 22
    .param p1, "root"    # Landroid/widget/FrameLayout;
    .param p2, "title"    # Ljava/lang/String;
    .param p3, "msg"    # Ljava/lang/String;
    .param p4, "ok"    # Ljava/lang/String;
    .param p5, "onOk"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/FrameLayout;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 410
    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p4

    new-instance v1, Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 513
    .local v2, "$this$confirmPage_u24lambda_u2439\\1":Landroid/widget/FrameLayout;
    const/4 v3, 0x0

    .line 410
    .local v3, "$i$a$-apply-PlayHud$confirmPage$shade$1\\1\\410\\0":I
    const/high16 v4, -0x34000000    # -3.3554432E7f

    invoke-virtual {v2, v4}, Landroid/widget/FrameLayout;->setBackgroundColor(I)V

    const/4 v9, 0x1

    invoke-virtual {v2, v9}, Landroid/widget/FrameLayout;->setClickable(Z)V

    .end local v2    # "$this$confirmPage_u24lambda_u2439\\1":Landroid/widget/FrameLayout;
    .end local v3    # "$i$a$-apply-PlayHud$confirmPage$shade$1\\1\\410\\0":I
    move-object v10, v1

    .line 411
    .local v10, "shade":Landroid/widget/FrameLayout;
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .local v2, "$this$confirmPage_u24lambda_u2441\\2":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 412
    .local v3, "$i$a$-apply-PlayHud$confirmPage$box$1\\2\\411\\0":I
    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual {v2, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 413
    const/high16 v4, 0x41c00000    # 24.0f

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    const/high16 v6, 0x41a00000    # 20.0f

    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v11

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v4

    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    invoke-virtual {v2, v5, v11, v4, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 414
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 513
    move-object v5, v4

    .local v5, "$this$confirmPage_u24lambda_u2441_u24lambda_u2440\\3":Landroid/graphics/drawable/GradientDrawable;
    const/4 v6, 0x0

    .line 414
    .local v6, "$i$a$-apply-PlayHud$confirmPage$box$1$1\\3\\414\\2":I
    const v11, -0xdcdad9

    invoke-virtual {v5, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v11, 0x41400000    # 12.0f

    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v11

    int-to-float v11, v11

    invoke-virtual {v5, v11}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v5    # "$this$confirmPage_u24lambda_u2441_u24lambda_u2440\\3":Landroid/graphics/drawable/GradientDrawable;
    .end local v6    # "$i$a$-apply-PlayHud$confirmPage$box$1$1\\3\\414\\2":I
    check-cast v4, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 415
    nop

    .line 411
    .end local v2    # "$this$confirmPage_u24lambda_u2441\\2":Landroid/widget/LinearLayout;
    .end local v3    # "$i$a$-apply-PlayHud$confirmPage$box$1\\2\\411\\0":I
    move-object v11, v1

    .line 416
    .local v11, "box":Landroid/widget/LinearLayout;
    const/4 v5, 0x4

    const/4 v6, 0x0

    const/high16 v2, 0x41a00000    # 20.0f

    const/4 v3, 0x0

    const/4 v4, 0x1

    move-object/from16 v1, p2

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v2

    .line 513
    move-object v0, v2

    .local v0, "$this$confirmPage_u24lambda_u2442\\4":Landroid/widget/TextView;
    const/4 v1, 0x0

    .line 416
    .local v1, "$i$a$-apply-PlayHud$confirmPage$1\\4\\416\\0":I
    const/16 v12, 0x11

    invoke-virtual {v0, v12}, Landroid/widget/TextView;->setGravity(I)V

    .end local v0    # "$this$confirmPage_u24lambda_u2442\\4":Landroid/widget/TextView;
    .end local v1    # "$i$a$-apply-PlayHud$confirmPage$1\\4\\416\\0":I
    check-cast v2, Landroid/view/View;

    invoke-virtual {v11, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 417
    const/16 v5, 0x8

    const/high16 v2, 0x41700000    # 15.0f

    const v3, -0x2f2f30

    const/4 v4, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v2

    .line 513
    move-object v1, v2

    .local v1, "$this$confirmPage_u24lambda_u2443\\5":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 417
    .local v3, "$i$a$-apply-PlayHud$confirmPage$2\\5\\417\\0":I
    invoke-virtual {v1, v12}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v4, 0x41200000    # 10.0f

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v4

    const/high16 v5, 0x41800000    # 16.0f

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    const/4 v6, 0x0

    invoke-virtual {v1, v6, v4, v6, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .end local v1    # "$this$confirmPage_u24lambda_u2443\\5":Landroid/widget/TextView;
    .end local v3    # "$i$a$-apply-PlayHud$confirmPage$2\\5\\417\\0":I
    check-cast v2, Landroid/view/View;

    invoke-virtual {v11, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 418
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 513
    .local v2, "$this$confirmPage_u24lambda_u2444\\6":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 418
    .local v3, "$i$a$-apply-PlayHud$confirmPage$row$1\\6\\418\\0":I
    invoke-virtual {v2, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 419
    .end local v2    # "$this$confirmPage_u24lambda_u2444\\6":Landroid/widget/LinearLayout;
    .end local v3    # "$i$a$-apply-PlayHud$confirmPage$row$1\\6\\418\\0":I
    .local v1, "row":Landroid/widget/LinearLayout;
    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;

    move-object/from16 v3, p5

    invoke-direct {v2, v7, v10, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;-><init>(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;Lkotlin/jvm/functions/Function0;)V

    invoke-direct {v0, v8, v9, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->pill(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)Landroid/widget/TextView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v4, v6, v5, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 513
    move-object v13, v4

    .local v13, "$this$confirmPage_u24lambda_u2446\\7":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v14, 0x0

    .line 419
    .local v14, "$i$a$-apply-PlayHud$confirmPage$4\\7\\419\\0":I
    const/high16 v15, 0x41000000    # 8.0f

    invoke-direct {v0, v15}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v15

    iput v15, v13, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v13    # "$this$confirmPage_u24lambda_u2446\\7":Landroid/widget/LinearLayout$LayoutParams;
    .end local v14    # "$i$a$-apply-PlayHud$confirmPage$4\\7\\419\\0":I
    sget-object v13, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 420
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Don\'t "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda17;

    invoke-direct {v4, v7, v10}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda17;-><init>(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;)V

    invoke-direct {v0, v2, v6, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->pill(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)Landroid/widget/TextView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v6, v5, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 421
    move-object v2, v1

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    invoke-direct {v4, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v11, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 422
    move-object v2, v11

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/high16 v9, 0x43d20000    # 420.0f

    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v9

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getWidth()I

    move-result v13

    int-to-float v13, v13

    const v14, 0x3f666666    # 0.9f

    mul-float/2addr v13, v14

    float-to-int v13, v13

    invoke-static {v9, v13}, Ljava/lang/Math;->min(II)I

    move-result v9

    invoke-direct {v4, v9, v5, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v10, v2, v4}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 423
    move-object v2, v10

    check-cast v2, Landroid/view/View;

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v4, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v4, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v7, v2, v4}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 424
    return-void
.end method

.method static final confirmPage$lambda$45(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;
    .registers 4
    .param p0, "$root"    # Landroid/widget/FrameLayout;
    .param p1, "$shade"    # Landroid/widget/FrameLayout;
    .param p2, "$onOk"    # Lkotlin/jvm/functions/Function0;

    .line 419
    move-object v0, p1

    check-cast v0, Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->removeView(Landroid/view/View;)V

    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final confirmPage$lambda$47(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;)Lkotlin/Unit;
    .registers 3
    .param p0, "$root"    # Landroid/widget/FrameLayout;
    .param p1, "$shade"    # Landroid/widget/FrameLayout;

    .line 420
    move-object v0, p1

    check-cast v0, Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->removeView(Landroid/view/View;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final dp(F)I
    .registers 3
    .param p1, "v"    # F

    .line 44
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->d:F

    mul-float/2addr v0, p1

    float-to-int v0, v0

    return v0
.end method

.method private final helpPage()Landroid/view/View;
    .registers 16

    .line 495
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .line 513
    .local v1, "$this$helpPage_u24lambda_u2476\\1":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 495
    .local v2, "$i$a$-apply-PlayHud$helpPage$box$1\\1\\495\\0":I
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v4, 0x40c00000    # 6.0f

    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    const/high16 v6, 0x40800000    # 4.0f

    invoke-direct {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v7

    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    invoke-direct {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    invoke-virtual {v1, v5, v7, v8, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 497
    .end local v1    # "$this$helpPage_u24lambda_u2476\\1":Landroid/widget/LinearLayout;
    .end local v2    # "$i$a$-apply-PlayHud$helpPage$box$1\\1\\495\\0":I
    .local v0, "box":Landroid/widget/LinearLayout;
    const/16 v1, 0x8

    new-array v1, v1, [Lkotlin/Pair;

    const-string v2, "Move"

    const-string v5, "Drag the thumbstick (bottom left). Keyboard: WASD or arrow keys"

    invoke-static {v2, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v5, 0x0

    aput-object v2, v1, v5

    .line 498
    const-string v2, "Look around"

    const-string v6, "Drag anywhere else on the screen. Keyboard: \u2190 \u2192 to turn"

    invoke-static {v2, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v1, v3

    .line 497
    nop

    .line 499
    const-string v2, "Zoom"

    const-string v3, "Pinch with two fingers. Keyboard: I / O"

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x2

    aput-object v2, v1, v3

    .line 497
    nop

    .line 500
    const-string v2, "Jump"

    const-string v3, "Jump button (bottom right). Keyboard: Space"

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x3

    aput-object v2, v1, v3

    .line 497
    nop

    .line 501
    const-string v2, "Shift lock"

    const-string v3, "Lock button above jump. Keyboard: Shift"

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x4

    aput-object v2, v1, v3

    .line 497
    nop

    .line 502
    const-string v2, "Chat"

    const-string v3, "Chat button (top left). Keyboard: /"

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x5

    aput-object v2, v1, v3

    .line 497
    nop

    .line 503
    const-string v2, "Tools"

    const-string v3, "Tap a slot at the bottom. Keyboard: 1\u20139"

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x6

    aput-object v2, v1, v3

    .line 497
    nop

    .line 504
    const-string v2, "Menu"

    const-string v3, "Roblox button (top left). Keyboard: Esc"

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x7

    aput-object v2, v1, v3

    .line 497
    nop

    .line 496
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_90
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_d7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lkotlin/Pair;

    invoke-virtual {v2}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v3

    move-object v7, v3

    check-cast v7, Ljava/lang/String;

    .local v7, "k":Ljava/lang/String;
    invoke-virtual {v2}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 506
    .local v2, "v":Ljava/lang/String;
    const/4 v11, 0x4

    const/4 v12, 0x0

    const/high16 v8, 0x41700000    # 15.0f

    const/4 v9, 0x0

    const/4 v10, 0x1

    move-object v6, p0

    invoke-static/range {v6 .. v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v3

    .line 513
    move-object v6, v3

    .local v6, "$this$helpPage_u24lambda_u2477\\2":Landroid/widget/TextView;
    const/4 v8, 0x0

    .line 506
    .local v8, "$i$a$-apply-PlayHud$helpPage$1\\2\\506\\0":I
    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v9

    invoke-virtual {v6, v5, v9, v5, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .end local v6    # "$this$helpPage_u24lambda_u2477\\2":Landroid/widget/TextView;
    .end local v8    # "$i$a$-apply-PlayHud$helpPage$1\\2\\506\\0":I
    check-cast v3, Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 507
    const/16 v13, 0x8

    const/4 v14, 0x0

    const/high16 v10, 0x41500000    # 13.0f

    const v11, -0x4c000001

    const/4 v12, 0x0

    move-object v8, p0

    move-object v9, v2

    .end local v2    # "v":Ljava/lang/String;
    .local v9, "v":Ljava/lang/String;
    invoke-static/range {v8 .. v14}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .end local v7    # "k":Ljava/lang/String;
    .end local v9    # "v":Ljava/lang/String;
    goto :goto_90

    .line 509
    :cond_d7
    new-instance v1, Landroid/widget/ScrollView;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 513
    .local v2, "$this$helpPage_u24lambda_u2478\\3":Landroid/widget/ScrollView;
    const/4 v3, 0x0

    .line 509
    .local v3, "$i$a$-apply-PlayHud$helpPage$2\\3\\509\\0":I
    move-object v4, v0

    check-cast v4, Landroid/view/View;

    invoke-virtual {v2, v4}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .end local v2    # "$this$helpPage_u24lambda_u2478\\3":Landroid/widget/ScrollView;
    .end local v3    # "$i$a$-apply-PlayHud$helpPage$2\\3\\509\\0":I
    check-cast v1, Landroid/view/View;

    return-object v1
.end method

.method private final hideKeyboard()V
    .registers 4

    .line 104
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "input_method"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getWindowToken()Landroid/os/IBinder;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z

    .line 105
    return-void
.end method

.method private final label(Ljava/lang/String;FIZ)Landroid/widget/TextView;
    .registers 9
    .param p1, "s"    # Ljava/lang/String;
    .param p2, "size"    # F
    .param p3, "color"    # I
    .param p4, "b"    # Z

    .line 358
    new-instance v0, Landroid/widget/TextView;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$label_u24lambda_u2415\\1":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 359
    .local v2, "$i$a$-apply-PlayHud$label$1\\1\\358\\0":I
    move-object v3, p1

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v1, p3}, Landroid/widget/TextView;->setTextColor(I)V

    if-eqz p4, :cond_1c

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->bold:Landroid/graphics/Typeface;

    goto :goto_1e

    :cond_1c
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->regular:Landroid/graphics/Typeface;

    :goto_1e
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 360
    nop

    .line 358
    .end local v1    # "$this$label_u24lambda_u2415\\1":Landroid/widget/TextView;
    .end local v2    # "$i$a$-apply-PlayHud$label$1\\1\\358\\0":I
    nop

    .line 360
    return-object v0
.end method

.method static synthetic label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;
    .registers 7

    .line 358
    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_5

    const/4 p3, -0x1

    :cond_5
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_a

    const/4 p4, 0x0

    :cond_a
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label(Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p0

    return-object p0
.end method

.method static final lambda$10$lambda$8(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .registers 7
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p2, "id"    # I
    .param p3, "ev"    # Landroid/view/KeyEvent;

    .line 85
    const/4 p1, 0x4

    const/4 v0, 0x1

    if-eq p2, p1, :cond_1f

    const/4 p1, 0x6

    if-eq p2, p1, :cond_1f

    const/4 p1, 0x0

    if-eqz p3, :cond_14

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v1

    const/16 v2, 0x42

    if-ne v1, v2, :cond_14

    move v1, v0

    goto :goto_15

    :cond_14
    move v1, p1

    :goto_15
    if-eqz v1, :cond_1d

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v1

    if-eqz v1, :cond_1f

    :cond_1d
    move v0, p1

    goto :goto_22

    :cond_1f
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->send()V

    :goto_22
    return v0
.end method

.method static final lambda$10$lambda$9(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;Z)V
    .registers 5
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p2, "f"    # Z

    .line 87
    if-eqz p2, :cond_8

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->lastChatActivity:J

    :cond_8
    return-void
.end method

.method private final openMenu()V
    .registers 23

    .line 371
    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->hideKeyboard()V

    .line 372
    new-instance v1, Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 513
    .local v2, "$this$openMenu_u24lambda_u2419\\1":Landroid/widget/FrameLayout;
    const/4 v3, 0x0

    .line 372
    .local v3, "$i$a$-apply-PlayHud$openMenu$root$1\\1\\372\\0":I
    const/high16 v4, -0x4d000000

    invoke-virtual {v2, v4}, Landroid/widget/FrameLayout;->setBackgroundColor(I)V

    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Landroid/widget/FrameLayout;->setClickable(Z)V

    .line 373
    .end local v2    # "$this$openMenu_u24lambda_u2419\\1":Landroid/widget/FrameLayout;
    .end local v3    # "$i$a$-apply-PlayHud$openMenu$root$1\\1\\372\\0":I
    .local v1, "root":Landroid/widget/FrameLayout;
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .line 513
    .local v3, "$this$openMenu_u24lambda_u2420\\2":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 373
    .local v5, "$i$a$-apply-PlayHud$openMenu$panel$1\\2\\373\\0":I
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v6, 0x41a00000    # 20.0f

    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v7

    const/high16 v8, 0x41600000    # 14.0f

    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    const/high16 v9, 0x41800000    # 16.0f

    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v9

    invoke-virtual {v3, v7, v8, v6, v9}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 374
    .end local v3    # "$this$openMenu_u24lambda_u2420\\2":Landroid/widget/LinearLayout;
    .end local v5    # "$i$a$-apply-PlayHud$openMenu$panel$1\\2\\373\\0":I
    .local v2, "panel":Landroid/widget/LinearLayout;
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v3, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v3

    .line 513
    .local v5, "$this$openMenu_u24lambda_u2421\\3":Landroid/widget/LinearLayout;
    const/4 v6, 0x0

    .line 374
    .local v6, "$i$a$-apply-PlayHud$openMenu$tabs$1\\3\\374\\0":I
    const/4 v7, 0x0

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v8, 0x11

    invoke-virtual {v5, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 375
    .end local v5    # "$this$openMenu_u24lambda_u2421\\3":Landroid/widget/LinearLayout;
    .end local v6    # "$i$a$-apply-PlayHud$openMenu$tabs$1\\3\\374\\0":I
    .local v3, "tabs":Landroid/widget/LinearLayout;
    new-instance v5, Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 376
    .local v5, "content":Landroid/widget/FrameLayout;
    const/4 v6, 0x3

    new-array v6, v6, [Ljava/lang/String;

    const-string v9, "People"

    aput-object v9, v6, v7

    const-string v9, "Settings"

    aput-object v9, v6, v4

    const/4 v9, 0x2

    const-string v10, "Help"

    aput-object v10, v6, v9

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 377
    .local v6, "tabNames":Ljava/util/List;
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 386
    .local v9, "tabViews":Ljava/util/ArrayList;
    move-object v10, v6

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$forEachIndexed\\4":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 514
    .local v11, "$i$f$forEachIndexed\\4\\386":I
    const/4 v12, 0x0

    .line 515
    .local v12, "index\\4":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_7f
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    const/4 v15, -0x1

    if-eqz v14, :cond_d9

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "item\\4":Ljava/lang/Object;
    add-int/lit8 v16, v12, 0x1

    .end local v12    # "index\\4":I
    .local v16, "index\\4":I
    if-gez v12, :cond_91

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_91
    move-object v8, v14

    check-cast v8, Ljava/lang/String;

    .local v8, "n\\5":Ljava/lang/String;
    .local v12, "i\\5":I
    const/16 v17, 0x0

    .line 387
    .local v17, "$i$a$-forEachIndexed-PlayHud$openMenu$1\\5\\515\\0":I
    const/high16 v7, 0x41700000    # 15.0f

    invoke-direct {v0, v8, v7, v15, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label(Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v7

    move-object v15, v7

    .line 513
    .local v15, "$this$openMenu_u24lambda_u2426_u24lambda_u2425\\6":Landroid/widget/TextView;
    const/16 v18, 0x0

    .line 387
    .local v18, "$i$a$-apply-PlayHud$openMenu$1$t$1\\6\\387\\5":I
    const/high16 v4, 0x41900000    # 18.0f

    move-object/from16 v19, v6

    .end local v6    # "tabNames":Ljava/util/List;
    .local v19, "tabNames":Ljava/util/List;
    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    move-object/from16 v20, v7

    const/high16 v7, 0x41100000    # 9.0f

    move-object/from16 v21, v8

    .end local v8    # "n\\5":Ljava/lang/String;
    .local v21, "n\\5":Ljava/lang/String;
    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v4

    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v7

    invoke-virtual {v15, v6, v8, v4, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    new-instance v4, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;

    invoke-direct {v4, v12, v9, v5, v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;-><init>(ILjava/util/ArrayList;Landroid/widget/FrameLayout;Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    invoke-virtual {v15, v4}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .end local v15    # "$this$openMenu_u24lambda_u2426_u24lambda_u2425\\6":Landroid/widget/TextView;
    .end local v18    # "$i$a$-apply-PlayHud$openMenu$1$t$1\\6\\387\\5":I
    move-object/from16 v4, v20

    .line 388
    .local v4, "t\\5":Landroid/widget/TextView;
    invoke-virtual {v9, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v6, v4

    check-cast v6, Landroid/view/View;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 389
    nop

    .line 515
    .end local v4    # "t\\5":Landroid/widget/TextView;
    .end local v12    # "i\\5":I
    .end local v17    # "$i$a$-forEachIndexed-PlayHud$openMenu$1\\5\\515\\0":I
    .end local v21    # "n\\5":Ljava/lang/String;
    move/from16 v12, v16

    move-object/from16 v6, v19

    const/4 v4, 0x1

    const/4 v7, 0x0

    const/16 v8, 0x11

    .end local v14    # "item\\4":Ljava/lang/Object;
    goto :goto_7f

    .line 516
    .end local v16    # "index\\4":I
    .end local v19    # "tabNames":Ljava/util/List;
    .restart local v6    # "tabNames":Ljava/util/List;
    .local v12, "index\\4":I
    :cond_d9
    move-object/from16 v19, v6

    .line 390
    .end local v6    # "tabNames":Ljava/util/List;
    .end local v10    # "$this$forEachIndexed\\4":Ljava/lang/Iterable;
    .end local v11    # "$i$f$forEachIndexed\\4\\386":I
    .end local v12    # "index\\4":I
    .restart local v19    # "tabNames":Ljava/util/List;
    move-object v4, v3

    check-cast v4, Landroid/view/View;

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x2

    invoke-direct {v6, v15, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 391
    new-instance v4, Landroid/view/View;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v4, v6}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 513
    move-object v6, v4

    .local v6, "$this$openMenu_u24lambda_u2427\\7":Landroid/view/View;
    const/4 v8, 0x0

    .line 391
    .local v8, "$i$a$-apply-PlayHud$openMenu$2\\7\\391\\0":I
    const v10, 0x33ffffff

    invoke-virtual {v6, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .end local v6    # "$this$openMenu_u24lambda_u2427\\7":Landroid/view/View;
    .end local v8    # "$i$a$-apply-PlayHud$openMenu$2\\7\\391\\0":I
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v10

    invoke-direct {v6, v15, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 513
    move-object v10, v6

    .local v10, "$this$openMenu_u24lambda_u2428\\8":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v11, 0x0

    .line 391
    .local v11, "$i$a$-apply-PlayHud$openMenu$3\\8\\391\\0":I
    const/high16 v12, 0x41000000    # 8.0f

    invoke-direct {v0, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v13

    iput v13, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-direct {v0, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v13

    iput v13, v10, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .end local v10    # "$this$openMenu_u24lambda_u2428\\8":Landroid/widget/LinearLayout$LayoutParams;
    .end local v11    # "$i$a$-apply-PlayHud$openMenu$3\\8\\391\\0":I
    sget-object v10, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 392
    move-object v4, v5

    check-cast v4, Landroid/view/View;

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x0

    invoke-direct {v6, v15, v10, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v6, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 393
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v4, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v6, v4

    .line 513
    .local v6, "$this$openMenu_u24lambda_u2429\\9":Landroid/widget/LinearLayout;
    const/4 v11, 0x0

    .line 393
    .local v11, "$i$a$-apply-PlayHud$openMenu$bottom$1\\9\\393\\0":I
    invoke-virtual {v6, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v13, 0x11

    invoke-virtual {v6, v13}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 394
    .end local v6    # "$this$openMenu_u24lambda_u2429\\9":Landroid/widget/LinearLayout;
    .end local v11    # "$i$a$-apply-PlayHud$openMenu$bottom$1\\9\\393\\0":I
    .local v4, "bottom":Landroid/widget/LinearLayout;
    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda1;

    invoke-direct {v6, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)V

    const-string v11, "Reset Character"

    invoke-direct {v0, v11, v10, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->pill(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)Landroid/widget/TextView;

    move-result-object v6

    check-cast v6, Landroid/view/View;

    .line 396
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v11, v10, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 513
    move-object v10, v11

    .local v10, "$this$openMenu_u24lambda_u2433\\10":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 396
    .local v13, "$i$a$-apply-PlayHud$openMenu$5\\10\\396\\0":I
    invoke-direct {v0, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v14

    iput v14, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v10    # "$this$openMenu_u24lambda_u2433\\10":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13    # "$i$a$-apply-PlayHud$openMenu$5\\10\\396\\0":I
    sget-object v10, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v11, Landroid/view/ViewGroup$LayoutParams;

    .line 394
    invoke-virtual {v4, v6, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 397
    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda2;

    invoke-direct {v6, v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)V

    const-string v10, "Leave"

    const/4 v11, 0x0

    invoke-direct {v0, v10, v11, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->pill(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)Landroid/widget/TextView;

    move-result-object v6

    check-cast v6, Landroid/view/View;

    .line 399
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v10, v11, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 513
    move-object v11, v10

    .local v11, "$this$openMenu_u24lambda_u2436\\11":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v13, 0x0

    .line 399
    .local v13, "$i$a$-apply-PlayHud$openMenu$7\\11\\399\\0":I
    invoke-direct {v0, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v12

    iput v12, v11, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v11    # "$this$openMenu_u24lambda_u2436\\11":Landroid/widget/LinearLayout$LayoutParams;
    .end local v13    # "$i$a$-apply-PlayHud$openMenu$7\\11\\399\\0":I
    sget-object v11, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v10, Landroid/view/ViewGroup$LayoutParams;

    .line 397
    invoke-virtual {v4, v6, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 400
    new-instance v6, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda3;

    invoke-direct {v6, v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda3;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    const-string v10, "Resume"

    const/4 v11, 0x1

    invoke-direct {v0, v10, v11, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->pill(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)Landroid/widget/TextView;

    move-result-object v6

    check-cast v6, Landroid/view/View;

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, 0x0

    invoke-direct {v10, v11, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v10, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v4, v6, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 401
    move-object v6, v4

    check-cast v6, Landroid/view/View;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v8, v15, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 513
    move-object v7, v8

    .local v7, "$this$openMenu_u24lambda_u2438\\12":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v10, 0x0

    .line 401
    .local v10, "$i$a$-apply-PlayHud$openMenu$9\\12\\401\\0":I
    const/high16 v11, 0x41200000    # 10.0f

    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v11

    iput v11, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .end local v7    # "$this$openMenu_u24lambda_u2438\\12":Landroid/widget/LinearLayout$LayoutParams;
    .end local v10    # "$i$a$-apply-PlayHud$openMenu$9\\12\\401\\0":I
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v2, v6, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 402
    const/high16 v6, 0x440c0000    # 560.0f

    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    .line 403
    .local v6, "maxW":I
    move-object v7, v2

    check-cast v7, Landroid/view/View;

    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getWidth()I

    move-result v10

    int-to-float v10, v10

    const v11, 0x3f70a3d7    # 0.94f

    mul-float/2addr v10, v11

    float-to-int v10, v10

    const/high16 v11, 0x438c0000    # 280.0f

    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v11

    invoke-static {v10, v11}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v10

    invoke-static {v6, v10}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getHeight()I

    move-result v11

    int-to-float v11, v11

    const v12, 0x3f666666    # 0.9f

    mul-float/2addr v11, v12

    float-to-int v11, v11

    const/16 v13, 0x11

    invoke-direct {v8, v10, v11, v13}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v7, v8}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 404
    move-object v7, v1

    check-cast v7, Landroid/view/View;

    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v8, v15, v15}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    check-cast v8, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, v7, v8}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 405
    move-object v7, v1

    check-cast v7, Landroid/view/View;

    iput-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->menu:Landroid/view/View;

    .line 406
    const/4 v11, 0x0

    invoke-static {v9, v5, v0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu$select(Ljava/util/ArrayList;Landroid/widget/FrameLayout;Lcom/exampletest/mobilestudiotest/ui/PlayHud;I)V

    .line 407
    return-void
.end method

.method static final openMenu$lambda$26$lambda$25$lambda$24(ILjava/util/ArrayList;Landroid/widget/FrameLayout;Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V
    .registers 5
    .param p0, "$i"    # I
    .param p1, "$tabViews"    # Ljava/util/ArrayList;
    .param p2, "$content"    # Landroid/widget/FrameLayout;
    .param p3, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p4, "it"    # Landroid/view/View;

    .line 387
    invoke-static {p1, p2, p3, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu$select(Ljava/util/ArrayList;Landroid/widget/FrameLayout;Lcom/exampletest/mobilestudiotest/ui/PlayHud;I)V

    return-void
.end method

.method static final openMenu$lambda$32(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)Lkotlin/Unit;
    .registers 8
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "$root"    # Landroid/widget/FrameLayout;

    .line 394
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda21;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda21;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    const-string v2, "Reset Character?"

    const-string v3, "Are you sure you want to reset your character?"

    const-string v4, "Reset"

    move-object v0, p0

    move-object v1, p1

    .end local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .end local p1    # "$root":Landroid/widget/FrameLayout;
    .local v0, "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .local v1, "$root":Landroid/widget/FrameLayout;
    invoke-direct/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->confirmPage(Landroid/widget/FrameLayout;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 396
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final openMenu$lambda$32$lambda$31(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 395
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 513
    const/4 v1, 0x0

    .line 395
    .local v1, "$i$a$-synchronized-PlayHud$openMenu$4$1$1\\1\\395\\0":I
    :try_start_8
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v2

    if-eqz v2, :cond_15

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->resetCharacter()V

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_15
    .catchall {:try_start_8 .. :try_end_15} :catchall_1c

    .end local v1    # "$i$a$-synchronized-PlayHud$openMenu$4$1$1\\1\\395\\0":I
    :cond_15
    monitor-exit v0

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->closeMenu()V

    .line 396
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 395
    :catchall_1c
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method static final openMenu$lambda$35(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)Lkotlin/Unit;
    .registers 8
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "$root"    # Landroid/widget/FrameLayout;

    .line 397
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda20;

    invoke-direct {v5, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda20;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    const-string v2, "Leave Experience?"

    const-string v3, "Are you sure you want to leave the experience?"

    const-string v4, "Leave"

    move-object v0, p0

    move-object v1, p1

    .end local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .end local p1    # "$root":Landroid/widget/FrameLayout;
    .local v0, "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .local v1, "$root":Landroid/widget/FrameLayout;
    invoke-direct/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->confirmPage(Landroid/widget/FrameLayout;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 399
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method static final openMenu$lambda$35$lambda$34(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 398
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->closeMenu()V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->stopPlay()V

    .line 399
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final openMenu$lambda$37(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;
    .registers 2
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 400
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->closeMenu()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final openMenu$select(Ljava/util/ArrayList;Landroid/widget/FrameLayout;Lcom/exampletest/mobilestudiotest/ui/PlayHud;I)V
    .registers 16
    .param p0, "tabViews"    # Ljava/util/ArrayList;
    .param p1, "content"    # Landroid/widget/FrameLayout;
    .param p2, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p3, "i"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Landroid/widget/TextView;",
            ">;",
            "Landroid/widget/FrameLayout;",
            "Lcom/exampletest/mobilestudiotest/ui/PlayHud;",
            "I)V"
        }
    .end annotation

    .line 379
    move-object v0, p0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 517
    .local v1, "$i$f$forEachIndexed\\1\\379":I
    const/4 v2, 0x0

    .line 518
    .local v2, "index\\1":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_9
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4b

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "item\\1":Ljava/lang/Object;
    add-int/lit8 v5, v2, 0x1

    .end local v2    # "index\\1":I
    .local v5, "index\\1":I
    if-gez v2, :cond_1a

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_1a
    move-object v6, v4

    check-cast v6, Landroid/widget/TextView;

    .local v2, "j\\2":I
    .local v6, "t\\2":Landroid/widget/TextView;
    const/4 v7, 0x0

    .line 380
    .local v7, "$i$a$-forEachIndexed-PlayHud$openMenu$select$1\\2\\518\\0":I
    if-ne p3, v2, :cond_22

    const/4 v8, -0x1

    goto :goto_25

    :cond_22
    const v8, -0x66000001

    :goto_25
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 381
    if-ne p3, v2, :cond_44

    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 513
    move-object v9, v8

    .local v9, "$this$openMenu_u24select_u24lambda_u2423_u24lambda_u2422\\3":Landroid/graphics/drawable/GradientDrawable;
    const/4 v10, 0x0

    .line 381
    .local v10, "$i$a$-apply-PlayHud$openMenu$select$1$1\\3\\381\\2":I
    const v11, 0x26ffffff

    invoke-virtual {v9, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v11, 0x41000000    # 8.0f

    invoke-direct {p2, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v11

    int-to-float v11, v11

    invoke-virtual {v9, v11}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v9    # "$this$openMenu_u24select_u24lambda_u2423_u24lambda_u2422\\3":Landroid/graphics/drawable/GradientDrawable;
    .end local v10    # "$i$a$-apply-PlayHud$openMenu$select$1$1\\3\\381\\2":I
    check-cast v8, Landroid/graphics/drawable/Drawable;

    goto :goto_45

    :cond_44
    const/4 v8, 0x0

    :goto_45
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 382
    nop

    .line 518
    .end local v2    # "j\\2":I
    .end local v6    # "t\\2":Landroid/widget/TextView;
    .end local v7    # "$i$a$-forEachIndexed-PlayHud$openMenu$select$1\\2\\518\\0":I
    move v2, v5

    .end local v4    # "item\\1":Ljava/lang/Object;
    goto :goto_9

    .line 519
    .end local v5    # "index\\1":I
    .local v2, "index\\1":I
    :cond_4b
    nop

    .line 383
    .end local v0    # "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$forEachIndexed\\1\\379":I
    .end local v2    # "index\\1":I
    invoke-virtual {p1}, Landroid/widget/FrameLayout;->removeAllViews()V

    .line 384
    packed-switch p3, :pswitch_data_64

    invoke-direct {p2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->helpPage()Landroid/view/View;

    move-result-object v0

    goto :goto_60

    :pswitch_57
    invoke-direct {p2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage()Landroid/view/View;

    move-result-object v0

    goto :goto_60

    :pswitch_5c
    invoke-direct {p2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->peoplePage()Landroid/view/View;

    move-result-object v0

    :goto_60
    invoke-virtual {p1, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 385
    return-void

    :pswitch_data_64
    .packed-switch 0x0
        :pswitch_5c
        :pswitch_57
    .end packed-switch
.end method

.method private final peoplePage()Landroid/view/View;
    .registers 17

    .line 427
    move-object/from16 v0, p0

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 513
    .local v2, "$this$peoplePage_u24lambda_u2448\\1":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 427
    .local v3, "$i$a$-apply-PlayHud$peoplePage$list$1\\1\\427\\0":I
    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .end local v2    # "$this$peoplePage_u24lambda_u2448\\1":Landroid/widget/LinearLayout;
    .end local v3    # "$i$a$-apply-PlayHud$peoplePage$list$1\\1\\427\\0":I
    move-object v7, v1

    .line 428
    .local v7, "list":Landroid/widget/LinearLayout;
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v8

    .line 429
    .local v8, "p":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    const/4 v1, 0x0

    if-eqz v8, :cond_20

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getPlayer()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    goto :goto_21

    :cond_20
    move-object v2, v1

    :goto_21
    move-object v9, v2

    .line 430
    .local v9, "pl":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v10, 0x0

    const/high16 v11, 0x41400000    # 12.0f

    if-eqz v9, :cond_132

    .line 431
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .local v3, "$this$peoplePage_u24lambda_u2450\\2":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 432
    .local v5, "$i$a$-apply-PlayHud$peoplePage$row$1\\2\\431\\0":I
    invoke-virtual {v3, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v6, 0x10

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 433
    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    const/high16 v12, 0x41200000    # 10.0f

    invoke-direct {v0, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v13

    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v14

    invoke-direct {v0, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v12

    invoke-virtual {v3, v6, v13, v14, v12}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 434
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 513
    move-object v12, v6

    .local v12, "$this$peoplePage_u24lambda_u2450_u24lambda_u2449\\3":Landroid/graphics/drawable/GradientDrawable;
    const/4 v13, 0x0

    .line 434
    .local v13, "$i$a$-apply-PlayHud$peoplePage$row$1$1\\3\\434\\2":I
    const v14, 0x1affffff

    invoke-virtual {v12, v14}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v14, 0x41000000    # 8.0f

    invoke-direct {v0, v14}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v14

    int-to-float v14, v14

    invoke-virtual {v12, v14}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v12    # "$this$peoplePage_u24lambda_u2450_u24lambda_u2449\\3":Landroid/graphics/drawable/GradientDrawable;
    .end local v13    # "$i$a$-apply-PlayHud$peoplePage$row$1$1\\3\\434\\2":I
    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 435
    nop

    .line 431
    .end local v3    # "$this$peoplePage_u24lambda_u2450\\2":Landroid/widget/LinearLayout;
    .end local v5    # "$i$a$-apply-PlayHud$peoplePage$row$1\\2\\431\\0":I
    move-object v12, v2

    .line 436
    .local v12, "row":Landroid/widget/LinearLayout;
    new-instance v2, Landroid/view/View;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 513
    move-object v3, v2

    .local v3, "$this$peoplePage_u24lambda_u2452\\4":Landroid/view/View;
    const/4 v5, 0x0

    .line 436
    .local v5, "$i$a$-apply-PlayHud$peoplePage$1\\4\\436\\0":I
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 513
    move-object v13, v6

    .local v13, "$this$peoplePage_u24lambda_u2452_u24lambda_u2451\\5":Landroid/graphics/drawable/GradientDrawable;
    const/4 v14, 0x0

    .line 436
    .local v14, "$i$a$-apply-PlayHud$peoplePage$1$1\\5\\436\\4":I
    invoke-virtual {v13, v4}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v8, v15}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->nameColor(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v13, v15}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .end local v13    # "$this$peoplePage_u24lambda_u2452_u24lambda_u2451\\5":Landroid/graphics/drawable/GradientDrawable;
    .end local v14    # "$i$a$-apply-PlayHud$peoplePage$1$1\\5\\436\\4":I
    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .end local v3    # "$this$peoplePage_u24lambda_u2452\\4":Landroid/view/View;
    .end local v5    # "$i$a$-apply-PlayHud$peoplePage$1\\4\\436\\0":I
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x42100000    # 36.0f

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    invoke-direct {v3, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 513
    move-object v5, v3

    .local v5, "$this$peoplePage_u24lambda_u2453\\6":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v6, 0x0

    .line 436
    .local v6, "$i$a$-apply-PlayHud$peoplePage$2\\6\\436\\0":I
    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v13

    iput v13, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v5    # "$this$peoplePage_u24lambda_u2453\\6":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6    # "$i$a$-apply-PlayHud$peoplePage$2\\6\\436\\0":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v12, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 437
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v2

    .line 513
    .local v3, "$this$peoplePage_u24lambda_u2454\\7":Landroid/widget/LinearLayout;
    const/4 v5, 0x0

    .line 437
    .local v5, "$i$a$-apply-PlayHud$peoplePage$names$1\\7\\437\\0":I
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .end local v3    # "$this$peoplePage_u24lambda_u2454\\7":Landroid/widget/LinearLayout;
    .end local v5    # "$i$a$-apply-PlayHud$peoplePage$names$1\\7\\437\\0":I
    move-object v13, v2

    .line 438
    .local v13, "names":Landroid/widget/LinearLayout;
    const-string v2, "DisplayName"

    invoke-virtual {v9, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v3, v2, Ljava/lang/String;

    if-eqz v3, :cond_cc

    move-object v1, v2

    check-cast v1, Ljava/lang/String;

    :cond_cc
    if-eqz v1, :cond_e3

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-eqz v2, :cond_d7

    move v4, v10

    :cond_d7
    if-eqz v4, :cond_de

    .line 513
    const/4 v1, 0x0

    .line 438
    .local v1, "$i$a$-ifEmpty-PlayHud$peoplePage$3\\8\\438\\0":I
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v1

    .end local v1    # "$i$a$-ifEmpty-PlayHud$peoplePage$3\\8\\438\\0":I
    :cond_de
    check-cast v1, Ljava/lang/String;

    if-eqz v1, :cond_e3

    goto :goto_e7

    :cond_e3
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v1

    :goto_e7
    const/4 v5, 0x4

    const/4 v6, 0x0

    const/high16 v2, 0x41800000    # 16.0f

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 439
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "@"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "  \u00b7  You"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/16 v5, 0x8

    const/high16 v2, 0x41500000    # 13.0f

    const v3, -0x4c000001

    const/4 v4, 0x0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 440
    move-object v0, v13

    check-cast v0, Landroid/view/View;

    invoke-virtual {v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 441
    move-object v0, v12

    check-cast v0, Landroid/view/View;

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 443
    .end local v12    # "row":Landroid/widget/LinearLayout;
    .end local v13    # "names":Landroid/widget/LinearLayout;
    :cond_132
    const/16 v5, 0x8

    const/4 v6, 0x0

    const-string v1, "Playtest in Mobile Studio: only you are in this server."

    const/high16 v2, 0x41500000    # 13.0f

    const v3, -0x66000001

    const/4 v4, 0x0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v1

    .line 513
    move-object v2, v1

    .local v2, "$this$peoplePage_u24lambda_u2456\\9":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 443
    .local v3, "$i$a$-apply-PlayHud$peoplePage$4\\9\\443\\0":I
    const/high16 v4, 0x40800000    # 4.0f

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    invoke-direct {v0, v11}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v4

    invoke-virtual {v2, v5, v6, v4, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .end local v2    # "$this$peoplePage_u24lambda_u2456\\9":Landroid/widget/TextView;
    .end local v3    # "$i$a$-apply-PlayHud$peoplePage$4\\9\\443\\0":I
    check-cast v1, Landroid/view/View;

    invoke-virtual {v7, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 444
    new-instance v1, Landroid/widget/ScrollView;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 513
    .local v2, "$this$peoplePage_u24lambda_u2457\\10":Landroid/widget/ScrollView;
    const/4 v3, 0x0

    .line 444
    .local v3, "$i$a$-apply-PlayHud$peoplePage$5\\10\\444\\0":I
    move-object v4, v7

    check-cast v4, Landroid/view/View;

    invoke-virtual {v2, v4}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .end local v2    # "$this$peoplePage_u24lambda_u2457\\10":Landroid/widget/ScrollView;
    .end local v3    # "$i$a$-apply-PlayHud$peoplePage$5\\10\\444\\0":I
    check-cast v1, Landroid/view/View;

    return-object v1
.end method

.method private final pill(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;)Landroid/widget/TextView;
    .registers 13
    .param p1, "s"    # Ljava/lang/String;
    .param p2, "primary"    # Z
    .param p3, "onClick"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/widget/TextView;"
        }
    .end annotation

    .line 362
    const/4 v0, -0x1

    if-eqz p2, :cond_6

    const/high16 v1, -0x1000000

    goto :goto_7

    :cond_6
    move v1, v0

    :goto_7
    const/high16 v2, 0x41700000    # 15.0f

    const/4 v3, 0x1

    invoke-direct {p0, p1, v2, v1, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label(Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    move-object v2, v1

    .local v2, "$this$pill_u24lambda_u2418\\1":Landroid/widget/TextView;
    const/4 v4, 0x0

    .line 363
    .local v4, "$i$a$-apply-PlayHud$pill$1\\1\\362\\0":I
    const/16 v5, 0x11

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 364
    const/high16 v5, 0x41900000    # 18.0f

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    const/high16 v7, 0x41300000    # 11.0f

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v8

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v7

    invoke-virtual {v2, v6, v8, v5, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 365
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 513
    move-object v6, v5

    .local v6, "$this$pill_u24lambda_u2418_u24lambda_u2416\\2":Landroid/graphics/drawable/GradientDrawable;
    const/4 v7, 0x0

    .line 365
    .local v7, "$i$a$-apply-PlayHud$pill$1$1\\2\\365\\1":I
    if-nez p2, :cond_38

    const v0, 0x33ffffff

    :cond_38
    invoke-virtual {v6, v0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v0, 0x41000000    # 8.0f

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v6, v0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v6    # "$this$pill_u24lambda_u2418_u24lambda_u2416\\2":Landroid/graphics/drawable/GradientDrawable;
    .end local v7    # "$i$a$-apply-PlayHud$pill$1$1\\2\\365\\1":I
    check-cast v5, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 366
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setClickable(Z)V

    .line 367
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda19;

    invoke-direct {v0, p3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda19;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 368
    nop

    .line 362
    .end local v2    # "$this$pill_u24lambda_u2418\\1":Landroid/widget/TextView;
    .end local v4    # "$i$a$-apply-PlayHud$pill$1\\1\\362\\0":I
    nop

    .line 368
    return-object v1
.end method

.method static final pill$lambda$18$lambda$17(Lkotlin/jvm/functions/Function0;Landroid/view/View;)V
    .registers 2
    .param p0, "$onClick"    # Lkotlin/jvm/functions/Function0;
    .param p1, "it"    # Landroid/view/View;

    .line 367
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private final send()V
    .registers 5

    .line 95
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 96
    .local v0, "text":Ljava/lang/String;
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    const-string v2, ""

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 97
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_36

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v1

    monitor-enter v1

    .line 513
    const/4 v2, 0x0

    .line 97
    .local v2, "$i$a$-synchronized-PlayHud$send$1\\1\\97\\0":I
    :try_start_24
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v3

    if-eqz v3, :cond_31

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->sendChat(Ljava/lang/String;)V

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_31
    .catchall {:try_start_24 .. :try_end_31} :catchall_33

    .end local v2    # "$i$a$-synchronized-PlayHud$send$1\\1\\97\\0":I
    :cond_31
    monitor-exit v1

    goto :goto_36

    :catchall_33
    move-exception v2

    monitor-exit v1

    throw v2

    .line 98
    :cond_36
    :goto_36
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->hideKeyboard()V

    .line 99
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->clearFocus()V

    .line 100
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    iput-wide v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->lastChatActivity:J

    .line 101
    return-void
.end method

.method private final settingsPage()Landroid/view/View;
    .registers 15

    .line 448
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 513
    .local v2, "$this$settingsPage_u24lambda_u2458\\1":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 448
    .local v3, "$i$a$-apply-PlayHud$settingsPage$box$1\\1\\448\\0":I
    const/4 v7, 0x1

    invoke-virtual {v2, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .end local v2    # "$this$settingsPage_u24lambda_u2458\\1":Landroid/widget/LinearLayout;
    .end local v3    # "$i$a$-apply-PlayHud$settingsPage$box$1\\1\\448\\0":I
    move-object v8, v1

    .line 477
    .local v8, "box":Landroid/widget/LinearLayout;
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v1

    const/4 v9, 0x0

    if-eqz v1, :cond_21

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getShiftLockAllowed()Z

    move-result v1

    if-nez v1, :cond_21

    move v1, v7

    goto :goto_22

    :cond_21
    move v1, v9

    :goto_22
    if-eqz v1, :cond_2e

    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->getShiftLockSwitch()Z

    move-result v1

    if-eqz v1, :cond_2e

    move v1, v9

    goto :goto_2f

    :cond_2e
    move v1, v7

    :goto_2f
    move v10, v1

    .line 478
    .local v10, "allowed":Z
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v1

    const-string v2, "StarterPlayer"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-eqz v1, :cond_4d

    const-string v2, "EnableMouseLockOption"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    goto :goto_4e

    :cond_4d
    move v1, v9

    :goto_4e
    const-string v11, "On"

    const-string v12, "Off"

    const/4 v13, 0x2

    if-nez v1, :cond_73

    .line 479
    new-array v1, v13, [Ljava/lang/String;

    aput-object v12, v1, v9

    aput-object v11, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Settings;->getShiftLockSwitch()Z

    move-result v2

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda9;

    invoke-direct {v3, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda9;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    invoke-static {p0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$selector(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/util/List;ILkotlin/jvm/functions/Function1;)Landroid/view/View;

    move-result-object v1

    const-string v2, "Shift Lock Switch"

    invoke-static {p0, v8, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$row(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/view/View;)V

    .line 481
    :cond_73
    if-nez v10, :cond_8a

    const/16 v5, 0x8

    const/4 v6, 0x0

    const-string v1, "This experience turned shift lock off."

    const/high16 v2, 0x41400000    # 12.0f

    const v3, -0x66000001

    const/4 v4, 0x0

    move-object v0, p0

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v8, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 482
    :cond_8a
    new-array v1, v13, [Ljava/lang/String;

    const-string v2, "Classic"

    aput-object v2, v1, v9

    const-string v3, "Follow"

    aput-object v3, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    sget-object v3, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Settings;->getCameraMode()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    xor-int/2addr v2, v7

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda10;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda10;-><init>()V

    invoke-static {p0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$selector(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/util/List;ILkotlin/jvm/functions/Function1;)Landroid/view/View;

    move-result-object v1

    const-string v2, "Camera Mode"

    invoke-static {p0, v8, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$row(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/view/View;)V

    .line 483
    new-array v1, v13, [Ljava/lang/String;

    const-string v2, "Dynamic Thumbstick"

    aput-object v2, v1, v9

    const-string v2, "Thumbstick"

    aput-object v2, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    sget-object v3, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Settings;->getMovementMode()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda11;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda11;-><init>()V

    invoke-static {p0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$selector(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/util/List;ILkotlin/jvm/functions/Function1;)Landroid/view/View;

    move-result-object v1

    const-string v2, "Movement Mode"

    invoke-static {p0, v8, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$row(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/view/View;)V

    .line 484
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->getPlayCameraSensitivity()F

    move-result v1

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda12;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda12;-><init>()V

    const v3, 0x3e4ccccd    # 0.2f

    const/high16 v4, 0x40800000    # 4.0f

    invoke-static {p0, v1, v3, v4, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$slider(Lcom/exampletest/mobilestudiotest/ui/PlayHud;FFFLkotlin/jvm/functions/Function1;)Landroid/view/View;

    move-result-object v1

    const-string v2, "Camera Sensitivity"

    invoke-static {p0, v8, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$row(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/view/View;)V

    .line 485
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->getVolume()I

    move-result v1

    int-to-float v1, v1

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda13;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda13;-><init>()V

    const/4 v3, 0x0

    const/high16 v4, 0x41200000    # 10.0f

    invoke-static {p0, v1, v3, v4, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$slider(Lcom/exampletest/mobilestudiotest/ui/PlayHud;FFFLkotlin/jvm/functions/Function1;)Landroid/view/View;

    move-result-object v1

    const-string v2, "Volume"

    invoke-static {p0, v8, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$row(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/view/View;)V

    .line 486
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->getGraphicsQuality()I

    move-result v1

    int-to-float v1, v1

    new-instance v2, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda14;

    invoke-direct {v2, p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda14;-><init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {p0, v1, v3, v4, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$slider(Lcom/exampletest/mobilestudiotest/ui/PlayHud;FFFLkotlin/jvm/functions/Function1;)Landroid/view/View;

    move-result-object v1

    const-string v2, "Graphics Quality"

    invoke-static {p0, v8, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$row(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/view/View;)V

    .line 490
    new-array v1, v13, [Ljava/lang/String;

    aput-object v12, v1, v9

    aput-object v11, v1, v7

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Settings;->getShowFps()Z

    move-result v2

    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda15;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda15;-><init>()V

    invoke-static {p0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$selector(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/util/List;ILkotlin/jvm/functions/Function1;)Landroid/view/View;

    move-result-object v1

    const-string v2, "Performance Stats"

    invoke-static {p0, v8, v2, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$row(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/view/View;)V

    .line 491
    new-instance v1, Landroid/widget/ScrollView;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v2, v1

    .line 513
    .local v2, "$this$settingsPage_u24lambda_u2475\\2":Landroid/widget/ScrollView;
    const/4 v3, 0x0

    .line 491
    .local v3, "$i$a$-apply-PlayHud$settingsPage$8\\2\\491\\0":I
    move-object v4, v8

    check-cast v4, Landroid/view/View;

    invoke-virtual {v2, v4}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .end local v2    # "$this$settingsPage_u24lambda_u2475\\2":Landroid/widget/ScrollView;
    .end local v3    # "$i$a$-apply-PlayHud$settingsPage$8\\2\\491\\0":I
    check-cast v1, Landroid/view/View;

    return-object v1
.end method

.method static final settingsPage$lambda$68(Lcom/exampletest/mobilestudiotest/ui/PlayHud;I)Lkotlin/Unit;
    .registers 7
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "it"    # I

    .line 479
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    const/4 v1, 0x1

    if-eq p1, v1, :cond_6

    const/4 v1, 0x0

    :cond_6
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->setShiftLockSwitch(Z)V

    if-nez p1, :cond_2c

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v0

    monitor-enter v0

    .line 513
    const/4 v1, 0x0

    .line 479
    .local v1, "$i$a$-synchronized-PlayHud$settingsPage$1$1\\1\\479\\0":I
    :try_start_13
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v2

    if-eqz v2, :cond_25

    .line 513
    .local v2, "p\\2":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    const/4 v3, 0x0

    .line 479
    .local v3, "$i$a$-let-PlayHud$settingsPage$1$1$1\\2\\479\\1":I
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getShiftLock()Z

    move-result v4

    if-eqz v4, :cond_25

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->toggleShiftLock()V

    .end local v1    # "$i$a$-synchronized-PlayHud$settingsPage$1$1\\1\\479\\0":I
    .end local v2    # "p\\2":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v3    # "$i$a$-let-PlayHud$settingsPage$1$1$1\\2\\479\\1":I
    :cond_25
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_27
    .catchall {:try_start_13 .. :try_end_27} :catchall_29

    monitor-exit v0

    goto :goto_2c

    :catchall_29
    move-exception v1

    monitor-exit v0

    throw v1

    :cond_2c
    :goto_2c
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final settingsPage$lambda$69(I)Lkotlin/Unit;
    .registers 3
    .param p0, "it"    # I

    .line 482
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    if-nez p0, :cond_7

    const-string v1, "Classic"

    goto :goto_9

    :cond_7
    const-string v1, "Follow"

    :goto_9
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->setCameraMode(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final settingsPage$lambda$70(I)Lkotlin/Unit;
    .registers 3
    .param p0, "it"    # I

    .line 483
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    const/4 v1, 0x1

    if-ne p0, v1, :cond_8

    const-string v1, "Thumbstick"

    goto :goto_a

    :cond_8
    const-string v1, "Dynamic Thumbstick"

    :goto_a
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->setMovementMode(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final settingsPage$lambda$71(F)Lkotlin/Unit;
    .registers 2
    .param p0, "it"    # F

    .line 484
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v0, p0}, Lcom/exampletest/mobilestudiotest/core/Settings;->setPlayCameraSensitivity(F)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final settingsPage$lambda$72(F)Lkotlin/Unit;
    .registers 3
    .param p0, "it"    # F

    .line 485
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    float-to-int v1, p0

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->setVolume(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final settingsPage$lambda$73(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)Lkotlin/Unit;
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "it"    # F

    .line 487
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    float-to-int v1, p1

    const/16 v2, 0xa

    const/4 v3, 0x1

    invoke-static {v1, v3, v2}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->setGraphicsQuality(I)V

    .line 488
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    sget-object v1, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->getGraphicsQuality()I

    move-result v1

    const/4 v2, 0x4

    if-ge v1, v2, :cond_19

    const/4 v3, 0x0

    :cond_19
    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->setShadowsEnabled(Z)V

    .line 489
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final settingsPage$lambda$74(I)Lkotlin/Unit;
    .registers 3
    .param p0, "it"    # I

    .line 490
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    const/4 v1, 0x1

    if-eq p0, v1, :cond_6

    const/4 v1, 0x0

    :cond_6
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/Settings;->setShowFps(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final settingsPage$row(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/view/View;)V
    .registers 15
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "box"    # Landroid/widget/LinearLayout;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "control"    # Landroid/view/View;

    .line 450
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .line 513
    .local v1, "$this$settingsPage_u24row_u24lambda_u2459\\1":Landroid/widget/LinearLayout;
    const/4 v2, 0x0

    .line 450
    .local v2, "$i$a$-apply-PlayHud$settingsPage$row$r$1\\1\\450\\0":I
    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v4, 0x10

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v4, 0x40c00000    # 6.0f

    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    const/high16 v6, 0x41000000    # 8.0f

    invoke-direct {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v7

    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v4

    invoke-direct {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    invoke-virtual {v1, v5, v7, v4, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 451
    .end local v1    # "$this$settingsPage_u24row_u24lambda_u2459\\1":Landroid/widget/LinearLayout;
    .end local v2    # "$i$a$-apply-PlayHud$settingsPage$row$r$1\\1\\450\\0":I
    .local v0, "r":Landroid/widget/LinearLayout;
    const/16 v9, 0xc

    const/4 v10, 0x0

    const/high16 v6, 0x41700000    # 15.0f

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v4, p0

    move-object v5, p2

    .end local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .end local p2    # "name":Ljava/lang/String;
    .local v4, "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .local v5, "name":Ljava/lang/String;
    invoke-static/range {v4 .. v10}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {p2, v3, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast p2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, p0, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 452
    invoke-virtual {v0, p3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 453
    move-object p0, v0

    check-cast p0, Landroid/view/View;

    invoke-virtual {p1, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 454
    new-instance p0, Landroid/view/View;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 513
    move-object p2, p0

    .local p2, "$this$settingsPage_u24row_u24lambda_u2460\\2":Landroid/view/View;
    const/4 v1, 0x0

    .line 454
    .local v1, "$i$a$-apply-PlayHud$settingsPage$row$1\\2\\454\\0":I
    const v2, 0x1affffff

    invoke-virtual {p2, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .end local v1    # "$i$a$-apply-PlayHud$settingsPage$row$1\\2\\454\\0":I
    .end local p2    # "$this$settingsPage_u24row_u24lambda_u2460\\2":Landroid/view/View;
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, 0x1

    invoke-direct {p2, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast p2, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p1, p0, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 455
    return-void
.end method

.method private static final settingsPage$selector(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/util/List;ILkotlin/jvm/functions/Function1;)Landroid/view/View;
    .registers 14
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "options"    # Ljava/util/List;
    .param p2, "current"    # I
    .param p3, "onSet"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/ui/PlayHud;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;I",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/view/View;"
        }
    .end annotation

    .line 457
    new-instance v0, Lkotlin/jvm/internal/Ref$IntRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$IntRef;-><init>()V

    move-object v2, v0

    .local v2, "idx":Lkotlin/jvm/internal/Ref$IntRef;
    iput p2, v2, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    .line 458
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .line 513
    .local v1, "$this$settingsPage_u24selector_u24lambda_u2461\\1":Landroid/widget/LinearLayout;
    const/4 v3, 0x0

    .line 458
    .local v3, "$i$a$-apply-PlayHud$settingsPage$selector$l$1\\1\\458\\0":I
    const/4 v4, 0x0

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v4, 0x10

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 459
    .end local v1    # "$this$settingsPage_u24selector_u24lambda_u2461\\1":Landroid/widget/LinearLayout;
    .end local v3    # "$i$a$-apply-PlayHud$settingsPage$selector$l$1\\1\\458\\0":I
    .local v0, "l":Landroid/widget/LinearLayout;
    iget v1, v2, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    check-cast v4, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/high16 v5, 0x41600000    # 14.0f

    const/4 v6, 0x0

    const/4 v7, 0x1

    move-object v3, p0

    .end local p0    # "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .local v3, "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    invoke-static/range {v3 .. v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v4

    move-object v1, v3

    .end local v3    # "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .local v1, "this$0":Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    move-object p0, v4

    .line 513
    .local p0, "$this$settingsPage_u24selector_u24lambda_u2462\\2":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 459
    .local v3, "$i$a$-apply-PlayHud$settingsPage$selector$t$1\\2\\459\\0":I
    const/16 v5, 0x11

    invoke-virtual {p0, v5}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v5, 0x43020000    # 130.0f

    invoke-direct {v1, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    invoke-virtual {p0, v5}, Landroid/widget/TextView;->setMinWidth(I)V

    .line 464
    .end local v3    # "$i$a$-apply-PlayHud$settingsPage$selector$t$1\\2\\459\\0":I
    .end local p0    # "$this$settingsPage_u24selector_u24lambda_u2462\\2":Landroid/widget/TextView;
    .local v4, "t":Landroid/widget/TextView;
    const-string v6, "\u2039"

    const/4 v7, -0x1

    move-object v3, p1

    move-object v5, p3

    .end local p1    # "options":Ljava/util/List;
    .end local p3    # "onSet":Lkotlin/jvm/functions/Function1;
    .local v3, "options":Ljava/util/List;
    .local v5, "onSet":Lkotlin/jvm/functions/Function1;
    invoke-static/range {v1 .. v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$selector$arrow(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Lkotlin/jvm/internal/Ref$IntRef;Ljava/util/List;Landroid/widget/TextView;Lkotlin/jvm/functions/Function1;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    move-object p0, v4

    check-cast p0, Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v6, "\u203a"

    const/4 v7, 0x1

    invoke-static/range {v1 .. v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$selector$arrow(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Lkotlin/jvm/internal/Ref$IntRef;Ljava/util/List;Landroid/widget/TextView;Lkotlin/jvm/functions/Function1;Ljava/lang/String;I)Landroid/widget/TextView;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 465
    move-object p0, v0

    check-cast p0, Landroid/view/View;

    return-object p0
.end method

.method private static final settingsPage$selector$arrow(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Lkotlin/jvm/internal/Ref$IntRef;Ljava/util/List;Landroid/widget/TextView;Lkotlin/jvm/functions/Function1;Ljava/lang/String;I)Landroid/widget/TextView;
    .registers 18
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "idx"    # Lkotlin/jvm/internal/Ref$IntRef;
    .param p2, "$options"    # Ljava/util/List;
    .param p3, "t"    # Landroid/widget/TextView;
    .param p4, "$onSet"    # Lkotlin/jvm/functions/Function1;
    .param p5, "s"    # Ljava/lang/String;
    .param p6, "delta"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/ui/PlayHud;",
            "Lkotlin/jvm/internal/Ref$IntRef;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Landroid/widget/TextView;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "I)",
            "Landroid/widget/TextView;"
        }
    .end annotation

    .line 460
    const/4 v5, 0x4

    const/4 v6, 0x0

    const/high16 v2, 0x41900000    # 18.0f

    const/4 v3, 0x0

    const/4 v4, 0x1

    move-object v0, p0

    move-object/from16 v1, p5

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->label$default(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v2

    move-object v1, v2

    .local v1, "$this$settingsPage_u24selector_u24arrow_u24lambda_u2464\\1":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 461
    .local v3, "$i$a$-apply-PlayHud$settingsPage$selector$arrow$1\\1\\460\\0":I
    const/high16 v4, 0x41200000    # 10.0f

    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v5

    const/high16 v6, 0x40000000    # 2.0f

    invoke-direct {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v7

    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v4

    invoke-direct {p0, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v6

    invoke-virtual {v1, v5, v7, v4, v6}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setClickable(Z)V

    .line 462
    new-instance v5, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;

    move-object v6, p1

    move-object v8, p2

    move-object v9, p3

    move-object v10, p4

    move/from16 v7, p6

    invoke-direct/range {v5 .. v10}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;-><init>(Lkotlin/jvm/internal/Ref$IntRef;ILjava/util/List;Landroid/widget/TextView;Lkotlin/jvm/functions/Function1;)V

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 463
    nop

    .line 460
    .end local v1    # "$this$settingsPage_u24selector_u24arrow_u24lambda_u2464\\1":Landroid/widget/TextView;
    .end local v3    # "$i$a$-apply-PlayHud$settingsPage$selector$arrow$1\\1\\460\\0":I
    nop

    .line 463
    return-object v2
.end method

.method static final settingsPage$selector$arrow$lambda$64$lambda$63(Lkotlin/jvm/internal/Ref$IntRef;ILjava/util/List;Landroid/widget/TextView;Lkotlin/jvm/functions/Function1;Landroid/view/View;)V
    .registers 8
    .param p0, "$idx"    # Lkotlin/jvm/internal/Ref$IntRef;
    .param p1, "$delta"    # I
    .param p2, "$options"    # Ljava/util/List;
    .param p3, "$t"    # Landroid/widget/TextView;
    .param p4, "$onSet"    # Lkotlin/jvm/functions/Function1;
    .param p5, "it"    # Landroid/view/View;

    .line 462
    iget v0, p0, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    add-int/2addr v0, p1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->floorMod(II)I

    move-result v0

    iput v0, p0, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    iget v0, p0, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v0, p0, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p4, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private static final settingsPage$slider(Lcom/exampletest/mobilestudiotest/ui/PlayHud;FFFLkotlin/jvm/functions/Function1;)Landroid/view/View;
    .registers 11
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p1, "value"    # F
    .param p2, "min"    # F
    .param p3, "max"    # F
    .param p4, "onSet"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/ui/PlayHud;",
            "FFF",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Float;",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/view/View;"
        }
    .end annotation

    .line 467
    new-instance v0, Landroid/widget/SeekBar;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$settingsPage_u24slider_u24lambda_u2465\\1":Landroid/widget/SeekBar;
    const/4 v2, 0x0

    .line 468
    .local v2, "$i$a$-apply-PlayHud$settingsPage$slider$1\\1\\467\\0":I
    const/16 v3, 0x64

    invoke-virtual {v1, v3}, Landroid/widget/SeekBar;->setMax(I)V

    .line 469
    sub-float v4, p1, p2

    sub-float v5, p3, p2

    div-float/2addr v4, v5

    const/high16 v5, 0x42c80000    # 100.0f

    mul-float/2addr v4, v5

    float-to-int v4, v4

    const/4 v5, 0x0

    invoke-static {v4, v5, v3}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 470
    new-instance v3, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;

    invoke-direct {v3, p4, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;-><init>(Lkotlin/jvm/functions/Function1;FF)V

    check-cast v3, Landroid/widget/SeekBar$OnSeekBarChangeListener;

    invoke-virtual {v1, v3}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 475
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x432a0000    # 170.0f

    invoke-direct {p0, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->dp(F)I

    move-result v4

    const/4 v5, -0x2

    invoke-direct {v3, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v3}, Landroid/widget/SeekBar;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 476
    nop

    .line 467
    .end local v1    # "$this$settingsPage_u24slider_u24lambda_u2465\\1":Landroid/widget/SeekBar;
    .end local v2    # "$i$a$-apply-PlayHud$settingsPage$slider$1\\1\\467\\0":I
    check-cast v0, Landroid/view/View;

    .line 476
    return-object v0
.end method

.method private final updateChatVisibility()V
    .registers 7

    .line 116
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    .line 117
    .local v0, "p":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getCoreChat()Z

    move-result v3

    if-nez v3, :cond_12

    move v3, v1

    goto :goto_13

    :cond_12
    move v3, v2

    :goto_13
    xor-int/2addr v3, v1

    .line 118
    .local v3, "enabled":Z
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    const/16 v4, 0x8

    if-eqz v3, :cond_1c

    move v5, v2

    goto :goto_1d

    :cond_1c
    move v5, v4

    :goto_1d
    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setVisibility(I)V

    .line 119
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    if-eqz v3, :cond_29

    iget-boolean v5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatOpen:Z

    if-eqz v5, :cond_29

    goto :goto_2a

    :cond_29
    move v2, v4

    :goto_2a
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 120
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    iget-boolean v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatOpen:Z

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setActive(Z)V

    .line 121
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->invalidate()V

    .line 122
    return-void
.end method


# virtual methods
.method public final focusChat()V
    .registers 4

    .line 141
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_12

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getCoreChat()Z

    move-result v0

    if-nez v0, :cond_12

    move v0, v1

    goto :goto_13

    :cond_12
    move v0, v2

    :goto_13
    if-eqz v0, :cond_16

    return-void

    .line 142
    :cond_16
    iput-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatOpen:Z

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->updateChatVisibility()V

    .line 143
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->requestFocus()Z

    .line 144
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "input_method"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1, v2}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    .line 145
    return-void
.end method

.method public final handleBack()Z
    .registers 3

    .line 149
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->menu:Landroid/view/View;

    const/4 v1, 0x1

    if-eqz v0, :cond_9

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->closeMenu()V

    return v1

    .line 150
    :cond_9
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->hideKeyboard()V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->clearFocus()V

    return v1

    .line 151
    :cond_1a
    const/4 v0, 0x0

    return v0
.end method

.method public final onFrame()V
    .registers 8

    .line 126
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_7

    return-void

    .line 127
    :cond_7
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-nez v0, :cond_10

    return-void

    .line 128
    .local v0, "p":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :cond_10
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getChatVersion()I

    move-result v1

    .line 129
    .local v1, "v":I
    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->seenChat:I

    if-eq v1, v2, :cond_25

    iput v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->seenChat:I

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iput-wide v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->lastChatActivity:J

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatLog:Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->reload()V

    .line 131
    :cond_25
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-wide v4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->lastChatActivity:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x2ee0

    cmp-long v2, v2, v4

    const/4 v3, 0x0

    if-lez v2, :cond_3d

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->hasFocus()Z

    move-result v2

    if-nez v2, :cond_3d

    const/4 v2, 0x1

    goto :goto_3e

    :cond_3d
    move v2, v3

    .line 132
    .local v2, "idle":Z
    :goto_3e
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBox:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_46

    const v5, 0x3eb33333    # 0.35f

    goto :goto_48

    :cond_46
    const/high16 v5, 0x3f800000    # 1.0f

    :goto_48
    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setAlpha(F)V

    .line 133
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->listBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getCorePlayerList()Z

    move-result v5

    const/16 v6, 0x8

    if-eqz v5, :cond_57

    move v5, v3

    goto :goto_58

    :cond_57
    move v5, v6

    :goto_58
    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setVisibility(I)V

    .line 134
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->getVisibility()I

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getCoreChat()Z

    move-result v5

    if-nez v5, :cond_68

    move v3, v6

    :cond_68
    if-eq v4, v3, :cond_6d

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->updateChatVisibility()V

    .line 135
    :cond_6d
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->layer:Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->invalidate()V

    .line 136
    return-void
.end method

.method public final onPlayStateChanged()V
    .registers 4

    .line 108
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->studio:Lcom/exampletest/mobilestudiotest/core/Studio;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->isPlaying()Z

    move-result v0

    .line 109
    .local v0, "playing":Z
    if-eqz v0, :cond_a

    const/4 v1, 0x0

    goto :goto_c

    :cond_a
    const/16 v1, 0x8

    :goto_c
    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->setVisibility(I)V

    .line 110
    if-nez v0, :cond_21

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->closeMenu()V

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->hideKeyboard()V

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->chatBar:Landroid/widget/EditText;

    const-string v2, ""

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2a

    .line 111
    :cond_21
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    iput-wide v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->lastChatActivity:J

    const/4 v1, -0x1

    iput v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->seenChat:I

    .line 112
    :goto_2a
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->updateChatVisibility()V

    .line 113
    return-void
.end method

.method public final toggleMenu()V
    .registers 2

    .line 354
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->menu:Landroid/view/View;

    if-eqz v0, :cond_8

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->closeMenu()V

    goto :goto_b

    :cond_8
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu()V

    :goto_b
    return-void
.end method

.method public final togglePlayerList()V
    .registers 3

    .line 138
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->playerListOpen:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->playerListOpen:Z

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->listBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    iget-boolean v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->playerListOpen:Z

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setActive(Z)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->listBtn:Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->invalidate()V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->layer:Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->invalidate()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud.ChatLog (com.exampletest.mobilestudiotest.ui.PlayHud$ChatLog)
.class final Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;
.super Landroid/view/View;
.source "PlayHud.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/PlayHud;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "ChatLog"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPlayHud.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlayHud.kt\ncom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,512:1\n1#2:513\n1563#3:514\n1634#3,3:515\n*S KotlinDebug\n*F\n+ 1 PlayHud.kt\ncom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog\n*L\n216#1:514\n216#1:515,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\u0008\u0083\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0006\u0010\u0010\u001a\u00020\u0011J\u0008\u0010\u0012\u001a\u00020\u0011H\u0002J\u0010\u0010\u0013\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\u0015H\u0014R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\r0\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;",
        "Landroid/view/View;",
        "ctx",
        "Landroid/content/Context;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;)V",
        "tp",
        "Landroid/text/TextPaint;",
        "shadow",
        "layouts",
        "",
        "Landroid/text/StaticLayout;",
        "lines",
        "Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;",
        "lastW",
        "",
        "reload",
        "",
        "build",
        "onDraw",
        "c",
        "Landroid/graphics/Canvas;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private lastW:I

.field private layouts:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "+",
            "Landroid/text/StaticLayout;",
            ">;"
        }
    .end annotation
.end field

.field private lines:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;",
            ">;"
        }
    .end annotation
.end field

.field private final shadow:Landroid/text/TextPaint;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

.field private final tp:Landroid/text/TextPaint;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;)V
    .registers 9
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p2, "ctx"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    const-string v0, "ctx"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 199
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 200
    new-instance v0, Landroid/text/TextPaint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 513
    move-object v2, v0

    .local v2, "$this$tp_u24lambda_u240\\1":Landroid/text/TextPaint;
    const/4 v3, 0x0

    .line 200
    .local v3, "$i$a$-apply-PlayHud$ChatLog$tp$1\\1\\200\\0":I
    const/4 v4, -0x1

    invoke-virtual {v2, v4}, Landroid/text/TextPaint;->setColor(I)V

    const/high16 v4, 0x41600000    # 14.0f

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v5

    mul-float/2addr v5, v4

    invoke-virtual {v2, v5}, Landroid/text/TextPaint;->setTextSize(F)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getRegular$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/text/TextPaint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .end local v2    # "$this$tp_u24lambda_u240\\1":Landroid/text/TextPaint;
    .end local v3    # "$i$a$-apply-PlayHud$ChatLog$tp$1\\1\\200\\0":I
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->tp:Landroid/text/TextPaint;

    .line 201
    new-instance v0, Landroid/text/TextPaint;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->tp:Landroid/text/TextPaint;

    check-cast v1, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(Landroid/graphics/Paint;)V

    .line 513
    move-object v1, v0

    .local v1, "$this$shadow_u24lambda_u241\\2":Landroid/text/TextPaint;
    const/4 v2, 0x0

    .line 201
    .local v2, "$i$a$-apply-PlayHud$ChatLog$shadow$1\\2\\201\\0":I
    const/high16 v3, -0x34000000    # -3.3554432E7f

    invoke-virtual {v1, v3}, Landroid/text/TextPaint;->setColor(I)V

    .end local v1    # "$this$shadow_u24lambda_u241\\2":Landroid/text/TextPaint;
    .end local v2    # "$i$a$-apply-PlayHud$ChatLog$shadow$1\\2\\201\\0":I
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->shadow:Landroid/text/TextPaint;

    .line 202
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->layouts:Ljava/util/List;

    .line 203
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->lines:Ljava/util/List;

    .line 199
    return-void
.end method

.method private final build()V
    .registers 17

    .line 213
    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->getWidth()I

    move-result v1

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v3, 0x40800000    # 4.0f

    invoke-static {v2, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v2

    sub-int/2addr v1, v2

    .line 214
    .local v1, "w":I
    if-gtz v1, :cond_18

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->layouts:Ljava/util/List;

    return-void

    .line 215
    :cond_18
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->getWidth()I

    move-result v2

    iput v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->lastW:I

    .line 216
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->lines:Ljava/util/List;

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 514
    .local v3, "$i$f$map\\1\\216":I
    new-instance v4, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {v2, v5}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 515
    .local v6, "$i$f$mapTo\\2\\514":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_36
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_db

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 516
    .local v8, "item\\2":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;

    .local v9, "l\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;
    const/4 v10, 0x0

    .line 217
    .local v10, "$i$a$-map-PlayHud$ChatLog$build$1\\3\\516\\0":I
    new-instance v11, Landroid/text/SpannableStringBuilder;

    invoke-direct {v11}, Landroid/text/SpannableStringBuilder;-><init>()V

    .line 218
    .local v11, "sb\\3":Landroid/text/SpannableStringBuilder;
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;->getFrom()Ljava/lang/String;

    move-result-object v12

    if-eqz v12, :cond_9f

    .line 219
    invoke-virtual {v11}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v12

    .line 220
    .local v12, "s\\3":I
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;->getFrom()Ljava/lang/String;

    move-result-object v15

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "["

    invoke-virtual {v14, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    const-string v14, "]: "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    check-cast v13, Ljava/lang/CharSequence;

    invoke-virtual {v11, v13}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 221
    new-instance v13, Landroid/text/style/ForegroundColorSpan;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;->getColor()I

    move-result v14

    invoke-direct {v13, v14}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-virtual {v11}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v14

    const/16 v15, 0x21

    invoke-virtual {v11, v13, v12, v14, v15}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 222
    new-instance v13, Landroid/text/style/StyleSpan;

    const/4 v14, 0x1

    invoke-direct {v13, v14}, Landroid/text/style/StyleSpan;-><init>(I)V

    invoke-virtual {v11}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v14

    invoke-virtual {v11, v13, v12, v14, v15}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 223
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;->getText()Ljava/lang/String;

    move-result-object v13

    check-cast v13, Ljava/lang/CharSequence;

    invoke-virtual {v11, v13}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const/4 v14, 0x0

    goto :goto_bb

    .line 225
    .end local v12    # "s\\3":I
    :cond_9f
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;->getText()Ljava/lang/String;

    move-result-object v12

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v11, v12}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 226
    new-instance v12, Landroid/text/style/ForegroundColorSpan;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;->getColor()I

    move-result v13

    invoke-direct {v12, v13}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-virtual {v11}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v13

    const/4 v14, 0x0

    const/16 v15, 0x21

    invoke-virtual {v11, v12, v14, v13, v15}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 228
    :goto_bb
    move-object v12, v11

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v11}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v13

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->tp:Landroid/text/TextPaint;

    invoke-static {v12, v14, v13, v15, v1}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object v12

    sget-object v13, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    invoke-virtual {v12, v13}, Landroid/text/StaticLayout$Builder;->setAlignment(Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    move-result-object v12

    invoke-virtual {v12, v14}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    move-result-object v12

    invoke-virtual {v12}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object v9

    .line 516
    .end local v9    # "l\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ChatLine;
    .end local v10    # "$i$a$-map-PlayHud$ChatLog$build$1\\3\\516\\0":I
    .end local v11    # "sb\\3":Landroid/text/SpannableStringBuilder;
    invoke-interface {v4, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto/16 :goto_36

    .line 517
    .end local v8    # "item\\2":Ljava/lang/Object;
    :cond_db
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\2\\514":I
    check-cast v4, Ljava/util/List;

    .line 514
    nop

    .line 216
    .end local v2    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$map\\1\\216":I
    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->layouts:Ljava/util/List;

    .line 230
    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 8
    .param p1, "c"    # Landroid/graphics/Canvas;

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 233
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->getWidth()I

    move-result v0

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->lastW:I

    if-eq v0, v1, :cond_10

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->build()V

    .line 234
    :cond_10
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->getHeight()I

    move-result v0

    int-to-float v0, v0

    .line 235
    .local v0, "y":F
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->getWidth()I

    move-result v1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->getHeight()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {p1, v3, v3, v1, v2}, Landroid/graphics/Canvas;->clipRect(IIII)Z

    .line 236
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->layouts:Ljava/util/List;

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->asReversed(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_68

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/text/StaticLayout;

    .line 237
    .local v2, "l":Landroid/text/StaticLayout;
    invoke-virtual {v2}, Landroid/text/StaticLayout;->getHeight()I

    move-result v3

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v5, 0x40000000    # 2.0f

    invoke-static {v4, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v4

    add-int/2addr v3, v4

    int-to-float v3, v3

    sub-float/2addr v0, v3

    .line 238
    invoke-virtual {v2}, Landroid/text/StaticLayout;->getHeight()I

    move-result v3

    int-to-float v3, v3

    add-float/2addr v3, v0

    const/4 v4, 0x0

    cmpg-float v3, v3, v4

    if-ltz v3, :cond_68

    .line 239
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v3, v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {p1, v3, v0}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {v2, p1}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .end local v2    # "l":Landroid/text/StaticLayout;
    goto :goto_2e

    .line 241
    :cond_68
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 242
    return-void
.end method

.method public final reload()V
    .registers 5

    .line 207
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    monitor-enter v0

    .line 513
    const/4 v2, 0x0

    .line 207
    .local v2, "$i$a$-synchronized-PlayHud$ChatLog$reload$1\\1\\207\\0":I
    :try_start_e
    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v1

    if-eqz v1, :cond_2f

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getChatLines()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_2f

    check-cast v1, Ljava/util/List;

    const/16 v3, 0x3c

    invoke-static {v1, v3}, Lkotlin/collections/CollectionsKt;->takeLast(Ljava/util/List;I)Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_2f

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1
    :try_end_2e
    .catchall {:try_start_e .. :try_end_2e} :catchall_40

    goto :goto_30

    :cond_2f
    const/4 v1, 0x0

    .end local v2    # "$i$a$-synchronized-PlayHud$ChatLog$reload$1\\1\\207\\0":I
    :goto_30
    monitor-exit v0

    if-nez v1, :cond_37

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v1

    :cond_37
    iput-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->lines:Ljava/util/List;

    .line 208
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->build()V

    .line 209
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$ChatLog;->invalidate()V

    .line 210
    return-void

    .line 207
    :catchall_40
    move-exception v1

    monitor-exit v0

    throw v1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud.Layer (com.exampletest.mobilestudiotest.ui.PlayHud$Layer)
.class final Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;
.super Landroid/view/View;
.source "PlayHud.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/PlayHud;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "Layer"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPlayHud.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlayHud.kt\ncom/exampletest/mobilestudiotest/ui/PlayHud$Layer\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,512:1\n1#2:513\n1491#3:514\n1516#3,3:515\n1519#3,3:525\n1878#3,3:528\n1878#3,3:531\n382#4,7:518\n*S KotlinDebug\n*F\n+ 1 PlayHud.kt\ncom/exampletest/mobilestudiotest/ui/PlayHud$Layer\n*L\n267#1:514\n267#1:515,3\n267#1:525,3\n310#1:528,3\n322#1:531,3\n267#1:518,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0008\u0083\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0010\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000eH\u0014J\u0018\u0010\u000f\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J\u0018\u0010\u0012\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J\u0018\u0010\u0013\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J\u0010\u0010\u0014\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u0010\u0010\u0015\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000eH\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;",
        "Landroid/view/View;",
        "ctx",
        "Landroid/content/Context;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;)V",
        "fill",
        "Landroid/graphics/Paint;",
        "tp",
        "Landroid/text/TextPaint;",
        "bp",
        "onDraw",
        "",
        "c",
        "Landroid/graphics/Canvas;",
        "drawBubbles",
        "p",
        "Lcom/exampletest/mobilestudiotest/engine/PlaySession;",
        "drawPlayerList",
        "drawHealth",
        "drawCursor",
        "drawDot",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final bp:Landroid/graphics/Paint;

.field private final fill:Landroid/graphics/Paint;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

.field private final tp:Landroid/text/TextPaint;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;)V
    .registers 10
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p2, "ctx"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    const-string v0, "ctx"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 248
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 249
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    .line 250
    new-instance v0, Landroid/text/TextPaint;

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 513
    move-object v3, v0

    .local v3, "$this$tp_u24lambda_u240\\1":Landroid/text/TextPaint;
    const/4 v4, 0x0

    .line 250
    .local v4, "$i$a$-apply-PlayHud$Layer$tp$1\\1\\250\\0":I
    const/high16 v5, 0x41600000    # 14.0f

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v6

    mul-float/2addr v6, v5

    invoke-virtual {v3, v6}, Landroid/text/TextPaint;->setTextSize(F)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getRegular$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/text/TextPaint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .end local v3    # "$this$tp_u24lambda_u240\\1":Landroid/text/TextPaint;
    .end local v4    # "$i$a$-apply-PlayHud$Layer$tp$1\\1\\250\\0":I
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->tp:Landroid/text/TextPaint;

    .line 251
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 513
    move-object v2, v0

    .local v2, "$this$bp_u24lambda_u241\\2":Landroid/graphics/Paint;
    const/4 v3, 0x0

    .line 251
    .local v3, "$i$a$-apply-PlayHud$Layer$bp$1\\2\\251\\0":I
    const/high16 v4, 0x41500000    # 13.0f

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v5

    mul-float/2addr v5, v4

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getBold$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/4 v1, -0x1

    invoke-virtual {v2, v1}, Landroid/graphics/Paint;->setColor(I)V

    .end local v2    # "$this$bp_u24lambda_u241\\2":Landroid/graphics/Paint;
    .end local v3    # "$i$a$-apply-PlayHud$Layer$bp$1\\2\\251\\0":I
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    .line 248
    return-void
.end method

.method private final drawBubbles(Landroid/graphics/Canvas;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V
    .registers 39
    .param p1, "c"    # Landroid/graphics/Canvas;
    .param p2, "p"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    .line 265
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getBubbles()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_f

    return-void

    .line 266
    :cond_f
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v3, 0x435c0000    # 220.0f

    invoke-static {v2, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v2

    .line 267
    .local v2, "maxW":I
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getBubbles()Ljava/util/ArrayList;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$groupBy\\1":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 514
    .local v4, "$i$f$groupBy\\1\\267":I
    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v5, Ljava/util/Map;

    .local v5, "destination\\2":Ljava/util/Map;
    move-object v6, v3

    .local v6, "$this$groupByTo\\2":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 515
    .local v7, "$i$f$groupByTo\\2\\514":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_2b
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_5d

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .line 516
    .local v9, "element\\2":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;

    .local v10, "it\\5":Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;
    const/4 v11, 0x0

    .line 267
    .local v11, "$i$a$-groupBy-PlayHud$Layer$drawBubbles$byPart$1\\5\\516\\0":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v10

    .line 516
    .end local v10    # "it\\5":Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;
    .end local v11    # "$i$a$-groupBy-PlayHud$Layer$drawBubbles$byPart$1\\5\\516\\0":I
    nop

    .line 517
    .local v10, "key\\2":Ljava/lang/Object;
    move-object v11, v5

    .local v11, "$this$getOrPut\\3":Ljava/util/Map;
    const/4 v12, 0x0

    .line 518
    .local v12, "$i$f$getOrPut\\3\\517":I
    invoke-interface {v11, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    .line 519
    .local v13, "value\\3":Ljava/lang/Object;
    if-nez v13, :cond_54

    .line 520
    const/4 v14, 0x0

    .line 517
    .local v14, "$i$a$-getOrPut-CollectionsKt___CollectionsKt$groupByTo$list$1\\4\\520\\2":I
    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    check-cast v15, Ljava/util/List;

    .line 520
    .end local v14    # "$i$a$-getOrPut-CollectionsKt___CollectionsKt$groupByTo$list$1\\4\\520\\2":I
    nop

    .line 521
    .local v15, "answer\\3":Ljava/lang/Object;
    invoke-interface {v11, v10, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 522
    nop

    .end local v15    # "answer\\3":Ljava/lang/Object;
    goto :goto_55

    .line 524
    :cond_54
    move-object v15, v13

    .line 519
    :goto_55
    nop

    .line 517
    .end local v11    # "$this$getOrPut\\3":Ljava/util/Map;
    .end local v12    # "$i$f$getOrPut\\3\\517":I
    .end local v13    # "value\\3":Ljava/lang/Object;
    move-object v11, v15

    check-cast v11, Ljava/util/List;

    .line 525
    .local v11, "list\\2":Ljava/util/List;
    invoke-interface {v11, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .end local v10    # "key\\2":Ljava/lang/Object;
    .end local v11    # "list\\2":Ljava/util/List;
    goto :goto_2b

    .line 527
    .end local v9    # "element\\2":Ljava/lang/Object;
    :cond_5d
    nop

    .line 514
    .end local v5    # "destination\\2":Ljava/util/Map;
    .end local v6    # "$this$groupByTo\\2":Ljava/lang/Iterable;
    .end local v7    # "$i$f$groupByTo\\2\\514":I
    nop

    .line 267
    .end local v3    # "$this$groupBy\\1":Ljava/lang/Iterable;
    .end local v4    # "$i$f$groupBy\\1\\267":I
    nop

    .line 268
    .local v5, "byPart":Ljava/util/Map;
    invoke-interface {v5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_68
    :goto_68
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2a0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v6, "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/List;

    .line 269
    .local v4, "list":Ljava/util/List;
    sget-object v7, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v7, v6}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    new-instance v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    sget-object v9, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v9, v6}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v9

    const/high16 v10, 0x40000000    # 2.0f

    div-float/2addr v9, v10

    const v11, 0x3fcccccd    # 1.6f

    add-float/2addr v9, v11

    const/4 v11, 0x0

    invoke-direct {v8, v11, v9, v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    .line 270
    .local v7, "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v8}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v8

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v8

    invoke-virtual {v8, v7}, Lcom/exampletest/mobilestudiotest/render/ViewState;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)[F

    move-result-object v8

    if-eqz v8, :cond_68

    .line 271
    .local v8, "s":[F
    const/4 v9, 0x2

    aget v9, v8, v9

    const/high16 v12, 0x3f800000    # 1.0f

    cmpl-float v9, v9, v12

    if-gtz v9, :cond_292

    .line 272
    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v9

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/core/Studio;->getView()Lcom/exampletest/mobilestudiotest/render/ViewState;

    move-result-object v9

    invoke-virtual {v9, v7}, Lcom/exampletest/mobilestudiotest/render/ViewState;->distTo(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v9

    .line 273
    .local v9, "dist":F
    const/high16 v13, 0x42c80000    # 100.0f

    cmpl-float v13, v9, v13

    if-gtz v13, :cond_282

    .line 274
    const/4 v13, 0x1

    aget v14, v8, v13

    .line 275
    .local v14, "bottom":F
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->asReversed(Ljava/util/List;)Ljava/util/List;

    move-result-object v15

    check-cast v15, Ljava/lang/Iterable;

    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    move/from16 v16, v13

    const/4 v13, 0x0

    move/from16 v17, v13

    :goto_e4
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_272

    move/from16 v18, v17

    .local v18, "i":I
    add-int/lit8 v17, v17, 0x1

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;

    .line 276
    .local v19, "b":Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;
    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;->getAge()F

    move-result v20

    const/high16 v21, 0x41300000    # 11.0f

    cmpl-float v20, v20, v21

    move/from16 v21, v10

    const/high16 v10, 0x41400000    # 12.0f

    if-lez v20, :cond_10b

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;->getAge()F

    move-result v20

    sub-float v20, v10, v20

    move/from16 v10, v20

    goto :goto_10c

    :cond_10b
    move v10, v12

    :goto_10c
    invoke-static {v10, v11, v12}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v10

    if-nez v18, :cond_115

    move/from16 v22, v12

    goto :goto_118

    :cond_115
    const v22, 0x3f4ccccd    # 0.8f

    :goto_118
    mul-float v10, v10, v22

    .line 277
    .local v10, "alpha":F
    iget-object v11, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->tp:Landroid/text/TextPaint;

    const/high16 v23, 0x437f0000    # 255.0f

    move/from16 v24, v12

    mul-float v12, v10, v23

    float-to-int v12, v12

    shl-int/lit8 v12, v12, 0x18

    const v25, 0x393b3d

    or-int v12, v12, v25

    invoke-virtual {v11, v12}, Landroid/text/TextPaint;->setColor(I)V

    .line 278
    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;->getText()Ljava/lang/String;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;->getText()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    move-object/from16 v25, v3

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->tp:Landroid/text/TextPaint;

    invoke-static {v11, v13, v12, v3, v2}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object v3

    sget-object v11, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    invoke-virtual {v3, v11}, Landroid/text/StaticLayout$Builder;->setAlignment(Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    move-result-object v3

    invoke-virtual {v3, v13}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object v3

    const-string v11, "build(...)"

    invoke-static {v3, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 279
    .local v3, "layout":Landroid/text/StaticLayout;
    const/4 v11, 0x0

    .line 280
    .local v11, "w":F
    const/4 v12, 0x0

    move/from16 v26, v13

    .local v12, "ln":I
    invoke-virtual {v3}, Landroid/text/StaticLayout;->getLineCount()I

    move-result v13

    :goto_15e
    if-ge v12, v13, :cond_16f

    move-object/from16 v27, v4

    .end local v4    # "list":Ljava/util/List;
    .local v27, "list":Ljava/util/List;
    invoke-virtual {v3, v12}, Landroid/text/StaticLayout;->getLineWidth(I)F

    move-result v4

    invoke-static {v11, v4}, Ljava/lang/Math;->max(FF)F

    move-result v11

    add-int/lit8 v12, v12, 0x1

    move-object/from16 v4, v27

    goto :goto_15e

    .end local v27    # "list":Ljava/util/List;
    .restart local v4    # "list":Ljava/util/List;
    :cond_16f
    move-object/from16 v27, v4

    .line 281
    .end local v4    # "list":Ljava/util/List;
    .end local v12    # "ln":I
    .restart local v27    # "list":Ljava/util/List;
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v12, 0x41200000    # 10.0f

    invoke-static {v4, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v4

    .local v4, "padX":I
    iget-object v13, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v12, 0x40c00000    # 6.0f

    invoke-static {v13, v12}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v12

    .line 282
    .local v12, "padY":I
    mul-int/lit8 v13, v4, 0x2

    int-to-float v13, v13

    add-float/2addr v13, v11

    move/from16 v29, v4

    .end local v4    # "padX":I
    .local v13, "bw":F
    .local v29, "padX":I
    invoke-virtual {v3}, Landroid/text/StaticLayout;->getHeight()I

    move-result v4

    int-to-float v4, v4

    move/from16 v30, v4

    int-to-float v4, v12

    mul-float v4, v4, v21

    add-float v4, v30, v4

    .line 283
    .local v4, "bh":F
    move/from16 v30, v4

    .end local v4    # "bh":F
    .local v30, "bh":F
    new-instance v4, Landroid/graphics/RectF;

    aget v31, v8, v26

    div-float v32, v13, v21

    move-object/from16 v33, v5

    .end local v5    # "byPart":Ljava/util/Map;
    .local v33, "byPart":Ljava/util/Map;
    sub-float v5, v31, v32

    sub-float v31, v14, v30

    move-object/from16 v32, v6

    .end local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v32, "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    move-object/from16 v34, v7

    const/high16 v7, 0x41200000    # 10.0f

    .end local v7    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v34, "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-static {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    sub-float v6, v31, v6

    aget v28, v8, v26

    div-float v31, v13, v21

    move-object/from16 v35, v8

    .end local v8    # "s":[F
    .local v35, "s":[F
    add-float v8, v28, v31

    move/from16 v28, v9

    .end local v9    # "dist":F
    .local v28, "dist":F
    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v9, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v7

    int-to-float v7, v7

    sub-float v7, v14, v7

    invoke-direct {v4, v5, v6, v8, v7}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 284
    .local v4, "r":Landroid/graphics/RectF;
    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    const v6, 0x3f6b851f    # 0.92f

    mul-float/2addr v6, v10

    mul-float v6, v6, v23

    float-to-int v6, v6

    shl-int/lit8 v6, v6, 0x18

    const v7, 0xffffff

    or-int/2addr v6, v7

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 285
    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v6, 0x41400000    # 12.0f

    invoke-static {v5, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v5

    int-to-float v5, v5

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v7, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v5, v6, v7}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 286
    if-nez v18, :cond_239

    new-instance v5, Landroid/graphics/Path;

    invoke-direct {v5}, Landroid/graphics/Path;-><init>()V

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 513
    move-object v7, v5

    .local v7, "$this$drawBubbles_u24lambda_u244\\6":Landroid/graphics/Path;
    const/4 v8, 0x0

    .line 286
    .local v8, "$i$a$-apply-PlayHud$Layer$drawBubbles$1\\6\\286\\0":I
    aget v9, v35, v26

    move/from16 v20, v8

    .end local v8    # "$i$a$-apply-PlayHud$Layer$drawBubbles$1\\6\\286\\0":I
    .local v20, "$i$a$-apply-PlayHud$Layer$drawBubbles$1\\6\\286\\0":I
    const/high16 v8, 0x40e00000    # 7.0f

    move/from16 v23, v9

    invoke-static {v6, v8}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v9

    int-to-float v9, v9

    sub-float v9, v23, v9

    iget v8, v4, Landroid/graphics/RectF;->bottom:F

    sub-float v8, v8, v24

    invoke-virtual {v7, v9, v8}, Landroid/graphics/Path;->moveTo(FF)V

    aget v8, v35, v26

    iget v9, v4, Landroid/graphics/RectF;->bottom:F

    move/from16 v31, v9

    const/high16 v9, 0x41000000    # 8.0f

    invoke-static {v6, v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v9

    int-to-float v9, v9

    add-float v9, v31, v9

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    aget v8, v35, v26

    const/high16 v9, 0x40e00000    # 7.0f

    invoke-static {v6, v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    add-float/2addr v8, v6

    iget v6, v4, Landroid/graphics/RectF;->bottom:F

    sub-float v6, v6, v24

    invoke-virtual {v7, v8, v6}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v7}, Landroid/graphics/Path;->close()V

    .end local v7    # "$this$drawBubbles_u24lambda_u244\\6":Landroid/graphics/Path;
    .end local v20    # "$i$a$-apply-PlayHud$Layer$drawBubbles$1\\6\\286\\0":I
    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    invoke-virtual {v1, v5, v6}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 287
    :cond_239
    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    aget v5, v35, v26

    int-to-float v6, v2

    div-float v6, v6, v21

    sub-float/2addr v5, v6

    iget v6, v4, Landroid/graphics/RectF;->top:F

    int-to-float v7, v12

    add-float/2addr v6, v7

    invoke-virtual {v1, v5, v6}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {v3, v1}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    .line 288
    iget v5, v4, Landroid/graphics/RectF;->top:F

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    move/from16 v7, v21

    invoke-static {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    sub-float v14, v5, v6

    move v10, v7

    move/from16 v12, v24

    move-object/from16 v3, v25

    move/from16 v13, v26

    move-object/from16 v4, v27

    move/from16 v9, v28

    move-object/from16 v6, v32

    move-object/from16 v5, v33

    move-object/from16 v7, v34

    move-object/from16 v8, v35

    const/4 v11, 0x0

    .end local v3    # "layout":Landroid/text/StaticLayout;
    .end local v4    # "r":Landroid/graphics/RectF;
    .end local v10    # "alpha":F
    .end local v11    # "w":F
    .end local v12    # "padY":I
    .end local v13    # "bw":F
    .end local v29    # "padX":I
    .end local v30    # "bh":F
    goto/16 :goto_e4

    .line 275
    .end local v18    # "i":I
    .end local v19    # "b":Lcom/exampletest/mobilestudiotest/engine/PlaySession$Bubble;
    .end local v27    # "list":Ljava/util/List;
    .end local v28    # "dist":F
    .end local v32    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v33    # "byPart":Ljava/util/Map;
    .end local v34    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v35    # "s":[F
    .local v4, "list":Ljava/util/List;
    .restart local v5    # "byPart":Ljava/util/Map;
    .restart local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v7, "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v8, "s":[F
    .restart local v9    # "dist":F
    :cond_272
    move-object/from16 v25, v3

    move-object/from16 v27, v4

    move-object/from16 v33, v5

    move-object/from16 v32, v6

    move-object/from16 v34, v7

    move-object/from16 v35, v8

    move/from16 v28, v9

    .end local v4    # "list":Ljava/util/List;
    .end local v5    # "byPart":Ljava/util/Map;
    .end local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "s":[F
    .end local v9    # "dist":F
    .restart local v27    # "list":Ljava/util/List;
    .restart local v28    # "dist":F
    .restart local v32    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v33    # "byPart":Ljava/util/Map;
    .restart local v34    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v35    # "s":[F
    goto/16 :goto_68

    .line 273
    .end local v14    # "bottom":F
    .end local v27    # "list":Ljava/util/List;
    .end local v28    # "dist":F
    .end local v32    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v33    # "byPart":Ljava/util/Map;
    .end local v34    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v35    # "s":[F
    .restart local v4    # "list":Ljava/util/List;
    .restart local v5    # "byPart":Ljava/util/Map;
    .restart local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v7    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v8    # "s":[F
    .restart local v9    # "dist":F
    :cond_282
    move-object/from16 v25, v3

    move-object/from16 v27, v4

    move-object/from16 v33, v5

    move-object/from16 v32, v6

    move-object/from16 v34, v7

    move-object/from16 v35, v8

    move/from16 v28, v9

    .end local v4    # "list":Ljava/util/List;
    .end local v5    # "byPart":Ljava/util/Map;
    .end local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "s":[F
    .end local v9    # "dist":F
    .restart local v27    # "list":Ljava/util/List;
    .restart local v28    # "dist":F
    .restart local v32    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v33    # "byPart":Ljava/util/Map;
    .restart local v34    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v35    # "s":[F
    goto/16 :goto_68

    .line 271
    .end local v27    # "list":Ljava/util/List;
    .end local v28    # "dist":F
    .end local v32    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v33    # "byPart":Ljava/util/Map;
    .end local v34    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v35    # "s":[F
    .restart local v4    # "list":Ljava/util/List;
    .restart local v5    # "byPart":Ljava/util/Map;
    .restart local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v7    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v8    # "s":[F
    :cond_292
    move-object/from16 v25, v3

    move-object/from16 v27, v4

    move-object/from16 v33, v5

    move-object/from16 v32, v6

    move-object/from16 v34, v7

    move-object/from16 v35, v8

    .end local v4    # "list":Ljava/util/List;
    .end local v5    # "byPart":Ljava/util/Map;
    .end local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "s":[F
    .restart local v27    # "list":Ljava/util/List;
    .restart local v32    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v33    # "byPart":Ljava/util/Map;
    .restart local v34    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v35    # "s":[F
    goto/16 :goto_68

    .line 291
    .end local v27    # "list":Ljava/util/List;
    .end local v32    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v33    # "byPart":Ljava/util/Map;
    .end local v34    # "world":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v35    # "s":[F
    .restart local v5    # "byPart":Ljava/util/Map;
    :cond_2a0
    return-void
.end method

.method private final drawCursor(Landroid/graphics/Canvas;)V
    .registers 7
    .param p1, "c"    # Landroid/graphics/Canvas;

    .line 339
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->getWidth()I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    const/4 v2, 0x0

    add-float/2addr v0, v2

    .local v0, "cx":F
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->getHeight()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v1

    .line 340
    .local v2, "cy":F
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v4

    mul-float/2addr v4, v1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    const v4, -0x19000001

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 341
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v3

    const/high16 v4, 0x41100000    # 9.0f

    mul-float/2addr v3, v4

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 342
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 343
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v3

    mul-float/2addr v3, v1

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v2, v3, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 344
    return-void
.end method

.method private final drawDot(Landroid/graphics/Canvas;)V
    .registers 6
    .param p1, "c"    # Landroid/graphics/Canvas;

    .line 347
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    const v1, -0x33000001    # -1.3421772E8f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 348
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->getWidth()I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->getHeight()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v1

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v1

    const/high16 v3, 0x40200000    # 2.5f

    mul-float/2addr v1, v3

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v2, v1, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 349
    return-void
.end method

.method private final drawHealth(Landroid/graphics/Canvas;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V
    .registers 21
    .param p1, "c"    # Landroid/graphics/Canvas;
    .param p2, "p"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    .line 326
    move-object/from16 v0, p0

    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getCharacter()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-eqz v1, :cond_e9

    const-string v2, "Humanoid"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-eqz v1, :cond_e9

    .line 327
    .local v1, "hum":Lcom/exampletest/mobilestudiotest/model/Instance;
    const-string v2, "Health_XML"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_1e

    const-string v2, "Health"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    :cond_1e
    instance-of v3, v2, Ljava/lang/Number;

    const/4 v4, 0x0

    if-eqz v3, :cond_26

    check-cast v2, Ljava/lang/Number;

    goto :goto_27

    :cond_26
    move-object v2, v4

    :goto_27
    if-eqz v2, :cond_e8

    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    move-result v2

    .line 328
    .local v2, "hp":F
    const-string v3, "MaxHealth"

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    instance-of v5, v3, Ljava/lang/Number;

    if-eqz v5, :cond_3a

    check-cast v3, Ljava/lang/Number;

    goto :goto_3b

    :cond_3a
    move-object v3, v4

    :goto_3b
    const/4 v5, 0x0

    if-eqz v3, :cond_5f

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    move-object v6, v3

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    move-result v6

    .line 513
    .local v6, "it\\1":F
    const/4 v7, 0x0

    .line 328
    .local v7, "$i$a$-takeIf-PlayHud$Layer$drawHealth$max$1\\1\\328\\0":I
    cmpl-float v8, v6, v5

    if-lez v8, :cond_54

    const/4 v8, 0x1

    goto :goto_55

    :cond_54
    const/4 v8, 0x0

    .end local v6    # "it\\1":F
    .end local v7    # "$i$a$-takeIf-PlayHud$Layer$drawHealth$max$1\\1\\328\\0":I
    :goto_55
    if-eqz v8, :cond_58

    move-object v4, v3

    :cond_58
    if-eqz v4, :cond_5f

    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    move-result v3

    goto :goto_61

    :cond_5f
    const/high16 v3, 0x42c80000    # 100.0f

    .line 329
    .local v3, "max":F
    :goto_61
    cmpl-float v4, v2, v3

    if-ltz v4, :cond_66

    return-void

    .line 330
    :cond_66
    div-float v4, v2, v3

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-static {v4, v5, v6}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v4

    .line 331
    .local v4, "f":F
    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v7, 0x42f00000    # 120.0f

    invoke-static {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    .local v6, "w":F
    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v8, 0x41000000    # 8.0f

    invoke-static {v7, v8}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v7

    int-to-float v7, v7

    .line 332
    .local v7, "h":F
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->getWidth()I

    move-result v8

    int-to-float v8, v8

    sub-float/2addr v8, v6

    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v10, 0x42800000    # 64.0f

    invoke-static {v9, v10}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v9

    int-to-float v9, v9

    sub-float v11, v8, v9

    .local v11, "x":F
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v9, 0x41c00000    # 24.0f

    invoke-static {v8, v9}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v8

    int-to-float v12, v8

    .line 333
    .local v12, "y":F
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    const/high16 v9, -0x80000000

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    add-float v13, v11, v6

    add-float v14, v12, v7

    const/high16 v8, 0x40000000    # 2.0f

    div-float v15, v7, v8

    div-float v16, v7, v8

    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    move-object/from16 v10, p1

    move-object/from16 v17, v9

    invoke-virtual/range {v10 .. v17}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 334
    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    const/high16 v10, 0x3f000000    # 0.5f

    cmpl-float v10, v4, v10

    if-lez v10, :cond_c0

    const v10, -0xd42ea5

    goto :goto_cd

    :cond_c0
    const/high16 v10, 0x3e800000    # 0.25f

    cmpl-float v10, v4, v10

    if-lez v10, :cond_ca

    const v10, -0xa3ae8

    goto :goto_cd

    :cond_ca
    const v10, -0x1ab7b3

    :goto_cd
    invoke-virtual {v9, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 335
    cmpl-float v5, v4, v5

    if-lez v5, :cond_e7

    mul-float v5, v6, v4

    add-float v13, v11, v5

    add-float v14, v12, v7

    div-float v15, v7, v8

    div-float v16, v7, v8

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    move-object/from16 v10, p1

    move-object/from16 v17, v5

    invoke-virtual/range {v10 .. v17}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 336
    :cond_e7
    return-void

    .line 327
    .end local v2    # "hp":F
    .end local v3    # "max":F
    .end local v4    # "f":F
    .end local v6    # "w":F
    .end local v7    # "h":F
    .end local v11    # "x":F
    .end local v12    # "y":F
    :cond_e8
    return-void

    .line 326
    .end local v1    # "hum":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_e9
    return-void
.end method

.method private final drawPlayerList(Landroid/graphics/Canvas;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V
    .registers 31
    .param p1, "c"    # Landroid/graphics/Canvas;
    .param p2, "p"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    .line 294
    move-object/from16 v0, p0

    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getPlayer()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-nez v1, :cond_9

    return-void

    :cond_9
    move-object v9, v1

    .line 295
    .local v9, "pl":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->leaderstats()Ljava/util/List;

    move-result-object v10

    .line 296
    .local v10, "stats":Ljava/util/List;
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v2, 0x42980000    # 76.0f

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v1

    int-to-float v11, v1

    .line 297
    .local v11, "colW":F
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v2, 0x43160000    # 150.0f

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v1

    int-to-float v12, v1

    .line 298
    .local v12, "nameW":F
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v1

    int-to-float v1, v1

    mul-float/2addr v1, v11

    add-float/2addr v1, v12

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v3, 0x41800000    # 16.0f

    invoke-static {v2, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v2

    int-to-float v2, v2

    add-float v13, v1, v2

    .line 299
    .local v13, "w":F
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v2, 0x42000000    # 32.0f

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v1

    int-to-float v14, v1

    .line 300
    .local v14, "rowH":F
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->getWidth()I

    move-result v1

    int-to-float v1, v1

    sub-float/2addr v1, v13

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v15, 0x41400000    # 12.0f

    invoke-static {v2, v15}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v2

    int-to-float v2, v2

    sub-float v2, v1, v2

    .local v2, "x0":F
    const/4 v1, 0x0

    .local v1, "y":F
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v4, 0x42600000    # 56.0f

    invoke-static {v3, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v3

    int-to-float v3, v3

    .line 301
    .end local v1    # "y":F
    .local v3, "y":F
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    const/high16 v4, -0x80000000

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 302
    move-object v1, v10

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    const/16 v16, 0x1

    xor-int/lit8 v1, v1, 0x1

    add-int/lit8 v1, v1, 0x1

    .line 303
    .local v1, "rows":I
    add-float v4, v2, v13

    int-to-float v5, v1

    mul-float/2addr v5, v14

    add-float/2addr v5, v3

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v7, 0x41000000    # 8.0f

    invoke-static {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    add-float/2addr v5, v6

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v8, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v7

    int-to-float v7, v7

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    move/from16 v17, v1

    move-object/from16 v1, p1

    .end local v1    # "rows":I
    .local v17, "rows":I
    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 304
    move/from16 v18, v2

    .end local v2    # "x0":F
    .local v18, "x0":F
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v4, 0x40800000    # 4.0f

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v2

    int-to-float v2, v2

    add-float/2addr v3, v2

    .line 305
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 306
    move-object v2, v10

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    const/16 v5, 0xa

    const/high16 v6, 0x41200000    # 10.0f

    const/high16 v19, 0x40000000    # 2.0f

    if-nez v2, :cond_13c

    .line 307
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    const v7, -0x373738

    invoke-virtual {v2, v7}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v15

    invoke-virtual {v2, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 308
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v2, v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v2

    int-to-float v2, v2

    add-float v2, v18, v2

    const v7, 0x3f1eb852    # 0.62f

    mul-float v8, v14, v7

    add-float/2addr v8, v3

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    const-string v6, "People"

    invoke-virtual {v1, v6, v2, v8, v15}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 309
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v6}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 310
    move-object v2, v10

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 528
    .local v6, "$i$f$forEachIndexed\\1\\310":I
    const/4 v8, 0x0

    .line 529
    .local v8, "index\\1":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_ec
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_135

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v21

    .local v21, "item\\1":Ljava/lang/Object;
    add-int/lit8 v22, v8, 0x1

    .end local v8    # "index\\1":I
    .local v22, "index\\1":I
    if-gez v8, :cond_fd

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_fd
    move-object/from16 v23, v21

    check-cast v23, Lkotlin/Pair;

    .local v8, "i\\2":I
    const/16 v24, 0x0

    .local v24, "$i$a$-forEachIndexed-PlayHud$Layer$drawPlayerList$1\\2\\529\\0":I
    invoke-virtual/range {v23 .. v23}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v23

    move/from16 v25, v7

    move-object/from16 v7, v23

    check-cast v7, Ljava/lang/String;

    .line 310
    .local v7, "n\\2":Ljava/lang/String;
    invoke-static {v7, v5}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    add-float v26, v18, v12

    int-to-float v5, v8

    mul-float/2addr v5, v11

    add-float v26, v26, v5

    div-float v5, v11, v19

    add-float v5, v26, v5

    mul-float v26, v14, v25

    move-object/from16 v27, v2

    .end local v2    # "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    .local v27, "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    add-float v2, v3, v26

    move/from16 v26, v3

    .end local v3    # "y":F
    .local v26, "y":F
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v5, v2, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 529
    .end local v7    # "n\\2":Ljava/lang/String;
    .end local v8    # "i\\2":I
    .end local v24    # "$i$a$-forEachIndexed-PlayHud$Layer$drawPlayerList$1\\2\\529\\0":I
    move/from16 v8, v22

    move/from16 v7, v25

    move/from16 v3, v26

    move-object/from16 v2, v27

    const/high16 v4, 0x40800000    # 4.0f

    const/16 v5, 0xa

    .end local v21    # "item\\1":Ljava/lang/Object;
    goto :goto_ec

    .line 530
    .end local v22    # "index\\1":I
    .end local v26    # "y":F
    .end local v27    # "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    .restart local v2    # "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    .restart local v3    # "y":F
    .local v8, "index\\1":I
    :cond_135
    move-object/from16 v27, v2

    move/from16 v26, v3

    .line 311
    .end local v2    # "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    .end local v3    # "y":F
    .end local v6    # "$i$f$forEachIndexed\\1\\310":I
    .end local v8    # "index\\1":I
    .restart local v26    # "y":F
    add-float v3, v26, v14

    .end local v26    # "y":F
    .restart local v3    # "y":F
    goto :goto_13e

    .line 306
    :cond_13c
    move/from16 v26, v3

    .line 314
    :goto_13e
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    const v4, 0x33ffffff

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 315
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v4, 0x40800000    # 4.0f

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v2

    int-to-float v2, v2

    add-float v2, v18, v2

    add-float v5, v18, v13

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v6, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v4

    int-to-float v4, v4

    sub-float v4, v5, v4

    add-float v5, v3, v14

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v7, 0x40c00000    # 6.0f

    invoke-static {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v8, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v7

    int-to-float v7, v7

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    const/high16 v15, 0x41200000    # 10.0f

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 316
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v4

    move-object/from16 v5, p2

    invoke-virtual {v5, v4}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->nameColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 317
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v4, 0x41a00000    # 20.0f

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v2

    int-to-float v2, v2

    add-float v2, v18, v2

    div-float v4, v14, v19

    add-float/2addr v4, v3

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v6, v15}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->fill:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v4, v6, v7}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 318
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    const/4 v4, -0x1

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v4

    const/high16 v6, 0x41600000    # 14.0f

    mul-float/2addr v4, v6

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 319
    const-string v2, "DisplayName"

    invoke-virtual {v9, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v4, v2, Ljava/lang/String;

    if-eqz v4, :cond_1c6

    check-cast v2, Ljava/lang/String;

    goto :goto_1c7

    :cond_1c6
    const/4 v2, 0x0

    :goto_1c7
    if-eqz v2, :cond_1df

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-eqz v4, :cond_1d3

    const/16 v16, 0x0

    :cond_1d3
    if-eqz v16, :cond_1da

    .line 513
    const/4 v2, 0x0

    .line 319
    .local v2, "$i$a$-ifEmpty-PlayHud$Layer$drawPlayerList$dn$1\\3\\319\\0":I
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    .end local v2    # "$i$a$-ifEmpty-PlayHud$Layer$drawPlayerList$dn$1\\3\\319\\0":I
    :cond_1da
    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_1df

    goto :goto_1e3

    :cond_1df
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    .line 320
    .local v2, "dn":Ljava/lang/String;
    :goto_1e3
    const/16 v4, 0x10

    invoke-static {v2, v4}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    const/high16 v7, 0x42100000    # 36.0f

    invoke-static {v6, v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$dp(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)I

    move-result v6

    int-to-float v6, v6

    add-float v6, v18, v6

    const v7, 0x3f266666    # 0.65f

    mul-float v8, v14, v7

    add-float/2addr v8, v3

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v6, v8, v15}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 321
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 322
    move-object v4, v10

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$forEachIndexed\\4":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 531
    .local v6, "$i$f$forEachIndexed\\4\\322":I
    const/4 v8, 0x0

    .line 532
    .local v8, "index\\4":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_20f
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_25c

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    .local v16, "item\\4":Ljava/lang/Object;
    add-int/lit8 v20, v8, 0x1

    .end local v8    # "index\\4":I
    .local v20, "index\\4":I
    if-gez v8, :cond_220

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_220
    move-object/from16 v21, v16

    check-cast v21, Lkotlin/Pair;

    .local v8, "i\\5":I
    const/16 v22, 0x0

    .local v22, "$i$a$-forEachIndexed-PlayHud$Layer$drawPlayerList$2\\5\\532\\0":I
    invoke-virtual/range {v21 .. v21}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v21

    move/from16 v23, v7

    move-object/from16 v7, v21

    check-cast v7, Ljava/lang/String;

    .line 322
    .local v7, "v\\5":Ljava/lang/String;
    move-object/from16 v21, v2

    move/from16 v24, v3

    const/16 v2, 0xa

    .end local v2    # "dn":Ljava/lang/String;
    .end local v3    # "y":F
    .local v21, "dn":Ljava/lang/String;
    .local v24, "y":F
    invoke-static {v7, v2}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    add-float v25, v18, v12

    int-to-float v2, v8

    mul-float/2addr v2, v11

    add-float v25, v25, v2

    div-float v2, v11, v19

    add-float v2, v25, v2

    mul-float v25, v14, v23

    move-object/from16 v26, v4

    .end local v4    # "$this$forEachIndexed\\4":Ljava/lang/Iterable;
    .local v26, "$this$forEachIndexed\\4":Ljava/lang/Iterable;
    add-float v4, v24, v25

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->bp:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v2, v4, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 532
    .end local v7    # "v\\5":Ljava/lang/String;
    .end local v8    # "i\\5":I
    .end local v22    # "$i$a$-forEachIndexed-PlayHud$Layer$drawPlayerList$2\\5\\532\\0":I
    move-object/from16 v5, p2

    move/from16 v8, v20

    move-object/from16 v2, v21

    move/from16 v7, v23

    move/from16 v3, v24

    move-object/from16 v4, v26

    .end local v16    # "item\\4":Ljava/lang/Object;
    goto :goto_20f

    .line 533
    .end local v20    # "index\\4":I
    .end local v21    # "dn":Ljava/lang/String;
    .end local v24    # "y":F
    .end local v26    # "$this$forEachIndexed\\4":Ljava/lang/Iterable;
    .restart local v2    # "dn":Ljava/lang/String;
    .restart local v3    # "y":F
    .restart local v4    # "$this$forEachIndexed\\4":Ljava/lang/Iterable;
    .local v8, "index\\4":I
    :cond_25c
    nop

    .line 323
    .end local v4    # "$this$forEachIndexed\\4":Ljava/lang/Iterable;
    .end local v6    # "$i$f$forEachIndexed\\4\\322":I
    .end local v8    # "index\\4":I
    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 7
    .param p1, "c"    # Landroid/graphics/Canvas;

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 254
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getLock()Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    monitor-enter v0

    const/4 v2, 0x0

    .line 255
    .local v2, "$i$a$-synchronized-PlayHud$Layer$onDraw$1\\1\\254\\0":I
    :try_start_13
    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getStudio$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v3
    :try_end_1b
    .catchall {:try_start_13 .. :try_end_1b} :catchall_58

    if-nez v3, :cond_1f

    .end local v2    # "$i$a$-synchronized-PlayHud$Layer$onDraw$1\\1\\254\\0":I
    monitor-exit v0

    return-void

    .line 256
    .restart local v2    # "$i$a$-synchronized-PlayHud$Layer$onDraw$1\\1\\254\\0":I
    .local v3, "p\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :cond_1f
    :try_start_1f
    invoke-direct {p0, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->drawBubbles(Landroid/graphics/Canvas;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V

    .line 257
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getCorePlayerList()Z

    move-result v4

    if-eqz v4, :cond_31

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getPlayerListOpen$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Z

    move-result v1

    if-eqz v1, :cond_31

    invoke-direct {p0, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->drawPlayerList(Landroid/graphics/Canvas;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V

    .line 258
    :cond_31
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getCoreHealth()Z

    move-result v1

    if-eqz v1, :cond_3a

    invoke-direct {p0, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->drawHealth(Landroid/graphics/Canvas;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V

    .line 259
    :cond_3a
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getShiftLock()Z

    move-result v1

    if-eqz v1, :cond_4a

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getFirstPerson()Z

    move-result v1

    if-nez v1, :cond_4a

    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->drawCursor(Landroid/graphics/Canvas;)V

    goto :goto_53

    .line 260
    :cond_4a
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getFirstPerson()Z

    move-result v1

    if-eqz v1, :cond_53

    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$Layer;->drawDot(Landroid/graphics/Canvas;)V

    .line 261
    :cond_53
    :goto_53
    nop

    .end local v2    # "$i$a$-synchronized-PlayHud$Layer$onDraw$1\\1\\254\\0":I
    .end local v3    # "p\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_56
    .catchall {:try_start_1f .. :try_end_56} :catchall_58

    .line 254
    monitor-exit v0

    .line 262
    return-void

    .line 254
    :catchall_58
    move-exception v1

    monitor-exit v0

    throw v1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud.TopButton (com.exampletest.mobilestudiotest.ui.PlayHud$TopButton)
.class final Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;
.super Landroid/view/View;
.source "PlayHud.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/PlayHud;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "TopButton"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPlayHud.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlayHud.kt\ncom/exampletest/mobilestudiotest/ui/PlayHud$TopButton\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,512:1\n1#2:513\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\u0008\u0083\u0004\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0014J\u0010\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u000bH\u0014J\u0010\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\u0019\u001a\u00020\u001aH\u0017R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u001a\u0010\n\u001a\u00020\u000bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000c\u0010\r\"\u0004\u0008\u000e\u0010\u000fR\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001b"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;",
        "Landroid/view/View;",
        "ctx",
        "Landroid/content/Context;",
        "kind",
        "",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;I)V",
        "getKind",
        "()I",
        "active",
        "",
        "getActive",
        "()Z",
        "setActive",
        "(Z)V",
        "p",
        "Landroid/graphics/Paint;",
        "onDraw",
        "",
        "c",
        "Landroid/graphics/Canvas;",
        "dispatchSetPressed",
        "pressed",
        "onTouchEvent",
        "e",
        "Landroid/view/MotionEvent;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private active:Z

.field private final kind:I

.field private final p:Landroid/graphics/Paint;

.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/content/Context;I)V
    .registers 6
    .param p1, "this$0"    # Lcom/exampletest/mobilestudiotest/ui/PlayHud;
    .param p2, "ctx"    # Landroid/content/Context;
    .param p3, "kind"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "I)V"
        }
    .end annotation

    const-string v0, "ctx"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 157
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput p3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->kind:I

    .line 158
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->active:Z

    .line 159
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    .line 160
    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setClickable(Z)V

    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->kind:I

    packed-switch v0, :pswitch_data_2c

    const-string v0, "Leaderboard"

    goto :goto_26

    :pswitch_21
    const-string v0, "Chat"

    goto :goto_26

    :pswitch_24
    const-string v0, "Roblox menu"

    :goto_26
    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 157
    return-void

    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_24
        :pswitch_21
    .end packed-switch
.end method


# virtual methods
.method protected dispatchSetPressed(Z)V
    .registers 2
    .param p1, "pressed"    # Z

    .line 191
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->invalidate()V

    return-void
.end method

.method public final getActive()Z
    .registers 2

    .line 158
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->active:Z

    return v0
.end method

.method public final getKind()I
    .registers 2

    .line 157
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->kind:I

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 18
    .param p1, "c"    # Landroid/graphics/Canvas;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "c"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 162
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->getWidth()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float v9, v2, v3

    .local v9, "cx":F
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->getHeight()I

    move-result v2

    int-to-float v2, v2

    div-float v10, v2, v3

    .local v10, "cy":F
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float v11, v2, v3

    .line 163
    .local v11, "r":F
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->isPressed()Z

    move-result v4

    if-eqz v4, :cond_32

    const/high16 v4, -0x4d000000

    goto :goto_34

    :cond_32
    const/high16 v4, -0x74000000

    :goto_34
    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 164
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v1, v9, v10, v11, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 165
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    const/4 v4, -0x1

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 166
    iget v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->kind:I

    const/16 v4, 0x96

    const/16 v12, 0xff

    const/high16 v13, 0x41000000    # 8.0f

    const/high16 v14, 0x41200000    # 10.0f

    const/high16 v5, 0x41100000    # 9.0f

    const/high16 v15, 0x40800000    # 4.0f

    packed-switch v2, :pswitch_data_22a

    .line 183
    move v6, v3

    iget-boolean v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->active:Z

    if-nez v2, :cond_169

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setAlpha(I)V

    goto/16 :goto_169

    .line 177
    :pswitch_5f
    iget-boolean v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->active:Z

    if-nez v2, :cond_68

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 178
    :cond_68
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v2

    mul-float/2addr v2, v5

    sub-float v2, v9, v2

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v3

    const/high16 v4, 0x40e00000    # 7.0f

    mul-float/2addr v3, v4

    sub-float v3, v10, v3

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v4

    mul-float/2addr v4, v5

    add-float/2addr v4, v9

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v5

    const/high16 v6, 0x40a00000    # 5.0f

    mul-float/2addr v5, v6

    add-float/2addr v5, v10

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v6

    mul-float/2addr v6, v15

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v15

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 179
    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    .line 513
    move-object v4, v2

    .local v4, "$this$onDraw_u24lambda_u240\\1":Landroid/graphics/Path;
    const/4 v5, 0x0

    .line 179
    .local v5, "$i$a$-apply-PlayHud$TopButton$onDraw$1\\1\\179\\0":I
    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v6

    mul-float/2addr v6, v15

    sub-float v6, v9, v6

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v15

    add-float/2addr v7, v10

    invoke-virtual {v4, v6, v7}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v6

    sub-float v6, v9, v7

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v14

    add-float/2addr v7, v10

    invoke-virtual {v4, v6, v7}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v6

    add-float/2addr v7, v9

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v3

    mul-float/2addr v3, v15

    add-float/2addr v3, v10

    invoke-virtual {v4, v7, v3}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v4}, Landroid/graphics/Path;->close()V

    .end local v4    # "$this$onDraw_u24lambda_u240\\1":Landroid/graphics/Path;
    .end local v5    # "$i$a$-apply-PlayHud$TopButton$onDraw$1\\1\\179\\0":I
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 180
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v2, v12}, Landroid/graphics/Paint;->setAlpha(I)V

    goto/16 :goto_229

    .line 168
    :pswitch_ec
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v4

    const v5, 0x40266666    # 2.6f

    mul-float/2addr v4, v5

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 169
    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    const/high16 v2, 0x41700000    # 15.0f

    invoke-virtual {v1, v2, v9, v10}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 170
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v2

    mul-float v12, v2, v13

    .line 171
    .local v12, "s":F
    sub-float v2, v9, v12

    move v6, v3

    sub-float v3, v10, v12

    add-float v4, v9, v12

    add-float v5, v10, v12

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v6

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v8}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v8

    mul-float/2addr v8, v6

    move v6, v7

    move v7, v8

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 172
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 173
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v1

    const v2, 0x400ccccd    # 2.2f

    mul-float/2addr v1, v2

    sub-float v1, v9, v1

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v3

    mul-float/2addr v3, v2

    sub-float v3, v10, v3

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v4

    mul-float/2addr v4, v2

    add-float/2addr v4, v9

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v5

    mul-float/2addr v5, v2

    add-float/2addr v5, v10

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    move v2, v1

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 174
    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    .end local v12    # "s":F
    goto/16 :goto_229

    .line 184
    :cond_169
    :goto_169
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v2

    mul-float/2addr v2, v15

    sub-float v2, v9, v2

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v3

    mul-float/2addr v3, v15

    sub-float v3, v10, v3

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v4

    const v7, 0x404ccccd    # 3.2f

    mul-float/2addr v4, v7

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v7}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v2

    const/high16 v3, 0x40900000    # 4.5f

    mul-float/2addr v2, v3

    add-float/2addr v2, v9

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v3

    const/high16 v4, 0x40400000    # 3.0f

    mul-float/2addr v3, v4

    sub-float v3, v10, v3

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v4

    const v7, 0x40333333    # 2.8f

    mul-float/2addr v4, v7

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v7}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 185
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v2

    mul-float/2addr v2, v14

    sub-float v2, v9, v2

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v3

    const/high16 v4, 0x3f000000    # 0.5f

    mul-float/2addr v3, v4

    add-float/2addr v3, v10

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v4

    mul-float/2addr v4, v6

    add-float/2addr v4, v9

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v6

    mul-float/2addr v6, v5

    add-float v5, v10, v6

    iget-object v6, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v6

    mul-float/2addr v6, v15

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v15

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 186
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v1

    const/4 v2, 0x0

    mul-float/2addr v1, v2

    add-float v2, v9, v1

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v1

    const/high16 v3, 0x3fc00000    # 1.5f

    mul-float/2addr v1, v3

    add-float v3, v10, v1

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v1

    mul-float/2addr v1, v14

    add-float v4, v9, v1

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v1

    mul-float/2addr v1, v13

    add-float v5, v10, v1

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v1

    const/high16 v6, 0x40600000    # 3.5f

    mul-float/2addr v1, v6

    iget-object v7, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->this$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v7}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->access$getD$p(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)F

    move-result v7

    mul-float/2addr v7, v6

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    move v6, v1

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 187
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->p:Landroid/graphics/Paint;

    invoke-virtual {v1, v12}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 190
    :goto_229
    return-void

    :pswitch_data_22a
    .packed-switch 0x0
        :pswitch_ec
        :pswitch_5f
    .end packed-switch
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 3
    .param p1, "e"    # Landroid/view/MotionEvent;

    const-string v0, "e"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 193
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    .local v0, "r":Z
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->invalidate()V

    return v0
.end method

.method public final setActive(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 158
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$TopButton;->active:Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "openMenu$lambda$26$lambda$25$lambda$24"
    proto = "(ILjava/util/ArrayList;Landroid/widget/FrameLayout;Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Ljava/util/ArrayList;

.field public final synthetic f$2:Landroid/widget/FrameLayout;

.field public final synthetic f$3:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(ILjava/util/ArrayList;Landroid/widget/FrameLayout;Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;->f$0:I

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;->f$1:Ljava/util/ArrayList;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;->f$2:Landroid/widget/FrameLayout;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;->f$3:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 6

    .line 0
    iget v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;->f$0:I

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;->f$1:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;->f$2:Landroid/widget/FrameLayout;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda0;->f$3:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0, v1, v2, v3, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu$lambda$26$lambda$25$lambda$24(ILjava/util/ArrayList;Landroid/widget/FrameLayout;Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "openMenu$lambda$32"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

.field public final synthetic f$1:Landroid/widget/FrameLayout;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda1;->f$1:Landroid/widget/FrameLayout;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda1;->f$1:Landroid/widget/FrameLayout;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu$lambda$32(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda10 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda10)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "settingsPage$lambda$69"
    proto = "(I)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$lambda$69(I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda11 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda11)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "settingsPage$lambda$70"
    proto = "(I)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$lambda$70(I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda12 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda12)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "settingsPage$lambda$71"
    proto = "(F)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$lambda$71(F)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda13 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda13)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "settingsPage$lambda$72"
    proto = "(F)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$lambda$72(F)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda14 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda14)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "settingsPage$lambda$73"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda14;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda14;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$lambda$73(Lcom/exampletest/mobilestudiotest/ui/PlayHud;F)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda15 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda15)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "settingsPage$lambda$74"
    proto = "(I)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$lambda$74(I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda16 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda16)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "confirmPage$lambda$45"
    proto = "(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/FrameLayout;

.field public final synthetic f$1:Landroid/widget/FrameLayout;

.field public final synthetic f$2:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;Lkotlin/jvm/functions/Function0;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;->f$0:Landroid/widget/FrameLayout;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;->f$1:Landroid/widget/FrameLayout;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;->f$2:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;->f$0:Landroid/widget/FrameLayout;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;->f$1:Landroid/widget/FrameLayout;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda16;->f$2:Lkotlin/jvm/functions/Function0;

    invoke-static {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->confirmPage$lambda$45(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda17 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda17)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "confirmPage$lambda$47"
    proto = "(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/FrameLayout;

.field public final synthetic f$1:Landroid/widget/FrameLayout;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda17;->f$0:Landroid/widget/FrameLayout;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda17;->f$1:Landroid/widget/FrameLayout;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda17;->f$0:Landroid/widget/FrameLayout;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda17;->f$1:Landroid/widget/FrameLayout;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->confirmPage$lambda$47(Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda18 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda18)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "settingsPage$selector$arrow$lambda$64$lambda$63"
    proto = "(Lkotlin/jvm/internal/Ref$IntRef;ILjava/util/List;Landroid/widget/TextView;Lkotlin/jvm/functions/Function1;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/internal/Ref$IntRef;

.field public final synthetic f$1:I

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Landroid/widget/TextView;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/internal/Ref$IntRef;ILjava/util/List;Landroid/widget/TextView;Lkotlin/jvm/functions/Function1;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$0:Lkotlin/jvm/internal/Ref$IntRef;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$1:I

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$2:Ljava/util/List;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$3:Landroid/widget/TextView;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$4:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 8

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$0:Lkotlin/jvm/internal/Ref$IntRef;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$1:I

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$2:Ljava/util/List;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$3:Landroid/widget/TextView;

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda18;->f$4:Lkotlin/jvm/functions/Function1;

    move-object v5, p1

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$selector$arrow$lambda$64$lambda$63(Lkotlin/jvm/internal/Ref$IntRef;ILjava/util/List;Landroid/widget/TextView;Lkotlin/jvm/functions/Function1;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda19 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda19)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "pill$lambda$18$lambda$17"
    proto = "(Lkotlin/jvm/functions/Function0;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda19;->f$0:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda19;->f$0:Lkotlin/jvm/functions/Function0;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->pill$lambda$18$lambda$17(Lkotlin/jvm/functions/Function0;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "openMenu$lambda$35"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

.field public final synthetic f$1:Landroid/widget/FrameLayout;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda2;->f$1:Landroid/widget/FrameLayout;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda2;->f$1:Landroid/widget/FrameLayout;

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu$lambda$35(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/FrameLayout;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda20 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda20)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "openMenu$lambda$35$lambda$34"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda20;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda20;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu$lambda$35$lambda$34(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda21 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda21)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "openMenu$lambda$32$lambda$31"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda21;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda21;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu$lambda$32$lambda$31(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "openMenu$lambda$37"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->openMenu$lambda$37(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "_init_$lambda$3"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->_init_$lambda$3(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "_init_$lambda$4"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->_init_$lambda$4(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "_init_$lambda$5"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->_init_$lambda$5(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/TextView$OnEditorActionListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "lambda$10$lambda$8"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->lambda$10$lambda$8(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda8 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "lambda$10$lambda$9"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;Z)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    invoke-static {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->lambda$10$lambda$9(Lcom/exampletest/mobilestudiotest/ui/PlayHud;Landroid/view/View;Z)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda9 (com.exampletest.mobilestudiotest.ui.PlayHud$$ExternalSyntheticLambda9)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/PlayHud;"
    method = "settingsPage$lambda$68"
    proto = "(Lcom/exampletest/mobilestudiotest/ui/PlayHud;I)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/ui/PlayHud;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/ui/PlayHud;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$lambda$68(Lcom/exampletest/mobilestudiotest/ui/PlayHud;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.ui.PlayHud$settingsPage$slider$1$1 (com.exampletest.mobilestudiotest.ui.PlayHud$settingsPage$slider$1$1)
.class public final Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;
.super Ljava/lang/Object;
.source "PlayHud.kt"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/ui/PlayHud;->settingsPage$slider(Lcom/exampletest/mobilestudiotest/ui/PlayHud;FFFLkotlin/jvm/functions/Function1;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000%\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\"\u0010\u0002\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\tH\u0016J\u0012\u0010\n\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0016J\u0012\u0010\u000b\u001a\u00020\u00032\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0016\u00a8\u0006\u000c"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1",
        "Landroid/widget/SeekBar$OnSeekBarChangeListener;",
        "onProgressChanged",
        "",
        "s",
        "Landroid/widget/SeekBar;",
        "pr",
        "",
        "fromUser",
        "",
        "onStartTrackingTouch",
        "onStopTrackingTouch",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $max:F

.field final synthetic $min:F

.field final synthetic $onSet:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Float;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/jvm/functions/Function1;FF)V
    .registers 4
    .param p1, "$onSet"    # Lkotlin/jvm/functions/Function1;
    .param p2, "$min"    # F
    .param p3, "$max"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Float;",
            "Lkotlin/Unit;",
            ">;FF)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;->$onSet:Lkotlin/jvm/functions/Function1;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;->$min:F

    iput p3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;->$max:F

    .line 470
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 8
    .param p1, "s"    # Landroid/widget/SeekBar;
    .param p2, "pr"    # I
    .param p3, "fromUser"    # Z

    .line 471
    if-eqz p3, :cond_18

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;->$onSet:Lkotlin/jvm/functions/Function1;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;->$min:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;->$max:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/ui/PlayHud$settingsPage$slider$1$1;->$min:F

    sub-float/2addr v2, v3

    int-to-float v3, p2

    mul-float/2addr v2, v3

    const/high16 v3, 0x42c80000    # 100.0f

    div-float/2addr v2, v3

    add-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_18
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2
    .param p1, "s"    # Landroid/widget/SeekBar;

    .line 472
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2
    .param p1, "s"    # Landroid/widget/SeekBar;

    .line 473
    return-void
.end method
