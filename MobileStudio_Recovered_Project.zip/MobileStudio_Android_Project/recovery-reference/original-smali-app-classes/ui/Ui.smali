###### Class com.exampletest.mobilestudiotest.ui.Ui (com.exampletest.mobilestudiotest.ui.Ui)
.class public final Lcom/exampletest/mobilestudiotest/ui/Ui;
.super Ljava/lang/Object;
.source "Ui.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;,
        Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nUi.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Ui.kt\ncom/exampletest/mobilestudiotest/ui/Ui\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,249:1\n1#2:250\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u008c\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008#\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0010\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0007\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0002vwB\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u00106\u001a\u0002072\u0006\u00108\u001a\u00020-J\u000e\u0010;\u001a\u00020<2\u0006\u0010=\u001a\u00020\u0005J\u001e\u0010>\u001a\u00020\u00052\u0006\u0010?\u001a\u00020\u00052\u0006\u0010@\u001a\u00020\u00052\u0006\u00108\u001a\u00020<J\u000e\u0010C\u001a\u00020D2\u0006\u0010E\u001a\u00020DJ\u0016\u0010F\u001a\u00020\u00052\u0006\u0010E\u001a\u00020D2\u0006\u0010G\u001a\u00020<J\u0016\u0010F\u001a\u00020\u00052\u0006\u0010G\u001a\u00020H2\u0006\u0010I\u001a\u00020<J6\u0010J\u001a\u00020K2\u0006\u0010E\u001a\u00020D2\u0008\u0008\u0002\u0010L\u001a\u00020M2\u0008\u0008\u0002\u0010N\u001a\u00020<2\u0008\u0008\u0002\u0010O\u001a\u00020\u00052\u0008\u0008\u0002\u0010P\u001a\u00020)J \u0010Q\u001a\u00020R2\u0006\u0010E\u001a\u00020D2\u0006\u0010S\u001a\u00020\u00052\u0008\u0008\u0002\u0010T\u001a\u00020<J4\u0010U\u001a\u00020K2\u0006\u0010E\u001a\u00020D2\u0006\u0010V\u001a\u00020M2\u0008\u0008\u0002\u0010S\u001a\u00020\u00052\u0012\u0010W\u001a\u000e\u0012\u0004\u0012\u00020H\u0012\u0004\u0012\u0002070XJ>\u0010Y\u001a\u00020K2\u0006\u0010E\u001a\u00020D2\u0008\u0010Z\u001a\u0004\u0018\u00010[2\u0006\u0010V\u001a\u00020M2\u0008\u0008\u0002\u0010S\u001a\u00020\u00052\u0012\u0010W\u001a\u000e\u0012\u0004\u0012\u00020H\u0012\u0004\u0012\u0002070XJ2\u0010\\\u001a\u00020]2\u0006\u0010E\u001a\u00020D2\u0006\u0010Z\u001a\u00020[2\u0006\u0010V\u001a\u00020M2\u0012\u0010W\u001a\u000e\u0012\u0004\u0012\u00020H\u0012\u0004\u0012\u0002070XJ6\u0010^\u001a\u00020_2\u0006\u0010E\u001a\u00020D2\u0008\u0008\u0002\u0010\u0004\u001a\u00020M2\u0008\u0008\u0002\u0010`\u001a\u00020M2\u0008\u0008\u0002\u0010a\u001a\u00020)2\u0008\u0008\u0002\u0010b\u001a\u00020)J\"\u0010c\u001a\u00020]2\u0006\u0010E\u001a\u00020D2\u0006\u0010d\u001a\u00020M2\n\u0008\u0002\u0010Z\u001a\u0004\u0018\u00010[J*\u0010e\u001a\u00020K2\u0006\u0010E\u001a\u00020D2\u0006\u0010f\u001a\u00020M2\u0012\u0010W\u001a\u000e\u0012\u0004\u0012\u00020H\u0012\u0004\u0012\u0002070XJ4\u0010g\u001a\u00020h2\u0006\u0010E\u001a\u00020D2\u0006\u0010Z\u001a\u00020[2\u0008\u0008\u0002\u0010N\u001a\u00020<2\u0012\u0010W\u001a\u000e\u0012\u0004\u0012\u00020H\u0012\u0004\u0012\u0002070XJ \u0010i\u001a\u00020j2\u0006\u0010k\u001a\u00020\u00052\u0006\u0010l\u001a\u00020\u00052\u0008\u0008\u0002\u0010m\u001a\u00020<J\u0018\u0010p\u001a\u00020H2\u0006\u0010E\u001a\u00020D2\u0008\u0008\u0002\u0010q\u001a\u00020)J\u0016\u0010Z\u001a\u00020[2\u0006\u0010E\u001a\u00020D2\u0006\u0010r\u001a\u00020sJ\u0016\u0010t\u001a\u00020[2\u0006\u0010E\u001a\u00020D2\u0006\u0010u\u001a\u00020MR\u001e\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008R\u001e\u0010\t\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u0008R\u001e\u0010\u000b\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\u0008R\u001e\u0010\r\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u0008R\u001e\u0010\u000f\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u0008R\u001e\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0008R\u001e\u0010\u0013\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0008R\u001e\u0010\u0015\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0008R\u001e\u0010\u0017\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0018\u0010\u0008R\u001e\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001a\u0010\u0008R\u001e\u0010\u001b\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001c\u0010\u0008R\u001e\u0010\u001d\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001e\u0010\u0008R\u001e\u0010\u001f\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008 \u0010\u0008R\u001e\u0010!\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\"\u0010\u0008R\u001e\u0010#\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008$\u0010\u0008R\u001e\u0010%\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008&\u0010\u0008R\u001e\u0010\'\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008(\u0010\u0008R\u001e\u0010*\u001a\u00020)2\u0006\u0010\u0004\u001a\u00020)@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008+\u0010,R\u001e\u0010.\u001a\u00020-2\u0006\u0010\u0004\u001a\u00020-@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008/\u00100R\u000e\u00101\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u0011\u00109\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008:\u0010\u0008R\u0011\u0010A\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008B\u0010\u0008R\u000e\u0010n\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010o\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006x"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/Ui;",
        "",
        "<init>",
        "()V",
        "value",
        "",
        "BG",
        "getBG",
        "()I",
        "PANEL",
        "getPANEL",
        "HEADER",
        "getHEADER",
        "TOPBAR",
        "getTOPBAR",
        "RIBBON",
        "getRIBBON",
        "BORDER",
        "getBORDER",
        "TEXT",
        "getTEXT",
        "DIM",
        "getDIM",
        "ACCENT",
        "getACCENT",
        "SELECT",
        "getSELECT",
        "HOVER",
        "getHOVER",
        "INPUT",
        "getINPUT",
        "ROW_ALT",
        "getROW_ALT",
        "EDITOR_BG",
        "getEDITOR_BG",
        "EDITOR_GUTTER",
        "getEDITOR_GUTTER",
        "EDITOR_TEXT",
        "getEDITOR_TEXT",
        "CARD",
        "getCARD",
        "",
        "LIGHT",
        "getLIGHT",
        "()Z",
        "Lcom/exampletest/mobilestudiotest/core/Theme;",
        "theme",
        "getTheme",
        "()Lcom/exampletest/mobilestudiotest/core/Theme;",
        "WARN",
        "ERROR",
        "INFO",
        "PLAY",
        "STOP",
        "applyTheme",
        "",
        "t",
        "SELECT_TEXT",
        "getSELECT_TEXT",
        "luminance",
        "",
        "c",
        "blend",
        "a",
        "b",
        "dialogTheme",
        "getDialogTheme",
        "popupContext",
        "Landroid/content/Context;",
        "ctx",
        "dp",
        "v",
        "Landroid/view/View;",
        "d",
        "text",
        "Landroid/widget/TextView;",
        "s",
        "",
        "size",
        "color",
        "bold",
        "rippleBg",
        "Landroid/graphics/drawable/RippleDrawable;",
        "base",
        "radius",
        "button",
        "label",
        "onClick",
        "Lkotlin/Function1;",
        "iconTextButton",
        "icon",
        "Landroid/graphics/drawable/Drawable;",
        "toolButton",
        "Landroid/widget/LinearLayout;",
        "input",
        "Landroid/widget/EditText;",
        "hint",
        "numeric",
        "multiLine",
        "header",
        "title",
        "smallIconButton",
        "glyph",
        "iconButton",
        "Landroid/widget/ImageView;",
        "lp",
        "Landroid/widget/LinearLayout$LayoutParams;",
        "w",
        "h",
        "weight",
        "MATCH",
        "WRAP",
        "divider",
        "vertical",
        "i",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "iconFor",
        "cls",
        "CheckBoxDrawable",
        "ArrowDrawable",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static ACCENT:I = 0x0

.field private static BG:I = 0x0

.field private static BORDER:I = 0x0

.field private static CARD:I = 0x0

.field private static DIM:I = 0x0

.field private static EDITOR_BG:I = 0x0

.field private static EDITOR_GUTTER:I = 0x0

.field private static EDITOR_TEXT:I = 0x0

.field public static final ERROR:I = -0xaaab

.field private static HEADER:I = 0x0

.field private static HOVER:I = 0x0

.field public static final INFO:I = -0x934901

.field private static INPUT:I = 0x0

.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

.field private static LIGHT:Z = false

.field public static final MATCH:I = -0x1

.field private static PANEL:I = 0x0

.field public static final PLAY:I = -0xd174a9

.field private static RIBBON:I = 0x0

.field private static ROW_ALT:I = 0x0

.field private static SELECT:I = 0x0

.field public static final STOP:I = -0x3fc6d5

.field private static TEXT:I = 0x0

.field private static TOPBAR:I = 0x0

.field public static final WARN:I = -0x5b00

.field public static final WRAP:I = -0x2

.field private static theme:Lcom/exampletest/mobilestudiotest/core/Theme;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    .line 30
    const v0, -0xd1d1d2

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->BG:I

    .line 31
    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->PANEL:I

    .line 32
    const v0, -0xcacacb

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->HEADER:I

    .line 33
    const v1, -0xdadadb

    sput v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->TOPBAR:I

    .line 34
    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->RIBBON:I

    .line 35
    const v0, -0xe5e5e6

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->BORDER:I

    .line 36
    const v0, -0x333334

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->TEXT:I

    .line 37
    const v0, -0x717172

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->DIM:I

    .line 38
    const v0, -0xf4a551

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->ACCENT:I

    .line 39
    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->SELECT:I

    .line 40
    const v0, -0xbdbdbe

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->HOVER:I

    .line 41
    sput v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->INPUT:I

    .line 42
    const v0, -0xcccccd

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->ROW_ALT:I

    .line 43
    const v0, -0xe1e1e2

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_BG:I

    .line 44
    const v0, -0xdadada

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_GUTTER:I

    .line 45
    const v0, -0x1f1f20

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_TEXT:I

    .line 46
    const v0, -0xc7c7c8

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->CARD:I

    .line 48
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/Theme;->Companion:Lcom/exampletest/mobilestudiotest/core/Theme$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Theme$Companion;->getDARK()Lcom/exampletest/mobilestudiotest/core/Theme;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->theme:Lcom/exampletest/mobilestudiotest/core/Theme;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final blend$ch(IFII)I
    .registers 6
    .param p0, "$a"    # I
    .param p1, "$t"    # F
    .param p2, "$b"    # I
    .param p3, "s"    # I

    .line 70
    shr-int v0, p0, p3

    and-int/lit16 v0, v0, 0xff

    int-to-float v0, v0

    const/high16 v1, 0x3f800000    # 1.0f

    sub-float/2addr v1, p1

    mul-float/2addr v0, v1

    shr-int v1, p2, p3

    and-int/lit16 v1, v1, 0xff

    int-to-float v1, v1

    mul-float/2addr v1, p1

    add-float/2addr v0, v1

    float-to-int v0, v0

    and-int/lit16 v0, v0, 0xff

    shl-int/2addr v0, p3

    return v0
.end method

.method public static synthetic button$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;ILkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/TextView;
    .registers 7

    .line 99
    and-int/lit8 p5, p5, 0x4

    if-eqz p5, :cond_6

    sget p3, Lcom/exampletest/mobilestudiotest/ui/Ui;->HOVER:I

    :cond_6
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->button(Landroid/content/Context;Ljava/lang/String;ILkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object p0

    return-object p0
.end method

.method static final button$lambda$4$lambda$3(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V
    .registers 2
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function1;
    .param p1, "p0"    # Landroid/view/View;

    .line 106
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static synthetic divider$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;ZILjava/lang/Object;)Landroid/view/View;
    .registers 5

    .line 195
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_5

    const/4 p2, 0x0

    :cond_5
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->divider(Landroid/content/Context;Z)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic header$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;Landroid/graphics/drawable/Drawable;ILjava/lang/Object;)Landroid/widget/LinearLayout;
    .registers 6

    .line 160
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_5

    const/4 p3, 0x0

    :cond_5
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->header(Landroid/content/Context;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)Landroid/widget/LinearLayout;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic iconButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/ImageView;
    .registers 7

    .line 180
    and-int/lit8 p5, p5, 0x4

    if-eqz p5, :cond_6

    const/high16 p3, 0x41f00000    # 30.0f

    :cond_6
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton(Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;)Landroid/widget/ImageView;

    move-result-object p0

    return-object p0
.end method

.method static final iconButton$lambda$21$lambda$20(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V
    .registers 2
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function1;
    .param p1, "p0"    # Landroid/view/View;

    .line 187
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static synthetic iconTextButton$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Landroid/graphics/drawable/Drawable;Ljava/lang/String;ILkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroid/widget/TextView;
    .registers 14

    .line 110
    and-int/lit8 p6, p6, 0x8

    if-eqz p6, :cond_6

    sget p4, Lcom/exampletest/mobilestudiotest/ui/Ui;->HOVER:I

    :cond_6
    move v4, p4

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, p5

    invoke-virtual/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconTextButton(Landroid/content/Context;Landroid/graphics/drawable/Drawable;Ljava/lang/String;ILkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic input$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZILjava/lang/Object;)Landroid/widget/EditText;
    .registers 9

    .line 142
    and-int/lit8 p7, p6, 0x2

    const-string v0, ""

    if-eqz p7, :cond_7

    move-object p2, v0

    :cond_7
    and-int/lit8 p7, p6, 0x4

    if-eqz p7, :cond_c

    move-object p3, v0

    :cond_c
    and-int/lit8 p7, p6, 0x8

    const/4 v0, 0x0

    if-eqz p7, :cond_12

    move p4, v0

    :cond_12
    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_17

    move p5, v0

    :cond_17
    invoke-virtual/range {p0 .. p5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->input(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZ)Landroid/widget/EditText;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic lp$default(Lcom/exampletest/mobilestudiotest/ui/Ui;IIFILjava/lang/Object;)Landroid/widget/LinearLayout$LayoutParams;
    .registers 6

    .line 191
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_5

    const/4 p3, 0x0

    :cond_5
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->lp(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic rippleBg$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;IFILjava/lang/Object;)Landroid/graphics/drawable/RippleDrawable;
    .registers 6

    .line 93
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_6

    const/high16 p3, 0x40800000    # 4.0f

    :cond_6
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->rippleBg(Landroid/content/Context;IF)Landroid/graphics/drawable/RippleDrawable;

    move-result-object p0

    return-object p0
.end method

.method static final smallIconButton$lambda$19$lambda$18(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V
    .registers 2
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function1;
    .param p1, "p0"    # Landroid/view/View;

    .line 176
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static synthetic text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;
    .registers 14

    .line 84
    and-int/lit8 p7, p6, 0x2

    if-eqz p7, :cond_6

    const-string p2, ""

    :cond_6
    move-object v2, p2

    and-int/lit8 p2, p6, 0x4

    if-eqz p2, :cond_d

    const/high16 p3, 0x41500000    # 13.0f

    :cond_d
    move v3, p3

    and-int/lit8 p2, p6, 0x8

    if-eqz p2, :cond_14

    sget p4, Lcom/exampletest/mobilestudiotest/ui/Ui;->TEXT:I

    :cond_14
    move v4, p4

    and-int/lit8 p6, p6, 0x10

    if-eqz p6, :cond_1a

    const/4 p5, 0x0

    :cond_1a
    move v5, p5

    move-object v0, p0

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p0

    return-object p0
.end method

.method static final toolButton$lambda$12$lambda$11(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V
    .registers 2
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function1;
    .param p1, "p0"    # Landroid/view/View;

    .line 139
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final applyTheme(Lcom/exampletest/mobilestudiotest/core/Theme;)V
    .registers 5
    .param p1, "t"    # Lcom/exampletest/mobilestudiotest/core/Theme;

    const-string v0, "t"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    sput-object p1, Lcom/exampletest/mobilestudiotest/ui/Ui;->theme:Lcom/exampletest/mobilestudiotest/core/Theme;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getLight()Z

    move-result v0

    sput-boolean v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->LIGHT:Z

    .line 58
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getBg()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->BG:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getPanel()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->PANEL:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getHeader()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->HEADER:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getTopbar()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->TOPBAR:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getRibbon()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->RIBBON:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getBorder()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->BORDER:I

    .line 59
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getText()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->TEXT:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getDim()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->DIM:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getAccent()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->ACCENT:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getSelect()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->SELECT:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getHover()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->HOVER:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getInput()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INPUT:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getRowAlt()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->ROW_ALT:I

    .line 60
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getEditorBg()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_BG:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getEditorGutter()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_GUTTER:I

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getEditorText()I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_TEXT:I

    .line 61
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getPanel()I

    move-result v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/core/Theme;->getLight()Z

    move-result v1

    if-eqz v1, :cond_7a

    const/high16 v1, -0x1000000

    goto :goto_7b

    :cond_7a
    const/4 v1, -0x1

    :goto_7b
    const v2, 0x3d75c28f    # 0.06f

    invoke-virtual {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend(IIF)I

    move-result v0

    sput v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->CARD:I

    .line 62
    return-void
.end method

.method public final blend(IIF)I
    .registers 6
    .param p1, "a"    # I
    .param p2, "b"    # I
    .param p3, "t"    # F

    .line 71
    const/16 v0, 0x10

    invoke-static {p1, p3, p2, v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend$ch(IFII)I

    move-result v0

    const/high16 v1, -0x1000000

    or-int/2addr v0, v1

    const/16 v1, 0x8

    invoke-static {p1, p3, p2, v1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend$ch(IFII)I

    move-result v1

    or-int/2addr v0, v1

    const/4 v1, 0x0

    invoke-static {p1, p3, p2, v1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->blend$ch(IFII)I

    move-result v1

    or-int/2addr v0, v1

    return v0
.end method

.method public final button(Landroid/content/Context;Ljava/lang/String;ILkotlin/jvm/functions/Function1;)Landroid/widget/TextView;
    .registers 14
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "label"    # Ljava/lang/String;
    .param p3, "base"    # I
    .param p4, "onClick"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "I",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroid/view/View;",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/widget/TextView;"
        }
    .end annotation

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "label"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onClick"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    const/16 v7, 0x18

    const/4 v8, 0x0

    const/high16 v4, 0x41500000    # 13.0f

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "label":Ljava/lang/String;
    .local v2, "ctx":Landroid/content/Context;
    .local v3, "label":Ljava/lang/String;
    invoke-static/range {v1 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object p1

    move-object v1, v2

    .end local v2    # "ctx":Landroid/content/Context;
    .end local v3    # "label":Ljava/lang/String;
    .local v1, "ctx":Landroid/content/Context;
    .restart local p2    # "label":Ljava/lang/String;
    move-object v6, p1

    .local v6, "$this$button_u24lambda_u244\\1":Landroid/widget/TextView;
    const/4 v7, 0x0

    .line 101
    .local v7, "$i$a$-apply-Ui$button$1\\1\\100\\0":I
    const/16 v0, 0x11

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 102
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v2, 0x41200000    # 10.0f

    invoke-virtual {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    .line 103
    .local v8, "p\\1":I
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v2, 0x40c00000    # 6.0f

    invoke-virtual {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-virtual {v6, v8, v0, v8, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 104
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, 0x0

    move v2, p3

    .end local p3    # "base":I
    .local v2, "base":I
    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->rippleBg$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;IFILjava/lang/Object;)Landroid/graphics/drawable/RippleDrawable;

    move-result-object p3

    check-cast p3, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v6, p3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 105
    const/4 p3, 0x1

    invoke-virtual {v6, p3}, Landroid/widget/TextView;->setClickable(Z)V

    .line 106
    new-instance p3, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda1;

    invoke-direct {p3, p4}, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda1;-><init>(Lkotlin/jvm/functions/Function1;)V

    invoke-virtual {v6, p3}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 107
    nop

    .line 100
    .end local v6    # "$this$button_u24lambda_u244\\1":Landroid/widget/TextView;
    .end local v7    # "$i$a$-apply-Ui$button$1\\1\\100\\0":I
    .end local v8    # "p\\1":I
    nop

    .line 107
    return-object p1
.end method

.method public final divider(Landroid/content/Context;Z)Landroid/view/View;
    .registers 10
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "vertical"    # Z

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$divider_u24lambda_u2422\\1":Landroid/view/View;
    const/4 v2, 0x0

    .line 196
    .local v2, "$i$a$-apply-Ui$divider$1\\1\\195\\0":I
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->BORDER:I

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 197
    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, -0x1

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v6, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    if-eqz p2, :cond_24

    invoke-direct {v5, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    goto :goto_27

    :cond_24
    invoke-direct {v5, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    :goto_27
    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 198
    nop

    .line 195
    .end local v1    # "$this$divider_u24lambda_u2422\\1":Landroid/view/View;
    .end local v2    # "$i$a$-apply-Ui$divider$1\\1\\195\\0":I
    nop

    .line 198
    return-object v0
.end method

.method public final dp(Landroid/content/Context;F)I
    .registers 5
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "v"    # F

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v1, p2, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    float-to-int v0, v0

    return v0
.end method

.method public final dp(Landroid/view/View;F)I
    .registers 5
    .param p1, "v"    # Landroid/view/View;
    .param p2, "d"    # F

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "getContext(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v0, p2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    return v0
.end method

.method public final getACCENT()I
    .registers 2

    .line 38
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->ACCENT:I

    return v0
.end method

.method public final getBG()I
    .registers 2

    .line 30
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->BG:I

    return v0
.end method

.method public final getBORDER()I
    .registers 2

    .line 35
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->BORDER:I

    return v0
.end method

.method public final getCARD()I
    .registers 2

    .line 46
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->CARD:I

    return v0
.end method

.method public final getDIM()I
    .registers 2

    .line 37
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->DIM:I

    return v0
.end method

.method public final getDialogTheme()I
    .registers 2

    .line 75
    sget-boolean v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->LIGHT:Z

    if-eqz v0, :cond_8

    const v0, 0x103023a

    goto :goto_b

    :cond_8
    const v0, 0x1030226

    :goto_b
    return v0
.end method

.method public final getEDITOR_BG()I
    .registers 2

    .line 43
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_BG:I

    return v0
.end method

.method public final getEDITOR_GUTTER()I
    .registers 2

    .line 44
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_GUTTER:I

    return v0
.end method

.method public final getEDITOR_TEXT()I
    .registers 2

    .line 45
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->EDITOR_TEXT:I

    return v0
.end method

.method public final getHEADER()I
    .registers 2

    .line 32
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->HEADER:I

    return v0
.end method

.method public final getHOVER()I
    .registers 2

    .line 40
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->HOVER:I

    return v0
.end method

.method public final getINPUT()I
    .registers 2

    .line 41
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INPUT:I

    return v0
.end method

.method public final getLIGHT()Z
    .registers 2

    .line 47
    sget-boolean v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->LIGHT:Z

    return v0
.end method

.method public final getPANEL()I
    .registers 2

    .line 31
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->PANEL:I

    return v0
.end method

.method public final getRIBBON()I
    .registers 2

    .line 34
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->RIBBON:I

    return v0
.end method

.method public final getROW_ALT()I
    .registers 2

    .line 42
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->ROW_ALT:I

    return v0
.end method

.method public final getSELECT()I
    .registers 2

    .line 39
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->SELECT:I

    return v0
.end method

.method public final getSELECT_TEXT()I
    .registers 3

    .line 65
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->SELECT:I

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/ui/Ui;->luminance(I)F

    move-result v0

    const v1, 0x3f0ccccd    # 0.55f

    cmpl-float v0, v0, v1

    if-lez v0, :cond_11

    const v0, -0xeeeeef

    goto :goto_12

    :cond_11
    const/4 v0, -0x1

    :goto_12
    return v0
.end method

.method public final getTEXT()I
    .registers 2

    .line 36
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->TEXT:I

    return v0
.end method

.method public final getTOPBAR()I
    .registers 2

    .line 33
    sget v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->TOPBAR:I

    return v0
.end method

.method public final getTheme()Lcom/exampletest/mobilestudiotest/core/Theme;
    .registers 2

    .line 48
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->theme:Lcom/exampletest/mobilestudiotest/core/Theme;

    return-object v0
.end method

.method public final header(Landroid/content/Context;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)Landroid/widget/LinearLayout;
    .registers 17
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "title"    # Ljava/lang/String;
    .param p3, "icon"    # Landroid/graphics/drawable/Drawable;

    move-object/from16 v0, p3

    const-string v1, "ctx"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "title"

    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 160
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v8, v1

    .local v8, "$this$header_u24lambda_u2417\\1":Landroid/widget/LinearLayout;
    const/4 v9, 0x0

    .line 161
    .local v9, "$i$a$-apply-Ui$header$1\\1\\160\\0":I
    const/4 v10, 0x0

    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 162
    const/16 v2, 0x10

    invoke-virtual {v8, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 163
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->HEADER:I

    invoke-virtual {v8, v2}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 164
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v3, 0x41000000    # 8.0f

    invoke-virtual {v2, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v11

    .line 165
    .local v11, "p\\1":I
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v3, 0x40400000    # 3.0f

    invoke-virtual {v2, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x40800000    # 4.0f

    invoke-virtual {v5, p1, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v6, p1, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-virtual {v8, v11, v2, v5, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 166
    if-eqz v0, :cond_78

    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 250
    move-object v3, v2

    .local v3, "$this$header_u24lambda_u2417_u24lambda_u2415\\2":Landroid/widget/ImageView;
    const/4 v5, 0x0

    .line 166
    .local v5, "$i$a$-apply-Ui$header$1$1\\2\\166\\1":I
    invoke-virtual {v3, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .end local v3    # "$this$header_u24lambda_u2417_u24lambda_u2415\\2":Landroid/widget/ImageView;
    .end local v5    # "$i$a$-apply-Ui$header$1$1\\2\\166\\1":I
    check-cast v2, Landroid/view/View;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x41800000    # 16.0f

    invoke-virtual {v5, p1, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7, p1, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-direct {v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 250
    move-object v5, v3

    .local v5, "$this$header_u24lambda_u2417_u24lambda_u2416\\3":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v6, 0x0

    .line 166
    .local v6, "$i$a$-apply-Ui$header$1$2\\3\\166\\1":I
    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v12, 0x40c00000    # 6.0f

    invoke-virtual {v7, p1, v12}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v7

    iput v7, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .end local v5    # "$this$header_u24lambda_u2417_u24lambda_u2416\\3":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6    # "$i$a$-apply-Ui$header$1$2\\3\\166\\1":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 167
    :cond_78
    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->TEXT:I

    const/4 v7, 0x1

    const/high16 v5, 0x41400000    # 12.0f

    move-object v3, p1

    move-object v4, p2

    invoke-virtual/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v3, v10, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v8, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 168
    nop

    .line 160
    .end local v8    # "$this$header_u24lambda_u2417\\1":Landroid/widget/LinearLayout;
    .end local v9    # "$i$a$-apply-Ui$header$1\\1\\160\\0":I
    .end local v11    # "p\\1":I
    nop

    .line 168
    return-object v1
.end method

.method public final icon(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/model/Instance;)Landroid/graphics/drawable/Drawable;
    .registers 5
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "i"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 201
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/ui/Icons;->instance(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0
.end method

.method public final iconButton(Landroid/content/Context;Landroid/graphics/drawable/Drawable;FLkotlin/jvm/functions/Function1;)Landroid/widget/ImageView;
    .registers 15
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "icon"    # Landroid/graphics/drawable/Drawable;
    .param p3, "size"    # F
    .param p4, "onClick"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/graphics/drawable/Drawable;",
            "F",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroid/view/View;",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/widget/ImageView;"
        }
    .end annotation

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "icon"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onClick"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 180
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$iconButton_u24lambda_u2421\\1":Landroid/widget/ImageView;
    const/4 v2, 0x0

    .line 181
    .local v2, "$i$a$-apply-Ui$iconButton$1\\1\\180\\0":I
    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 182
    sget-object v3, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 183
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v4, 0x41900000    # 18.0f

    sub-float v4, p3, v4

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    invoke-virtual {v3, p1, v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    .line 184
    .local v3, "p\\1":I
    invoke-virtual {v1, v3, v3, v3, v3}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 185
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v5, p1

    .end local p1    # "ctx":Landroid/content/Context;
    .local v5, "ctx":Landroid/content/Context;
    invoke-static/range {v4 .. v9}, Lcom/exampletest/mobilestudiotest/ui/Ui;->rippleBg$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;IFILjava/lang/Object;)Landroid/graphics/drawable/RippleDrawable;

    move-result-object p1

    check-cast p1, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, p1}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 186
    const/4 p1, 0x1

    invoke-virtual {v1, p1}, Landroid/widget/ImageView;->setClickable(Z)V

    .line 187
    new-instance p1, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda0;

    invoke-direct {p1, p4}, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/functions/Function1;)V

    invoke-virtual {v1, p1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 188
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v4, v5, p3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v6, v5, p3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-direct {p1, v4, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast p1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, p1}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 189
    nop

    .line 180
    .end local v1    # "$this$iconButton_u24lambda_u2421\\1":Landroid/widget/ImageView;
    .end local v2    # "$i$a$-apply-Ui$iconButton$1\\1\\180\\0":I
    .end local v3    # "p\\1":I
    nop

    .line 189
    return-object v0
.end method

.method public final iconFor(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 4
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "cls"    # Ljava/lang/String;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cls"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 202
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Icons;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Icons;

    invoke-virtual {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/Icons;->instance(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0
.end method

.method public final iconTextButton(Landroid/content/Context;Landroid/graphics/drawable/Drawable;Ljava/lang/String;ILkotlin/jvm/functions/Function1;)Landroid/widget/TextView;
    .registers 12
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "icon"    # Landroid/graphics/drawable/Drawable;
    .param p3, "label"    # Ljava/lang/String;
    .param p4, "base"    # I
    .param p5, "onClick"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/graphics/drawable/Drawable;",
            "Ljava/lang/String;",
            "I",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroid/view/View;",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/widget/TextView;"
        }
    .end annotation

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "label"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onClick"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    invoke-virtual {p0, p1, p3, p4, p5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->button(Landroid/content/Context;Ljava/lang/String;ILkotlin/jvm/functions/Function1;)Landroid/widget/TextView;

    move-result-object v0

    move-object v1, v0

    .local v1, "$this$iconTextButton_u24lambda_u245\\1":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 112
    .local v2, "$i$a$-apply-Ui$iconTextButton$1\\1\\111\\0":I
    if-eqz p2, :cond_32

    .line 113
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v4, 0x41900000    # 18.0f

    invoke-virtual {v3, p1, v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    .line 114
    .local v3, "s\\1":I
    const/4 v4, 0x0

    invoke-virtual {p2, v4, v4, v3, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 115
    const/4 v4, 0x0

    invoke-virtual {v1, p2, v4, v4, v4}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 116
    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v5, 0x40c00000    # 6.0f

    invoke-virtual {v4, p1, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    .line 118
    .end local v3    # "s\\1":I
    :cond_32
    nop

    .line 111
    .end local v1    # "$this$iconTextButton_u24lambda_u245\\1":Landroid/widget/TextView;
    .end local v2    # "$i$a$-apply-Ui$iconTextButton$1\\1\\111\\0":I
    nop

    .line 118
    return-object v0
.end method

.method public final input(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZ)Landroid/widget/EditText;
    .registers 14
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "value"    # Ljava/lang/String;
    .param p3, "hint"    # Ljava/lang/String;
    .param p4, "numeric"    # Z
    .param p5, "multiLine"    # Z

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "value"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "hint"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 143
    new-instance v0, Landroid/widget/EditText;

    invoke-direct {v0, p1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$input_u24lambda_u2414\\1":Landroid/widget/EditText;
    const/4 v2, 0x0

    .line 144
    .local v2, "$i$a$-apply-Ui$input$1\\1\\143\\0":I
    move-object v3, p2

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 145
    move-object v3, p3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 146
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->TEXT:I

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setTextColor(I)V

    .line 147
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->DIM:I

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setHintTextColor(I)V

    .line 148
    const/4 v3, 0x2

    const/high16 v4, 0x41600000    # 14.0f

    invoke-virtual {v1, v3, v4}, Landroid/widget/EditText;->setTextSize(IF)V

    .line 149
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 250
    move-object v4, v3

    .local v4, "$this$input_u24lambda_u2414_u24lambda_u2413\\2":Landroid/graphics/drawable/GradientDrawable;
    const/4 v5, 0x0

    .line 149
    .local v5, "$i$a$-apply-Ui$input$1$1\\2\\149\\1":I
    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INPUT:I

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-virtual {v6, p1, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-boolean v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->LIGHT:Z

    if-eqz v7, :cond_56

    const v7, -0x3b3b3c

    goto :goto_59

    :cond_56
    const v7, -0xb5b5b6

    :goto_59
    invoke-virtual {v4, v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    sget-object v6, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v7, 0x40400000    # 3.0f

    invoke-virtual {v6, p1, v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v4    # "$this$input_u24lambda_u2414_u24lambda_u2413\\2":Landroid/graphics/drawable/GradientDrawable;
    .end local v5    # "$i$a$-apply-Ui$input$1$1\\2\\149\\1":I
    check-cast v3, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 150
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v4, 0x41000000    # 8.0f

    invoke-virtual {v3, p1, v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    .line 151
    .local v3, "p\\1":I
    invoke-virtual {v1, v3, v3, v3, v3}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 152
    nop

    .line 153
    if-eqz p4, :cond_7e

    const/16 v4, 0x3002

    goto :goto_87

    .line 154
    :cond_7e
    if-eqz p5, :cond_84

    const v4, 0xa0001

    goto :goto_87

    .line 155
    :cond_84
    const v4, 0x80001

    .line 152
    :goto_87
    invoke-virtual {v1, v4}, Landroid/widget/EditText;->setInputType(I)V

    .line 157
    if-nez p5, :cond_90

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 158
    :cond_90
    nop

    .line 143
    .end local v1    # "$this$input_u24lambda_u2414\\1":Landroid/widget/EditText;
    .end local v2    # "$i$a$-apply-Ui$input$1\\1\\143\\0":I
    .end local v3    # "p\\1":I
    nop

    .line 158
    return-object v0
.end method

.method public final lp(IIF)Landroid/widget/LinearLayout$LayoutParams;
    .registers 5
    .param p1, "w"    # I
    .param p2, "h"    # I
    .param p3, "weight"    # F

    .line 191
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, p1, p2, p3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    return-object v0
.end method

.method public final luminance(I)F
    .registers 5
    .param p1, "c"    # I

    .line 67
    shr-int/lit8 v0, p1, 0x10

    and-int/lit16 v0, v0, 0xff

    int-to-float v0, v0

    const v1, 0x3e991687    # 0.299f

    mul-float/2addr v0, v1

    shr-int/lit8 v1, p1, 0x8

    and-int/lit16 v1, v1, 0xff

    int-to-float v1, v1

    const v2, 0x3f1645a2    # 0.587f

    mul-float/2addr v1, v2

    add-float/2addr v0, v1

    and-int/lit16 v1, p1, 0xff

    int-to-float v1, v1

    const v2, 0x3de978d5    # 0.114f

    mul-float/2addr v1, v2

    add-float/2addr v0, v1

    const/high16 v1, 0x437f0000    # 255.0f

    div-float/2addr v0, v1

    return v0
.end method

.method public final popupContext(Landroid/content/Context;)Landroid/content/Context;
    .registers 4
    .param p1, "ctx"    # Landroid/content/Context;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    new-instance v0, Landroid/view/ContextThemeWrapper;

    sget-boolean v1, Lcom/exampletest/mobilestudiotest/ui/Ui;->LIGHT:Z

    if-eqz v1, :cond_f

    const v1, 0x1030237

    goto :goto_12

    :cond_f
    const v1, 0x1030224

    :goto_12
    invoke-direct {v0, p1, v1}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    check-cast v0, Landroid/content/Context;

    return-object v0
.end method

.method public final rippleBg(Landroid/content/Context;IF)Landroid/graphics/drawable/RippleDrawable;
    .registers 10
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "base"    # I
    .param p3, "radius"    # F

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v1, v0

    .line 250
    .local v1, "$this$rippleBg_u24lambda_u241\\1":Landroid/graphics/drawable/GradientDrawable;
    const/4 v2, 0x0

    .line 94
    .local v2, "$i$a$-apply-Ui$rippleBg$shape$1\\1\\94\\0":I
    invoke-virtual {v1, p2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3, p1, p3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v1, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 95
    .end local v1    # "$this$rippleBg_u24lambda_u241\\1":Landroid/graphics/drawable/GradientDrawable;
    .end local v2    # "$i$a$-apply-Ui$rippleBg$shape$1\\1\\94\\0":I
    .local v0, "shape":Landroid/graphics/drawable/GradientDrawable;
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v2, v1

    .line 250
    .local v2, "$this$rippleBg_u24lambda_u242\\2":Landroid/graphics/drawable/GradientDrawable;
    const/4 v3, 0x0

    .line 95
    .local v3, "$i$a$-apply-Ui$rippleBg$mask$1\\2\\95\\0":I
    const/4 v4, -0x1

    invoke-virtual {v2, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v4, p1, p3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v2, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 96
    .end local v2    # "$this$rippleBg_u24lambda_u242\\2":Landroid/graphics/drawable/GradientDrawable;
    .end local v3    # "$i$a$-apply-Ui$rippleBg$mask$1\\2\\95\\0":I
    .local v1, "mask":Landroid/graphics/drawable/GradientDrawable;
    new-instance v2, Landroid/graphics/drawable/RippleDrawable;

    sget-boolean v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->LIGHT:Z

    if-eqz v3, :cond_37

    const/high16 v3, 0x22000000

    goto :goto_3a

    :cond_37
    const v3, 0x33ffffff

    :goto_3a
    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    move-object v4, v0

    check-cast v4, Landroid/graphics/drawable/Drawable;

    move-object v5, v1

    check-cast v5, Landroid/graphics/drawable/Drawable;

    invoke-direct {v2, v3, v4, v5}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    return-object v2
.end method

.method public final smallIconButton(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Landroid/widget/TextView;
    .registers 13
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "glyph"    # Ljava/lang/String;
    .param p3, "onClick"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroid/view/View;",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/widget/TextView;"
        }
    .end annotation

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "glyph"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onClick"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    const/16 v7, 0x18

    const/4 v8, 0x0

    const/high16 v4, 0x41500000    # 13.0f

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    .end local p1    # "ctx":Landroid/content/Context;
    .end local p2    # "glyph":Ljava/lang/String;
    .local v2, "ctx":Landroid/content/Context;
    .local v3, "glyph":Ljava/lang/String;
    invoke-static/range {v1 .. v8}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object p1

    move-object v1, v2

    .end local v2    # "ctx":Landroid/content/Context;
    .end local v3    # "glyph":Ljava/lang/String;
    .local v1, "ctx":Landroid/content/Context;
    .restart local p2    # "glyph":Ljava/lang/String;
    move-object v6, p1

    .local v6, "$this$smallIconButton_u24lambda_u2419\\1":Landroid/widget/TextView;
    const/4 v7, 0x0

    .line 171
    .local v7, "$i$a$-apply-Ui$smallIconButton$1\\1\\170\\0":I
    const/16 v0, 0x11

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 172
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v2, 0x40c00000    # 6.0f

    invoke-virtual {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v8

    .line 173
    .local v8, "p\\1":I
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v2, 0x40400000    # 3.0f

    invoke-virtual {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3, v1, v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-virtual {v6, v8, v0, v8, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 174
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->rippleBg$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;IFILjava/lang/Object;)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 175
    const/4 v0, 0x1

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setClickable(Z)V

    .line 176
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda3;

    invoke-direct {v0, p3}, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/functions/Function1;)V

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 177
    nop

    .line 170
    .end local v6    # "$this$smallIconButton_u24lambda_u2419\\1":Landroid/widget/TextView;
    .end local v7    # "$i$a$-apply-Ui$smallIconButton$1\\1\\170\\0":I
    .end local v8    # "p\\1":I
    nop

    .line 177
    return-object p1
.end method

.method public final text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;
    .registers 11
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "s"    # Ljava/lang/String;
    .param p3, "size"    # F
    .param p4, "color"    # I
    .param p5, "bold"    # Z

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "s"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$text_u24lambda_u240\\1":Landroid/widget/TextView;
    const/4 v2, 0x0

    .line 86
    .local v2, "$i$a$-apply-Ui$text$1\\1\\85\\0":I
    move-object v3, p2

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 87
    invoke-virtual {v1, p4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 88
    const/4 v3, 0x2

    invoke-virtual {v1, v3, p3}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 89
    const/4 v3, 0x1

    if-eqz p5, :cond_28

    invoke-virtual {v1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v4

    invoke-virtual {v1, v4, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 90
    :cond_28
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 91
    nop

    .line 85
    .end local v1    # "$this$text_u24lambda_u240\\1":Landroid/widget/TextView;
    .end local v2    # "$i$a$-apply-Ui$text$1\\1\\85\\0":I
    nop

    .line 91
    return-object v0
.end method

.method public final toolButton(Landroid/content/Context;Landroid/graphics/drawable/Drawable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Landroid/widget/LinearLayout;
    .registers 22
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "icon"    # Landroid/graphics/drawable/Drawable;
    .param p3, "label"    # Ljava/lang/String;
    .param p4, "onClick"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/graphics/drawable/Drawable;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Landroid/view/View;",
            "Lkotlin/Unit;",
            ">;)",
            "Landroid/widget/LinearLayout;"
        }
    .end annotation

    move-object/from16 v1, p1

    move-object/from16 v8, p2

    move-object/from16 v9, p4

    const-string v0, "ctx"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "icon"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "label"

    move-object/from16 v2, p3

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onClick"

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v11, v10

    .local v11, "$this$toolButton_u24lambda_u2412\\1":Landroid/widget/LinearLayout;
    const/4 v12, 0x0

    .line 123
    .local v12, "$i$a$-apply-Ui$toolButton$1\\1\\122\\0":I
    const/4 v13, 0x1

    invoke-virtual {v11, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 124
    const/16 v14, 0x11

    invoke-virtual {v11, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 125
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-virtual {v0, v1, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v15

    .line 126
    .local v15, "p\\1":I
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v3, 0x40800000    # 4.0f

    invoke-virtual {v0, v1, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v4, 0x40400000    # 3.0f

    invoke-virtual {v3, v1, v4}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-virtual {v11, v15, v0, v15, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 127
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v3, 0x42580000    # 54.0f

    invoke-virtual {v0, v1, v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setMinimumWidth(I)V

    .line 128
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 250
    move-object v3, v0

    .local v3, "$this$toolButton_u24lambda_u2412_u24lambda_u246\\2":Landroid/widget/ImageView;
    const/4 v5, 0x0

    .line 128
    .local v5, "$i$a$-apply-Ui$toolButton$1$1\\2\\128\\1":I
    invoke-virtual {v3, v8}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget-object v6, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v3, v6}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .end local v3    # "$this$toolButton_u24lambda_u2412_u24lambda_u246\\2":Landroid/widget/ImageView;
    .end local v5    # "$i$a$-apply-Ui$toolButton$1$1\\2\\128\\1":I
    check-cast v0, Landroid/view/View;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    sget-object v5, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v6, 0x41d00000    # 26.0f

    invoke-virtual {v5, v1, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    sget-object v7, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v7, v1, v6}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v6

    invoke-direct {v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v11, v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 131
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    move v3, v4

    sget v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->TEXT:I

    const/16 v6, 0x10

    const/4 v7, 0x0

    move v5, v3

    const/high16 v3, 0x41300000    # 11.0f

    move/from16 v16, v5

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/ui/Ui;->text$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;Ljava/lang/String;FIZILjava/lang/Object;)Landroid/widget/TextView;

    move-result-object v0

    .line 250
    move-object v2, v0

    .local v2, "$this$toolButton_u24lambda_u2412_u24lambda_u247\\3":Landroid/widget/TextView;
    const/4 v3, 0x0

    .line 131
    .local v3, "$i$a$-apply-Ui$toolButton$1$2\\3\\131\\1":I
    invoke-virtual {v2, v14}, Landroid/widget/TextView;->setGravity(I)V

    sget-object v4, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v5, 0x40000000    # 2.0f

    invoke-virtual {v4, v1, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v2, v5, v4, v5, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    .end local v2    # "$this$toolButton_u24lambda_u2412_u24lambda_u247\\3":Landroid/widget/TextView;
    .end local v3    # "$i$a$-apply-Ui$toolButton$1$2\\3\\131\\1":I
    check-cast v0, Landroid/view/View;

    .line 132
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    invoke-direct {v2, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 250
    move-object v3, v2

    .local v3, "$this$toolButton_u24lambda_u2412_u24lambda_u248\\4":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v4, 0x0

    .line 132
    .local v4, "$i$a$-apply-Ui$toolButton$1$3\\4\\132\\1":I
    iput v13, v3, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .end local v3    # "$this$toolButton_u24lambda_u2412_u24lambda_u248\\4":Landroid/widget/LinearLayout$LayoutParams;
    .end local v4    # "$i$a$-apply-Ui$toolButton$1$3\\4\\132\\1":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v2, Landroid/view/ViewGroup$LayoutParams;

    .line 131
    invoke-virtual {v11, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 133
    new-instance v0, Landroid/graphics/drawable/StateListDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    move-object v2, v0

    .local v2, "$this$toolButton_u24lambda_u2412_u24lambda_u2410\\5":Landroid/graphics/drawable/StateListDrawable;
    const/4 v3, 0x0

    .line 134
    .local v3, "$i$a$-apply-Ui$toolButton$1$4\\5\\133\\1":I
    const v4, 0x10100a1

    filled-new-array {v4}, [I

    move-result-object v4

    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 250
    move-object v7, v6

    .local v7, "$this$toolButton_u24lambda_u2412_u24lambda_u2410_u24lambda_u249\\6":Landroid/graphics/drawable/GradientDrawable;
    const/4 v14, 0x0

    .line 134
    .local v14, "$i$a$-apply-Ui$toolButton$1$4$1\\6\\134\\5":I
    sget-object v16, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    sget v13, Lcom/exampletest/mobilestudiotest/ui/Ui;->SELECT:I

    invoke-virtual {v7, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    sget-object v13, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/high16 v5, 0x40400000    # 3.0f

    invoke-virtual {v13, v1, v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v7, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .end local v7    # "$this$toolButton_u24lambda_u2412_u24lambda_u2410_u24lambda_u249\\6":Landroid/graphics/drawable/GradientDrawable;
    .end local v14    # "$i$a$-apply-Ui$toolButton$1$4$1\\6\\134\\5":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2, v4, v6}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 135
    const/4 v4, 0x0

    new-array v5, v4, [I

    new-instance v6, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v6, v4}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    check-cast v6, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2, v5, v6}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 136
    nop

    .line 133
    .end local v2    # "$this$toolButton_u24lambda_u2412_u24lambda_u2410\\5":Landroid/graphics/drawable/StateListDrawable;
    .end local v3    # "$i$a$-apply-Ui$toolButton$1$4\\5\\133\\1":I
    check-cast v0, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 137
    sget-object v0, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/ui/Ui;->rippleBg$default(Lcom/exampletest/mobilestudiotest/ui/Ui;Landroid/content/Context;IFILjava/lang/Object;)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V

    .line 138
    const/4 v0, 0x1

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 139
    new-instance v0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda2;

    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda2;-><init>(Lkotlin/jvm/functions/Function1;)V

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 140
    nop

    .line 122
    .end local v11    # "$this$toolButton_u24lambda_u2412\\1":Landroid/widget/LinearLayout;
    .end local v12    # "$i$a$-apply-Ui$toolButton$1\\1\\122\\0":I
    .end local v15    # "p\\1":I
    nop

    .line 140
    return-object v10
.end method

###### Class com.exampletest.mobilestudiotest.ui.Ui.ArrowDrawable (com.exampletest.mobilestudiotest.ui.Ui$ArrowDrawable)
.class public final Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;
.super Landroid/graphics/drawable/Drawable;
.source "Ui.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/Ui;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ArrowDrawable"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nUi.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Ui.kt\ncom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,249:1\n1#2:250\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\rH\u0016J\u0010\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0005H\u0016J\u0012\u0010\u0010\u001a\u00020\u000b2\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0016J\u0008\u0010\u0013\u001a\u00020\u0005H\u0017R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0014"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;",
        "Landroid/graphics/drawable/Drawable;",
        "expanded",
        "",
        "color",
        "",
        "<init>",
        "(ZI)V",
        "p",
        "Landroid/graphics/Paint;",
        "draw",
        "",
        "c",
        "Landroid/graphics/Canvas;",
        "setAlpha",
        "alpha",
        "setColorFilter",
        "cf",
        "Landroid/graphics/ColorFilter;",
        "getOpacity",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final color:I

.field private final expanded:Z

.field private final p:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(ZI)V
    .registers 7
    .param p1, "expanded"    # Z
    .param p2, "color"    # I

    .line 230
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->expanded:Z

    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->color:I

    .line 231
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    .line 250
    move-object v1, v0

    .local v1, "$this$p_u24lambda_u240\\1":Landroid/graphics/Paint;
    const/4 v2, 0x0

    .line 231
    .local v2, "$i$a$-apply-Ui$ArrowDrawable$p$1\\1\\231\\0":I
    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .end local v1    # "$this$p_u24lambda_u240\\1":Landroid/graphics/Paint;
    .end local v2    # "$i$a$-apply-Ui$ArrowDrawable$p$1\\1\\231\\0":I
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->p:Landroid/graphics/Paint;

    .line 230
    return-void
.end method

.method public synthetic constructor <init>(ZIILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 5

    .line 230
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_a

    sget-object p2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getDIM()I

    move-result p2

    :cond_a
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;-><init>(ZI)V

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 11
    .param p1, "c"    # Landroid/graphics/Canvas;

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 233
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const-string v1, "getBounds(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    .local v0, "b":Landroid/graphics/Rect;
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    int-to-float v1, v1

    const v2, 0x3eb851ec    # 0.36f

    mul-float/2addr v1, v2

    .line 235
    .local v1, "s":F
    invoke-virtual {v0}, Landroid/graphics/Rect;->exactCenterX()F

    move-result v2

    .local v2, "cx":F
    invoke-virtual {v0}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v3

    .line 236
    .local v3, "cy":F
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->p:Landroid/graphics/Paint;

    iget v5, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->color:I

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 237
    new-instance v4, Landroid/graphics/Path;

    invoke-direct {v4}, Landroid/graphics/Path;-><init>()V

    .line 238
    .local v4, "path":Landroid/graphics/Path;
    iget-boolean v5, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->expanded:Z

    const v6, 0x3f19999a    # 0.6f

    const/high16 v7, 0x3f000000    # 0.5f

    if-eqz v5, :cond_53

    sub-float v5, v2, v1

    mul-float v8, v1, v7

    sub-float v8, v3, v8

    invoke-virtual {v4, v5, v8}, Landroid/graphics/Path;->moveTo(FF)V

    add-float v5, v2, v1

    mul-float/2addr v7, v1

    sub-float v7, v3, v7

    invoke-virtual {v4, v5, v7}, Landroid/graphics/Path;->lineTo(FF)V

    mul-float/2addr v6, v1

    add-float/2addr v6, v3

    invoke-virtual {v4, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    goto :goto_69

    .line 239
    :cond_53
    mul-float v5, v1, v7

    sub-float v5, v2, v5

    sub-float v8, v3, v1

    invoke-virtual {v4, v5, v8}, Landroid/graphics/Path;->moveTo(FF)V

    mul-float/2addr v6, v1

    add-float/2addr v6, v2

    invoke-virtual {v4, v6, v3}, Landroid/graphics/Path;->lineTo(FF)V

    mul-float/2addr v7, v1

    sub-float v5, v2, v7

    add-float v6, v3, v1

    invoke-virtual {v4, v5, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 240
    :goto_69
    invoke-virtual {v4}, Landroid/graphics/Path;->close()V

    .line 241
    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$ArrowDrawable;->p:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 242
    return-void
.end method

.method public getOpacity()I
    .registers 2
    .annotation runtime Lkotlin/Deprecated;
        message = "Deprecated in Java"
    .end annotation

    .line 246
    const/4 v0, -0x3

    return v0
.end method

.method public setAlpha(I)V
    .registers 2
    .param p1, "alpha"    # I

    .line 243
    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2
    .param p1, "cf"    # Landroid/graphics/ColorFilter;

    .line 244
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.Ui.CheckBoxDrawable (com.exampletest.mobilestudiotest.ui.Ui$CheckBoxDrawable)
.class public final Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;
.super Landroid/graphics/drawable/Drawable;
.source "Ui.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/ui/Ui;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "CheckBoxDrawable"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nUi.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Ui.kt\ncom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,249:1\n1#2:250\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\rH\u0016J\u0010\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\u0012\u0010\u0011\u001a\u00020\u000b2\u0008\u0010\u0012\u001a\u0004\u0018\u00010\u0013H\u0016J\u0008\u0010\u0014\u001a\u00020\u0010H\u0017R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0015"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;",
        "Landroid/graphics/drawable/Drawable;",
        "checked",
        "",
        "density",
        "",
        "<init>",
        "(ZF)V",
        "p",
        "Landroid/graphics/Paint;",
        "draw",
        "",
        "c",
        "Landroid/graphics/Canvas;",
        "setAlpha",
        "alpha",
        "",
        "setColorFilter",
        "cf",
        "Landroid/graphics/ColorFilter;",
        "getOpacity",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final checked:Z

.field private final density:F

.field private final p:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(ZF)V
    .registers 5
    .param p1, "checked"    # Z
    .param p2, "density"    # F

    .line 205
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->checked:Z

    iput p2, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->density:F

    .line 206
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    .line 205
    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 14
    .param p1, "c"    # Landroid/graphics/Canvas;

    const-string v0, "c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 208
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const-string v1, "getBounds(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 209
    .local v0, "b":Landroid/graphics/Rect;
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    int-to-float v1, v1

    .line 210
    .local v1, "s":F
    iget v2, v0, Landroid/graphics/Rect;->left:I

    int-to-float v4, v2

    .local v4, "l":F
    iget v2, v0, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v3

    int-to-float v3, v3

    sub-float/2addr v3, v1

    const/high16 v11, 0x40000000    # 2.0f

    div-float/2addr v3, v11

    add-float v5, v2, v3

    .line 211
    .local v5, "t":F
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 212
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    iget-boolean v3, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->checked:Z

    if-eqz v3, :cond_40

    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getACCENT()I

    move-result v3

    goto :goto_46

    :cond_40
    sget-object v3, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getINPUT()I

    move-result v3

    :goto_46
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 213
    add-float v6, v4, v1

    add-float v7, v5, v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->density:F

    mul-float v8, v2, v11

    iget v2, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->density:F

    mul-float v9, v2, v11

    iget-object v10, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    move-object v3, p1

    .end local p1    # "c":Landroid/graphics/Canvas;
    .local v3, "c":Landroid/graphics/Canvas;
    invoke-virtual/range {v3 .. v10}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 214
    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    const/high16 v2, 0x3f800000    # 1.0f

    iget v6, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->density:F

    mul-float/2addr v6, v2

    invoke-virtual {p1, v6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 215
    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    iget-boolean v2, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->checked:Z

    if-eqz v2, :cond_79

    sget-object v2, Lcom/exampletest/mobilestudiotest/ui/Ui;->INSTANCE:Lcom/exampletest/mobilestudiotest/ui/Ui;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/ui/Ui;->getACCENT()I

    move-result v2

    goto :goto_7c

    :cond_79
    const v2, -0x757576

    :goto_7c
    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 216
    add-float v6, v4, v1

    add-float v7, v5, v1

    iget p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->density:F

    mul-float v8, p1, v11

    iget p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->density:F

    mul-float v9, p1, v11

    iget-object v10, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v3 .. v10}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 217
    iget-boolean p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->checked:Z

    if-eqz p1, :cond_df

    .line 218
    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    const/4 v2, -0x1

    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setColor(I)V

    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    const v2, 0x3fe66666    # 1.8f

    iget v6, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->density:F

    mul-float/2addr v6, v2

    invoke-virtual {p1, v6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 219
    new-instance p1, Landroid/graphics/Path;

    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    move-object v2, p1

    .line 250
    .local v2, "$this$draw_u24lambda_u240\\1":Landroid/graphics/Path;
    const/4 v6, 0x0

    .line 219
    .local v6, "$i$a$-apply-Ui$CheckBoxDrawable$draw$path$1\\1\\219\\0":I
    const v7, 0x3e6147ae    # 0.22f

    mul-float/2addr v7, v1

    add-float/2addr v7, v4

    const v8, 0x3f051eb8    # 0.52f

    mul-float/2addr v8, v1

    add-float/2addr v8, v5

    invoke-virtual {v2, v7, v8}, Landroid/graphics/Path;->moveTo(FF)V

    const v7, 0x3ed70a3d    # 0.42f

    mul-float/2addr v7, v1

    add-float/2addr v7, v4

    const v8, 0x3f3851ec    # 0.72f

    mul-float/2addr v8, v1

    add-float/2addr v8, v5

    invoke-virtual {v2, v7, v8}, Landroid/graphics/Path;->lineTo(FF)V

    const v7, 0x3f47ae14    # 0.78f

    mul-float/2addr v7, v1

    add-float/2addr v7, v4

    const v8, 0x3e99999a    # 0.3f

    mul-float/2addr v8, v1

    add-float/2addr v8, v5

    invoke-virtual {v2, v7, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 220
    .end local v2    # "$this$draw_u24lambda_u240\\1":Landroid/graphics/Path;
    .end local v6    # "$i$a$-apply-Ui$CheckBoxDrawable$draw$path$1\\1\\219\\0":I
    .local p1, "path":Landroid/graphics/Path;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$CheckBoxDrawable;->p:Landroid/graphics/Paint;

    invoke-virtual {v3, p1, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 222
    .end local p1    # "path":Landroid/graphics/Path;
    :cond_df
    return-void
.end method

.method public getOpacity()I
    .registers 2
    .annotation runtime Lkotlin/Deprecated;
        message = "Deprecated in Java"
    .end annotation

    .line 226
    const/4 v0, -0x3

    return v0
.end method

.method public setAlpha(I)V
    .registers 2
    .param p1, "alpha"    # I

    .line 223
    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2
    .param p1, "cf"    # Landroid/graphics/ColorFilter;

    .line 224
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.Ui$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.ui.Ui$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/Ui;"
    method = "iconButton$lambda$21$lambda$20"
    proto = "(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda0;->f$0:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda0;->f$0:Lkotlin/jvm/functions/Function1;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->iconButton$lambda$21$lambda$20(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.Ui$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.ui.Ui$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/Ui;"
    method = "button$lambda$4$lambda$3"
    proto = "(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda1;->f$0:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda1;->f$0:Lkotlin/jvm/functions/Function1;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->button$lambda$4$lambda$3(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.Ui$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.ui.Ui$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/Ui;"
    method = "toolButton$lambda$12$lambda$11"
    proto = "(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda2;->f$0:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda2;->f$0:Lkotlin/jvm/functions/Function1;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->toolButton$lambda$12$lambda$11(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.ui.Ui$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.ui.Ui$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/ui/Ui;"
    method = "smallIconButton$lambda$19$lambda$18"
    proto = "(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda3;->f$0:Lkotlin/jvm/functions/Function1;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/ui/Ui$$ExternalSyntheticLambda3;->f$0:Lkotlin/jvm/functions/Function1;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/ui/Ui;->smallIconButton$lambda$19$lambda$18(Lkotlin/jvm/functions/Function1;Landroid/view/View;)V

    return-void
.end method
