###### Class com.exampletest.mobilestudiotest.render.Draco (com.exampletest.mobilestudiotest.render.Draco)
.class public final Lcom/exampletest/mobilestudiotest/render/Draco;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;,
        Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;,
        Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;,
        Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;,
        Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;,
        Lcom/exampletest/mobilestudiotest/render/Draco$Octa;,
        Lcom/exampletest/mobilestudiotest/render/Draco$RAns;,
        Lcom/exampletest/mobilestudiotest/render/Draco$Reader;,
        Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDraco.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Draco.kt\ncom/exampletest/mobilestudiotest/render/Draco\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,489:1\n1#2:490\n1563#3:491\n1634#3,3:492\n1563#3:495\n1634#3,3:496\n*S KotlinDebug\n*F\n+ 1 Draco.kt\ncom/exampletest/mobilestudiotest/render/Draco\n*L\n471#1:491\n471#1:492,3\n486#1:495\n486#1:496,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0012\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0015\n\u0002\u0008\u0006\n\u0002\u0010\u0002\n\u0002\u0008\t\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u000c\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\t456789:;<B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0016\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u0005J\u0010\u0010\u000f\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0005H\u0002J\u0018\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0005H\u0002J \u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J\u0018\u0010\u001a\u001a\u00020\u00052\u0006\u0010\u001b\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u0005H\u0002J\u0018\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u00172\u0006\u0010 \u001a\u00020\u0005H\u0002J\u0010\u0010%\u001a\u00020\u00052\u0006\u0010&\u001a\u00020\u0005H\u0002J\u0018\u0010\'\u001a\u00020(2\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010&\u001a\u00020\u0005H\u0002J \u0010)\u001a\u00020\u001e2\u0006\u0010*\u001a\u00020+2\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J\u0018\u0010,\u001a\u00020\u001e2\u0006\u0010*\u001a\u00020+2\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J\u0018\u0010-\u001a\u00020\u001e2\u0006\u0010*\u001a\u00020+2\u0006\u0010\u0018\u001a\u00020\u0005H\u0002J\u001a\u0010.\u001a\u00020\u001e2\u0006\u0010\u0013\u001a\u00020\u00142\u0008\u0008\u0002\u0010/\u001a\u00020\u0005H\u0002J\"\u00100\u001a\u0002012\u0006\u00102\u001a\u00020\r2\u0008\u0008\u0002\u0010\u000e\u001a\u00020\u00052\u0008\u0008\u0002\u00103\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006="
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco;",
        "",
        "<init>",
        "()V",
        "POSITION",
        "",
        "NORMAL",
        "COLOR",
        "TEX_COORD",
        "GENERIC",
        "isDraco",
        "",
        "b",
        "",
        "off",
        "precisionFor",
        "bits",
        "createSymbolDecoder",
        "Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;",
        "r",
        "Lcom/exampletest/mobilestudiotest/render/Draco$Reader;",
        "uniqueSymbolBits",
        "decodeSymbols",
        "",
        "n",
        "comps",
        "rotationCount",
        "x",
        "y",
        "rotate",
        "",
        "p",
        "count",
        "KIND_GENERIC",
        "KIND_INTEGER",
        "KIND_QUANTIZED",
        "KIND_NORMALS",
        "typeLength",
        "dt",
        "readTyped",
        "",
        "decodePortable",
        "d",
        "Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;",
        "decodeTransformData",
        "finish",
        "skipMetadata",
        "depth",
        "decode",
        "Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;",
        "bytes",
        "len",
        "DracoException",
        "Attribute",
        "Mesh",
        "Reader",
        "BitReader",
        "RAns",
        "SymbolDecoder",
        "Octa",
        "AttDecoder",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final COLOR:I = 0x2

.field public static final GENERIC:I = 0x4

.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/render/Draco;

.field private static final KIND_GENERIC:I = 0x0

.field private static final KIND_INTEGER:I = 0x1

.field private static final KIND_NORMALS:I = 0x3

.field private static final KIND_QUANTIZED:I = 0x2

.field public static final NORMAL:I = 0x1

.field public static final POSITION:I = 0x0

.field public static final TEX_COORD:I = 0x3


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/exampletest/mobilestudiotest/render/Draco;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/render/Draco;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/render/Draco;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/Draco;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final createSymbolDecoder(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;
    .registers 12
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/render/Draco$Reader;
    .param p2, "uniqueSymbolBits"    # I

    .line 149
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v0

    .line 150
    .local v0, "num":I
    div-int/lit8 v1, v0, 0x40

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getRemaining()I

    move-result v2

    if-gt v1, v2, :cond_5f

    .line 151
    if-nez v0, :cond_16

    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;-><init>(ILcom/exampletest/mobilestudiotest/render/Draco$RAns;)V

    return-object v1

    .line 152
    :cond_16
    new-array v1, v0, [I

    .line 153
    .local v1, "probs":[I
    const/4 v2, 0x0

    .line 154
    .local v2, "i":I
    :goto_19
    if-ge v2, v0, :cond_50

    .line 155
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v3

    .line 156
    .local v3, "data":I
    and-int/lit8 v4, v3, 0x3

    .line 157
    .local v4, "token":I
    const/4 v5, 0x3

    if-ne v4, v5, :cond_36

    .line 158
    ushr-int/lit8 v5, v3, 0x2

    .line 159
    .local v5, "run":I
    add-int v6, v2, v5

    if-ge v6, v0, :cond_2e

    .line 160
    add-int/lit8 v6, v5, 0x1

    add-int/2addr v2, v6

    .end local v5    # "run":I
    goto :goto_19

    .line 159
    .restart local v5    # "run":I
    :cond_2e
    new-instance v6, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v7, "bad probability run"

    invoke-direct {v6, v7}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v6

    .line 162
    .end local v5    # "run":I
    :cond_36
    ushr-int/lit8 v5, v3, 0x2

    .line 163
    .local v5, "p":I
    const/4 v6, 0x0

    .local v6, "k":I
    :goto_39
    if-ge v6, v4, :cond_4a

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v7

    add-int/lit8 v8, v6, 0x1

    mul-int/lit8 v8, v8, 0x8

    add-int/lit8 v8, v8, -0x2

    shl-int/2addr v7, v8

    or-int/2addr v5, v7

    add-int/lit8 v6, v6, 0x1

    goto :goto_39

    .line 164
    .end local v6    # "k":I
    :cond_4a
    aput v5, v1, v2

    .line 165
    nop

    .end local v5    # "p":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_19

    .line 168
    .end local v3    # "data":I
    .end local v4    # "token":I
    :cond_50
    new-instance v3, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;

    new-instance v4, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;

    invoke-direct {p0, p2}, Lcom/exampletest/mobilestudiotest/render/Draco;->precisionFor(I)I

    move-result v5

    invoke-direct {v4, v5, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;-><init>(I[I)V

    invoke-direct {v3, v0, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;-><init>(ILcom/exampletest/mobilestudiotest/render/Draco$RAns;)V

    return-object v3

    .line 150
    .end local v1    # "probs":[I
    .end local v2    # "i":I
    :cond_5f
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "too many symbols"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public static synthetic decode$default(Lcom/exampletest/mobilestudiotest/render/Draco;[BIIILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;
    .registers 6

    .line 417
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_5

    const/4 p2, 0x0

    :cond_5
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_b

    array-length p3, p1

    sub-int/2addr p3, p2

    :cond_b
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/render/Draco;->decode([BII)Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;

    move-result-object p0

    return-object p0
.end method

.method private final decodePortable(Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;ILcom/exampletest/mobilestudiotest/render/Draco$Reader;)V
    .registers 30
    .param p1, "d"    # Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    .param p2, "n"    # I
    .param p3, "r"    # Lcom/exampletest/mobilestudiotest/render/Draco$Reader;

    .line 300
    move-object/from16 v0, p0

    move-object/from16 v1, p3

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getAtt()Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    move-result-object v2

    .line 301
    .local v2, "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v3

    if-nez v3, :cond_2b

    .line 302
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getComponents()I

    move-result v3

    mul-int v3, v3, p2

    new-array v3, v3, [F

    .line 303
    .local v3, "v":[F
    const/4 v4, 0x0

    .local v4, "i":I
    array-length v5, v3

    :goto_18
    if-ge v4, v5, :cond_27

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getDataType()I

    move-result v6

    invoke-direct {v0, v1, v6}, Lcom/exampletest/mobilestudiotest/render/Draco;->readTyped(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)F

    move-result v6

    aput v6, v3, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_18

    .line 304
    .end local v4    # "i":I
    :cond_27
    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->setValues([F)V

    .line 305
    return-void

    .line 307
    .end local v3    # "v":[F
    :cond_2b
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v3

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-ne v3, v5, :cond_35

    move v3, v4

    goto :goto_39

    :cond_35
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getComponents()I

    move-result v3

    .line 308
    .local v3, "comps":I
    :goto_39
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i8()I

    move-result v6

    .line 309
    .local v6, "method":I
    const/4 v7, -0x1

    .line 310
    .local v7, "transform":I
    const/4 v8, -0x2

    if-eq v6, v8, :cond_82

    .line 311
    if-lt v6, v8, :cond_69

    const/4 v9, 0x6

    if-gt v6, v9, :cond_69

    .line 312
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i8()I

    move-result v7

    .line 313
    const/4 v9, -0x1

    if-lt v7, v9, :cond_50

    if-gt v7, v5, :cond_50

    goto :goto_82

    :cond_50
    new-instance v4, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "bad prediction transform "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 311
    :cond_69
    new-instance v4, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "bad prediction method "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 317
    :cond_82
    :goto_82
    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eq v6, v8, :cond_9a

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v8

    if-ne v8, v5, :cond_91

    if-eq v7, v4, :cond_90

    if-ne v7, v5, :cond_95

    :cond_90
    goto :goto_93

    :cond_91
    if-ne v7, v10, :cond_95

    :goto_93
    move v8, v10

    goto :goto_96

    :cond_95
    move v8, v9

    :goto_96
    if-eqz v8, :cond_9a

    move v8, v10

    goto :goto_9b

    :cond_9a
    move v8, v9

    .line 318
    .local v8, "predicted":Z
    :goto_9b
    mul-int v11, p2, v3

    .line 319
    .local v11, "total":I
    const/4 v12, 0x0

    .line 320
    .local v12, "values":[I
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v13

    const/4 v14, 0x4

    if-lez v13, :cond_ac

    invoke-direct {v0, v11, v3, v1}, Lcom/exampletest/mobilestudiotest/render/Draco;->decodeSymbols(IILcom/exampletest/mobilestudiotest/render/Draco$Reader;)[I

    move-result-object v12

    move/from16 v17, v10

    goto :goto_e0

    .line 322
    :cond_ac
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v13

    .line 323
    .local v13, "nb":I
    if-lt v13, v10, :cond_27b

    if-gt v13, v14, :cond_27b

    .line 324
    mul-int v15, v13, v11

    invoke-virtual {v1, v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->need(I)V

    .line 325
    new-array v12, v11, [I

    .line 326
    const/4 v15, 0x0

    .local v15, "i":I
    :goto_bc
    if-ge v15, v11, :cond_de

    const/16 v16, 0x0

    .local v16, "v":I
    const/16 v17, 0x0

    move/from16 v25, v17

    move/from16 v17, v10

    move/from16 v10, v25

    .local v10, "k":I
    :goto_c8
    if-ge v10, v13, :cond_d7

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v18

    mul-int/lit8 v19, v10, 0x8

    shl-int v18, v18, v19

    or-int v16, v16, v18

    add-int/lit8 v10, v10, 0x1

    goto :goto_c8

    .end local v10    # "k":I
    :cond_d7
    aput v16, v12, v15

    .end local v16    # "v":I
    add-int/lit8 v15, v15, 0x1

    move/from16 v10, v17

    goto :goto_bc

    :cond_de
    move/from16 v17, v10

    .line 328
    .end local v13    # "nb":I
    .end local v15    # "i":I
    :goto_e0
    if-eqz v8, :cond_eb

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v10

    if-ne v10, v5, :cond_eb

    move/from16 v10, v17

    goto :goto_ec

    :cond_eb
    move v10, v9

    .line 329
    .local v10, "positive":Z
    :goto_ec
    if-nez v10, :cond_107

    const/4 v13, 0x0

    .local v13, "i":I
    array-length v15, v12

    :goto_f0
    if-ge v13, v15, :cond_104

    aget v16, v12, v13

    .local v16, "u":I
    ushr-int/lit8 v18, v16, 0x1

    move/from16 v19, v14

    and-int/lit8 v14, v16, 0x1

    neg-int v14, v14

    xor-int v18, v18, v14

    aput v18, v12, v13

    .end local v16    # "u":I
    add-int/lit8 v13, v13, 0x1

    move/from16 v14, v19

    goto :goto_f0

    :cond_104
    move/from16 v19, v14

    goto :goto_109

    .end local v13    # "i":I
    :cond_107
    move/from16 v19, v14

    .line 330
    :goto_109
    if-eqz v8, :cond_271

    .line 331
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v13

    if-ne v13, v5, :cond_223

    .line 332
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v13

    .line 333
    .local v13, "maxQ":I
    if-ne v7, v5, :cond_11a

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    .line 334
    :cond_11a
    rem-int/lit8 v14, v13, 0x2

    if-eqz v14, :cond_217

    if-lez v13, :cond_217

    .line 335
    invoke-static {v13}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    move-result v14

    rsub-int/lit8 v14, v14, 0x20

    .line 336
    .local v14, "bits":I
    new-instance v15, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;

    invoke-direct {v15, v14}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;-><init>(I)V

    .line 337
    .local v15, "oct":Lcom/exampletest/mobilestudiotest/render/Draco$Octa;
    new-array v5, v4, [I

    .line 338
    .local v5, "pred":[I
    new-array v1, v4, [I

    .line 339
    .local v1, "orig":[I
    invoke-static {v9, v11}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v18

    move/from16 v20, v9

    move-object/from16 v9, v18

    check-cast v9, Lkotlin/ranges/IntProgression;

    invoke-static {v9, v4}, Lkotlin/ranges/RangesKt;->step(Lkotlin/ranges/IntProgression;I)Lkotlin/ranges/IntProgression;

    move-result-object v4

    invoke-virtual {v4}, Lkotlin/ranges/IntProgression;->getFirst()I

    move-result v9

    move-object/from16 v18, v2

    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .local v9, "i":I
    .local v18, "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    invoke-virtual {v4}, Lkotlin/ranges/IntProgression;->getLast()I

    move-result v2

    invoke-virtual {v4}, Lkotlin/ranges/IntProgression;->getStep()I

    move-result v4

    if-lez v4, :cond_14f

    if-le v9, v2, :cond_153

    :cond_14f
    if-gez v4, :cond_214

    if-gt v2, v9, :cond_214

    .line 340
    :cond_153
    :goto_153
    if-nez v9, :cond_15a

    aput v20, v5, v20

    aput v20, v5, v17

    goto :goto_166

    :cond_15a
    add-int/lit8 v21, v9, -0x2

    aget v21, v12, v21

    aput v21, v5, v20

    add-int/lit8 v21, v9, -0x1

    aget v21, v12, v21

    aput v21, v5, v17

    .line 341
    :goto_166
    aget v21, v5, v20

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->getCenter()I

    move-result v22

    sub-int v21, v21, v22

    aput v21, v5, v20

    aget v21, v5, v17

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->getCenter()I

    move-result v22

    sub-int v21, v21, v22

    aput v21, v5, v17

    .line 342
    move/from16 v21, v4

    aget v4, v5, v20

    move/from16 v22, v6

    .end local v6    # "method":I
    .local v22, "method":I
    aget v6, v5, v17

    invoke-virtual {v15, v4, v6}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->isInDiamond(II)Z

    move-result v4

    .line 343
    .local v4, "inDiamond":Z
    if-nez v4, :cond_18b

    invoke-virtual {v15, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->invertDiamond([I)V

    .line 344
    :cond_18b
    const/4 v6, 0x3

    if-ne v7, v6, :cond_1d6

    .line 345
    aget v16, v5, v20

    if-nez v16, :cond_196

    aget v16, v5, v17

    if-eqz v16, :cond_19e

    :cond_196
    aget v16, v5, v20

    if-gez v16, :cond_1a1

    aget v16, v5, v17

    if-gtz v16, :cond_1a1

    :cond_19e
    move/from16 v16, v17

    goto :goto_1a3

    :cond_1a1
    move/from16 v16, v20

    .line 346
    .local v16, "bottomLeft":Z
    :goto_1a3
    aget v6, v5, v20

    move/from16 v23, v4

    .end local v4    # "inDiamond":Z
    .local v23, "inDiamond":Z
    aget v4, v5, v17

    invoke-direct {v0, v6, v4}, Lcom/exampletest/mobilestudiotest/render/Draco;->rotationCount(II)I

    move-result v4

    .line 347
    .local v4, "rot":I
    if-nez v16, :cond_1b2

    invoke-direct {v0, v5, v4}, Lcom/exampletest/mobilestudiotest/render/Draco;->rotate([II)V

    .line 348
    :cond_1b2
    aget v6, v5, v20

    aget v24, v12, v9

    add-int v6, v6, v24

    invoke-virtual {v15, v6}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->modMax(I)I

    move-result v6

    aput v6, v1, v20

    aget v6, v5, v17

    add-int/lit8 v24, v9, 0x1

    aget v24, v12, v24

    add-int v6, v6, v24

    invoke-virtual {v15, v6}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->modMax(I)I

    move-result v6

    aput v6, v1, v17

    .line 349
    if-nez v16, :cond_1f0

    rsub-int/lit8 v6, v4, 0x4

    rem-int/lit8 v6, v6, 0x4

    invoke-direct {v0, v1, v6}, Lcom/exampletest/mobilestudiotest/render/Draco;->rotate([II)V

    .end local v4    # "rot":I
    .end local v16    # "bottomLeft":Z
    goto :goto_1f0

    .line 351
    .end local v23    # "inDiamond":Z
    .local v4, "inDiamond":Z
    :cond_1d6
    move/from16 v23, v4

    .end local v4    # "inDiamond":Z
    .restart local v23    # "inDiamond":Z
    aget v4, v5, v20

    aget v6, v12, v9

    add-int/2addr v4, v6

    invoke-virtual {v15, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->modMax(I)I

    move-result v4

    aput v4, v1, v20

    aget v4, v5, v17

    add-int/lit8 v6, v9, 0x1

    aget v6, v12, v6

    add-int/2addr v4, v6

    invoke-virtual {v15, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->modMax(I)I

    move-result v4

    aput v4, v1, v17

    .line 353
    :cond_1f0
    :goto_1f0
    if-nez v23, :cond_1f5

    invoke-virtual {v15, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->invertDiamond([I)V

    .line 354
    :cond_1f5
    aget v4, v1, v20

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->getCenter()I

    move-result v6

    add-int/2addr v4, v6

    aput v4, v12, v9

    add-int/lit8 v4, v9, 0x1

    aget v6, v1, v17

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->getCenter()I

    move-result v16

    add-int v6, v6, v16

    aput v6, v12, v4

    .line 339
    .end local v23    # "inDiamond":Z
    if-eq v9, v2, :cond_275

    add-int v9, v9, v21

    move/from16 v4, v21

    move/from16 v6, v22

    goto/16 :goto_153

    .end local v22    # "method":I
    .restart local v6    # "method":I
    :cond_214
    move/from16 v22, v6

    .end local v6    # "method":I
    .restart local v22    # "method":I
    goto :goto_275

    .line 334
    .end local v1    # "orig":[I
    .end local v5    # "pred":[I
    .end local v9    # "i":I
    .end local v14    # "bits":I
    .end local v15    # "oct":Lcom/exampletest/mobilestudiotest/render/Draco$Octa;
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v22    # "method":I
    .restart local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v6    # "method":I
    :cond_217
    move-object/from16 v18, v2

    move/from16 v22, v6

    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v6    # "method":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v22    # "method":I
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "bad normal transform data"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 357
    .end local v13    # "maxQ":I
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v22    # "method":I
    .restart local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v6    # "method":I
    :cond_223
    move-object/from16 v18, v2

    move/from16 v22, v6

    move/from16 v20, v9

    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v6    # "method":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v22    # "method":I
    invoke-virtual/range {p3 .. p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v1

    .local v1, "mn":I
    invoke-virtual/range {p3 .. p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v2

    .line 358
    .local v2, "mx":I
    const-string v4, "bad wrap transform data"

    if-gt v1, v2, :cond_26b

    .line 359
    int-to-long v5, v2

    int-to-long v13, v1

    sub-long/2addr v5, v13

    .line 360
    .local v5, "dif":J
    const-wide/32 v13, 0x7fffffff

    cmp-long v9, v5, v13

    if-gez v9, :cond_265

    .line 361
    const-wide/16 v13, 0x1

    add-long/2addr v13, v5

    long-to-int v4, v13

    .line 362
    .local v4, "maxDif":I
    const/4 v9, 0x0

    .restart local v9    # "i":I
    :goto_244
    if-ge v9, v11, :cond_275

    .line 363
    if-ge v9, v3, :cond_24b

    move/from16 v13, v20

    goto :goto_24f

    :cond_24b
    sub-int v13, v9, v3

    aget v13, v12, v13

    .line 364
    .local v13, "p":I
    :goto_24f
    if-le v13, v2, :cond_253

    move v13, v2

    goto :goto_256

    :cond_253
    if-ge v13, v1, :cond_256

    move v13, v1

    .line 365
    :cond_256
    :goto_256
    aget v14, v12, v9

    add-int/2addr v14, v13

    .line 366
    .local v14, "o":I
    if-le v14, v2, :cond_25d

    sub-int/2addr v14, v4

    goto :goto_260

    :cond_25d
    if-ge v14, v1, :cond_260

    add-int/2addr v14, v4

    .line 367
    :cond_260
    :goto_260
    aput v14, v12, v9

    .line 362
    .end local v13    # "p":I
    .end local v14    # "o":I
    add-int/lit8 v9, v9, 0x1

    goto :goto_244

    .line 360
    .end local v4    # "maxDif":I
    .end local v9    # "i":I
    :cond_265
    new-instance v9, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v9, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v9

    .line 358
    .end local v5    # "dif":J
    :cond_26b
    new-instance v5, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v5, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 330
    .end local v1    # "mn":I
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v22    # "method":I
    .local v2, "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v6    # "method":I
    :cond_271
    move-object/from16 v18, v2

    move/from16 v22, v6

    .line 371
    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v6    # "method":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v22    # "method":I
    :cond_275
    :goto_275
    move-object/from16 v1, p1

    invoke-virtual {v1, v12}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->setPortable([I)V

    .line 372
    return-void

    .line 323
    .end local v10    # "positive":Z
    .end local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v22    # "method":I
    .restart local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v6    # "method":I
    .local v13, "nb":I
    :cond_27b
    move-object/from16 v1, p1

    move-object/from16 v18, v2

    move/from16 v22, v6

    .end local v2    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v6    # "method":I
    .restart local v18    # "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v22    # "method":I
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v4, "bad raw integer size"

    invoke-direct {v2, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method private final decodeSymbols(IILcom/exampletest/mobilestudiotest/render/Draco$Reader;)[I
    .registers 13
    .param p1, "n"    # I
    .param p2, "comps"    # I
    .param p3, "r"    # Lcom/exampletest/mobilestudiotest/render/Draco$Reader;

    .line 173
    new-array v0, p1, [I

    .line 174
    .local v0, "out":[I
    if-nez p1, :cond_5

    return-object v0

    .line 175
    :cond_5
    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v1

    packed-switch v1, :pswitch_data_c6

    .line 200
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "unknown symbol coding"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 193
    :pswitch_14
    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v1

    .line 194
    .local v1, "maxBits":I
    const/4 v2, 0x1

    if-lt v1, v2, :cond_40

    const/16 v2, 0x12

    if-gt v1, v2, :cond_40

    .line 195
    invoke-direct {p0, p3, v1}, Lcom/exampletest/mobilestudiotest/render/Draco;->createSymbolDecoder(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;

    move-result-object v2

    .line 196
    .local v2, "dec":Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->getNumSymbols()I

    move-result v3

    if-eqz v3, :cond_38

    .line 197
    invoke-virtual {v2, p3}, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->start(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;)V

    .line 198
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_2d
    if-ge v3, p1, :cond_b5

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->read()I

    move-result v4

    aput v4, v0, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_2d

    .line 196
    .end local v3    # "i":I
    :cond_38
    new-instance v3, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v4, "no symbols"

    invoke-direct {v3, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v3

    .line 194
    .end local v2    # "dec":Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;
    :cond_40
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "bad symbol bit length "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 177
    .end local v1    # "maxBits":I
    :pswitch_59
    const/4 v1, 0x5

    invoke-direct {p0, p3, v1}, Lcom/exampletest/mobilestudiotest/render/Draco;->createSymbolDecoder(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;

    move-result-object v1

    .line 178
    .local v1, "tags":Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;
    invoke-virtual {v1, p3}, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->start(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;)V

    .line 179
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->getNumSymbols()I

    move-result v2

    if-eqz v2, :cond_be

    .line 180
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;

    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getB()[B

    move-result-object v3

    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getPos()I

    move-result v4

    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getEnd()I

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;-><init>([BII)V

    .line 181
    .local v2, "bits":Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;
    const/4 v3, 0x0

    .line 182
    .local v3, "id":I
    const/4 v4, 0x0

    .line 183
    .local v4, "i":I
    :goto_7a
    if-ge v4, p1, :cond_9f

    .line 184
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->read()I

    move-result v5

    .line 185
    .local v5, "len":I
    const/16 v6, 0x20

    if-gt v5, v6, :cond_97

    .line 186
    const/4 v6, 0x0

    .local v6, "j":I
    :goto_85
    if-ge v6, p2, :cond_95

    if-ge v3, p1, :cond_95

    add-int/lit8 v7, v3, 0x1

    .end local v3    # "id":I
    .local v7, "id":I
    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->get(I)I

    move-result v8

    aput v8, v0, v3

    add-int/lit8 v6, v6, 0x1

    move v3, v7

    goto :goto_85

    .line 187
    .end local v6    # "j":I
    .end local v7    # "id":I
    .restart local v3    # "id":I
    :cond_95
    add-int/2addr v4, p2

    .end local v5    # "len":I
    goto :goto_7a

    .line 185
    .restart local v5    # "len":I
    :cond_97
    new-instance v6, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v7, "bad tag"

    invoke-direct {v6, v7}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v6

    .line 189
    .end local v5    # "len":I
    :cond_9f
    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getPos()I

    move-result v5

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->bytesUsed()I

    move-result v6

    add-int/2addr v5, v6

    invoke-virtual {p3, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->setPos(I)V

    .line 190
    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getPos()I

    move-result v5

    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getEnd()I

    move-result v6

    if-gt v5, v6, :cond_b6

    .line 202
    .end local v1    # "tags":Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;
    .end local v2    # "bits":Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;
    .end local v3    # "id":I
    .end local v4    # "i":I
    :cond_b5
    return-object v0

    .line 190
    .restart local v1    # "tags":Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;
    .restart local v2    # "bits":Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;
    .restart local v3    # "id":I
    .restart local v4    # "i":I
    :cond_b6
    new-instance v5, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v6, "unexpected end of data"

    invoke-direct {v5, v6}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 179
    .end local v2    # "bits":Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;
    .end local v3    # "id":I
    .end local v4    # "i":I
    :cond_be
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v3, "no tag symbols"

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v2

    :pswitch_data_c6
    .packed-switch 0x0
        :pswitch_59
        :pswitch_14
    .end packed-switch
.end method

.method private final decodeTransformData(Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;Lcom/exampletest/mobilestudiotest/render/Draco$Reader;)V
    .registers 7
    .param p1, "d"    # Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    .param p2, "r"    # Lcom/exampletest/mobilestudiotest/render/Draco$Reader;

    .line 375
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v0

    packed-switch v0, :pswitch_data_50

    goto :goto_4f

    .line 382
    :pswitch_8
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->setOctBits(I)V

    goto :goto_4f

    .line 377
    :pswitch_10
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getAtt()Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getComponents()I

    move-result v0

    new-array v1, v0, [F

    const/4 v2, 0x0

    :goto_1b
    if-ge v2, v0, :cond_26

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->f32()F

    move-result v3

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1b

    :cond_26
    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->setMinValues([F)V

    .line 378
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->f32()F

    move-result v0

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->setRange(F)V

    .line 379
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->setQBits(I)V

    .line 380
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getQBits()I

    move-result v0

    const/4 v1, 0x1

    if-lt v0, v1, :cond_47

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getQBits()I

    move-result v0

    const/16 v1, 0x1e

    if-gt v0, v1, :cond_47

    goto :goto_4f

    :cond_47
    new-instance v0, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v1, "bad quantization"

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 384
    :goto_4f
    return-void

    :pswitch_data_50
    .packed-switch 0x2
        :pswitch_10
        :pswitch_8
    .end packed-switch
.end method

.method private final finish(Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;I)V
    .registers 13
    .param p1, "d"    # Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    .param p2, "n"    # I

    .line 387
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getAtt()Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    move-result-object v0

    .line 388
    .local v0, "a":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getKind()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    packed-switch v1, :pswitch_data_86

    goto/16 :goto_85

    .line 397
    :pswitch_f
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getOctBits()I

    move-result v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;-><init>(I)V

    .line 398
    .local v1, "oct":Lcom/exampletest/mobilestudiotest/render/Draco$Octa;
    mul-int/lit8 v2, p2, 0x3

    new-array v2, v2, [F

    .line 399
    .local v2, "out":[F
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_1d
    if-ge v4, p2, :cond_38

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getPortable()[I

    move-result-object v5

    mul-int/lit8 v6, v4, 0x2

    aget v5, v5, v6

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getPortable()[I

    move-result-object v6

    mul-int/lit8 v7, v4, 0x2

    add-int/2addr v7, v3

    aget v6, v6, v7

    mul-int/lit8 v7, v4, 0x3

    invoke-virtual {v1, v5, v6, v2, v7}, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->toUnit(II[FI)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_1d

    .line 400
    .end local v4    # "i":I
    :cond_38
    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->setValues([F)V

    goto :goto_85

    .line 391
    .end local v1    # "oct":Lcom/exampletest/mobilestudiotest/render/Draco$Octa;
    .end local v2    # "out":[F
    :pswitch_3c
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getQBits()I

    move-result v1

    shl-int v1, v3, v1

    sub-int/2addr v1, v3

    .line 392
    .local v1, "maxQ":I
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getRange()F

    move-result v3

    int-to-float v4, v1

    div-float/2addr v3, v4

    .line 393
    .local v3, "delta":F
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getComponents()I

    move-result v4

    .line 394
    .local v4, "c":I
    mul-int v5, p2, v4

    new-array v6, v5, [F

    :goto_51
    if-ge v2, v5, :cond_69

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getPortable()[I

    move-result-object v7

    aget v7, v7, v2

    int-to-float v7, v7

    mul-float/2addr v7, v3

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getMinValues()[F

    move-result-object v8

    rem-int v9, v2, v4

    aget v8, v8, v9

    add-float/2addr v7, v8

    aput v7, v6, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_51

    :cond_69
    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->setValues([F)V

    .end local v1    # "maxQ":I
    .end local v3    # "delta":F
    .end local v4    # "c":I
    goto :goto_85

    .line 389
    :pswitch_6d
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getPortable()[I

    move-result-object v1

    array-length v1, v1

    new-array v3, v1, [F

    :goto_74
    if-ge v2, v1, :cond_82

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getPortable()[I

    move-result-object v4

    aget v4, v4, v2

    int-to-float v4, v4

    aput v4, v3, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_74

    :cond_82
    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->setValues([F)V

    .line 403
    :goto_85
    return-void

    :pswitch_data_86
    .packed-switch 0x1
        :pswitch_6d
        :pswitch_3c
        :pswitch_f
    .end packed-switch
.end method

.method private final precisionFor(I)I
    .registers 5
    .param p1, "bits"    # I

    .line 146
    mul-int/lit8 v0, p1, 0x3

    div-int/lit8 v0, v0, 0x2

    const/16 v1, 0xc

    const/16 v2, 0x14

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v0

    return v0
.end method

.method private final readTyped(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)F
    .registers 10
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/render/Draco$Reader;
    .param p2, "dt"    # I

    .line 286
    const/16 v0, 0x20

    const-wide v1, 0xffffffffL

    packed-switch p2, :pswitch_data_74

    .line 296
    new-instance v0, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "bad data type "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 295
    :pswitch_23
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v3

    int-to-long v3, v3

    and-long/2addr v3, v1

    .local v3, "lo":J
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v1

    int-to-long v1, v1

    .local v1, "hi":J
    shl-long v5, v1, v0

    or-long/2addr v5, v3

    invoke-static {v5, v6}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v5

    double-to-float v0, v5

    .end local v1    # "hi":J
    .end local v3    # "lo":J
    goto :goto_72

    .line 294
    :pswitch_37
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->f32()F

    move-result v0

    goto :goto_72

    .line 293
    :pswitch_3c
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v3

    int-to-long v3, v3

    and-long/2addr v3, v1

    .restart local v3    # "lo":J
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v1

    int-to-long v1, v1

    .restart local v1    # "hi":J
    shl-long v5, v1, v0

    or-long/2addr v5, v3

    long-to-float v0, v5

    .end local v1    # "hi":J
    .end local v3    # "lo":J
    goto :goto_72

    .line 292
    :pswitch_4c
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v0

    int-to-long v3, v0

    and-long/2addr v3, v1

    long-to-float v0, v3

    goto :goto_72

    .line 291
    :pswitch_54
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v0

    int-to-float v0, v0

    goto :goto_72

    .line 290
    :pswitch_5a
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u16()I

    move-result v0

    int-to-float v0, v0

    goto :goto_72

    .line 289
    :pswitch_60
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u16()I

    move-result v0

    int-to-short v0, v0

    int-to-float v0, v0

    goto :goto_72

    .line 288
    :pswitch_67
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v0

    int-to-float v0, v0

    goto :goto_72

    .line 287
    :pswitch_6d
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i8()I

    move-result v0

    int-to-float v0, v0

    .line 297
    :goto_72
    return v0

    nop

    :pswitch_data_74
    .packed-switch 0x1
        :pswitch_6d
        :pswitch_67
        :pswitch_60
        :pswitch_5a
        :pswitch_54
        :pswitch_4c
        :pswitch_3c
        :pswitch_3c
        :pswitch_37
        :pswitch_23
        :pswitch_67
    .end packed-switch
.end method

.method private final rotate([II)V
    .registers 8
    .param p1, "p"    # [I
    .param p2, "count"    # I

    .line 261
    const/4 v0, 0x0

    aget v1, p1, v0

    .local v1, "x":I
    const/4 v2, 0x1

    aget v3, p1, v2

    .line 262
    .local v3, "y":I
    packed-switch p2, :pswitch_data_1e

    goto :goto_1c

    .line 265
    :pswitch_a
    neg-int v4, v3

    aput v4, p1, v0

    aput v1, p1, v2

    goto :goto_1c

    .line 264
    :pswitch_10
    neg-int v4, v1

    aput v4, p1, v0

    neg-int v0, v3

    aput v0, p1, v2

    goto :goto_1c

    .line 263
    :pswitch_17
    aput v3, p1, v0

    neg-int v0, v1

    aput v0, p1, v2

    .line 267
    :goto_1c
    return-void

    nop

    :pswitch_data_1e
    .packed-switch 0x1
        :pswitch_17
        :pswitch_10
        :pswitch_a
    .end packed-switch
.end method

.method private final rotationCount(II)I
    .registers 6
    .param p1, "x"    # I
    .param p2, "y"    # I

    .line 254
    nop

    .line 255
    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez p1, :cond_e

    if-nez p2, :cond_a

    move v0, v2

    goto :goto_19

    :cond_a
    if-lez p2, :cond_19

    move v0, v1

    goto :goto_19

    .line 256
    :cond_e
    if-lez p1, :cond_14

    if-ltz p2, :cond_19

    const/4 v0, 0x2

    goto :goto_19

    .line 257
    :cond_14
    if-gtz p2, :cond_18

    move v0, v2

    goto :goto_19

    :cond_18
    move v0, v1

    .line 258
    :cond_19
    :goto_19
    return v0
.end method

.method private final skipMetadata(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)V
    .registers 10
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/render/Draco$Reader;
    .param p2, "depth"    # I

    .line 408
    const/16 v0, 0x20

    if-gt p2, v0, :cond_3a

    .line 409
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v0

    .line 410
    .local v0, "entries":I
    const/4 v1, 0x0

    move v2, v1

    :goto_a
    if-ge v2, v0, :cond_1f

    move v3, v2

    .line 490
    .local v3, "it\\1":I
    const/4 v4, 0x0

    .line 410
    .local v4, "$i$a$-repeat-Draco$skipMetadata$1\\1\\410\\0":I
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v5

    invoke-virtual {p1, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->skip(I)V

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v5

    invoke-virtual {p1, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->skip(I)V

    .end local v3    # "it\\1":I
    .end local v4    # "$i$a$-repeat-Draco$skipMetadata$1\\1\\410\\0":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_a

    .line 411
    :cond_1f
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v2

    .line 412
    .local v2, "subs":I
    nop

    :goto_24
    if-ge v1, v2, :cond_39

    move v3, v1

    .line 490
    .local v3, "it\\2":I
    const/4 v4, 0x0

    .line 412
    .local v4, "$i$a$-repeat-Draco$skipMetadata$2\\2\\412\\0":I
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v5

    invoke-virtual {p1, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->skip(I)V

    sget-object v5, Lcom/exampletest/mobilestudiotest/render/Draco;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/Draco;

    add-int/lit8 v6, p2, 0x1

    invoke-direct {v5, p1, v6}, Lcom/exampletest/mobilestudiotest/render/Draco;->skipMetadata(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)V

    .end local v3    # "it\\2":I
    .end local v4    # "$i$a$-repeat-Draco$skipMetadata$2\\2\\412\\0":I
    add-int/lit8 v1, v1, 0x1

    goto :goto_24

    .line 413
    :cond_39
    return-void

    .line 408
    .end local v0    # "entries":I
    .end local v2    # "subs":I
    :cond_3a
    new-instance v0, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v1, "metadata too deep"

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static synthetic skipMetadata$default(Lcom/exampletest/mobilestudiotest/render/Draco;Lcom/exampletest/mobilestudiotest/render/Draco$Reader;IILjava/lang/Object;)V
    .registers 5

    .line 407
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_5

    const/4 p2, 0x0

    :cond_5
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/render/Draco;->skipMetadata(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;I)V

    return-void
.end method

.method private final typeLength(I)I
    .registers 5
    .param p1, "dt"    # I

    .line 284
    packed-switch p1, :pswitch_data_26

    new-instance v0, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "bad data type "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_1c
    const/16 v0, 0x8

    goto :goto_24

    :pswitch_1f
    const/4 v0, 0x4

    goto :goto_24

    :pswitch_21
    const/4 v0, 0x2

    goto :goto_24

    :pswitch_23
    const/4 v0, 0x1

    :goto_24
    return v0

    nop

    :pswitch_data_26
    .packed-switch 0x1
        :pswitch_23
        :pswitch_23
        :pswitch_21
        :pswitch_21
        :pswitch_1f
        :pswitch_1f
        :pswitch_1c
        :pswitch_1c
        :pswitch_1f
        :pswitch_1c
        :pswitch_23
    .end packed-switch
.end method


# virtual methods
.method public final decode([BII)Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;
    .registers 35
    .param p1, "bytes"    # [B
    .param p2, "off"    # I
    .param p3, "len"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    const-string v3, "bytes"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 418
    new-instance v3, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;

    add-int v4, v2, p3

    invoke-direct {v3, v1, v2, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;-><init>([BII)V

    .line 419
    .local v3, "r":Lcom/exampletest/mobilestudiotest/render/Draco$Reader;
    invoke-virtual/range {p0 .. p2}, Lcom/exampletest/mobilestudiotest/render/Draco;->isDraco([BI)Z

    move-result v4

    if-eqz v4, :cond_342

    .line 420
    const/4 v4, 0x5

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->skip(I)V

    .line 421
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v5

    .local v5, "major":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v6

    .line 422
    .local v6, "minor":I
    mul-int/lit16 v7, v5, 0x100

    add-int/2addr v7, v6

    .line 423
    .local v7, "version":I
    const/4 v8, 0x2

    if-ne v5, v8, :cond_319

    .line 424
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v9

    const/4 v10, 0x1

    if-ne v9, v10, :cond_311

    .line 425
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v9

    .line 426
    .local v9, "method":I
    if-nez v9, :cond_309

    .line 427
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u16()I

    move-result v11

    .line 428
    .local v11, "flags":I
    const v12, 0x8000

    and-int/2addr v12, v11

    const/4 v13, 0x0

    if-eqz v12, :cond_63

    .line 429
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v12

    .line 430
    .local v12, "attMeta":I
    move v14, v13

    :goto_47
    const/4 v15, 0x0

    if-ge v14, v12, :cond_5d

    move/from16 v16, v14

    .line 490
    .local v16, "it\\1":I
    const/16 v17, 0x0

    .line 430
    .local v17, "$i$a$-repeat-Draco$decode$1\\1\\430\\0":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varint()J

    move/from16 v18, v4

    sget-object v4, Lcom/exampletest/mobilestudiotest/render/Draco;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/Draco;

    invoke-static {v4, v3, v13, v8, v15}, Lcom/exampletest/mobilestudiotest/render/Draco;->skipMetadata$default(Lcom/exampletest/mobilestudiotest/render/Draco;Lcom/exampletest/mobilestudiotest/render/Draco$Reader;IILjava/lang/Object;)V

    .end local v16    # "it\\1":I
    .end local v17    # "$i$a$-repeat-Draco$decode$1\\1\\430\\0":I
    add-int/lit8 v14, v14, 0x1

    move/from16 v4, v18

    goto :goto_47

    .line 431
    :cond_5d
    move/from16 v18, v4

    invoke-static {v0, v3, v13, v8, v15}, Lcom/exampletest/mobilestudiotest/render/Draco;->skipMetadata$default(Lcom/exampletest/mobilestudiotest/render/Draco;Lcom/exampletest/mobilestudiotest/render/Draco$Reader;IILjava/lang/Object;)V

    goto :goto_65

    .line 428
    .end local v12    # "attMeta":I
    :cond_63
    move/from16 v18, v4

    .line 434
    :goto_65
    const/4 v4, 0x0

    .local v4, "numFaces":I
    const/4 v12, 0x0

    .line 435
    .local v12, "numPoints":I
    const/16 v14, 0x202

    if-ge v7, v14, :cond_74

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v4

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v12

    goto :goto_7c

    :cond_74
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v4

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v12

    .line 436
    :goto_7c
    if-ltz v4, :cond_2fb

    const v15, 0x1312d00

    if-gt v4, v15, :cond_2fb

    .line 437
    if-ltz v12, :cond_2f3

    .line 438
    mul-int/lit8 v15, v4, 0x3

    new-array v15, v15, [I

    .line 439
    .local v15, "faces":[I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v16

    if-nez v16, :cond_c0

    .line 440
    mul-int/lit8 v14, v4, 0x3

    invoke-direct {v0, v14, v10, v3}, Lcom/exampletest/mobilestudiotest/render/Draco;->decodeSymbols(IILcom/exampletest/mobilestudiotest/render/Draco$Reader;)[I

    move-result-object v14

    .line 441
    .local v14, "enc":[I
    const/16 v16, 0x0

    .line 442
    .local v16, "last":I
    const/16 v17, 0x0

    .local v17, "i":I
    array-length v10, v14

    move/from16 v13, v16

    move/from16 v8, v17

    .end local v16    # "last":I
    .end local v17    # "i":I
    .local v8, "i":I
    .local v13, "last":I
    :goto_9e
    if-ge v8, v10, :cond_ea

    .line 443
    aget v17, v14, v8

    .line 444
    .local v17, "e":I
    ushr-int/lit8 v1, v17, 0x1

    .line 445
    .local v1, "diff":I
    and-int/lit8 v19, v17, 0x1

    if-eqz v19, :cond_b6

    if-gt v1, v13, :cond_ac

    neg-int v1, v1

    goto :goto_b8

    :cond_ac
    new-instance v10, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    move/from16 v19, v1

    .end local v1    # "diff":I
    .local v19, "diff":I
    const-string v1, "bad index"

    invoke-direct {v10, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v10

    .end local v19    # "diff":I
    .restart local v1    # "diff":I
    :cond_b6
    move/from16 v19, v1

    .line 446
    :goto_b8
    add-int/2addr v13, v1

    .line 447
    aput v13, v15, v8

    .line 442
    .end local v1    # "diff":I
    .end local v17    # "e":I
    add-int/lit8 v8, v8, 0x1

    move-object/from16 v1, p1

    goto :goto_9e

    .line 450
    .end local v8    # "i":I
    .end local v13    # "last":I
    .end local v14    # "enc":[I
    :cond_c0
    const/4 v1, 0x0

    .local v1, "i":I
    array-length v8, v15

    :goto_c2
    if-ge v1, v8, :cond_ea

    .line 451
    const/16 v10, 0x100

    if-ge v12, v10, :cond_cd

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v10

    goto :goto_e5

    .line 452
    :cond_cd
    const/high16 v10, 0x10000

    if-ge v12, v10, :cond_d6

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u16()I

    move-result v10

    goto :goto_e5

    .line 453
    :cond_d6
    const/high16 v10, 0x200000

    if-ge v12, v10, :cond_e1

    if-lt v7, v14, :cond_e1

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v10

    goto :goto_e5

    .line 454
    :cond_e1
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v10

    :goto_e5
    aput v10, v15, v1

    .line 450
    add-int/lit8 v1, v1, 0x1

    goto :goto_c2

    .line 457
    .end local v1    # "i":I
    :cond_ea
    array-length v1, v15

    const/4 v8, 0x0

    :goto_ec
    if-ge v8, v1, :cond_ff

    aget v10, v15, v8

    .local v10, "f":I
    if-ltz v10, :cond_f7

    if-ge v10, v12, :cond_f7

    .end local v10    # "f":I
    add-int/lit8 v8, v8, 0x1

    goto :goto_ec

    .restart local v10    # "f":I
    :cond_f7
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v8, "face index out of range"

    invoke-direct {v1, v8}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 459
    .end local v10    # "f":I
    :cond_ff
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 460
    .local v1, "groups":Ljava/util/ArrayList;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v8

    .line 461
    .local v8, "nDec":I
    const/4 v10, 0x0

    .local v10, "g":I
    :goto_109
    if-ge v10, v8, :cond_257

    .line 462
    const/16 v14, 0x200

    if-ge v7, v14, :cond_114

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v14

    goto :goto_118

    :cond_114
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varintInt()I

    move-result v14

    .line 463
    .local v14, "nAtt":I
    :goto_118
    if-lez v14, :cond_247

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getRemaining()I

    move-result v17

    mul-int/lit8 v13, v17, 0x5

    if-gt v14, v13, :cond_247

    .line 464
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 465
    .local v13, "atts":Ljava/util/ArrayList;
    const/16 v17, 0x0

    move/from16 v2, v17

    .local v2, "k":I
    :goto_12b
    if-ge v2, v14, :cond_194

    .line 466
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v21

    move/from16 v17, v2

    .end local v2    # "k":I
    .local v17, "k":I
    .local v21, "type":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v2

    .local v2, "dt":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v23

    .local v23, "comps":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v27

    .line 467
    .local v27, "norm":I
    if-eqz v2, :cond_184

    move/from16 v28, v4

    .end local v4    # "numFaces":I
    .local v28, "numFaces":I
    const/16 v4, 0xb

    if-gt v2, v4, :cond_17d

    if-eqz v23, :cond_17d

    .line 468
    const/16 v4, 0x103

    if-ge v7, v4, :cond_157

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u16()I

    move-result v4

    move/from16 v29, v7

    move/from16 v30, v8

    .end local v7    # "version":I
    .end local v8    # "nDec":I
    .local v29, "version":I
    .local v30, "nDec":I
    int-to-long v7, v4

    goto :goto_15f

    .end local v29    # "version":I
    .end local v30    # "nDec":I
    .restart local v7    # "version":I
    .restart local v8    # "nDec":I
    :cond_157
    move/from16 v29, v7

    move/from16 v30, v8

    .end local v7    # "version":I
    .end local v8    # "nDec":I
    .restart local v29    # "version":I
    .restart local v30    # "nDec":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varint()J

    move-result-wide v7

    :goto_15f
    move-wide/from16 v25, v7

    .line 469
    .local v25, "uid":J
    new-instance v20, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    if-lez v27, :cond_168

    const/16 v24, 0x1

    goto :goto_16a

    :cond_168
    const/16 v24, 0x0

    :goto_16a
    move/from16 v22, v2

    .end local v2    # "dt":I
    .local v22, "dt":I
    invoke-direct/range {v20 .. v26}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;-><init>(IIIZJ)V

    move-object/from16 v2, v20

    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 465
    .end local v21    # "type":I
    .end local v22    # "dt":I
    .end local v23    # "comps":I
    .end local v25    # "uid":J
    .end local v27    # "norm":I
    add-int/lit8 v2, v17, 0x1

    move/from16 v4, v28

    move/from16 v7, v29

    move/from16 v8, v30

    .end local v17    # "k":I
    .local v2, "k":I
    goto :goto_12b

    .line 467
    .end local v29    # "version":I
    .end local v30    # "nDec":I
    .local v2, "dt":I
    .restart local v7    # "version":I
    .restart local v8    # "nDec":I
    .restart local v17    # "k":I
    .restart local v21    # "type":I
    .restart local v23    # "comps":I
    .restart local v27    # "norm":I
    :cond_17d
    move/from16 v22, v2

    move/from16 v29, v7

    move/from16 v30, v8

    .end local v2    # "dt":I
    .end local v7    # "version":I
    .end local v8    # "nDec":I
    .restart local v22    # "dt":I
    .restart local v29    # "version":I
    .restart local v30    # "nDec":I
    goto :goto_18c

    .end local v22    # "dt":I
    .end local v28    # "numFaces":I
    .end local v29    # "version":I
    .end local v30    # "nDec":I
    .restart local v2    # "dt":I
    .restart local v4    # "numFaces":I
    .restart local v7    # "version":I
    .restart local v8    # "nDec":I
    :cond_184
    move/from16 v22, v2

    move/from16 v28, v4

    move/from16 v29, v7

    move/from16 v30, v8

    .end local v2    # "dt":I
    .end local v4    # "numFaces":I
    .end local v7    # "version":I
    .end local v8    # "nDec":I
    .restart local v22    # "dt":I
    .restart local v28    # "numFaces":I
    .restart local v29    # "version":I
    .restart local v30    # "nDec":I
    :goto_18c
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v4, "bad attribute"

    invoke-direct {v2, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 465
    .end local v17    # "k":I
    .end local v21    # "type":I
    .end local v22    # "dt":I
    .end local v23    # "comps":I
    .end local v27    # "norm":I
    .end local v28    # "numFaces":I
    .end local v29    # "version":I
    .end local v30    # "nDec":I
    .local v2, "k":I
    .restart local v4    # "numFaces":I
    .restart local v7    # "version":I
    .restart local v8    # "nDec":I
    :cond_194
    move/from16 v17, v2

    move/from16 v28, v4

    move/from16 v29, v7

    move/from16 v30, v8

    .line 471
    .end local v2    # "k":I
    .end local v4    # "numFaces":I
    .end local v7    # "version":I
    .end local v8    # "nDec":I
    .restart local v28    # "numFaces":I
    .restart local v29    # "version":I
    .restart local v30    # "nDec":I
    move-object v2, v13

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 491
    .local v4, "$i$f$map\\2\\471":I
    new-instance v7, Ljava/util/ArrayList;

    const/16 v8, 0xa

    invoke-static {v2, v8}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\3":Ljava/util/Collection;
    move-object v8, v2

    .local v8, "$this$mapTo\\3":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 492
    .local v17, "$i$f$mapTo\\3\\491":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v19

    :goto_1b4
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    move-result v20

    if-eqz v20, :cond_22b

    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v20

    .line 493
    .local v20, "item\\3":Ljava/lang/Object;
    move-object/from16 v21, v2

    .end local v2    # "$this$map\\2":Ljava/lang/Iterable;
    .local v21, "$this$map\\2":Ljava/lang/Iterable;
    move-object/from16 v2, v20

    check-cast v2, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    .local v2, "a\\4":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    const/16 v22, 0x0

    .line 472
    .local v22, "$i$a$-map-Draco$decode$decs$1\\4\\493\\0":I
    move/from16 v23, v4

    .end local v4    # "$i$f$map\\2\\471":I
    .local v23, "$i$f$map\\2\\471":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v4

    .line 473
    .local v4, "kind\\4":I
    move-object/from16 v24, v8

    .end local v8    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .local v24, "$this$mapTo\\3":Ljava/lang/Iterable;
    const/4 v8, 0x3

    if-gt v4, v8, :cond_20e

    .line 474
    const/4 v8, 0x2

    if-eq v4, v8, :cond_1da

    const/4 v8, 0x3

    if-eq v4, v8, :cond_1da

    move/from16 v26, v9

    goto :goto_1e4

    :cond_1da
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getDataType()I

    move-result v8

    move/from16 v26, v9

    .end local v9    # "method":I
    .local v26, "method":I
    const/16 v9, 0x9

    if-ne v8, v9, :cond_206

    .line 475
    :goto_1e4
    const/4 v8, 0x3

    if-ne v4, v8, :cond_1f5

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getComponents()I

    move-result v9

    if-eq v9, v8, :cond_1f5

    new-instance v8, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v9, "bad normal attribute"

    invoke-direct {v8, v9}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v8

    .line 476
    :cond_1f5
    new-instance v8, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;

    invoke-direct {v8, v2, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;-><init>(Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;I)V

    .line 493
    .end local v2    # "a\\4":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v4    # "kind\\4":I
    .end local v22    # "$i$a$-map-Draco$decode$decs$1\\4\\493\\0":I
    invoke-interface {v7, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v2, v21

    move/from16 v4, v23

    move-object/from16 v8, v24

    move/from16 v9, v26

    goto :goto_1b4

    .line 474
    .restart local v2    # "a\\4":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .restart local v4    # "kind\\4":I
    .restart local v22    # "$i$a$-map-Draco$decode$decs$1\\4\\493\\0":I
    :cond_206
    new-instance v8, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v9, "bad attribute type"

    invoke-direct {v8, v9}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v8

    .line 473
    .end local v26    # "method":I
    .restart local v9    # "method":I
    :cond_20e
    move/from16 v26, v9

    .end local v9    # "method":I
    .restart local v26    # "method":I
    new-instance v8, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v19, v2

    .end local v2    # "a\\4":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .local v19, "a\\4":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    const-string v2, "unknown attribute decoder "

    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v8, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v8

    .line 494
    .end local v19    # "a\\4":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v20    # "item\\3":Ljava/lang/Object;
    .end local v21    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v22    # "$i$a$-map-Draco$decode$decs$1\\4\\493\\0":I
    .end local v23    # "$i$f$map\\2\\471":I
    .end local v24    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .end local v26    # "method":I
    .local v2, "$this$map\\2":Ljava/lang/Iterable;
    .local v4, "$i$f$map\\2\\471":I
    .restart local v8    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .restart local v9    # "method":I
    :cond_22b
    move-object/from16 v21, v2

    move/from16 v23, v4

    move-object/from16 v24, v8

    move/from16 v26, v9

    .end local v2    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$map\\2\\471":I
    .end local v7    # "destination\\3":Ljava/util/Collection;
    .end local v8    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .end local v9    # "method":I
    .end local v17    # "$i$f$mapTo\\3\\491":I
    .restart local v21    # "$this$map\\2":Ljava/lang/Iterable;
    .restart local v23    # "$i$f$map\\2\\471":I
    .restart local v26    # "method":I
    move-object v2, v7

    check-cast v2, Ljava/util/List;

    .line 491
    nop

    .line 471
    .end local v21    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v23    # "$i$f$map\\2\\471":I
    nop

    .line 478
    .local v2, "decs":Ljava/util/List;
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 461
    .end local v2    # "decs":Ljava/util/List;
    .end local v13    # "atts":Ljava/util/ArrayList;
    .end local v14    # "nAtt":I
    add-int/lit8 v10, v10, 0x1

    move/from16 v2, p2

    move/from16 v4, v28

    move/from16 v7, v29

    move/from16 v8, v30

    goto/16 :goto_109

    .line 463
    .end local v26    # "method":I
    .end local v28    # "numFaces":I
    .end local v29    # "version":I
    .end local v30    # "nDec":I
    .local v4, "numFaces":I
    .local v7, "version":I
    .local v8, "nDec":I
    .restart local v9    # "method":I
    .restart local v14    # "nAtt":I
    :cond_247
    move/from16 v28, v4

    move/from16 v29, v7

    move/from16 v30, v8

    move/from16 v26, v9

    .end local v4    # "numFaces":I
    .end local v7    # "version":I
    .end local v8    # "nDec":I
    .end local v9    # "method":I
    .restart local v26    # "method":I
    .restart local v28    # "numFaces":I
    .restart local v29    # "version":I
    .restart local v30    # "nDec":I
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v4, "bad attribute count"

    invoke-direct {v2, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 461
    .end local v14    # "nAtt":I
    .end local v26    # "method":I
    .end local v28    # "numFaces":I
    .end local v29    # "version":I
    .end local v30    # "nDec":I
    .restart local v4    # "numFaces":I
    .restart local v7    # "version":I
    .restart local v8    # "nDec":I
    .restart local v9    # "method":I
    :cond_257
    move/from16 v28, v4

    move/from16 v29, v7

    move/from16 v30, v8

    move/from16 v26, v9

    .line 481
    .end local v4    # "numFaces":I
    .end local v7    # "version":I
    .end local v8    # "nDec":I
    .end local v9    # "method":I
    .end local v10    # "g":I
    .restart local v26    # "method":I
    .restart local v28    # "numFaces":I
    .restart local v29    # "version":I
    .restart local v30    # "nDec":I
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const-string v4, "iterator(...)"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_268
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2b5

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const-string v7, "next(...)"

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/util/List;

    .line 482
    .local v4, "decs":Ljava/util/List;
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_27d
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_28d

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;

    .local v8, "d":Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    invoke-direct {v0, v8, v12, v3}, Lcom/exampletest/mobilestudiotest/render/Draco;->decodePortable(Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;ILcom/exampletest/mobilestudiotest/render/Draco$Reader;)V

    .end local v8    # "d":Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    goto :goto_27d

    .line 483
    :cond_28d
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_291
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_2a1

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;

    .restart local v8    # "d":Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    invoke-direct {v0, v8, v3}, Lcom/exampletest/mobilestudiotest/render/Draco;->decodeTransformData(Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;Lcom/exampletest/mobilestudiotest/render/Draco$Reader;)V

    .end local v8    # "d":Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    goto :goto_291

    .line 484
    :cond_2a1
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_2a5
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_268

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;

    .restart local v8    # "d":Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    invoke-direct {v0, v8, v12}, Lcom/exampletest/mobilestudiotest/render/Draco;->finish(Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;I)V

    .end local v8    # "d":Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    goto :goto_2a5

    .line 486
    .end local v4    # "decs":Ljava/util/List;
    :cond_2b5
    move-object v2, v1

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->flatten(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\5":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 495
    .local v4, "$i$f$map\\5\\486":I
    new-instance v7, Ljava/util/ArrayList;

    const/16 v8, 0xa

    invoke-static {v2, v8}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\6":Ljava/util/Collection;
    move-object v8, v2

    .local v8, "$this$mapTo\\6":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 496
    .local v9, "$i$f$mapTo\\6\\495":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_2d2
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_2e9

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .line 497
    .local v13, "item\\6":Ljava/lang/Object;
    move-object v14, v13

    check-cast v14, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;

    .local v14, "it\\7":Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    const/16 v16, 0x0

    .line 486
    .local v16, "$i$a$-map-Draco$decode$2\\7\\497\\0":I
    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->getAtt()Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    move-result-object v14

    .line 497
    .end local v14    # "it\\7":Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
    .end local v16    # "$i$a$-map-Draco$decode$2\\7\\497\\0":I
    invoke-interface {v7, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2d2

    .line 498
    .end local v13    # "item\\6":Ljava/lang/Object;
    :cond_2e9
    nop

    .end local v7    # "destination\\6":Ljava/util/Collection;
    .end local v8    # "$this$mapTo\\6":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapTo\\6\\495":I
    check-cast v7, Ljava/util/List;

    .line 495
    nop

    .line 486
    .end local v2    # "$this$map\\5":Ljava/lang/Iterable;
    .end local v4    # "$i$f$map\\5\\486":I
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;

    invoke-direct {v2, v12, v15, v7}, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;-><init>(I[ILjava/util/List;)V

    return-object v2

    .line 437
    .end local v1    # "groups":Ljava/util/ArrayList;
    .end local v15    # "faces":[I
    .end local v26    # "method":I
    .end local v28    # "numFaces":I
    .end local v29    # "version":I
    .end local v30    # "nDec":I
    .local v4, "numFaces":I
    .local v7, "version":I
    .local v9, "method":I
    :cond_2f3
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "bad point count"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 436
    :cond_2fb
    move/from16 v28, v4

    move/from16 v29, v7

    move/from16 v26, v9

    .end local v4    # "numFaces":I
    .end local v7    # "version":I
    .end local v9    # "method":I
    .restart local v26    # "method":I
    .restart local v28    # "numFaces":I
    .restart local v29    # "version":I
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "bad face count"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 426
    .end local v11    # "flags":I
    .end local v12    # "numPoints":I
    .end local v26    # "method":I
    .end local v28    # "numFaces":I
    .end local v29    # "version":I
    .restart local v7    # "version":I
    .restart local v9    # "method":I
    :cond_309
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "Draco edgebreaker meshes aren\'t supported"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 424
    .end local v9    # "method":I
    :cond_311
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "not a triangle mesh"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 423
    :cond_319
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Draco version "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "."

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " isn\'t supported"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 419
    .end local v5    # "major":I
    .end local v6    # "minor":I
    .end local v7    # "version":I
    :cond_342
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "not Draco data"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final isDraco([BI)Z
    .registers 5
    .param p1, "b"    # [B
    .param p2, "off"    # I

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    array-length v0, p1

    add-int/lit8 v1, p2, 0x5

    if-lt v0, v1, :cond_32

    aget-byte v0, p1, p2

    const/16 v1, 0x44

    if-ne v0, v1, :cond_32

    add-int/lit8 v0, p2, 0x1

    aget-byte v0, p1, v0

    const/16 v1, 0x52

    if-ne v0, v1, :cond_32

    add-int/lit8 v0, p2, 0x2

    aget-byte v0, p1, v0

    const/16 v1, 0x41

    if-ne v0, v1, :cond_32

    .line 30
    add-int/lit8 v0, p2, 0x3

    aget-byte v0, p1, v0

    const/16 v1, 0x43

    if-ne v0, v1, :cond_32

    add-int/lit8 v0, p2, 0x4

    aget-byte v0, p1, v0

    const/16 v1, 0x4f

    if-ne v0, v1, :cond_32

    const/4 v0, 0x1

    goto :goto_33

    :cond_32
    const/4 v0, 0x0

    :goto_33
    return v0
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.AttDecoder (com.exampletest.mobilestudiotest.render.Draco$AttDecoder)
.class final Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "AttDecoder"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0007\n\u0002\u0010\u0015\n\u0002\u0008\u0005\n\u0002\u0010\u0014\n\u0002\u0008\u0005\n\u0002\u0010\u0007\n\u0002\u0008\u000c\u0008\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u001a\u0010\u000c\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000e\u0010\u000f\"\u0004\u0008\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015\"\u0004\u0008\u0016\u0010\u0017R\u001a\u0010\u0018\u001a\u00020\u0019X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001a\u0010\u001b\"\u0004\u0008\u001c\u0010\u001dR\u001a\u0010\u001e\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001f\u0010\u000b\"\u0004\u0008 \u0010!R\u001a\u0010\"\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008#\u0010\u000b\"\u0004\u0008$\u0010!\u00a8\u0006%"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;",
        "",
        "att",
        "Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;",
        "kind",
        "",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;I)V",
        "getAtt",
        "()Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;",
        "getKind",
        "()I",
        "portable",
        "",
        "getPortable",
        "()[I",
        "setPortable",
        "([I)V",
        "minValues",
        "",
        "getMinValues",
        "()[F",
        "setMinValues",
        "([F)V",
        "range",
        "",
        "getRange",
        "()F",
        "setRange",
        "(F)V",
        "qBits",
        "getQBits",
        "setQBits",
        "(I)V",
        "octBits",
        "getOctBits",
        "setOctBits",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final att:Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

.field private final kind:I

.field private minValues:[F

.field private octBits:I

.field private portable:[I

.field private qBits:I

.field private range:F


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;I)V
    .registers 5
    .param p1, "att"    # Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .param p2, "kind"    # I

    const-string v0, "att"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 276
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->att:Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->kind:I

    .line 277
    const/4 v0, 0x0

    new-array v1, v0, [I

    iput-object v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->portable:[I

    .line 278
    new-array v0, v0, [F

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->minValues:[F

    .line 276
    return-void
.end method


# virtual methods
.method public final getAtt()Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .registers 2

    .line 276
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->att:Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    return-object v0
.end method

.method public final getKind()I
    .registers 2

    .line 276
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->kind:I

    return v0
.end method

.method public final getMinValues()[F
    .registers 2

    .line 278
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->minValues:[F

    return-object v0
.end method

.method public final getOctBits()I
    .registers 2

    .line 281
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->octBits:I

    return v0
.end method

.method public final getPortable()[I
    .registers 2

    .line 277
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->portable:[I

    return-object v0
.end method

.method public final getQBits()I
    .registers 2

    .line 280
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->qBits:I

    return v0
.end method

.method public final getRange()F
    .registers 2

    .line 279
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->range:F

    return v0
.end method

.method public final setMinValues([F)V
    .registers 3
    .param p1, "<set-?>"    # [F

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 278
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->minValues:[F

    return-void
.end method

.method public final setOctBits(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 281
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->octBits:I

    return-void
.end method

.method public final setPortable([I)V
    .registers 3
    .param p1, "<set-?>"    # [I

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 277
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->portable:[I

    return-void
.end method

.method public final setQBits(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 280
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->qBits:I

    return-void
.end method

.method public final setRange(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 279
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$AttDecoder;->range:F

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.Attribute (com.exampletest.mobilestudiotest.render.Draco$Attribute)
.class public final Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Attribute"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u000b\n\u0002\u0010\u0014\n\u0002\u0008\u0005\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\t\u00a2\u0006\u0004\u0008\n\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011R\u0011\u0010\u0008\u001a\u00020\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u0015X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0016\u0010\u0017\"\u0004\u0008\u0018\u0010\u0019\u00a8\u0006\u001a"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;",
        "",
        "type",
        "",
        "dataType",
        "components",
        "normalized",
        "",
        "uniqueId",
        "",
        "<init>",
        "(IIIZJ)V",
        "getType",
        "()I",
        "getDataType",
        "getComponents",
        "getNormalized",
        "()Z",
        "getUniqueId",
        "()J",
        "values",
        "",
        "getValues",
        "()[F",
        "setValues",
        "([F)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final components:I

.field private final dataType:I

.field private final normalized:Z

.field private final type:I

.field private final uniqueId:J

.field private values:[F


# direct methods
.method public constructor <init>(IIIZJ)V
    .registers 8
    .param p1, "type"    # I
    .param p2, "dataType"    # I
    .param p3, "components"    # I
    .param p4, "normalized"    # Z
    .param p5, "uniqueId"    # J

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->type:I

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->dataType:I

    iput p3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->components:I

    iput-boolean p4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->normalized:Z

    iput-wide p5, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->uniqueId:J

    .line 21
    const/4 v0, 0x0

    new-array v0, v0, [F

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->values:[F

    .line 19
    return-void
.end method


# virtual methods
.method public final getComponents()I
    .registers 2

    .line 19
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->components:I

    return v0
.end method

.method public final getDataType()I
    .registers 2

    .line 19
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->dataType:I

    return v0
.end method

.method public final getNormalized()Z
    .registers 2

    .line 19
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->normalized:Z

    return v0
.end method

.method public final getType()I
    .registers 2

    .line 19
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->type:I

    return v0
.end method

.method public final getUniqueId()J
    .registers 3

    .line 19
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->uniqueId:J

    return-wide v0
.end method

.method public final getValues()[F
    .registers 2

    .line 21
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->values:[F

    return-object v0
.end method

.method public final setValues([F)V
    .registers 3
    .param p1, "<set-?>"    # [F

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->values:[F

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.BitReader (com.exampletest.mobilestudiotest.render.Draco$BitReader)
.class final Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "BitReader"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\t\n\u0002\u0010\t\n\u0002\u0008\u0008\u0008\u0002\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u000e\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0005J\u0006\u0010\u0016\u001a\u00020\u0005R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000cR\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011\"\u0004\u0008\u0012\u0010\u0013\u00a8\u0006\u0017"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;",
        "",
        "b",
        "",
        "start",
        "",
        "end",
        "<init>",
        "([BII)V",
        "getB",
        "()[B",
        "getStart",
        "()I",
        "getEnd",
        "bit",
        "",
        "getBit",
        "()J",
        "setBit",
        "(J)V",
        "get",
        "n",
        "bytesUsed",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final b:[B

.field private bit:J

.field private final end:I

.field private final start:I


# direct methods
.method public constructor <init>([BII)V
    .registers 5
    .param p1, "b"    # [B
    .param p2, "start"    # I
    .param p3, "end"    # I

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->b:[B

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->start:I

    iput p3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->end:I

    return-void
.end method


# virtual methods
.method public final bytesUsed()I
    .registers 5

    .line 81
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->bit:J

    const-wide/16 v2, 0x7

    add-long/2addr v0, v2

    const-wide/16 v2, 0x8

    div-long/2addr v0, v2

    long-to-int v0, v0

    return v0
.end method

.method public final get(I)I
    .registers 10
    .param p1, "n"    # I

    .line 72
    const/4 v0, 0x0

    .line 73
    .local v0, "v":I
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_2
    if-ge v1, p1, :cond_2c

    .line 74
    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->start:I

    iget-wide v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->bit:J

    const/4 v5, 0x3

    ushr-long/2addr v3, v5

    long-to-int v3, v3

    add-int/2addr v2, v3

    .line 75
    .local v2, "byte":I
    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->end:I

    if-ge v2, v3, :cond_1e

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->b:[B

    aget-byte v3, v3, v2

    iget-wide v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->bit:J

    const-wide/16 v6, 0x7

    and-long/2addr v4, v6

    long-to-int v4, v4

    ushr-int/2addr v3, v4

    and-int/lit8 v3, v3, 0x1

    goto :goto_1f

    :cond_1e
    const/4 v3, 0x0

    .line 76
    .local v3, "x":I
    :goto_1f
    iget-wide v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->bit:J

    const-wide/16 v6, 0x1

    add-long/2addr v4, v6

    iput-wide v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->bit:J

    .line 77
    shl-int v4, v3, v1

    or-int/2addr v0, v4

    .line 73
    .end local v2    # "byte":I
    .end local v3    # "x":I
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 79
    .end local v1    # "i":I
    :cond_2c
    return v0
.end method

.method public final getB()[B
    .registers 2

    .line 69
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->b:[B

    return-object v0
.end method

.method public final getBit()J
    .registers 3

    .line 70
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->bit:J

    return-wide v0
.end method

.method public final getEnd()I
    .registers 2

    .line 69
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->end:I

    return v0
.end method

.method public final getStart()I
    .registers 2

    .line 69
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->start:I

    return v0
.end method

.method public final setBit(J)V
    .registers 3
    .param p1, "<set-?>"    # J

    .line 70
    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$BitReader;->bit:J

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.DracoException (com.exampletest.mobilestudiotest.render.Draco$DracoException)
.class public final Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;
.super Ljava/lang/Exception;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "DracoException"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0003\u0018\u00002\u00060\u0001j\u0002`\u0002B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0005\u0010\u0006\u00a8\u0006\u0007"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;",
        "Ljava/lang/Exception;",
        "Lkotlin/Exception;",
        "msg",
        "",
        "<init>",
        "(Ljava/lang/String;)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3
    .param p1, "msg"    # Ljava/lang/String;

    const-string v0, "msg"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.Mesh (com.exampletest.mobilestudiotest.render.Draco$Mesh)
.class public final Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Mesh"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDraco.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Draco.kt\ncom/exampletest/mobilestudiotest/render/Draco$Mesh\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,489:1\n295#2,2:490\n*S KotlinDebug\n*F\n+ 1 Draco.kt\ncom/exampletest/mobilestudiotest/render/Draco$Mesh\n*L\n25#1:490,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u000b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0007\u00a2\u0006\u0004\u0008\t\u0010\nJ\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u00082\u0006\u0010\u0012\u001a\u00020\u0003R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u0017\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010\u00a8\u0006\u0013"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;",
        "",
        "numPoints",
        "",
        "faces",
        "",
        "attributes",
        "",
        "Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;",
        "<init>",
        "(I[ILjava/util/List;)V",
        "getNumPoints",
        "()I",
        "getFaces",
        "()[I",
        "getAttributes",
        "()Ljava/util/List;",
        "attribute",
        "type",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final attributes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;",
            ">;"
        }
    .end annotation
.end field

.field private final faces:[I

.field private final numPoints:I


# direct methods
.method public constructor <init>(I[ILjava/util/List;)V
    .registers 5
    .param p1, "numPoints"    # I
    .param p2, "faces"    # [I
    .param p3, "attributes"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[I",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;",
            ">;)V"
        }
    .end annotation

    const-string v0, "faces"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "attributes"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;->numPoints:I

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;->faces:[I

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;->attributes:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final attribute(I)Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .registers 9
    .param p1, "type"    # I

    .line 25
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;->attributes:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 490
    .local v1, "$i$f$firstOrNull\\1\\25":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_23

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    .local v4, "it\\2":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    const/4 v5, 0x0

    .line 25
    .local v5, "$i$a$-firstOrNull-Draco$Mesh$attribute$1\\2\\490\\0":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;->getType()I

    move-result v6

    if-ne v6, p1, :cond_1f

    const/4 v6, 0x1

    goto :goto_20

    :cond_1f
    const/4 v6, 0x0

    .line 490
    .end local v4    # "it\\2":Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;
    .end local v5    # "$i$a$-firstOrNull-Draco$Mesh$attribute$1\\2\\490\\0":I
    :goto_20
    if-eqz v6, :cond_9

    goto :goto_24

    .line 491
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_23
    const/4 v3, 0x0

    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\25":I
    :goto_24
    check-cast v3, Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;

    .line 25
    return-object v3
.end method

.method public final getAttributes()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/render/Draco$Attribute;",
            ">;"
        }
    .end annotation

    .line 24
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;->attributes:Ljava/util/List;

    return-object v0
.end method

.method public final getFaces()[I
    .registers 2

    .line 24
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;->faces:[I

    return-object v0
.end method

.method public final getNumPoints()I
    .registers 2

    .line 24
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Mesh;->numPoints:I

    return v0
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.Octa (com.exampletest.mobilestudiotest.render.Draco$Octa)
.class final Lcom/exampletest/mobilestudiotest/render/Draco$Octa;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Octa"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\n\n\u0002\u0010\u0007\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0015\n\u0002\u0008\u0006\n\u0002\u0010\u0014\n\u0002\u0008\u0002\u0008\u0002\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0016\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u0003J\u000e\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0018J\u000e\u0010\u0019\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u0003J&\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u001c\u001a\u00020\u00032\u0006\u0010\u001d\u001a\u00020\u00032\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0003R\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008R\u0011\u0010\t\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u0008R\u0011\u0010\u000b\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\u0008R\u0011\u0010\r\u001a\u00020\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010\u00a8\u0006!"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$Octa;",
        "",
        "bits",
        "",
        "<init>",
        "(I)V",
        "maxQ",
        "getMaxQ",
        "()I",
        "maxValue",
        "getMaxValue",
        "center",
        "getCenter",
        "scale",
        "",
        "getScale",
        "()F",
        "isInDiamond",
        "",
        "s",
        "t",
        "invertDiamond",
        "",
        "p",
        "",
        "modMax",
        "x",
        "toUnit",
        "si",
        "ti",
        "out",
        "",
        "o",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final center:I

.field private final maxQ:I

.field private final maxValue:I

.field private final scale:F


# direct methods
.method public constructor <init>(I)V
    .registers 5
    .param p1, "bits"    # I

    .line 207
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 213
    nop

    .line 214
    const/4 v0, 0x2

    if-lt p1, v0, :cond_25

    const/16 v1, 0x1e

    if-gt p1, v1, :cond_25

    .line 215
    const/4 v1, 0x1

    shl-int v2, v1, p1

    sub-int/2addr v2, v1

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxQ:I

    .line 216
    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxQ:I

    sub-int/2addr v2, v1

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxValue:I

    .line 217
    iget v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxValue:I

    div-int/2addr v1, v0

    iput v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->center:I

    .line 218
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxValue:I

    int-to-float v0, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v1, v0

    iput v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->scale:F

    .line 219
    nop

    .line 207
    return-void

    .line 214
    :cond_25
    new-instance v0, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v1, "bad normal quantization"

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public final getCenter()I
    .registers 2

    .line 210
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->center:I

    return v0
.end method

.method public final getMaxQ()I
    .registers 2

    .line 208
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxQ:I

    return v0
.end method

.method public final getMaxValue()I
    .registers 2

    .line 209
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxValue:I

    return v0
.end method

.method public final getScale()F
    .registers 2

    .line 211
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->scale:F

    return v0
.end method

.method public final invertDiamond([I)V
    .registers 13
    .param p1, "p"    # [I

    const-string v0, "p"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 225
    const/4 v0, 0x0

    aget v1, p1, v0

    .local v1, "s":I
    const/4 v2, 0x1

    aget v3, p1, v2

    .line 226
    .local v3, "t":I
    const/4 v4, 0x0

    .local v4, "signS":I
    const/4 v5, 0x0

    .line 227
    .local v5, "signT":I
    if-ltz v1, :cond_14

    if-ltz v3, :cond_14

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_26

    .line 228
    :cond_14
    if-gtz v1, :cond_1b

    if-gtz v3, :cond_1b

    const/4 v4, -0x1

    const/4 v5, -0x1

    goto :goto_26

    .line 229
    :cond_1b
    const/4 v6, -0x1

    if-lez v1, :cond_20

    move v7, v2

    goto :goto_21

    :cond_20
    move v7, v6

    :goto_21
    move v4, v7

    if-lez v3, :cond_25

    move v6, v2

    :cond_25
    move v5, v6

    .line 230
    :goto_26
    iget v6, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->center:I

    mul-int/2addr v6, v4

    .local v6, "cs":I
    iget v7, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->center:I

    mul-int/2addr v7, v5

    .line 231
    .local v7, "ct":I
    add-int v8, v1, v1

    sub-int/2addr v8, v6

    .line 232
    .local v8, "us":I
    add-int v9, v3, v3

    sub-int/2addr v9, v7

    .line 233
    .local v9, "ut":I
    mul-int v10, v4, v5

    if-ltz v10, :cond_3a

    move v10, v8

    .local v10, "tmp":I
    neg-int v8, v9

    neg-int v9, v10

    .end local v10    # "tmp":I
    goto :goto_3d

    :cond_3a
    move v10, v8

    .restart local v10    # "tmp":I
    move v8, v9

    move v9, v10

    .line 234
    .end local v10    # "tmp":I
    :goto_3d
    add-int/2addr v8, v6

    add-int/2addr v9, v7

    .line 235
    div-int/lit8 v1, v8, 0x2

    div-int/lit8 v3, v9, 0x2

    .line 236
    aput v1, p1, v0

    aput v3, p1, v2

    .line 237
    return-void
.end method

.method public final isInDiamond(II)Z
    .registers 7
    .param p1, "s"    # I
    .param p2, "t"    # I

    .line 221
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v0

    int-to-long v0, v0

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result v2

    int-to-long v2, v2

    add-long/2addr v0, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->center:I

    int-to-long v2, v2

    cmp-long v0, v0, v2

    if-gtz v0, :cond_14

    const/4 v0, 0x1

    goto :goto_15

    :cond_14
    const/4 v0, 0x0

    :goto_15
    return v0
.end method

.method public final modMax(I)I
    .registers 3
    .param p1, "x"    # I

    .line 239
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->center:I

    if-le p1, v0, :cond_9

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxQ:I

    sub-int v0, p1, v0

    goto :goto_13

    :cond_9
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->center:I

    neg-int v0, v0

    if-ge p1, v0, :cond_12

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->maxQ:I

    add-int/2addr v0, p1

    goto :goto_13

    :cond_12
    move v0, p1

    :goto_13
    return v0
.end method

.method public final toUnit(II[FI)V
    .registers 14
    .param p1, "si"    # I
    .param p2, "ti"    # I
    .param p3, "out"    # [F
    .param p4, "o"    # I

    const-string v0, "out"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 242
    int-to-float v0, p1

    iget v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->scale:F

    mul-float/2addr v0, v1

    const/high16 v1, 0x3f800000    # 1.0f

    sub-float/2addr v0, v1

    .line 243
    .local v0, "y":F
    int-to-float v2, p2

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Octa;->scale:F

    mul-float/2addr v2, v3

    sub-float/2addr v2, v1

    .line 244
    .local v2, "z":F
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v3

    sub-float v3, v1, v3

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v4

    sub-float/2addr v3, v4

    .line 245
    .local v3, "x":F
    neg-float v4, v3

    const/4 v5, 0x0

    cmpg-float v4, v4, v5

    if-gez v4, :cond_24

    move v4, v5

    goto :goto_25

    :cond_24
    neg-float v4, v3

    .line 246
    .local v4, "xo":F
    :goto_25
    cmpg-float v6, v0, v5

    if-gez v6, :cond_2b

    move v6, v4

    goto :goto_2c

    :cond_2b
    neg-float v6, v4

    :goto_2c
    add-float/2addr v0, v6

    .line 247
    cmpg-float v6, v2, v5

    if-gez v6, :cond_33

    move v6, v4

    goto :goto_34

    :cond_33
    neg-float v6, v4

    :goto_34
    add-float/2addr v2, v6

    .line 248
    mul-float v6, v3, v3

    mul-float v7, v0, v0

    add-float/2addr v6, v7

    mul-float v7, v2, v2

    add-float/2addr v6, v7

    .line 249
    .local v6, "n2":F
    const v7, 0x358637bd    # 1.0E-6f

    cmpg-float v7, v6, v7

    if-gez v7, :cond_4f

    aput v5, p3, p4

    add-int/lit8 v1, p4, 0x1

    aput v5, p3, v1

    add-int/lit8 v1, p4, 0x2

    aput v5, p3, v1

    goto :goto_66

    .line 250
    :cond_4f
    float-to-double v7, v6

    invoke-static {v7, v8}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v7

    double-to-float v5, v7

    div-float/2addr v1, v5

    .local v1, "d":F
    mul-float v5, v3, v1

    aput v5, p3, p4

    add-int/lit8 v5, p4, 0x1

    mul-float v7, v0, v1

    aput v7, p3, v5

    add-int/lit8 v5, p4, 0x2

    mul-float v7, v2, v1

    aput v7, p3, v5

    .line 251
    .end local v1    # "d":F
    :goto_66
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.RAns (com.exampletest.mobilestudiotest.render.Draco$RAns)
.class final Lcom/exampletest/mobilestudiotest/render/Draco$RAns;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "RAns"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0015\n\u0002\u0008\u0004\n\u0002\u0010\t\n\u0002\u0008\u0004\n\u0002\u0010\u0012\n\u0002\u0008\u0004\n\u0002\u0010\u0002\n\u0002\u0008\u0005\u0008\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u001e\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u000f2\u0006\u0010\u0016\u001a\u00020\u00032\u0006\u0010\u0017\u001a\u00020\u0003J\u0006\u0010\u0018\u001a\u00020\u0003R\u000e\u0010\u0008\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0019"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$RAns;",
        "",
        "precisionBits",
        "",
        "probs",
        "",
        "<init>",
        "(I[I)V",
        "precision",
        "lBase",
        "",
        "lut",
        "prob",
        "cum",
        "buf",
        "",
        "start",
        "offset",
        "state",
        "init",
        "",
        "b",
        "s",
        "len",
        "read",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private buf:[B

.field private final cum:[I

.field private final lBase:J

.field private final lut:[I

.field private offset:I

.field private final precision:I

.field private final prob:[I

.field private start:I

.field private state:J


# direct methods
.method public constructor <init>(I[I)V
    .registers 13
    .param p1, "precisionBits"    # I
    .param p2, "probs"    # [I

    const-string v0, "probs"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 87
    const/4 v0, 0x1

    shl-int/2addr v0, p1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->precision:I

    .line 88
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->precision:I

    int-to-long v0, v0

    const-wide/16 v2, 0x4

    mul-long/2addr v0, v2

    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->lBase:J

    .line 89
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->precision:I

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->lut:[I

    .line 90
    array-length v0, p2

    invoke-static {p2, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object v0

    const-string v1, "copyOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->prob:[I

    .line 91
    array-length v0, p2

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->cum:[I

    .line 92
    const/4 v0, 0x0

    new-array v0, v0, [B

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->buf:[B

    .line 97
    nop

    .line 98
    const-wide/16 v0, 0x0

    .line 99
    .local v0, "c":J
    const/4 v2, 0x0

    .line 100
    .local v2, "act":I
    const/4 v3, 0x0

    .local v3, "i":I
    array-length v4, p2

    :goto_36
    const-string v5, "bad probability table"

    if-ge v3, v4, :cond_65

    .line 101
    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->cum:[I

    long-to-int v7, v0

    aput v7, v6, v3

    .line 102
    aget v6, p2, v3

    int-to-long v6, v6

    const-wide v8, 0xffffffffL

    and-long/2addr v6, v8

    add-long/2addr v0, v6

    .line 103
    iget v6, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->precision:I

    int-to-long v6, v6

    cmp-long v6, v0, v6

    if-gtz v6, :cond_5f

    .line 104
    move v5, v2

    .local v5, "j":I
    long-to-int v6, v0

    :goto_52
    if-ge v5, v6, :cond_5b

    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->lut:[I

    aput v3, v7, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_52

    .line 105
    .end local v5    # "j":I
    :cond_5b
    long-to-int v2, v0

    .line 100
    add-int/lit8 v3, v3, 0x1

    goto :goto_36

    .line 103
    :cond_5f
    new-instance v4, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 107
    .end local v3    # "i":I
    :cond_65
    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->precision:I

    int-to-long v3, v3

    cmp-long v3, v0, v3

    if-nez v3, :cond_6e

    .line 108
    .end local v0    # "c":J
    .end local v2    # "act":I
    nop

    .line 86
    return-void

    .line 107
    .restart local v0    # "c":J
    .restart local v2    # "act":I
    :cond_6e
    new-instance v3, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v3, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method private static final init$le([BIII)J
    .registers 11
    .param p0, "$b"    # [B
    .param p1, "$s"    # I
    .param p2, "at"    # I
    .param p3, "n"    # I

    .line 114
    const-wide/16 v0, 0x0

    .local v0, "v":J
    const/4 v2, 0x0

    .local v2, "k":I
    :goto_3
    if-ge v2, p3, :cond_15

    add-int v3, p1, p2

    add-int/2addr v3, v2

    aget-byte v3, p0, v3

    int-to-long v3, v3

    const-wide/16 v5, 0xff

    and-long/2addr v3, v5

    mul-int/lit8 v5, v2, 0x8

    shl-long/2addr v3, v5

    or-long/2addr v0, v3

    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    .end local v2    # "k":I
    :cond_15
    return-wide v0
.end method


# virtual methods
.method public final init([BII)V
    .registers 11
    .param p1, "b"    # [B
    .param p2, "s"    # I
    .param p3, "len"    # I

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    const/4 v0, 0x1

    if-lt p3, v0, :cond_8b

    .line 112
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->buf:[B

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->start:I

    .line 113
    add-int v1, p2, p3

    sub-int/2addr v1, v0

    aget-byte v0, p1, v1

    and-int/lit16 v0, v0, 0xff

    .line 115
    .local v0, "last":I
    ushr-int/lit8 v1, v0, 0x6

    const-string v2, "bad rANS data"

    packed-switch v1, :pswitch_data_94

    .line 119
    const/4 v1, 0x4

    if-lt p3, v1, :cond_85

    add-int/lit8 v2, p3, -0x4

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->offset:I

    add-int/lit8 v2, p3, -0x4

    invoke-static {p1, p2, v2, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->init$le([BIII)J

    move-result-wide v1

    const-wide/32 v3, 0x3fffffff

    and-long/2addr v1, v3

    iput-wide v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    goto :goto_6a

    .line 118
    :pswitch_2e
    const/4 v1, 0x3

    if-lt p3, v1, :cond_42

    add-int/lit8 v2, p3, -0x3

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->offset:I

    add-int/lit8 v2, p3, -0x3

    invoke-static {p1, p2, v2, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->init$le([BIII)J

    move-result-wide v1

    const-wide/32 v3, 0x3fffff

    and-long/2addr v1, v3

    iput-wide v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    goto :goto_6a

    :cond_42
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 117
    :pswitch_48
    const/4 v1, 0x2

    if-lt p3, v1, :cond_5b

    add-int/lit8 v2, p3, -0x2

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->offset:I

    add-int/lit8 v2, p3, -0x2

    invoke-static {p1, p2, v2, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->init$le([BIII)J

    move-result-wide v1

    const-wide/16 v3, 0x3fff

    and-long/2addr v1, v3

    iput-wide v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    goto :goto_6a

    :cond_5b
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 116
    :pswitch_61
    add-int/lit8 v1, p3, -0x1

    iput v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->offset:I

    and-int/lit8 v1, v0, 0x3f

    int-to-long v1, v1

    iput-wide v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    .line 121
    :goto_6a
    iget-wide v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    iget-wide v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->lBase:J

    add-long/2addr v1, v3

    iput-wide v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    .line 122
    iget-wide v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    iget-wide v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->lBase:J

    const-wide/16 v5, 0x100

    mul-long/2addr v3, v5

    cmp-long v1, v1, v3

    if-gez v1, :cond_7d

    .line 123
    return-void

    .line 122
    :cond_7d
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v2, "bad rANS state"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 119
    :cond_85
    new-instance v1, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 111
    .end local v0    # "last":I
    :cond_8b
    new-instance v0, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v1, "empty rANS data"

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v0

    nop

    :pswitch_data_94
    .packed-switch 0x0
        :pswitch_61
        :pswitch_48
        :pswitch_2e
    .end packed-switch
.end method

.method public final read()I
    .registers 9

    .line 126
    nop

    :goto_1
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    iget-wide v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->lBase:J

    cmp-long v0, v0, v2

    if-gez v0, :cond_29

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->offset:I

    if-lez v0, :cond_29

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    const-wide/16 v2, 0x100

    mul-long/2addr v0, v2

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->buf:[B

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->start:I

    iget v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->offset:I

    add-int/lit8 v4, v4, -0x1

    iput v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->offset:I

    iget v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->offset:I

    add-int/2addr v3, v4

    aget-byte v2, v2, v3

    int-to-long v2, v2

    const-wide/16 v4, 0xff

    and-long/2addr v2, v4

    add-long/2addr v0, v2

    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    goto :goto_1

    .line 127
    :cond_29
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->precision:I

    int-to-long v2, v2

    div-long/2addr v0, v2

    .line 128
    .local v0, "quo":J
    iget-wide v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    iget v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->precision:I

    int-to-long v4, v4

    rem-long/2addr v2, v4

    long-to-int v2, v2

    .line 129
    .local v2, "rem":I
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->lut:[I

    aget v3, v3, v2

    .line 130
    .local v3, "sym":I
    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->prob:[I

    aget v4, v4, v3

    int-to-long v4, v4

    const-wide v6, 0xffffffffL

    and-long/2addr v4, v6

    mul-long/2addr v4, v0

    int-to-long v6, v2

    add-long/2addr v4, v6

    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->cum:[I

    aget v6, v6, v3

    int-to-long v6, v6

    sub-long/2addr v4, v6

    iput-wide v4, p0, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->state:J

    .line 131
    return v3
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.Reader (com.exampletest.mobilestudiotest.render.Draco$Reader)
.class final Lcom/exampletest/mobilestudiotest/render/Draco$Reader;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Reader"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\r\n\u0002\u0010\u0002\n\u0002\u0008\u0006\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0003\u0008\u0002\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u000e\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0005J\u0006\u0010\u0015\u001a\u00020\u0005J\u0006\u0010\u0016\u001a\u00020\u0005J\u0006\u0010\u0017\u001a\u00020\u0005J\u0006\u0010\u0018\u001a\u00020\u0005J\u0006\u0010\u0019\u001a\u00020\u001aJ\u0006\u0010\u001b\u001a\u00020\u001cJ\u0006\u0010\u001d\u001a\u00020\u0005J\u000e\u0010\u001e\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0005R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000b\u0010\u000c\"\u0004\u0008\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u000cR\u0011\u0010\u0010\u001a\u00020\u00058F\u00a2\u0006\u0006\u001a\u0004\u0008\u0011\u0010\u000c\u00a8\u0006\u001f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$Reader;",
        "",
        "b",
        "",
        "pos",
        "",
        "end",
        "<init>",
        "([BII)V",
        "getB",
        "()[B",
        "getPos",
        "()I",
        "setPos",
        "(I)V",
        "getEnd",
        "remaining",
        "getRemaining",
        "need",
        "",
        "n",
        "u8",
        "i8",
        "u16",
        "i32",
        "f32",
        "",
        "varint",
        "",
        "varintInt",
        "skip",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final b:[B

.field private final end:I

.field private pos:I


# direct methods
.method public constructor <init>([BII)V
    .registers 5
    .param p1, "b"    # [B
    .param p2, "pos"    # I
    .param p3, "end"    # I

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    iput p3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->end:I

    return-void
.end method


# virtual methods
.method public final f32()F
    .registers 2

    .line 47
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->i32()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    return v0
.end method

.method public final getB()[B
    .registers 2

    .line 34
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    return-object v0
.end method

.method public final getEnd()I
    .registers 2

    .line 34
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->end:I

    return v0
.end method

.method public final getPos()I
    .registers 2

    .line 34
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    return v0
.end method

.method public final getRemaining()I
    .registers 3

    .line 35
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->end:I

    iget v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    sub-int/2addr v0, v1

    return v0
.end method

.method public final i32()I
    .registers 5

    .line 41
    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->need(I)V

    .line 42
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    aget-byte v1, v1, v2

    and-int/lit16 v1, v1, 0xff

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/lit8 v3, v3, 0x1

    aget-byte v2, v2, v3

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x8

    or-int/2addr v1, v2

    .line 43
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/lit8 v3, v3, 0x2

    aget-byte v2, v2, v3

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x10

    .line 42
    or-int/2addr v1, v2

    .line 43
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/lit8 v3, v3, 0x3

    aget-byte v2, v2, v3

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x18

    .line 42
    or-int/2addr v1, v2

    .line 44
    .local v1, "v":I
    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/2addr v2, v0

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    .line 45
    return v1
.end method

.method public final i8()I
    .registers 4

    .line 38
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->need(I)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iget v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    aget-byte v0, v0, v1

    return v0
.end method

.method public final need(I)V
    .registers 4
    .param p1, "n"    # I

    .line 36
    if-ltz p1, :cond_a

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/2addr v0, p1

    iget v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->end:I

    if-gt v0, v1, :cond_a

    return-void

    :cond_a
    new-instance v0, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v1, "unexpected end of data"

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final setPos(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 34
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    return-void
.end method

.method public final skip(I)V
    .registers 3
    .param p1, "n"    # I

    .line 65
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->need(I)V

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/2addr v0, p1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    return-void
.end method

.method public final u16()I
    .registers 5

    .line 39
    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->need(I)V

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    aget-byte v1, v1, v2

    and-int/lit16 v1, v1, 0xff

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/lit8 v3, v3, 0x1

    aget-byte v2, v2, v3

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x8

    or-int/2addr v1, v2

    .local v1, "v":I
    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/2addr v2, v0

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    return v1
.end method

.method public final u8()I
    .registers 4

    .line 37
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->need(I)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->b:[B

    iget v1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->pos:I

    aget-byte v0, v0, v1

    and-int/lit16 v0, v0, 0xff

    return v0
.end method

.method public final varint()J
    .registers 7

    .line 50
    const-wide/16 v0, 0x0

    .line 51
    .local v0, "result":J
    const/4 v2, 0x0

    .line 52
    .local v2, "shift":I
    :cond_3
    nop

    .line 53
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->u8()I

    move-result v3

    .line 54
    .local v3, "v":I
    and-int/lit8 v4, v3, 0x7f

    int-to-long v4, v4

    shl-long/2addr v4, v2

    or-long/2addr v0, v4

    .line 55
    and-int/lit16 v4, v3, 0x80

    if-nez v4, :cond_12

    return-wide v0

    .line 56
    :cond_12
    add-int/lit8 v2, v2, 0x7

    .line 57
    const/16 v4, 0x3f

    if-le v2, v4, :cond_3

    new-instance v4, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v5, "bad varint"

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v4
.end method

.method public final varintInt()I
    .registers 5

    .line 61
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varint()J

    move-result-wide v0

    .line 62
    .local v0, "v":J
    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-ltz v2, :cond_13

    const-wide/32 v2, 0x7fffffff

    cmp-long v2, v0, v2

    if-gtz v2, :cond_13

    .line 63
    long-to-int v2, v0

    return v2

    .line 62
    :cond_13
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v3, "value out of range"

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

###### Class com.exampletest.mobilestudiotest.render.Draco.SymbolDecoder (com.exampletest.mobilestudiotest.render.Draco$SymbolDecoder)
.class final Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;
.super Ljava/lang/Object;
.source "Draco.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/Draco;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "SymbolDecoder"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0002\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u000e\u0010\u000c\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fJ\u0006\u0010\u0010\u001a\u00020\u0003R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000b\u00a8\u0006\u0011"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;",
        "",
        "numSymbols",
        "",
        "ans",
        "Lcom/exampletest/mobilestudiotest/render/Draco$RAns;",
        "<init>",
        "(ILcom/exampletest/mobilestudiotest/render/Draco$RAns;)V",
        "getNumSymbols",
        "()I",
        "getAns",
        "()Lcom/exampletest/mobilestudiotest/render/Draco$RAns;",
        "start",
        "",
        "r",
        "Lcom/exampletest/mobilestudiotest/render/Draco$Reader;",
        "read",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final ans:Lcom/exampletest/mobilestudiotest/render/Draco$RAns;

.field private final numSymbols:I


# direct methods
.method public constructor <init>(ILcom/exampletest/mobilestudiotest/render/Draco$RAns;)V
    .registers 3
    .param p1, "numSymbols"    # I
    .param p2, "ans"    # Lcom/exampletest/mobilestudiotest/render/Draco$RAns;

    .line 135
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->numSymbols:I

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->ans:Lcom/exampletest/mobilestudiotest/render/Draco$RAns;

    return-void
.end method


# virtual methods
.method public final getAns()Lcom/exampletest/mobilestudiotest/render/Draco$RAns;
    .registers 2

    .line 135
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->ans:Lcom/exampletest/mobilestudiotest/render/Draco$RAns;

    return-object v0
.end method

.method public final getNumSymbols()I
    .registers 2

    .line 135
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->numSymbols:I

    return v0
.end method

.method public final read()I
    .registers 2

    .line 143
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->ans:Lcom/exampletest/mobilestudiotest/render/Draco$RAns;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->read()I

    move-result v0

    return v0
.end method

.method public final start(Lcom/exampletest/mobilestudiotest/render/Draco$Reader;)V
    .registers 8
    .param p1, "r"    # Lcom/exampletest/mobilestudiotest/render/Draco$Reader;

    const-string v0, "r"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->varint()J

    move-result-wide v0

    .line 138
    .local v0, "bytes":J
    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-ltz v2, :cond_39

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getRemaining()I

    move-result v2

    int-to-long v2, v2

    cmp-long v2, v0, v2

    if-gtz v2, :cond_39

    .line 139
    long-to-int v2, v0

    .line 140
    .local v2, "n":I
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/render/Draco$SymbolDecoder;->ans:Lcom/exampletest/mobilestudiotest/render/Draco$RAns;

    if-eqz v3, :cond_31

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getB()[B

    move-result-object v4

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getPos()I

    move-result v5

    invoke-virtual {v3, v4, v5, v2}, Lcom/exampletest/mobilestudiotest/render/Draco$RAns;->init([BII)V

    .line 141
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->getPos()I

    move-result v3

    add-int/2addr v3, v2

    invoke-virtual {p1, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$Reader;->setPos(I)V

    .line 142
    return-void

    .line 140
    :cond_31
    new-instance v3, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v4, "no symbols"

    invoke-direct {v3, v4}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v3

    .line 138
    .end local v2    # "n":I
    :cond_39
    new-instance v2, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;

    const-string v3, "bad rANS size"

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/render/Draco$DracoException;-><init>(Ljava/lang/String;)V

    throw v2
.end method
