###### Class com.exampletest.mobilestudiotest.render.UnionMeshes (com.exampletest.mobilestudiotest.render.UnionMeshes)
.class public final Lcom/exampletest/mobilestudiotest/render/UnionMeshes;
.super Ljava/lang/Object;
.source "UnionMeshes.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nUnionMeshes.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UnionMeshes.kt\ncom/exampletest/mobilestudiotest/render/UnionMeshes\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 5 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,131:1\n1#2:132\n2746#3,3:133\n382#4,7:136\n126#5:143\n153#5,3:144\n*S KotlinDebug\n*F\n+ 1 UnionMeshes.kt\ncom/exampletest/mobilestudiotest/render/UnionMeshes\n*L\n45#1:133,3\n113#1:136,7\n126#1:143\n126#1:144,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000h\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0010$\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0010\u0012\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0001*B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0014\u0010\u0018\u001a\u0004\u0018\u00010\u00192\u0008\u0010\u001a\u001a\u0004\u0018\u00010\u0001H\u0002J\u000e\u0010\u001b\u001a\u00020\u000b2\u0006\u0010\u001c\u001a\u00020\u001dJ\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u001c\u001a\u00020\u001dJ\u0010\u0010\u001f\u001a\u00020\u00192\u0006\u0010 \u001a\u00020\u0019H\u0002J&\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u00062\u0006\u0010$\u001a\u00020\u00062\u000c\u0010%\u001a\u0008\u0012\u0004\u0012\u00020\u00190&H\u0002J\u0018\u0010\'\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u00062\u0006\u0010(\u001a\u00020)H\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000RN\u0010\u0008\u001aB\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b \n* \u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b\u0018\u00010\t0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000RN\u0010\u000c\u001aB\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b \n* \u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u000b0\u000b\u0018\u00010\t0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\r\u001a\n \n*\u0004\u0018\u00010\u000e0\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000RN\u0010\u000f\u001aB\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u00010\u0001\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u00060\u0006 \n* \u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u00010\u0001\u0012\u000c\u0012\n \n*\u0004\u0018\u00010\u00060\u0006\u0018\u00010\u00110\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0013@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0015\u0010\u0016R\u000e\u0010\u0017\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006+"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/UnionMeshes;",
        "",
        "<init>",
        "()V",
        "ready",
        "Ljava/util/concurrent/ConcurrentHashMap;",
        "",
        "Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;",
        "bad",
        "Ljava/util/concurrent/ConcurrentHashMap$KeySetView;",
        "kotlin.jvm.PlatformType",
        "",
        "pending",
        "pool",
        "Ljava/util/concurrent/ExecutorService;",
        "inlineKeys",
        "",
        "",
        "value",
        "",
        "epoch",
        "getEpoch",
        "()I",
        "listening",
        "bytesOf",
        "",
        "v",
        "isStored",
        "p",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "get",
        "meshDataFromAsset",
        "bytes",
        "build",
        "",
        "key",
        "name",
        "source",
        "Lkotlin/Function0;",
        "toData",
        "m",
        "Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;",
        "Data",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

.field private static final bad:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap$KeySetView<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile epoch:I

.field private static final inlineKeys:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile listening:Z

.field private static final pending:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap$KeySetView<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private static final pool:Ljava/util/concurrent/ExecutorService;

.field private static final ready:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/String;",
            "Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    .line 28
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->ready:Ljava/util/concurrent/ConcurrentHashMap;

    .line 29
    invoke-static {}, Ljava/util/concurrent/ConcurrentHashMap;->newKeySet()Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bad:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 30
    invoke-static {}, Ljava/util/concurrent/ConcurrentHashMap;->newKeySet()Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pending:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    .line 31
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pool:Ljava/util/concurrent/ExecutorService;

    .line 32
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    check-cast v0, Ljava/util/Map;

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->inlineKeys:Ljava/util/Map;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final build(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .registers 9
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "source"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "[B>;)V"
        }
    .end annotation

    .line 88
    nop

    .line 89
    :try_start_1
    sget-object v0, Lcom/exampletest/mobilestudiotest/format/CsgMesh;->INSTANCE:Lcom/exampletest/mobilestudiotest/format/CsgMesh;

    invoke-interface {p3}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/format/CsgMesh;->decode([B)Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;

    move-result-object v0

    .line 90
    .local v0, "m":Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;
    sget-object v1, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->ready:Ljava/util/concurrent/ConcurrentHashMap;

    check-cast v1, Ljava/util/Map;

    invoke-direct {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->toData(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;)Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;

    move-result-object v2

    invoke-interface {v1, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_18} :catch_25
    .catchall {:try_start_1 .. :try_end_18} :catchall_61

    .line 95
    nop

    .end local v0    # "m":Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;
    :goto_19
    sget-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pending:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->remove(Ljava/lang/Object;)Z

    .line 96
    sget v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->epoch:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->epoch:I

    .line 97
    goto :goto_60

    .line 91
    :catch_25
    move-exception v0

    .line 92
    .local v0, "e":Ljava/lang/Exception;
    :try_start_26
    sget-object v1, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bad:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v1, p1}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->add(Ljava/lang/Object;)Z

    .line 93
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_36

    check-cast v2, Ljava/io/Serializable;

    goto :goto_39

    :cond_36
    move-object v2, v0

    check-cast v2, Ljava/io/Serializable;

    :goto_39
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Union \'"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\' can\'t be shown ("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "); it is drawn as a box."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->warn(Ljava/lang/String;)V
    :try_end_5f
    .catchall {:try_start_26 .. :try_end_5f} :catchall_61

    .line 95
    .end local v0    # "e":Ljava/lang/Exception;
    goto :goto_19

    .line 98
    :goto_60
    return-void

    .line 95
    :catchall_61
    move-exception v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pending:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v1, p1}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->remove(Ljava/lang/Object;)Z

    .line 96
    sget v1, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->epoch:I

    add-int/lit8 v1, v1, 0x1

    sput v1, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->epoch:I

    throw v0
.end method

.method private final bytesOf(Ljava/lang/Object;)[B
    .registers 8
    .param p1, "v"    # Ljava/lang/Object;

    .line 42
    nop

    .line 37
    nop

    .line 38
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    const/16 v1, 0x10

    const/4 v2, 0x0

    if-eqz v0, :cond_11

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/BinaryString;->getBytes()[B

    move-result-object v0

    goto :goto_3c

    .line 39
    :cond_11
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/SharedStr;

    if-eqz v0, :cond_1d

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/SharedStr;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/SharedStr;->getBytes()[B

    move-result-object v0

    goto :goto_3c

    .line 40
    :cond_1d
    instance-of v0, p1, Ljava/lang/String;

    if-eqz v0, :cond_3b

    move-object v0, p1

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-le v0, v1, :cond_39

    move-object v0, p1

    check-cast v0, Ljava/lang/String;

    sget-object v3, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v3, "getBytes(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_3c

    :cond_39
    move-object v0, v2

    goto :goto_3c

    .line 41
    :cond_3b
    move-object v0, v2

    .line 37
    :goto_3c
    nop

    .line 42
    if-eqz v0, :cond_4b

    .line 37
    nop

    .line 42
    move-object v3, v0

    .line 132
    .local v3, "it\\1":[B
    const/4 v4, 0x0

    .line 42
    .local v4, "$i$a$-takeIf-UnionMeshes$bytesOf$1\\1\\42\\0":I
    array-length v5, v3

    if-le v5, v1, :cond_47

    const/4 v1, 0x1

    goto :goto_48

    :cond_47
    const/4 v1, 0x0

    .end local v3    # "it\\1":[B
    .end local v4    # "$i$a$-takeIf-UnionMeshes$bytesOf$1\\1\\42\\0":I
    :goto_48
    if-eqz v1, :cond_4b

    move-object v2, v0

    :cond_4b
    return-object v2
.end method

.method static final get$lambda$10(J)Lkotlin/Unit;
    .registers 5
    .param p0, "done"    # J

    .line 68
    sget-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->ready:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "asset:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_25

    sget-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    sget v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->epoch:I

    sget-object v1, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    add-int/lit8 v0, v0, 0x1

    sput v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->epoch:I

    :cond_25
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final get$lambda$12(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V
    .registers 6
    .param p0, "$key"    # Ljava/lang/String;
    .param p1, "$p"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "$bytes"    # [B

    .line 73
    sget-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda0;

    invoke-direct {v2, p2}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda0;-><init>([B)V

    invoke-direct {v0, p0, v1, v2}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->build(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method static final get$lambda$12$lambda$11([B)[B
    .registers 2
    .param p0, "$bytes"    # [B

    .line 73
    sget-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->meshDataFromAsset([B)[B

    move-result-object v0

    return-object v0
.end method

.method static final get$lambda$8(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V
    .registers 6
    .param p0, "$key"    # Ljava/lang/String;
    .param p1, "$p"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "$b"    # [B

    .line 57
    sget-object v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda1;

    invoke-direct {v2, p2}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda1;-><init>([B)V

    invoke-direct {v0, p0, v1, v2}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->build(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method static final get$lambda$8$lambda$7([B)[B
    .registers 1
    .param p0, "$b"    # [B

    .line 57
    return-object p0
.end method

.method private final meshDataFromAsset([B)[B
    .registers 9
    .param p1, "bytes"    # [B

    .line 78
    sget-object v0, Lcom/exampletest/mobilestudiotest/format/CsgMesh;->INSTANCE:Lcom/exampletest/mobilestudiotest/format/CsgMesh;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/format/CsgMesh;->isCsgMesh([B)Z

    move-result v0

    if-eqz v0, :cond_9

    return-object p1

    .line 79
    :cond_9
    sget-object v0, Lcom/exampletest/mobilestudiotest/format/RbxFile;->INSTANCE:Lcom/exampletest/mobilestudiotest/format/RbxFile;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/format/RbxFile;->read([B)Lcom/exampletest/mobilestudiotest/format/RbxDocument;

    move-result-object v0

    .line 80
    .local v0, "doc":Lcom/exampletest/mobilestudiotest/format/RbxDocument;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/format/RbxDocument;->getRoots()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_17
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_69

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v2, "r":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/util/Collection;

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v2, v5, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v3, v4}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_39
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_17

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 81
    .local v4, "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v5

    const-string v6, "MeshData"

    invoke-virtual {v5, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bytesOf(Ljava/lang/Object;)[B

    move-result-object v5

    if-eqz v5, :cond_57

    .line 132
    .local v5, "it\\1":[B
    const/4 v1, 0x0

    .line 81
    .local v1, "$i$a$-let-UnionMeshes$meshDataFromAsset$1\\1\\81\\0":I
    return-object v5

    .line 82
    .end local v1    # "$i$a$-let-UnionMeshes$meshDataFromAsset$1\\1\\81\\0":I
    .end local v5    # "it\\1":[B
    :cond_57
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v5

    const-string v6, "MeshData2"

    invoke-virtual {v5, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bytesOf(Ljava/lang/Object;)[B

    move-result-object v5

    if-eqz v5, :cond_39

    .line 132
    .local v5, "it\\2":[B
    const/4 v1, 0x0

    .line 82
    .local v1, "$i$a$-let-UnionMeshes$meshDataFromAsset$2\\2\\82\\0":I
    return-object v5

    .line 84
    .end local v1    # "$i$a$-let-UnionMeshes$meshDataFromAsset$2\\2\\82\\0":I
    .end local v2    # "r":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v4    # "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v5    # "it\\2":[B
    :cond_69
    new-instance v1, Lcom/exampletest/mobilestudiotest/format/CsgMesh$CsgException;

    const-string v2, "the union asset has no mesh"

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$CsgException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method private final toData(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;)Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    .registers 34
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "m"    # Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;

    .line 101
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;->getPos()[F

    move-result-object v0

    .local v0, "p":[F
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;->getNrm()[F

    move-result-object v1

    .line 102
    .local v1, "n":[F
    const/4 v2, 0x3

    new-array v3, v2, [F

    fill-array-data v3, :array_202

    move-object v4, v3

    .line 103
    .local v4, "mn":[F
    new-array v3, v2, [F

    fill-array-data v3, :array_20c

    .line 104
    .local v3, "mx":[F
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;->getIndices()[I

    move-result-object v5

    array-length v6, v5

    const/4 v11, 0x0

    move v7, v11

    :goto_1b
    if-ge v7, v6, :cond_3d

    aget v8, v5, v7

    .local v8, "i":I
    const/4 v9, 0x0

    .local v9, "c":I
    :goto_20
    if-ge v9, v2, :cond_3a

    mul-int/lit8 v10, v8, 0x3

    add-int/2addr v10, v9

    aget v10, v0, v10

    .local v10, "v":F
    aget v12, v4, v9

    cmpg-float v12, v10, v12

    if-gez v12, :cond_2f

    aput v10, v4, v9

    :cond_2f
    aget v12, v3, v9

    cmpl-float v12, v10, v12

    if-lez v12, :cond_37

    aput v10, v3, v9

    .end local v10    # "v":F
    :cond_37
    add-int/lit8 v9, v9, 0x1

    goto :goto_20

    .end local v8    # "i":I
    .end local v9    # "c":I
    :cond_3a
    add-int/lit8 v7, v7, 0x1

    goto :goto_1b

    .line 105
    :cond_3d
    aget v5, v4, v11

    aget v6, v3, v11

    cmpl-float v5, v5, v6

    if-lez v5, :cond_56

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lkotlin/collections/ArraysKt;->fill$default([FFIIILjava/lang/Object;)V

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x0

    move-object v5, v3

    .end local v3    # "mx":[F
    .local v5, "mx":[F
    invoke-static/range {v5 .. v10}, Lkotlin/collections/ArraysKt;->fill$default([FFIIILjava/lang/Object;)V

    goto :goto_57

    .end local v5    # "mx":[F
    .restart local v3    # "mx":[F
    :cond_56
    move-object v5, v3

    .line 106
    .end local v3    # "mx":[F
    .restart local v5    # "mx":[F
    :goto_57
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 107
    .local v3, "groups":Ljava/util/LinkedHashMap;
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 108
    .local v6, "all":Ljava/util/ArrayList;
    const/4 v7, 0x0

    .line 109
    .local v7, "t":I
    :goto_62
    add-int/lit8 v8, v7, 0x2

    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;->getIndices()[I

    move-result-object v9

    array-length v9, v9

    if-ge v8, v9, :cond_165

    .line 110
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;->getIndices()[I

    move-result-object v8

    aget v8, v8, v7

    .local v8, "a":I
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;->getIndices()[I

    move-result-object v9

    add-int/lit8 v13, v7, 0x1

    aget v9, v9, v13

    .local v9, "b":I
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;->getIndices()[I

    move-result-object v13

    add-int/lit8 v14, v7, 0x2

    aget v13, v13, v14

    .line 111
    .local v13, "c":I
    add-int/lit8 v7, v7, 0x3

    .line 112
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/format/CsgMesh$Decoded;->getColors()[I

    move-result-object v14

    aget v14, v14, v8

    const/high16 v15, -0x1000000

    or-int/2addr v14, v15

    .line 113
    .local v14, "color":I
    move-object v15, v3

    check-cast v15, Ljava/util/Map;

    .local v15, "$this$getOrPut\\1":Ljava/util/Map;
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    .local v16, "key\\1":Ljava/lang/Object;
    move-object/from16 v17, v16

    .end local v16    # "key\\1":Ljava/lang/Object;
    .local v17, "key\\1":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 136
    .local v16, "$i$f$getOrPut\\1\\113":I
    move-object/from16 v10, v17

    const/16 v18, 0x2

    .end local v17    # "key\\1":Ljava/lang/Object;
    .local v10, "key\\1":Ljava/lang/Object;
    invoke-interface {v15, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v17

    .line 137
    .local v17, "value\\1":Ljava/lang/Object;
    if-nez v17, :cond_b3

    .line 138
    const/16 v19, 0x0

    .line 113
    .local v19, "$i$a$-getOrPut-UnionMeshes$toData$list$1\\2\\138\\0":I
    new-instance v20, Ljava/util/ArrayList;

    invoke-direct/range {v20 .. v20}, Ljava/util/ArrayList;-><init>()V

    .line 138
    .end local v19    # "$i$a$-getOrPut-UnionMeshes$toData$list$1\\2\\138\\0":I
    move-object/from16 v19, v20

    .line 139
    .local v19, "answer\\1":Ljava/lang/Object;
    move/from16 v20, v11

    move-object/from16 v11, v19

    .end local v19    # "answer\\1":Ljava/lang/Object;
    .local v11, "answer\\1":Ljava/lang/Object;
    invoke-interface {v15, v10, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    nop

    .end local v11    # "answer\\1":Ljava/lang/Object;
    goto :goto_b7

    .line 142
    :cond_b3
    move/from16 v20, v11

    move-object/from16 v19, v17

    .line 137
    :goto_b7
    nop

    .line 113
    .end local v10    # "key\\1":Ljava/lang/Object;
    .end local v15    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v16    # "$i$f$getOrPut\\1\\113":I
    .end local v17    # "value\\1":Ljava/lang/Object;
    move-object/from16 v10, v19

    check-cast v10, Ljava/util/ArrayList;

    .line 114
    .local v10, "list":Ljava/util/ArrayList;
    const/16 v11, 0x9

    new-array v11, v11, [F

    .line 115
    .local v11, "tri":[F
    const/4 v15, 0x0

    .line 116
    .local v15, "k":I
    filled-new-array {v8, v9, v13}, [I

    move-result-object v16

    move/from16 v12, v20

    const/16 v17, 0x1

    :goto_c9
    if-ge v12, v2, :cond_159

    aget v19, v16, v12

    .line 117
    .local v19, "v":I
    const/16 v21, 0x0

    move/from16 v30, v21

    move-object/from16 v21, v0

    move/from16 v0, v30

    .local v0, "q":I
    .local v21, "p":[F
    :goto_d5
    if-ge v0, v2, :cond_f3

    mul-int/lit8 v22, v19, 0x3

    add-int v22, v22, v0

    aget v22, v21, v22

    invoke-static/range {v22 .. v22}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v15, 0x1

    .end local v15    # "k":I
    .local v2, "k":I
    mul-int/lit8 v22, v19, 0x3

    add-int v22, v22, v0

    aget v22, v21, v22

    aput v22, v11, v15

    add-int/lit8 v0, v0, 0x1

    move v15, v2

    const/4 v2, 0x3

    goto :goto_d5

    .line 118
    .end local v0    # "q":I
    .end local v2    # "k":I
    .restart local v15    # "k":I
    :cond_f3
    mul-int/lit8 v0, v19, 0x3

    aget v0, v1, v0

    .local v0, "nx":F
    mul-int/lit8 v2, v19, 0x3

    add-int/lit8 v2, v2, 0x1

    aget v2, v1, v2

    .local v2, "ny":F
    mul-int/lit8 v22, v19, 0x3

    add-int/lit8 v22, v22, 0x2

    aget v22, v1, v22

    .line 119
    .local v22, "nz":F
    mul-float v23, v0, v0

    mul-float v24, v2, v2

    add-float v23, v23, v24

    mul-float v24, v22, v22

    move/from16 v25, v0

    .end local v0    # "nx":F
    .local v25, "nx":F
    add-float v0, v23, v24

    move-object/from16 v23, v1

    .end local v1    # "n":[F
    .local v23, "n":[F
    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    double-to-float v0, v0

    .line 120
    .local v0, "l":F
    const v1, 0x358637bd    # 1.0E-6f

    cmpl-float v1, v0, v1

    if-lez v1, :cond_124

    div-float v1, v25, v0

    .end local v25    # "nx":F
    .local v1, "nx":F
    div-float/2addr v2, v0

    div-float v22, v22, v0

    goto :goto_129

    .end local v1    # "nx":F
    .restart local v25    # "nx":F
    :cond_124
    const/4 v1, 0x0

    .end local v25    # "nx":F
    .restart local v1    # "nx":F
    const/high16 v2, 0x3f800000    # 1.0f

    const/16 v22, 0x0

    .line 121
    :goto_129
    move/from16 v24, v0

    .end local v0    # "l":F
    .local v24, "l":F
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static/range {v22 .. v22}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 122
    const/16 v25, 0x0

    invoke-static/range {v25 .. v25}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static/range {v25 .. v25}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 116
    .end local v1    # "nx":F
    .end local v2    # "ny":F
    .end local v19    # "v":I
    .end local v22    # "nz":F
    .end local v24    # "l":F
    add-int/lit8 v12, v12, 0x1

    move-object/from16 v0, v21

    move-object/from16 v1, v23

    const/4 v2, 0x3

    goto/16 :goto_c9

    .line 124
    .end local v21    # "p":[F
    .end local v23    # "n":[F
    .local v0, "p":[F
    .local v1, "n":[F
    :cond_159
    move-object/from16 v21, v0

    move-object/from16 v23, v1

    .end local v0    # "p":[F
    .end local v1    # "n":[F
    .restart local v21    # "p":[F
    .restart local v23    # "n":[F
    invoke-virtual {v6, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v11, v20

    const/4 v2, 0x3

    goto/16 :goto_62

    .line 126
    .end local v8    # "a":I
    .end local v9    # "b":I
    .end local v10    # "list":Ljava/util/ArrayList;
    .end local v11    # "tri":[F
    .end local v13    # "c":I
    .end local v14    # "color":I
    .end local v15    # "k":I
    .end local v21    # "p":[F
    .end local v23    # "n":[F
    .restart local v0    # "p":[F
    .restart local v1    # "n":[F
    :cond_165
    move-object/from16 v21, v0

    move-object/from16 v23, v1

    move/from16 v20, v11

    const/16 v17, 0x1

    const/16 v18, 0x2

    .end local v0    # "p":[F
    .end local v1    # "n":[F
    .restart local v21    # "p":[F
    .restart local v23    # "n":[F
    move-object v0, v3

    check-cast v0, Ljava/util/Map;

    .local v0, "$this$map\\3":Ljava/util/Map;
    const/4 v1, 0x0

    .line 143
    .local v1, "$i$f$map\\3\\126":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v8

    invoke-direct {v2, v8}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\4":Ljava/util/Collection;
    move-object v8, v0

    .local v8, "$this$mapTo\\4":Ljava/util/Map;
    const/4 v9, 0x0

    .line 144
    .local v9, "$i$f$mapTo\\4\\143":I
    invoke-interface {v8}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_188
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_1bd

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/util/Map$Entry;

    .line 145
    .local v11, "item\\4":Ljava/util/Map$Entry;
    const/4 v12, 0x0

    .local v12, "$i$a$-map-UnionMeshes$toData$1\\5\\145\\0":I
    invoke-interface {v11}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Number;

    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    move-result v13

    .local v13, "col\\5":I
    invoke-interface {v11}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/util/ArrayList;

    .line 126
    .local v14, "l\\5":Ljava/util/ArrayList;
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    move-object/from16 v16, v14

    check-cast v16, Ljava/util/Collection;

    move-object/from16 v19, v0

    .end local v0    # "$this$map\\3":Ljava/util/Map;
    .local v19, "$this$map\\3":Ljava/util/Map;
    invoke-static/range {v16 .. v16}, Lkotlin/collections/CollectionsKt;->toFloatArray(Ljava/util/Collection;)[F

    move-result-object v0

    invoke-static {v15, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    .line 145
    .end local v12    # "$i$a$-map-UnionMeshes$toData$1\\5\\145\\0":I
    .end local v13    # "col\\5":I
    .end local v14    # "l\\5":Ljava/util/ArrayList;
    invoke-interface {v2, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, v19

    goto :goto_188

    .line 146
    .end local v11    # "item\\4":Ljava/util/Map$Entry;
    .end local v19    # "$this$map\\3":Ljava/util/Map;
    .restart local v0    # "$this$map\\3":Ljava/util/Map;
    :cond_1bd
    move-object/from16 v19, v0

    .end local v0    # "$this$map\\3":Ljava/util/Map;
    .end local v2    # "destination\\4":Ljava/util/Collection;
    .end local v8    # "$this$mapTo\\4":Ljava/util/Map;
    .end local v9    # "$i$f$mapTo\\4\\143":I
    .restart local v19    # "$this$map\\3":Ljava/util/Map;
    move-object/from16 v26, v2

    check-cast v26, Ljava/util/List;

    .line 143
    nop

    .line 127
    .end local v1    # "$i$f$map\\3\\126":I
    .end local v19    # "$this$map\\3":Ljava/util/Map;
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    aget v1, v4, v20

    aget v2, v5, v20

    add-float/2addr v1, v2

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    aget v8, v4, v17

    aget v9, v5, v17

    add-float/2addr v8, v9

    div-float/2addr v8, v2

    aget v9, v4, v18

    aget v10, v5, v18

    add-float/2addr v9, v10

    div-float/2addr v9, v2

    invoke-direct {v0, v1, v8, v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 128
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    aget v2, v5, v20

    aget v8, v4, v20

    sub-float/2addr v2, v8

    aget v8, v5, v17

    aget v9, v4, v17

    sub-float/2addr v8, v9

    aget v9, v5, v18

    aget v10, v4, v18

    sub-float/2addr v9, v10

    invoke-direct {v1, v2, v8, v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    move-object/from16 v29, v6

    check-cast v29, Ljava/util/List;

    .line 126
    new-instance v24, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;

    move-object/from16 v25, p1

    move-object/from16 v27, v0

    move-object/from16 v28, v1

    invoke-direct/range {v24 .. v29}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;-><init>(Ljava/lang/String;Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Ljava/util/List;)V

    return-object v24

    nop

    :array_202
    .array-data 4
        0x7f7fffff    # Float.MAX_VALUE
        0x7f7fffff    # Float.MAX_VALUE
        0x7f7fffff    # Float.MAX_VALUE
    .end array-data

    :array_20c
    .array-data 4
        -0x800001
        -0x800001
        -0x800001
    .end array-data
.end method


# virtual methods
.method public final get(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    .registers 12
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "p"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v0

    const-string v1, "MeshData2"

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_26

    move-object v4, v0

    .line 132
    .local v4, "it\\1":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 48
    .local v5, "$i$a$-takeIf-UnionMeshes$get$inlineVal$1\\1\\48\\0":I
    sget-object v6, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-direct {v6, v4}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bytesOf(Ljava/lang/Object;)[B

    move-result-object v6

    if-eqz v6, :cond_20

    move v4, v2

    goto :goto_21

    :cond_20
    move v4, v1

    .end local v4    # "it\\1":Ljava/lang/Object;
    .end local v5    # "$i$a$-takeIf-UnionMeshes$get$inlineVal$1\\1\\48\\0":I
    :goto_21
    if-nez v4, :cond_24

    move-object v0, v3

    :cond_24
    if-nez v0, :cond_3f

    :cond_26
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v0

    const-string v4, "MeshData"

    invoke-virtual {v0, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_40

    move-object v4, v0

    .line 132
    .local v4, "it\\2":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 48
    .local v5, "$i$a$-takeIf-UnionMeshes$get$inlineVal$2\\2\\48\\0":I
    sget-object v6, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-direct {v6, v4}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bytesOf(Ljava/lang/Object;)[B

    move-result-object v6

    if-eqz v6, :cond_3d

    move v1, v2

    .end local v4    # "it\\2":Ljava/lang/Object;
    .end local v5    # "$i$a$-takeIf-UnionMeshes$get$inlineVal$2\\2\\48\\0":I
    :cond_3d
    if-eqz v1, :cond_40

    :cond_3f
    goto :goto_41

    :cond_40
    move-object v0, v3

    .line 49
    .local v0, "inlineVal":Ljava/lang/Object;
    :goto_41
    if-eqz v0, :cond_b6

    .line 50
    sget-object v1, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->inlineKeys:Ljava/util/Map;

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_87

    move-object v1, p0

    check-cast v1, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    .local v1, "$this$get_u24lambda_u245\\3":Lcom/exampletest/mobilestudiotest/render/UnionMeshes;
    const/4 v2, 0x0

    .line 51
    .local v2, "$i$a$-run-UnionMeshes$get$key$1\\3\\50\\0":I
    invoke-direct {v1, v0}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bytesOf(Ljava/lang/Object;)[B

    move-result-object v4

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 52
    .local v4, "b\\3":[B
    array-length v5, v4

    invoke-static {v4}, Ljava/util/Arrays;->hashCode([B)I

    move-result v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "inline:"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, ":"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v6, v5

    .line 132
    .local v6, "it\\4":Ljava/lang/String;
    const/4 v7, 0x0

    .line 52
    .local v7, "$i$a$-also-UnionMeshes$get$key$1$1\\4\\52\\3":I
    sget-object v8, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->inlineKeys:Ljava/util/Map;

    const-string v9, "inlineKeys"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v8, v0, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .end local v1    # "$this$get_u24lambda_u245\\3":Lcom/exampletest/mobilestudiotest/render/UnionMeshes;
    .end local v2    # "$i$a$-run-UnionMeshes$get$key$1\\3\\50\\0":I
    .end local v4    # "b\\3":[B
    .end local v6    # "it\\4":Ljava/lang/String;
    .end local v7    # "$i$a$-also-UnionMeshes$get$key$1$1\\4\\52\\3":I
    move-object v1, v5

    .line 54
    .local v1, "key":Ljava/lang/String;
    :cond_87
    sget-object v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->ready:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v2, v1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;

    if-eqz v2, :cond_93

    .line 132
    .local v2, "it\\5":Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    const/4 v3, 0x0

    .line 54
    .local v3, "$i$a$-let-UnionMeshes$get$1\\5\\54\\0":I
    return-object v2

    .line 55
    .end local v2    # "it\\5":Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    .end local v3    # "$i$a$-let-UnionMeshes$get$1\\5\\54\\0":I
    :cond_93
    sget-object v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bad:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v2, v1}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_b5

    sget-object v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pending:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v2, v1}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->add(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_b5

    .line 56
    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bytesOf(Ljava/lang/Object;)[B

    move-result-object v2

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 57
    .local v2, "b":[B
    sget-object v4, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pool:Ljava/util/concurrent/ExecutorService;

    new-instance v5, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;

    invoke-direct {v5, v1, p1, v2}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V

    invoke-interface {v4, v5}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 58
    return-object v3

    .line 55
    .end local v2    # "b":[B
    :cond_b5
    return-object v3

    .line 60
    .end local v1    # "key":Ljava/lang/String;
    :cond_b6
    sget-object v1, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v4

    const-string v5, "AssetId"

    invoke-virtual {v4, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v4}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->idOf(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object v1

    if-eqz v1, :cond_12d

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    .line 61
    .local v4, "id":J
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "asset:"

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 62
    .restart local v1    # "key":Ljava/lang/String;
    sget-object v6, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->ready:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v6, v1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;

    if-eqz v6, :cond_eb

    .line 132
    .local v6, "it\\6":Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    const/4 v2, 0x0

    .line 62
    .local v2, "$i$a$-let-UnionMeshes$get$3\\6\\62\\0":I
    return-object v6

    .line 63
    .end local v2    # "$i$a$-let-UnionMeshes$get$3\\6\\62\\0":I
    .end local v6    # "it\\6":Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    :cond_eb
    sget-object v6, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->bad:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v6, v1}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_12c

    sget-object v6, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pending:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v6, v1}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_12c

    .line 64
    sget-object v6, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    invoke-virtual {v6, v4, v5}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->request(J)[B

    move-result-object v6

    .line 65
    .local v6, "bytes":[B
    if-nez v6, :cond_118

    .line 66
    sget-boolean v7, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->listening:Z

    if-nez v7, :cond_117

    .line 67
    sput-boolean v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->listening:Z

    .line 68
    sget-object v2, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->getListeners()Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v2

    new-instance v7, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda3;

    invoke-direct {v7}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda3;-><init>()V

    invoke-virtual {v2, v7}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 70
    :cond_117
    return-object v3

    .line 72
    :cond_118
    sget-object v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pending:Ljava/util/concurrent/ConcurrentHashMap$KeySetView;

    invoke-virtual {v2, v1}, Ljava/util/concurrent/ConcurrentHashMap$KeySetView;->add(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_121

    return-object v3

    .line 73
    :cond_121
    sget-object v2, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->pool:Ljava/util/concurrent/ExecutorService;

    new-instance v7, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;

    invoke-direct {v7, v1, p1, v6}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V

    invoke-interface {v2, v7}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 74
    return-object v3

    .line 63
    .end local v6    # "bytes":[B
    :cond_12c
    return-object v3

    .line 60
    .end local v1    # "key":Ljava/lang/String;
    .end local v4    # "id":J
    :cond_12d
    return-object v3
.end method

.method public final getEpoch()I
    .registers 2

    .line 33
    sget v0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->epoch:I

    return v0
.end method

.method public final isStored(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 11
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "p"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    const-string v0, "PartOperation"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_51

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "NegateOperation"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_51

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$none\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 133
    .local v2, "$i$f$none\\1\\45":I
    instance-of v3, v0, Ljava/util/Collection;

    const/4 v4, 0x1

    if-eqz v3, :cond_31

    move-object v3, v0

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_31

    move v0, v4

    goto :goto_4e

    .line 134
    :cond_31
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_35
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4d

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\1":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v6, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v7, 0x0

    .line 45
    .local v7, "$i$a$-none-UnionMeshes$isStored$1\\2\\134\\0":I
    const-string v8, "BasePart"

    invoke-virtual {v6, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v6

    .line 134
    .end local v6    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "$i$a$-none-UnionMeshes$isStored$1\\2\\134\\0":I
    if-eqz v6, :cond_35

    move v0, v1

    goto :goto_4e

    .line 135
    .end local v5    # "element\\1":Ljava/lang/Object;
    :cond_4d
    move v0, v4

    .line 45
    .end local v0    # "$this$none\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$none\\1\\45":I
    :goto_4e
    if-eqz v0, :cond_51

    move v1, v4

    :cond_51
    return v1
.end method

###### Class com.exampletest.mobilestudiotest.render.UnionMeshes.Data (com.exampletest.mobilestudiotest.render.UnionMeshes$Data)
.class public final Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
.super Ljava/lang/Object;
.source "UnionMeshes.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/UnionMeshes;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Data"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0008\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\r\u0018\u00002\u00020\u0001BG\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0018\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00080\u00060\u0005\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u000c\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0005\u00a2\u0006\u0004\u0008\r\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R#\u0010\u0004\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00080\u00060\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0014R\u0011\u0010\u000b\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0015\u0010\u0014R\u0017\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0012\u00a8\u0006\u0017"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;",
        "",
        "key",
        "",
        "groups",
        "",
        "Lkotlin/Pair;",
        "",
        "",
        "center",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "size",
        "triangles",
        "<init>",
        "(Ljava/lang/String;Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Ljava/util/List;)V",
        "getKey",
        "()Ljava/lang/String;",
        "getGroups",
        "()Ljava/util/List;",
        "getCenter",
        "()Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "getSize",
        "getTriangles",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final center:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private final groups:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "[F>;>;"
        }
    .end annotation
.end field

.field private final key:Ljava/lang/String;

.field private final size:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private final triangles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "[F>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Ljava/util/List;)V
    .registers 7
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "groups"    # Ljava/util/List;
    .param p3, "center"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p4, "size"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p5, "triangles"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "[F>;>;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Ljava/util/List<",
            "[F>;)V"
        }
    .end annotation

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "groups"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "center"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "size"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "triangles"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->key:Ljava/lang/String;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->groups:Ljava/util/List;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->center:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->size:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->triangles:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 26
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->center:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public final getGroups()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "[F>;>;"
        }
    .end annotation

    .line 26
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->groups:Ljava/util/List;

    return-object v0
.end method

.method public final getKey()Ljava/lang/String;
    .registers 2

    .line 26
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->key:Ljava/lang/String;

    return-object v0
.end method

.method public final getSize()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 26
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->size:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public final getTriangles()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "[F>;"
        }
    .end annotation

    .line 26
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->triangles:Ljava/util/List;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/render/UnionMeshes;"
    method = "get$lambda$12$lambda$11"
    proto = "([B)[B"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:[B


# direct methods
.method public synthetic constructor <init>([B)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda0;->f$0:[B

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda0;->f$0:[B

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->get$lambda$12$lambda$11([B)[B

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/render/UnionMeshes;"
    method = "get$lambda$8$lambda$7"
    proto = "([B)[B"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:[B


# direct methods
.method public synthetic constructor <init>([B)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda1;->f$0:[B

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda1;->f$0:[B

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->get$lambda$8$lambda$7([B)[B

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/render/UnionMeshes;"
    method = "get$lambda$8"
    proto = "(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

.field public final synthetic f$2:[B


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;->f$0:Ljava/lang/String;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;->f$2:[B

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;->f$0:Ljava/lang/String;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda2;->f$2:[B

    invoke-static {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->get$lambda$8(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/render/UnionMeshes;"
    method = "get$lambda$10"
    proto = "(J)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->get$lambda$10(J)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.render.UnionMeshes$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/render/UnionMeshes;"
    method = "get$lambda$12"
    proto = "(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

.field public final synthetic f$2:[B


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;->f$0:Ljava/lang/String;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;->f$2:[B

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;->f$0:Ljava/lang/String;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;->f$1:Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$$ExternalSyntheticLambda4;->f$2:[B

    invoke-static {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->get$lambda$12(Ljava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;[B)V

    return-void
.end method
