###### Class com.exampletest.mobilestudiotest.render.TexBind (com.exampletest.mobilestudiotest.render.TexBind)
.class public final Lcom/exampletest/mobilestudiotest/render/TexBind;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0002\u0008\u000c\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0000\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\t\u0010\u000e\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u000f\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0010\u001a\u00020\u0006H\u00c6\u0003J\'\u0010\u0011\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0006H\u00c6\u0001J\u0013\u0010\u0012\u001a\u00020\u00132\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0015\u001a\u00020\u0003H\u00d6\u0001J\t\u0010\u0016\u001a\u00020\u0017H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\r\u00a8\u0006\u0018"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/TexBind;",
        "",
        "color",
        "",
        "normal",
        "scale",
        "",
        "<init>",
        "(IIF)V",
        "getColor",
        "()I",
        "getNormal",
        "getScale",
        "()F",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final color:I

.field private final normal:I

.field private final scale:F


# direct methods
.method public constructor <init>(IIF)V
    .registers 4
    .param p1, "color"    # I
    .param p2, "normal"    # I
    .param p3, "scale"    # F

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->color:I

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->normal:I

    iput p3, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->scale:F

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/render/TexBind;IIFILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/render/TexBind;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget p1, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->color:I

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget p2, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->normal:I

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget p3, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->scale:F

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/render/TexBind;->copy(IIF)Lcom/exampletest/mobilestudiotest/render/TexBind;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->color:I

    return v0
.end method

.method public final component2()I
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->normal:I

    return v0
.end method

.method public final component3()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->scale:F

    return v0
.end method

.method public final copy(IIF)Lcom/exampletest/mobilestudiotest/render/TexBind;
    .registers 5

    new-instance v0, Lcom/exampletest/mobilestudiotest/render/TexBind;

    invoke-direct {v0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/render/TexBind;-><init>(IIF)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/render/TexBind;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/render/TexBind;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->color:I

    iget v4, v1, Lcom/exampletest/mobilestudiotest/render/TexBind;->color:I

    if-eq v3, v4, :cond_14

    return v2

    :cond_14
    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->normal:I

    iget v4, v1, Lcom/exampletest/mobilestudiotest/render/TexBind;->normal:I

    if-eq v3, v4, :cond_1b

    return v2

    :cond_1b
    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->scale:F

    iget v1, v1, Lcom/exampletest/mobilestudiotest/render/TexBind;->scale:F

    invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_26

    return v2

    :cond_26
    return v0
.end method

.method public final getColor()I
    .registers 2

    .line 18
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->color:I

    return v0
.end method

.method public final getNormal()I
    .registers 2

    .line 18
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->normal:I

    return v0
.end method

.method public final getScale()F
    .registers 2

    .line 18
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->scale:F

    return v0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->color:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->normal:I

    invoke-static {v2}, Ljava/lang/Integer;->hashCode(I)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->scale:F

    invoke-static {v2}, Ljava/lang/Float;->hashCode(F)I

    move-result v2

    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 6

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->color:I

    iget v1, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->normal:I

    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/TexBind;->scale:F

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "TexBind(color="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, ", normal="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", scale="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
