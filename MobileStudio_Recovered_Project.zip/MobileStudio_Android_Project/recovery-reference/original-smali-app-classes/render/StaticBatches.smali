###### Class com.exampletest.mobilestudiotest.render.StaticBatches (com.exampletest.mobilestudiotest.render.StaticBatches)
.class public final Lcom/exampletest/mobilestudiotest/render/StaticBatches;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;,
        Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;,
        Lcom/exampletest/mobilestudiotest/render/StaticBatches$Companion;,
        Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;,
        Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;,
        Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;,
        Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStaticBatches.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StaticBatches.kt\ncom/exampletest/mobilestudiotest/render/StaticBatches\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,462:1\n1#2:463\n1011#3,2:464\n774#3:466\n865#3,2:467\n1056#3:469\n382#4,7:470\n382#4,7:477\n*S KotlinDebug\n*F\n+ 1 StaticBatches.kt\ncom/exampletest/mobilestudiotest/render/StaticBatches\n*L\n223#1:464,2\n240#1:466\n240#1:467,2\n240#1:469\n248#1:470,7\n298#1:477,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0010\u0008\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0002\u0008\t\n\u0002\u0010 \n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0002\u0008\u000b\u0018\u0000 W2\u00020\u0001:\u0007QRSTUVWB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u000e\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 J\u0010\u0010!\u001a\u00020\u001a2\u0006\u0010\"\u001a\u00020#H\u0002J\u0016\u0010$\u001a\u00020#2\u0006\u0010%\u001a\u00020\u001a2\u0006\u0010&\u001a\u00020#J \u0010\'\u001a\u00020\u00082\u0006\u0010(\u001a\u00020#2\u0006\u0010)\u001a\u00020#2\u0006\u0010*\u001a\u00020#H\u0002J^\u0010+\u001a\u00020\u001e2\u000c\u0010,\u001a\u0008\u0012\u0004\u0012\u00020\u000f0-2\u0006\u0010.\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\u001a2\u0006\u0010/\u001a\u0002002\u0006\u00101\u001a\u0002022\u0006\u0010&\u001a\u00020#2\u0008\u00103\u001a\u0004\u0018\u0001002\u0006\u00104\u001a\u00020#2\u0006\u00105\u001a\u00020\u00082\u0006\u00106\u001a\u00020\u0008J\u0018\u00107\u001a\u00020\u001e2\u0006\u00108\u001a\u00020\u000f2\u0006\u00109\u001a\u00020:H\u0002J\u0010\u0010;\u001a\u00020\u001e2\u0006\u0010<\u001a\u00020\tH\u0002J \u0010=\u001a\u00020\u001e2\u0006\u0010<\u001a\u00020\t2\u0006\u0010\u001c\u001a\u00020\u001a2\u0006\u0010>\u001a\u00020\u001aH\u0002J(\u0010D\u001a\u00020\u001a2\u0006\u0010E\u001a\u00020\u001a2\u0006\u0010F\u001a\u00020\u001a2\u0006\u0010<\u001a\u00020\u001a2\u0006\u0010G\u001a\u00020\u001aH\u0002J\u0010\u0010H\u001a\u00020\u001a2\u0006\u0010I\u001a\u00020#H\u0002J\u0010\u0010J\u001a\u00020\u001a2\u0006\u0010I\u001a\u00020#H\u0002J \u0010K\u001a\u00020\u001a2\u0006\u0010L\u001a\u00020M2\u0006\u0010N\u001a\u00020@2\u0006\u0010O\u001a\u00020\u001aH\u0002J \u0010P\u001a\u00020\u001a2\u0006\u0010L\u001a\u00020M2\u0006\u0010N\u001a\u00020@2\u0006\u0010O\u001a\u00020\u001aH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R-\u0010\u0006\u001a\u001e\u0012\u0004\u0012\u00020\u0008\u0012\u0004\u0012\u00020\t0\u0007j\u000e\u0012\u0004\u0012\u00020\u0008\u0012\u0004\u0012\u00020\t`\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR!\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\u000f0\u000ej\u0008\u0012\u0004\u0012\u00020\u000f`\u0010\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R!\u0010\u0013\u001a\u0012\u0012\u0004\u0012\u00020\t0\u000ej\u0008\u0012\u0004\u0012\u00020\t`\u0010\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0012R\u001e\u0010\u0016\u001a\u00020\u00082\u0006\u0010\u0015\u001a\u00020\u0008@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0017\u0010\u0018R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010?\u001a\u00020@X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010A\u001a\u0004\u0018\u00010BX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020 X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006X"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches;",
        "",
        "host",
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;)V",
        "chunks",
        "Ljava/util/HashMap;",
        "",
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;",
        "Lkotlin/collections/HashMap;",
        "getChunks",
        "()Ljava/util/HashMap;",
        "loose",
        "Ljava/util/ArrayList;",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "Lkotlin/collections/ArrayList;",
        "getLoose",
        "()Ljava/util/ArrayList;",
        "visible",
        "getVisible",
        "value",
        "totalBytes",
        "getTotalBytes",
        "()J",
        "gen",
        "",
        "lastListVersion",
        "frame",
        "reset",
        "",
        "deleteBuffers",
        "",
        "tierOf",
        "r",
        "",
        "tierRange",
        "tier",
        "detail",
        "keyOf",
        "x",
        "y",
        "z",
        "update",
        "parts",
        "",
        "listVersion",
        "cam",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "fr",
        "Lcom/exampletest/mobilestudiotest/render/Frustum;",
        "shadowAt",
        "shadowR",
        "budgetNs",
        "maxBytes",
        "join",
        "p",
        "rec",
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;",
        "free",
        "c",
        "build",
        "texEpoch",
        "scratch",
        "",
        "direct",
        "Ljava/nio/ByteBuffer;",
        "little",
        "b4",
        "a",
        "b",
        "d",
        "sb",
        "v",
        "ub",
        "pack",
        "s",
        "Lcom/exampletest/mobilestudiotest/render/BatchSpec;",
        "out",
        "start",
        "packMesh",
        "Host",
        "PartRec",
        "Batch",
        "Chunk",
        "Group",
        "GroupKey",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final CELL:F = 64.0f

.field public static final COOL:I = 0x2d

.field public static final Companion:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Companion;

.field public static final MESH_STRIDE_BYTES:I = 0x1c

.field public static final MESH_STRIDE_INTS:I = 0x7

.field public static final STRIDE_BYTES:I = 0x28

.field public static final STRIDE_INTS:I = 0xa

.field public static final UNLOAD_FRAMES:I = 0x384


# instance fields
.field private final chunks:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Long;",
            "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;",
            ">;"
        }
    .end annotation
.end field

.field private direct:Ljava/nio/ByteBuffer;

.field private frame:I

.field private gen:I

.field private final host:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;

.field private lastListVersion:I

.field private final little:Z

.field private final loose:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation
.end field

.field private scratch:[I

.field private totalBytes:J

.field private final visible:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->Companion:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Companion;

    return-void
.end method

.method public constructor <init>(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;)V
    .registers 4
    .param p1, "host"    # Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;

    const-string v0, "host"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->host:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;

    .line 132
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    .line 134
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->loose:Ljava/util/ArrayList;

    .line 136
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->visible:Ljava/util/ArrayList;

    .line 138
    const/4 v0, 0x1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->gen:I

    .line 139
    const/4 v0, -0x1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->lastListVersion:I

    .line 336
    const v0, 0x16800

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->scratch:[I

    .line 338
    invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;

    move-result-object v0

    sget-object v1, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->little:Z

    .line 79
    return-void
.end method

.method private final b4(IIII)I
    .registers 7
    .param p1, "a"    # I
    .param p2, "b"    # I
    .param p3, "c"    # I
    .param p4, "d"    # I

    .line 341
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->little:Z

    if-eqz v0, :cond_16

    and-int/lit16 v0, p1, 0xff

    and-int/lit16 v1, p2, 0xff

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    and-int/lit16 v1, p3, 0xff

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    and-int/lit16 v1, p4, 0xff

    shl-int/lit8 v1, v1, 0x18

    or-int/2addr v0, v1

    goto :goto_27

    .line 342
    :cond_16
    and-int/lit16 v0, p1, 0xff

    shl-int/lit8 v0, v0, 0x18

    and-int/lit16 v1, p2, 0xff

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    and-int/lit16 v1, p3, 0xff

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    and-int/lit16 v1, p4, 0xff

    or-int/2addr v0, v1

    :goto_27
    return v0
.end method

.method private final build(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;II)V
    .registers 35
    .param p1, "c"    # Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .param p2, "frame"    # I
    .param p3, "texEpoch"    # I

    .line 268
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    new-instance v0, Ljava/util/ArrayList;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getParts()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(I)V

    move-object v3, v0

    .line 269
    .local v3, "keep":Ljava/util/ArrayList;
    new-instance v0, Ljava/util/IdentityHashMap;

    invoke-direct {v0}, Ljava/util/IdentityHashMap;-><init>()V

    check-cast v0, Ljava/util/Map;

    invoke-static {v0}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v4

    .line 270
    .local v4, "once":Ljava/util/Set;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getParts()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v5, "iterator(...)"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_2a
    :goto_2a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v7, 0x0

    const-string v8, "next(...)"

    if-eqz v6, :cond_67

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 271
    .local v6, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget-object v8, v6, Lcom/exampletest/mobilestudiotest/model/Instance;->renderRec:Ljava/lang/Object;

    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    if-eqz v9, :cond_45

    check-cast v8, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    goto :goto_46

    :cond_45
    move-object v8, v7

    :goto_46
    if-eqz v8, :cond_2a

    .line 272
    .local v8, "r":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getChunk()Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    move-result-object v9

    if-ne v9, v2, :cond_64

    invoke-interface {v4, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2a

    .line 273
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getSeen()I

    move-result v9

    move/from16 v10, p2

    if-eq v9, v10, :cond_60

    invoke-virtual {v8, v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setChunk(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V

    goto :goto_2a

    .line 274
    :cond_60
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .end local v8    # "r":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    goto :goto_2a

    .line 272
    .restart local v8    # "r":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    :cond_64
    move/from16 v10, p2

    goto :goto_2a

    .line 276
    .end local v6    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "r":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    :cond_67
    move/from16 v10, p2

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setParts(Ljava/util/ArrayList;)V

    .line 277
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->free(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V

    .line 278
    const v0, 0x7f7fffff    # Float.MAX_VALUE

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setX0(F)V

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setY0(F)V

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setZ0(F)V

    .line 279
    const v0, -0x800001

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setX1(F)V

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setY1(F)V

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setZ1(F)V

    .line 280
    const/4 v6, 0x0

    invoke-virtual {v2, v6}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setMaxTier(I)V

    .line 281
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    move-object v9, v0

    .line 282
    .local v9, "groups":Ljava/util/LinkedHashMap;
    const/4 v0, 0x0

    .line 283
    .local v0, "pending":Z
    new-instance v11, Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v12

    invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 284
    .local v11, "stillIn":Ljava/util/ArrayList;
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v12

    invoke-static {v12, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move v13, v0

    .end local v0    # "pending":Z
    .local v13, "pending":Z
    :goto_a3
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1af

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v15, v0

    check-cast v15, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 285
    .local v15, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :try_start_b3
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->host:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;

    invoke-interface {v0, v15}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;->spec(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0
    :try_end_b9
    .catch Ljava/lang/Exception; {:try_start_b3 .. :try_end_b9} :catch_ba

    goto :goto_bc

    :catch_ba
    move-exception v0

    move-object v0, v7

    .line 286
    .local v0, "list":Ljava/util/List;
    :goto_bc
    iget-object v14, v15, Lcom/exampletest/mobilestudiotest/model/Instance;->renderRec:Ljava/lang/Object;

    const-string v6, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.render.StaticBatches.PartRec"

    invoke-static {v14, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v6, v14

    check-cast v6, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    .line 287
    .local v6, "rec":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    move-object v14, v0

    check-cast v14, Ljava/util/Collection;

    if-eqz v14, :cond_d3

    invoke-interface {v14}, Ljava/util/Collection;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_d3

    const/4 v14, 0x0

    goto :goto_d4

    :cond_d3
    const/4 v14, 0x1

    :goto_d4
    if-eqz v14, :cond_e8

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setChunk(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V

    const/4 v14, 0x0

    invoke-virtual {v6, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setBatchable(Z)V

    const/4 v14, 0x1

    invoke-virtual {v6, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setKnown(Z)V

    iget-object v14, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->loose:Ljava/util/ArrayList;

    invoke-virtual {v14, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x0

    goto :goto_a3

    .line 288
    :cond_e8
    invoke-virtual {v11, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 290
    sget-object v14, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v14, v15}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v14

    const/high16 v16, 0x3f000000    # 0.5f

    mul-float v14, v14, v16

    .line 291
    .local v14, "pr":F
    sget-object v7, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v7, v15}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    .line 292
    .local v7, "pc":Lcom/exampletest/mobilestudiotest/model/CFrame;
    move-object/from16 v16, v0

    .end local v0    # "list":Ljava/util/List;
    .local v16, "list":Ljava/util/List;
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getX()F

    move-result v0

    move-object/from16 v19, v3

    .end local v3    # "keep":Ljava/util/ArrayList;
    .local v19, "keep":Ljava/util/ArrayList;
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getY()F

    move-result v3

    move-object/from16 v20, v4

    .end local v4    # "once":Ljava/util/Set;
    .local v20, "once":Ljava/util/Set;
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getZ()F

    move-result v4

    invoke-virtual {v2, v0, v3, v4, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->grow(FFFF)V

    .line 293
    invoke-direct {v1, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->tierOf(F)I

    move-result v0

    .line 294
    .local v0, "tier":I
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getMaxTier()I

    move-result v3

    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setMaxTier(I)V

    .line 295
    invoke-interface/range {v16 .. v16}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_127
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_19f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/render/BatchSpec;

    .line 296
    .local v4, "s":Lcom/exampletest/mobilestudiotest/render/BatchSpec;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getPending()Z

    move-result v21

    if-eqz v21, :cond_13a

    const/4 v13, 0x1

    .line 297
    :cond_13a
    move-object/from16 v21, v3

    new-instance v3, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;

    move-object/from16 v22, v6

    .end local v6    # "rec":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    .local v22, "rec":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getKind()I

    move-result v6

    move-object/from16 v23, v7

    .end local v7    # "pc":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v23, "pc":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getTex()Lcom/exampletest/mobilestudiotest/render/TexBind;

    move-result-object v7

    invoke-direct {v3, v0, v6, v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;-><init>(IILcom/exampletest/mobilestudiotest/render/TexBind;)V

    .line 298
    .local v3, "gk":Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    move-object v6, v9

    check-cast v6, Ljava/util/Map;

    .local v6, "$this$getOrPut\\1":Ljava/util/Map;
    move-object v7, v3

    .local v7, "key\\1":Ljava/lang/Object;
    const/16 v24, 0x0

    .line 477
    .local v24, "$i$f$getOrPut\\1\\298":I
    invoke-interface {v6, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v25

    .line 478
    .local v25, "value\\1":Ljava/lang/Object;
    if-nez v25, :cond_172

    .line 479
    const/16 v26, 0x0

    .line 298
    .local v26, "$i$a$-getOrPut-StaticBatches$build$g$1\\2\\479\\0":I
    move-object/from16 v27, v3

    .end local v3    # "gk":Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    .local v27, "gk":Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    new-instance v3, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;

    move-object/from16 v28, v9

    .end local v9    # "groups":Ljava/util/LinkedHashMap;
    .local v28, "groups":Ljava/util/LinkedHashMap;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getKind()I

    move-result v9

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getTex()Lcom/exampletest/mobilestudiotest/render/TexBind;

    move-result-object v10

    invoke-direct {v3, v0, v9, v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;-><init>(IILcom/exampletest/mobilestudiotest/render/TexBind;)V

    .line 479
    .end local v26    # "$i$a$-getOrPut-StaticBatches$build$g$1\\2\\479\\0":I
    nop

    .line 480
    .local v3, "answer\\1":Ljava/lang/Object;
    invoke-interface {v6, v7, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 481
    nop

    .end local v3    # "answer\\1":Ljava/lang/Object;
    goto :goto_178

    .line 483
    .end local v27    # "gk":Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    .end local v28    # "groups":Ljava/util/LinkedHashMap;
    .local v3, "gk":Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    .restart local v9    # "groups":Ljava/util/LinkedHashMap;
    :cond_172
    move-object/from16 v27, v3

    move-object/from16 v28, v9

    .end local v3    # "gk":Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    .end local v9    # "groups":Ljava/util/LinkedHashMap;
    .restart local v27    # "gk":Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    .restart local v28    # "groups":Ljava/util/LinkedHashMap;
    move-object/from16 v3, v25

    .line 478
    :goto_178
    nop

    .line 298
    .end local v6    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v7    # "key\\1":Ljava/lang/Object;
    .end local v24    # "$i$f$getOrPut\\1\\298":I
    .end local v25    # "value\\1":Ljava/lang/Object;
    check-cast v3, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;

    .line 299
    .local v3, "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getSpecs()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getVerts()I

    move-result v6

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getMesh()[F

    move-result-object v7

    array-length v7, v7

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getStride()I

    move-result v9

    div-int/2addr v7, v9

    add-int/2addr v6, v7

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->setVerts(I)V

    move/from16 v10, p2

    move-object/from16 v3, v21

    move-object/from16 v6, v22

    move-object/from16 v7, v23

    move-object/from16 v9, v28

    .end local v3    # "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    .end local v4    # "s":Lcom/exampletest/mobilestudiotest/render/BatchSpec;
    .end local v27    # "gk":Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    goto :goto_127

    .line 295
    .end local v22    # "rec":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    .end local v23    # "pc":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v28    # "groups":Ljava/util/LinkedHashMap;
    .local v6, "rec":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    .local v7, "pc":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .restart local v9    # "groups":Ljava/util/LinkedHashMap;
    :cond_19f
    move-object/from16 v22, v6

    move-object/from16 v23, v7

    move-object/from16 v28, v9

    .end local v6    # "rec":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    .end local v7    # "pc":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v9    # "groups":Ljava/util/LinkedHashMap;
    .restart local v22    # "rec":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    .restart local v23    # "pc":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .restart local v28    # "groups":Ljava/util/LinkedHashMap;
    move/from16 v10, p2

    move-object/from16 v3, v19

    move-object/from16 v4, v20

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto/16 :goto_a3

    .line 302
    .end local v0    # "tier":I
    .end local v14    # "pr":F
    .end local v15    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v16    # "list":Ljava/util/List;
    .end local v19    # "keep":Ljava/util/ArrayList;
    .end local v20    # "once":Ljava/util/Set;
    .end local v22    # "rec":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    .end local v23    # "pc":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v28    # "groups":Ljava/util/LinkedHashMap;
    .local v3, "keep":Ljava/util/ArrayList;
    .local v4, "once":Ljava/util/Set;
    .restart local v9    # "groups":Ljava/util/LinkedHashMap;
    :cond_1af
    move-object/from16 v19, v3

    move-object/from16 v20, v4

    move-object/from16 v28, v9

    .end local v3    # "keep":Ljava/util/ArrayList;
    .end local v4    # "once":Ljava/util/Set;
    .end local v9    # "groups":Ljava/util/LinkedHashMap;
    .restart local v19    # "keep":Ljava/util/ArrayList;
    .restart local v20    # "once":Ljava/util/Set;
    .restart local v28    # "groups":Ljava/util/LinkedHashMap;
    invoke-virtual {v2, v11}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setParts(Ljava/util/ArrayList;)V

    .line 303
    new-instance v0, Ljava/util/ArrayList;

    invoke-virtual/range {v28 .. v28}, Ljava/util/LinkedHashMap;->size()I

    move-result v3

    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 304
    .local v0, "out":Ljava/util/ArrayList;
    invoke-virtual/range {v28 .. v28}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1c9
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2d6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;

    .line 305
    .local v4, "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getVerts()I

    move-result v7

    if-eqz v7, :cond_2d0

    .line 306
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getVerts()I

    move-result v7

    const/16 v9, 0xa

    mul-int/2addr v7, v9

    .line 307
    .local v7, "ints":I
    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->scratch:[I

    array-length v10, v10

    if-ge v10, v7, :cond_1f7

    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->scratch:[I

    array-length v10, v10

    mul-int/lit8 v10, v10, 0x2

    invoke-static {v7, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    new-array v10, v10, [I

    iput-object v10, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->scratch:[I

    .line 308
    :cond_1f7
    const/4 v10, 0x0

    .line 309
    .local v10, "o":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getSpecs()Ljava/util/ArrayList;

    move-result-object v12

    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v12

    invoke-static {v12, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_203
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    const/4 v15, 0x3

    if-eqz v14, :cond_22a

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    invoke-static {v14, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v14, Lcom/exampletest/mobilestudiotest/render/BatchSpec;

    .local v14, "s":Lcom/exampletest/mobilestudiotest/render/BatchSpec;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getKind()I

    move-result v9

    if-ne v9, v15, :cond_220

    iget-object v9, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->scratch:[I

    invoke-direct {v1, v14, v9, v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->packMesh(Lcom/exampletest/mobilestudiotest/render/BatchSpec;[II)I

    move-result v9

    goto :goto_226

    :cond_220
    iget-object v9, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->scratch:[I

    invoke-direct {v1, v14, v9, v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->pack(Lcom/exampletest/mobilestudiotest/render/BatchSpec;[II)I

    move-result v9

    :goto_226
    move v10, v9

    const/16 v9, 0xa

    .end local v14    # "s":Lcom/exampletest/mobilestudiotest/render/BatchSpec;
    goto :goto_203

    .line 310
    :cond_22a
    mul-int/lit8 v9, v10, 0x4

    .line 311
    .local v9, "bytes":I
    iget-object v12, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->direct:Ljava/nio/ByteBuffer;

    if-eqz v12, :cond_23c

    iget-object v12, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->direct:Ljava/nio/ByteBuffer;

    invoke-static {v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v12}, Ljava/nio/ByteBuffer;->capacity()I

    move-result v12

    if-lt v12, v9, :cond_23c

    goto :goto_25a

    :cond_23c
    iget-object v12, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->direct:Ljava/nio/ByteBuffer;

    if-eqz v12, :cond_245

    invoke-virtual {v12}, Ljava/nio/ByteBuffer;->capacity()I

    move-result v12

    goto :goto_246

    :cond_245
    const/4 v12, 0x0

    :goto_246
    mul-int/lit8 v12, v12, 0x2

    invoke-static {v9, v12}, Ljava/lang/Math;->max(II)I

    move-result v12

    invoke-static {v12}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v12

    invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v12

    iput-object v12, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->direct:Ljava/nio/ByteBuffer;

    .line 312
    :goto_25a
    iget-object v12, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->direct:Ljava/nio/ByteBuffer;

    invoke-static {v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 313
    .local v12, "bb":Ljava/nio/ByteBuffer;
    invoke-virtual {v12}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    .line 314
    invoke-virtual {v12}, Ljava/nio/ByteBuffer;->asIntBuffer()Ljava/nio/IntBuffer;

    move-result-object v14

    const-string v15, "asIntBuffer(...)"

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 315
    .local v14, "ib":Ljava/nio/IntBuffer;
    iget-object v15, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->scratch:[I

    const/4 v6, 0x0

    invoke-virtual {v14, v15, v6, v10}, Ljava/nio/IntBuffer;->put([III)Ljava/nio/IntBuffer;

    .line 316
    invoke-virtual {v12, v6}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    invoke-virtual {v12, v9}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    .line 317
    move-object/from16 v29, v3

    const/4 v15, 0x1

    new-array v3, v15, [I

    .line 318
    .local v3, "ids":[I
    invoke-static {v15, v3, v6}, Landroid/opengl/GLES20;->glGenBuffers(I[II)V

    .line 319
    aget v15, v3, v6

    move/from16 v17, v6

    const v6, 0x8892

    invoke-static {v6, v15}, Landroid/opengl/GLES20;->glBindBuffer(II)V

    .line 320
    move-object v15, v12

    check-cast v15, Ljava/nio/Buffer;

    move-object/from16 v30, v3

    .end local v3    # "ids":[I
    .local v30, "ids":[I
    const v3, 0x88e4

    invoke-static {v6, v9, v15, v3}, Landroid/opengl/GLES20;->glBufferData(IILjava/nio/Buffer;I)V

    .line 321
    const/4 v3, 0x3

    new-instance v21, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;

    aget v22, v30, v17

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getKind()I

    move-result v6

    if-ne v6, v3, :cond_2a3

    const/4 v3, 0x7

    move/from16 v18, v3

    goto :goto_2a5

    :cond_2a3
    const/16 v18, 0xa

    :goto_2a5
    div-int v23, v10, v18

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getTier()I

    move-result v24

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getKind()I

    move-result v25

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->getTex()Lcom/exampletest/mobilestudiotest/render/TexBind;

    move-result-object v26

    move/from16 v27, v9

    .end local v9    # "bytes":I
    .local v27, "bytes":I
    invoke-direct/range {v21 .. v27}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;-><init>(IIIILcom/exampletest/mobilestudiotest/render/TexBind;I)V

    move-object/from16 v6, v21

    move/from16 v3, v27

    .end local v27    # "bytes":I
    .local v3, "bytes":I
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 322
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBytes()J

    move-result-wide v21

    move-object v9, v4

    move-object v6, v5

    .end local v4    # "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    .local v9, "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    int-to-long v4, v3

    add-long v4, v21, v4

    invoke-virtual {v2, v4, v5}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setBytes(J)V

    move-object v5, v6

    move-object/from16 v3, v29

    .end local v3    # "bytes":I
    .end local v7    # "ints":I
    .end local v9    # "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    .end local v10    # "o":I
    .end local v12    # "bb":Ljava/nio/ByteBuffer;
    .end local v14    # "ib":Ljava/nio/IntBuffer;
    .end local v30    # "ids":[I
    goto/16 :goto_1c9

    .line 305
    .restart local v4    # "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    :cond_2d0
    move-object/from16 v29, v3

    move-object v9, v4

    move-object v6, v5

    .end local v4    # "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    .restart local v9    # "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    goto/16 :goto_1c9

    .line 324
    .end local v9    # "g":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
    :cond_2d6
    const v6, 0x8892

    const/4 v14, 0x0

    invoke-static {v6, v14}, Landroid/opengl/GLES20;->glBindBuffer(II)V

    .line 325
    iget-wide v3, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->totalBytes:J

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBytes()J

    move-result-wide v5

    add-long/2addr v3, v5

    iput-wide v3, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->totalBytes:J

    .line 326
    move-object v3, v0

    check-cast v3, Ljava/util/List;

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setBatches(Ljava/util/List;)V

    .line 327
    const/4 v14, 0x1

    invoke-virtual {v2, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setBuilt(Z)V

    .line 328
    const/4 v14, 0x0

    invoke-virtual {v2, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setDirty(Z)V

    .line 329
    move/from16 v3, p3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setTexEpoch(I)V

    .line 330
    invoke-virtual {v2, v13}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setPendingTex(Z)V

    .line 331
    invoke-virtual/range {p1 .. p2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setLastInRange(I)V

    .line 332
    return-void
.end method

.method private final free(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V
    .registers 8
    .param p1, "c"    # Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .line 257
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBatches()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_31

    .line 258
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBatches()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    new-array v2, v0, [I

    move v3, v1

    :goto_18
    if-ge v3, v0, :cond_2d

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBatches()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->getVbo()I

    move-result v4

    aput v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_18

    .line 259
    .local v2, "ids":[I
    :cond_2d
    array-length v0, v2

    invoke-static {v0, v2, v1}, Landroid/opengl/GLES20;->glDeleteBuffers(I[II)V

    .line 261
    .end local v2    # "ids":[I
    :cond_31
    iget-wide v2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->totalBytes:J

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBytes()J

    move-result-wide v4

    sub-long/2addr v2, v4

    iput-wide v2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->totalBytes:J

    .line 262
    const-wide/16 v2, 0x0

    invoke-virtual {p1, v2, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setBytes(J)V

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setBatches(Ljava/util/List;)V

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setBuilt(Z)V

    .line 263
    return-void
.end method

.method private final join(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;)V
    .registers 14
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "rec"    # Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    .line 246
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    .line 247
    .local v0, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    sget-object v1, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v1

    const/high16 v2, 0x3f000000    # 0.5f

    mul-float/2addr v1, v2

    .line 248
    .local v1, "r":F
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    check-cast v2, Ljava/util/Map;

    .local v2, "$this$getOrPut\\1":Ljava/util/Map;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getX()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getY()F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getZ()F

    move-result v5

    invoke-direct {p0, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->keyOf(FFF)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    .local v3, "key\\1":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 470
    .local v4, "$i$f$getOrPut\\1\\248":I
    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    .line 471
    .local v5, "value\\1":Ljava/lang/Object;
    if-nez v5, :cond_4e

    .line 472
    const/4 v6, 0x0

    .line 248
    .local v6, "$i$a$-getOrPut-StaticBatches$join$c$1\\2\\472\\0":I
    new-instance v7, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getX()F

    move-result v8

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getY()F

    move-result v9

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getZ()F

    move-result v10

    invoke-direct {p0, v8, v9, v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->keyOf(FFF)J

    move-result-wide v8

    invoke-direct {v7, v8, v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;-><init>(J)V

    .line 472
    .end local v6    # "$i$a$-getOrPut-StaticBatches$join$c$1\\2\\472\\0":I
    nop

    .line 473
    .local v7, "answer\\1":Ljava/lang/Object;
    invoke-interface {v2, v3, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 474
    nop

    .end local v7    # "answer\\1":Ljava/lang/Object;
    goto :goto_4f

    .line 476
    :cond_4e
    move-object v7, v5

    .line 471
    :goto_4f
    nop

    .line 248
    .end local v2    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v3    # "key\\1":Ljava/lang/Object;
    .end local v4    # "$i$f$getOrPut\\1\\248":I
    .end local v5    # "value\\1":Ljava/lang/Object;
    move-object v2, v7

    check-cast v2, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .line 249
    .local v2, "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getParts()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 250
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getX()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getY()F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getZ()F

    move-result v5

    invoke-virtual {v2, v3, v4, v5, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->grow(FFFF)V

    .line 251
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getMaxTier()I

    move-result v3

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->tierOf(F)I

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setMaxTier(I)V

    .line 252
    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setDirty(Z)V

    .line 253
    invoke-virtual {p2, v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setChunk(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V

    .line 254
    return-void
.end method

.method private final keyOf(FFF)J
    .registers 15
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 159
    const/high16 v0, 0x42800000    # 64.0f

    div-float v1, p1, v0

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-float v1, v1

    float-to-long v1, v1

    const-wide/32 v3, 0x1fffff

    and-long/2addr v1, v3

    .local v1, "ix":J
    div-float v5, p2, v0

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-float v5, v5

    float-to-long v5, v5

    and-long/2addr v5, v3

    .local v5, "iy":J
    div-float v0, p3, v0

    float-to-double v7, v0

    invoke-static {v7, v8}, Ljava/lang/Math;->floor(D)D

    move-result-wide v7

    double-to-float v0, v7

    float-to-long v7, v0

    and-long/2addr v7, v3

    .line 160
    .local v7, "iz":J
    const/16 v0, 0x2a

    shl-long v3, v1, v0

    const/16 v0, 0x15

    shl-long v9, v5, v0

    or-long/2addr v3, v9

    or-long/2addr v3, v7

    return-wide v3
.end method

.method private final pack(Lcom/exampletest/mobilestudiotest/render/BatchSpec;[II)I
    .registers 68
    .param p1, "s"    # Lcom/exampletest/mobilestudiotest/render/BatchSpec;
    .param p2, "out"    # [I
    .param p3, "start"    # I

    .line 353
    move-object/from16 v0, p0

    move/from16 v1, p3

    .line 354
    .local v1, "o":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    .local v2, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getScale()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    .local v3, "sx":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getScale()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    .local v4, "sy":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getScale()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    .line 355
    .local v5, "sz":F
    const/4 v6, 0x0

    cmpg-float v7, v3, v6

    const/4 v9, 0x0

    if-nez v7, :cond_28

    const/4 v7, 0x1

    goto :goto_29

    :cond_28
    move v7, v9

    :goto_29
    const/high16 v10, 0x3f800000    # 1.0f

    if-nez v7, :cond_30

    div-float v7, v10, v3

    goto :goto_31

    :cond_30
    move v7, v6

    .local v7, "ix":F
    :goto_31
    cmpg-float v11, v4, v6

    if-nez v11, :cond_37

    const/4 v11, 0x1

    goto :goto_38

    :cond_37
    move v11, v9

    :goto_38
    if-nez v11, :cond_3d

    div-float v11, v10, v4

    goto :goto_3e

    :cond_3d
    move v11, v6

    .local v11, "iy":F
    :goto_3e
    cmpg-float v12, v5, v6

    if-nez v12, :cond_44

    const/4 v12, 0x1

    goto :goto_45

    :cond_44
    move v12, v9

    :goto_45
    if-nez v12, :cond_4a

    div-float v12, v10, v5

    goto :goto_4b

    :cond_4a
    move v12, v6

    .line 356
    .local v12, "iz":F
    :goto_4b
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getR()F

    move-result v13

    invoke-direct {v0, v13}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->ub(F)I

    move-result v13

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getG()F

    move-result v14

    invoke-direct {v0, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->ub(F)I

    move-result v14

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getB()F

    move-result v15

    invoke-direct {v0, v15}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->ub(F)I

    move-result v15

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getEmissive()Z

    move-result v16

    move/from16 v17, v6

    const/16 v6, 0xff

    if-eqz v16, :cond_6f

    move v8, v6

    goto :goto_70

    :cond_6f
    move v8, v9

    :goto_70
    const/16 v16, 0x1

    invoke-direct {v0, v13, v14, v15, v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->b4(IIII)I

    move-result v8

    .line 357
    .local v8, "col":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getMat()[F

    move-result-object v13

    .line 358
    .local v13, "m":[F
    aget v14, v13, v9

    float-to-int v14, v14

    invoke-static {v14, v9, v6}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v14

    aget v15, v13, v16

    const/high16 v18, 0x447a0000    # 1000.0f

    mul-float v15, v15, v18

    const/high16 v18, 0x3f000000    # 0.5f

    add-float v15, v15, v18

    float-to-int v15, v15

    invoke-static {v15, v9, v6}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v15

    const/16 v19, 0x2

    aget v19, v13, v19

    const/high16 v20, 0x42480000    # 50.0f

    mul-float v19, v19, v20

    add-float v10, v19, v18

    float-to-int v10, v10

    invoke-static {v10, v9, v6}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v10

    const/4 v6, 0x3

    aget v21, v13, v6

    const/high16 v22, 0x42f00000    # 120.0f

    mul-float v21, v21, v22

    move/from16 v22, v6

    add-float v6, v21, v18

    float-to-int v6, v6

    move/from16 v21, v1

    const/16 v1, 0xff

    .end local v1    # "o":I
    .local v21, "o":I
    invoke-static {v6, v9, v1}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v1

    invoke-direct {v0, v14, v15, v10, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->b4(IIII)I

    move-result v1

    .line 359
    .local v1, "matI":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getMesh()[F

    move-result-object v6

    .line 360
    .local v6, "mesh":[F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getStride()I

    move-result v10

    .line 361
    .local v10, "st":I
    array-length v14, v6

    mul-int/lit8 v15, v10, 0x3

    div-int/2addr v14, v15

    .line 362
    .local v14, "tris":I
    const/4 v15, 0x0

    .local v15, "t":I
    :goto_c4
    if-ge v15, v14, :cond_3f9

    .line 363
    mul-int/lit8 v19, v15, 0x3

    mul-int v19, v19, v10

    .line 365
    .local v19, "base":I
    add-int/lit8 v23, v19, 0x3

    aget v23, v6, v23

    add-int v24, v19, v10

    add-int/lit8 v24, v24, 0x3

    aget v24, v6, v24

    add-float v23, v23, v24

    mul-int/lit8 v24, v10, 0x2

    add-int v24, v19, v24

    add-int/lit8 v24, v24, 0x3

    aget v24, v6, v24

    add-float v23, v23, v24

    invoke-static/range {v23 .. v23}, Ljava/lang/Math;->abs(F)F

    move-result v23

    .line 366
    .local v23, "anx":F
    add-int/lit8 v24, v19, 0x4

    aget v24, v6, v24

    add-int v25, v19, v10

    add-int/lit8 v25, v25, 0x4

    aget v25, v6, v25

    add-float v24, v24, v25

    mul-int/lit8 v25, v10, 0x2

    add-int v25, v19, v25

    add-int/lit8 v25, v25, 0x4

    aget v25, v6, v25

    add-float v24, v24, v25

    invoke-static/range {v24 .. v24}, Ljava/lang/Math;->abs(F)F

    move-result v24

    .line 367
    .local v24, "any":F
    add-int/lit8 v25, v19, 0x5

    aget v25, v6, v25

    add-int v26, v19, v10

    add-int/lit8 v26, v26, 0x5

    aget v26, v6, v26

    add-float v25, v25, v26

    mul-int/lit8 v26, v10, 0x2

    add-int v26, v19, v26

    add-int/lit8 v26, v26, 0x5

    aget v26, v6, v26

    add-float v25, v25, v26

    invoke-static/range {v25 .. v25}, Ljava/lang/Math;->abs(F)F

    move-result v25

    .line 368
    .local v25, "anz":F
    cmpl-float v26, v24, v23

    if-lez v26, :cond_123

    cmpl-float v26, v24, v25

    if-lez v26, :cond_123

    move/from16 v26, v16

    goto :goto_125

    :cond_123
    move/from16 v26, v9

    .line 369
    .local v26, "yF":Z
    :goto_125
    if-nez v26, :cond_12e

    cmpl-float v27, v23, v25

    if-lez v27, :cond_12e

    move/from16 v27, v16

    goto :goto_130

    :cond_12e
    move/from16 v27, v9

    .line 371
    .local v27, "xF":Z
    :goto_130
    if-nez v26, :cond_137

    if-eqz v27, :cond_137

    move/from16 v28, v17

    goto :goto_139

    :cond_137
    const/high16 v28, 0x3f800000    # 1.0f

    .local v28, "tlx":F
    :goto_139
    if-nez v26, :cond_140

    if-eqz v27, :cond_140

    const/high16 v29, 0x3f800000    # 1.0f

    goto :goto_142

    :cond_140
    move/from16 v29, v17

    .line 372
    .local v29, "tlz":F
    :goto_142
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR00()F

    move-result v30

    mul-float v30, v30, v28

    mul-float v30, v30, v3

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR02()F

    move-result v31

    mul-float v31, v31, v29

    mul-float v31, v31, v5

    add-float v30, v30, v31

    .local v30, "tx":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR10()F

    move-result v31

    mul-float v31, v31, v28

    mul-float v31, v31, v3

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR12()F

    move-result v32

    mul-float v32, v32, v29

    mul-float v32, v32, v5

    add-float v31, v31, v32

    .local v31, "ty":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR20()F

    move-result v32

    mul-float v32, v32, v28

    mul-float v32, v32, v3

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR22()F

    move-result v33

    mul-float v33, v33, v29

    mul-float v33, v33, v5

    add-float v32, v32, v33

    .line 373
    .local v32, "tz":F
    mul-float v33, v30, v30

    mul-float v34, v31, v31

    add-float v33, v33, v34

    mul-float v34, v32, v32

    add-float v9, v33, v34

    move/from16 v34, v1

    move-object/from16 v33, v2

    .end local v1    # "matI":I
    .end local v2    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v33, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v34, "matI":I
    float-to-double v1, v9

    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v1

    double-to-float v1, v1

    const v2, 0x3089705f    # 1.0E-9f

    invoke-static {v1, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v1

    .local v1, "tl":F
    div-float v9, v30, v1

    .end local v30    # "tx":F
    .local v9, "tx":F
    div-float v2, v31, v1

    move/from16 v31, v1

    .end local v1    # "tl":F
    .local v2, "ty":F
    .local v31, "tl":F
    div-float v1, v32, v31

    .line 374
    .end local v32    # "tz":F
    .local v1, "tz":F
    const/16 v32, 0x0

    .local v32, "bx":F
    const/16 v36, 0x0

    .local v36, "by":F
    const/16 v37, 0x0

    .line 375
    .local v37, "bz":F
    if-eqz v26, :cond_1b0

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR02()F

    move-result v32

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR12()F

    move-result v36

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR22()F

    move-result v37

    goto :goto_1bc

    :cond_1b0
    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR01()F

    move-result v32

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR11()F

    move-result v36

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR21()F

    move-result v37

    .line 376
    :goto_1bc
    mul-float v38, v32, v32

    mul-float v39, v36, v36

    add-float v38, v38, v39

    mul-float v39, v37, v37

    move/from16 v40, v3

    .end local v3    # "sx":F
    .local v40, "sx":F
    add-float v3, v38, v39

    move/from16 v38, v4

    .end local v4    # "sy":F
    .local v38, "sy":F
    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v3

    double-to-float v3, v3

    const v4, 0x3089705f    # 1.0E-9f

    invoke-static {v3, v4}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v3

    .end local v31    # "tl":F
    .local v3, "tl":F
    div-float v4, v32, v3

    move/from16 v31, v3

    .end local v3    # "tl":F
    .end local v32    # "bx":F
    .local v4, "bx":F
    .restart local v31    # "tl":F
    div-float v3, v36, v31

    move/from16 v32, v5

    .end local v5    # "sz":F
    .end local v36    # "by":F
    .local v3, "by":F
    .local v32, "sz":F
    div-float v5, v37, v31

    .line 377
    .end local v37    # "bz":F
    .local v5, "bz":F
    move-object/from16 v36, v6

    .end local v6    # "mesh":[F
    .local v36, "mesh":[F
    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v6

    move/from16 v37, v7

    .end local v7    # "ix":F
    .local v37, "ix":F
    invoke-direct {v0, v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v7

    move/from16 v39, v2

    .end local v2    # "ty":F
    .local v39, "ty":F
    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v2

    move/from16 v41, v1

    const/4 v1, 0x0

    .end local v1    # "tz":F
    .local v41, "tz":F
    invoke-direct {v0, v6, v7, v2, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->b4(IIII)I

    move-result v2

    .line 378
    .local v2, "tanI":I
    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v6

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v7

    move/from16 v42, v2

    .end local v2    # "tanI":I
    .local v42, "tanI":I
    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v2

    invoke-direct {v0, v6, v7, v2, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->b4(IIII)I

    move-result v2

    .line 380
    .local v2, "bitI":I
    const/4 v1, 0x0

    .line 381
    .local v1, "surf":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getCube()Z

    move-result v6

    if-eqz v6, :cond_279

    .line 382
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getSurfA()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    .local v6, "a":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getSurfB()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    .line 383
    .local v7, "bb":Lcom/exampletest/mobilestudiotest/model/Vector3;
    if-eqz v26, :cond_222

    add-int/lit8 v43, v19, 0x4

    aget v43, v36, v43

    goto :goto_22d

    :cond_222
    if-eqz v27, :cond_229

    add-int/lit8 v43, v19, 0x3

    aget v43, v36, v43

    goto :goto_22d

    :cond_229
    add-int/lit8 v43, v19, 0x5

    aget v43, v36, v43

    .line 384
    .local v43, "ln":F
    :goto_22d
    if-eqz v6, :cond_271

    if-eqz v7, :cond_271

    .line 385
    if-eqz v26, :cond_241

    cmpl-float v44, v43, v17

    if-lez v44, :cond_23c

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v44

    goto :goto_25c

    :cond_23c
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v44

    goto :goto_25c

    :cond_241
    cmpl-float v44, v43, v17

    if-eqz v27, :cond_251

    if-lez v44, :cond_24c

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v44

    goto :goto_25c

    :cond_24c
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v44

    goto :goto_25c

    :cond_251
    if-lez v44, :cond_258

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v44

    goto :goto_25c

    :cond_258
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v44

    :goto_25c
    move/from16 v45, v44

    .line 386
    .local v45, "v":F
    move/from16 v44, v1

    move/from16 v1, v45

    move/from16 v45, v2

    .end local v2    # "bitI":I
    .local v1, "v":F
    .local v44, "surf":I
    .local v45, "bitI":I
    float-to-int v2, v1

    move/from16 v46, v1

    .end local v1    # "v":F
    .local v46, "v":F
    const/16 v1, 0x7f

    move/from16 v47, v3

    const/4 v3, 0x0

    .end local v3    # "by":F
    .local v47, "by":F
    invoke-static {v2, v3, v1}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v1

    .end local v44    # "surf":I
    .local v1, "surf":I
    goto :goto_282

    .line 384
    .end local v45    # "bitI":I
    .end local v46    # "v":F
    .end local v47    # "by":F
    .restart local v2    # "bitI":I
    .restart local v3    # "by":F
    :cond_271
    move/from16 v44, v1

    move/from16 v45, v2

    move/from16 v47, v3

    const/4 v3, 0x0

    .end local v1    # "surf":I
    .end local v2    # "bitI":I
    .end local v3    # "by":F
    .restart local v44    # "surf":I
    .restart local v45    # "bitI":I
    .restart local v47    # "by":F
    goto :goto_280

    .line 381
    .end local v6    # "a":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v7    # "bb":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v43    # "ln":F
    .end local v44    # "surf":I
    .end local v45    # "bitI":I
    .end local v47    # "by":F
    .restart local v1    # "surf":I
    .restart local v2    # "bitI":I
    .restart local v3    # "by":F
    :cond_279
    move/from16 v44, v1

    move/from16 v45, v2

    move/from16 v47, v3

    const/4 v3, 0x0

    .line 389
    .end local v1    # "surf":I
    .end local v2    # "bitI":I
    .end local v3    # "by":F
    .restart local v44    # "surf":I
    .restart local v45    # "bitI":I
    .restart local v47    # "by":F
    :goto_280
    move/from16 v1, v44

    .end local v44    # "surf":I
    .restart local v1    # "surf":I
    :goto_282
    const/4 v2, 0x0

    .local v2, "v":I
    :goto_283
    move/from16 v6, v22

    if-ge v2, v6, :cond_3de

    .line 390
    mul-int v7, v2, v10

    add-int v7, v19, v7

    .line 391
    .local v7, "k":I
    aget v22, v36, v7

    .local v22, "lx":F
    add-int/lit8 v35, v7, 0x1

    aget v35, v36, v35

    .local v35, "ly":F
    add-int/lit8 v43, v7, 0x2

    aget v43, v36, v43

    .line 392
    .local v43, "lz":F
    mul-float v44, v22, v40

    .local v44, "px":F
    mul-float v46, v35, v38

    .local v46, "py":F
    mul-float v48, v43, v32

    .line 393
    .local v48, "pz":F
    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR00()F

    move-result v49

    mul-float v49, v49, v44

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR01()F

    move-result v50

    mul-float v50, v50, v46

    add-float v49, v49, v50

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR02()F

    move-result v50

    mul-float v50, v50, v48

    add-float v49, v49, v50

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getX()F

    move-result v50

    add-float v49, v49, v50

    invoke-static/range {v49 .. v49}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v49

    aput v49, p2, v21

    .line 394
    add-int/lit8 v49, v21, 0x1

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR10()F

    move-result v50

    mul-float v50, v50, v44

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR11()F

    move-result v51

    mul-float v51, v51, v46

    add-float v50, v50, v51

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR12()F

    move-result v51

    mul-float v51, v51, v48

    add-float v50, v50, v51

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getY()F

    move-result v51

    add-float v50, v50, v51

    invoke-static/range {v50 .. v50}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v50

    aput v50, p2, v49

    .line 395
    add-int/lit8 v49, v21, 0x2

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR20()F

    move-result v50

    mul-float v50, v50, v44

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR21()F

    move-result v51

    mul-float v51, v51, v46

    add-float v50, v50, v51

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR22()F

    move-result v51

    mul-float v51, v51, v48

    add-float v50, v50, v51

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getZ()F

    move-result v51

    add-float v50, v50, v51

    invoke-static/range {v50 .. v50}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v50

    aput v50, p2, v49

    .line 396
    mul-float v49, v40, v18

    add-float v49, v44, v49

    .local v49, "ux":F
    mul-float v50, v38, v18

    add-float v50, v46, v50

    .local v50, "uy":F
    mul-float v51, v32, v18

    add-float v51, v48, v51

    .line 397
    .local v51, "uz":F
    if-nez v26, :cond_318

    if-eqz v27, :cond_318

    move/from16 v52, v51

    goto :goto_31a

    :cond_318
    move/from16 v52, v49

    .line 398
    .local v52, "u":F
    :goto_31a
    if-eqz v26, :cond_31f

    move/from16 v53, v51

    goto :goto_321

    :cond_31f
    move/from16 v53, v50

    .line 399
    .local v53, "w":F
    :goto_321
    add-int/lit8 v54, v21, 0x3

    invoke-static/range {v52 .. v52}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v55

    aput v55, p2, v54

    .line 400
    add-int/lit8 v54, v21, 0x4

    invoke-static/range {v53 .. v53}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v55

    aput v55, p2, v54

    .line 401
    add-int/lit8 v54, v7, 0x3

    aget v54, v36, v54

    mul-float v54, v54, v37

    .local v54, "nx0":F
    add-int/lit8 v55, v7, 0x4

    aget v55, v36, v55

    mul-float v55, v55, v11

    .local v55, "ny0":F
    add-int/lit8 v56, v7, 0x5

    aget v56, v36, v56

    mul-float v56, v56, v12

    .line 402
    .local v56, "nz0":F
    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR00()F

    move-result v57

    mul-float v57, v57, v54

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR01()F

    move-result v58

    mul-float v58, v58, v55

    add-float v57, v57, v58

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR02()F

    move-result v58

    mul-float v58, v58, v56

    add-float v57, v57, v58

    .line 403
    .local v57, "nx":F
    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR10()F

    move-result v58

    mul-float v58, v58, v54

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR11()F

    move-result v59

    mul-float v59, v59, v55

    add-float v58, v58, v59

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR12()F

    move-result v59

    mul-float v59, v59, v56

    add-float v58, v58, v59

    .line 404
    .local v58, "ny":F
    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR20()F

    move-result v59

    mul-float v59, v59, v54

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR21()F

    move-result v60

    mul-float v60, v60, v55

    add-float v59, v59, v60

    invoke-virtual/range {v33 .. v33}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR22()F

    move-result v60

    mul-float v60, v60, v56

    add-float v59, v59, v60

    .line 405
    .local v59, "nz":F
    mul-float v60, v57, v57

    mul-float v61, v58, v58

    add-float v60, v60, v61

    mul-float v61, v59, v59

    add-float v3, v60, v61

    move/from16 v61, v7

    .end local v7    # "k":I
    .local v61, "k":I
    float-to-double v6, v3

    invoke-static {v6, v7}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v6

    double-to-float v3, v6

    const v6, 0x3089705f    # 1.0E-9f

    invoke-static {v3, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v3

    .local v3, "nl":F
    div-float v7, v57, v3

    .end local v57    # "nx":F
    .local v7, "nx":F
    div-float v6, v58, v3

    move/from16 v57, v2

    .end local v2    # "v":I
    .end local v58    # "ny":F
    .local v6, "ny":F
    .local v57, "v":I
    div-float v2, v59, v3

    .line 406
    .end local v59    # "nz":F
    .local v2, "nz":F
    add-int/lit8 v58, v21, 0x5

    move/from16 v59, v3

    .end local v3    # "nl":F
    .local v59, "nl":F
    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v3

    move/from16 v62, v4

    .end local v4    # "bx":F
    .local v62, "bx":F
    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v4

    move/from16 v63, v5

    .end local v5    # "bz":F
    .local v63, "bz":F
    invoke-direct {v0, v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v5

    invoke-direct {v0, v3, v4, v5, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->b4(IIII)I

    move-result v3

    aput v3, p2, v58

    .line 407
    add-int/lit8 v3, v21, 0x6

    aput v8, p2, v3

    .line 408
    add-int/lit8 v3, v21, 0x7

    aput v34, p2, v3

    .line 409
    add-int/lit8 v3, v21, 0x8

    aput v42, p2, v3

    .line 410
    add-int/lit8 v3, v21, 0x9

    aput v45, p2, v3

    .line 411
    nop

    .end local v2    # "nz":F
    .end local v6    # "ny":F
    .end local v7    # "nx":F
    .end local v22    # "lx":F
    .end local v35    # "ly":F
    .end local v43    # "lz":F
    .end local v44    # "px":F
    .end local v46    # "py":F
    .end local v48    # "pz":F
    .end local v49    # "ux":F
    .end local v50    # "uy":F
    .end local v51    # "uz":F
    .end local v52    # "u":F
    .end local v53    # "w":F
    .end local v54    # "nx0":F
    .end local v55    # "ny0":F
    .end local v56    # "nz0":F
    .end local v59    # "nl":F
    .end local v61    # "k":I
    add-int/lit8 v21, v21, 0xa

    .line 389
    add-int/lit8 v2, v57, 0x1

    move/from16 v4, v62

    move/from16 v5, v63

    const/4 v3, 0x0

    const/16 v22, 0x3

    .end local v57    # "v":I
    .local v2, "v":I
    goto/16 :goto_283

    .end local v62    # "bx":F
    .end local v63    # "bz":F
    .restart local v4    # "bx":F
    .restart local v5    # "bz":F
    :cond_3de
    move/from16 v57, v2

    move/from16 v62, v4

    move/from16 v63, v5

    .line 362
    .end local v1    # "surf":I
    .end local v2    # "v":I
    .end local v4    # "bx":F
    .end local v5    # "bz":F
    .end local v9    # "tx":F
    .end local v19    # "base":I
    .end local v23    # "anx":F
    .end local v24    # "any":F
    .end local v25    # "anz":F
    .end local v26    # "yF":Z
    .end local v27    # "xF":Z
    .end local v28    # "tlx":F
    .end local v29    # "tlz":F
    .end local v31    # "tl":F
    .end local v39    # "ty":F
    .end local v41    # "tz":F
    .end local v42    # "tanI":I
    .end local v45    # "bitI":I
    .end local v47    # "by":F
    add-int/lit8 v15, v15, 0x1

    move/from16 v5, v32

    move-object/from16 v2, v33

    move/from16 v1, v34

    move-object/from16 v6, v36

    move/from16 v7, v37

    move/from16 v4, v38

    move/from16 v3, v40

    const/4 v9, 0x0

    const/16 v22, 0x3

    goto/16 :goto_c4

    .line 414
    .end local v15    # "t":I
    .end local v32    # "sz":F
    .end local v33    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v34    # "matI":I
    .end local v36    # "mesh":[F
    .end local v37    # "ix":F
    .end local v38    # "sy":F
    .end local v40    # "sx":F
    .local v1, "matI":I
    .local v2, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v3, "sx":F
    .local v4, "sy":F
    .local v5, "sz":F
    .local v6, "mesh":[F
    .local v7, "ix":F
    :cond_3f9
    return v21
.end method

.method private final packMesh(Lcom/exampletest/mobilestudiotest/render/BatchSpec;[II)I
    .registers 35
    .param p1, "s"    # Lcom/exampletest/mobilestudiotest/render/BatchSpec;
    .param p2, "out"    # [I
    .param p3, "start"    # I

    .line 423
    move-object/from16 v0, p0

    move/from16 v1, p3

    .line 424
    .local v1, "o":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    .local v2, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getScale()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    .local v3, "sx":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getScale()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    .local v4, "sy":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getScale()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    .line 425
    .local v5, "sz":F
    const/4 v6, 0x0

    cmpg-float v7, v3, v6

    const/4 v8, 0x1

    if-nez v7, :cond_28

    move v7, v8

    goto :goto_29

    :cond_28
    const/4 v7, 0x0

    :goto_29
    const/high16 v10, 0x3f800000    # 1.0f

    if-nez v7, :cond_30

    div-float v7, v10, v3

    goto :goto_31

    :cond_30
    move v7, v6

    .local v7, "ix":F
    :goto_31
    cmpg-float v11, v4, v6

    if-nez v11, :cond_37

    move v11, v8

    goto :goto_38

    :cond_37
    const/4 v11, 0x0

    :goto_38
    if-nez v11, :cond_3d

    div-float v11, v10, v4

    goto :goto_3e

    :cond_3d
    move v11, v6

    .local v11, "iy":F
    :goto_3e
    cmpg-float v12, v5, v6

    if-eqz v12, :cond_43

    const/4 v8, 0x0

    :cond_43
    if-nez v8, :cond_47

    div-float/2addr v10, v5

    goto :goto_48

    :cond_47
    move v10, v6

    .line 426
    .local v10, "iz":F
    :goto_48
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getR()F

    move-result v8

    invoke-direct {v0, v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->ub(F)I

    move-result v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getG()F

    move-result v12

    invoke-direct {v0, v12}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->ub(F)I

    move-result v12

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getB()F

    move-result v13

    invoke-direct {v0, v13}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->ub(F)I

    move-result v13

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getEmissive()Z

    move-result v14

    if-eqz v14, :cond_69

    const/16 v14, 0xff

    goto :goto_6a

    :cond_69
    const/4 v14, 0x0

    :goto_6a
    invoke-direct {v0, v8, v12, v13, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->b4(IIII)I

    move-result v8

    .line 427
    .local v8, "col":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getMesh()[F

    move-result-object v12

    .local v12, "m":[F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getStride()I

    move-result v13

    .line 428
    .local v13, "st":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getOffset()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v14

    .local v14, "ox":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getOffset()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v15

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v15

    .local v15, "oy":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/render/BatchSpec;->getOffset()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v16

    .line 429
    .local v16, "oz":F
    const/16 v17, 0x0

    .line 430
    .local v17, "k":I
    :goto_90
    add-int v6, v17, v13

    array-length v9, v12

    if-gt v6, v9, :cond_1dc

    .line 431
    aget v6, v12, v17

    sub-float/2addr v6, v14

    mul-float/2addr v6, v3

    .local v6, "px":F
    add-int/lit8 v9, v17, 0x1

    aget v9, v12, v9

    sub-float/2addr v9, v15

    mul-float/2addr v9, v4

    .local v9, "py":F
    add-int/lit8 v18, v17, 0x2

    aget v18, v12, v18

    sub-float v18, v18, v16

    mul-float v18, v18, v5

    .line 432
    .local v18, "pz":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR00()F

    move-result v19

    mul-float v19, v19, v6

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR01()F

    move-result v20

    mul-float v20, v20, v9

    add-float v19, v19, v20

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR02()F

    move-result v20

    mul-float v20, v20, v18

    add-float v19, v19, v20

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getX()F

    move-result v20

    add-float v19, v19, v20

    invoke-static/range {v19 .. v19}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v19

    aput v19, p2, v1

    .line 433
    add-int/lit8 v19, v1, 0x1

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR10()F

    move-result v20

    mul-float v20, v20, v6

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR11()F

    move-result v21

    mul-float v21, v21, v9

    add-float v20, v20, v21

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR12()F

    move-result v21

    mul-float v21, v21, v18

    add-float v20, v20, v21

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getY()F

    move-result v21

    add-float v20, v20, v21

    invoke-static/range {v20 .. v20}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v20

    aput v20, p2, v19

    .line 434
    add-int/lit8 v19, v1, 0x2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR20()F

    move-result v20

    mul-float v20, v20, v6

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR21()F

    move-result v21

    mul-float v21, v21, v9

    add-float v20, v20, v21

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR22()F

    move-result v21

    mul-float v21, v21, v18

    add-float v20, v20, v21

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getZ()F

    move-result v21

    add-float v20, v20, v21

    invoke-static/range {v20 .. v20}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v20

    aput v20, p2, v19

    .line 435
    add-int/lit8 v19, v1, 0x3

    move/from16 v20, v1

    .end local v1    # "o":I
    .local v20, "o":I
    const/16 v1, 0x8

    if-lt v13, v1, :cond_11e

    add-int/lit8 v21, v17, 0x6

    aget v21, v12, v21

    goto :goto_120

    :cond_11e
    const/16 v21, 0x0

    :goto_120
    invoke-static/range {v21 .. v21}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v21

    aput v21, p2, v19

    .line 436
    add-int/lit8 v19, v20, 0x4

    if-lt v13, v1, :cond_12f

    add-int/lit8 v1, v17, 0x7

    aget v1, v12, v1

    goto :goto_130

    :cond_12f
    const/4 v1, 0x0

    :goto_130
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v1

    aput v1, p2, v19

    .line 437
    add-int/lit8 v1, v17, 0x3

    aget v1, v12, v1

    mul-float/2addr v1, v7

    .local v1, "nx0":F
    add-int/lit8 v19, v17, 0x4

    aget v19, v12, v19

    mul-float v19, v19, v11

    .local v19, "ny0":F
    add-int/lit8 v21, v17, 0x5

    aget v21, v12, v21

    mul-float v21, v21, v10

    .line 438
    .local v21, "nz0":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR00()F

    move-result v22

    mul-float v22, v22, v1

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR01()F

    move-result v23

    mul-float v23, v23, v19

    add-float v22, v22, v23

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR02()F

    move-result v23

    mul-float v23, v23, v21

    add-float v22, v22, v23

    .line 439
    .local v22, "nx":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR10()F

    move-result v23

    mul-float v23, v23, v1

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR11()F

    move-result v24

    mul-float v24, v24, v19

    add-float v23, v23, v24

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR12()F

    move-result v24

    mul-float v24, v24, v21

    add-float v23, v23, v24

    .line 440
    .local v23, "ny":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR20()F

    move-result v24

    mul-float v24, v24, v1

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR21()F

    move-result v25

    mul-float v25, v25, v19

    add-float v24, v24, v25

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR22()F

    move-result v25

    mul-float v25, v25, v21

    add-float v24, v24, v25

    .line 441
    .local v24, "nz":F
    mul-float v25, v22, v22

    mul-float v26, v23, v23

    add-float v25, v25, v26

    mul-float v26, v24, v24

    move/from16 v27, v1

    .end local v1    # "nx0":F
    .local v27, "nx0":F
    add-float v1, v25, v26

    move-object/from16 v25, v2

    .end local v2    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v25, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v1

    double-to-float v1, v1

    const v2, 0x3089705f    # 1.0E-9f

    invoke-static {v1, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v1

    .local v1, "nl":F
    div-float v2, v22, v1

    move/from16 v22, v1

    .end local v1    # "nl":F
    .local v2, "nx":F
    .local v22, "nl":F
    div-float v1, v23, v22

    move/from16 v23, v3

    .end local v3    # "sx":F
    .local v1, "ny":F
    .local v23, "sx":F
    div-float v3, v24, v22

    .line 442
    .end local v24    # "nz":F
    .local v3, "nz":F
    add-int/lit8 v24, v20, 0x5

    move/from16 v26, v4

    .end local v4    # "sy":F
    .local v26, "sy":F
    invoke-direct {v0, v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v4

    move/from16 v28, v2

    .end local v2    # "nx":F
    .local v28, "nx":F
    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v2

    move/from16 v29, v1

    .end local v1    # "ny":F
    .local v29, "ny":F
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->sb(F)I

    move-result v1

    move/from16 v30, v3

    const/4 v3, 0x0

    .end local v3    # "nz":F
    .local v30, "nz":F
    invoke-direct {v0, v4, v2, v1, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->b4(IIII)I

    move-result v1

    aput v1, p2, v24

    .line 443
    add-int/lit8 v1, v20, 0x6

    aput v8, p2, v1

    .line 444
    add-int/lit8 v1, v20, 0x7

    .line 445
    .end local v20    # "o":I
    .local v1, "o":I
    add-int v17, v17, v13

    move/from16 v3, v23

    move-object/from16 v2, v25

    move/from16 v4, v26

    const/4 v6, 0x0

    .end local v6    # "px":F
    .end local v9    # "py":F
    .end local v18    # "pz":F
    .end local v19    # "ny0":F
    .end local v21    # "nz0":F
    .end local v22    # "nl":F
    .end local v27    # "nx0":F
    .end local v28    # "nx":F
    .end local v29    # "ny":F
    .end local v30    # "nz":F
    goto/16 :goto_90

    .line 447
    .end local v23    # "sx":F
    .end local v25    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v26    # "sy":F
    .local v2, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v3, "sx":F
    .restart local v4    # "sy":F
    :cond_1dc
    move/from16 v20, v1

    .end local v1    # "o":I
    .restart local v20    # "o":I
    return v20
.end method

.method private final sb(F)I
    .registers 6
    .param p1, "v"    # F

    .line 344
    const/high16 v0, -0x40800000    # -1.0f

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {p1, v0, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    const/high16 v1, 0x42fe0000    # 127.0f

    mul-float/2addr v0, v1

    .line 463
    .local v0, "it\\1":F
    const/4 v1, 0x0

    .line 344
    .local v1, "$i$a$-let-StaticBatches$sb$1\\1\\344\\0":I
    const/4 v2, 0x0

    cmpl-float v2, v0, v2

    const/high16 v3, 0x3f000000    # 0.5f

    if-ltz v2, :cond_16

    add-float/2addr v3, v0

    float-to-int v2, v3

    goto :goto_19

    :cond_16
    sub-float v2, v0, v3

    float-to-int v2, v2

    .end local v0    # "it\\1":F
    .end local v1    # "$i$a$-let-StaticBatches$sb$1\\1\\344\\0":I
    :goto_19
    return v2
.end method

.method private final tierOf(F)I
    .registers 3
    .param p1, "r"    # F

    .line 151
    const v0, 0x3f99999a    # 1.2f

    cmpg-float v0, p1, v0

    if-gez v0, :cond_9

    const/4 v0, 0x0

    goto :goto_12

    :cond_9
    const/high16 v0, 0x40a00000    # 5.0f

    cmpg-float v0, p1, v0

    if-gez v0, :cond_11

    const/4 v0, 0x1

    goto :goto_12

    :cond_11
    const/4 v0, 0x2

    :goto_12
    return v0
.end method

.method private final ub(F)I
    .registers 4
    .param p1, "v"    # F

    .line 345
    const/4 v0, 0x0

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {p1, v0, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    const/high16 v1, 0x437f0000    # 255.0f

    mul-float/2addr v0, v1

    const/high16 v1, 0x3f000000    # 0.5f

    add-float/2addr v0, v1

    float-to-int v0, v0

    return v0
.end method


# virtual methods
.method public final getChunks()Ljava/util/HashMap;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/Long;",
            "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;",
            ">;"
        }
    .end annotation

    .line 132
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    return-object v0
.end method

.method public final getLoose()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 134
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->loose:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final getTotalBytes()J
    .registers 3

    .line 137
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->totalBytes:J

    return-wide v0
.end method

.method public final getVisible()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;",
            ">;"
        }
    .end annotation

    .line 136
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->visible:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final reset(Z)V
    .registers 5
    .param p1, "deleteBuffers"    # Z

    .line 144
    if-eqz p1, :cond_21

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_21

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const-string v2, "next(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .local v1, "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->free(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V

    .end local v1    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    goto :goto_c

    .line 145
    :cond_21
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->visible:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->loose:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 146
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->totalBytes:J

    .line 147
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->gen:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->gen:I

    .line 148
    return-void
.end method

.method public final tierRange(IF)F
    .registers 5
    .param p1, "tier"    # I
    .param p2, "detail"    # F

    .line 156
    packed-switch p1, :pswitch_data_18

    const v0, 0x7f7fffff    # Float.MAX_VALUE

    goto :goto_17

    :pswitch_7
    const/high16 v0, 0x40a00000    # 5.0f

    mul-float/2addr v0, p2

    const/high16 v1, 0x44610000    # 900.0f

    goto :goto_13

    :pswitch_d
    const v0, 0x3f99999a    # 1.2f

    mul-float/2addr v0, p2

    const/high16 v1, 0x43160000    # 150.0f

    :goto_13
    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    :goto_17
    return v0

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_d
        :pswitch_7
    .end packed-switch
.end method

.method public final update(Ljava/util/List;IILcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/render/Frustum;FLcom/exampletest/mobilestudiotest/model/Vector3;FJJ)V
    .registers 36
    .param p1, "parts"    # Ljava/util/List;
    .param p2, "listVersion"    # I
    .param p3, "frame"    # I
    .param p4, "cam"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p5, "fr"    # Lcom/exampletest/mobilestudiotest/render/Frustum;
    .param p6, "detail"    # F
    .param p7, "shadowAt"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p8, "shadowR"    # F
    .param p9, "budgetNs"    # J
    .param p11, "maxBytes"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;II",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/render/Frustum;",
            "F",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "FJJ)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move/from16 v1, p2

    move/from16 v2, p3

    move-object/from16 v3, p4

    const-string v4, "parts"

    move-object/from16 v5, p1

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "cam"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "fr"

    move-object/from16 v6, p5

    invoke-static {v6, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    iput v2, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->frame:I

    .line 171
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->loose:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->visible:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 172
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_2b
    :goto_2b
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x1

    if-eqz v7, :cond_bb

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 173
    .local v7, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .local v8, "rec":Ljava/lang/Object;
    iget-object v9, v7, Lcom/exampletest/mobilestudiotest/model/Instance;->renderRec:Ljava/lang/Object;

    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    if-eqz v10, :cond_44

    check-cast v9, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    goto :goto_45

    :cond_44
    move-object v9, v14

    .line 174
    .end local v8    # "rec":Ljava/lang/Object;
    .local v9, "rec":Ljava/lang/Object;
    :goto_45
    if-eqz v9, :cond_70

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getGen()I

    move-result v8

    iget v10, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->gen:I

    if-ne v8, v10, :cond_70

    .line 179
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getVer()I

    move-result v8

    iget v10, v7, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    if-eq v8, v10, :cond_84

    .line 180
    iget v8, v7, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    invoke-virtual {v9, v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setVer(I)V

    .line 181
    invoke-virtual {v9, v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setChangedFrame(I)V

    .line 182
    invoke-virtual {v9, v13}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setKnown(Z)V

    .line 183
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getChunk()Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    move-result-object v8

    if-eqz v8, :cond_84

    .line 463
    .local v8, "it\\1":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    const/4 v10, 0x0

    .line 183
    .local v10, "$i$a$-let-StaticBatches$update$1\\1\\183\\0":I
    invoke-virtual {v8, v15}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setDirty(Z)V

    invoke-virtual {v9, v14}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setChunk(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V

    .end local v8    # "it\\1":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v10    # "$i$a$-let-StaticBatches$update$1\\1\\183\\0":I
    goto :goto_84

    .line 175
    :cond_70
    new-instance v8, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    iget v10, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->gen:I

    invoke-direct {v8, v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;-><init>(I)V

    move-object v9, v8

    iput-object v9, v7, Lcom/exampletest/mobilestudiotest/model/Instance;->renderRec:Ljava/lang/Object;

    .line 176
    iget v8, v7, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    invoke-virtual {v9, v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setVer(I)V

    .line 178
    add-int/lit8 v8, v2, -0x2d

    invoke-virtual {v9, v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setChangedFrame(I)V

    .line 185
    :cond_84
    :goto_84
    invoke-virtual {v9, v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setSeen(I)V

    .line 186
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getChunk()Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    move-result-object v8

    if-nez v8, :cond_2b

    .line 187
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getChangedFrame()I

    move-result v8

    sub-int v8, v2, v8

    const/16 v10, 0x2d

    if-lt v8, v10, :cond_b4

    .line 188
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getKnown()Z

    move-result v8

    if-nez v8, :cond_a9

    invoke-virtual {v9, v15}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setKnown(Z)V

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->host:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;

    invoke-interface {v8, v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;->batchable(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v8

    invoke-virtual {v9, v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->setBatchable(Z)V

    .line 189
    :cond_a9
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getBatchable()Z

    move-result v8

    if-eqz v8, :cond_b4

    invoke-direct {v0, v7, v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->join(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;)V

    goto/16 :goto_2b

    .line 191
    :cond_b4
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->loose:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .end local v9    # "rec":Ljava/lang/Object;
    goto/16 :goto_2b

    .line 194
    .end local v7    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_bb
    iget v4, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->lastListVersion:I

    const-string v7, "iterator(...)"

    const-string v8, "next(...)"

    if-eq v1, v4, :cond_11f

    .line 195
    iput v1, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->lastListVersion:I

    .line 196
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    invoke-virtual {v4}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_cf
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_11f

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    invoke-static {v9, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v9, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .local v9, "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getDirty()Z

    move-result v10

    if-nez v10, :cond_11d

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getParts()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v10

    invoke-static {v10, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_ef
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_11d

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    invoke-static {v11, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 197
    .local v11, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget-object v12, v11, Lcom/exampletest/mobilestudiotest/model/Instance;->renderRec:Ljava/lang/Object;

    instance-of v13, v12, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    if-eqz v13, :cond_107

    check-cast v12, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    goto :goto_108

    :cond_107
    move-object v12, v14

    .line 198
    .local v12, "r":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    :goto_108
    if-eqz v12, :cond_118

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getSeen()I

    move-result v13

    if-ne v13, v2, :cond_118

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getChunk()Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    move-result-object v13

    if-ne v13, v9, :cond_118

    const/4 v13, 0x0

    goto :goto_ef

    :cond_118
    invoke-virtual {v9, v15}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setDirty(Z)V

    const/4 v13, 0x0

    goto :goto_cf

    .line 196
    .end local v11    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v12    # "r":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    :cond_11d
    const/4 v13, 0x0

    goto :goto_cf

    .line 201
    .end local v9    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    :cond_11f
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->host:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;

    invoke-interface {v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;->loadSignature()I

    move-result v4

    .line 202
    .local v4, "texEpoch":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    move-object v13, v9

    .line 203
    .local v13, "toBuild":Ljava/util/ArrayList;
    mul-float v16, p8, p8

    .line 204
    .local v16, "shR2":F
    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    invoke-virtual {v9}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v17

    .line 205
    .local v17, "it":Ljava/util/Iterator;
    :goto_137
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_247

    .line 206
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    invoke-static {v9, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v9, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .line 207
    .restart local v9    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getParts()Ljava/util/ArrayList;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_15a

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBuilt()Z

    move-result v10

    if-nez v10, :cond_15a

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->remove()V

    goto :goto_137

    .line 208
    :cond_15a
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBuilt()Z

    move-result v10

    if-eqz v10, :cond_16f

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getPendingTex()Z

    move-result v10

    if-eqz v10, :cond_16f

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getTexEpoch()I

    move-result v10

    if-eq v10, v4, :cond_16f

    invoke-virtual {v9, v15}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setDirty(Z)V

    .line 209
    :cond_16f
    invoke-virtual {v9, v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->distTo(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v10

    .line 210
    .local v10, "d":F
    invoke-virtual {v9, v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setDist(F)V

    .line 211
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getMaxTier()I

    move-result v11

    move/from16 v12, p6

    invoke-virtual {v0, v11, v12}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->tierRange(IF)F

    move-result v11

    cmpg-float v11, v10, v11

    if-gtz v11, :cond_1b1

    move-object v11, v7

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getX0()F

    move-result v7

    move-object/from16 v18, v8

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getY0()F

    move-result v8

    move-object/from16 v19, v9

    .end local v9    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .local v19, "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getZ0()F

    move-result v9

    move/from16 v20, v10

    .end local v10    # "d":F
    .local v20, "d":F
    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getX1()F

    move-result v10

    move-object/from16 v21, v11

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getY1()F

    move-result v11

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getZ1()F

    move-result v12

    move-object/from16 v22, v18

    move-object/from16 v14, v21

    invoke-virtual/range {v6 .. v12}, Lcom/exampletest/mobilestudiotest/render/Frustum;->box(FFFFFF)Z

    move-result v7

    if-eqz v7, :cond_1b8

    move v6, v15

    goto :goto_1b9

    .end local v19    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v20    # "d":F
    .restart local v9    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .restart local v10    # "d":F
    :cond_1b1
    move-object v14, v7

    move-object/from16 v22, v8

    move-object/from16 v19, v9

    move/from16 v20, v10

    .end local v9    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v10    # "d":F
    .restart local v19    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .restart local v20    # "d":F
    :cond_1b8
    const/4 v6, 0x0

    .line 212
    .local v6, "need":Z
    :goto_1b9
    if-nez v6, :cond_1ff

    if-eqz p7, :cond_1ff

    .line 213
    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getX0()F

    move-result v7

    invoke-virtual/range {p7 .. p7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v8

    sub-float/2addr v7, v8

    const/4 v8, 0x0

    invoke-static {v7, v8}, Ljava/lang/Math;->max(FF)F

    move-result v7

    invoke-virtual/range {p7 .. p7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v9

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getX1()F

    move-result v10

    sub-float/2addr v9, v10

    invoke-static {v7, v9}, Ljava/lang/Math;->max(FF)F

    move-result v7

    .local v7, "dx":F
    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getZ0()F

    move-result v9

    invoke-virtual/range {p7 .. p7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v10

    sub-float/2addr v9, v10

    invoke-static {v9, v8}, Ljava/lang/Math;->max(FF)F

    move-result v8

    invoke-virtual/range {p7 .. p7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v9

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getZ1()F

    move-result v10

    sub-float/2addr v9, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->max(FF)F

    move-result v8

    .line 214
    .local v8, "dz":F
    mul-float v9, v7, v7

    mul-float v10, v8, v8

    add-float/2addr v9, v10

    cmpg-float v9, v9, v16

    if-gez v9, :cond_1fd

    move v9, v15

    goto :goto_1fe

    :cond_1fd
    const/4 v9, 0x0

    :goto_1fe
    move v6, v9

    .line 216
    .end local v7    # "dx":F
    .end local v8    # "dz":F
    :cond_1ff
    if-eqz v6, :cond_207

    move-object/from16 v7, v19

    .end local v19    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .local v7, "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    invoke-virtual {v7, v2}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setLastInRange(I)V

    goto :goto_21f

    .line 218
    .end local v7    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .restart local v19    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    :cond_207
    move-object/from16 v7, v19

    .end local v19    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .restart local v7    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBuilt()Z

    move-result v8

    if-eqz v8, :cond_21f

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getLastInRange()I

    move-result v8

    sub-int v8, v2, v8

    const/16 v9, 0x384

    if-le v8, v9, :cond_21f

    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->free(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V

    invoke-virtual {v7, v15}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setDirty(Z)V

    .line 219
    :cond_21f
    :goto_21f
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getDirty()Z

    move-result v8

    if-nez v8, :cond_23a

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBuilt()Z

    move-result v8

    if-eqz v8, :cond_23a

    .line 220
    if-eqz v6, :cond_232

    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->visible:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_232
    move-object/from16 v6, p5

    move-object v7, v14

    move-object/from16 v8, v22

    const/4 v14, 0x0

    goto/16 :goto_137

    .line 219
    :cond_23a
    if-eqz v6, :cond_23f

    invoke-virtual {v13, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_23f
    move-object/from16 v6, p5

    move-object v7, v14

    move-object/from16 v8, v22

    const/4 v14, 0x0

    goto/16 :goto_137

    .line 222
    .end local v6    # "need":Z
    .end local v7    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v20    # "d":F
    :cond_247
    move-object v14, v7

    move-object/from16 v22, v8

    move-object v6, v13

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_314

    .line 223
    move-object v6, v13

    check-cast v6, Ljava/util/List;

    .local v6, "$this$sortBy\\2":Ljava/util/List;
    const/4 v7, 0x0

    .line 464
    .local v7, "$i$f$sortBy\\2\\223":I
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v8

    if-le v8, v15, :cond_267

    new-instance v8, Lcom/exampletest/mobilestudiotest/render/StaticBatches$update$$inlined$sortBy$1;

    invoke-direct {v8}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$update$$inlined$sortBy$1;-><init>()V

    check-cast v8, Ljava/util/Comparator;

    invoke-static {v6, v8}, Lkotlin/collections/CollectionsKt;->sortWith(Ljava/util/List;Ljava/util/Comparator;)V

    .line 465
    :cond_267
    nop

    .line 224
    .end local v6    # "$this$sortBy\\2":Ljava/util/List;
    .end local v7    # "$i$f$sortBy\\2\\223":I
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v6

    add-long v6, v6, p9

    .line 225
    .local v6, "end":J
    const/4 v8, 0x1

    .line 226
    .local v8, "first":Z
    invoke-virtual {v13}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v9

    invoke-static {v9, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_276
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_311

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    move-object/from16 v11, v22

    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v10, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .line 227
    .local v10, "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    if-nez v8, :cond_2e2

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v19

    cmp-long v12, v19, v6

    if-ltz v12, :cond_2e2

    .line 234
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getParts()Ljava/util/ArrayList;

    move-result-object v12

    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v12

    invoke-static {v12, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_29c
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v19

    if-eqz v19, :cond_2da

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    invoke-static {v15, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v15, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v15, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget-object v1, v15, Lcom/exampletest/mobilestudiotest/model/Instance;->renderRec:Ljava/lang/Object;

    instance-of v3, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    if-eqz v3, :cond_2b4

    check-cast v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;

    goto :goto_2b5

    :cond_2b4
    const/4 v1, 0x0

    :goto_2b5
    if-nez v1, :cond_2bd

    move/from16 v1, p2

    move-object/from16 v3, p4

    const/4 v15, 0x1

    goto :goto_29c

    .local v1, "r":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    :cond_2bd
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getChunk()Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    move-result-object v3

    if-ne v3, v10, :cond_2d4

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->getSeen()I

    move-result v3

    if-ne v3, v2, :cond_2d4

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->loose:Ljava/util/ArrayList;

    invoke-virtual {v3, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v1, p2

    move-object/from16 v3, p4

    const/4 v15, 0x1

    goto :goto_29c

    :cond_2d4
    move/from16 v1, p2

    move-object/from16 v3, p4

    const/4 v15, 0x1

    goto :goto_29c

    .end local v1    # "r":Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
    .end local v15    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_2da
    move/from16 v1, p2

    move-object/from16 v3, p4

    move-object/from16 v22, v11

    const/4 v15, 0x1

    goto :goto_276

    .line 228
    :cond_2e2
    const/4 v8, 0x0

    .line 229
    invoke-direct {v0, v10, v2, v4}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->build(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;II)V

    .line 230
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBuilt()Z

    move-result v1

    if-eqz v1, :cond_2f1

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->visible:Ljava/util/ArrayList;

    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 231
    :cond_2f1
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getParts()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_308

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getKey()J

    move-result-wide v20

    invoke-static/range {v20 .. v21}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 226
    .end local v10    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    :cond_308
    move/from16 v1, p2

    move-object/from16 v3, p4

    move-object/from16 v22, v11

    const/4 v15, 0x1

    goto/16 :goto_276

    :cond_311
    move-object/from16 v11, v22

    goto :goto_316

    .line 222
    .end local v6    # "end":J
    .end local v8    # "first":Z
    :cond_314
    move-object/from16 v11, v22

    .line 239
    :goto_316
    iget-wide v6, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->totalBytes:J

    cmp-long v1, v6, p11

    if-lez v1, :cond_38f

    .line 240
    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->chunks:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v1

    const-string v3, "<get-values>(...)"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$filter\\3":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 466
    .local v3, "$i$f$filter\\3\\240":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\4":Ljava/util/Collection;
    move-object v7, v1

    .local v7, "$this$filterTo\\4":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 467
    .local v8, "$i$f$filterTo\\4\\466":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_337
    :goto_337
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_35a

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\4":Ljava/lang/Object;
    move-object v12, v10

    check-cast v12, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .local v12, "it\\5":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    const/4 v14, 0x0

    .line 240
    .local v14, "$i$a$-filter-StaticBatches$update$idle$1\\5\\467\\0":I
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getBuilt()Z

    move-result v15

    if-eqz v15, :cond_353

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getLastInRange()I

    move-result v15

    if-eq v15, v2, :cond_353

    const/4 v12, 0x1

    goto :goto_354

    :cond_353
    const/4 v12, 0x0

    .line 467
    .end local v12    # "it\\5":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v14    # "$i$a$-filter-StaticBatches$update$idle$1\\5\\467\\0":I
    :goto_354
    if-eqz v12, :cond_337

    invoke-interface {v6, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_337

    .line 468
    .end local v10    # "element\\4":Ljava/lang/Object;
    :cond_35a
    nop

    .end local v6    # "destination\\4":Ljava/util/Collection;
    .end local v7    # "$this$filterTo\\4":Ljava/lang/Iterable;
    .end local v8    # "$i$f$filterTo\\4\\466":I
    check-cast v6, Ljava/util/List;

    .line 466
    nop

    .end local v1    # "$this$filter\\3":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filter\\3\\240":I
    check-cast v6, Ljava/lang/Iterable;

    .line 240
    nop

    .local v6, "$this$sortedBy\\6":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 469
    .local v1, "$i$f$sortedBy\\6\\240":I
    new-instance v3, Lcom/exampletest/mobilestudiotest/render/StaticBatches$update$$inlined$sortedBy$1;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$update$$inlined$sortedBy$1;-><init>()V

    check-cast v3, Ljava/util/Comparator;

    invoke-static {v6, v3}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v1

    .line 240
    .end local v1    # "$i$f$sortedBy\\6\\240":I
    .end local v6    # "$this$sortedBy\\6":Ljava/lang/Iterable;
    nop

    .line 241
    .local v1, "idle":Ljava/util/List;
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_372
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_38f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    invoke-static {v6, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .local v6, "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    iget-wide v7, v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->totalBytes:J

    cmp-long v7, v7, p11

    if-lez v7, :cond_38f

    invoke-direct {v0, v6}, Lcom/exampletest/mobilestudiotest/render/StaticBatches;->free(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->setDirty(Z)V

    .end local v6    # "c":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    goto :goto_372

    .line 243
    .end local v1    # "idle":Ljava/util/List;
    :cond_38f
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches.Batch (com.exampletest.mobilestudiotest.render.StaticBatches$Batch)
.class public final Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Batch"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u000e\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0008\u0010\u0007\u001a\u0004\u0018\u00010\u0008\u0012\u0006\u0010\t\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\n\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\rR\u0013\u0010\u0007\u001a\u0004\u0018\u00010\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R\u0011\u0010\t\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\rR\u0011\u0010\u0014\u001a\u00020\u00038F\u00a2\u0006\u0006\u001a\u0004\u0008\u0015\u0010\r\u00a8\u0006\u0016"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;",
        "",
        "vbo",
        "",
        "count",
        "tier",
        "kind",
        "tex",
        "Lcom/exampletest/mobilestudiotest/render/TexBind;",
        "bytes",
        "<init>",
        "(IIIILcom/exampletest/mobilestudiotest/render/TexBind;I)V",
        "getVbo",
        "()I",
        "getCount",
        "getTier",
        "getKind",
        "getTex",
        "()Lcom/exampletest/mobilestudiotest/render/TexBind;",
        "getBytes",
        "strideBytes",
        "getStrideBytes",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final bytes:I

.field private final count:I

.field private final kind:I

.field private final tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

.field private final tier:I

.field private final vbo:I


# direct methods
.method public constructor <init>(IIIILcom/exampletest/mobilestudiotest/render/TexBind;I)V
    .registers 7
    .param p1, "vbo"    # I
    .param p2, "count"    # I
    .param p3, "tier"    # I
    .param p4, "kind"    # I
    .param p5, "tex"    # Lcom/exampletest/mobilestudiotest/render/TexBind;
    .param p6, "bytes"    # I

    .line 103
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->vbo:I

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->count:I

    iput p3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->tier:I

    iput p4, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->kind:I

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    iput p6, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->bytes:I

    return-void
.end method


# virtual methods
.method public final getBytes()I
    .registers 2

    .line 103
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->bytes:I

    return v0
.end method

.method public final getCount()I
    .registers 2

    .line 103
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->count:I

    return v0
.end method

.method public final getKind()I
    .registers 2

    .line 103
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->kind:I

    return v0
.end method

.method public final getStrideBytes()I
    .registers 3

    .line 104
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->kind:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_8

    const/16 v0, 0x1c

    goto :goto_a

    :cond_8
    const/16 v0, 0x28

    :goto_a
    return v0
.end method

.method public final getTex()Lcom/exampletest/mobilestudiotest/render/TexBind;
    .registers 2

    .line 103
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    return-object v0
.end method

.method public final getTier()I
    .registers 2

    .line 103
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->tier:I

    return v0
.end method

.method public final getVbo()I
    .registers 2

    .line 103
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;->vbo:I

    return v0
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches.Chunk (com.exampletest.mobilestudiotest.render.StaticBatches$Chunk)
.class public final Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Chunk"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0008\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0007\n\u0002\u0008\u0014\n\u0002\u0010\u0008\n\u0002\u0008\u0014\n\u0002\u0010\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J&\u0010J\u001a\u00020K2\u0006\u0010L\u001a\u00020!2\u0006\u0010M\u001a\u00020!2\u0006\u0010N\u001a\u00020!2\u0006\u0010O\u001a\u00020!J\u000e\u0010P\u001a\u00020!2\u0006\u0010Q\u001a\u00020RR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007R*\u0010\u0008\u001a\u0012\u0012\u0004\u0012\u00020\n0\tj\u0008\u0012\u0004\u0012\u00020\n`\u000bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000c\u0010\r\"\u0004\u0008\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0012\u0010\u0013\"\u0004\u0008\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u0011X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0017\u0010\u0013\"\u0004\u0008\u0018\u0010\u0015R \u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\u001b0\u001aX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001c\u0010\u001d\"\u0004\u0008\u001e\u0010\u001fR\u001a\u0010 \u001a\u00020!X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\"\u0010#\"\u0004\u0008$\u0010%R\u001a\u0010&\u001a\u00020!X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\'\u0010#\"\u0004\u0008(\u0010%R\u001a\u0010)\u001a\u00020!X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008*\u0010#\"\u0004\u0008+\u0010%R\u001a\u0010,\u001a\u00020!X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008-\u0010#\"\u0004\u0008.\u0010%R\u001a\u0010/\u001a\u00020!X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00080\u0010#\"\u0004\u00081\u0010%R\u001a\u00102\u001a\u00020!X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00083\u0010#\"\u0004\u00084\u0010%R\u001a\u00105\u001a\u000206X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00087\u00108\"\u0004\u00089\u0010:R\u001a\u0010;\u001a\u000206X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008<\u00108\"\u0004\u0008=\u0010:R\u001a\u0010>\u001a\u00020\u0011X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008?\u0010\u0013\"\u0004\u0008@\u0010\u0015R\u001a\u0010A\u001a\u000206X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008B\u00108\"\u0004\u0008C\u0010:R\u001a\u0010D\u001a\u00020!X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008E\u0010#\"\u0004\u0008F\u0010%R\u001a\u0010G\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008H\u0010\u0007\"\u0004\u0008I\u0010\u0005\u00a8\u0006S"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;",
        "",
        "key",
        "",
        "<init>",
        "(J)V",
        "getKey",
        "()J",
        "parts",
        "Ljava/util/ArrayList;",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "Lkotlin/collections/ArrayList;",
        "getParts",
        "()Ljava/util/ArrayList;",
        "setParts",
        "(Ljava/util/ArrayList;)V",
        "dirty",
        "",
        "getDirty",
        "()Z",
        "setDirty",
        "(Z)V",
        "built",
        "getBuilt",
        "setBuilt",
        "batches",
        "",
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;",
        "getBatches",
        "()Ljava/util/List;",
        "setBatches",
        "(Ljava/util/List;)V",
        "x0",
        "",
        "getX0",
        "()F",
        "setX0",
        "(F)V",
        "y0",
        "getY0",
        "setY0",
        "z0",
        "getZ0",
        "setZ0",
        "x1",
        "getX1",
        "setX1",
        "y1",
        "getY1",
        "setY1",
        "z1",
        "getZ1",
        "setZ1",
        "maxTier",
        "",
        "getMaxTier",
        "()I",
        "setMaxTier",
        "(I)V",
        "texEpoch",
        "getTexEpoch",
        "setTexEpoch",
        "pendingTex",
        "getPendingTex",
        "setPendingTex",
        "lastInRange",
        "getLastInRange",
        "setLastInRange",
        "dist",
        "getDist",
        "setDist",
        "bytes",
        "getBytes",
        "setBytes",
        "grow",
        "",
        "cx",
        "cy",
        "cz",
        "r",
        "distTo",
        "p",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private batches:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;",
            ">;"
        }
    .end annotation
.end field

.field private built:Z

.field private bytes:J

.field private dirty:Z

.field private dist:F

.field private final key:J

.field private lastInRange:I

.field private maxTier:I

.field private parts:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation
.end field

.field private pendingTex:Z

.field private texEpoch:I

.field private x0:F

.field private x1:F

.field private y0:F

.field private y1:F

.field private z0:F

.field private z1:F


# direct methods
.method public constructor <init>(J)V
    .registers 4
    .param p1, "key"    # J

    .line 107
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->key:J

    .line 108
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->parts:Ljava/util/ArrayList;

    .line 109
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->dirty:Z

    .line 111
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->batches:Ljava/util/List;

    .line 112
    const v0, 0x7f7fffff    # Float.MAX_VALUE

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x0:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y0:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z0:F

    .line 113
    const v0, -0x800001

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x1:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y1:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z1:F

    .line 115
    const/4 v0, -0x1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->texEpoch:I

    .line 107
    return-void
.end method


# virtual methods
.method public final distTo(Lcom/exampletest/mobilestudiotest/model/Vector3;)F
    .registers 7
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "p"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 127
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x0:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v1

    sub-float/2addr v0, v1

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x1:F

    sub-float/2addr v2, v3

    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    move-result v0

    .local v0, "dx":F
    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y0:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    sub-float/2addr v2, v3

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v2

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    iget v4, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y1:F

    sub-float/2addr v3, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    move-result v2

    .local v2, "dy":F
    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z0:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    sub-float/2addr v3, v4

    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    iget v4, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z1:F

    sub-float/2addr v3, v4

    invoke-static {v1, v3}, Ljava/lang/Math;->max(FF)F

    move-result v1

    .line 128
    .local v1, "dz":F
    mul-float v3, v0, v0

    mul-float v4, v2, v2

    add-float/2addr v3, v4

    mul-float v4, v1, v1

    add-float/2addr v3, v4

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v3

    double-to-float v3, v3

    return v3
.end method

.method public final getBatches()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;",
            ">;"
        }
    .end annotation

    .line 111
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->batches:Ljava/util/List;

    return-object v0
.end method

.method public final getBuilt()Z
    .registers 2

    .line 110
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->built:Z

    return v0
.end method

.method public final getBytes()J
    .registers 3

    .line 119
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->bytes:J

    return-wide v0
.end method

.method public final getDirty()Z
    .registers 2

    .line 109
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->dirty:Z

    return v0
.end method

.method public final getDist()F
    .registers 2

    .line 118
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->dist:F

    return v0
.end method

.method public final getKey()J
    .registers 3

    .line 107
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->key:J

    return-wide v0
.end method

.method public final getLastInRange()I
    .registers 2

    .line 117
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->lastInRange:I

    return v0
.end method

.method public final getMaxTier()I
    .registers 2

    .line 114
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->maxTier:I

    return v0
.end method

.method public final getParts()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 108
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->parts:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final getPendingTex()Z
    .registers 2

    .line 116
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->pendingTex:Z

    return v0
.end method

.method public final getTexEpoch()I
    .registers 2

    .line 115
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->texEpoch:I

    return v0
.end method

.method public final getX0()F
    .registers 2

    .line 112
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x0:F

    return v0
.end method

.method public final getX1()F
    .registers 2

    .line 113
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x1:F

    return v0
.end method

.method public final getY0()F
    .registers 2

    .line 112
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y0:F

    return v0
.end method

.method public final getY1()F
    .registers 2

    .line 113
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y1:F

    return v0
.end method

.method public final getZ0()F
    .registers 2

    .line 112
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z0:F

    return v0
.end method

.method public final getZ1()F
    .registers 2

    .line 113
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z1:F

    return v0
.end method

.method public final grow(FFFF)V
    .registers 7
    .param p1, "cx"    # F
    .param p2, "cy"    # F
    .param p3, "cz"    # F
    .param p4, "r"    # F

    .line 122
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x0:F

    sub-float v1, p1, p4

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x0:F

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y0:F

    sub-float v1, p2, p4

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y0:F

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z0:F

    sub-float v1, p3, p4

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z0:F

    .line 123
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x1:F

    add-float v1, p1, p4

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x1:F

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y1:F

    add-float v1, p2, p4

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y1:F

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z1:F

    add-float v1, p3, p4

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z1:F

    .line 124
    return-void
.end method

.method public final setBatches(Ljava/util/List;)V
    .registers 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Batch;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->batches:Ljava/util/List;

    return-void
.end method

.method public final setBuilt(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 110
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->built:Z

    return-void
.end method

.method public final setBytes(J)V
    .registers 3
    .param p1, "<set-?>"    # J

    .line 119
    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->bytes:J

    return-void
.end method

.method public final setDirty(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 109
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->dirty:Z

    return-void
.end method

.method public final setDist(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 118
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->dist:F

    return-void
.end method

.method public final setLastInRange(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 117
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->lastInRange:I

    return-void
.end method

.method public final setMaxTier(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 114
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->maxTier:I

    return-void
.end method

.method public final setParts(Ljava/util/ArrayList;)V
    .registers 3
    .param p1, "<set-?>"    # Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->parts:Ljava/util/ArrayList;

    return-void
.end method

.method public final setPendingTex(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 116
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->pendingTex:Z

    return-void
.end method

.method public final setTexEpoch(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 115
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->texEpoch:I

    return-void
.end method

.method public final setX0(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 112
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x0:F

    return-void
.end method

.method public final setX1(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 113
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->x1:F

    return-void
.end method

.method public final setY0(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 112
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y0:F

    return-void
.end method

.method public final setY1(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 113
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->y1:F

    return-void
.end method

.method public final setZ0(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 112
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z0:F

    return-void
.end method

.method public final setZ1(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 113
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->z1:F

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches.Companion (com.exampletest.mobilestudiotest.render.StaticBatches$Companion)
.class public final Lcom/exampletest/mobilestudiotest/render/StaticBatches$Companion;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0006\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0007X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0007X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0007X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\u0007X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Companion;",
        "",
        "<init>",
        "()V",
        "CELL",
        "",
        "STRIDE_INTS",
        "",
        "STRIDE_BYTES",
        "MESH_STRIDE_INTS",
        "MESH_STRIDE_BYTES",
        "COOL",
        "UNLOAD_FRAMES",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 450
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Companion;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches.Group (com.exampletest.mobilestudiotest.render.StaticBatches$Group)
.class final Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Group"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0007\u0008\u0002\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\nR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR!\u0010\u000e\u001a\u0012\u0012\u0004\u0012\u00020\u00100\u000fj\u0008\u0012\u0004\u0012\u00020\u0010`\u0011\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0015\u0010\n\"\u0004\u0008\u0016\u0010\u0017\u00a8\u0006\u0018"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;",
        "",
        "tier",
        "",
        "kind",
        "tex",
        "Lcom/exampletest/mobilestudiotest/render/TexBind;",
        "<init>",
        "(IILcom/exampletest/mobilestudiotest/render/TexBind;)V",
        "getTier",
        "()I",
        "getKind",
        "getTex",
        "()Lcom/exampletest/mobilestudiotest/render/TexBind;",
        "specs",
        "Ljava/util/ArrayList;",
        "Lcom/exampletest/mobilestudiotest/render/BatchSpec;",
        "Lkotlin/collections/ArrayList;",
        "getSpecs",
        "()Ljava/util/ArrayList;",
        "verts",
        "getVerts",
        "setVerts",
        "(I)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final kind:I

.field private final specs:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/render/BatchSpec;",
            ">;"
        }
    .end annotation
.end field

.field private final tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

.field private final tier:I

.field private verts:I


# direct methods
.method public constructor <init>(IILcom/exampletest/mobilestudiotest/render/TexBind;)V
    .registers 5
    .param p1, "tier"    # I
    .param p2, "kind"    # I
    .param p3, "tex"    # Lcom/exampletest/mobilestudiotest/render/TexBind;

    .line 265
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->tier:I

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->kind:I

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->specs:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final getKind()I
    .registers 2

    .line 265
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->kind:I

    return v0
.end method

.method public final getSpecs()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/render/BatchSpec;",
            ">;"
        }
    .end annotation

    .line 265
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->specs:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final getTex()Lcom/exampletest/mobilestudiotest/render/TexBind;
    .registers 2

    .line 265
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    return-object v0
.end method

.method public final getTier()I
    .registers 2

    .line 265
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->tier:I

    return v0
.end method

.method public final getVerts()I
    .registers 2

    .line 265
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->verts:I

    return v0
.end method

.method public final setVerts(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 265
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Group;->verts:I

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches.GroupKey (com.exampletest.mobilestudiotest.render.StaticBatches$GroupKey)
.class final Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "GroupKey"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0000\u0008\u0082\u0008\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\t\u0010\u000e\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u000f\u001a\u00020\u0003H\u00c6\u0003J\u000b\u0010\u0010\u001a\u0004\u0018\u00010\u0006H\u00c6\u0003J)\u0010\u0011\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00032\n\u0008\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u00c6\u0001J\u0013\u0010\u0012\u001a\u00020\u00132\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0015\u001a\u00020\u0003H\u00d6\u0001J\t\u0010\u0016\u001a\u00020\u0017H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\nR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\r\u00a8\u0006\u0018"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;",
        "",
        "tier",
        "",
        "kind",
        "tex",
        "Lcom/exampletest/mobilestudiotest/render/TexBind;",
        "<init>",
        "(IILcom/exampletest/mobilestudiotest/render/TexBind;)V",
        "getTier",
        "()I",
        "getKind",
        "getTex",
        "()Lcom/exampletest/mobilestudiotest/render/TexBind;",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final kind:I

.field private final tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

.field private final tier:I


# direct methods
.method public constructor <init>(IILcom/exampletest/mobilestudiotest/render/TexBind;)V
    .registers 4
    .param p1, "tier"    # I
    .param p2, "kind"    # I
    .param p3, "tex"    # Lcom/exampletest/mobilestudiotest/render/TexBind;

    .line 334
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tier:I

    iput p2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->kind:I

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;IILcom/exampletest/mobilestudiotest/render/TexBind;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tier:I

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget p2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->kind:I

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget-object p3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->copy(IILcom/exampletest/mobilestudiotest/render/TexBind;)Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tier:I

    return v0
.end method

.method public final component2()I
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->kind:I

    return v0
.end method

.method public final component3()Lcom/exampletest/mobilestudiotest/render/TexBind;
    .registers 2

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    return-object v0
.end method

.method public final copy(IILcom/exampletest/mobilestudiotest/render/TexBind;)Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;
    .registers 5

    new-instance v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;

    invoke-direct {v0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;-><init>(IILcom/exampletest/mobilestudiotest/render/TexBind;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tier:I

    iget v4, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tier:I

    if-eq v3, v4, :cond_14

    return v2

    :cond_14
    iget v3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->kind:I

    iget v4, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->kind:I

    if-eq v3, v4, :cond_1b

    return v2

    :cond_1b
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    iget-object v1, v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_26

    return v2

    :cond_26
    return v0
.end method

.method public final getKind()I
    .registers 2

    .line 334
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->kind:I

    return v0
.end method

.method public final getTex()Lcom/exampletest/mobilestudiotest/render/TexBind;
    .registers 2

    .line 334
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    return-object v0
.end method

.method public final getTier()I
    .registers 2

    .line 334
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tier:I

    return v0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tier:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->kind:I

    invoke-static {v2}, Ljava/lang/Integer;->hashCode(I)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    if-nez v2, :cond_17

    const/4 v2, 0x0

    goto :goto_1d

    :cond_17
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/render/TexBind;->hashCode()I

    move-result v2

    :goto_1d
    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 6

    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tier:I

    iget v1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->kind:I

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$GroupKey;->tex:Lcom/exampletest/mobilestudiotest/render/TexBind;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "GroupKey(tier="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, ", kind="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", tex="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches.Host (com.exampletest.mobilestudiotest.render.StaticBatches$Host)
.class public interface abstract Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Host"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\u0008f\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0018\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0008\u0018\u00010\u00072\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0008\u0010\t\u001a\u00020\nH&\u00a8\u0006\u000b\u00c0\u0006\u0003"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Host;",
        "",
        "batchable",
        "",
        "p",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "spec",
        "",
        "Lcom/exampletest/mobilestudiotest/render/BatchSpec;",
        "loadSignature",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# virtual methods
.method public abstract batchable(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
.end method

.method public abstract loadSignature()I
.end method

.method public abstract spec(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ")",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/render/BatchSpec;",
            ">;"
        }
    .end annotation
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches.PartRec (com.exampletest.mobilestudiotest.render.StaticBatches$PartRec)
.class public final Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;
.super Ljava/lang/Object;
.source "StaticBatches.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "PartRec"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u000e\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0008\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007R\u001a\u0010\u0008\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\t\u0010\u0007\"\u0004\u0008\n\u0010\u0005R\u001a\u0010\u000b\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000c\u0010\u0007\"\u0004\u0008\r\u0010\u0005R\u001a\u0010\u000e\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000f\u0010\u0007\"\u0004\u0008\u0010\u0010\u0005R\u001c\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0013\u0010\u0014\"\u0004\u0008\u0015\u0010\u0016R\u001a\u0010\u0017\u001a\u00020\u0018X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0019\u0010\u001a\"\u0004\u0008\u001b\u0010\u001cR\u001a\u0010\u001d\u001a\u00020\u0018X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001e\u0010\u001a\"\u0004\u0008\u001f\u0010\u001c\u00a8\u0006 "
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;",
        "",
        "gen",
        "",
        "<init>",
        "(I)V",
        "getGen",
        "()I",
        "ver",
        "getVer",
        "setVer",
        "changedFrame",
        "getChangedFrame",
        "setChangedFrame",
        "seen",
        "getSeen",
        "setSeen",
        "chunk",
        "Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;",
        "getChunk",
        "()Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;",
        "setChunk",
        "(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V",
        "known",
        "",
        "getKnown",
        "()Z",
        "setKnown",
        "(Z)V",
        "batchable",
        "getBatchable",
        "setBatchable",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private batchable:Z

.field private changedFrame:I

.field private chunk:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

.field private final gen:I

.field private known:Z

.field private seen:I

.field private ver:I


# direct methods
.method public constructor <init>(I)V
    .registers 3
    .param p1, "gen"    # I

    .line 93
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->gen:I

    .line 95
    const/high16 v0, -0x40000000    # -2.0f

    iput v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->changedFrame:I

    .line 93
    return-void
.end method


# virtual methods
.method public final getBatchable()Z
    .registers 2

    .line 99
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->batchable:Z

    return v0
.end method

.method public final getChangedFrame()I
    .registers 2

    .line 95
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->changedFrame:I

    return v0
.end method

.method public final getChunk()Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .registers 2

    .line 97
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->chunk:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    return-object v0
.end method

.method public final getGen()I
    .registers 2

    .line 93
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->gen:I

    return v0
.end method

.method public final getKnown()Z
    .registers 2

    .line 98
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->known:Z

    return v0
.end method

.method public final getSeen()I
    .registers 2

    .line 96
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->seen:I

    return v0
.end method

.method public final getVer()I
    .registers 2

    .line 94
    iget v0, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->ver:I

    return v0
.end method

.method public final setBatchable(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 99
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->batchable:Z

    return-void
.end method

.method public final setChangedFrame(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 95
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->changedFrame:I

    return-void
.end method

.method public final setChunk(Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;)V
    .registers 2
    .param p1, "<set-?>"    # Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .line 97
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->chunk:Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    return-void
.end method

.method public final setKnown(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 98
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->known:Z

    return-void
.end method

.method public final setSeen(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 96
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->seen:I

    return-void
.end method

.method public final setVer(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 94
    iput p1, p0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$PartRec;->ver:I

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches$update$$inlined$sortBy$1 (com.exampletest.mobilestudiotest.render.StaticBatches$update$$inlined$sortBy$1)
.class public final Lcom/exampletest/mobilestudiotest/render/StaticBatches$update$$inlined$sortBy$1;
.super Ljava/lang/Object;
.source "Comparisons.kt"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;->update(Ljava/util/List;IILcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/render/Frustum;FLcom/exampletest/mobilestudiotest/model/Vector3;FJJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Comparator;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nComparisons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Comparisons.kt\nkotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2\n+ 2 StaticBatches.kt\ncom/exampletest/mobilestudiotest/render/StaticBatches\n*L\n1#1,328:1\n223#2:329\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 7
    .param p1, "a"    # Ljava/lang/Object;
    .param p2, "b"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)I"
        }
    .end annotation

    .line 102
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .local v0, "it\\1":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    const/4 v1, 0x0

    .line 329
    .local v1, "$i$a$-sortBy-StaticBatches$update$2\\1\\102\\0":I
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getDist()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    .line 102
    .end local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v1    # "$i$a$-sortBy-StaticBatches$update$2\\1\\102\\0":I
    check-cast v0, Ljava/lang/Comparable;

    move-object v1, p2

    check-cast v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .local v1, "it\\2":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    const/4 v2, 0x0

    .line 329
    .local v2, "$i$a$-sortBy-StaticBatches$update$2\\2\\102\\0":I
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getDist()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    .line 102
    .end local v1    # "it\\2":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v2    # "$i$a$-sortBy-StaticBatches$update$2\\2\\102\\0":I
    check-cast v1, Ljava/lang/Comparable;

    invoke-static {v0, v1}, Lkotlin/comparisons/ComparisonsKt;->compareValues(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    move-result v0

    return v0
.end method

###### Class com.exampletest.mobilestudiotest.render.StaticBatches$update$$inlined$sortedBy$1 (com.exampletest.mobilestudiotest.render.StaticBatches$update$$inlined$sortedBy$1)
.class public final Lcom/exampletest/mobilestudiotest/render/StaticBatches$update$$inlined$sortedBy$1;
.super Ljava/lang/Object;
.source "Comparisons.kt"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/render/StaticBatches;->update(Ljava/util/List;IILcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/render/Frustum;FLcom/exampletest/mobilestudiotest/model/Vector3;FJJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Comparator;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nComparisons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Comparisons.kt\nkotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2\n+ 2 StaticBatches.kt\ncom/exampletest/mobilestudiotest/render/StaticBatches\n*L\n1#1,328:1\n240#2:329\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 7
    .param p1, "a"    # Ljava/lang/Object;
    .param p2, "b"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)I"
        }
    .end annotation

    .line 102
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .local v0, "it\\1":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    const/4 v1, 0x0

    .line 329
    .local v1, "$i$a$-sortedBy-StaticBatches$update$idle$2\\1\\102\\0":I
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getLastInRange()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    .line 102
    .end local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v1    # "$i$a$-sortedBy-StaticBatches$update$idle$2\\1\\102\\0":I
    check-cast v0, Ljava/lang/Comparable;

    move-object v1, p2

    check-cast v1, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;

    .local v1, "it\\2":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    const/4 v2, 0x0

    .line 329
    .local v2, "$i$a$-sortedBy-StaticBatches$update$idle$2\\2\\102\\0":I
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;->getLastInRange()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    .line 102
    .end local v1    # "it\\2":Lcom/exampletest/mobilestudiotest/render/StaticBatches$Chunk;
    .end local v2    # "$i$a$-sortedBy-StaticBatches$update$idle$2\\2\\102\\0":I
    check-cast v1, Ljava/lang/Comparable;

    invoke-static {v0, v1}, Lkotlin/comparisons/ComparisonsKt;->compareValues(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    move-result v0

    return v0
.end method
