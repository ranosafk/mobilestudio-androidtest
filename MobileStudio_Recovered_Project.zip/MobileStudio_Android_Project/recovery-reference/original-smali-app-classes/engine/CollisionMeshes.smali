###### Class com.exampletest.mobilestudiotest.engine.CollisionMeshes (com.exampletest.mobilestudiotest.engine.CollisionMeshes)
.class public final Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;
.super Ljava/lang/Object;
.source "CollisionMeshes.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCollisionMeshes.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CollisionMeshes.kt\ncom/exampletest/mobilestudiotest/engine/CollisionMeshes\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 CollisionMeshes.kt\ncom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh\n*L\n1#1,264:1\n1563#2:265\n1634#2,3:266\n1563#2:270\n1634#2,3:271\n1563#2:288\n1634#2,3:289\n1#3:269\n62#4,7:274\n62#4,7:281\n*S KotlinDebug\n*F\n+ 1 CollisionMeshes.kt\ncom/exampletest/mobilestudiotest/engine/CollisionMeshes\n*L\n109#1:265\n109#1:266,3\n163#1:270\n163#1:271,3\n160#1:288\n160#1:289,3\n188#1:274,7\n259#1:281,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000`\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0004\n\u0002\u0010\t\n\u0000\n\u0002\u0010 \n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\u0008\u0010\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u00015B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u000bJ\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u000e\u001a\u00020\u000bJ\u001a\u0010\u0011\u001a\u0004\u0018\u00010\u000c2\u0006\u0010\u000e\u001a\u00020\u000b2\u0008\u0008\u0002\u0010\u0012\u001a\u00020\u0010J>\u0010\u0013\u001a\u00020\u000c2\u0006\u0010\u0014\u001a\u00020\u00152\u000c\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u00180\u00172\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u0010H\u0002J \u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020\u00182\u0006\u0010#\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u001dH\u0002J4\u0010$\u001a\u0010\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020&\u0018\u00010%2\u0006\u0010\'\u001a\u00020\u000c2\u0006\u0010(\u001a\u00020!2\u0006\u0010)\u001a\u00020\u001a2\u0006\u0010*\u001a\u00020\u001aJ0\u0010+\u001a\u00020\u00102\u0006\u0010,\u001a\u00020!2\u0006\u0010-\u001a\u00020\u001a2\u0006\u0010.\u001a\u00020\u001a2\u0006\u0010/\u001a\u00020\u001a2\u0006\u00100\u001a\u00020\u001aH\u0002J4\u00101\u001a\u0010\u0012\u0004\u0012\u00020&\u0012\u0004\u0012\u00020\u001a\u0018\u00010%2\u0006\u0010\'\u001a\u00020\u000c2\u0006\u00102\u001a\u00020\u001a2\u0006\u00103\u001a\u00020\u001a2\u0006\u00104\u001a\u00020&R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000c0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001f\u001a\u0008\u0012\u0004\u0012\u00020\u001a0\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u00066"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;",
        "",
        "<init>",
        "()V",
        "DEFAULT",
        "",
        "HULL",
        "BOX",
        "PRECISE",
        "cache",
        "Ljava/util/WeakHashMap;",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;",
        "fidelity",
        "p",
        "hasGeometry",
        "",
        "forPart",
        "forRays",
        "build",
        "key",
        "",
        "src",
        "",
        "",
        "center",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "scale",
        "cf",
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "hull",
        "DIRS",
        "hullOf",
        "Lcom/exampletest/mobilestudiotest/engine/ConvexShape;",
        "pos",
        "count",
        "push",
        "Lkotlin/Pair;",
        "",
        "m",
        "shape",
        "lo",
        "hi",
        "overlaps",
        "s",
        "a",
        "b",
        "c",
        "n",
        "ray",
        "o",
        "d",
        "maxDist",
        "Mesh",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final BOX:I = 0x2

.field public static final DEFAULT:I = 0x0

.field private static final DIRS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            ">;"
        }
    .end annotation
.end field

.field public static final HULL:I = 0x1

.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;

.field public static final PRECISE:I = 0x3

.field private static final cache:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 9

    new-instance v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;

    .line 75
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->cache:Ljava/util/WeakHashMap;

    .line 160
    nop

    .line 157
    const/16 v0, 0xd

    new-array v0, v0, [Lcom/exampletest/mobilestudiotest/model/Vector3;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/4 v4, 0x0

    aput-object v1, v0, v4

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v3, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/4 v4, 0x1

    aput-object v1, v0, v4

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v3, v3, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/4 v4, 0x2

    aput-object v1, v0, v4

    .line 158
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v2, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/4 v4, 0x3

    aput-object v1, v0, v4

    .line 157
    nop

    .line 158
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/high16 v4, -0x40800000    # -1.0f

    invoke-direct {v1, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/4 v5, 0x4

    aput-object v1, v0, v5

    .line 157
    nop

    .line 158
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v2, v3, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/4 v5, 0x5

    aput-object v1, v0, v5

    .line 157
    nop

    .line 158
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/4 v5, 0x6

    aput-object v1, v0, v5

    .line 157
    nop

    .line 158
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v3, v2, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/4 v5, 0x7

    aput-object v1, v0, v5

    .line 157
    nop

    .line 158
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v3, v2, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/16 v3, 0x8

    aput-object v1, v0, v3

    .line 157
    nop

    .line 159
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v2, v2, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/16 v3, 0x9

    aput-object v1, v0, v3

    .line 157
    nop

    .line 159
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v2, v2, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/16 v3, 0xa

    aput-object v1, v0, v3

    .line 157
    nop

    .line 159
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v2, v4, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/16 v5, 0xb

    aput-object v1, v0, v5

    .line 157
    nop

    .line 159
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v1, v4, v2, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    const/16 v2, 0xc

    aput-object v1, v0, v2

    .line 157
    nop

    .line 156
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 160
    nop

    .local v0, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 288
    .local v1, "$i$f$map\\1\\160":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 289
    .local v4, "$i$f$mapTo\\2\\288":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_a8
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_be

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 290
    .local v6, "item\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v7, "it\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v8, 0x0

    .line 160
    .local v8, "$i$a$-map-CollisionMeshes$DIRS$1\\3\\290\\0":I
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    .line 290
    .end local v7    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "$i$a$-map-CollisionMeshes$DIRS$1\\3\\290\\0":I
    invoke-interface {v2, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_a8

    .line 291
    .end local v6    # "item\\2":Ljava/lang/Object;
    :cond_be
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapTo\\2\\288":I
    check-cast v2, Ljava/util/List;

    .line 288
    nop

    .line 160
    .end local v0    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map\\1\\160":I
    sput-object v2, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->DIRS:Ljava/util/List;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final build(JLjava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/CFrame;Z)Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .registers 30
    .param p1, "key"    # J
    .param p3, "src"    # Ljava/util/List;
    .param p4, "center"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p5, "scale"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p6, "cf"    # Lcom/exampletest/mobilestudiotest/model/CFrame;
    .param p7, "hull"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/util/List<",
            "[F>;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/CFrame;",
            "Z)",
            "Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;"
        }
    .end annotation

    .line 124
    move-object/from16 v0, p6

    move-object/from16 v1, p3

    check-cast v1, Ljava/lang/Iterable;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v3, 0x0

    :goto_b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [F

    .line 269
    nop

    .local v4, "it\\1":[F
    const/4 v5, 0x0

    .line 124
    .local v5, "$i$a$-sumOfInt-CollisionMeshes$build$n$1\\1\\124\\0":I
    array-length v6, v4

    div-int/lit8 v6, v6, 0x18

    .end local v4    # "it\\1":[F
    .end local v5    # "$i$a$-sumOfInt-CollisionMeshes$build$n$1\\1\\124\\0":I
    add-int/2addr v3, v6

    goto :goto_b

    .line 125
    .local v3, "n":I
    :cond_1e
    mul-int/lit8 v1, v3, 0x9

    new-array v7, v1, [F

    .line 126
    .local v7, "pos":[F
    mul-int/lit8 v1, v3, 0x3

    new-array v8, v1, [F

    .line 127
    .local v8, "nrm":[F
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const v4, 0x7f7fffff    # Float.MAX_VALUE

    invoke-direct {v1, v4, v4, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .local v1, "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    .line 128
    .local v4, "mx":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v5, 0x0

    .line 129
    .local v5, "t":I
    invoke-interface/range {p3 .. p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    move v9, v5

    .end local v5    # "t":I
    .local v9, "t":I
    :goto_38
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_17d

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [F

    .line 130
    .local v5, "arr":[F
    const/4 v10, 0x0

    .line 131
    .local v10, "o":I
    :goto_45
    add-int/lit8 v11, v10, 0x18

    array-length v12, v5

    if-gt v11, v12, :cond_177

    .line 132
    const/4 v11, 0x3

    new-array v12, v11, [Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/4 v13, 0x0

    :goto_4e
    if-ge v13, v11, :cond_96

    .line 133
    mul-int/lit8 v14, v13, 0x8

    add-int/2addr v14, v10

    .line 134
    .local v14, "b":I
    new-instance v15, Lcom/exampletest/mobilestudiotest/model/Vector3;

    aget v16, v5, v14

    invoke-virtual/range {p4 .. p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v17

    sub-float v16, v16, v17

    invoke-virtual/range {p5 .. p5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v17

    const/16 v18, 0x0

    mul-float v2, v16, v17

    add-int/lit8 v16, v14, 0x1

    aget v16, v5, v16

    invoke-virtual/range {p4 .. p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v17

    sub-float v16, v16, v17

    invoke-virtual/range {p5 .. p5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v17

    mul-float v11, v16, v17

    add-int/lit8 v16, v14, 0x2

    aget v16, v5, v16

    invoke-virtual/range {p4 .. p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v17

    sub-float v16, v16, v17

    invoke-virtual/range {p5 .. p5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v17

    move-object/from16 v20, v1

    .end local v1    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v20, "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    mul-float v1, v16, v17

    invoke-direct {v15, v2, v11, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v0, v15}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .end local v14    # "b":I
    aput-object v1, v12, v13

    .line 132
    add-int/lit8 v13, v13, 0x1

    move-object/from16 v1, v20

    const/4 v11, 0x3

    goto :goto_4e

    .end local v20    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v1    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_96
    move-object/from16 v20, v1

    const/16 v18, 0x0

    .line 137
    .end local v1    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v12, "w":[Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v20    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v1, 0x1

    aget-object v2, v12, v1

    aget-object v11, v12, v18

    invoke-virtual {v2, v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    const/4 v11, 0x2

    aget-object v13, v12, v11

    aget-object v14, v12, v18

    invoke-virtual {v13, v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v13

    invoke-virtual {v2, v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->cross(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    .line 138
    .local v2, "fn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v13, Lcom/exampletest/mobilestudiotest/model/Vector3;

    add-int/lit8 v14, v10, 0x3

    aget v14, v5, v14

    add-int/lit8 v15, v10, 0xb

    aget v15, v5, v15

    add-float/2addr v14, v15

    add-int/lit8 v15, v10, 0x13

    aget v15, v5, v15

    add-float/2addr v14, v15

    add-int/lit8 v15, v10, 0x4

    aget v15, v5, v15

    add-int/lit8 v16, v10, 0xc

    aget v16, v5, v16

    add-float v15, v15, v16

    add-int/lit8 v16, v10, 0x14

    aget v16, v5, v16

    add-float v15, v15, v16

    add-int/lit8 v16, v10, 0x5

    aget v16, v5, v16

    add-int/lit8 v17, v10, 0xd

    aget v17, v5, v17

    add-float v16, v16, v17

    add-int/lit8 v17, v10, 0x15

    aget v17, v5, v17

    move/from16 v21, v1

    add-float v1, v16, v17

    invoke-direct {v13, v14, v15, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v0, v13}, Lcom/exampletest/mobilestudiotest/model/CFrame;->vectorToWorld(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .line 139
    .local v1, "vn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v13

    const/4 v14, 0x0

    cmpg-float v13, v13, v14

    if-gez v13, :cond_f6

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    .line 140
    :cond_f6
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v13

    .line 141
    .local v13, "len":F
    add-int/lit8 v10, v10, 0x18

    .line 142
    const v14, 0x3089705f    # 1.0E-9f

    cmpg-float v14, v13, v14

    if-ltz v14, :cond_173

    .line 143
    invoke-virtual {v2, v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    .line 144
    const/4 v14, 0x0

    move v15, v14

    move-object v14, v4

    move-object/from16 v4, v20

    .end local v20    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v4, "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v14, "mx":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v15, "v":I
    :goto_10c
    move/from16 v16, v11

    const/4 v11, 0x3

    if-ge v15, v11, :cond_150

    mul-int/lit8 v17, v9, 0x9

    mul-int/lit8 v19, v15, 0x3

    add-int v17, v17, v19

    aget-object v19, v12, v15

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v19

    aput v19, v7, v17

    mul-int/lit8 v17, v9, 0x9

    mul-int/lit8 v19, v15, 0x3

    add-int v17, v17, v19

    add-int/lit8 v17, v17, 0x1

    aget-object v19, v12, v15

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v19

    aput v19, v7, v17

    mul-int/lit8 v17, v9, 0x9

    mul-int/lit8 v19, v15, 0x3

    add-int v17, v17, v19

    add-int/lit8 v17, v17, 0x2

    aget-object v19, v12, v15

    invoke-virtual/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v19

    aput v19, v7, v17

    aget-object v11, v12, v15

    invoke-virtual {v4, v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->min(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    aget-object v11, v12, v15

    invoke-virtual {v14, v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->max(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    add-int/lit8 v15, v15, 0x1

    move/from16 v11, v16

    goto :goto_10c

    .line 145
    .end local v15    # "v":I
    :cond_150
    mul-int/lit8 v11, v9, 0x3

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v15

    aput v15, v8, v11

    mul-int/lit8 v11, v9, 0x3

    add-int/lit8 v11, v11, 0x1

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v15

    aput v15, v8, v11

    mul-int/lit8 v11, v9, 0x3

    add-int/lit8 v11, v11, 0x2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v15

    aput v15, v8, v11

    .line 146
    nop

    .end local v1    # "vn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v2    # "fn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v12    # "w":[Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v13    # "len":F
    add-int/lit8 v9, v9, 0x1

    move-object v1, v4

    move-object v4, v14

    goto/16 :goto_45

    .line 142
    .end local v14    # "mx":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v1    # "vn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v2    # "fn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v4, "mx":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v12    # "w":[Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v13    # "len":F
    .restart local v20    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_173
    move-object/from16 v1, v20

    goto/16 :goto_45

    .line 131
    .end local v2    # "fn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v12    # "w":[Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v13    # "len":F
    .end local v20    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v1, "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_177
    move-object/from16 v20, v1

    const/16 v18, 0x0

    .end local v1    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v20    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    goto/16 :goto_38

    .line 149
    .end local v5    # "arr":[F
    .end local v10    # "o":I
    .end local v20    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v1    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_17d
    if-nez v9, :cond_187

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    :cond_187
    move-object v10, v1

    move-object v11, v4

    .line 150
    .end local v1    # "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v4    # "mx":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v10, "mn":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v11, "mx":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v4, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;

    move-wide/from16 v5, p1

    invoke-direct/range {v4 .. v11}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;-><init>(J[F[FILcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    .line 151
    .local v4, "m":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    if-eqz p7, :cond_19e

    if-lez v9, :cond_19e

    move-object/from16 v1, p0

    invoke-direct {v1, v7, v9, v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->hullOf([FILcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/engine/ConvexShape;

    move-result-object v2

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->setHull(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;)V

    goto :goto_1a0

    :cond_19e
    move-object/from16 v1, p0

    .line 152
    :goto_1a0
    return-object v4
.end method

.method public static synthetic forPart$default(Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;Lcom/exampletest/mobilestudiotest/model/Instance;ZILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .registers 5

    .line 83
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_5

    const/4 p2, 0x0

    :cond_5
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->forPart(Lcom/exampletest/mobilestudiotest/model/Instance;Z)Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;

    move-result-object p0

    return-object p0
.end method

.method private static final forPart$k(FF)F
    .registers 3
    .param p0, "a"    # F
    .param p1, "b"    # F

    .line 93
    const v0, 0x3727c5ac    # 1.0E-5f

    cmpl-float v0, p1, v0

    if-lez v0, :cond_a

    div-float v0, p0, p1

    goto :goto_c

    :cond_a
    const/high16 v0, 0x3f800000    # 1.0f

    :goto_c
    return v0
.end method

.method private final hullOf([FILcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    .registers 19
    .param p1, "pos"    # [F
    .param p2, "count"    # I
    .param p3, "cf"    # Lcom/exampletest/mobilestudiotest/model/CFrame;

    .line 163
    sget-object v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->DIRS:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 270
    .local v1, "$i$f$map\\1\\163":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 271
    .local v4, "$i$f$mapTo\\2\\270":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_18
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_30

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 272
    .local v6, "item\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v7, "it\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v8, 0x0

    .line 163
    .local v8, "$i$a$-map-CollisionMeshes$hullOf$dirs$1\\3\\272\\0":I
    move-object/from16 v9, p3

    invoke-virtual {v9, v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->vectorToWorld(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    .line 272
    .end local v7    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "$i$a$-map-CollisionMeshes$hullOf$dirs$1\\3\\272\\0":I
    invoke-interface {v2, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_18

    .line 273
    .end local v6    # "item\\2":Ljava/lang/Object;
    :cond_30
    move-object/from16 v9, p3

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapTo\\2\\270":I
    check-cast v2, Ljava/util/List;

    .line 270
    nop

    .line 163
    .end local v0    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map\\1\\163":I
    nop

    .line 164
    .local v2, "dirs":Ljava/util/List;
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 165
    .local v0, "extremes":Ljava/util/LinkedHashSet;
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_3f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_91

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 166
    .local v3, "d":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const v4, 0x7f7fffff    # Float.MAX_VALUE

    .local v4, "lo":F
    const v5, -0x800001

    .local v5, "hi":F
    sget-object v6, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    .local v6, "a":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v7, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    .line 167
    .local v7, "b":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v8, 0x0

    .local v8, "i":I
    mul-int/lit8 v10, p2, 0x3

    :goto_60
    if-ge v8, v10, :cond_8a

    .line 168
    new-instance v11, Lcom/exampletest/mobilestudiotest/model/Vector3;

    mul-int/lit8 v12, v8, 0x3

    aget v12, p1, v12

    mul-int/lit8 v13, v8, 0x3

    add-int/lit8 v13, v13, 0x1

    aget v13, p1, v13

    mul-int/lit8 v14, v8, 0x3

    add-int/lit8 v14, v14, 0x2

    aget v14, p1, v14

    invoke-direct {v11, v12, v13, v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 169
    .local v11, "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v11, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v12

    .line 170
    .local v12, "s":F
    cmpg-float v13, v12, v4

    if-gez v13, :cond_81

    move v4, v12

    move-object v6, v11

    .line 171
    :cond_81
    cmpl-float v13, v12, v5

    if-lez v13, :cond_87

    move v5, v12

    move-object v7, v11

    .line 167
    .end local v11    # "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v12    # "s":F
    :cond_87
    add-int/lit8 v8, v8, 0x1

    goto :goto_60

    .line 173
    .end local v8    # "i":I
    :cond_8a
    invoke-virtual {v0, v6}, Ljava/util/LinkedHashSet;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0, v7}, Ljava/util/LinkedHashSet;->add(Ljava/lang/Object;)Z

    .end local v4    # "lo":F
    .end local v5    # "hi":F
    .end local v6    # "a":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v7    # "b":Lcom/exampletest/mobilestudiotest/model/Vector3;
    goto :goto_3f

    .line 175
    .end local v3    # "d":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_91
    new-instance v1, Lcom/exampletest/mobilestudiotest/engine/ConvexShape;

    move-object v3, v0

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v3

    invoke-direct {v1, v3, v2, v2}, Lcom/exampletest/mobilestudiotest/engine/ConvexShape;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    return-object v1
.end method

.method private final overlaps(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Z
    .registers 15
    .param p1, "s"    # Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    .param p2, "a"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "b"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p4, "c"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p5, "n"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 222
    invoke-static {p1, p2, p3, p4, p5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->overlaps$sep(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    return v1

    .line 223
    :cond_8
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/engine/ConvexShape;->getNormals()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_23

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v2, "ax":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-static {p1, p2, p3, p4, v2}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->overlaps$sep(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Z

    move-result v3

    if-eqz v3, :cond_10

    return v1

    .line 224
    .end local v2    # "ax":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_23
    const/4 v0, 0x3

    new-array v0, v0, [Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {p3, p2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-virtual {p4, p3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    const/4 v3, 0x1

    aput-object v2, v0, v3

    const/4 v2, 0x2

    invoke-virtual {p2, p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    aput-object v4, v0, v2

    .line 225
    .local v0, "edges":[Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/engine/ConvexShape;->getEdges()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_42
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_62

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v4, "e":Lcom/exampletest/mobilestudiotest/model/Vector3;
    array-length v5, v0

    move v6, v1

    :goto_50
    if-ge v6, v5, :cond_42

    aget-object v7, v0, v6

    .local v7, "te":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v4, v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->cross(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-static {p1, p2, p3, p4, v8}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->overlaps$sep(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Z

    move-result v8

    if-eqz v8, :cond_5f

    return v1

    .end local v7    # "te":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_5f
    add-int/lit8 v6, v6, 0x1

    goto :goto_50

    .line 226
    .end local v4    # "e":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_62
    return v3
.end method

.method private static final overlaps$sep(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Z
    .registers 13
    .param p0, "$s"    # Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    .param p1, "$a"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "$b"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "$c"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p4, "axis"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 216
    invoke-virtual {p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v0

    .line 217
    .local v0, "l":F
    const v1, 0x358637bd    # 1.0E-6f

    cmpg-float v1, v0, v1

    const/4 v2, 0x0

    if-gez v1, :cond_d

    return v2

    .line 218
    :cond_d
    invoke-virtual {p0, p4}, Lcom/exampletest/mobilestudiotest/engine/ConvexShape;->project(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lkotlin/Pair;

    move-result-object v1

    invoke-virtual {v1}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v3

    .local v3, "s0":F
    invoke-virtual {v1}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    .line 219
    .local v1, "s1":F
    invoke-virtual {p1, p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v4

    .local v4, "ta":F
    invoke-virtual {p2, p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v5

    .local v5, "tb":F
    invoke-virtual {p3, p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v6

    .line 220
    .local v6, "tc":F
    invoke-static {v5, v6}, Ljava/lang/Math;->min(FF)F

    move-result v7

    invoke-static {v4, v7}, Ljava/lang/Math;->min(FF)F

    move-result v7

    cmpg-float v7, v1, v7

    if-ltz v7, :cond_4a

    invoke-static {v5, v6}, Ljava/lang/Math;->max(FF)F

    move-result v7

    invoke-static {v4, v7}, Ljava/lang/Math;->max(FF)F

    move-result v7

    cmpl-float v7, v3, v7

    if-gtz v7, :cond_4a

    goto :goto_4b

    :cond_4a
    const/4 v2, 0x1

    :goto_4b
    return v2
.end method

.method static final ray$lambda$9([FLcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/internal/Ref$FloatRef;FLkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;I)Lkotlin/Unit;
    .registers 38
    .param p0, "$p"    # [F
    .param p1, "$d"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "$o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "$best"    # Lkotlin/jvm/internal/Ref$FloatRef;
    .param p4, "$maxDist"    # F
    .param p5, "$bestN"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p6, "$m"    # Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .param p7, "t"    # I

    .line 238
    move-object/from16 v0, p3

    mul-int/lit8 v1, p7, 0x9

    .line 239
    .local v1, "o9":I
    aget v2, p0, v1

    .local v2, "ax":F
    add-int/lit8 v3, v1, 0x1

    aget v3, p0, v3

    .local v3, "ay":F
    add-int/lit8 v4, v1, 0x2

    aget v4, p0, v4

    .line 240
    .local v4, "az":F
    add-int/lit8 v5, v1, 0x3

    aget v5, p0, v5

    sub-float/2addr v5, v2

    .local v5, "e1x":F
    add-int/lit8 v6, v1, 0x4

    aget v6, p0, v6

    sub-float/2addr v6, v3

    .local v6, "e1y":F
    add-int/lit8 v7, v1, 0x5

    aget v7, p0, v7

    sub-float/2addr v7, v4

    .line 241
    .local v7, "e1z":F
    add-int/lit8 v8, v1, 0x6

    aget v8, p0, v8

    sub-float/2addr v8, v2

    .local v8, "e2x":F
    add-int/lit8 v9, v1, 0x7

    aget v9, p0, v9

    sub-float/2addr v9, v3

    .local v9, "e2y":F
    add-int/lit8 v10, v1, 0x8

    aget v10, p0, v10

    sub-float/2addr v10, v4

    .line 242
    .local v10, "e2z":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v11

    mul-float/2addr v11, v10

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v12

    mul-float/2addr v12, v9

    sub-float/2addr v11, v12

    .local v11, "px":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v12

    mul-float/2addr v12, v8

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v13

    mul-float/2addr v13, v10

    sub-float/2addr v12, v13

    .local v12, "py":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v13

    mul-float/2addr v13, v9

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v14

    mul-float/2addr v14, v8

    sub-float/2addr v13, v14

    .line 243
    .local v13, "pz":F
    mul-float v14, v5, v11

    mul-float v15, v6, v12

    add-float/2addr v14, v15

    mul-float v15, v7, v13

    add-float/2addr v14, v15

    .line 244
    .local v14, "det":F
    invoke-static {v14}, Ljava/lang/Math;->abs(F)F

    move-result v15

    const v16, 0x3089705f    # 1.0E-9f

    cmpl-float v15, v15, v16

    if-lez v15, :cond_132

    .line 245
    const/high16 v15, 0x3f800000    # 1.0f

    div-float v16, v15, v14

    .line 246
    .local v16, "inv":F
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v17

    sub-float v17, v17, v2

    .local v17, "tx":F
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v18

    sub-float v18, v18, v3

    .local v18, "ty":F
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v19

    sub-float v19, v19, v4

    .line 247
    .local v19, "tz":F
    mul-float v20, v17, v11

    mul-float v21, v18, v12

    add-float v20, v20, v21

    mul-float v21, v19, v13

    add-float v20, v20, v21

    mul-float v20, v20, v16

    .line 248
    .local v20, "u":F
    const/16 v21, 0x0

    cmpg-float v22, v21, v20

    const/16 v23, 0x0

    const/16 v24, 0x1

    if-gtz v22, :cond_92

    cmpg-float v22, v20, v15

    if-gtz v22, :cond_92

    move/from16 v23, v24

    :cond_92
    if-eqz v23, :cond_129

    .line 249
    mul-float v22, v18, v7

    mul-float v23, v19, v6

    sub-float v22, v22, v23

    .local v22, "qx":F
    mul-float v23, v19, v5

    mul-float v25, v17, v7

    sub-float v23, v23, v25

    .local v23, "qy":F
    mul-float v25, v17, v6

    mul-float v26, v18, v5

    sub-float v25, v25, v26

    .line 250
    .local v25, "qz":F
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v26

    mul-float v26, v26, v22

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v27

    mul-float v27, v27, v23

    add-float v26, v26, v27

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v27

    mul-float v27, v27, v25

    add-float v26, v26, v27

    mul-float v26, v26, v16

    .line 251
    .local v26, "v":F
    cmpl-float v27, v26, v21

    if-ltz v27, :cond_120

    add-float v27, v20, v26

    cmpg-float v15, v27, v15

    if-gtz v15, :cond_120

    .line 252
    mul-float v15, v8, v22

    mul-float v27, v9, v23

    add-float v15, v15, v27

    mul-float v27, v10, v25

    add-float v15, v15, v27

    mul-float v15, v15, v16

    .line 253
    .local v15, "dist":F
    cmpl-float v21, v15, v21

    if-ltz v21, :cond_117

    move/from16 v21, v1

    .end local v1    # "o9":I
    .local v21, "o9":I
    iget v1, v0, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    cmpg-float v1, v15, v1

    if-gez v1, :cond_110

    cmpg-float v1, v15, p4

    if-gtz v1, :cond_110

    iput v15, v0, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual/range {p6 .. p6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNrm()[F

    move-result-object v27

    mul-int/lit8 v28, p7, 0x3

    aget v0, v27, v28

    invoke-virtual/range {p6 .. p6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNrm()[F

    move-result-object v27

    mul-int/lit8 v28, p7, 0x3

    add-int/lit8 v28, v28, 0x1

    move/from16 v24, v2

    .end local v2    # "ax":F
    .local v24, "ax":F
    aget v2, v27, v28

    invoke-virtual/range {p6 .. p6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNrm()[F

    move-result-object v27

    mul-int/lit8 v28, p7, 0x3

    add-int/lit8 v28, v28, 0x2

    move/from16 v29, v3

    .end local v3    # "ay":F
    .local v29, "ay":F
    aget v3, v27, v28

    invoke-direct {v1, v0, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    move-object/from16 v0, p5

    iput-object v1, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    goto :goto_13a

    .end local v24    # "ax":F
    .end local v29    # "ay":F
    .restart local v2    # "ax":F
    .restart local v3    # "ay":F
    :cond_110
    move-object/from16 v0, p5

    move/from16 v24, v2

    move/from16 v29, v3

    .end local v2    # "ax":F
    .end local v3    # "ay":F
    .restart local v24    # "ax":F
    .restart local v29    # "ay":F
    goto :goto_13a

    .end local v21    # "o9":I
    .end local v24    # "ax":F
    .end local v29    # "ay":F
    .restart local v1    # "o9":I
    .restart local v2    # "ax":F
    .restart local v3    # "ay":F
    :cond_117
    move-object/from16 v0, p5

    move/from16 v21, v1

    move/from16 v24, v2

    move/from16 v29, v3

    .end local v1    # "o9":I
    .end local v2    # "ax":F
    .end local v3    # "ay":F
    .restart local v21    # "o9":I
    .restart local v24    # "ax":F
    .restart local v29    # "ay":F
    goto :goto_13a

    .line 251
    .end local v15    # "dist":F
    .end local v21    # "o9":I
    .end local v24    # "ax":F
    .end local v29    # "ay":F
    .restart local v1    # "o9":I
    .restart local v2    # "ax":F
    .restart local v3    # "ay":F
    :cond_120
    move-object/from16 v0, p5

    move/from16 v21, v1

    move/from16 v24, v2

    move/from16 v29, v3

    .end local v1    # "o9":I
    .end local v2    # "ax":F
    .end local v3    # "ay":F
    .restart local v21    # "o9":I
    .restart local v24    # "ax":F
    .restart local v29    # "ay":F
    goto :goto_13a

    .line 248
    .end local v21    # "o9":I
    .end local v22    # "qx":F
    .end local v23    # "qy":F
    .end local v24    # "ax":F
    .end local v25    # "qz":F
    .end local v26    # "v":F
    .end local v29    # "ay":F
    .restart local v1    # "o9":I
    .restart local v2    # "ax":F
    .restart local v3    # "ay":F
    :cond_129
    move-object/from16 v0, p5

    move/from16 v21, v1

    move/from16 v24, v2

    move/from16 v29, v3

    .end local v1    # "o9":I
    .end local v2    # "ax":F
    .end local v3    # "ay":F
    .restart local v21    # "o9":I
    .restart local v24    # "ax":F
    .restart local v29    # "ay":F
    goto :goto_13a

    .line 244
    .end local v16    # "inv":F
    .end local v17    # "tx":F
    .end local v18    # "ty":F
    .end local v19    # "tz":F
    .end local v20    # "u":F
    .end local v21    # "o9":I
    .end local v24    # "ax":F
    .end local v29    # "ay":F
    .restart local v1    # "o9":I
    .restart local v2    # "ax":F
    .restart local v3    # "ay":F
    :cond_132
    move-object/from16 v0, p5

    move/from16 v21, v1

    move/from16 v24, v2

    move/from16 v29, v3

    .line 257
    .end local v1    # "o9":I
    .end local v2    # "ax":F
    .end local v3    # "ay":F
    .restart local v21    # "o9":I
    .restart local v24    # "ax":F
    .restart local v29    # "ay":F
    :goto_13a
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method


# virtual methods
.method public final fidelity(Lcom/exampletest/mobilestudiotest/model/Instance;)I
    .registers 4
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "p"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    const-string v0, "CollisionFidelity"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v1, :cond_12

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    if-eqz v0, :cond_1a

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v0

    goto :goto_1b

    :cond_1a
    const/4 v0, 0x0

    :goto_1b
    return v0
.end method

.method public final forPart(Lcom/exampletest/mobilestudiotest/model/Instance;Z)Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .registers 24
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "forRays"    # Z

    move-object/from16 v1, p1

    const-string v0, "p"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    invoke-virtual/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->hasGeometry(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    const/4 v2, 0x0

    if-nez v0, :cond_f

    return-object v2

    .line 85
    :cond_f
    const/4 v0, 0x2

    if-nez p2, :cond_19

    invoke-virtual/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->fidelity(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v3

    if-ne v3, v0, :cond_19

    return-object v2

    .line 86
    :cond_19
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v10

    .line 87
    .local v10, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    .line 89
    .local v3, "size":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v4, 0x0

    .line 90
    .local v4, "src":Ljava/util/List;
    const/4 v5, 0x0

    .line 91
    .local v5, "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v6, 0x0

    .line 92
    .local v6, "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const-wide/16 v7, 0x0

    .line 94
    .local v7, "srcKey":J
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v9

    const-string v11, "MeshPart"

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-eqz v9, :cond_a5

    .line 95
    sget-object v9, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    sget-object v13, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v13, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->meshContent(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v9, v13}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->idOf(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object v9

    if-eqz v9, :cond_a4

    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    .line 96
    .local v13, "id":J
    sget-object v9, Lcom/exampletest/mobilestudiotest/render/MeshLoader;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/MeshLoader;

    invoke-virtual {v9, v13, v14}, Lcom/exampletest/mobilestudiotest/render/MeshLoader;->get(J)Lcom/exampletest/mobilestudiotest/render/MeshData;

    move-result-object v9

    if-nez v9, :cond_53

    return-object v2

    .line 97
    .local v9, "m":Lcom/exampletest/mobilestudiotest/render/MeshData;
    :cond_53
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/MeshData;->getTriangles()I

    move-result v15

    if-nez v15, :cond_5a

    return-object v2

    .line 98
    :cond_5a
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/MeshData;->getVerts()[F

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    .line 99
    .end local v4    # "src":Ljava/util/List;
    .local v2, "src":Ljava/util/List;
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/render/MeshData;->center(I)F

    move-result v15

    invoke-virtual {v9, v12}, Lcom/exampletest/mobilestudiotest/render/MeshData;->center(I)F

    move-result v11

    invoke-virtual {v9, v0}, Lcom/exampletest/mobilestudiotest/render/MeshData;->center(I)F

    move-result v12

    invoke-direct {v4, v15, v11, v12}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 100
    .end local v5    # "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v4, "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v11

    const/4 v12, 0x0

    invoke-virtual {v9, v12}, Lcom/exampletest/mobilestudiotest/render/MeshData;->size(I)F

    move-result v15

    invoke-static {v11, v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->forPart$k(FF)F

    move-result v11

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v15

    const/4 v12, 0x1

    invoke-virtual {v9, v12}, Lcom/exampletest/mobilestudiotest/render/MeshData;->size(I)F

    move-result v0

    invoke-static {v15, v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->forPart$k(FF)F

    move-result v0

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v12

    const/4 v15, 0x2

    invoke-virtual {v9, v15}, Lcom/exampletest/mobilestudiotest/render/MeshData;->size(I)F

    move-result v15

    invoke-static {v12, v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->forPart$k(FF)F

    move-result v12

    invoke-direct {v5, v11, v0, v12}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 101
    .end local v6    # "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v5, "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object v7, v2

    move-object v8, v4

    move-object v9, v5

    .end local v7    # "srcKey":J
    .end local v9    # "m":Lcom/exampletest/mobilestudiotest/render/MeshData;
    .local v13, "srcKey":J
    goto/16 :goto_169

    .line 95
    .end local v2    # "src":Ljava/util/List;
    .end local v13    # "srcKey":J
    .local v4, "src":Ljava/util/List;
    .local v5, "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v6    # "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v7    # "srcKey":J
    :cond_a4
    return-object v2

    .line 103
    :cond_a5
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/SolidModeling;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->result(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;

    move-result-object v0

    .line 104
    .local v0, "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    if-eqz v0, :cond_d0

    .line 105
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;->getTris()Ljava/util/Map;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    .end local v4    # "src":Ljava/util/List;
    .restart local v2    # "src":Ljava/util/List;
    sget-object v4, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    .end local v5    # "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v4, "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v5, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/SolidModeling;

    invoke-virtual {v5, v1, v0}, Lcom/exampletest/mobilestudiotest/core/SolidModeling;->scaleOf(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    .end local v6    # "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v5, "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;->getSig()J

    move-result-wide v13

    move-object v7, v2

    move-object v8, v4

    move-object v9, v5

    .end local v7    # "srcKey":J
    .restart local v13    # "srcKey":J
    goto/16 :goto_169

    .line 107
    .end local v2    # "src":Ljava/util/List;
    .end local v13    # "srcKey":J
    .local v4, "src":Ljava/util/List;
    .local v5, "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v6    # "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v7    # "srcKey":J
    :cond_d0
    sget-object v9, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-virtual {v9, v1}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->isStored(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v9

    if-nez v9, :cond_d9

    return-object v2

    .line 108
    :cond_d9
    sget-object v9, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/render/UnionMeshes;

    invoke-virtual {v9, v1}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes;->get(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;

    move-result-object v9

    if-nez v9, :cond_e2

    return-object v2

    .line 109
    .local v9, "d":Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;
    :cond_e2
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->getGroups()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 265
    .local v11, "$i$f$map\\1\\109":I
    new-instance v12, Ljava/util/ArrayList;

    const/16 v13, 0xa

    invoke-static {v2, v13}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v13

    invoke-direct {v12, v13}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v12, Ljava/util/Collection;

    .local v12, "destination\\2":Ljava/util/Collection;
    move-object v13, v2

    .local v13, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 266
    .local v14, "$i$f$mapTo\\2\\265":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_fc
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_11c

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    .line 267
    .local v16, "item\\2":Ljava/lang/Object;
    move-object/from16 v17, v16

    check-cast v17, Lkotlin/Pair;

    .local v17, "it\\3":Lkotlin/Pair;
    const/16 v18, 0x0

    .line 109
    .local v18, "$i$a$-map-CollisionMeshes$forPart$1\\3\\267\\0":I
    invoke-virtual/range {v17 .. v17}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v19

    move-object/from16 v20, v0

    .end local v0    # "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    .local v20, "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    move-object/from16 v0, v19

    check-cast v0, [F

    .line 267
    .end local v17    # "it\\3":Lkotlin/Pair;
    .end local v18    # "$i$a$-map-CollisionMeshes$forPart$1\\3\\267\\0":I
    invoke-interface {v12, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, v20

    goto :goto_fc

    .line 268
    .end local v16    # "item\\2":Ljava/lang/Object;
    .end local v20    # "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    .restart local v0    # "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    :cond_11c
    move-object/from16 v20, v0

    .end local v0    # "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    .end local v12    # "destination\\2":Ljava/util/Collection;
    .end local v13    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v14    # "$i$f$mapTo\\2\\265":I
    .restart local v20    # "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    move-object v0, v12

    check-cast v0, Ljava/util/List;

    .line 265
    nop

    .line 109
    .end local v2    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v11    # "$i$f$map\\1\\109":I
    move-object v2, v0

    .end local v4    # "src":Ljava/util/List;
    .local v2, "src":Ljava/util/List;
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    .line 110
    .end local v5    # "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v4, "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->getSize()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-virtual {v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v11

    invoke-static {v5, v11}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->forPart$k(FF)F

    move-result v5

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v11

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->getSize()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v12

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v12

    invoke-static {v11, v12}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->forPart$k(FF)F

    move-result v11

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v12

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->getSize()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v13

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v13

    invoke-static {v12, v13}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->forPart$k(FF)F

    move-result v12

    invoke-direct {v0, v5, v11, v12}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    move-object v5, v0

    .line 111
    .end local v6    # "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v5, "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/render/UnionMeshes$Data;->getKey()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    int-to-long v13, v0

    move-object v7, v2

    move-object v8, v4

    move-object v9, v5

    .line 114
    .end local v2    # "src":Ljava/util/List;
    .end local v4    # "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v5    # "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v20    # "r":Lcom/exampletest/mobilestudiotest/core/SolidModeling$Result;
    .local v7, "src":Ljava/util/List;
    .local v8, "center":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v9, "scale":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v13, "srcKey":J
    :goto_169
    const-wide/16 v4, 0x1f

    mul-long v11, v13, v4

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/CFrame;->hashCode()I

    move-result v0

    move-wide/from16 v16, v4

    int-to-long v4, v0

    add-long/2addr v11, v4

    mul-long v11, v11, v16

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->hashCode()I

    move-result v0

    int-to-long v4, v0

    add-long/2addr v11, v4

    mul-long v11, v11, v16

    invoke-virtual/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->fidelity(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v0

    int-to-long v4, v0

    add-long v5, v11, v4

    .line 115
    .local v5, "key":J
    sget-object v2, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->cache:Ljava/util/WeakHashMap;

    monitor-enter v2

    const/4 v0, 0x0

    .line 116
    .local v0, "$i$a$-synchronized-CollisionMeshes$forPart$2\\4\\115\\0":I
    :try_start_18a
    sget-object v4, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->cache:Ljava/util/WeakHashMap;

    invoke-virtual {v4, v1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;

    if-eqz v4, :cond_19f

    .line 269
    .local v4, "it\\5":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    const/4 v11, 0x0

    .line 116
    .local v11, "$i$a$-let-CollisionMeshes$forPart$2$1\\5\\116\\4":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getKey()J

    move-result-wide v16
    :try_end_199
    .catchall {:try_start_18a .. :try_end_199} :catchall_1bb

    cmp-long v12, v16, v5

    if-nez v12, :cond_19f

    .end local v0    # "$i$a$-synchronized-CollisionMeshes$forPart$2\\4\\115\\0":I
    .end local v4    # "it\\5":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .end local v11    # "$i$a$-let-CollisionMeshes$forPart$2$1\\5\\116\\4":I
    monitor-exit v2

    return-object v4

    .line 117
    .restart local v0    # "$i$a$-synchronized-CollisionMeshes$forPart$2\\4\\115\\0":I
    :cond_19f
    :try_start_19f
    sget-object v4, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;

    sget-object v11, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;

    invoke-virtual {v11, v1}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->fidelity(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v11

    const/4 v12, 0x1

    if-ne v11, v12, :cond_1ac

    move v11, v12

    goto :goto_1ad

    :cond_1ac
    const/4 v11, 0x0

    :goto_1ad
    invoke-direct/range {v4 .. v11}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->build(JLjava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/CFrame;Z)Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;

    move-result-object v4

    .line 118
    .local v4, "built\\4":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    sget-object v11, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->cache:Ljava/util/WeakHashMap;

    check-cast v11, Ljava/util/Map;

    invoke-interface {v11, v1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1b8
    .catchall {:try_start_19f .. :try_end_1b8} :catchall_1bb

    .line 119
    nop

    .end local v0    # "$i$a$-synchronized-CollisionMeshes$forPart$2\\4\\115\\0":I
    .end local v4    # "built\\4":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    monitor-exit v2

    return-object v4

    :catchall_1bb
    move-exception v0

    monitor-exit v2

    throw v0
.end method

.method public final hasGeometry(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 4
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "p"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    const-string v0, "PartOperation"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "NegateOperation"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_25

    :cond_19
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "MeshPart"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_27

    :cond_25
    const/4 v0, 0x1

    goto :goto_28

    :cond_27
    const/4 v0, 0x0

    :goto_28
    return v0
.end method

.method public final push(Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lkotlin/Pair;
    .registers 44
    .param p1, "m"    # Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .param p2, "shape"    # Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    .param p3, "lo"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p4, "hi"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;",
            "Lcom/exampletest/mobilestudiotest/engine/ConvexShape;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            ")",
            "Lkotlin/Pair<",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    move-object/from16 v1, p2

    const-string v0, "m"

    move-object/from16 v6, p1

    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "shape"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "lo"

    move-object/from16 v7, p3

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "hi"

    move-object/from16 v8, p4

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 182
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getHull()Lcom/exampletest/mobilestudiotest/engine/ConvexShape;

    move-result-object v0

    if-eqz v0, :cond_3f

    .line 269
    .local v0, "h\\1":Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    const/4 v2, 0x0

    .line 182
    .local v2, "$i$a$-let-CollisionMeshes$push$1\\1\\182\\0":I
    sget-object v3, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v3, v1, v0}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->sat(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/engine/ConvexShape;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    if-eqz v3, :cond_3d

    .line 269
    .local v3, "it\\2":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v4, 0x0

    .line 182
    .local v4, "$i$a$-let-CollisionMeshes$push$1$1\\2\\182\\1":I
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-static {v3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v9

    .end local v3    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v4    # "$i$a$-let-CollisionMeshes$push$1$1\\2\\182\\1":I
    goto :goto_3e

    :cond_3d
    const/4 v9, 0x0

    :goto_3e
    return-object v9

    .line 183
    .end local v0    # "h\\1":Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    .end local v2    # "$i$a$-let-CollisionMeshes$push$1\\1\\182\\0":I
    :cond_3f
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/ConvexShape;->getCenter()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    .line 184
    .local v10, "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v0, 0x0

    .line 185
    .local v0, "best":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "bestLen":F
    const v2, 0x7f7fffff    # Float.MAX_VALUE

    .line 186
    const/4 v3, 0x0

    .local v3, "top":F
    const v3, -0x800001

    .line 187
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getPos()[F

    move-result-object v11

    .local v11, "p":[F
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNrm()[F

    move-result-object v12

    .line 188
    .local v12, "nr":[F
    move-object/from16 v4, p4

    .local v4, "hi\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object/from16 v13, p3

    .local v13, "lo\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object v14, v4

    .end local v4    # "hi\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v14, "hi\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object/from16 v15, p1

    .local v15, "this_\\3":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    const/16 v16, 0x0

    .line 274
    .local v16, "$i$f$forTris\\3\\188":I
    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    cmpg-float v4, v4, v5

    if-ltz v4, :cond_451

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    cmpl-float v4, v4, v5

    if-gtz v4, :cond_451

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    cmpg-float v4, v4, v5

    if-ltz v4, :cond_451

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    cmpl-float v4, v4, v5

    if-gtz v4, :cond_451

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    cmpg-float v4, v4, v5

    if-ltz v4, :cond_451

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    cmpl-float v4, v4, v5

    if-lez v4, :cond_c9

    move-object/from16 v18, v0

    move-object/from16 v31, v10

    move-object/from16 v32, v11

    move-object/from16 v33, v12

    const/16 v17, 0x0

    goto/16 :goto_45b

    .line 275
    :cond_c9
    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nextStamp()I

    move-result v4

    .line 276
    .local v4, "g\\3":I
    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    const/16 v17, 0x0

    const/4 v9, 0x0

    invoke-virtual {v15, v5, v9}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v5

    move-object/from16 v18, v0

    .end local v0    # "best":Ljava/lang/Object;
    .local v5, "i\\3":I
    .local v18, "best":Ljava/lang/Object;
    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v0

    invoke-virtual {v15, v0, v9}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v0

    if-gt v5, v0, :cond_446

    :goto_e4
    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v9

    const/4 v6, 0x1

    invoke-virtual {v15, v9, v6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v9

    move/from16 v19, v0

    .local v9, "j\\3":I
    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v0

    invoke-virtual {v15, v0, v6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v0

    if-gt v9, v0, :cond_420

    :goto_f9
    move/from16 v20, v6

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v6

    const/4 v7, 0x2

    invoke-virtual {v15, v6, v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v6

    move/from16 v21, v0

    .local v6, "k\\3":I
    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v0

    invoke-virtual {v15, v0, v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v0

    if-gt v6, v0, :cond_3f9

    .line 277
    :goto_110
    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getCells()[[I

    move-result-object v22

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNy()I

    move-result v23

    mul-int v23, v23, v5

    add-int v23, v23, v9

    invoke-virtual {v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNz()I

    move-result v24

    mul-int v23, v23, v24

    add-int v23, v23, v6

    aget-object v22, v22, v23

    if-nez v22, :cond_13a

    move/from16 v22, v7

    move-object/from16 v31, v10

    move-object/from16 v32, v11

    move-object/from16 v33, v12

    move/from16 v7, v19

    move/from16 v10, v21

    move v11, v0

    move/from16 v19, v4

    move v12, v5

    goto/16 :goto_3df

    :cond_13a
    move-object/from16 v23, v22

    .line 278
    .local v23, "list\\3":[I
    move/from16 v22, v7

    move-object/from16 v7, v23

    .end local v23    # "list\\3":[I
    .local v7, "list\\3":[I
    array-length v8, v7

    move/from16 v23, v3

    move-object/from16 v24, v18

    move/from16 v18, v2

    const/4 v2, 0x0

    .end local v2    # "bestLen":F
    .end local v3    # "top":F
    .local v18, "bestLen":F
    .local v23, "top":F
    .local v24, "best":Ljava/lang/Object;
    :goto_148
    if-ge v2, v8, :cond_3c9

    aget v3, v7, v2

    .local v3, "t\\3":I
    invoke-virtual {v15, v3, v4}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->mark(II)Z

    move-result v25

    if-eqz v25, :cond_39a

    move/from16 v25, v3

    .local v25, "t\\4":I
    const/16 v26, 0x0

    .line 189
    .local v26, "$i$a$-forTris-CollisionMeshes$push$2\\4\\278\\0":I
    mul-int/lit8 v27, v25, 0x9

    .line 190
    .local v27, "o\\4":I
    move-object/from16 v28, v7

    .end local v7    # "list\\3":[I
    .local v28, "list\\3":[I
    aget v7, v11, v27

    .local v7, "ax\\4":F
    add-int/lit8 v29, v27, 0x1

    move/from16 v30, v8

    aget v8, v11, v29

    .local v8, "ay\\4":F
    add-int/lit8 v29, v27, 0x2

    move-object/from16 v31, v10

    .end local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v31, "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    aget v10, v11, v29

    .line 192
    .local v10, "az\\4":F
    add-int/lit8 v29, v27, 0x3

    move/from16 v32, v0

    aget v0, v11, v29

    add-int/lit8 v29, v27, 0x6

    aget v1, v11, v29

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-static {v7, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual/range {p3 .. p3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v1

    cmpg-float v0, v0, v1

    if-ltz v0, :cond_382

    add-int/lit8 v0, v27, 0x3

    aget v0, v11, v0

    add-int/lit8 v1, v27, 0x6

    aget v1, v11, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-static {v7, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-virtual/range {p4 .. p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v1

    cmpl-float v0, v0, v1

    if-lez v0, :cond_1ae

    move/from16 v7, v32

    move-object/from16 v32, v11

    move v11, v7

    move/from16 v34, v2

    move/from16 v35, v3

    move-object/from16 v33, v12

    move/from16 v7, v19

    move/from16 v10, v21

    move/from16 v19, v4

    move v12, v5

    goto/16 :goto_3b0

    .line 193
    :cond_1ae
    add-int/lit8 v0, v27, 0x4

    aget v0, v11, v0

    add-int/lit8 v1, v27, 0x7

    aget v1, v11, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-static {v8, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual/range {p3 .. p3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v1

    cmpg-float v0, v0, v1

    if-ltz v0, :cond_36a

    add-int/lit8 v0, v27, 0x4

    aget v0, v11, v0

    add-int/lit8 v1, v27, 0x7

    aget v1, v11, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-static {v8, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-virtual/range {p4 .. p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v1

    cmpl-float v0, v0, v1

    if-lez v0, :cond_1f2

    move/from16 v7, v32

    move-object/from16 v32, v11

    move v11, v7

    move/from16 v34, v2

    move/from16 v35, v3

    move-object/from16 v33, v12

    move/from16 v7, v19

    move/from16 v10, v21

    move/from16 v19, v4

    move v12, v5

    goto/16 :goto_3b0

    .line 194
    :cond_1f2
    add-int/lit8 v0, v27, 0x5

    aget v0, v11, v0

    add-int/lit8 v1, v27, 0x8

    aget v1, v11, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-static {v10, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual/range {p3 .. p3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v1

    cmpg-float v0, v0, v1

    if-ltz v0, :cond_352

    add-int/lit8 v0, v27, 0x5

    aget v0, v11, v0

    add-int/lit8 v1, v27, 0x8

    aget v1, v11, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-static {v10, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-virtual/range {p4 .. p4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v1

    cmpl-float v0, v0, v1

    if-lez v0, :cond_236

    move/from16 v7, v32

    move-object/from16 v32, v11

    move v11, v7

    move/from16 v34, v2

    move/from16 v35, v3

    move-object/from16 v33, v12

    move/from16 v7, v19

    move/from16 v10, v21

    move/from16 v19, v4

    move v12, v5

    goto/16 :goto_3b0

    .line 195
    :cond_236
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    mul-int/lit8 v1, v25, 0x3

    aget v1, v12, v1

    mul-int/lit8 v29, v25, 0x3

    add-int/lit8 v29, v29, 0x1

    move/from16 v33, v2

    aget v2, v12, v29

    mul-int/lit8 v29, v25, 0x3

    add-int/lit8 v29, v29, 0x2

    move/from16 v34, v3

    .end local v3    # "t\\3":I
    .local v34, "t\\3":I
    aget v3, v12, v29

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 197
    .local v0, "n\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v1

    invoke-virtual/range {v31 .. v31}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    sub-float/2addr v2, v7

    mul-float/2addr v1, v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v2

    invoke-virtual/range {v31 .. v31}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    sub-float/2addr v3, v8

    mul-float/2addr v2, v3

    add-float/2addr v1, v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v2

    invoke-virtual/range {v31 .. v31}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    sub-float/2addr v3, v10

    mul-float/2addr v2, v3

    add-float/2addr v1, v2

    const/4 v2, 0x0

    cmpg-float v1, v1, v2

    if-ltz v1, :cond_338

    .line 198
    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v2, v7, v8, v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .local v2, "a\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    add-int/lit8 v1, v27, 0x3

    aget v1, v11, v1

    add-int/lit8 v29, v27, 0x4

    move-object/from16 v35, v0

    .end local v0    # "n\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v35, "n\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    aget v0, v11, v29

    add-int/lit8 v29, v27, 0x5

    move-object/from16 v36, v2

    .end local v2    # "a\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v36, "a\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    aget v2, v11, v29

    invoke-direct {v3, v1, v0, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .local v3, "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    add-int/lit8 v1, v27, 0x6

    aget v1, v11, v1

    add-int/lit8 v2, v27, 0x7

    aget v2, v11, v2

    add-int/lit8 v29, v27, 0x8

    move-object/from16 v37, v3

    .end local v3    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v37, "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    aget v3, v11, v29

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 199
    .local v0, "cc\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move v1, v4

    move-object v4, v0

    .end local v0    # "cc\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v1, "g\\3":I
    .local v4, "cc\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;

    move-object v2, v12

    move v12, v5

    move-object/from16 v5, v35

    move/from16 v35, v34

    move/from16 v34, v33

    move-object/from16 v33, v2

    move/from16 v2, v32

    move-object/from16 v32, v11

    move v11, v2

    move/from16 v29, v10

    move/from16 v10, v21

    move-object/from16 v2, v36

    move-object/from16 v3, v37

    move/from16 v21, v7

    move/from16 v7, v19

    move/from16 v19, v1

    move-object/from16 v1, p2

    .end local v1    # "g\\3":I
    .end local v7    # "ax\\4":F
    .end local v10    # "az\\4":F
    .end local v11    # "p":[F
    .end local v34    # "t\\3":I
    .end local v36    # "a\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v37    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v2    # "a\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v3    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v5, "n\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v12, "i\\3":I
    .local v19, "g\\3":I
    .local v21, "ax\\4":F
    .local v29, "az\\4":F
    .local v32, "p":[F
    .local v33, "nr":[F
    .local v35, "t\\3":I
    invoke-direct/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->overlaps(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Z

    move-result v0

    if-eqz v0, :cond_334

    .line 201
    const v0, 0x7f7fffff    # Float.MAX_VALUE

    .line 202
    .local v0, "deepest\\4":F
    invoke-virtual/range {p2 .. p2}, Lcom/exampletest/mobilestudiotest/engine/ConvexShape;->getVerts()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2d5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v36

    if-eqz v36, :cond_2fe

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v36

    move-object/from16 v37, v1

    move-object/from16 v1, v36

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-object/from16 v36, v3

    .end local v3    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v1, "v\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v36, "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v3

    .local v3, "d\\4":F
    cmpg-float v38, v3, v0

    if-gez v38, :cond_2f9

    move v0, v3

    move-object/from16 v3, v36

    move-object/from16 v1, v37

    .end local v1    # "v\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v3    # "d\\4":F
    goto :goto_2d5

    .restart local v1    # "v\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v3    # "d\\4":F
    :cond_2f9
    move-object/from16 v3, v36

    move-object/from16 v1, v37

    goto :goto_2d5

    .line 203
    .end local v1    # "v\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v36    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v3, "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_2fe
    move-object/from16 v36, v3

    .end local v3    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v36    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    neg-float v1, v0

    .line 204
    .local v1, "pen\\4":F
    const v3, 0x3727c5ac    # 1.0E-5f

    cmpg-float v3, v1, v3

    if-lez v3, :cond_330

    .line 205
    add-int/lit8 v3, v27, 0x4

    aget v3, v32, v3

    add-int/lit8 v37, v27, 0x7

    move/from16 v38, v0

    .end local v0    # "deepest\\4":F
    .local v38, "deepest\\4":F
    aget v0, v32, v37

    invoke-static {v3, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-static {v8, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    .line 206
    .local v0, "triTop\\4":F
    cmpg-float v3, v1, v18

    if-gez v3, :cond_327

    move v3, v1

    .end local v18    # "bestLen":F
    .local v3, "bestLen":F
    invoke-virtual {v5, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v18

    move-object/from16 v24, v18

    move/from16 v18, v3

    .line 207
    .end local v3    # "bestLen":F
    .restart local v18    # "bestLen":F
    :cond_327
    cmpl-float v3, v0, v23

    if-lez v3, :cond_32e

    move v3, v0

    move/from16 v23, v3

    .line 208
    :cond_32e
    goto/16 :goto_3b0

    .line 204
    .end local v38    # "deepest\\4":F
    .local v0, "deepest\\4":F
    :cond_330
    move/from16 v38, v0

    .end local v0    # "deepest\\4":F
    .restart local v38    # "deepest\\4":F
    goto/16 :goto_3b0

    .line 199
    .end local v1    # "pen\\4":F
    .end local v36    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v38    # "deepest\\4":F
    .local v3, "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_334
    move-object/from16 v36, v3

    .end local v3    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v36    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    goto/16 :goto_3b0

    .line 197
    .end local v2    # "a\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v19    # "g\\3":I
    .end local v21    # "ax\\4":F
    .end local v29    # "az\\4":F
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .end local v35    # "t\\3":I
    .end local v36    # "b\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v0, "n\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v4, "g\\3":I
    .local v5, "i\\3":I
    .restart local v7    # "ax\\4":F
    .restart local v10    # "az\\4":F
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    .restart local v34    # "t\\3":I
    :cond_338
    move/from16 v29, v32

    move-object/from16 v32, v11

    move/from16 v11, v29

    move/from16 v29, v10

    move/from16 v10, v21

    move/from16 v35, v34

    move/from16 v21, v7

    move/from16 v7, v19

    move/from16 v34, v33

    move/from16 v19, v4

    move-object/from16 v33, v12

    move v12, v5

    move-object v5, v0

    .end local v0    # "n\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v4    # "g\\3":I
    .end local v7    # "ax\\4":F
    .end local v10    # "az\\4":F
    .end local v11    # "p":[F
    .end local v34    # "t\\3":I
    .local v5, "n\\4":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v12, "i\\3":I
    .restart local v19    # "g\\3":I
    .restart local v21    # "ax\\4":F
    .restart local v29    # "az\\4":F
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    .restart local v35    # "t\\3":I
    goto/16 :goto_3b0

    .line 194
    .end local v19    # "g\\3":I
    .end local v21    # "ax\\4":F
    .end local v29    # "az\\4":F
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .end local v35    # "t\\3":I
    .local v3, "t\\3":I
    .restart local v4    # "g\\3":I
    .local v5, "i\\3":I
    .restart local v7    # "ax\\4":F
    .restart local v10    # "az\\4":F
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    :cond_352
    move/from16 v29, v32

    move-object/from16 v32, v11

    move/from16 v11, v29

    move/from16 v34, v2

    move/from16 v35, v3

    move/from16 v29, v10

    move-object/from16 v33, v12

    move/from16 v10, v21

    move v12, v5

    move/from16 v21, v7

    move/from16 v7, v19

    move/from16 v19, v4

    .end local v3    # "t\\3":I
    .end local v4    # "g\\3":I
    .end local v5    # "i\\3":I
    .end local v7    # "ax\\4":F
    .end local v10    # "az\\4":F
    .end local v11    # "p":[F
    .local v12, "i\\3":I
    .restart local v19    # "g\\3":I
    .restart local v21    # "ax\\4":F
    .restart local v29    # "az\\4":F
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    .restart local v35    # "t\\3":I
    goto :goto_3b0

    .line 193
    .end local v19    # "g\\3":I
    .end local v21    # "ax\\4":F
    .end local v29    # "az\\4":F
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .end local v35    # "t\\3":I
    .restart local v3    # "t\\3":I
    .restart local v4    # "g\\3":I
    .restart local v5    # "i\\3":I
    .restart local v7    # "ax\\4":F
    .restart local v10    # "az\\4":F
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    :cond_36a
    move/from16 v29, v32

    move-object/from16 v32, v11

    move/from16 v11, v29

    move/from16 v34, v2

    move/from16 v35, v3

    move/from16 v29, v10

    move-object/from16 v33, v12

    move/from16 v10, v21

    move v12, v5

    move/from16 v21, v7

    move/from16 v7, v19

    move/from16 v19, v4

    .end local v3    # "t\\3":I
    .end local v4    # "g\\3":I
    .end local v5    # "i\\3":I
    .end local v7    # "ax\\4":F
    .end local v10    # "az\\4":F
    .end local v11    # "p":[F
    .local v12, "i\\3":I
    .restart local v19    # "g\\3":I
    .restart local v21    # "ax\\4":F
    .restart local v29    # "az\\4":F
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    .restart local v35    # "t\\3":I
    goto :goto_3b0

    .line 192
    .end local v19    # "g\\3":I
    .end local v21    # "ax\\4":F
    .end local v29    # "az\\4":F
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .end local v35    # "t\\3":I
    .restart local v3    # "t\\3":I
    .restart local v4    # "g\\3":I
    .restart local v5    # "i\\3":I
    .restart local v7    # "ax\\4":F
    .restart local v10    # "az\\4":F
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    :cond_382
    move/from16 v29, v32

    move-object/from16 v32, v11

    move/from16 v11, v29

    move/from16 v34, v2

    move/from16 v35, v3

    move/from16 v29, v10

    move-object/from16 v33, v12

    move/from16 v10, v21

    move v12, v5

    move/from16 v21, v7

    move/from16 v7, v19

    move/from16 v19, v4

    .end local v3    # "t\\3":I
    .end local v4    # "g\\3":I
    .end local v5    # "i\\3":I
    .end local v7    # "ax\\4":F
    .end local v10    # "az\\4":F
    .end local v11    # "p":[F
    .local v12, "i\\3":I
    .restart local v19    # "g\\3":I
    .restart local v21    # "ax\\4":F
    .restart local v29    # "az\\4":F
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    .restart local v35    # "t\\3":I
    goto :goto_3b0

    .line 278
    .end local v8    # "ay\\4":F
    .end local v19    # "g\\3":I
    .end local v21    # "ax\\4":F
    .end local v25    # "t\\4":I
    .end local v26    # "$i$a$-forTris-CollisionMeshes$push$2\\4\\278\\0":I
    .end local v27    # "o\\4":I
    .end local v28    # "list\\3":[I
    .end local v29    # "az\\4":F
    .end local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .end local v35    # "t\\3":I
    .restart local v3    # "t\\3":I
    .restart local v4    # "g\\3":I
    .restart local v5    # "i\\3":I
    .local v7, "list\\3":[I
    .local v10, "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    :cond_39a
    move/from16 v34, v2

    move/from16 v35, v3

    move-object/from16 v28, v7

    move/from16 v30, v8

    move-object/from16 v31, v10

    move-object/from16 v32, v11

    move-object/from16 v33, v12

    move/from16 v7, v19

    move/from16 v10, v21

    move v11, v0

    move/from16 v19, v4

    move v12, v5

    .end local v3    # "t\\3":I
    .end local v4    # "g\\3":I
    .end local v5    # "i\\3":I
    .end local v7    # "list\\3":[I
    .end local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "p":[F
    .local v12, "i\\3":I
    .restart local v19    # "g\\3":I
    .restart local v28    # "list\\3":[I
    .restart local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    .restart local v35    # "t\\3":I
    :goto_3b0
    nop

    .end local v35    # "t\\3":I
    add-int/lit8 v2, v34, 0x1

    move-object/from16 v1, p2

    move/from16 v21, v10

    move v0, v11

    move v5, v12

    move/from16 v4, v19

    move/from16 v8, v30

    move-object/from16 v10, v31

    move-object/from16 v11, v32

    move-object/from16 v12, v33

    move/from16 v19, v7

    move-object/from16 v7, v28

    goto/16 :goto_148

    .end local v19    # "g\\3":I
    .end local v28    # "list\\3":[I
    .end local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .restart local v4    # "g\\3":I
    .restart local v5    # "i\\3":I
    .restart local v7    # "list\\3":[I
    .restart local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    :cond_3c9
    move-object/from16 v28, v7

    move-object/from16 v31, v10

    move-object/from16 v32, v11

    move-object/from16 v33, v12

    move/from16 v7, v19

    move/from16 v10, v21

    move v11, v0

    move/from16 v19, v4

    move v12, v5

    .end local v4    # "g\\3":I
    .end local v5    # "i\\3":I
    .end local v7    # "list\\3":[I
    .end local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "p":[F
    .local v12, "i\\3":I
    .restart local v19    # "g\\3":I
    .restart local v28    # "list\\3":[I
    .restart local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    move/from16 v2, v18

    move/from16 v3, v23

    move-object/from16 v18, v24

    .line 276
    .end local v23    # "top":F
    .end local v24    # "best":Ljava/lang/Object;
    .end local v28    # "list\\3":[I
    .local v2, "bestLen":F
    .local v3, "top":F
    .local v18, "best":Ljava/lang/Object;
    :goto_3df
    if-eq v6, v11, :cond_406

    add-int/lit8 v6, v6, 0x1

    move-object/from16 v1, p2

    move-object/from16 v8, p4

    move/from16 v21, v10

    move v0, v11

    move v5, v12

    move/from16 v4, v19

    move-object/from16 v10, v31

    move-object/from16 v11, v32

    move-object/from16 v12, v33

    move/from16 v19, v7

    move/from16 v7, v22

    goto/16 :goto_110

    .end local v19    # "g\\3":I
    .end local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .restart local v4    # "g\\3":I
    .restart local v5    # "i\\3":I
    .restart local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    :cond_3f9
    move-object/from16 v31, v10

    move-object/from16 v32, v11

    move-object/from16 v33, v12

    move/from16 v7, v19

    move/from16 v10, v21

    move/from16 v19, v4

    move v12, v5

    .end local v4    # "g\\3":I
    .end local v5    # "i\\3":I
    .end local v6    # "k\\3":I
    .end local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "p":[F
    .local v12, "i\\3":I
    .restart local v19    # "g\\3":I
    .restart local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    :cond_406
    if-eq v9, v10, :cond_42b

    add-int/lit8 v9, v9, 0x1

    move-object/from16 v1, p2

    move-object/from16 v8, p4

    move v0, v10

    move v5, v12

    move/from16 v4, v19

    move/from16 v6, v20

    move-object/from16 v10, v31

    move-object/from16 v11, v32

    move-object/from16 v12, v33

    move/from16 v19, v7

    move-object/from16 v7, p3

    goto/16 :goto_f9

    .end local v19    # "g\\3":I
    .end local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .restart local v4    # "g\\3":I
    .restart local v5    # "i\\3":I
    .restart local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    :cond_420
    move-object/from16 v31, v10

    move-object/from16 v32, v11

    move-object/from16 v33, v12

    move/from16 v7, v19

    move/from16 v19, v4

    move v12, v5

    .end local v4    # "g\\3":I
    .end local v5    # "i\\3":I
    .end local v9    # "j\\3":I
    .end local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "p":[F
    .local v12, "i\\3":I
    .restart local v19    # "g\\3":I
    .restart local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    :cond_42b
    if-eq v12, v7, :cond_443

    add-int/lit8 v5, v12, 0x1

    move-object/from16 v6, p1

    move-object/from16 v1, p2

    move-object/from16 v8, p4

    move v0, v7

    move/from16 v4, v19

    move-object/from16 v10, v31

    move-object/from16 v11, v32

    move-object/from16 v12, v33

    const/4 v9, 0x0

    move-object/from16 v7, p3

    .end local v12    # "i\\3":I
    .restart local v5    # "i\\3":I
    goto/16 :goto_e4

    .end local v5    # "i\\3":I
    .restart local v12    # "i\\3":I
    :cond_443
    move-object/from16 v0, v18

    goto :goto_450

    .end local v19    # "g\\3":I
    .end local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .restart local v4    # "g\\3":I
    .restart local v5    # "i\\3":I
    .restart local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v11    # "p":[F
    .local v12, "nr":[F
    :cond_446
    move/from16 v19, v4

    move-object/from16 v31, v10

    move-object/from16 v32, v11

    move-object/from16 v33, v12

    .end local v4    # "g\\3":I
    .end local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "p":[F
    .end local v12    # "nr":[F
    .restart local v19    # "g\\3":I
    .restart local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    move-object/from16 v0, v18

    .line 280
    .end local v5    # "i\\3":I
    .end local v18    # "best":Ljava/lang/Object;
    .local v0, "best":Ljava/lang/Object;
    :goto_450
    goto :goto_45d

    .line 274
    .end local v19    # "g\\3":I
    .end local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v32    # "p":[F
    .end local v33    # "nr":[F
    .restart local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v11    # "p":[F
    .restart local v12    # "nr":[F
    :cond_451
    move-object/from16 v18, v0

    move-object/from16 v31, v10

    move-object/from16 v32, v11

    move-object/from16 v33, v12

    const/16 v17, 0x0

    .line 209
    .end local v0    # "best":Ljava/lang/Object;
    .end local v10    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "p":[F
    .end local v12    # "nr":[F
    .end local v13    # "lo\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v14    # "hi\\3":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v15    # "this_\\3":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .end local v16    # "$i$f$forTris\\3\\188":I
    .restart local v18    # "best":Ljava/lang/Object;
    .restart local v31    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v32    # "p":[F
    .restart local v33    # "nr":[F
    :goto_45b
    move-object/from16 v0, v18

    .end local v18    # "best":Ljava/lang/Object;
    .restart local v0    # "best":Ljava/lang/Object;
    :goto_45d
    if-nez v0, :cond_460

    return-object v17

    :cond_460
    move-object v1, v0

    .line 210
    .local v1, "b":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    invoke-static {v1, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    return-object v4
.end method

.method public final ray(Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;F)Lkotlin/Pair;
    .registers 32
    .param p1, "m"    # Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .param p2, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "d"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p4, "maxDist"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "F)",
            "Lkotlin/Pair<",
            "Ljava/lang/Float;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            ">;"
        }
    .end annotation

    move-object/from16 v3, p2

    move-object/from16 v2, p3

    const-string v0, "m"

    move-object/from16 v7, p1

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "o"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "d"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 232
    const v0, 0x47c35000    # 100000.0f

    move/from16 v5, p4

    invoke-static {v5, v0}, Lkotlin/ranges/RangesKt;->coerceAtMost(FF)F

    move-result v0

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    .line 233
    .local v8, "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->min(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->max(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    .local v9, "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->max(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->min(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    .line 234
    .local v10, "hi":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v0

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v1

    cmpl-float v0, v0, v1

    if-gtz v0, :cond_21e

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v0

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v1

    cmpl-float v0, v0, v1

    if-gtz v0, :cond_21e

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v0

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v1

    cmpl-float v0, v0, v1

    if-lez v0, :cond_6a

    move-object/from16 v20, v8

    move-object/from16 v21, v9

    const/16 v16, 0x0

    goto/16 :goto_224

    .line 235
    :cond_6a
    new-instance v4, Lkotlin/jvm/internal/Ref$FloatRef;

    invoke-direct {v4}, Lkotlin/jvm/internal/Ref$FloatRef;-><init>()V

    .local v4, "best":Lkotlin/jvm/internal/Ref$FloatRef;
    const v0, 0x7f7fffff    # Float.MAX_VALUE

    iput v0, v4, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    new-instance v6, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v6}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 236
    .local v6, "bestN":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getPos()[F

    move-result-object v1

    .line 237
    .local v1, "p":[F
    new-instance v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;

    invoke-direct/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;-><init>([FLcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/internal/Ref$FloatRef;FLkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;)V

    .line 259
    .local v0, "visit":Lkotlin/jvm/functions/Function1;
    invoke-virtual {v10, v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v3

    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getCell()F

    move-result v5

    const/high16 v7, 0x41400000    # 12.0f

    mul-float/2addr v5, v7

    cmpl-float v3, v3, v5

    if-lez v3, :cond_b0

    const/4 v3, 0x0

    .local v3, "t":I
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getCount()I

    move-result v5

    :goto_9a
    if-ge v3, v5, :cond_a6

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v0, v7}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v3, v3, 0x1

    goto :goto_9a

    :cond_a6
    move-object/from16 v17, v1

    move-object/from16 v20, v8

    move-object/from16 v21, v9

    const/16 v16, 0x0

    goto/16 :goto_1fd

    .end local v3    # "t":I
    :cond_b0
    move-object v3, v10

    .local v3, "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object/from16 v5, p1

    .local v5, "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    move-object v7, v9

    .local v7, "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v12, 0x0

    .line 281
    .local v12, "$i$f$forTris\\1\\259":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v13

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v14

    cmpg-float v13, v13, v14

    if-ltz v13, :cond_1ef

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v13

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v14

    cmpl-float v13, v13, v14

    if-gtz v13, :cond_1ef

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v13

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v14

    cmpg-float v13, v13, v14

    if-ltz v13, :cond_1ef

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v13

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v14

    cmpl-float v13, v13, v14

    if-gtz v13, :cond_1ef

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v13

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v14

    cmpg-float v13, v13, v14

    if-ltz v13, :cond_1ef

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v13

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v14

    invoke-virtual {v14}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v14

    cmpl-float v13, v13, v14

    if-lez v13, :cond_11f

    move-object/from16 v17, v1

    move-object/from16 v20, v8

    move-object/from16 v21, v9

    const/16 v16, 0x0

    goto/16 :goto_1fd

    .line 282
    :cond_11f
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nextStamp()I

    move-result v13

    .line 283
    .local v13, "g\\1":I
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v14

    const/4 v15, 0x0

    invoke-virtual {v5, v14, v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v14

    const/16 v16, 0x0

    .local v14, "i\\1":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v11

    invoke-virtual {v5, v11, v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v11

    if-gt v14, v11, :cond_1e2

    :goto_138
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v15

    move-object/from16 v17, v1

    .end local v1    # "p":[F
    .local v17, "p":[F
    const/4 v1, 0x1

    invoke-virtual {v5, v15, v1}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v15

    move-object/from16 v18, v3

    .end local v3    # "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v15, "j\\1":I
    .local v18, "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual/range {v18 .. v18}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    invoke-virtual {v5, v3, v1}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v1

    if-gt v15, v1, :cond_1c7

    :goto_14f
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    move-object/from16 v19, v7

    .end local v7    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v19, "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v7, 0x2

    invoke-virtual {v5, v3, v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v3

    move-object/from16 v20, v8

    .end local v8    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v3, "k\\1":I
    .local v20, "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual/range {v18 .. v18}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v8

    invoke-virtual {v5, v8, v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v7

    if-gt v3, v7, :cond_1b6

    .line 284
    :goto_166
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getCells()[[I

    move-result-object v8

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNy()I

    move-result v21

    mul-int v21, v21, v14

    add-int v21, v21, v15

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNz()I

    move-result v22

    mul-int v21, v21, v22

    add-int v21, v21, v3

    aget-object v8, v8, v21

    if-nez v8, :cond_183

    move-object/from16 v26, v5

    move-object/from16 v21, v9

    goto :goto_1ad

    .line 285
    .local v8, "list\\1":[I
    :cond_183
    move-object/from16 v21, v9

    .end local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v21, "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    array-length v9, v8

    move-object/from16 v22, v8

    const/4 v8, 0x0

    .end local v8    # "list\\1":[I
    .local v22, "list\\1":[I
    :goto_189
    if-ge v8, v9, :cond_1ab

    move/from16 v23, v8

    aget v8, v22, v23

    .local v8, "t\\1":I
    invoke-virtual {v5, v8, v13}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->mark(II)Z

    move-result v24

    if-eqz v24, :cond_1a3

    move/from16 v24, v8

    .local v24, "it\\2":I
    const/16 v25, 0x0

    .line 259
    .local v25, "$i$a$-forTris-CollisionMeshes$ray$1\\2\\285\\0":I
    move-object/from16 v26, v5

    .end local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .local v26, "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v0, v5}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .end local v24    # "it\\2":I
    .end local v25    # "$i$a$-forTris-CollisionMeshes$ray$1\\2\\285\\0":I
    goto :goto_1a5

    .line 285
    .end local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    :cond_1a3
    move-object/from16 v26, v5

    .end local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    :goto_1a5
    nop

    .end local v8    # "t\\1":I
    add-int/lit8 v8, v23, 0x1

    move-object/from16 v5, v26

    goto :goto_189

    .end local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    :cond_1ab
    move-object/from16 v26, v5

    .line 283
    .end local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .end local v22    # "list\\1":[I
    .restart local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    :goto_1ad
    if-eq v3, v7, :cond_1ba

    add-int/lit8 v3, v3, 0x1

    move-object/from16 v9, v21

    move-object/from16 v5, v26

    goto :goto_166

    .end local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_1b6
    move-object/from16 v26, v5

    move-object/from16 v21, v9

    .end local v3    # "k\\1":I
    .end local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .end local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    :cond_1ba
    if-eq v15, v1, :cond_1cf

    add-int/lit8 v15, v15, 0x1

    move-object/from16 v7, v19

    move-object/from16 v8, v20

    move-object/from16 v9, v21

    move-object/from16 v5, v26

    goto :goto_14f

    .end local v19    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v20    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v7    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v8, "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_1c7
    move-object/from16 v26, v5

    move-object/from16 v19, v7

    move-object/from16 v20, v8

    move-object/from16 v21, v9

    .end local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .end local v7    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v15    # "j\\1":I
    .restart local v19    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v20    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    :cond_1cf
    if-eq v14, v11, :cond_1ee

    add-int/lit8 v14, v14, 0x1

    move-object/from16 v1, v17

    move-object/from16 v3, v18

    move-object/from16 v7, v19

    move-object/from16 v8, v20

    move-object/from16 v9, v21

    move-object/from16 v5, v26

    const/4 v15, 0x0

    goto/16 :goto_138

    .end local v17    # "p":[F
    .end local v18    # "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v19    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v20    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v1    # "p":[F
    .local v3, "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v7    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v8    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_1e2
    move-object/from16 v17, v1

    move-object/from16 v18, v3

    move-object/from16 v26, v5

    move-object/from16 v19, v7

    move-object/from16 v20, v8

    move-object/from16 v21, v9

    .line 287
    .end local v1    # "p":[F
    .end local v3    # "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .end local v7    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v14    # "i\\1":I
    .restart local v17    # "p":[F
    .restart local v18    # "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v19    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v20    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    :cond_1ee
    goto :goto_1fd

    .line 281
    .end local v13    # "g\\1":I
    .end local v17    # "p":[F
    .end local v18    # "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v19    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v20    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v26    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v1    # "p":[F
    .restart local v3    # "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .restart local v7    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v8    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_1ef
    move-object/from16 v17, v1

    move-object/from16 v18, v3

    move-object/from16 v26, v5

    move-object/from16 v19, v7

    move-object/from16 v20, v8

    move-object/from16 v21, v9

    const/16 v16, 0x0

    .line 260
    .end local v1    # "p":[F
    .end local v3    # "hi\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v5    # "this_\\1":Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
    .end local v7    # "lo\\1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v12    # "$i$f$forTris\\1\\259":I
    .restart local v17    # "p":[F
    .restart local v20    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :goto_1fd
    iget-object v1, v6, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v1, :cond_204

    return-object v16

    .line 261
    .local v1, "n":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_204
    iget v3, v4, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v5

    const/4 v7, 0x0

    cmpl-float v5, v5, v7

    if-lez v5, :cond_218

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    goto :goto_219

    :cond_218
    move-object v5, v1

    :goto_219
    invoke-static {v3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    return-object v3

    .line 234
    .end local v0    # "visit":Lkotlin/jvm/functions/Function1;
    .end local v1    # "n":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v4    # "best":Lkotlin/jvm/internal/Ref$FloatRef;
    .end local v6    # "bestN":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v17    # "p":[F
    .end local v20    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v8    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_21e
    move-object/from16 v20, v8

    move-object/from16 v21, v9

    const/16 v16, 0x0

    .end local v8    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v20    # "end":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v21    # "lo":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :goto_224
    return-object v16
.end method

###### Class com.exampletest.mobilestudiotest.engine.CollisionMeshes.Mesh (com.exampletest.mobilestudiotest.engine.CollisionMeshes$Mesh)
.class public final Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;
.super Ljava/lang/Object;
.source "CollisionMeshes.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Mesh"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCollisionMeshes.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CollisionMeshes.kt\ncom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh\n+ 2 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,264:1\n382#2,7:265\n*S KotlinDebug\n*F\n+ 1 CollisionMeshes.kt\ncom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh\n*L\n48#1:265,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000Z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0014\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u000e\n\u0002\u0010\u0007\n\u0002\u0008\t\n\u0002\u0010\u0011\n\u0002\u0010\u0015\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0003\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0008\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\n\u00a2\u0006\u0004\u0008\u000c\u0010\rJ\u0018\u00100\u001a\u00020\u00082\u0006\u00101\u001a\u00020\u00192\u0006\u00102\u001a\u00020\u0008H\u0002J \u00103\u001a\u00020\u00082\u0006\u00104\u001a\u00020\u00082\u0006\u00105\u001a\u00020\u00082\u0006\u00106\u001a\u00020\u0008H\u0002J0\u00107\u001a\u0002082\u0006\u00109\u001a\u00020\n2\u0006\u0010:\u001a\u00020\n2\u0012\u0010;\u001a\u000e\u0012\u0004\u0012\u00020\u0008\u0012\u0004\u0012\u0002080<H\u0086\u0008\u00f8\u0001\u0000J\u0016\u0010=\u001a\u00020\u00082\u0006\u00101\u001a\u00020\u00192\u0006\u00102\u001a\u00020\u0008J\u0006\u0010>\u001a\u00020\u0008J\u0016\u0010?\u001a\u00020@2\u0006\u0010A\u001a\u00020\u00082\u0006\u0010B\u001a\u00020\u0008R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0011R\u0011\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0014R\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0015\u0010\u0016R\u0011\u0010\u000b\u001a\u00020\n\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0017\u0010\u0016R\u0011\u0010\u0018\u001a\u00020\u0019\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001a\u0010\u001bR\u0011\u0010\u001c\u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u0014R\u0011\u0010\u001e\u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001f\u0010\u0014R\u0011\u0010 \u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008!\u0010\u0014R\u001b\u0010\"\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010$0#\u00a2\u0006\n\n\u0002\u0010\'\u001a\u0004\u0008%\u0010&R\u000e\u0010(\u001a\u00020$X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0008X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010*\u001a\u0004\u0018\u00010+X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008,\u0010-\"\u0004\u0008.\u0010/\u0082\u0002\u0007\n\u0005\u0008\u009920\u0001\u00a8\u0006C"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;",
        "",
        "key",
        "",
        "pos",
        "",
        "nrm",
        "count",
        "",
        "min",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "max",
        "<init>",
        "(J[F[FILcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V",
        "getKey",
        "()J",
        "getPos",
        "()[F",
        "getNrm",
        "getCount",
        "()I",
        "getMin",
        "()Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "getMax",
        "cell",
        "",
        "getCell",
        "()F",
        "nx",
        "getNx",
        "ny",
        "getNy",
        "nz",
        "getNz",
        "cells",
        "",
        "",
        "getCells",
        "()[[I",
        "[[I",
        "stamp",
        "stampGen",
        "hull",
        "Lcom/exampletest/mobilestudiotest/engine/ConvexShape;",
        "getHull",
        "()Lcom/exampletest/mobilestudiotest/engine/ConvexShape;",
        "setHull",
        "(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;)V",
        "ci",
        "v",
        "axis",
        "idx",
        "i",
        "j",
        "k",
        "forTris",
        "",
        "lo",
        "hi",
        "f",
        "Lkotlin/Function1;",
        "cellIndex",
        "nextStamp",
        "mark",
        "",
        "t",
        "g",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final cell:F

.field private final cells:[[I

.field private final count:I

.field private hull:Lcom/exampletest/mobilestudiotest/engine/ConvexShape;

.field private final key:J

.field private final max:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private final min:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private final nrm:[F

.field private final nx:I

.field private final ny:I

.field private final nz:I

.field private final pos:[F

.field private final stamp:[I

.field private stampGen:I


# direct methods
.method public constructor <init>(J[F[FILcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V
    .registers 33
    .param p1, "key"    # J
    .param p3, "pos"    # [F
    .param p4, "nrm"    # [F
    .param p5, "count"    # I
    .param p6, "min"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p7, "max"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    move-object/from16 v3, p6

    move-object/from16 v4, p7

    const-string v5, "pos"

    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "nrm"

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "min"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "max"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    move-wide/from16 v5, p1

    iput-wide v5, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->key:J

    iput-object v1, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nrm:[F

    move/from16 v7, p5

    iput v7, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->count:I

    iput-object v3, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->min:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iput-object v4, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->max:Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 34
    iget v8, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->count:I

    new-array v8, v8, [I

    iput-object v8, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stamp:[I

    .line 38
    nop

    .line 39
    iget-object v8, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->max:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->min:Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    .line 40
    .local v8, "ext":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v9

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v10

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v11

    invoke-static {v10, v11}, Ljava/lang/Math;->max(FF)F

    move-result v10

    invoke-static {v9, v10}, Ljava/lang/Math;->max(FF)F

    move-result v9

    const/high16 v10, 0x41c00000    # 24.0f

    div-float/2addr v9, v10

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-static {v9, v10}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v9

    iput v9, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cell:F

    .line 41
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v9

    iget v10, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cell:F

    div-float/2addr v9, v10

    float-to-int v9, v9

    const/4 v10, 0x1

    add-int/2addr v9, v10

    iput v9, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nx:I

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v9

    iget v11, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cell:F

    div-float/2addr v9, v11

    float-to-int v9, v9

    add-int/2addr v9, v10

    iput v9, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ny:I

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v9

    iget v11, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cell:F

    div-float/2addr v9, v11

    float-to-int v9, v9

    add-int/2addr v9, v10

    iput v9, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nz:I

    .line 42
    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    .line 43
    .local v9, "lists":Ljava/util/HashMap;
    const/4 v11, 0x0

    .local v11, "t":I
    iget v12, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->count:I

    :goto_89
    if-ge v11, v12, :cond_1d5

    .line 44
    mul-int/lit8 v13, v11, 0x9

    .line 45
    .local v13, "o":I
    iget-object v14, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    aget v14, v14, v13

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v16, v13, 0x3

    aget v15, v15, v16

    iget-object v10, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x6

    aget v10, v10, v17

    invoke-static {v15, v10}, Ljava/lang/Math;->min(FF)F

    move-result v10

    invoke-static {v14, v10}, Ljava/lang/Math;->min(FF)F

    move-result v10

    .local v10, "x0":F
    iget-object v14, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    aget v14, v14, v13

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x3

    aget v15, v15, v17

    iget-object v1, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x6

    aget v1, v1, v17

    invoke-static {v15, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-static {v14, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    .line 46
    .local v1, "x1":F
    iget-object v14, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v15, v13, 0x1

    aget v14, v14, v15

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x4

    aget v15, v15, v17

    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x7

    aget v2, v2, v17

    invoke-static {v15, v2}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v14, v2}, Ljava/lang/Math;->min(FF)F

    move-result v2

    .local v2, "y0":F
    iget-object v14, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v15, v13, 0x1

    aget v14, v14, v15

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x4

    aget v15, v15, v17

    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x7

    aget v3, v3, v17

    invoke-static {v15, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-static {v14, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    .line 47
    .local v3, "y1":F
    iget-object v14, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v15, v13, 0x2

    aget v14, v14, v15

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x5

    aget v15, v15, v17

    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x8

    aget v4, v4, v17

    invoke-static {v15, v4}, Ljava/lang/Math;->min(FF)F

    move-result v4

    invoke-static {v14, v4}, Ljava/lang/Math;->min(FF)F

    move-result v4

    .local v4, "z0":F
    iget-object v14, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v15, v13, 0x2

    aget v14, v14, v15

    iget-object v15, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v17, v13, 0x5

    aget v15, v15, v17

    iget-object v5, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    add-int/lit8 v6, v13, 0x8

    aget v5, v5, v6

    invoke-static {v15, v5}, Ljava/lang/Math;->max(FF)F

    move-result v5

    invoke-static {v14, v5}, Ljava/lang/Math;->max(FF)F

    move-result v5

    .line 48
    .local v5, "z1":F
    const/4 v6, 0x0

    invoke-direct {v0, v10, v6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ci(FI)I

    move-result v14

    .local v14, "i":I
    invoke-direct {v0, v1, v6}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ci(FI)I

    move-result v6

    if-gt v14, v6, :cond_1ba

    :goto_130
    move/from16 v16, v1

    const/4 v15, 0x1

    .end local v1    # "x1":F
    .local v16, "x1":F
    invoke-direct {v0, v2, v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ci(FI)I

    move-result v1

    move/from16 v17, v2

    .end local v2    # "y0":F
    .local v1, "j":I
    .local v17, "y0":F
    invoke-direct {v0, v3, v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ci(FI)I

    move-result v2

    if-gt v1, v2, :cond_1a2

    :goto_13f
    const/4 v15, 0x2

    move/from16 v18, v3

    .end local v3    # "y1":F
    .local v18, "y1":F
    invoke-direct {v0, v4, v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ci(FI)I

    move-result v3

    .local v3, "k":I
    invoke-direct {v0, v5, v15}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ci(FI)I

    move-result v15

    if-gt v3, v15, :cond_190

    :goto_14c
    move/from16 v19, v4

    .end local v4    # "z0":F
    .local v19, "z0":F
    move-object v4, v9

    check-cast v4, Ljava/util/Map;

    .local v4, "$this$getOrPut\\1":Ljava/util/Map;
    invoke-direct {v0, v14, v1, v3}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->idx(III)I

    move-result v20

    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v20

    .local v20, "key\\1":Ljava/lang/Object;
    move-object/from16 v21, v20

    .end local v20    # "key\\1":Ljava/lang/Object;
    .local v21, "key\\1":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 265
    .local v20, "$i$f$getOrPut\\1\\48":I
    move/from16 v22, v5

    move-object/from16 v5, v21

    .end local v21    # "key\\1":Ljava/lang/Object;
    .local v5, "key\\1":Ljava/lang/Object;
    .local v22, "z1":F
    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v21

    .line 266
    .local v21, "value\\1":Ljava/lang/Object;
    if-nez v21, :cond_177

    .line 267
    const/16 v23, 0x0

    .line 48
    .local v23, "$i$a$-getOrPut-CollisionMeshes$Mesh$1\\2\\267\\0":I
    new-instance v24, Ljava/util/ArrayList;

    invoke-direct/range {v24 .. v24}, Ljava/util/ArrayList;-><init>()V

    .line 267
    .end local v23    # "$i$a$-getOrPut-CollisionMeshes$Mesh$1\\2\\267\\0":I
    move-object/from16 v23, v24

    .line 268
    .local v23, "answer\\1":Ljava/lang/Object;
    move-object/from16 v7, v23

    .end local v23    # "answer\\1":Ljava/lang/Object;
    .local v7, "answer\\1":Ljava/lang/Object;
    invoke-interface {v4, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 269
    nop

    .end local v7    # "answer\\1":Ljava/lang/Object;
    goto :goto_179

    .line 271
    :cond_177
    move-object/from16 v23, v21

    .line 266
    :goto_179
    nop

    .end local v4    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v5    # "key\\1":Ljava/lang/Object;
    .end local v20    # "$i$f$getOrPut\\1\\48":I
    .end local v21    # "value\\1":Ljava/lang/Object;
    move-object/from16 v4, v23

    check-cast v4, Ljava/util/ArrayList;

    .line 48
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eq v3, v15, :cond_194

    add-int/lit8 v3, v3, 0x1

    move/from16 v7, p5

    move/from16 v4, v19

    move/from16 v5, v22

    goto :goto_14c

    .end local v19    # "z0":F
    .end local v22    # "z1":F
    .local v4, "z0":F
    .local v5, "z1":F
    :cond_190
    move/from16 v19, v4

    move/from16 v22, v5

    .end local v3    # "k":I
    .end local v4    # "z0":F
    .end local v5    # "z1":F
    .restart local v19    # "z0":F
    .restart local v22    # "z1":F
    :cond_194
    if-eq v1, v2, :cond_1a8

    add-int/lit8 v1, v1, 0x1

    move/from16 v7, p5

    move/from16 v3, v18

    move/from16 v4, v19

    move/from16 v5, v22

    const/4 v15, 0x1

    goto :goto_13f

    .end local v18    # "y1":F
    .end local v19    # "z0":F
    .end local v22    # "z1":F
    .local v3, "y1":F
    .restart local v4    # "z0":F
    .restart local v5    # "z1":F
    :cond_1a2
    move/from16 v18, v3

    move/from16 v19, v4

    move/from16 v22, v5

    .end local v1    # "j":I
    .end local v3    # "y1":F
    .end local v4    # "z0":F
    .end local v5    # "z1":F
    .restart local v18    # "y1":F
    .restart local v19    # "z0":F
    .restart local v22    # "z1":F
    :cond_1a8
    if-eq v14, v6, :cond_1c4

    add-int/lit8 v14, v14, 0x1

    move/from16 v7, p5

    move/from16 v1, v16

    move/from16 v2, v17

    move/from16 v3, v18

    move/from16 v4, v19

    move/from16 v5, v22

    goto/16 :goto_130

    .end local v16    # "x1":F
    .end local v17    # "y0":F
    .end local v18    # "y1":F
    .end local v19    # "z0":F
    .end local v22    # "z1":F
    .local v1, "x1":F
    .restart local v2    # "y0":F
    .restart local v3    # "y1":F
    .restart local v4    # "z0":F
    .restart local v5    # "z1":F
    :cond_1ba
    move/from16 v16, v1

    move/from16 v17, v2

    move/from16 v18, v3

    move/from16 v19, v4

    move/from16 v22, v5

    .line 43
    .end local v1    # "x1":F
    .end local v2    # "y0":F
    .end local v3    # "y1":F
    .end local v4    # "z0":F
    .end local v5    # "z1":F
    .end local v10    # "x0":F
    .end local v13    # "o":I
    .end local v14    # "i":I
    :cond_1c4
    add-int/lit8 v11, v11, 0x1

    move-wide/from16 v5, p1

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    move/from16 v7, p5

    move-object/from16 v3, p6

    move-object/from16 v4, p7

    const/4 v10, 0x1

    goto/16 :goto_89

    .line 50
    .end local v11    # "t":I
    :cond_1d5
    iget v1, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nx:I

    iget v2, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ny:I

    mul-int/2addr v1, v2

    iget v2, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nz:I

    mul-int/2addr v1, v2

    new-array v1, v1, [[I

    iput-object v1, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cells:[[I

    .line 51
    move-object v1, v9

    check-cast v1, Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1ec
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_214

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    .local v3, "k":I
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/ArrayList;

    .local v2, "l":Ljava/util/ArrayList;
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cells:[[I

    move-object v5, v2

    check-cast v5, Ljava/util/Collection;

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->toIntArray(Ljava/util/Collection;)[I

    move-result-object v5

    aput-object v5, v4, v3

    .end local v2    # "l":Ljava/util/ArrayList;
    .end local v3    # "k":I
    goto :goto_1ec

    .line 52
    .end local v8    # "ext":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "lists":Ljava/util/HashMap;
    :cond_214
    nop

    .line 29
    return-void
.end method

.method private final ci(FI)I
    .registers 8
    .param p1, "v"    # F
    .param p2, "axis"    # I

    .line 55
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->min:Lcom/exampletest/mobilestudiotest/model/Vector3;

    packed-switch p2, :pswitch_data_50

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    iget v1, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nz:I

    goto :goto_25

    :pswitch_10
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    iget v1, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ny:I

    goto :goto_25

    :pswitch_1b
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    iget v1, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nx:I

    :goto_25
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    .local v1, "o":F
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 56
    .local v0, "n":I
    sub-float v2, p1, v1

    iget v3, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cell:F

    div-float/2addr v2, v3

    float-to-int v2, v2

    add-int/lit8 v3, v0, -0x1

    const/4 v4, 0x0

    invoke-static {v2, v4, v3}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v2

    return v2

    nop

    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_10
    .end packed-switch
.end method

.method private final idx(III)I
    .registers 6
    .param p1, "i"    # I
    .param p2, "j"    # I
    .param p3, "k"    # I

    .line 58
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ny:I

    mul-int/2addr v0, p1

    add-int/2addr v0, p2

    iget v1, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nz:I

    mul-int/2addr v0, v1

    add-int/2addr v0, p3

    return v0
.end method


# virtual methods
.method public final cellIndex(FI)I
    .registers 4
    .param p1, "v"    # F
    .param p2, "axis"    # I

    .line 70
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ci(FI)I

    move-result v0

    return v0
.end method

.method public final forTris(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/functions/Function1;)V
    .registers 21
    .param p1, "lo"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "hi"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "f"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    const-string v2, "lo"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "hi"

    move-object/from16 v4, p2

    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "f"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    .line 62
    .local v2, "$i$f$forTris":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v6

    cmpg-float v5, v5, v6

    if-ltz v5, :cond_fb

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v6

    cmpl-float v5, v5, v6

    if-gtz v5, :cond_fb

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v6

    cmpg-float v5, v5, v6

    if-ltz v5, :cond_fb

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v6

    cmpl-float v5, v5, v6

    if-gtz v5, :cond_fb

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v6

    cmpg-float v5, v5, v6

    if-ltz v5, :cond_fb

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v6

    cmpl-float v5, v5, v6

    if-gtz v5, :cond_fb

    .line 63
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nextStamp()I

    move-result v5

    .line 64
    .local v5, "g":I
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v6

    const/4 v7, 0x0

    invoke-virtual {v0, v6, v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v6

    .local v6, "i":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v8

    invoke-virtual {v0, v8, v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v8

    if-gt v6, v8, :cond_fa

    :goto_8f
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v9

    const/4 v10, 0x1

    invoke-virtual {v0, v9, v10}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v9

    .local v9, "j":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v11

    invoke-virtual {v0, v11, v10}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v10

    if-gt v9, v10, :cond_f2

    :goto_a2
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v11

    const/4 v12, 0x2

    invoke-virtual {v0, v11, v12}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v11

    .local v11, "k":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v13

    invoke-virtual {v0, v13, v12}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cellIndex(FI)I

    move-result v12

    if-gt v11, v12, :cond_ea

    .line 65
    :goto_b5
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getCells()[[I

    move-result-object v13

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNy()I

    move-result v14

    mul-int/2addr v14, v6

    add-int/2addr v14, v9

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->getNz()I

    move-result v15

    mul-int/2addr v14, v15

    add-int/2addr v14, v11

    aget-object v13, v13, v14

    if-eqz v13, :cond_e2

    .line 66
    .local v13, "list":[I
    array-length v14, v13

    move v15, v7

    :goto_cb
    if-ge v15, v14, :cond_e2

    aget v7, v13, v15

    .local v7, "t":I
    invoke-virtual {v0, v7, v5}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->mark(II)Z

    move-result v16

    if-eqz v16, :cond_dc

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .end local v7    # "t":I
    :cond_dc
    add-int/lit8 v15, v15, 0x1

    const/4 v7, 0x0

    move-object/from16 v0, p0

    goto :goto_cb

    .line 64
    .end local v13    # "list":[I
    :cond_e2
    if-eq v11, v12, :cond_ea

    add-int/lit8 v11, v11, 0x1

    const/4 v7, 0x0

    move-object/from16 v0, p0

    goto :goto_b5

    .end local v11    # "k":I
    :cond_ea
    if-eq v9, v10, :cond_f2

    add-int/lit8 v9, v9, 0x1

    const/4 v7, 0x0

    move-object/from16 v0, p0

    goto :goto_a2

    .end local v9    # "j":I
    :cond_f2
    if-eq v6, v8, :cond_fa

    add-int/lit8 v6, v6, 0x1

    const/4 v7, 0x0

    move-object/from16 v0, p0

    goto :goto_8f

    .line 68
    .end local v6    # "i":I
    :cond_fa
    return-void

    .line 62
    .end local v5    # "g":I
    :cond_fb
    return-void
.end method

.method public final getCell()F
    .registers 2

    .line 31
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cell:F

    return v0
.end method

.method public final getCells()[[I
    .registers 2

    .line 33
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->cells:[[I

    return-object v0
.end method

.method public final getCount()I
    .registers 2

    .line 29
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->count:I

    return v0
.end method

.method public final getHull()Lcom/exampletest/mobilestudiotest/engine/ConvexShape;
    .registers 2

    .line 36
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->hull:Lcom/exampletest/mobilestudiotest/engine/ConvexShape;

    return-object v0
.end method

.method public final getKey()J
    .registers 3

    .line 29
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->key:J

    return-wide v0
.end method

.method public final getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 29
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->max:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public final getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 29
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->min:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public final getNrm()[F
    .registers 2

    .line 29
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nrm:[F

    return-object v0
.end method

.method public final getNx()I
    .registers 2

    .line 32
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nx:I

    return v0
.end method

.method public final getNy()I
    .registers 2

    .line 32
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->ny:I

    return v0
.end method

.method public final getNz()I
    .registers 2

    .line 32
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->nz:I

    return v0
.end method

.method public final getPos()[F
    .registers 2

    .line 29
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->pos:[F

    return-object v0
.end method

.method public final mark(II)Z
    .registers 4
    .param p1, "t"    # I
    .param p2, "g"    # I

    .line 72
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stamp:[I

    aget v0, v0, p1

    if-ne v0, p2, :cond_8

    const/4 v0, 0x0

    return v0

    :cond_8
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stamp:[I

    aput p2, v0, p1

    const/4 v0, 0x1

    return v0
.end method

.method public final nextStamp()I
    .registers 10

    .line 71
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stampGen:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stampGen:I

    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stampGen:I

    const v2, 0x7fffffff

    if-ne v0, v2, :cond_19

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stamp:[I

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Lkotlin/collections/ArraysKt;->fill$default([IIIIILjava/lang/Object;)V

    iput v1, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stampGen:I

    :cond_19
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->stampGen:I

    return v0
.end method

.method public final setHull(Lcom/exampletest/mobilestudiotest/engine/ConvexShape;)V
    .registers 2
    .param p1, "<set-?>"    # Lcom/exampletest/mobilestudiotest/engine/ConvexShape;

    .line 36
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;->hull:Lcom/exampletest/mobilestudiotest/engine/ConvexShape;

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.engine.CollisionMeshes$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.engine.CollisionMeshes$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;"
    method = "ray$lambda$9"
    proto = "([FLcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/internal/Ref$FloatRef;FLkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;I)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:[F

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field public final synthetic f$2:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field public final synthetic f$3:Lkotlin/jvm/internal/Ref$FloatRef;

.field public final synthetic f$4:F

.field public final synthetic f$5:Lkotlin/jvm/internal/Ref$ObjectRef;

.field public final synthetic f$6:Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;


# direct methods
.method public synthetic constructor <init>([FLcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/internal/Ref$FloatRef;FLkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;)V
    .registers 8

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$0:[F

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$2:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$3:Lkotlin/jvm/internal/Ref$FloatRef;

    iput p5, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$4:F

    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$5:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p7, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$6:Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$0:[F

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$1:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$2:Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$3:Lkotlin/jvm/internal/Ref$FloatRef;

    iget v4, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$4:F

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$5:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$$ExternalSyntheticLambda0;->f$6:Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-static/range {v0 .. v7}, Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes;->ray$lambda$9([FLcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/internal/Ref$FloatRef;FLkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/CollisionMeshes$Mesh;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
