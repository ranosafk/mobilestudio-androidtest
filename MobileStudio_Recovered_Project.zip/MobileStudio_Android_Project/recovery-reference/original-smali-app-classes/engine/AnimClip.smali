###### Class com.exampletest.mobilestudiotest.engine.AnimClip (com.exampletest.mobilestudiotest.engine.AnimClip)
.class public final Lcom/exampletest/mobilestudiotest/engine/AnimClip;
.super Ljava/lang/Object;
.source "KeyframeAnim.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;,
        Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0010\"\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0018\u0000 \u001e2\u00020\u0001:\u0002\u001d\u001eB9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0018\u0010\u0008\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u000c0\u000b0\t\u00a2\u0006\u0004\u0008\r\u0010\u000eJ\u0018\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\u0006\u0010\u001b\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00020\u0003R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0014R \u0010\u0008\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u000c0\u000b0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u0015\u001a\u0008\u0012\u0004\u0012\u00020\n0\u00168F\u00a2\u0006\u0006\u001a\u0004\u0008\u0017\u0010\u0018\u00a8\u0006\u001f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/engine/AnimClip;",
        "",
        "length",
        "",
        "looped",
        "",
        "priority",
        "",
        "joints",
        "",
        "",
        "",
        "Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;",
        "<init>",
        "(FZILjava/util/Map;)V",
        "getLength",
        "()F",
        "getLooped",
        "()Z",
        "getPriority",
        "()I",
        "jointNames",
        "",
        "getJointNames",
        "()Ljava/util/Set;",
        "sample",
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "joint",
        "t",
        "Key",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;


# instance fields
.field private final joints:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "[",
            "Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;",
            ">;"
        }
    .end annotation
.end field

.field private final length:F

.field private final looped:Z

.field private final priority:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->Companion:Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;

    return-void
.end method

.method public constructor <init>(FZILjava/util/Map;)V
    .registers 6
    .param p1, "length"    # F
    .param p2, "looped"    # Z
    .param p3, "priority"    # I
    .param p4, "joints"    # Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FZI",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "[",
            "Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;",
            ">;)V"
        }
    .end annotation

    const-string v0, "joints"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->length:F

    iput-boolean p2, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->looped:Z

    iput p3, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->priority:I

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->joints:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public final getJointNames()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 82
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->joints:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    return-object v0
.end method

.method public final getLength()F
    .registers 2

    .line 79
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->length:F

    return v0
.end method

.method public final getLooped()Z
    .registers 2

    .line 79
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->looped:Z

    return v0
.end method

.method public final getPriority()I
    .registers 2

    .line 79
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->priority:I

    return v0
.end method

.method public final sample(Ljava/lang/String;F)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 16
    .param p1, "joint"    # Ljava/lang/String;
    .param p2, "t"    # F

    const-string v0, "joint"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->joints:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;

    if-nez v0, :cond_11

    const/4 v0, 0x0

    return-object v0

    .line 87
    .local v0, "keys":[Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    :cond_11
    array-length v1, v0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v1, v3, :cond_85

    aget-object v1, v0, v2

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getT()F

    move-result v1

    cmpg-float v1, p2, v1

    if-lez v1, :cond_85

    .line 88
    array-length v1, v0

    sub-int/2addr v1, v3

    aget-object v1, v0, v1

    .line 89
    .local v1, "last":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getT()F

    move-result v2

    cmpl-float v2, p2, v2

    if-ltz v2, :cond_31

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    return-object v2

    .line 90
    :cond_31
    const/4 v2, 0x0

    .line 91
    .local v2, "i":I
    :goto_32
    array-length v3, v0

    add-int/lit8 v3, v3, -0x2

    if-ge v2, v3, :cond_46

    add-int/lit8 v3, v2, 0x1

    aget-object v3, v0, v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getT()F

    move-result v3

    cmpg-float v3, v3, p2

    if-gtz v3, :cond_46

    add-int/lit8 v2, v2, 0x1

    goto :goto_32

    .line 92
    :cond_46
    aget-object v3, v0, v2

    .local v3, "a":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    add-int/lit8 v4, v2, 0x1

    aget-object v4, v0, v4

    .line 93
    .local v4, "b":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getT()F

    move-result v5

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getT()F

    move-result v6

    sub-float/2addr v5, v6

    .line 94
    .local v5, "span":F
    const v6, 0x3727c5ac    # 1.0E-5f

    cmpg-float v6, v5, v6

    if-gtz v6, :cond_61

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v6

    return-object v6

    .line 95
    :cond_61
    sget-object v6, Lcom/exampletest/mobilestudiotest/engine/Quat;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Quat;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v8

    sget-object v9, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->Companion:Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getT()F

    move-result v10

    sub-float v10, p2, v10

    div-float/2addr v10, v5

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getStyle()I

    move-result v11

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getDir()I

    move-result v12

    invoke-virtual {v9, v10, v11, v12}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->ease(FII)F

    move-result v9

    invoke-virtual {v6, v7, v8, v9}, Lcom/exampletest/mobilestudiotest/engine/Quat;->lerp(Lcom/exampletest/mobilestudiotest/model/CFrame;Lcom/exampletest/mobilestudiotest/model/CFrame;F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v6

    return-object v6

    .line 87
    .end local v1    # "last":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    .end local v2    # "i":I
    .end local v3    # "a":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    .end local v4    # "b":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    .end local v5    # "span":F
    :cond_85
    aget-object v1, v0, v2

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    return-object v1
.end method

###### Class com.exampletest.mobilestudiotest.engine.AnimClip.Companion (com.exampletest.mobilestudiotest.engine.AnimClip$Companion)
.class public final Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;
.super Ljava/lang/Object;
.source "KeyframeAnim.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/engine/AnimClip;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nKeyframeAnim.kt\nKotlin\n*S Kotlin\n*F\n+ 1 KeyframeAnim.kt\ncom/exampletest/mobilestudiotest/engine/AnimClip$Companion\n+ 2 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,414:1\n463#2:415\n413#2:416\n382#2,7:425\n1252#3,2:417\n1056#3:419\n1255#3:424\n37#4:420\n36#4,3:421\n*S KotlinDebug\n*F\n+ 1 KeyframeAnim.kt\ncom/exampletest/mobilestudiotest/engine/AnimClip$Companion\n*L\n151#1:415\n151#1:416\n143#1:425,7\n151#1:417,2\n151#1:419\n151#1:424\n151#1:420\n151#1:421,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u001e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u00082\u0006\u0010\t\u001a\u00020\u0008J\u0010\u0010\n\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u0005H\u0002J\u0010\u0010\u000c\u001a\u0004\u0018\u00010\r2\u0006\u0010\u000e\u001a\u00020\u000f\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;",
        "",
        "<init>",
        "()V",
        "ease",
        "",
        "x",
        "style",
        "",
        "dir0",
        "bounceOut",
        "t",
        "from",
        "Lcom/exampletest/mobilestudiotest/engine/AnimClip;",
        "seq",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 98
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;-><init>()V

    return-void
.end method

.method private final bounceOut(F)F
    .registers 5
    .param p1, "t"    # F

    .line 120
    nop

    .line 121
    const v0, 0x3eba2e8c

    cmpg-float v0, p1, v0

    const/high16 v1, 0x40f20000    # 7.5625f

    if-gez v0, :cond_d

    mul-float/2addr v1, p1

    mul-float/2addr v1, p1

    goto :goto_3b

    .line 122
    :cond_d
    const v0, 0x3f3a2e8c

    cmpg-float v0, p1, v0

    if-gez v0, :cond_1f

    const v0, 0x3f0ba2e9

    sub-float v0, p1, v0

    .local v0, "u":F
    mul-float/2addr v1, v0

    mul-float/2addr v1, v0

    const/high16 v2, 0x3f400000    # 0.75f

    add-float/2addr v1, v2

    .end local v0    # "u":F
    goto :goto_3b

    .line 123
    :cond_1f
    const v0, 0x3f68ba2f

    cmpg-float v0, p1, v0

    if-gez v0, :cond_31

    const v0, 0x3f51745d

    sub-float v0, p1, v0

    .restart local v0    # "u":F
    mul-float/2addr v1, v0

    mul-float/2addr v1, v0

    const/high16 v2, 0x3f700000    # 0.9375f

    add-float/2addr v1, v2

    .end local v0    # "u":F
    goto :goto_3b

    .line 124
    :cond_31
    const v0, 0x3f745d17

    sub-float v0, p1, v0

    .restart local v0    # "u":F
    mul-float/2addr v1, v0

    mul-float/2addr v1, v0

    const/high16 v2, 0x3f7c0000    # 0.984375f

    add-float/2addr v1, v2

    .line 125
    .end local v0    # "u":F
    :goto_3b
    return v1
.end method

.method private static final ease$inF(IF)F
    .registers 6
    .param p0, "$style"    # I
    .param p1, "t"    # F

    .line 108
    const/high16 v0, 0x3f800000    # 1.0f

    packed-switch p0, :pswitch_data_42

    .line 111
    :pswitch_5
    mul-float v0, p1, p1

    mul-float/2addr v0, p1

    goto :goto_40

    .line 110
    :pswitch_9
    sget-object v1, Lcom/exampletest/mobilestudiotest/engine/AnimClip;->Companion:Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;

    sub-float v2, v0, p1

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->bounceOut(F)F

    move-result v1

    sub-float/2addr v0, v1

    goto :goto_40

    .line 109
    :pswitch_13
    const/4 v1, 0x0

    cmpg-float v1, p1, v1

    if-lez v1, :cond_3f

    cmpl-float v1, p1, v0

    if-gez v1, :cond_3f

    const/high16 v1, 0x41200000    # 10.0f

    sub-float v0, p1, v0

    mul-float/2addr v0, v1

    float-to-double v0, v0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    double-to-float v0, v0

    neg-float v0, v0

    const v1, 0x3f89999a    # 1.075f

    sub-float v1, p1, v1

    const v2, 0x40c90fdb

    mul-float/2addr v1, v2

    const v2, 0x3e99999a    # 0.3f

    div-float/2addr v1, v2

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v1, v1

    mul-float/2addr v0, v1

    goto :goto_40

    :cond_3f
    move v0, p1

    .line 112
    :goto_40
    return v0

    nop

    :pswitch_data_42
    .packed-switch 0x2
        :pswitch_13
        :pswitch_5
        :pswitch_9
    .end packed-switch
.end method

.method private static final from$walk(Ljava/util/HashMap;FLcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 15
    .param p0, "lists"    # Ljava/util/HashMap;
    .param p1, "t"    # F
    .param p2, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;",
            ">;>;F",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ")V"
        }
    .end annotation

    .line 136
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v1, "iterator(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_d
    :goto_d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_b2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const-string v2, "next(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 137
    .local v1, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "Pose"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d

    .line 138
    const-string v2, "Weight"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v3, v2, Ljava/lang/Number;

    const/4 v4, 0x0

    if-eqz v3, :cond_38

    check-cast v2, Ljava/lang/Number;

    goto :goto_39

    :cond_38
    move-object v2, v4

    :goto_39
    if-eqz v2, :cond_40

    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    move-result v2

    goto :goto_42

    :cond_40
    const/high16 v2, 0x3f800000    # 1.0f

    .line 139
    .local v2, "w":F
    :goto_42
    const/4 v3, 0x0

    cmpl-float v3, v2, v3

    if-lez v3, :cond_ad

    .line 140
    const-string v3, "CFrame"

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_54

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    goto :goto_55

    :cond_54
    move-object v3, v4

    :goto_55
    if-nez v3, :cond_5d

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    .line 141
    .local v3, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    :cond_5d
    const-string v5, "EasingStyle"

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v6, :cond_6a

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    goto :goto_6b

    :cond_6a
    move-object v5, v4

    :goto_6b
    const/4 v6, 0x0

    if-eqz v5, :cond_73

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v5

    goto :goto_74

    :cond_73
    move v5, v6

    .line 142
    .local v5, "st":I
    :goto_74
    const-string v7, "EasingDirection"

    invoke-virtual {v1, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v8, :cond_81

    move-object v4, v7

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    :cond_81
    if-eqz v4, :cond_87

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v6

    .line 143
    .local v6, "dr":I
    :cond_87
    move-object v4, p0

    check-cast v4, Ljava/util/Map;

    .local v4, "$this$getOrPut\\1":Ljava/util/Map;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v7

    .local v7, "key\\1":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 425
    .local v8, "$i$f$getOrPut\\1\\143":I
    invoke-interface {v4, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    .line 426
    .local v9, "value\\1":Ljava/lang/Object;
    if-nez v9, :cond_a1

    .line 427
    const/4 v10, 0x0

    .line 143
    .local v10, "$i$a$-getOrPut-AnimClip$Companion$from$walk$1\\2\\427\\0":I
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 427
    .end local v10    # "$i$a$-getOrPut-AnimClip$Companion$from$walk$1\\2\\427\\0":I
    nop

    .line 428
    .local v11, "answer\\1":Ljava/lang/Object;
    invoke-interface {v4, v7, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 429
    nop

    .end local v11    # "answer\\1":Ljava/lang/Object;
    goto :goto_a2

    .line 431
    :cond_a1
    move-object v11, v9

    .line 426
    :goto_a2
    nop

    .end local v4    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v7    # "key\\1":Ljava/lang/Object;
    .end local v8    # "$i$f$getOrPut\\1\\143":I
    .end local v9    # "value\\1":Ljava/lang/Object;
    check-cast v11, Ljava/util/ArrayList;

    .line 143
    new-instance v4, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;

    invoke-direct {v4, p1, v3, v5, v6}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;-><init>(FLcom/exampletest/mobilestudiotest/model/CFrame;II)V

    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 145
    .end local v3    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v5    # "st":I
    .end local v6    # "dr":I
    :cond_ad
    invoke-static {p0, p1, v1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->from$walk(Ljava/util/HashMap;FLcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v1    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "w":F
    goto/16 :goto_d

    .line 147
    :cond_b2
    return-void
.end method


# virtual methods
.method public final ease(FII)F
    .registers 8
    .param p1, "x"    # F
    .param p2, "style"    # I
    .param p3, "dir0"    # I

    .line 105
    if-nez p2, :cond_3

    return p1

    .line 106
    :cond_3
    const/4 v0, 0x1

    if-ne p2, v0, :cond_8

    const/4 v0, 0x0

    return v0

    .line 107
    :cond_8
    const/4 v0, 0x5

    if-eq p2, v0, :cond_11

    const/4 v0, 0x2

    if-eq p3, v0, :cond_11

    rsub-int/lit8 v0, p3, 0x1

    goto :goto_12

    :cond_11
    move v0, p3

    .line 113
    .local v0, "dir":I
    :goto_12
    const/high16 v1, 0x3f800000    # 1.0f

    packed-switch v0, :pswitch_data_3e

    .line 116
    const/high16 v2, 0x3f000000    # 0.5f

    cmpg-float v2, p1, v2

    const/high16 v3, 0x40000000    # 2.0f

    if-gez v2, :cond_34

    mul-float v1, p1, v3

    invoke-static {p2, v1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->ease$inF(IF)F

    move-result v1

    div-float/2addr v1, v3

    goto :goto_3d

    .line 115
    :pswitch_27
    sub-float v2, v1, p1

    invoke-static {p2, v2}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->ease$inF(IF)F

    move-result v2

    sub-float/2addr v1, v2

    goto :goto_3d

    .line 114
    :pswitch_2f
    invoke-static {p2, p1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->ease$inF(IF)F

    move-result v1

    goto :goto_3d

    .line 116
    :cond_34
    sub-float v2, v1, p1

    mul-float/2addr v2, v3

    invoke-static {p2, v2}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->ease$inF(IF)F

    move-result v2

    div-float/2addr v2, v3

    sub-float/2addr v1, v2

    .line 113
    :goto_3d
    return v1

    :pswitch_data_3e
    .packed-switch 0x0
        :pswitch_2f
        :pswitch_27
    .end packed-switch
.end method

.method public final from(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/engine/AnimClip;
    .registers 23
    .param p1, "seq"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    move-object/from16 v0, p1

    const-string v1, "seq"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 128
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "KeyframeSequence"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_15

    return-object v2

    .line 129
    :cond_15
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 130
    .local v1, "lists":Ljava/util/HashMap;
    const/4 v3, 0x0

    .line 131
    .local v3, "length":F
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    const-string v5, "iterator(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_28
    :goto_28
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_64

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const-string v6, "next(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 132
    .local v5, "kf":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v6

    const-string v7, "Keyframe"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_28

    .line 133
    const-string v6, "Time"

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v6, Ljava/lang/Number;

    if-eqz v7, :cond_52

    check-cast v6, Ljava/lang/Number;

    goto :goto_53

    :cond_52
    move-object v6, v2

    :goto_53
    if-eqz v6, :cond_5a

    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    move-result v6

    goto :goto_5b

    :cond_5a
    const/4 v6, 0x0

    .line 134
    .local v6, "t":F
    :goto_5b
    cmpl-float v7, v6, v3

    if-lez v7, :cond_60

    move v3, v6

    .line 148
    :cond_60
    invoke-static {v1, v6, v5}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->from$walk(Ljava/util/HashMap;FLcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v5    # "kf":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v6    # "t":F
    goto :goto_28

    .line 150
    :cond_64
    invoke-virtual {v1}, Ljava/util/HashMap;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_6b

    return-object v2

    .line 151
    :cond_6b
    move-object v4, v1

    check-cast v4, Ljava/util/Map;

    .local v4, "$this$mapValues\\1":Ljava/util/Map;
    const/4 v5, 0x0

    .line 415
    .local v5, "$i$f$mapValues\\1\\151":I
    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-interface {v4}, Ljava/util/Map;->size()I

    move-result v7

    invoke-static {v7}, Lkotlin/collections/MapsKt;->mapCapacity(I)I

    move-result v7

    invoke-direct {v6, v7}, Ljava/util/LinkedHashMap;-><init>(I)V

    check-cast v6, Ljava/util/Map;

    .local v6, "destination\\2":Ljava/util/Map;
    move-object v7, v4

    .local v7, "$this$mapValuesTo\\2":Ljava/util/Map;
    const/4 v8, 0x0

    .line 416
    .local v8, "$i$f$mapValuesTo\\2\\415":I
    invoke-interface {v7}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v9

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$associateByTo\\3":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 417
    .local v10, "$i$f$associateByTo\\3\\416":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_8b
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_d6

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .line 418
    .local v12, "element\\3":Ljava/lang/Object;
    move-object v14, v12

    check-cast v14, Ljava/util/Map$Entry;

    .local v14, "it\\4":Ljava/util/Map$Entry;
    const/4 v15, 0x0

    .line 416
    .local v15, "$i$a$-associateByTo-MapsKt__MapsKt$mapValuesTo$1\\4\\418\\2":I
    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v14

    .line 418
    .end local v14    # "it\\4":Ljava/util/Map$Entry;
    .end local v15    # "$i$a$-associateByTo-MapsKt__MapsKt$mapValuesTo$1\\4\\418\\2":I
    move-object v15, v12

    check-cast v15, Ljava/util/Map$Entry;

    const/16 v16, 0x0

    .local v16, "$i$a$-mapValues-AnimClip$Companion$from$joints$1\\5\\418\\0":I
    invoke-interface {v15}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/util/ArrayList;

    .line 151
    .local v15, "l\\5":Ljava/util/ArrayList;
    move-object v2, v15

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$sortedBy\\6":Ljava/lang/Iterable;
    const/16 v18, 0x0

    .line 419
    .local v18, "$i$f$sortedBy\\6\\151":I
    new-instance v19, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion$from$lambda$2$$inlined$sortedBy$1;

    invoke-direct/range {v19 .. v19}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion$from$lambda$2$$inlined$sortedBy$1;-><init>()V

    move-object/from16 v13, v19

    check-cast v13, Ljava/util/Comparator;

    invoke-static {v2, v13}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v2

    .end local v2    # "$this$sortedBy\\6":Ljava/lang/Iterable;
    .end local v18    # "$i$f$sortedBy\\6\\151":I
    check-cast v2, Ljava/util/Collection;

    .line 151
    nop

    .local v2, "$this$toTypedArray\\7":Ljava/util/Collection;
    const/4 v13, 0x0

    .line 420
    .local v13, "$i$f$toTypedArray\\7\\151":I
    nop

    .line 421
    move-object/from16 v18, v2

    .line 423
    .local v18, "this_\\7":Ljava/util/Collection;
    move-object/from16 v19, v1

    const/4 v1, 0x0

    .end local v1    # "lists":Ljava/util/HashMap;
    .local v19, "lists":Ljava/util/HashMap;
    new-array v1, v1, [Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;

    move-object/from16 v20, v2

    .end local v18    # "this_\\7":Ljava/util/Collection;
    .local v2, "this_\\7":Ljava/util/Collection;
    .local v20, "$this$toTypedArray\\7":Ljava/util/Collection;
    invoke-interface {v2, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    .end local v2    # "this_\\7":Ljava/util/Collection;
    .end local v13    # "$i$f$toTypedArray\\7\\151":I
    .end local v20    # "$this$toTypedArray\\7":Ljava/util/Collection;
    check-cast v1, [Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;

    .line 151
    nop

    .line 418
    .end local v15    # "l\\5":Ljava/util/ArrayList;
    .end local v16    # "$i$a$-mapValues-AnimClip$Companion$from$joints$1\\5\\418\\0":I
    invoke-interface {v6, v14, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v1, v19

    const/4 v2, 0x0

    goto :goto_8b

    .line 424
    .end local v12    # "element\\3":Ljava/lang/Object;
    .end local v19    # "lists":Ljava/util/HashMap;
    .restart local v1    # "lists":Ljava/util/HashMap;
    :cond_d6
    move-object/from16 v19, v1

    .line 416
    .end local v1    # "lists":Ljava/util/HashMap;
    .end local v9    # "$this$associateByTo\\3":Ljava/lang/Iterable;
    .end local v10    # "$i$f$associateByTo\\3\\416":I
    .restart local v19    # "lists":Ljava/util/HashMap;
    nop

    .line 415
    .end local v6    # "destination\\2":Ljava/util/Map;
    .end local v7    # "$this$mapValuesTo\\2":Ljava/util/Map;
    .end local v8    # "$i$f$mapValuesTo\\2\\415":I
    nop

    .line 151
    .end local v4    # "$this$mapValues\\1":Ljava/util/Map;
    .end local v5    # "$i$f$mapValues\\1\\151":I
    nop

    .line 152
    .local v6, "joints":Ljava/util/Map;
    new-instance v1, Lcom/exampletest/mobilestudiotest/engine/AnimClip;

    const-string v2, "Loop"

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/16 v20, 0x0

    invoke-static/range {v20 .. v20}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    xor-int/lit8 v2, v2, 0x1

    const-string v4, "Priority"

    invoke-virtual {v0, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    instance-of v5, v4, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v5, :cond_fe

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    move-object/from16 v17, v4

    goto :goto_100

    :cond_fe
    const/16 v17, 0x0

    :goto_100
    if-eqz v17, :cond_107

    invoke-virtual/range {v17 .. v17}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v13

    goto :goto_109

    :cond_107
    move/from16 v13, v20

    :goto_109
    invoke-direct {v1, v3, v2, v13, v6}, Lcom/exampletest/mobilestudiotest/engine/AnimClip;-><init>(FZILjava/util/Map;)V

    return-object v1
.end method

###### Class com.exampletest.mobilestudiotest.engine.AnimClip$Companion$from$lambda$2$$inlined$sortedBy$1 (com.exampletest.mobilestudiotest.engine.AnimClip$Companion$from$lambda$2$$inlined$sortedBy$1)
.class public final Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion$from$lambda$2$$inlined$sortedBy$1;
.super Ljava/lang/Object;
.source "Comparisons.kt"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/engine/AnimClip$Companion;->from(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/engine/AnimClip;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Comparator;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nComparisons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Comparisons.kt\nkotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2\n+ 2 KeyframeAnim.kt\ncom/exampletest/mobilestudiotest/engine/AnimClip$Companion\n*L\n1#1,328:1\n151#2:329\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 7
    .param p1, "a"    # Ljava/lang/Object;
    .param p2, "b"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)I"
        }
    .end annotation

    .line 102
    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;

    .local v0, "it\\1":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    const/4 v1, 0x0

    .line 329
    .local v1, "$i$a$-sortedBy-AnimClip$Companion$from$joints$1$1\\1\\102\\0":I
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getT()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    .line 102
    .end local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    .end local v1    # "$i$a$-sortedBy-AnimClip$Companion$from$joints$1$1\\1\\102\\0":I
    check-cast v0, Ljava/lang/Comparable;

    move-object v1, p2

    check-cast v1, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;

    .local v1, "it\\2":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    const/4 v2, 0x0

    .line 329
    .local v2, "$i$a$-sortedBy-AnimClip$Companion$from$joints$1$1\\2\\102\\0":I
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->getT()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    .line 102
    .end local v1    # "it\\2":Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
    .end local v2    # "$i$a$-sortedBy-AnimClip$Companion$from$joints$1$1\\2\\102\\0":I
    check-cast v1, Ljava/lang/Comparable;

    invoke-static {v0, v1}, Lkotlin/comparisons/ComparisonsKt;->compareValues(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    move-result v0

    return v0
.end method

###### Class com.exampletest.mobilestudiotest.engine.AnimClip.Key (com.exampletest.mobilestudiotest.engine.AnimClip$Key)
.class public final Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;
.super Ljava/lang/Object;
.source "KeyframeAnim.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/engine/AnimClip;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Key"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u000b\u0018\u00002\u00020\u0001B\'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R\u0011\u0010\u0008\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0010\u00a8\u0006\u0012"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;",
        "",
        "t",
        "",
        "cf",
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "style",
        "",
        "dir",
        "<init>",
        "(FLcom/exampletest/mobilestudiotest/model/CFrame;II)V",
        "getT",
        "()F",
        "getCf",
        "()Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "getStyle",
        "()I",
        "getDir",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final cf:Lcom/exampletest/mobilestudiotest/model/CFrame;

.field private final dir:I

.field private final style:I

.field private final t:F


# direct methods
.method public constructor <init>(FLcom/exampletest/mobilestudiotest/model/CFrame;II)V
    .registers 6
    .param p1, "t"    # F
    .param p2, "cf"    # Lcom/exampletest/mobilestudiotest/model/CFrame;
    .param p3, "style"    # I
    .param p4, "dir"    # I

    const-string v0, "cf"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->t:F

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->cf:Lcom/exampletest/mobilestudiotest/model/CFrame;

    iput p3, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->style:I

    iput p4, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->dir:I

    return-void
.end method


# virtual methods
.method public final getCf()Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 2

    .line 80
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->cf:Lcom/exampletest/mobilestudiotest/model/CFrame;

    return-object v0
.end method

.method public final getDir()I
    .registers 2

    .line 80
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->dir:I

    return v0
.end method

.method public final getStyle()I
    .registers 2

    .line 80
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->style:I

    return v0
.end method

.method public final getT()F
    .registers 2

    .line 80
    iget v0, p0, Lcom/exampletest/mobilestudiotest/engine/AnimClip$Key;->t:F

    return v0
.end method
