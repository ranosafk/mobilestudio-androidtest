###### Class com.exampletest.mobilestudiotest.R (com.exampletest.mobilestudiotest.R)
.class public final Lcom/exampletest/mobilestudiotest/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/R$color;,
        Lcom/exampletest/mobilestudiotest/R$drawable;,
        Lcom/exampletest/mobilestudiotest/R$mipmap;,
        Lcom/exampletest/mobilestudiotest/R$string;,
        Lcom/exampletest/mobilestudiotest/R$style;,
        Lcom/exampletest/mobilestudiotest/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.R.anim is created by jadx
###### Class com.exampletest.mobilestudiotest.R.animator is created by jadx
###### Class com.exampletest.mobilestudiotest.R.attr is created by jadx
###### Class com.exampletest.mobilestudiotest.R.bool is created by jadx
###### Class com.exampletest.mobilestudiotest.R.color (com.exampletest.mobilestudiotest.R$color)
.class public final Lcom/exampletest/mobilestudiotest/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static black:I = 0x7f050021

.field public static ic_launcher_background:I = 0x7f050060

.field public static white:I = 0x7f0503c1


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.R.dimen is created by jadx
###### Class com.exampletest.mobilestudiotest.R.drawable (com.exampletest.mobilestudiotest.R$drawable)
.class public final Lcom/exampletest/mobilestudiotest/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static ic_launcher_background:I = 0x7f070093

.field public static ic_launcher_foreground:I = 0x7f070094


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.R.id is created by jadx
###### Class com.exampletest.mobilestudiotest.R.integer is created by jadx
###### Class com.exampletest.mobilestudiotest.R.interpolator is created by jadx
###### Class com.exampletest.mobilestudiotest.R.layout is created by jadx
###### Class com.exampletest.mobilestudiotest.R.mipmap (com.exampletest.mobilestudiotest.R$mipmap)
.class public final Lcom/exampletest/mobilestudiotest/R$mipmap;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mipmap"
.end annotation


# static fields
.field public static ic_launcher:I = 0x7f0d0000

.field public static ic_launcher_foreground:I = 0x7f0d0001

.field public static ic_launcher_round:I = 0x7f0d0002


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.R.plurals is created by jadx
###### Class com.exampletest.mobilestudiotest.R.string (com.exampletest.mobilestudiotest.R$string)
.class public final Lcom/exampletest/mobilestudiotest/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static app_name:I = 0x7f0f001c


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.R.style (com.exampletest.mobilestudiotest.R$style)
.class public final Lcom/exampletest/mobilestudiotest/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static Base_Theme_Mobilestudiotest:I = 0x7f10007f

.field public static Theme_Mobilestudiotest:I = 0x7f100351


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.R.xml (com.exampletest.mobilestudiotest.R$xml)
.class public final Lcom/exampletest/mobilestudiotest/R$xml;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static backup_rules:I = 0x7f120000

.field public static data_extraction_rules:I = 0x7f120001


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
