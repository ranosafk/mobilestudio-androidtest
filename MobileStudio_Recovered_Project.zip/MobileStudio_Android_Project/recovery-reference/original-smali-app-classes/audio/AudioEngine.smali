###### Class com.exampletest.mobilestudiotest.audio.AudioEngine (com.exampletest.mobilestudiotest.audio.AudioEngine)
.class public final Lcom/exampletest/mobilestudiotest/audio/AudioEngine;
.super Ljava/lang/Object;
.source "AudioEngine.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;,
        Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;,
        Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;,
        Lcom/exampletest/mobilestudiotest/audio/AudioEngine$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAudioEngine.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AudioEngine.kt\ncom/exampletest/mobilestudiotest/audio/AudioEngine\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,358:1\n1#2:359\n1761#3,3:360\n1869#3,2:363\n*S KotlinDebug\n*F\n+ 1 AudioEngine.kt\ncom/exampletest/mobilestudiotest/audio/AudioEngine\n*L\n155#1:360,3\n245#1:363,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0082\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u000b\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0010\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0003LMNB\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0017\u0010\u001c\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u001d\u001a\u00020\u000cH\u0002\u00a2\u0006\u0002\u0010\u001eJ\"\u0010\u001f\u001a\u00020 2\u0008\u0010!\u001a\u0004\u0018\u00010\u000c2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020 H\u0002J\u000e\u0010%\u001a\u00020\u00142\u0006\u0010&\u001a\u00020\'J\u0010\u0010(\u001a\u00020\u00142\u0006\u0010)\u001a\u00020\rH\u0002J\u0018\u0010*\u001a\u00020\u00142\u0006\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020 H\u0002J8\u0010.\u001a\u00020\u00142\u0006\u0010)\u001a\u00020\r2\u0006\u0010/\u001a\u00020 2\u0006\u00100\u001a\u00020 2\u0006\u0010-\u001a\u00020 2\u0006\u00101\u001a\u0002022\u0006\u00103\u001a\u000202H\u0002J\u0010\u00104\u001a\u00020\u00142\u0006\u0010)\u001a\u00020\rH\u0002J\u0010\u00105\u001a\u00020\u00142\u0006\u0010)\u001a\u00020\rH\u0002J\u0006\u00106\u001a\u00020\u0014J\u0008\u0010B\u001a\u00020\u0014H\u0002J\u0018\u0010C\u001a\u00020\u00142\u0006\u0010D\u001a\u00020\u00102\u0008\u0008\u0002\u0010E\u001a\u00020 J\u0018\u00104\u001a\u00020\u00142\u0006\u0010F\u001a\u0002082\u0006\u0010+\u001a\u00020,H\u0002J\u0006\u0010G\u001a\u00020\u0014J\u0006\u0010H\u001a\u00020\u0014J\u0016\u0010I\u001a\u00020\u00142\u0006\u0010D\u001a\u00020\u00102\u0006\u0010J\u001a\u00020 J\u0006\u0010K\u001a\u00020\u0014R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u000c\u0012\u0004\u0012\u00020\r0\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u000e\u001a\u0012\u0012\u0004\u0012\u00020\u00100\u000fj\u0008\u0012\u0004\u0012\u00020\u0010`\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000R(\u0010\u0012\u001a\u0010\u0012\u0004\u0012\u00020\u000c\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0015\u0010\u0016\"\u0004\u0008\u0017\u0010\u0018R(\u0010\u0019\u001a\u0010\u0012\u0004\u0012\u00020\u000c\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001a\u0010\u0016\"\u0004\u0008\u001b\u0010\u0018R\"\u00109\u001a\u0004\u0018\u0001082\u0008\u00107\u001a\u0004\u0018\u000108@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008:\u0010;R\u0010\u0010<\u001a\u0004\u0018\u00010,X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001d\u0010=\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00140?0>\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008@\u0010A\u00a8\u0006O"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;",
        "",
        "<init>",
        "()V",
        "thread",
        "Landroid/os/HandlerThread;",
        "h",
        "Landroid/os/Handler;",
        "MAX_VOICES",
        "",
        "voices",
        "Ljava/util/IdentityHashMap;",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;",
        "missing",
        "Ljava/util/HashSet;",
        "",
        "Lkotlin/collections/HashSet;",
        "onLoaded",
        "Lkotlin/Function1;",
        "",
        "getOnLoaded",
        "()Lkotlin/jvm/functions/Function1;",
        "setOnLoaded",
        "(Lkotlin/jvm/functions/Function1;)V",
        "onEnded",
        "getOnEnded",
        "setOnEnded",
        "soundId",
        "s",
        "(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/Long;",
        "num",
        "",
        "i",
        "k",
        "",
        "d",
        "update",
        "studio",
        "Lcom/exampletest/mobilestudiotest/core/Studio;",
        "create",
        "v",
        "setSpeed",
        "mp",
        "Landroid/media/MediaPlayer;",
        "speed",
        "apply",
        "l",
        "r",
        "loop",
        "",
        "restart",
        "tick",
        "release",
        "stopAll",
        "value",
        "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;",
        "preview",
        "getPreview",
        "()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;",
        "previewPlayer",
        "previewListeners",
        "Ljava/util/concurrent/CopyOnWriteArrayList;",
        "Lkotlin/Function0;",
        "getPreviewListeners",
        "()Ljava/util/concurrent/CopyOnWriteArrayList;",
        "notifyPreview",
        "togglePreview",
        "id",
        "volume",
        "p",
        "pausePreview",
        "resumePreview",
        "seekPreview",
        "seconds",
        "stopPreview",
        "Voice",
        "PreviewState",
        "Preview",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

.field private static final MAX_VOICES:I = 0x1c

.field private static final h:Landroid/os/Handler;

.field private static final missing:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private static onEnded:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private static onLoaded:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

.field private static final previewListeners:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field

.field private static previewPlayer:Landroid/media/MediaPlayer;

.field private static final thread:Landroid/os/HandlerThread;

.field private static final voices:Ljava/util/IdentityHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/IdentityHashMap<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    .line 25
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "audio"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    move-object v1, v0

    .line 359
    .local v1, "it\\1":Landroid/os/HandlerThread;
    const/4 v2, 0x0

    .line 25
    .local v2, "$i$a$-also-AudioEngine$thread$1\\1\\25\\0":I
    invoke-virtual {v1}, Landroid/os/HandlerThread;->start()V

    .end local v1    # "it\\1":Landroid/os/HandlerThread;
    .end local v2    # "$i$a$-also-AudioEngine$thread$1\\1\\25\\0":I
    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->thread:Landroid/os/HandlerThread;

    .line 26
    new-instance v0, Landroid/os/Handler;

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->thread:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    .line 44
    new-instance v0, Ljava/util/IdentityHashMap;

    invoke-direct {v0}, Ljava/util/IdentityHashMap;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    .line 45
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->missing:Ljava/util/HashSet;

    .line 243
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewListeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$getH$p()Landroid/os/Handler;
    .registers 1

    .line 24
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    return-object v0
.end method

.method public static final synthetic access$getPreviewPlayer$p()Landroid/media/MediaPlayer;
    .registers 1

    .line 24
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewPlayer:Landroid/media/MediaPlayer;

    return-object v0
.end method

.method public static final synthetic access$notifyPreview(Lcom/exampletest/mobilestudiotest/audio/AudioEngine;)V
    .registers 1
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    .line 24
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    return-void
.end method

.method private final apply(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;FFFZZ)V
    .registers 9
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .param p2, "l"    # F
    .param p3, "r"    # F
    .param p4, "speed"    # F
    .param p5, "loop"    # Z
    .param p6, "restart"    # Z

    .line 197
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getMp()Landroid/media/MediaPlayer;

    move-result-object v0

    if-nez v0, :cond_7

    return-void

    .line 198
    .local v0, "mp":Landroid/media/MediaPlayer;
    :cond_7
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getPrepared()Z

    move-result v1

    if-nez v1, :cond_e

    return-void

    .line 199
    :cond_e
    nop

    .line 200
    :try_start_f
    invoke-virtual {v0, p2, p3}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 201
    invoke-virtual {v0, p5}, Landroid/media/MediaPlayer;->setLooping(Z)V

    .line 202
    invoke-direct {p0, v0, p4}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->setSpeed(Landroid/media/MediaPlayer;F)V

    .line 203
    if-nez p6, :cond_20

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v1

    if-nez v1, :cond_28

    :cond_20
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V

    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->tick(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_26} :catch_27

    goto :goto_28

    .line 204
    :catch_27
    move-exception v1

    .line 205
    :cond_28
    :goto_28
    return-void
.end method

.method private final create(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 4
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .line 162
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda12;

    invoke-direct {v1, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda12;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 189
    return-void
.end method

.method static final create$lambda$12(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 8
    .param p0, "$v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .line 163
    nop

    .line 164
    :try_start_1
    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getId()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->cacheFile(J)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_10

    return-void

    :cond_10
    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 165
    .local v0, "f":Ljava/io/File;
    new-instance v1, Landroid/media/MediaPlayer;

    invoke-direct {v1}, Landroid/media/MediaPlayer;-><init>()V

    .line 166
    .local v1, "mp":Landroid/media/MediaPlayer;
    new-instance v2, Landroid/media/AudioAttributes$Builder;

    invoke-direct {v2}, Landroid/media/AudioAttributes$Builder;-><init>()V

    const/16 v3, 0xe

    invoke-virtual {v2, v3}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v2

    const/4 v3, 0x4

    invoke-virtual {v2, v3}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/media/MediaPlayer;->setAudioAttributes(Landroid/media/AudioAttributes;)V

    .line 167
    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    .line 168
    new-instance v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda13;

    invoke-direct {v2, p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda13;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    invoke-virtual {v1, v2}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    .line 180
    new-instance v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda14;

    invoke-direct {v2, p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda14;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    invoke-virtual {v1, v2}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 181
    new-instance v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda15;

    invoke-direct {v2, p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda15;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    invoke-virtual {v1, v2}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    .line 182
    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setMp(Landroid/media/MediaPlayer;)V

    .line 183
    invoke-virtual {v1}, Landroid/media/MediaPlayer;->prepareAsync()V
    :try_end_54
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_54} :catch_55

    .end local v0    # "f":Ljava/io/File;
    .end local v1    # "mp":Landroid/media/MediaPlayer;
    goto :goto_84

    .line 184
    :catch_55
    move-exception v0

    .line 185
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setFailed(Z)V

    .line 186
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getId()J

    move-result-wide v2

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Sound rbxassetid://"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ": "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->warn(Ljava/lang/String;)V

    .line 188
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_84
    return-void
.end method

.method static final create$lambda$12$lambda$10(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;)V
    .registers 4
    .param p0, "$v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .param p1, "it"    # Landroid/media/MediaPlayer;

    .line 180
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->isLooping()Z

    move-result v0

    if-nez v0, :cond_f

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setEnded(Z)V

    const-wide/16 v0, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setPosition(D)V

    :cond_f
    return-void
.end method

.method static final create$lambda$12$lambda$11(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;II)Z
    .registers 9
    .param p0, "$v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .param p2, "what"    # I
    .param p3, "extra"    # I

    .line 181
    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setFailed(Z)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getId()J

    move-result-wide v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Sound rbxassetid://"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " can\'t be played on this device ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->warn(Ljava/lang/String;)V

    return p1
.end method

.method static final create$lambda$12$lambda$9(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;)V
    .registers 9
    .param p0, "$v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .param p1, "it"    # Landroid/media/MediaPlayer;

    .line 169
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setPrepared(Z)V

    .line 170
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v1

    int-to-double v1, v1

    const-wide v3, 0x408f400000000000L    # 1000.0

    div-double/2addr v1, v3

    invoke-virtual {p0, v1, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setLength(D)V

    .line 171
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getSeek()D

    move-result-wide v1

    const-wide/16 v5, 0x0

    cmpl-double v1, v1, v5

    if-lez v1, :cond_27

    :try_start_1c
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getSeek()D

    move-result-wide v1

    mul-double/2addr v1, v3

    double-to-int v1, v1

    invoke-virtual {p1, v1}, Landroid/media/MediaPlayer;->seekTo(I)V
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_25} :catch_26

    goto :goto_27

    :catch_26
    move-exception v1

    .line 172
    :cond_27
    :goto_27
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getWantPlay()Z

    move-result v1

    if-eqz v1, :cond_5f

    .line 173
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastL()F

    move-result v1

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastR()F

    move-result v3

    invoke-static {v3, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v2

    invoke-virtual {p1, v1, v2}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 174
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastLoop()Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/media/MediaPlayer;->setLooping(Z)V

    .line 175
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastSpeed()F

    move-result v1

    invoke-direct {v0, p1, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->setSpeed(Landroid/media/MediaPlayer;F)V

    .line 176
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->start()V

    .line 178
    :cond_5f
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->tick(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    .line 179
    return-void
.end method

.method private final notifyPreview()V
    .registers 7

    .line 245
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewListeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 363
    .local v1, "$i$f$forEach\\1\\245":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lkotlin/jvm/functions/Function0;

    .local v4, "it\\2":Lkotlin/jvm/functions/Function0;
    const/4 v5, 0x0

    .line 245
    .local v5, "$i$a$-forEach-AudioEngine$notifyPreview$1\\2\\363\\0":I
    invoke-interface {v4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 363
    .end local v4    # "it\\2":Lkotlin/jvm/functions/Function0;
    .end local v5    # "$i$a$-forEach-AudioEngine$notifyPreview$1\\2\\363\\0":I
    nop

    .end local v3    # "element\\1":Ljava/lang/Object;
    goto :goto_9

    .line 364
    :cond_1c
    nop

    .line 245
    .end local v0    # "$this$forEach\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$forEach\\1\\245":I
    return-void
.end method

.method private final num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F
    .registers 7
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "k"    # Ljava/lang/String;
    .param p3, "d"    # F

    .line 52
    const/4 v0, 0x0

    if-eqz p1, :cond_8

    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    goto :goto_9

    :cond_8
    move-object v1, v0

    :goto_9
    instance-of v2, v1, Ljava/lang/Number;

    if-eqz v2, :cond_10

    move-object v0, v1

    check-cast v0, Ljava/lang/Number;

    :cond_10
    if-eqz v0, :cond_17

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto :goto_18

    :cond_17
    move v0, p3

    :goto_18
    return v0
.end method

.method static final pausePreview$lambda$20(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V
    .registers 4
    .param p0, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    .line 312
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewPlayer:Landroid/media/MediaPlayer;

    if-nez v0, :cond_5

    return-void

    .line 313
    .local v0, "mp":Landroid/media/MediaPlayer;
    :cond_5
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-ne v1, p0, :cond_2e

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-ne v1, v2, :cond_2e

    .line 314
    :try_start_13
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->pause()V

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x447a0000    # 1000.0f

    div-float/2addr v1, v2

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setPosition(F)V
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_21} :catch_22

    goto :goto_23

    :catch_22
    move-exception v1

    .line 315
    :goto_23
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PAUSED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    .line 316
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    .line 317
    return-void

    .line 313
    :cond_2e
    return-void
.end method

.method private final release(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 4
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .line 219
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setWantPlay(Z)V

    .line 220
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda8;

    invoke-direct {v1, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda8;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 221
    return-void
.end method

.method static final release$lambda$13(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 2
    .param p0, "$v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .line 220
    :try_start_0
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getMp()Landroid/media/MediaPlayer;

    move-result-object v0

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_9} :catch_a

    goto :goto_b

    :catch_a
    move-exception v0

    :cond_b
    :goto_b
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setMp(Landroid/media/MediaPlayer;)V

    return-void
.end method

.method static final resumePreview$lambda$21(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V
    .registers 4
    .param p0, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    .line 323
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewPlayer:Landroid/media/MediaPlayer;

    if-nez v0, :cond_5

    return-void

    .line 324
    .local v0, "mp":Landroid/media/MediaPlayer;
    :cond_5
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-eq v1, p0, :cond_c

    return-void

    .line 325
    :cond_c
    nop

    .line 326
    :try_start_d
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->STOPPED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-ne v1, v2, :cond_1d

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setPosition(F)V

    .line 327
    :cond_1d
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_20} :catch_30

    .line 329
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    .line 330
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    .line 331
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->tick(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V

    .line 332
    return-void

    .line 328
    :catch_30
    move-exception v1

    .local v1, "<unused var>":Ljava/lang/Exception;
    return-void
.end method

.method static final seekPreview$lambda$23(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V
    .registers 6
    .param p0, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .param p1, "$seconds"    # F

    .line 339
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewPlayer:Landroid/media/MediaPlayer;

    if-nez v0, :cond_5

    return-void

    .line 340
    .local v0, "mp":Landroid/media/MediaPlayer;
    :cond_5
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-ne v1, p0, :cond_3b

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getLength()F

    move-result v1

    const/4 v2, 0x0

    cmpg-float v1, v1, v2

    if-lez v1, :cond_3b

    .line 341
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getLength()F

    move-result v1

    invoke-static {p1, v2, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v1

    .line 342
    .local v1, "t":F
    const/high16 v2, 0x447a0000    # 1000.0f

    mul-float/2addr v2, v1

    float-to-int v2, v2

    :try_start_20
    invoke-virtual {v0, v2}, Landroid/media/MediaPlayer;->seekTo(I)V
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_23} :catch_39

    .line 343
    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setPosition(F)V

    .line 345
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v2

    sget-object v3, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->STOPPED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-ne v2, v3, :cond_33

    sget-object v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PAUSED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {p0, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    .line 346
    :cond_33
    sget-object v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    .line 347
    return-void

    .line 342
    :catch_39
    move-exception v2

    .local v2, "<unused var>":Ljava/lang/Exception;
    return-void

    .line 340
    .end local v1    # "t":F
    .end local v2    # "<unused var>":Ljava/lang/Exception;
    :cond_3b
    return-void
.end method

.method private final setSpeed(Landroid/media/MediaPlayer;F)V
    .registers 5
    .param p1, "mp"    # Landroid/media/MediaPlayer;
    .param p2, "speed"    # F

    .line 192
    const/4 v0, 0x0

    cmpg-float v0, p2, v0

    if-lez v0, :cond_26

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float v0, p2, v0

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const v1, 0x3a83126f    # 0.001f

    cmpg-float v0, v0, v1

    if-ltz v0, :cond_26

    .line 193
    :try_start_14
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->getPlaybackParams()Landroid/media/PlaybackParams;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/media/PlaybackParams;->setSpeed(F)Landroid/media/PlaybackParams;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/media/PlaybackParams;->setPitch(F)Landroid/media/PlaybackParams;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/media/MediaPlayer;->setPlaybackParams(Landroid/media/PlaybackParams;)V
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_23} :catch_24

    goto :goto_25

    :catch_24
    move-exception v0

    .line 194
    :goto_25
    return-void

    .line 192
    :cond_26
    return-void
.end method

.method private final soundId(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/Long;
    .registers 4
    .param p1, "s"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 50
    sget-object v0, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    const-string v1, "SoundId"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->idOf(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object v0

    return-object v0
.end method

.method static final stopPreview$lambda$24()V
    .registers 1

    .line 354
    :try_start_0
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewPlayer:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_9

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_7} :catch_8

    goto :goto_9

    :catch_8
    move-exception v0

    :cond_9
    :goto_9
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    const/4 v0, 0x0

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewPlayer:Landroid/media/MediaPlayer;

    return-void
.end method

.method private final tick(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V
    .registers 7
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .param p2, "mp"    # Landroid/media/MediaPlayer;

    .line 299
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;

    invoke-direct {v1, p1, p2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V

    check-cast v1, Ljava/lang/Runnable;

    .line 306
    nop

    .line 299
    const-wide/16 v2, 0x96

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 307
    return-void
.end method

.method private final tick(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 6
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .line 209
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$1;

    invoke-direct {v1, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$1;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    check-cast v1, Ljava/lang/Runnable;

    .line 215
    nop

    .line 209
    const-wide/16 v2, 0xc8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 216
    return-void
.end method

.method public static synthetic togglePreview$default(Lcom/exampletest/mobilestudiotest/audio/AudioEngine;JFILjava/lang/Object;)V
    .registers 6

    .line 251
    and-int/lit8 p4, p4, 0x2

    if-eqz p4, :cond_6

    const/high16 p3, 0x3f000000    # 0.5f

    :cond_6
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview(JF)V

    return-void
.end method

.method static final togglePreview$lambda$19(JLcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V
    .registers 6
    .param p0, "$id"    # J
    .param p2, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .param p3, "$volume"    # F

    .line 265
    nop

    .line 266
    :try_start_1
    sget-object v0, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    invoke-virtual {v0, p0, p1}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->load(J)[B

    .line 267
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;

    invoke-direct {v1, p2, p0, p1, p3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;JF)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_10} :catch_11

    goto :goto_27

    .line 289
    :catch_11
    move-exception v0

    .line 290
    .local v0, "e":Ljava/lang/Exception;
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {p2, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    .line 291
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1f

    const-string v1, "Couldn\'t download the audio"

    :cond_1f
    invoke-virtual {p2, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setError(Ljava/lang/String;)V

    .line 292
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    .line 294
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_27
    return-void
.end method

.method static final togglePreview$lambda$19$lambda$18(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;JF)V
    .registers 7
    .param p0, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .param p1, "$id"    # J
    .param p3, "$volume"    # F

    .line 268
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-eq v0, p0, :cond_7

    return-void

    .line 269
    :cond_7
    nop

    .line 270
    :try_start_8
    new-instance v0, Landroid/media/MediaPlayer;

    invoke-direct {v0}, Landroid/media/MediaPlayer;-><init>()V

    .line 271
    .local v0, "mp":Landroid/media/MediaPlayer;
    new-instance v1, Landroid/media/AudioAttributes$Builder;

    invoke-direct {v1}, Landroid/media/AudioAttributes$Builder;-><init>()V

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v1

    const/4 v2, 0x2

    invoke-virtual {v1, v2}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setAudioAttributes(Landroid/media/AudioAttributes;)V

    .line 272
    sget-object v1, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    invoke-virtual {v1, p1, p2}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->cacheFile(J)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    .line 273
    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    .line 283
    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 284
    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda3;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    .line 285
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewPlayer:Landroid/media/MediaPlayer;

    .line 286
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->prepareAsync()V
    :try_end_4e
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_4e} :catch_4f

    .end local v0    # "mp":Landroid/media/MediaPlayer;
    goto :goto_61

    .line 287
    :catch_4f
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setError(Ljava/lang/String;)V

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    .line 288
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_61
    return-void
.end method

.method static final togglePreview$lambda$19$lambda$18$lambda$15(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;FLandroid/media/MediaPlayer;)V
    .registers 6
    .param p0, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .param p1, "$volume"    # F
    .param p2, "it"    # Landroid/media/MediaPlayer;

    .line 274
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-eq v0, p0, :cond_a

    invoke-virtual {p2}, Landroid/media/MediaPlayer;->release()V

    return-void

    .line 275
    :cond_a
    invoke-virtual {p2}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x447a0000    # 1000.0f

    div-float/2addr v0, v1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setLength(F)V

    .line 276
    const/high16 v0, 0x40000000    # 2.0f

    mul-float/2addr v0, p1

    const v1, 0x3d4ccccd    # 0.05f

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    .line 277
    .local v0, "vol":F
    invoke-virtual {p2, v0, v0}, Landroid/media/MediaPlayer;->setVolume(FF)V

    .line 278
    invoke-virtual {p2}, Landroid/media/MediaPlayer;->start()V

    .line 279
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    .line 280
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    .line 281
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-static {p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v1, p0, p2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->tick(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V

    .line 282
    return-void
.end method

.method static final togglePreview$lambda$19$lambda$18$lambda$16(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V
    .registers 3
    .param p0, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .param p1, "it"    # Landroid/media/MediaPlayer;

    .line 283
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->STOPPED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setPosition(F)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    return-void
.end method

.method static final togglePreview$lambda$19$lambda$18$lambda$17(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;II)Z
    .registers 4
    .param p0, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    .line 284
    sget-object p1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    const-string p1, "This audio can\'t be played on this device"

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setError(Ljava/lang/String;)V

    sget-object p1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    const/4 p1, 0x1

    return p1
.end method

.method static final update$lambda$2(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Z)V
    .registers 5
    .param p0, "$vv"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .param p1, "$stopped"    # Z

    .line 74
    :try_start_0
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getMp()Landroid/media/MediaPlayer;

    move-result-object v0

    if-eqz v0, :cond_1e

    .line 359
    .local v0, "it\\1":Landroid/media/MediaPlayer;
    const/4 v1, 0x0

    .line 74
    .local v1, "$i$a$-let-AudioEngine$update$1$1\\1\\74\\0":I
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v2

    if-eqz v2, :cond_10

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->pause()V

    :cond_10
    if-eqz p1, :cond_1e

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getPrepared()Z

    move-result v2

    if-eqz v2, :cond_1e

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/media/MediaPlayer;->seekTo(I)V
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1c} :catch_1d

    goto :goto_1e

    .end local v0    # "it\\1":Landroid/media/MediaPlayer;
    .end local v1    # "$i$a$-let-AudioEngine$update$1$1\\1\\74\\0":I
    :catch_1d
    move-exception v0

    :cond_1e
    :goto_1e
    return-void
.end method

.method static final update$lambda$6(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 3
    .param p0, "$vv"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .line 133
    :try_start_0
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getPrepared()Z

    move-result v0

    if-eqz v0, :cond_12

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getMp()Landroid/media/MediaPlayer;

    move-result-object v0

    if-eqz v0, :cond_12

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_10} :catch_11

    goto :goto_12

    :catch_11
    move-exception v0

    :cond_12
    :goto_12
    return-void
.end method

.method static final update$lambda$7(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;FFFZZ)V
    .registers 13
    .param p0, "$vv"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .param p1, "$l"    # F
    .param p2, "$r"    # F
    .param p3, "$speed"    # F
    .param p4, "$loop"    # Z
    .param p5, "$restart"    # Z

    .line 138
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    move-object v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move v6, p5

    .end local p0    # "$vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .end local p1    # "$l":F
    .end local p2    # "$r":F
    .end local p3    # "$speed":F
    .end local p4    # "$loop":Z
    .end local p5    # "$restart":Z
    .local v1, "$vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .local v2, "$l":F
    .local v3, "$r":F
    .local v4, "$speed":F
    .local v5, "$loop":Z
    .local v6, "$restart":Z
    invoke-direct/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->apply(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;FFFZZ)V

    return-void
.end method


# virtual methods
.method public final getOnEnded()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 48
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->onEnded:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final getOnLoaded()Lkotlin/jvm/functions/Function1;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 47
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->onLoaded:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final getPreview()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .registers 2

    .line 240
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    return-object v0
.end method

.method public final getPreviewListeners()Ljava/util/concurrent/CopyOnWriteArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation

    .line 243
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->previewListeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    return-object v0
.end method

.method public final pausePreview()V
    .registers 4

    .line 310
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-nez v0, :cond_5

    return-void

    .line 311
    .local v0, "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    :cond_5
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda16;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda16;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 318
    return-void
.end method

.method public final resumePreview()V
    .registers 4

    .line 321
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-nez v0, :cond_5

    return-void

    .line 322
    .local v0, "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    :cond_5
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda11;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda11;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 333
    return-void
.end method

.method public final seekPreview(JF)V
    .registers 9
    .param p1, "id"    # J
    .param p3, "seconds"    # F

    .line 337
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-eqz v0, :cond_21

    move-object v1, v0

    .line 359
    .local v1, "it\\1":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    const/4 v2, 0x0

    .line 337
    .local v2, "$i$a$-takeIf-AudioEngine$seekPreview$p$1\\1\\337\\0":I
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getId()J

    move-result-wide v3

    cmp-long v3, v3, p1

    if-nez v3, :cond_10

    const/4 v3, 0x1

    goto :goto_11

    :cond_10
    const/4 v3, 0x0

    .end local v1    # "it\\1":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .end local v2    # "$i$a$-takeIf-AudioEngine$seekPreview$p$1\\1\\337\\0":I
    :goto_11
    if-nez v3, :cond_14

    const/4 v0, 0x0

    :cond_14
    if-eqz v0, :cond_21

    .line 338
    .local v0, "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda0;

    invoke-direct {v2, v0, p3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 348
    return-void

    .line 337
    .end local v0    # "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    :cond_21
    return-void
.end method

.method public final setOnEnded(Lkotlin/jvm/functions/Function1;)V
    .registers 2
    .param p1, "<set-?>"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 48
    sput-object p1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->onEnded:Lkotlin/jvm/functions/Function1;

    return-void
.end method

.method public final setOnLoaded(Lkotlin/jvm/functions/Function1;)V
    .registers 2
    .param p1, "<set-?>"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 47
    sput-object p1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->onLoaded:Lkotlin/jvm/functions/Function1;

    return-void
.end method

.method public final stopAll()V
    .registers 3

    .line 224
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    invoke-virtual {v0}, Ljava/util/IdentityHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .local v1, "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->release(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    .end local v1    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    goto :goto_a

    .line 225
    :cond_1d
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    invoke-virtual {v0}, Ljava/util/IdentityHashMap;->clear()V

    .line 226
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->missing:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    .line 227
    return-void
.end method

.method public final stopPreview()V
    .registers 4

    .line 351
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    .line 352
    .local v0, "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    const/4 v1, 0x0

    sput-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    .line 353
    if-eqz v0, :cond_c

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->STOPPED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V

    .line 354
    :cond_c
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda7;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda7;-><init>()V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 355
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    .line 356
    return-void
.end method

.method public final togglePreview(JF)V
    .registers 8
    .param p1, "id"    # J
    .param p3, "volume"    # F

    .line 252
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    .line 253
    .local v0, "cur":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    if-eqz v0, :cond_3b

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getId()J

    move-result-wide v1

    cmp-long v1, v1, p1

    if-nez v1, :cond_3b

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ordinal()I

    move-result v1

    aget v1, v2, v1

    packed-switch v1, :pswitch_data_56

    new-instance v1, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v1}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v1

    .line 257
    :pswitch_21
    goto :goto_3b

    :pswitch_22
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->stopPreview()V

    return-void

    .line 256
    :pswitch_26
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getLength()F

    move-result v1

    const/4 v2, 0x0

    cmpl-float v1, v1, v2

    if-lez v1, :cond_3b

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->resumePreview()V

    return-void

    .line 255
    :pswitch_33
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->resumePreview()V

    return-void

    .line 254
    :pswitch_37
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->pausePreview()V

    return-void

    .line 260
    :cond_3b
    :goto_3b
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->stopPreview()V

    .line 261
    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    invoke-direct {v1, p1, p2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;-><init>(J)V

    .line 262
    .local v1, "p":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    sput-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->preview:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    .line 263
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->notifyPreview()V

    .line 264
    new-instance v2, Ljava/lang/Thread;

    .line 294
    new-instance v3, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;

    invoke-direct {v3, p1, p2, v1, p3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;-><init>(JLcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V

    .line 264
    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 294
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 295
    return-void

    :pswitch_data_56
    .packed-switch 0x1
        :pswitch_37
        :pswitch_33
        :pswitch_26
        :pswitch_22
        :pswitch_21
    .end packed-switch
.end method

.method public final update(Lcom/exampletest/mobilestudiotest/core/Studio;)V
    .registers 40
    .param p1, "studio"    # Lcom/exampletest/mobilestudiotest/core/Studio;

    move-object/from16 v0, p0

    const-string v1, "studio"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v1

    .line 57
    .local v1, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    if-nez v1, :cond_1d

    sget-object v3, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    check-cast v3, Ljava/util/Map;

    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_1c

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->stopAll()V

    :cond_1c
    return-void

    .line 58
    :cond_1d
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->audibleSounds()Ljava/util/List;

    move-result-object v3

    .line 59
    .local v3, "sounds":Ljava/util/List;
    new-instance v4, Ljava/util/IdentityHashMap;

    invoke-direct {v4}, Ljava/util/IdentityHashMap;-><init>()V

    check-cast v4, Ljava/util/Map;

    invoke-static {v4}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v4

    .line 60
    .local v4, "alive":Ljava/util/Set;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCamera()Lcom/exampletest/mobilestudiotest/render/FlyCamera;

    move-result-object v5

    .line 61
    .local v5, "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    sget-object v6, Lcom/exampletest/mobilestudiotest/core/Settings;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Settings;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/core/Settings;->getVolume()I

    move-result v6

    int-to-float v6, v6

    const/high16 v7, 0x41200000    # 10.0f

    div-float/2addr v6, v7

    .line 62
    .local v6, "master":F
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_3e
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eqz v9, :cond_4de

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    move-object v12, v9

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 63
    .local v12, "s":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v9

    if-eqz v9, :cond_4d2

    .line 64
    invoke-interface {v4, v12}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 65
    const-string v9, "Playing"

    invoke-virtual {v12, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v13

    invoke-static {v9, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_78

    const-string v9, "IsPlaying"

    invoke-virtual {v12, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v13

    invoke-static {v9, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_78

    move v9, v11

    goto :goto_79

    :cond_78
    move v9, v10

    .line 66
    .local v9, "playing":Z
    :goto_79
    sget-object v13, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    invoke-virtual {v13, v12}, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .line 67
    .local v13, "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    invoke-direct {v0, v12}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->soundId(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/lang/Long;

    move-result-object v14

    .line 68
    .local v14, "id":Ljava/lang/Long;
    if-eqz v13, :cond_9e

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getId()J

    move-result-wide v15

    if-eqz v14, :cond_95

    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    move-result-wide v17

    cmp-long v15, v15, v17

    if-eqz v15, :cond_9e

    :cond_95
    invoke-direct {v0, v13}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->release(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    sget-object v15, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    invoke-virtual {v15, v12}, Ljava/util/IdentityHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    .line 69
    :cond_9e
    const-string v15, "TimePosition"

    const/4 v10, 0x0

    if-nez v9, :cond_c8

    .line 70
    if-eqz v13, :cond_c4

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getWantPlay()Z

    move-result v17

    if-eqz v17, :cond_c4

    .line 71
    invoke-virtual {v13, v11}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setWantPlay(Z)V

    .line 72
    invoke-direct {v0, v12, v15, v10}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v15

    cmpg-float v10, v15, v10

    if-nez v10, :cond_b8

    const/4 v10, 0x1

    goto :goto_b9

    :cond_b8
    move v10, v11

    .line 73
    .local v10, "stopped":Z
    :goto_b9
    move-object v11, v13

    .line 74
    .local v11, "vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    sget-object v15, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v7, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda4;

    invoke-direct {v7, v11, v10}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Z)V

    invoke-virtual {v15, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 76
    .end local v10    # "stopped":Z
    .end local v11    # "vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    :cond_c4
    const/high16 v7, 0x41200000    # 10.0f

    goto/16 :goto_3e

    .line 78
    :cond_c8
    if-eqz v14, :cond_4c5

    .line 79
    if-nez v13, :cond_18c

    .line 80
    sget-object v7, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    invoke-virtual {v7}, Ljava/util/IdentityHashMap;->size()I

    move-result v7

    const/16 v11, 0x1c

    if-ge v7, v11, :cond_180

    .line 81
    sget-object v7, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    invoke-virtual {v7, v10, v11}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->isCached(J)Z

    move-result v7

    .line 82
    .local v7, "bytes":Z
    if-nez v7, :cond_15b

    .line 83
    sget-object v10, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    move-object v11, v1

    .end local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .local v11, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {v10, v1, v2}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->request(J)[B

    .line 84
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->missing:Ljava/util/HashSet;

    invoke-virtual {v1, v14}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_14a

    sget-object v1, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    move-object v10, v3

    .end local v3    # "sounds":Ljava/util/List;
    .local v10, "sounds":Ljava/util/List;
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->lastError(J)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_145

    .line 85
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->missing:Ljava/util/HashSet;

    invoke-virtual {v1, v14}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 86
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->fullName()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->INSTANCE:Lcom/exampletest/mobilestudiotest/net/AssetFetcher;

    move-object/from16 v20, v5

    move/from16 v21, v6

    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .local v20, "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .local v21, "master":F
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-virtual {v3, v5, v6}, Lcom/exampletest/mobilestudiotest/net/AssetFetcher;->lastError(J)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Couldn\'t load sound "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, " (rbxassetid://"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, "): "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->warn(Ljava/lang/String;)V

    goto :goto_14f

    .line 84
    .end local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v21    # "master":F
    .restart local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v6    # "master":F
    :cond_145
    move-object/from16 v20, v5

    move/from16 v21, v6

    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .restart local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v21    # "master":F
    goto :goto_14f

    .end local v10    # "sounds":Ljava/util/List;
    .end local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v21    # "master":F
    .restart local v3    # "sounds":Ljava/util/List;
    .restart local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v6    # "master":F
    :cond_14a
    move-object v10, v3

    move-object/from16 v20, v5

    move/from16 v21, v6

    .line 88
    .end local v3    # "sounds":Ljava/util/List;
    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .restart local v10    # "sounds":Ljava/util/List;
    .restart local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v21    # "master":F
    :goto_14f
    move-object/from16 v2, p1

    move-object v3, v10

    move-object v1, v11

    move-object/from16 v5, v20

    move/from16 v6, v21

    const/high16 v7, 0x41200000    # 10.0f

    goto/16 :goto_3e

    .line 90
    .end local v10    # "sounds":Ljava/util/List;
    .end local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v21    # "master":F
    .restart local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v3    # "sounds":Ljava/util/List;
    .restart local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v6    # "master":F
    :cond_15b
    move-object v11, v1

    move-object v10, v3

    move-object/from16 v20, v5

    move/from16 v21, v6

    .end local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v3    # "sounds":Ljava/util/List;
    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .restart local v10    # "sounds":Ljava/util/List;
    .restart local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v21    # "master":F
    new-instance v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-direct {v1, v12, v2, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;-><init>(Lcom/exampletest/mobilestudiotest/model/Instance;J)V

    move-object v13, v1

    .line 91
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    check-cast v1, Ljava/util/Map;

    invoke-interface {v1, v12, v13}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    const/4 v1, 0x0

    invoke-direct {v0, v12, v15, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v2

    float-to-double v1, v2

    .line 93
    .local v1, "start":D
    invoke-virtual {v13, v1, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setSeek(D)V

    .line 94
    invoke-direct {v0, v13}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->create(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    move-object v1, v13

    goto :goto_193

    .line 80
    .end local v7    # "bytes":Z
    .end local v10    # "sounds":Ljava/util/List;
    .end local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v21    # "master":F
    .local v1, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v3    # "sounds":Ljava/util/List;
    .restart local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v6    # "master":F
    :cond_180
    move-object v11, v1

    move-object v10, v3

    move-object/from16 v20, v5

    move/from16 v21, v6

    .end local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v3    # "sounds":Ljava/util/List;
    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .restart local v10    # "sounds":Ljava/util/List;
    .restart local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v21    # "master":F
    move-object/from16 v2, p1

    const/high16 v7, 0x41200000    # 10.0f

    goto/16 :goto_3e

    .line 79
    .end local v10    # "sounds":Ljava/util/List;
    .end local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v21    # "master":F
    .restart local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v3    # "sounds":Ljava/util/List;
    .restart local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v6    # "master":F
    :cond_18c
    move-object v11, v1

    move-object v10, v3

    move-object/from16 v20, v5

    move/from16 v21, v6

    .end local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v3    # "sounds":Ljava/util/List;
    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .restart local v10    # "sounds":Ljava/util/List;
    .restart local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v21    # "master":F
    move-object v1, v13

    .line 96
    .end local v13    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .local v1, "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    :goto_193
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getFailed()Z

    move-result v2

    if-nez v2, :cond_4b6

    .line 98
    const/4 v2, 0x0

    .local v2, "vol":F
    const-string v3, "Volume"

    const/high16 v5, 0x3f000000    # 0.5f

    invoke-direct {v0, v12, v3, v5}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v6

    const/high16 v7, 0x41200000    # 10.0f

    const/4 v13, 0x0

    invoke-static {v6, v13, v7}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v2

    .line 99
    const-string v6, "SoundGroup"

    invoke-virtual {v12, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v7, :cond_1b6

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_1b7

    :cond_1b6
    const/4 v6, 0x0

    :goto_1b7
    const/high16 v7, 0x3f800000    # 1.0f

    if-eqz v6, :cond_1ce

    .line 359
    .local v6, "g\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v22, 0x0

    .line 99
    .local v22, "$i$a$-let-AudioEngine$update$2\\1\\99\\0":I
    move/from16 v23, v5

    sget-object v5, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-direct {v5, v6, v3, v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v3

    const/high16 v5, 0x41200000    # 10.0f

    const/4 v13, 0x0

    invoke-static {v3, v13, v5}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v3

    mul-float/2addr v2, v3

    .end local v6    # "g\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v22    # "$i$a$-let-AudioEngine$update$2\\1\\99\\0":I
    goto :goto_1d0

    :cond_1ce
    move/from16 v23, v5

    .line 100
    :goto_1d0
    mul-float v2, v2, v21

    .line 101
    const/high16 v3, 0x3f800000    # 1.0f

    .local v3, "left":F
    const/high16 v5, 0x3f800000    # 1.0f

    .line 102
    .local v5, "right":F
    nop

    .line 103
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6

    const-string v13, "BasePart"

    if-eqz v6, :cond_1ea

    invoke-virtual {v6, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v6

    move/from16 v22, v7

    const/4 v7, 0x1

    if-ne v6, v7, :cond_1ec

    const/4 v6, 0x1

    goto :goto_1ed

    :cond_1ea
    move/from16 v22, v7

    :cond_1ec
    const/4 v6, 0x0

    :goto_1ed
    if-eqz v6, :cond_206

    sget-object v6, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    move-object/from16 v25, v1

    move/from16 v26, v2

    goto/16 :goto_271

    .line 104
    :cond_206
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6

    if-eqz v6, :cond_211

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v6

    goto :goto_212

    :cond_211
    const/4 v6, 0x0

    :goto_212
    const-string v7, "Attachment"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_26c

    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6

    if-eqz v6, :cond_266

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6

    if-eqz v6, :cond_266

    move-object v7, v6

    .line 359
    .local v7, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v25, 0x0

    .line 104
    .local v25, "$i$a$-takeIf-AudioEngine$update$emitter$1\\2\\104\\0":I
    invoke-virtual {v7, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v7

    .end local v7    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v25    # "$i$a$-takeIf-AudioEngine$update$emitter$1\\2\\104\\0":I
    if-nez v7, :cond_230

    const/4 v6, 0x0

    :cond_230
    if-eqz v6, :cond_266

    .line 359
    .local v6, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v7, 0x0

    .line 104
    .local v7, "$i$a$-let-AudioEngine$update$emitter$2\\3\\104\\0":I
    sget-object v13, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v13, v6}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v13

    move-object/from16 v25, v1

    .end local v1    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .local v25, "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move/from16 v26, v2

    .end local v2    # "vol":F
    .local v26, "vol":F
    const-string v2, "CFrame"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v2, :cond_251

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    goto :goto_252

    :cond_251
    const/4 v1, 0x0

    :goto_252
    if-eqz v1, :cond_25b

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    if-eqz v1, :cond_25b

    goto :goto_261

    :cond_25b
    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    :goto_261
    invoke-virtual {v13, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    .end local v6    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "$i$a$-let-AudioEngine$update$emitter$2\\3\\104\\0":I
    goto :goto_271

    .end local v25    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .end local v26    # "vol":F
    .restart local v1    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .restart local v2    # "vol":F
    :cond_266
    move-object/from16 v25, v1

    move/from16 v26, v2

    .end local v1    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .end local v2    # "vol":F
    .restart local v25    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .restart local v26    # "vol":F
    const/4 v6, 0x0

    goto :goto_271

    .line 105
    .end local v25    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .end local v26    # "vol":F
    .restart local v1    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .restart local v2    # "vol":F
    :cond_26c
    move-object/from16 v25, v1

    move/from16 v26, v2

    .end local v1    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .end local v2    # "vol":F
    .restart local v25    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .restart local v26    # "vol":F
    const/4 v6, 0x0

    .line 102
    :goto_271
    nop

    .line 107
    .local v6, "emitter":Lcom/exampletest/mobilestudiotest/model/Vector3;
    if-eqz v6, :cond_328

    .line 108
    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getPos()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v6, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v1

    .line 109
    .local v1, "d":F
    const-string v2, "xmlRead_MinDistance_3"

    const/high16 v7, 0x41200000    # 10.0f

    invoke-direct {v0, v12, v2, v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v2

    const-string v13, "RollOffMinDistance"

    invoke-direct {v0, v12, v13, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v2

    const v13, 0x3dcccccd    # 0.1f

    invoke-static {v2, v13}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v2

    .line 110
    .local v2, "mn":F
    const-string v13, "xmlRead_MaxDistance_3"

    const v7, 0x461c4000    # 10000.0f

    invoke-direct {v0, v12, v13, v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v7

    const-string v13, "RollOffMaxDistance"

    invoke-direct {v0, v12, v13, v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v7

    invoke-static {v7, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v7

    .line 111
    .local v7, "mx":F
    const-string v13, "RollOffMode"

    invoke-virtual {v12, v13}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v13

    move/from16 v27, v1

    .end local v1    # "d":F
    .local v27, "d":F
    instance-of v1, v13, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v1, :cond_2b7

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    goto :goto_2b8

    :cond_2b7
    const/4 v13, 0x0

    :goto_2b8
    if-eqz v13, :cond_2bf

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->getValue()I

    move-result v1

    goto :goto_2c0

    :cond_2bf
    const/4 v1, 0x0

    .line 112
    .local v1, "mode":I
    :goto_2c0
    nop

    .line 113
    cmpg-float v13, v27, v2

    if-gtz v13, :cond_2c8

    move/from16 v13, v22

    goto :goto_2df

    .line 114
    :cond_2c8
    cmpl-float v13, v27, v7

    if-ltz v13, :cond_2ce

    const/4 v13, 0x0

    goto :goto_2df

    .line 115
    :cond_2ce
    const/4 v13, 0x1

    if-eq v1, v13, :cond_2d7

    const/4 v13, 0x3

    if-eq v1, v13, :cond_2d7

    .line 116
    div-float v13, v2, v27

    goto :goto_2df

    .line 115
    :cond_2d7
    sub-float v13, v27, v2

    sub-float v28, v7, v2

    div-float v13, v13, v28

    sub-float v13, v22, v13

    .line 112
    :goto_2df
    nop

    .line 118
    .local v13, "gain":F
    mul-float v26, v26, v13

    .line 119
    move/from16 v28, v1

    .end local v1    # "mode":I
    .local v28, "mode":I
    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getPos()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v6, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .line 120
    .local v1, "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    cmpl-float v23, v27, v23

    if-lez v23, :cond_31e

    .line 121
    move-object/from16 v23, v1

    .end local v1    # "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v23, "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual/range {v23 .. v23}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    move/from16 v29, v2

    .end local v2    # "mn":F
    .local v29, "mn":F
    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->getRight()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v1

    const/high16 v2, -0x40800000    # -1.0f

    move/from16 v30, v3

    move/from16 v3, v22

    .end local v3    # "left":F
    .local v30, "left":F
    invoke-static {v1, v2, v3}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v1

    const v2, 0x3f333333    # 0.7f

    mul-float/2addr v1, v2

    .line 122
    .local v1, "pan":F
    const/4 v2, 0x0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v19

    sub-float v19, v3, v19

    .end local v30    # "left":F
    .local v19, "left":F
    invoke-static {v2, v1}, Ljava/lang/Math;->min(FF)F

    move-result v22

    add-float v5, v22, v3

    move/from16 v30, v19

    goto :goto_32d

    .line 120
    .end local v19    # "left":F
    .end local v23    # "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v29    # "mn":F
    .local v1, "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v2    # "mn":F
    .restart local v3    # "left":F
    :cond_31e
    move-object/from16 v23, v1

    move/from16 v29, v2

    move/from16 v30, v3

    move/from16 v3, v22

    const/4 v2, 0x0

    .end local v1    # "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v2    # "mn":F
    .end local v3    # "left":F
    .restart local v23    # "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v29    # "mn":F
    .restart local v30    # "left":F
    goto :goto_32d

    .line 107
    .end local v7    # "mx":F
    .end local v13    # "gain":F
    .end local v23    # "dir":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v27    # "d":F
    .end local v28    # "mode":I
    .end local v29    # "mn":F
    .end local v30    # "left":F
    .restart local v3    # "left":F
    :cond_328
    move/from16 v30, v3

    move/from16 v3, v22

    const/4 v2, 0x0

    .line 125
    .end local v3    # "left":F
    .restart local v30    # "left":F
    :goto_32d
    mul-float v1, v26, v30

    invoke-static {v1, v2, v3}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v1

    .local v1, "l":F
    mul-float v7, v26, v5

    invoke-static {v7, v2, v3}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v2

    .line 126
    .local v2, "r":F
    const-string v7, "Pitch"

    invoke-direct {v0, v12, v7, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v3

    const-string v7, "PlaybackSpeed"

    invoke-direct {v0, v12, v7, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->num(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;F)F

    move-result v3

    const v7, 0x3d4ccccd    # 0.05f

    const/high16 v13, 0x41000000    # 8.0f

    invoke-static {v3, v7, v13}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v3

    .line 127
    .local v3, "speed":F
    const-string v7, "Looped"

    invoke-virtual {v12, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    const/16 v16, 0x1

    invoke-static/range {v16 .. v16}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v13

    invoke-static {v7, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v36

    .line 128
    .local v36, "loop":Z
    move-object/from16 v7, v25

    .line 130
    .local v7, "vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    invoke-virtual {v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v13

    move/from16 v19, v5

    .end local v5    # "right":F
    .local v19, "right":F
    const-string v5, "__playSeq"

    invoke-virtual {v13, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    instance-of v13, v5, Ljava/lang/Integer;

    if-eqz v13, :cond_374

    move-object v13, v5

    check-cast v13, Ljava/lang/Integer;

    goto :goto_375

    :cond_374
    const/4 v13, 0x0

    :goto_375
    if-eqz v13, :cond_37c

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v5

    goto :goto_37d

    :cond_37c
    const/4 v5, 0x0

    .line 131
    .local v5, "seq":I
    :goto_37d
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getSeq()I

    move-result v13

    if-eq v5, v13, :cond_39c

    .line 132
    invoke-virtual {v7, v5}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setSeq(I)V

    .line 133
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getWantPlay()Z

    move-result v13

    if-eqz v13, :cond_399

    sget-object v13, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    move/from16 v22, v5

    .end local v5    # "seq":I
    .local v22, "seq":I
    new-instance v5, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda5;

    invoke-direct {v5, v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda5;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    invoke-virtual {v13, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_39e

    .end local v22    # "seq":I
    .restart local v5    # "seq":I
    :cond_399
    move/from16 v22, v5

    .end local v5    # "seq":I
    .restart local v22    # "seq":I
    goto :goto_39e

    .line 131
    .end local v22    # "seq":I
    .restart local v5    # "seq":I
    :cond_39c
    move/from16 v22, v5

    .line 135
    .end local v5    # "seq":I
    .restart local v22    # "seq":I
    :goto_39e
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getWantPlay()Z

    move-result v5

    if-eqz v5, :cond_3e6

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastL()F

    move-result v5

    sub-float v5, v1, v5

    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    move-result v5

    const v13, 0x3c23d70a    # 0.01f

    cmpl-float v5, v5, v13

    if-gtz v5, :cond_3e6

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastR()F

    move-result v5

    sub-float v5, v2, v5

    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    move-result v5

    cmpl-float v5, v5, v13

    if-gtz v5, :cond_3e6

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastSpeed()F

    move-result v5

    cmpg-float v5, v3, v5

    if-nez v5, :cond_3cd

    const/4 v5, 0x1

    goto :goto_3ce

    :cond_3cd
    const/4 v5, 0x0

    :goto_3ce
    if-eqz v5, :cond_3e6

    invoke-static/range {v36 .. v36}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastLoop()Ljava/lang/Boolean;

    move-result-object v13

    invoke-static {v5, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3e6

    move/from16 v33, v1

    move/from16 v34, v2

    move/from16 v35, v3

    move-object v1, v7

    goto :goto_416

    .line 136
    :cond_3e6
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getWantPlay()Z

    move-result v5

    const/4 v13, 0x1

    xor-int/lit8 v37, v5, 0x1

    .line 137
    .local v37, "restart":Z
    invoke-virtual {v7, v13}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setWantPlay(Z)V

    invoke-virtual {v7, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setLastL(F)V

    invoke-virtual {v7, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setLastR(F)V

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setLastSpeed(F)V

    invoke-static/range {v36 .. v36}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-virtual {v7, v5}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setLastLoop(Ljava/lang/Boolean;)V

    .line 138
    sget-object v5, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->h:Landroid/os/Handler;

    new-instance v31, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;

    move/from16 v33, v1

    move/from16 v34, v2

    move/from16 v35, v3

    move-object/from16 v32, v7

    .end local v1    # "l":F
    .end local v2    # "r":F
    .end local v3    # "speed":F
    .end local v7    # "vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .local v32, "vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .local v33, "l":F
    .local v34, "r":F
    .local v35, "speed":F
    invoke-direct/range {v31 .. v37}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;FFFZZ)V

    move-object/from16 v2, v31

    move-object/from16 v1, v32

    .end local v32    # "vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .local v1, "vv":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    invoke-virtual {v5, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 141
    .end local v37    # "restart":Z
    :goto_416
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLength()D

    move-result-wide v2

    const-wide/16 v23, 0x0

    cmpl-double v2, v2, v23

    if-lez v2, :cond_448

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLoadedNotified()Z

    move-result v2

    if-nez v2, :cond_448

    .line 142
    const/4 v13, 0x1

    invoke-virtual {v1, v13}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setLoadedNotified(Z)V

    .line 143
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLength()D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    const-string v3, "TimeLength"

    const/4 v5, 0x0

    invoke-virtual {v12, v3, v2, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 144
    const-string v2, "IsLoaded"

    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-virtual {v12, v2, v3, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 145
    sget-object v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->onLoaded:Lkotlin/jvm/functions/Function1;

    if-eqz v2, :cond_448

    invoke-interface {v2, v12}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 147
    :cond_448
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getPosition()D

    move-result-wide v2

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getLastPushedPos()D

    move-result-wide v27

    sub-double v2, v2, v27

    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    move-result-wide v2

    const-wide v27, 0x3fc999999999999aL    # 0.2

    cmpl-double v2, v2, v27

    if-lez v2, :cond_473

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getPosition()D

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setLastPushedPos(D)V

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getPosition()D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    const/4 v5, 0x0

    invoke-virtual {v12, v15, v2, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    goto :goto_474

    :cond_473
    const/4 v5, 0x0

    .line 148
    :goto_474
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getEnded()Z

    move-result v2

    if-eqz v2, :cond_4a9

    .line 149
    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setEnded(Z)V

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setWantPlay(Z)V

    .line 150
    invoke-static/range {v23 .. v24}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    invoke-virtual {v12, v15, v2, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 151
    move-object v2, v14

    .end local v14    # "id":Ljava/lang/Long;
    .local v2, "id":Ljava/lang/Long;
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    const/16 v16, 0x4

    const/16 v17, 0x0

    const-string v13, "Playing"

    const/4 v15, 0x0

    invoke-static/range {v12 .. v17}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 152
    sget-object v3, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->onEnded:Lkotlin/jvm/functions/Function1;

    if-eqz v3, :cond_49d

    invoke-interface {v3, v12}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_49d
    move-object/from16 v2, p1

    move-object v3, v10

    move-object v1, v11

    move-object/from16 v5, v20

    move/from16 v6, v21

    const/high16 v7, 0x41200000    # 10.0f

    goto/16 :goto_3e

    .line 148
    .end local v2    # "id":Ljava/lang/Long;
    .restart local v14    # "id":Ljava/lang/Long;
    :cond_4a9
    move-object v2, v14

    .end local v14    # "id":Ljava/lang/Long;
    .restart local v2    # "id":Ljava/lang/Long;
    move-object/from16 v2, p1

    move-object v3, v10

    move-object v1, v11

    move-object/from16 v5, v20

    move/from16 v6, v21

    const/high16 v7, 0x41200000    # 10.0f

    goto/16 :goto_3e

    .line 96
    .end local v2    # "id":Ljava/lang/Long;
    .end local v6    # "emitter":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v19    # "right":F
    .end local v22    # "seq":I
    .end local v25    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .end local v26    # "vol":F
    .end local v30    # "left":F
    .end local v33    # "l":F
    .end local v34    # "r":F
    .end local v35    # "speed":F
    .end local v36    # "loop":Z
    .local v1, "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .restart local v14    # "id":Ljava/lang/Long;
    :cond_4b6
    move-object/from16 v25, v1

    move-object v2, v14

    .end local v1    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .end local v14    # "id":Ljava/lang/Long;
    .restart local v2    # "id":Ljava/lang/Long;
    .restart local v25    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    move-object/from16 v2, p1

    move-object v3, v10

    move-object v1, v11

    move-object/from16 v5, v20

    move/from16 v6, v21

    const/high16 v7, 0x41200000    # 10.0f

    goto/16 :goto_3e

    .line 78
    .end local v2    # "id":Ljava/lang/Long;
    .end local v10    # "sounds":Ljava/util/List;
    .end local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v21    # "master":F
    .end local v25    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .local v1, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .local v3, "sounds":Ljava/util/List;
    .local v5, "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .local v6, "master":F
    .local v13, "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .restart local v14    # "id":Ljava/lang/Long;
    :cond_4c5
    move-object v11, v1

    move-object v10, v3

    move-object/from16 v20, v5

    move/from16 v21, v6

    move-object v2, v14

    .end local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v3    # "sounds":Ljava/util/List;
    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .end local v14    # "id":Ljava/lang/Long;
    .restart local v2    # "id":Ljava/lang/Long;
    .restart local v10    # "sounds":Ljava/util/List;
    .restart local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v21    # "master":F
    move-object/from16 v2, p1

    const/high16 v7, 0x41200000    # 10.0f

    goto/16 :goto_3e

    .line 63
    .end local v2    # "id":Ljava/lang/Long;
    .end local v9    # "playing":Z
    .end local v10    # "sounds":Ljava/util/List;
    .end local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v13    # "v":Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
    .end local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v21    # "master":F
    .restart local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v3    # "sounds":Ljava/util/List;
    .restart local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v6    # "master":F
    :cond_4d2
    move-object v11, v1

    move-object v10, v3

    move-object/from16 v20, v5

    move/from16 v21, v6

    .end local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v3    # "sounds":Ljava/util/List;
    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .restart local v10    # "sounds":Ljava/util/List;
    .restart local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v21    # "master":F
    move-object/from16 v2, p1

    const/high16 v7, 0x41200000    # 10.0f

    goto/16 :goto_3e

    .line 155
    .end local v10    # "sounds":Ljava/util/List;
    .end local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v12    # "s":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v21    # "master":F
    .restart local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v3    # "sounds":Ljava/util/List;
    .restart local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v6    # "master":F
    :cond_4de
    move-object/from16 v20, v5

    move/from16 v21, v6

    move v13, v10

    move v5, v11

    move-object v11, v1

    move-object v10, v3

    .end local v1    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v3    # "sounds":Ljava/util/List;
    .end local v5    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .end local v6    # "master":F
    .restart local v10    # "sounds":Ljava/util/List;
    .restart local v11    # "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v20    # "cam":Lcom/exampletest/mobilestudiotest/render/FlyCamera;
    .restart local v21    # "master":F
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    invoke-virtual {v1}, Ljava/util/IdentityHashMap;->size()I

    move-result v1

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v2

    if-gt v1, v2, :cond_52c

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    invoke-virtual {v1}, Ljava/util/IdentityHashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    const-string v2, "<get-keys>(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$any\\4":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 360
    .local v2, "$i$f$any\\4\\155":I
    instance-of v3, v1, Ljava/util/Collection;

    if-eqz v3, :cond_50e

    move-object v3, v1

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_50e

    goto :goto_529

    .line 361
    :cond_50e
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_512
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_528

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\4":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 155
    .local v8, "$i$a$-any-AudioEngine$update$5\\5\\361\\0":I
    invoke-interface {v4, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v9

    .line 361
    .end local v7    # "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-any-AudioEngine$update$5\\5\\361\\0":I
    if-nez v9, :cond_512

    move v5, v13

    goto :goto_529

    .line 362
    .end local v6    # "element\\4":Ljava/lang/Object;
    :cond_528
    nop

    .line 155
    .end local v1    # "$this$any\\4":Ljava/lang/Iterable;
    .end local v2    # "$i$f$any\\4\\155":I
    :goto_529
    if-nez v5, :cond_52c

    goto :goto_563

    .line 156
    :cond_52c
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->voices:Ljava/util/IdentityHashMap;

    invoke-virtual {v1}, Ljava/util/IdentityHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .line 157
    .local v1, "it":Ljava/util/Iterator;
    :cond_536
    :goto_536
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_563

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const-string v3, "next(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljava/util/Map$Entry;

    .local v2, "e":Ljava/util/Map$Entry;
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v4, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_536

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const-string v5, "<get-value>(...)"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->release(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    .end local v2    # "e":Ljava/util/Map$Entry;
    goto :goto_536

    .line 159
    .end local v1    # "it":Ljava/util/Iterator;
    :cond_563
    :goto_563
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine.Preview (com.exampletest.mobilestudiotest.audio.AudioEngine$Preview)
.class public final Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
.super Ljava/lang/Object;
.source "AudioEngine.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/audio/AudioEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Preview"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0007\n\u0002\u0008\u0008\n\u0002\u0010\u000e\n\u0002\u0008\u0005\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007R\u001a\u0010\u0008\u001a\u00020\tX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\n\u0010\u000b\"\u0004\u0008\u000c\u0010\rR\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0010\u0010\u0011\"\u0004\u0008\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0015\u0010\u0011\"\u0004\u0008\u0016\u0010\u0013R\u001c\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0019\u0010\u001a\"\u0004\u0008\u001b\u0010\u001c\u00a8\u0006\u001d"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;",
        "",
        "id",
        "",
        "<init>",
        "(J)V",
        "getId",
        "()J",
        "state",
        "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;",
        "getState",
        "()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;",
        "setState",
        "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V",
        "position",
        "",
        "getPosition",
        "()F",
        "setPosition",
        "(F)V",
        "length",
        "getLength",
        "setLength",
        "error",
        "",
        "getError",
        "()Ljava/lang/String;",
        "setError",
        "(Ljava/lang/String;)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private volatile error:Ljava/lang/String;

.field private final id:J

.field private volatile length:F

.field private volatile position:F

.field private volatile state:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;


# direct methods
.method public constructor <init>(J)V
    .registers 4
    .param p1, "id"    # J

    .line 233
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->id:J

    .line 234
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->LOADING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->state:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    .line 233
    return-void
.end method


# virtual methods
.method public final getError()Ljava/lang/String;
    .registers 2

    .line 237
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->error:Ljava/lang/String;

    return-object v0
.end method

.method public final getId()J
    .registers 3

    .line 233
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->id:J

    return-wide v0
.end method

.method public final getLength()F
    .registers 2

    .line 236
    iget v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->length:F

    return v0
.end method

.method public final getPosition()F
    .registers 2

    .line 235
    iget v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->position:F

    return v0
.end method

.method public final getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;
    .registers 2

    .line 234
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->state:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    return-object v0
.end method

.method public final setError(Ljava/lang/String;)V
    .registers 2
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 237
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->error:Ljava/lang/String;

    return-void
.end method

.method public final setLength(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 236
    iput p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->length:F

    return-void
.end method

.method public final setPosition(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 235
    iput p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->position:F

    return-void
.end method

.method public final setState(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;)V
    .registers 3
    .param p1, "<set-?>"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->state:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine.PreviewState (com.exampletest.mobilestudiotest.audio.AudioEngine$PreviewState)
.class public final enum Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;
.super Ljava/lang/Enum;
.source "AudioEngine.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/audio/AudioEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "PreviewState"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0008\u0008\u0008\u0086\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003j\u0002\u0008\u0004j\u0002\u0008\u0005j\u0002\u0008\u0006j\u0002\u0008\u0007j\u0002\u0008\u0008\u00a8\u0006\t"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;",
        "",
        "<init>",
        "(Ljava/lang/String;I)V",
        "LOADING",
        "PLAYING",
        "PAUSED",
        "STOPPED",
        "ERROR",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

.field public static final enum ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

.field public static final enum LOADING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

.field public static final enum PAUSED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

.field public static final enum PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

.field public static final enum STOPPED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;


# direct methods
.method private static final synthetic $values()[Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;
    .registers 5

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->LOADING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    sget-object v2, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PAUSED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    sget-object v3, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->STOPPED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    sget-object v4, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    filled-new-array {v0, v1, v2, v3, v4}, [Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 3

    .line 232
    new-instance v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    const-string v1, "LOADING"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->LOADING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    new-instance v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    const-string v1, "PLAYING"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    new-instance v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    const-string v1, "PAUSED"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PAUSED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    new-instance v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    const-string v1, "STOPPED"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->STOPPED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    new-instance v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    const-string v1, "ERROR"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-static {}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->$values()[Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->$VALUES:[Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->$VALUES:[Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 232
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;
    .registers 2

    const-class v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    return-object v0
.end method

.method public static values()[Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;
    .registers 1

    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->$VALUES:[Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine.Voice (com.exampletest.mobilestudiotest.audio.AudioEngine$Voice)
.class final Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;
.super Ljava/lang/Object;
.source "AudioEngine.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/audio/AudioEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Voice"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0005\n\u0002\u0010\u0007\n\u0002\u0008\u0014\n\u0002\u0010\u0006\n\u0002\u0008\u0017\n\u0002\u0010\u0008\n\u0002\u0008\u0005\u0008\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u001c\u0010\u000c\u001a\u0004\u0018\u00010\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000e\u0010\u000f\"\u0004\u0008\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015\"\u0004\u0008\u0016\u0010\u0017R\u001a\u0010\u0018\u001a\u00020\u0019X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001a\u0010\u001b\"\u0004\u0008\u001c\u0010\u001dR\u001a\u0010\u001e\u001a\u00020\u0019X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001f\u0010\u001b\"\u0004\u0008 \u0010\u001dR\u001a\u0010!\u001a\u00020\u0019X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\"\u0010\u001b\"\u0004\u0008#\u0010\u001dR\u001e\u0010$\u001a\u0004\u0018\u00010\u0013X\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010)\u001a\u0004\u0008%\u0010&\"\u0004\u0008\'\u0010(R\u001a\u0010*\u001a\u00020\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008+\u0010\u0015\"\u0004\u0008,\u0010\u0017R\u001a\u0010-\u001a\u00020.X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008/\u00100\"\u0004\u00081\u00102R\u001a\u00103\u001a\u00020.X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00084\u00100\"\u0004\u00085\u00102R\u001a\u00106\u001a\u00020\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00087\u0010\u0015\"\u0004\u00088\u0010\u0017R\u001a\u00109\u001a\u00020\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008:\u0010\u0015\"\u0004\u0008;\u0010\u0017R\u001a\u0010<\u001a\u00020\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008=\u0010\u0015\"\u0004\u0008>\u0010\u0017R\u001a\u0010?\u001a\u00020.X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008@\u00100\"\u0004\u0008A\u00102R\u001a\u0010B\u001a\u00020.X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008C\u00100\"\u0004\u0008D\u00102R\u001a\u0010E\u001a\u00020FX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008G\u0010H\"\u0004\u0008I\u0010J\u00a8\u0006K"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;",
        "",
        "sound",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "id",
        "",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/model/Instance;J)V",
        "getSound",
        "()Lcom/exampletest/mobilestudiotest/model/Instance;",
        "getId",
        "()J",
        "mp",
        "Landroid/media/MediaPlayer;",
        "getMp",
        "()Landroid/media/MediaPlayer;",
        "setMp",
        "(Landroid/media/MediaPlayer;)V",
        "prepared",
        "",
        "getPrepared",
        "()Z",
        "setPrepared",
        "(Z)V",
        "lastL",
        "",
        "getLastL",
        "()F",
        "setLastL",
        "(F)V",
        "lastR",
        "getLastR",
        "setLastR",
        "lastSpeed",
        "getLastSpeed",
        "setLastSpeed",
        "lastLoop",
        "getLastLoop",
        "()Ljava/lang/Boolean;",
        "setLastLoop",
        "(Ljava/lang/Boolean;)V",
        "Ljava/lang/Boolean;",
        "wantPlay",
        "getWantPlay",
        "setWantPlay",
        "position",
        "",
        "getPosition",
        "()D",
        "setPosition",
        "(D)V",
        "length",
        "getLength",
        "setLength",
        "ended",
        "getEnded",
        "setEnded",
        "loadedNotified",
        "getLoadedNotified",
        "setLoadedNotified",
        "failed",
        "getFailed",
        "setFailed",
        "lastPushedPos",
        "getLastPushedPos",
        "setLastPushedPos",
        "seek",
        "getSeek",
        "setSeek",
        "seq",
        "",
        "getSeq",
        "()I",
        "setSeq",
        "(I)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private volatile ended:Z

.field private volatile failed:Z

.field private final id:J

.field private lastL:F

.field private lastLoop:Ljava/lang/Boolean;

.field private lastPushedPos:D

.field private lastR:F

.field private lastSpeed:F

.field private volatile length:D

.field private volatile loadedNotified:Z

.field private mp:Landroid/media/MediaPlayer;

.field private volatile position:D

.field private prepared:Z

.field private seek:D

.field private seq:I

.field private final sound:Lcom/exampletest/mobilestudiotest/model/Instance;

.field private wantPlay:Z


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/model/Instance;J)V
    .registers 6
    .param p1, "sound"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "id"    # J

    const-string v0, "sound"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->sound:Lcom/exampletest/mobilestudiotest/model/Instance;

    iput-wide p2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->id:J

    .line 33
    const/high16 v0, -0x40800000    # -1.0f

    iput v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastL:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastR:F

    iput v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastSpeed:F

    .line 40
    const-wide/high16 v0, -0x4010000000000000L    # -1.0

    iput-wide v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->seek:D

    .line 41
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->sound:Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v0

    const-string v1, "__playSeq"

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Integer;

    if-eqz v1, :cond_2b

    check-cast v0, Ljava/lang/Integer;

    goto :goto_2c

    :cond_2b
    const/4 v0, 0x0

    :goto_2c
    if-eqz v0, :cond_33

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    goto :goto_34

    :cond_33
    const/4 v0, 0x0

    :goto_34
    iput v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->seq:I

    .line 30
    return-void
.end method


# virtual methods
.method public final getEnded()Z
    .registers 2

    .line 36
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->ended:Z

    return v0
.end method

.method public final getFailed()Z
    .registers 2

    .line 38
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->failed:Z

    return v0
.end method

.method public final getId()J
    .registers 3

    .line 30
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->id:J

    return-wide v0
.end method

.method public final getLastL()F
    .registers 2

    .line 33
    iget v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastL:F

    return v0
.end method

.method public final getLastLoop()Ljava/lang/Boolean;
    .registers 2

    .line 33
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastLoop:Ljava/lang/Boolean;

    return-object v0
.end method

.method public final getLastPushedPos()D
    .registers 3

    .line 39
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastPushedPos:D

    return-wide v0
.end method

.method public final getLastR()F
    .registers 2

    .line 33
    iget v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastR:F

    return v0
.end method

.method public final getLastSpeed()F
    .registers 2

    .line 33
    iget v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastSpeed:F

    return v0
.end method

.method public final getLength()D
    .registers 3

    .line 35
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->length:D

    return-wide v0
.end method

.method public final getLoadedNotified()Z
    .registers 2

    .line 37
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->loadedNotified:Z

    return v0
.end method

.method public final getMp()Landroid/media/MediaPlayer;
    .registers 2

    .line 31
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->mp:Landroid/media/MediaPlayer;

    return-object v0
.end method

.method public final getPosition()D
    .registers 3

    .line 34
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->position:D

    return-wide v0
.end method

.method public final getPrepared()Z
    .registers 2

    .line 32
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->prepared:Z

    return v0
.end method

.method public final getSeek()D
    .registers 3

    .line 40
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->seek:D

    return-wide v0
.end method

.method public final getSeq()I
    .registers 2

    .line 41
    iget v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->seq:I

    return v0
.end method

.method public final getSound()Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 2

    .line 30
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->sound:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-object v0
.end method

.method public final getWantPlay()Z
    .registers 2

    .line 33
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->wantPlay:Z

    return v0
.end method

.method public final setEnded(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 36
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->ended:Z

    return-void
.end method

.method public final setFailed(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 38
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->failed:Z

    return-void
.end method

.method public final setLastL(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 33
    iput p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastL:F

    return-void
.end method

.method public final setLastLoop(Ljava/lang/Boolean;)V
    .registers 2
    .param p1, "<set-?>"    # Ljava/lang/Boolean;

    .line 33
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastLoop:Ljava/lang/Boolean;

    return-void
.end method

.method public final setLastPushedPos(D)V
    .registers 3
    .param p1, "<set-?>"    # D

    .line 39
    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastPushedPos:D

    return-void
.end method

.method public final setLastR(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 33
    iput p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastR:F

    return-void
.end method

.method public final setLastSpeed(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 33
    iput p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->lastSpeed:F

    return-void
.end method

.method public final setLength(D)V
    .registers 3
    .param p1, "<set-?>"    # D

    .line 35
    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->length:D

    return-void
.end method

.method public final setLoadedNotified(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 37
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->loadedNotified:Z

    return-void
.end method

.method public final setMp(Landroid/media/MediaPlayer;)V
    .registers 2
    .param p1, "<set-?>"    # Landroid/media/MediaPlayer;

    .line 31
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->mp:Landroid/media/MediaPlayer;

    return-void
.end method

.method public final setPosition(D)V
    .registers 3
    .param p1, "<set-?>"    # D

    .line 34
    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->position:D

    return-void
.end method

.method public final setPrepared(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 32
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->prepared:Z

    return-void
.end method

.method public final setSeek(D)V
    .registers 3
    .param p1, "<set-?>"    # D

    .line 40
    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->seek:D

    return-void
.end method

.method public final setSeq(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 41
    iput p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->seq:I

    return-void
.end method

.method public final setWantPlay(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 33
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->wantPlay:Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine.WhenMappings (com.exampletest.mobilestudiotest.audio.AudioEngine$WhenMappings)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$WhenMappings;
.super Ljava/lang/Object;
.source "AudioEngine.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/audio/AudioEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1019
    name = "WhenMappings"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final synthetic $EnumSwitchMapping$0:[I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    invoke-static {}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->values()[Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_7
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_10} :catch_11

    goto :goto_12

    :catch_11
    move-exception v1

    :goto_12
    :try_start_12
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PAUSED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_1b} :catch_1c

    goto :goto_1d

    :catch_1c
    move-exception v1

    :goto_1d
    :try_start_1d
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->STOPPED:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_26
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1d .. :try_end_26} :catch_27

    goto :goto_28

    :catch_27
    move-exception v1

    :goto_28
    :try_start_28
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->LOADING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_31
    .catch Ljava/lang/NoSuchFieldError; {:try_start_28 .. :try_end_31} :catch_32

    goto :goto_33

    :catch_32
    move-exception v1

    :goto_33
    :try_start_33
    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ERROR:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->ordinal()I

    move-result v1

    const/4 v2, 0x5

    aput v2, v0, v1
    :try_end_3c
    .catch Ljava/lang/NoSuchFieldError; {:try_start_33 .. :try_end_3c} :catch_3d

    goto :goto_3e

    :catch_3d
    move-exception v1

    :goto_3e
    sput-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$WhenMappings;->$EnumSwitchMapping$0:[I

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine.AnonymousClass1 (com.exampletest.mobilestudiotest.audio.AudioEngine$tick$1)
.class public final Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$1;
.super Ljava/lang/Object;
.source "AudioEngine.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->tick(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/audio/AudioEngine$tick$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $v:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;


# direct methods
.method constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 2
    .param p1, "$v"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$1;->$v:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    .line 209
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    .line 211
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$1;->$v:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getMp()Landroid/media/MediaPlayer;

    move-result-object v0

    if-nez v0, :cond_9

    return-void

    .line 212
    .local v0, "mp":Landroid/media/MediaPlayer;
    :cond_9
    :try_start_9
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$1;->$v:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getPrepared()Z

    move-result v1

    if-eqz v1, :cond_21

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$1;->$v:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v2

    int-to-double v2, v2

    const-wide v4, 0x408f400000000000L    # 1000.0

    div-double/2addr v2, v4

    invoke-virtual {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->setPosition(D)V
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_21} :catch_36

    .line 213
    :cond_21
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$1;->$v:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;->getWantPlay()Z

    move-result v1

    if-eqz v1, :cond_35

    invoke-static {}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->access$getH$p()Landroid/os/Handler;

    move-result-object v1

    move-object v2, p0

    check-cast v2, Ljava/lang/Runnable;

    const-wide/16 v3, 0xc8

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 214
    :cond_35
    return-void

    .line 212
    :catch_36
    move-exception v1

    .local v1, "<unused var>":Ljava/lang/Exception;
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine.AnonymousClass2 (com.exampletest.mobilestudiotest.audio.AudioEngine$tick$2)
.class public final Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;
.super Ljava/lang/Object;
.source "AudioEngine.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->tick(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/audio/AudioEngine$tick$2",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $mp:Landroid/media/MediaPlayer;

.field final synthetic $p:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;


# direct methods
.method constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V
    .registers 3
    .param p1, "$p"    # Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;
    .param p2, "$mp"    # Landroid/media/MediaPlayer;

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;->$p:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;->$mp:Landroid/media/MediaPlayer;

    .line 299
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 301
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->getPreview()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;->$p:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    if-ne v0, v1, :cond_3f

    invoke-static {}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->access$getPreviewPlayer$p()Landroid/media/MediaPlayer;

    move-result-object v0

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;->$mp:Landroid/media/MediaPlayer;

    if-ne v0, v1, :cond_3f

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;->$p:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->getState()Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;->PLAYING:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$PreviewState;

    if-ne v0, v1, :cond_3f

    .line 302
    :try_start_1c
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;->$p:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$tick$2;->$mp:Landroid/media/MediaPlayer;

    invoke-virtual {v1}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x447a0000    # 1000.0f

    div-float/2addr v1, v2

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;->setPosition(F)V
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_2b} :catch_3d

    .line 303
    sget-object v0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->INSTANCE:Lcom/exampletest/mobilestudiotest/audio/AudioEngine;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->access$notifyPreview(Lcom/exampletest/mobilestudiotest/audio/AudioEngine;)V

    .line 304
    invoke-static {}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->access$getH$p()Landroid/os/Handler;

    move-result-object v0

    move-object v1, p0

    check-cast v1, Ljava/lang/Runnable;

    const-wide/16 v2, 0x96

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 305
    return-void

    .line 302
    :catch_3d
    move-exception v0

    .local v0, "<unused var>":Ljava/lang/Exception;
    return-void

    .line 301
    .end local v0    # "<unused var>":Ljava/lang/Exception;
    :cond_3f
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "seekPreview$lambda$23"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

.field public final synthetic f$1:F


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda0;->f$1:F

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda0;->f$1:F

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->seekPreview$lambda$23(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnPreparedListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "togglePreview$lambda$19$lambda$18$lambda$15"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;FLandroid/media/MediaPlayer;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

.field public final synthetic f$1:F


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda1;->f$1:F

    return-void
.end method


# virtual methods
.method public final onPrepared(Landroid/media/MediaPlayer;)V
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda1;->f$1:F

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview$lambda$19$lambda$18$lambda$15(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;FLandroid/media/MediaPlayer;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda10 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda10)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "togglePreview$lambda$19"
    proto = "(JLcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

.field public final synthetic f$2:F


# direct methods
.method public synthetic constructor <init>(JLcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;->f$0:J

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;->f$1:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iput p4, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;->f$2:F

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;->f$0:J

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;->f$1:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda10;->f$2:F

    invoke-static {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview$lambda$19(JLcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;F)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda11 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda11)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "resumePreview$lambda$21"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda11;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda11;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->resumePreview$lambda$21(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda12 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda12)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "create$lambda$12"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda12;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda12;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->create$lambda$12(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda13 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda13)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnPreparedListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "create$lambda$12$lambda$9"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda13;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    return-void
.end method


# virtual methods
.method public final onPrepared(Landroid/media/MediaPlayer;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda13;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->create$lambda$12$lambda$9(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda14 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda14)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnCompletionListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "create$lambda$12$lambda$10"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda14;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    return-void
.end method


# virtual methods
.method public final onCompletion(Landroid/media/MediaPlayer;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda14;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->create$lambda$12$lambda$10(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda15 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda15)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "create$lambda$12$lambda$11"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;II)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda15;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    return-void
.end method


# virtual methods
.method public final onError(Landroid/media/MediaPlayer;II)Z
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda15;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-static {v0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->create$lambda$12$lambda$11(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Landroid/media/MediaPlayer;II)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda16 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda16)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "pausePreview$lambda$20"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda16;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda16;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->pausePreview$lambda$20(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnCompletionListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "togglePreview$lambda$19$lambda$18$lambda$16"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    return-void
.end method


# virtual methods
.method public final onCompletion(Landroid/media/MediaPlayer;)V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview$lambda$19$lambda$18$lambda$16(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "togglePreview$lambda$19$lambda$18$lambda$17"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;II)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    return-void
.end method


# virtual methods
.method public final onError(Landroid/media/MediaPlayer;II)Z
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda3;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    invoke-static {v0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview$lambda$19$lambda$18$lambda$17(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;Landroid/media/MediaPlayer;II)Z

    move-result p1

    return p1
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "update$lambda$2"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Z)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Z)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    iput-boolean p2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda4;->f$1:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    iget-boolean v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda4;->f$1:Z

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->update$lambda$2(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;Z)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "update$lambda$6"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda5;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->update$lambda$6(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "update$lambda$7"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;FFFZZ)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

.field public final synthetic f$1:F

.field public final synthetic f$2:F

.field public final synthetic f$3:F

.field public final synthetic f$4:Z

.field public final synthetic f$5:Z


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;FFFZZ)V
    .registers 7

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    iput p2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$1:F

    iput p3, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$2:F

    iput p4, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$3:F

    iput-boolean p5, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$4:Z

    iput-boolean p6, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$5:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$1:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$2:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$3:F

    iget-boolean v4, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$4:Z

    iget-boolean v5, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda6;->f$5:Z

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->update$lambda$7(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;FFFZZ)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "stopPreview$lambda$24"
    proto = "()V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 1

    .line 0
    invoke-static {}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->stopPreview$lambda$24()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda8 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "release$lambda$13"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda8;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->release$lambda$13(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Voice;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda9 (com.exampletest.mobilestudiotest.audio.AudioEngine$$ExternalSyntheticLambda9)
.class public final synthetic Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/audio/AudioEngine;"
    method = "togglePreview$lambda$19$lambda$18"
    proto = "(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;JF)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

.field public final synthetic f$1:J

.field public final synthetic f$2:F


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;JF)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iput-wide p2, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;->f$1:J

    iput p4, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;->f$2:F

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;

    iget-wide v1, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;->f$1:J

    iget v3, p0, Lcom/exampletest/mobilestudiotest/audio/AudioEngine$$ExternalSyntheticLambda9;->f$2:F

    invoke-static {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/audio/AudioEngine;->togglePreview$lambda$19$lambda$18(Lcom/exampletest/mobilestudiotest/audio/AudioEngine$Preview;JF)V

    return-void
.end method
