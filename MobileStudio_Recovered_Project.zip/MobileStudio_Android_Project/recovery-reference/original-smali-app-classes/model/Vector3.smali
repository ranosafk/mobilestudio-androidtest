###### Class com.exampletest.mobilestudiotest.model.Vector3 (com.exampletest.mobilestudiotest.model.Vector3)
.class public final Lcom/exampletest/mobilestudiotest/model/Vector3;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u001d\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0004\u0008\u0086\u0008\u0018\u0000 ,2\u00020\u0001:\u0001,B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0011\u0010\u000c\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0000H\u0086\u0002J\u0011\u0010\u000e\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0000H\u0086\u0002J\u0011\u0010\u000f\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0003H\u0086\u0002J\u0011\u0010\u000f\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0000H\u0086\u0002J\u0011\u0010\u0011\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0003H\u0086\u0002J\u0011\u0010\u0011\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0000H\u0086\u0002J\t\u0010\u0012\u001a\u00020\u0000H\u0086\u0002J\u000e\u0010\u0013\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\u0000J\u000e\u0010\u0014\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0000J\u0016\u0010\u001a\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u0003J\u0006\u0010\u001c\u001a\u00020\u0000J\u000e\u0010\u001d\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0000J\u000e\u0010\u001e\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0000J\u0011\u0010\u001f\u001a\u00020\u00032\u0006\u0010 \u001a\u00020!H\u0086\u0002J\u0008\u0010\"\u001a\u00020#H\u0016J\t\u0010$\u001a\u00020\u0003H\u00c6\u0003J\t\u0010%\u001a\u00020\u0003H\u00c6\u0003J\t\u0010&\u001a\u00020\u0003H\u00c6\u0003J\'\u0010\'\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0003H\u00c6\u0001J\u0013\u0010(\u001a\u00020)2\u0008\u0010*\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010+\u001a\u00020!H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\tR\u0011\u0010\u0015\u001a\u00020\u00038F\u00a2\u0006\u0006\u001a\u0004\u0008\u0016\u0010\tR\u0011\u0010\u0017\u001a\u00020\u00008F\u00a2\u0006\u0006\u001a\u0004\u0008\u0018\u0010\u0019\u00a8\u0006-"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "",
        "x",
        "",
        "y",
        "z",
        "<init>",
        "(FFF)V",
        "getX",
        "()F",
        "getY",
        "getZ",
        "plus",
        "o",
        "minus",
        "times",
        "s",
        "div",
        "unaryMinus",
        "dot",
        "cross",
        "magnitude",
        "getMagnitude",
        "unit",
        "getUnit",
        "()Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "lerp",
        "t",
        "abs",
        "min",
        "max",
        "get",
        "i",
        "",
        "toString",
        "",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

.field private static final ONE:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private static final X:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private static final Y:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private static final Z:Lcom/exampletest/mobilestudiotest/model/Vector3;

.field private static final ZERO:Lcom/exampletest/mobilestudiotest/model/Vector3;


# instance fields
.field private final x:F

.field private final y:F

.field private final z:F


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    .line 43
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->ZERO:Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 44
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v0, v2, v2, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->ONE:Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 45
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v0, v2, v1, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->X:Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 46
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v0, v1, v2, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Y:Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 47
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v0, v1, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Z:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-void
.end method

.method public constructor <init>(FFF)V
    .registers 4
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iput p2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iput p3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    return-void
.end method

.method public static final synthetic access$getONE$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 1

    .line 23
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->ONE:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public static final synthetic access$getX$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 1

    .line 23
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->X:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public static final synthetic access$getY$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 1

    .line 23
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Y:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public static final synthetic access$getZ$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 1

    .line 23
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Z:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public static final synthetic access$getZERO$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 1

    .line 23
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->ZERO:Lcom/exampletest/mobilestudiotest/model/Vector3;

    return-object v0
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/model/Vector3;FFFILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget p1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget p2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget p3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->copy(FFF)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final abs()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 5

    .line 36
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final component1()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    return v0
.end method

.method public final component2()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    return v0
.end method

.method public final component3()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    return v0
.end method

.method public final copy(FFF)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 5

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final cross(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 8
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    mul-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    mul-float/2addr v2, v3

    sub-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    mul-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    mul-float/2addr v3, v4

    sub-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    mul-float/2addr v3, v4

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v5, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    mul-float/2addr v4, v5

    sub-float/2addr v3, v4

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 6
    .param p1, "s"    # F

    .line 28
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    div-float/2addr v1, p1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    div-float/2addr v2, p1

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    div-float/2addr v3, p1

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final div(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 7
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    div-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    div-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    div-float/2addr v3, v4

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F
    .registers 5
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v1, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    mul-float/2addr v0, v1

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    mul-float/2addr v1, v2

    add-float/2addr v0, v1

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    mul-float/2addr v1, v2

    add-float/2addr v0, v1

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    invoke-static {v3, v4}, Ljava/lang/Float;->compare(FF)I

    move-result v3

    if-eqz v3, :cond_18

    return v2

    :cond_18
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    invoke-static {v3, v4}, Ljava/lang/Float;->compare(FF)I

    move-result v3

    if-eqz v3, :cond_23

    return v2

    :cond_23
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v1, v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_2e

    return v2

    :cond_2e
    return v0
.end method

.method public final get(I)F
    .registers 3
    .param p1, "i"    # I

    .line 39
    packed-switch p1, :pswitch_data_c

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    goto :goto_b

    :pswitch_6
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    goto :goto_b

    :pswitch_9
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    :goto_b
    return v0

    :pswitch_data_c
    .packed-switch 0x0
        :pswitch_9
        :pswitch_6
    .end packed-switch
.end method

.method public final getMagnitude()F
    .registers 4

    .line 33
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    mul-float/2addr v0, v1

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    mul-float/2addr v1, v2

    add-float/2addr v0, v1

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    mul-float/2addr v1, v2

    add-float/2addr v0, v1

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    double-to-float v0, v0

    return v0
.end method

.method public final getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 3

    .line 34
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v0

    .local v0, "m":F
    const v1, 0x3089705f    # 1.0E-9f

    cmpg-float v1, v0, v1

    if-gez v1, :cond_e

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->ZERO:Lcom/exampletest/mobilestudiotest/model/Vector3;

    goto :goto_12

    :cond_e
    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    :goto_12
    return-object v1
.end method

.method public final getX()F
    .registers 2

    .line 23
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    return v0
.end method

.method public final getY()F
    .registers 2

    .line 23
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    return v0
.end method

.method public final getZ()F
    .registers 2

    .line 23
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    return v0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    invoke-static {v2}, Ljava/lang/Float;->hashCode(F)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    invoke-static {v2}, Ljava/lang/Float;->hashCode(F)I

    move-result v2

    add-int/2addr v0, v2

    return v0
.end method

.method public final lerp(Lcom/exampletest/mobilestudiotest/model/Vector3;F)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 9
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "t"    # F

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    sub-float/2addr v2, v3

    mul-float/2addr v2, p2

    add-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    sub-float/2addr v3, v4

    mul-float/2addr v3, p2

    add-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    sub-float/2addr v4, v5

    mul-float/2addr v4, p2

    add-float/2addr v3, v4

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final max(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 7
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    move-result v2

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final min(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 7
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 37
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 7
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    sub-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    sub-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    sub-float/2addr v3, v4

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 7
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    add-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    add-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    add-float/2addr v3, v4

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 6
    .param p1, "s"    # F

    .line 26
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    mul-float/2addr v1, p1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    mul-float/2addr v2, p1

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    mul-float/2addr v3, p1

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 7
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    mul-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    mul-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    mul-float/2addr v3, v4

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 5

    .line 40
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v0

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, ", "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 5

    .line 30
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->x:F

    neg-float v1, v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->y:F

    neg-float v2, v2

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Vector3;->z:F

    neg-float v3, v3

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.model.Vector3.Companion (com.exampletest.mobilestudiotest.model.Vector3$Companion)
.class public final Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/model/Vector3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u0008\n\u0000\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\u0010\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\u0012R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007R\u0011\u0010\u0008\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\u0007R\u0011\u0010\n\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u0007R\u0011\u0010\u000c\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u0007R\u0011\u0010\u000e\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0007\u00a8\u0006\u0013"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;",
        "",
        "<init>",
        "()V",
        "ZERO",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "getZERO",
        "()Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "ONE",
        "getONE",
        "X",
        "getX",
        "Y",
        "getY",
        "Z",
        "getZ",
        "axis",
        "i",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final axis(I)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 3
    .param p1, "i"    # I

    .line 48
    packed-switch p1, :pswitch_data_12

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZ()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    goto :goto_11

    :pswitch_8
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getY()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    goto :goto_11

    :pswitch_d
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getX()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    :goto_11
    return-object v0

    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_d
        :pswitch_8
    .end packed-switch
.end method

.method public final getONE()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 44
    invoke-static {}, Lcom/exampletest/mobilestudiotest/model/Vector3;->access$getONE$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0
.end method

.method public final getX()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 45
    invoke-static {}, Lcom/exampletest/mobilestudiotest/model/Vector3;->access$getX$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0
.end method

.method public final getY()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 46
    invoke-static {}, Lcom/exampletest/mobilestudiotest/model/Vector3;->access$getY$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0
.end method

.method public final getZ()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 47
    invoke-static {}, Lcom/exampletest/mobilestudiotest/model/Vector3;->access$getZ$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0
.end method

.method public final getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 2

    .line 43
    invoke-static {}, Lcom/exampletest/mobilestudiotest/model/Vector3;->access$getZERO$cp()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0
.end method
