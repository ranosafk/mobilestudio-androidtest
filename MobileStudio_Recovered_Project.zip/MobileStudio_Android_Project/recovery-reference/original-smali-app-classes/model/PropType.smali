###### Class com.exampletest.mobilestudiotest.model.PropType (com.exampletest.mobilestudiotest.model.PropType)
.class public final Lcom/exampletest/mobilestudiotest/model/PropType;
.super Ljava/lang/Object;
.source "Instance.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008#\n\u0002\u0010\u000b\n\u0000\u0008\u00c6\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010$\u001a\u00020\u00052\u0008\u0010%\u001a\u0004\u0018\u00010\u0001J\u0010\u0010&\u001a\u0004\u0018\u00010\u00012\u0006\u0010\'\u001a\u00020\u0005J\u0018\u0010(\u001a\u00020)2\u0006\u0010\'\u001a\u00020\u00052\u0008\u0010%\u001a\u0004\u0018\u00010\u0001R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006*"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/PropType;",
        "",
        "<init>",
        "()V",
        "STRING",
        "",
        "BOOL",
        "INT",
        "FLOAT",
        "DOUBLE",
        "UDIM",
        "UDIM2",
        "RAY",
        "FACES",
        "AXES",
        "BRICKCOLOR",
        "COLOR3",
        "VECTOR2",
        "VECTOR3",
        "CFRAME",
        "ENUM",
        "REF",
        "VECTOR3INT16",
        "NUMBERSEQ",
        "COLORSEQ",
        "NUMBERRANGE",
        "RECT",
        "PHYSPROPS",
        "COLOR3U8",
        "INT64",
        "SHAREDSTRING",
        "OPTCFRAME",
        "UNIQUEID",
        "FONT",
        "SECCAPS",
        "CONTENT",
        "infer",
        "v",
        "default",
        "t",
        "hidden",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final AXES:I = 0xa

.field public static final BOOL:I = 0x2

.field public static final BRICKCOLOR:I = 0xb

.field public static final CFRAME:I = 0x10

.field public static final COLOR3:I = 0xc

.field public static final COLOR3U8:I = 0x1a

.field public static final COLORSEQ:I = 0x16

.field public static final CONTENT:I = 0x22

.field public static final DOUBLE:I = 0x5

.field public static final ENUM:I = 0x12

.field public static final FACES:I = 0x9

.field public static final FLOAT:I = 0x4

.field public static final FONT:I = 0x20

.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropType;

.field public static final INT:I = 0x3

.field public static final INT64:I = 0x1b

.field public static final NUMBERRANGE:I = 0x17

.field public static final NUMBERSEQ:I = 0x15

.field public static final OPTCFRAME:I = 0x1e

.field public static final PHYSPROPS:I = 0x19

.field public static final RAY:I = 0x8

.field public static final RECT:I = 0x18

.field public static final REF:I = 0x13

.field public static final SECCAPS:I = 0x21

.field public static final SHAREDSTRING:I = 0x1c

.field public static final STRING:I = 0x1

.field public static final UDIM:I = 0x6

.field public static final UDIM2:I = 0x7

.field public static final UNIQUEID:I = 0x1f

.field public static final VECTOR2:I = 0xd

.field public static final VECTOR3:I = 0xe

.field public static final VECTOR3INT16:I = 0x14


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/PropType;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/model/PropType;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/PropType;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropType;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 216
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final default(I)Ljava/lang/Object;
    .registers 17
    .param p1, "t"    # I

    .line 261
    const-wide/16 v0, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v4, ""

    const/4 v5, 0x0

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v7, 0x0

    const/4 v8, 0x0

    packed-switch p1, :pswitch_data_128

    .line 292
    :pswitch_e
    move-object v4, v5

    goto/16 :goto_126

    .line 291
    :pswitch_11
    new-instance v9, Lcom/exampletest/mobilestudiotest/model/ContentValue;

    const/4 v13, 0x6

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-direct/range {v9 .. v14}, Lcom/exampletest/mobilestudiotest/model/ContentValue;-><init>(ILjava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v4, v9

    goto/16 :goto_126

    .line 290
    :pswitch_1e
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;

    invoke-direct {v4, v0, v1}, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;-><init>(J)V

    goto/16 :goto_126

    .line 289
    :pswitch_25
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/FontValue;

    const-string v1, "rbxasset://fonts/families/SourceSansPro.json"

    const/16 v2, 0x190

    invoke-direct {v0, v1, v2, v7, v4}, Lcom/exampletest/mobilestudiotest/model/FontValue;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    move-object v4, v0

    goto/16 :goto_126

    .line 288
    :pswitch_31
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/UniqueId;

    const/16 v0, 0x10

    new-array v0, v0, [B

    invoke-direct {v4, v0}, Lcom/exampletest/mobilestudiotest/model/UniqueId;-><init>([B)V

    goto/16 :goto_126

    .line 287
    :pswitch_3c
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;-><init>(Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    goto/16 :goto_126

    .line 286
    :pswitch_43
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/SharedStr;

    new-array v0, v7, [B

    invoke-direct {v4, v0}, Lcom/exampletest/mobilestudiotest/model/SharedStr;-><init>([B)V

    goto/16 :goto_126

    .line 267
    :pswitch_4c
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    goto/16 :goto_126

    .line 285
    :pswitch_52
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;

    const/16 v13, 0x7e

    const/4 v14, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-direct/range {v5 .. v14}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;-><init>(IFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v4, v5

    goto/16 :goto_126

    .line 284
    :pswitch_64
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Rect;

    invoke-direct {v4, v8, v8, v8, v8}, Lcom/exampletest/mobilestudiotest/model/Rect;-><init>(FFFF)V

    goto/16 :goto_126

    .line 283
    :pswitch_6b
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/NumberRange;

    invoke-direct {v4, v8, v8}, Lcom/exampletest/mobilestudiotest/model/NumberRange;-><init>(FF)V

    goto/16 :goto_126

    .line 282
    :pswitch_72
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/ColorSequence;

    new-array v0, v3, [Lcom/exampletest/mobilestudiotest/model/ColorKey;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    new-instance v3, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v3, v6, v6, v6}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    invoke-direct {v1, v8, v3, v8}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    aput-object v1, v0, v7

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    new-instance v3, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v3, v6, v6, v6}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    invoke-direct {v1, v6, v3, v8}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    aput-object v1, v0, v2

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-direct {v4, v0}, Lcom/exampletest/mobilestudiotest/model/ColorSequence;-><init>(Ljava/util/List;)V

    goto/16 :goto_126

    .line 281
    :pswitch_97
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/NumberSequence;

    new-array v0, v3, [Lcom/exampletest/mobilestudiotest/model/NumberKey;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    invoke-direct {v1, v8, v8, v8}, Lcom/exampletest/mobilestudiotest/model/NumberKey;-><init>(FFF)V

    aput-object v1, v0, v7

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    invoke-direct {v1, v6, v8, v8}, Lcom/exampletest/mobilestudiotest/model/NumberKey;-><init>(FFF)V

    aput-object v1, v0, v2

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-direct {v4, v0}, Lcom/exampletest/mobilestudiotest/model/NumberSequence;-><init>(Ljava/util/List;)V

    goto/16 :goto_126

    .line 280
    :pswitch_b2
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    invoke-direct {v4, v7, v7, v7}, Lcom/exampletest/mobilestudiotest/model/Vector3int16;-><init>(III)V

    goto/16 :goto_126

    .line 279
    :pswitch_b9
    move-object v4, v5

    goto/16 :goto_126

    .line 278
    :pswitch_bc
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-direct {v4, v7}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    goto/16 :goto_126

    .line 277
    :pswitch_c3
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    goto :goto_126

    .line 276
    :pswitch_ca
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    goto :goto_126

    .line 275
    :pswitch_d1
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-direct {v4, v8, v8}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    goto :goto_126

    .line 274
    :pswitch_d7
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v4, v8, v8, v8}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    goto :goto_126

    .line 273
    :pswitch_dd
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    const/16 v0, 0xc2

    invoke-direct {v4, v0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    goto :goto_126

    .line 272
    :pswitch_e5
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Axes;

    invoke-direct {v4, v7}, Lcom/exampletest/mobilestudiotest/model/Axes;-><init>(I)V

    goto :goto_126

    .line 271
    :pswitch_eb
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Faces;

    invoke-direct {v4, v7}, Lcom/exampletest/mobilestudiotest/model/Faces;-><init>(I)V

    goto :goto_126

    .line 270
    :pswitch_f1
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Ray;

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-direct {v4, v0, v1}, Lcom/exampletest/mobilestudiotest/model/Ray;-><init>(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    goto :goto_126

    .line 269
    :pswitch_103
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/UDim2;

    invoke-direct {v4, v8, v7, v8, v7}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    goto :goto_126

    .line 268
    :pswitch_109
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-direct {v4, v8, v7}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    goto :goto_126

    .line 266
    :pswitch_10f
    const-wide/16 v0, 0x0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    goto :goto_126

    .line 265
    :pswitch_116
    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    goto :goto_126

    .line 264
    :pswitch_11b
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    goto :goto_126

    .line 263
    :pswitch_120
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    goto :goto_126

    .line 262
    :pswitch_125
    nop

    .line 293
    :goto_126
    return-object v4

    nop

    :pswitch_data_128
    .packed-switch 0x1
        :pswitch_125
        :pswitch_120
        :pswitch_11b
        :pswitch_116
        :pswitch_10f
        :pswitch_109
        :pswitch_103
        :pswitch_f1
        :pswitch_eb
        :pswitch_e5
        :pswitch_dd
        :pswitch_d7
        :pswitch_d1
        :pswitch_ca
        :pswitch_e
        :pswitch_c3
        :pswitch_e
        :pswitch_bc
        :pswitch_b9
        :pswitch_b2
        :pswitch_97
        :pswitch_72
        :pswitch_6b
        :pswitch_64
        :pswitch_52
        :pswitch_d7
        :pswitch_4c
        :pswitch_43
        :pswitch_e
        :pswitch_3c
        :pswitch_31
        :pswitch_25
        :pswitch_1e
        :pswitch_11
    .end packed-switch
.end method

.method public final hidden(ILjava/lang/Object;)Z
    .registers 4
    .param p1, "t"    # I
    .param p2, "v"    # Ljava/lang/Object;

    .line 296
    const/16 v0, 0x1c

    if-eq p1, v0, :cond_16

    const/16 v0, 0x1f

    if-eq p1, v0, :cond_16

    const/16 v0, 0x21

    if-eq p1, v0, :cond_16

    instance-of v0, p2, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    if-nez v0, :cond_16

    instance-of v0, p2, Lcom/exampletest/mobilestudiotest/model/RawPropValue;

    if-nez v0, :cond_16

    const/4 v0, 0x0

    goto :goto_17

    :cond_16
    const/4 v0, 0x1

    :goto_17
    return v0
.end method

.method public final infer(Ljava/lang/Object;)I
    .registers 5
    .param p1, "v"    # Ljava/lang/Object;

    .line 225
    nop

    .line 226
    const/16 v0, 0x13

    if-nez p1, :cond_7

    goto/16 :goto_f4

    .line 227
    :cond_7
    instance-of v1, p1, Ljava/lang/String;

    const/4 v2, 0x1

    if-nez v1, :cond_f3

    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    if-nez v1, :cond_f3

    .line 228
    instance-of v1, p1, Ljava/lang/Boolean;

    if-eqz v1, :cond_17

    const/4 v0, 0x2

    goto/16 :goto_f4

    .line 229
    :cond_17
    instance-of v1, p1, Ljava/lang/Integer;

    if-eqz v1, :cond_1e

    const/4 v0, 0x3

    goto/16 :goto_f4

    .line 230
    :cond_1e
    instance-of v1, p1, Ljava/lang/Float;

    if-eqz v1, :cond_25

    const/4 v0, 0x4

    goto/16 :goto_f4

    .line 231
    :cond_25
    instance-of v1, p1, Ljava/lang/Double;

    if-eqz v1, :cond_2c

    const/4 v0, 0x5

    goto/16 :goto_f4

    .line 232
    :cond_2c
    instance-of v1, p1, Ljava/lang/Long;

    if-eqz v1, :cond_34

    const/16 v0, 0x1b

    goto/16 :goto_f4

    .line 233
    :cond_34
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v1, :cond_3b

    const/4 v0, 0x6

    goto/16 :goto_f4

    .line 234
    :cond_3b
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v1, :cond_42

    const/4 v0, 0x7

    goto/16 :goto_f4

    .line 235
    :cond_42
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Ray;

    if-eqz v1, :cond_4a

    const/16 v0, 0x8

    goto/16 :goto_f4

    .line 236
    :cond_4a
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Faces;

    if-eqz v1, :cond_52

    const/16 v0, 0x9

    goto/16 :goto_f4

    .line 237
    :cond_52
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Axes;

    if-eqz v1, :cond_5a

    const/16 v0, 0xa

    goto/16 :goto_f4

    .line 238
    :cond_5a
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    if-eqz v1, :cond_62

    const/16 v0, 0xb

    goto/16 :goto_f4

    .line 239
    :cond_62
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v1, :cond_6a

    const/16 v0, 0xc

    goto/16 :goto_f4

    .line 240
    :cond_6a
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v1, :cond_72

    const/16 v0, 0xd

    goto/16 :goto_f4

    .line 241
    :cond_72
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v1, :cond_7a

    const/16 v0, 0xe

    goto/16 :goto_f4

    .line 242
    :cond_7a
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v1, :cond_82

    const/16 v0, 0x10

    goto/16 :goto_f4

    .line 243
    :cond_82
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    if-eqz v1, :cond_8a

    const/16 v0, 0x12

    goto/16 :goto_f4

    .line 244
    :cond_8a
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v1, :cond_90

    goto/16 :goto_f4

    .line 245
    :cond_90
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    if-eqz v0, :cond_98

    const/16 v0, 0x14

    goto/16 :goto_f4

    .line 246
    :cond_98
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/NumberSequence;

    if-eqz v0, :cond_9f

    const/16 v0, 0x15

    goto :goto_f4

    .line 247
    :cond_9f
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/ColorSequence;

    if-eqz v0, :cond_a6

    const/16 v0, 0x16

    goto :goto_f4

    .line 248
    :cond_a6
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/NumberRange;

    if-eqz v0, :cond_ad

    const/16 v0, 0x17

    goto :goto_f4

    .line 249
    :cond_ad
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/Rect;

    if-eqz v0, :cond_b4

    const/16 v0, 0x18

    goto :goto_f4

    .line 250
    :cond_b4
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;

    if-eqz v0, :cond_bb

    const/16 v0, 0x19

    goto :goto_f4

    .line 251
    :cond_bb
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/SharedStr;

    if-eqz v0, :cond_c2

    const/16 v0, 0x1c

    goto :goto_f4

    .line 252
    :cond_c2
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    if-eqz v0, :cond_c9

    const/16 v0, 0x1e

    goto :goto_f4

    .line 253
    :cond_c9
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/UniqueId;

    if-eqz v0, :cond_d0

    const/16 v0, 0x1f

    goto :goto_f4

    .line 254
    :cond_d0
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/FontValue;

    if-eqz v0, :cond_d7

    const/16 v0, 0x20

    goto :goto_f4

    .line 255
    :cond_d7
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;

    if-eqz v0, :cond_de

    const/16 v0, 0x21

    goto :goto_f4

    .line 256
    :cond_de
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/ContentValue;

    if-eqz v0, :cond_e5

    const/16 v0, 0x22

    goto :goto_f4

    .line 257
    :cond_e5
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/RawPropValue;

    if-eqz v0, :cond_f1

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/RawPropValue;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/RawPropValue;->getType()I

    move-result v0

    goto :goto_f4

    .line 258
    :cond_f1
    move v0, v2

    goto :goto_f4

    .line 227
    :cond_f3
    move v0, v2

    .line 259
    :goto_f4
    return v0
.end method
