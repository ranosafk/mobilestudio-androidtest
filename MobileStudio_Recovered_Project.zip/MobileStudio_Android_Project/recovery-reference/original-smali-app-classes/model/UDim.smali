###### Class com.exampletest.mobilestudiotest.model.UDim (com.exampletest.mobilestudiotest.model.UDim)
.class public final Lcom/exampletest/mobilestudiotest/model/UDim;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0007\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u000b\n\u0002\u0008\u0003\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0008\u0010\u000c\u001a\u00020\rH\u0016J\t\u0010\u000e\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u000f\u001a\u00020\u0005H\u00c6\u0003J\u001d\u0010\u0010\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005H\u00c6\u0001J\u0013\u0010\u0011\u001a\u00020\u00122\u0008\u0010\u0013\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0014\u001a\u00020\u0005H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000b\u00a8\u0006\u0015"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/UDim;",
        "",
        "scale",
        "",
        "offset",
        "",
        "<init>",
        "(FI)V",
        "getScale",
        "()F",
        "getOffset",
        "()I",
        "toString",
        "",
        "component1",
        "component2",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final offset:I

.field private final scale:F


# direct methods
.method public constructor <init>(FI)V
    .registers 3
    .param p1, "scale"    # F
    .param p2, "offset"    # I

    .line 291
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->scale:F

    iput p2, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->offset:I

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/model/UDim;FIILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/UDim;
    .registers 5

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_6

    iget p1, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->scale:F

    :cond_6
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_c

    iget p2, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->offset:I

    :cond_c
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/UDim;->copy(FI)Lcom/exampletest/mobilestudiotest/model/UDim;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->scale:F

    return v0
.end method

.method public final component2()I
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->offset:I

    return v0
.end method

.method public final copy(FI)Lcom/exampletest/mobilestudiotest/model/UDim;
    .registers 4

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-direct {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/UDim;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/UDim;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->scale:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/UDim;->scale:F

    invoke-static {v3, v4}, Ljava/lang/Float;->compare(FF)I

    move-result v3

    if-eqz v3, :cond_18

    return v2

    :cond_18
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->offset:I

    iget v1, v1, Lcom/exampletest/mobilestudiotest/model/UDim;->offset:I

    if-eq v3, v1, :cond_1f

    return v2

    :cond_1f
    return v0
.end method

.method public final getOffset()I
    .registers 2

    .line 291
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->offset:I

    return v0
.end method

.method public final getScale()F
    .registers 2

    .line 291
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->scale:F

    return v0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->scale:F

    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->offset:I

    invoke-static {v2}, Ljava/lang/Integer;->hashCode(I)I

    move-result v2

    add-int/2addr v1, v2

    return v1
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    .line 292
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->scale:F

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v0

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/UDim;->offset:I

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ", "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
