###### Class com.exampletest.mobilestudiotest.model.Color3 (com.exampletest.mobilestudiotest.model.Color3)
.class public final Lcom/exampletest/mobilestudiotest/model/Color3;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/model/Color3$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\t\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0014\n\u0002\u0008\u0006\n\u0002\u0010\u000b\n\u0002\u0008\u0004\u0008\u0086\u0008\u0018\u0000 \u001e2\u00020\u0001:\u0001\u001eB\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0006\u0010\u0007J\u0006\u0010\u000c\u001a\u00020\rJ\u0016\u0010\u000e\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0003J\u0006\u0010\u0011\u001a\u00020\u0012J\u0006\u0010\u0013\u001a\u00020\u0014J\u0008\u0010\u0015\u001a\u00020\u0012H\u0016J\t\u0010\u0016\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0017\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0018\u001a\u00020\u0003H\u00c6\u0003J\'\u0010\u0019\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0003H\u00c6\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\u0008\u0010\u001c\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u001d\u001a\u00020\rH\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0008\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\t\u00a8\u0006\u001f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/Color3;",
        "",
        "r",
        "",
        "g",
        "b",
        "<init>",
        "(FFF)V",
        "getR",
        "()F",
        "getG",
        "getB",
        "toArgb",
        "",
        "lerp",
        "o",
        "t",
        "toHex",
        "",
        "toHSV",
        "",
        "toString",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;


# instance fields
.field private final b:F

.field private final g:F

.field private final r:F


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    return-void
.end method

.method public constructor <init>(FFF)V
    .registers 4
    .param p1, "r"    # F
    .param p2, "g"    # F
    .param p3, "b"    # F

    .line 247
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    iput p2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    iput p3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/model/Color3;FFFILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget p1, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget p2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget p3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/model/Color3;->copy(FFF)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    return v0
.end method

.method public final component2()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    return v0
.end method

.method public final component3()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    return v0
.end method

.method public final copy(FFF)Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 5

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/Color3;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Color3;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    invoke-static {v3, v4}, Ljava/lang/Float;->compare(FF)I

    move-result v3

    if-eqz v3, :cond_18

    return v2

    :cond_18
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    invoke-static {v3, v4}, Ljava/lang/Float;->compare(FF)I

    move-result v3

    if-eqz v3, :cond_23

    return v2

    :cond_23
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    iget v1, v1, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_2e

    return v2

    :cond_2e
    return v0
.end method

.method public final getB()F
    .registers 2

    .line 247
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    return v0
.end method

.method public final getG()F
    .registers 2

    .line 247
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    return v0
.end method

.method public final getR()F
    .registers 2

    .line 247
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    return v0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    invoke-static {v2}, Ljava/lang/Float;->hashCode(F)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    invoke-static {v2}, Ljava/lang/Float;->hashCode(F)I

    move-result v2

    add-int/2addr v0, v2

    return v0
.end method

.method public final lerp(Lcom/exampletest/mobilestudiotest/model/Color3;F)Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 9
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Color3;
    .param p2, "t"    # F

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 249
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Color3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    iget v2, p1, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    sub-float/2addr v2, v3

    mul-float/2addr v2, p2

    add-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    sub-float/2addr v3, v4

    mul-float/2addr v3, p2

    add-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    iget v4, p1, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    sub-float/2addr v4, v5

    mul-float/2addr v4, p2

    add-float/2addr v3, v4

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    return-object v0
.end method

.method public final toArgb()I
    .registers 4

    .line 248
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v0

    shl-int/lit8 v0, v0, 0x10

    const/high16 v1, -0x1000000

    or-int/2addr v0, v1

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v1

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v1

    or-int/2addr v0, v1

    return v0
.end method

.method public final toHSV()[F
    .registers 10

    .line 252
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    .local v0, "mx":F
    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    .local v1, "mn":F
    sub-float v2, v0, v1

    .line 253
    .local v2, "d":F
    nop

    .line 254
    const/4 v3, 0x0

    cmpg-float v4, v2, v3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v4, :cond_28

    move v4, v5

    goto :goto_29

    :cond_28
    move v4, v6

    :goto_29
    const/high16 v7, 0x40c00000    # 6.0f

    if-eqz v4, :cond_2f

    move v4, v3

    goto :goto_60

    .line 255
    :cond_2f
    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    cmpg-float v4, v0, v4

    if-nez v4, :cond_37

    move v4, v5

    goto :goto_38

    :cond_37
    move v4, v6

    :goto_38
    if-eqz v4, :cond_42

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    sub-float/2addr v4, v8

    div-float/2addr v4, v2

    rem-float/2addr v4, v7

    goto :goto_60

    .line 256
    :cond_42
    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    cmpg-float v4, v0, v4

    if-nez v4, :cond_4a

    move v4, v5

    goto :goto_4b

    :cond_4a
    move v4, v6

    :goto_4b
    if-eqz v4, :cond_57

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    sub-float/2addr v4, v8

    div-float/2addr v4, v2

    const/high16 v8, 0x40000000    # 2.0f

    add-float/2addr v4, v8

    goto :goto_60

    .line 257
    :cond_57
    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    sub-float/2addr v4, v8

    div-float/2addr v4, v2

    const/high16 v8, 0x40800000    # 4.0f

    add-float/2addr v4, v8

    .line 258
    :goto_60
    nop

    .line 253
    div-float/2addr v4, v7

    .line 259
    .local v4, "h":F
    cmpg-float v7, v4, v3

    if-gez v7, :cond_69

    const/high16 v7, 0x3f800000    # 1.0f

    add-float/2addr v4, v7

    .line 260
    :cond_69
    cmpg-float v7, v0, v3

    if-nez v7, :cond_6f

    move v7, v5

    goto :goto_70

    :cond_6f
    move v7, v6

    :goto_70
    if-nez v7, :cond_74

    div-float v3, v2, v0

    :cond_74
    const/4 v7, 0x3

    new-array v7, v7, [F

    aput v4, v7, v6

    aput v3, v7, v5

    const/4 v3, 0x2

    aput v0, v7, v3

    return-object v7
.end method

.method public final toHex()Ljava/lang/String;
    .registers 5

    .line 250
    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    invoke-static {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v0, v1, v2}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x3

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%02X%02X%02X"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 5

    .line 262
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->r:F

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->g:F

    invoke-static {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/Color3;->b:F

    invoke-static {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, ", "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.model.Color3.Companion (com.exampletest.mobilestudiotest.model.Color3$Companion)
.class public final Lcom/exampletest/mobilestudiotest/model/Color3$Companion;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/model/Color3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDataTypes.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DataTypes.kt\ncom/exampletest/mobilestudiotest/model/Color3$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,423:1\n1#2:424\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u000e\n\u0002\u0008\u0004\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0002J\u001e\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u00052\u0006\u0010\u000c\u001a\u00020\u0005J\u000e\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u0005J\u0010\u0010\u000f\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0010\u001a\u00020\u0011J\u001e\u0010\u0012\u001a\u00020\t2\u0006\u0010\u0010\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0007\u00a8\u0006\u0015"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/Color3$Companion;",
        "",
        "<init>",
        "()V",
        "c8",
        "",
        "f",
        "",
        "fromRGB",
        "Lcom/exampletest/mobilestudiotest/model/Color3;",
        "r",
        "g",
        "b",
        "fromArgb",
        "c",
        "fromHex",
        "h",
        "",
        "fromHSV",
        "s",
        "v",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 264
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;-><init>()V

    return-void
.end method

.method public static final synthetic access$c8(Lcom/exampletest/mobilestudiotest/model/Color3$Companion;F)I
    .registers 3
    .param p0, "$this"    # Lcom/exampletest/mobilestudiotest/model/Color3$Companion;
    .param p1, "f"    # F

    .line 264
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->c8(F)I

    move-result v0

    return v0
.end method

.method private final c8(F)I
    .registers 4
    .param p1, "f"    # F

    .line 265
    const/4 v0, 0x0

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {p1, v0, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    const/high16 v1, 0x437f0000    # 255.0f

    mul-float/2addr v0, v1

    invoke-static {v0}, Lkotlin/math/MathKt;->roundToInt(F)I

    move-result v0

    return v0
.end method


# virtual methods
.method public final fromArgb(I)Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 5
    .param p1, "c"    # I

    .line 267
    shr-int/lit8 v0, p1, 0x10

    and-int/lit16 v0, v0, 0xff

    shr-int/lit8 v1, p1, 0x8

    and-int/lit16 v1, v1, 0xff

    and-int/lit16 v2, p1, 0xff

    invoke-virtual {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v0

    return-object v0
.end method

.method public final fromHSV(FFF)Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 10
    .param p1, "h"    # F
    .param p2, "s"    # F
    .param p3, "v"    # F

    .line 274
    const/high16 v0, 0x40c00000    # 6.0f

    mul-float v1, p1, v0

    float-to-int v1, v1

    .line 275
    .local v1, "i":I
    mul-float/2addr v0, p1

    int-to-float v2, v1

    sub-float/2addr v0, v2

    .line 276
    .local v0, "f":F
    const/high16 v2, 0x3f800000    # 1.0f

    sub-float v3, v2, p2

    mul-float/2addr v3, p3

    .local v3, "p":F
    mul-float v4, v0, p2

    sub-float v4, v2, v4

    mul-float/2addr v4, p3

    .local v4, "q":F
    sub-float v5, v2, v0

    mul-float/2addr v5, p2

    sub-float/2addr v2, v5

    mul-float/2addr v2, p3

    .line 277
    .local v2, "t":F
    rem-int/lit8 v5, v1, 0x6

    add-int/lit8 v5, v5, 0x6

    rem-int/lit8 v5, v5, 0x6

    packed-switch v5, :pswitch_data_44

    .line 279
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v5, p3, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    goto :goto_43

    :pswitch_26
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v5, v2, v3, p3}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    goto :goto_43

    :pswitch_2c
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v5, v3, v4, p3}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    goto :goto_43

    .line 278
    :pswitch_32
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v5, v3, p3, v2}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    goto :goto_43

    :pswitch_38
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v5, v4, p3, v3}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    goto :goto_43

    :pswitch_3e
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-direct {v5, p3, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    .line 277
    :goto_43
    return-object v5

    :pswitch_data_44
    .packed-switch 0x0
        :pswitch_3e
        :pswitch_38
        :pswitch_32
        :pswitch_2c
        :pswitch_26
    .end packed-switch
.end method

.method public final fromHex(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 6
    .param p1, "h"    # Ljava/lang/String;

    const-string v0, "h"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 269
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "#"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v0, v1}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 270
    .local v0, "s":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eq v1, v2, :cond_21

    return-object v3

    .line 271
    :cond_21
    const/16 v1, 0x10

    invoke-static {v0, v1}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;I)Ljava/lang/Integer;

    move-result-object v1

    if-eqz v1, :cond_36

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    .line 424
    .local v1, "it\\1":I
    const/4 v2, 0x0

    .line 271
    .local v2, "$i$a$-let-Color3$Companion$fromHex$1\\1\\271\\0":I
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromArgb(I)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v3

    .end local v1    # "it\\1":I
    .end local v2    # "$i$a$-let-Color3$Companion$fromHex$1\\1\\271\\0":I
    :cond_36
    return-object v3
.end method

.method public final fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 9
    .param p1, "r"    # I
    .param p2, "g"    # I
    .param p3, "b"    # I

    .line 266
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Color3;

    int-to-float v1, p1

    const/high16 v2, 0x437f0000    # 255.0f

    div-float/2addr v1, v2

    int-to-float v3, p2

    div-float/2addr v3, v2

    int-to-float v4, p3

    div-float/2addr v4, v2

    invoke-direct {v0, v1, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    return-object v0
.end method
