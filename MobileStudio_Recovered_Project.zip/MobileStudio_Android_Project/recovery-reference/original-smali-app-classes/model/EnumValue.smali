###### Class com.exampletest.mobilestudiotest.model.EnumValue (com.exampletest.mobilestudiotest.model.EnumValue)
.class public final Lcom/exampletest/mobilestudiotest/model/EnumValue;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0003\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0008\u0010\u0008\u001a\u00020\tH\u0016J\t\u0010\n\u001a\u00020\u0003H\u00c6\u0003J\u0013\u0010\u000b\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003H\u00c6\u0001J\u0013\u0010\u000c\u001a\u00020\r2\u0008\u0010\u000e\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u000f\u001a\u00020\u0003H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/EnumValue;",
        "",
        "value",
        "",
        "<init>",
        "(I)V",
        "getValue",
        "()I",
        "toString",
        "",
        "component1",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final value:I


# direct methods
.method public constructor <init>(I)V
    .registers 2
    .param p1, "value"    # I

    .line 318
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/EnumValue;->value:I

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/model/EnumValue;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/EnumValue;
    .registers 4

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    iget p1, p0, Lcom/exampletest/mobilestudiotest/model/EnumValue;->value:I

    :cond_6
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/model/EnumValue;->copy(I)Lcom/exampletest/mobilestudiotest/model/EnumValue;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()I
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/EnumValue;->value:I

    return v0
.end method

.method public final copy(I)Lcom/exampletest/mobilestudiotest/model/EnumValue;
    .registers 3

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-direct {v0, p1}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/EnumValue;->value:I

    iget v1, v1, Lcom/exampletest/mobilestudiotest/model/EnumValue;->value:I

    if-eq v3, v1, :cond_14

    return v2

    :cond_14
    return v0
.end method

.method public final getValue()I
    .registers 2

    .line 318
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/EnumValue;->value:I

    return v0
.end method

.method public hashCode()I
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/EnumValue;->value:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 319
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/EnumValue;->value:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
