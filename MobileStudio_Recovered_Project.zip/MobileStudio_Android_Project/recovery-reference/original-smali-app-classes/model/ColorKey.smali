###### Class com.exampletest.mobilestudiotest.model.ColorKey (com.exampletest.mobilestudiotest.model.ColorKey)
.class public final Lcom/exampletest/mobilestudiotest/model/ColorKey;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\r\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0000\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\t\u0010\u000e\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u000f\u001a\u00020\u0005H\u00c6\u0003J\t\u0010\u0010\u001a\u00020\u0003H\u00c6\u0003J\'\u0010\u0011\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00052\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0003H\u00c6\u0001J\u0013\u0010\u0012\u001a\u00020\u00132\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0015\u001a\u00020\u0016H\u00d6\u0001J\t\u0010\u0017\u001a\u00020\u0018H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\n\u00a8\u0006\u0019"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/ColorKey;",
        "",
        "time",
        "",
        "color",
        "Lcom/exampletest/mobilestudiotest/model/Color3;",
        "envelope",
        "<init>",
        "(FLcom/exampletest/mobilestudiotest/model/Color3;F)V",
        "getTime",
        "()F",
        "getColor",
        "()Lcom/exampletest/mobilestudiotest/model/Color3;",
        "getEnvelope",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final color:Lcom/exampletest/mobilestudiotest/model/Color3;

.field private final envelope:F

.field private final time:F


# direct methods
.method public constructor <init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V
    .registers 5
    .param p1, "time"    # F
    .param p2, "color"    # Lcom/exampletest/mobilestudiotest/model/Color3;
    .param p3, "envelope"    # F

    const-string v0, "color"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 331
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->time:F

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->color:Lcom/exampletest/mobilestudiotest/model/Color3;

    iput p3, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->envelope:F

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/model/ColorKey;FLcom/exampletest/mobilestudiotest/model/Color3;FILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/ColorKey;
    .registers 6

    and-int/lit8 p5, p4, 0x1

    if-eqz p5, :cond_6

    iget p1, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->time:F

    :cond_6
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_c

    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->color:Lcom/exampletest/mobilestudiotest/model/Color3;

    :cond_c
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_12

    iget p3, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->envelope:F

    :cond_12
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/model/ColorKey;->copy(FLcom/exampletest/mobilestudiotest/model/Color3;F)Lcom/exampletest/mobilestudiotest/model/ColorKey;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->time:F

    return v0
.end method

.method public final component2()Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 2

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->color:Lcom/exampletest/mobilestudiotest/model/Color3;

    return-object v0
.end method

.method public final component3()F
    .registers 2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->envelope:F

    return v0
.end method

.method public final copy(FLcom/exampletest/mobilestudiotest/model/Color3;F)Lcom/exampletest/mobilestudiotest/model/ColorKey;
    .registers 5

    const-string v0, "color"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    invoke-direct {v0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->time:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;->time:F

    invoke-static {v3, v4}, Ljava/lang/Float;->compare(FF)I

    move-result v3

    if-eqz v3, :cond_18

    return v2

    :cond_18
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->color:Lcom/exampletest/mobilestudiotest/model/Color3;

    iget-object v4, v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;->color:Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_23

    return v2

    :cond_23
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->envelope:F

    iget v1, v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;->envelope:F

    invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_2e

    return v2

    :cond_2e
    return v0
.end method

.method public final getColor()Lcom/exampletest/mobilestudiotest/model/Color3;
    .registers 2

    .line 331
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->color:Lcom/exampletest/mobilestudiotest/model/Color3;

    return-object v0
.end method

.method public final getEnvelope()F
    .registers 2

    .line 331
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->envelope:F

    return v0
.end method

.method public final getTime()F
    .registers 2

    .line 331
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->time:F

    return v0
.end method

.method public hashCode()I
    .registers 4

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->time:F

    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->color:Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Color3;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->envelope:F

    invoke-static {v2}, Ljava/lang/Float;->hashCode(F)I

    move-result v2

    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 6

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->time:F

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->color:Lcom/exampletest/mobilestudiotest/model/Color3;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/ColorKey;->envelope:F

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "ColorKey(time="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, ", color="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", envelope="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
