###### Class com.exampletest.mobilestudiotest.model.OptionalCFrame (com.exampletest.mobilestudiotest.model.OptionalCFrame)
.class public final Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u0011\u0012\u0008\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0008\u0010\u0008\u001a\u00020\tH\u0016J\u000b\u0010\n\u001a\u0004\u0018\u00010\u0003H\u00c6\u0003J\u0015\u0010\u000b\u001a\u00020\u00002\n\u0008\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003H\u00c6\u0001J\u0013\u0010\u000c\u001a\u00020\r2\u0008\u0010\u000e\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u000f\u001a\u00020\u0010H\u00d6\u0001R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\u00a8\u0006\u0011"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;",
        "",
        "cframe",
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/model/CFrame;)V",
        "getCframe",
        "()Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "toString",
        "",
        "component1",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/model/CFrame;)V
    .registers 2
    .param p1, "cframe"    # Lcom/exampletest/mobilestudiotest/model/CFrame;

    .line 361
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;Lcom/exampletest/mobilestudiotest/model/CFrame;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;
    .registers 4

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    iget-object p1, p0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    :cond_6
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->copy(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 2

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    return-object v0
.end method

.method public final copy(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;
    .registers 3

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    invoke-direct {v0, p1}, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;-><init>(Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    iget-object v1, v1, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_18

    return v2

    :cond_18
    return v0
.end method

.method public final getCframe()Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 2

    .line 361
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    return-object v0
.end method

.method public hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_c

    :cond_6
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->hashCode()I

    move-result v0

    :goto_c
    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 362
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->cframe:Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toString()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_b

    goto :goto_d

    :cond_b
    const-string v0, "nil"

    :goto_d
    return-object v0
.end method
