###### Class com.exampletest.mobilestudiotest.model.SecurityCaps (com.exampletest.mobilestudiotest.model.SecurityCaps)
.class public final Lcom/exampletest/mobilestudiotest/model/SecurityCaps;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0007\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0000\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\t\u0010\u0008\u001a\u00020\u0003H\u00c6\u0003J\u0013\u0010\t\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u0003H\u00c6\u0001J\u0013\u0010\n\u001a\u00020\u000b2\u0008\u0010\u000c\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\r\u001a\u00020\u000eH\u00d6\u0001J\t\u0010\u000f\u001a\u00020\u0010H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\u00a8\u0006\u0011"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/SecurityCaps;",
        "",
        "value",
        "",
        "<init>",
        "(J)V",
        "getValue",
        "()J",
        "component1",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final value:J


# direct methods
.method public constructor <init>(J)V
    .registers 3
    .param p1, "value"    # J

    .line 375
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->value:J

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/model/SecurityCaps;JILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/SecurityCaps;
    .registers 5

    and-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_6

    iget-wide p1, p0, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->value:J

    :cond_6
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->copy(J)Lcom/exampletest/mobilestudiotest/model/SecurityCaps;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()J
    .registers 3

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->value:J

    return-wide v0
.end method

.method public final copy(J)Lcom/exampletest/mobilestudiotest/model/SecurityCaps;
    .registers 4

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;

    invoke-direct {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;-><init>(J)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;

    iget-wide v3, p0, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->value:J

    iget-wide v5, v1, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->value:J

    cmp-long v1, v3, v5

    if-eqz v1, :cond_16

    return v2

    :cond_16
    return v0
.end method

.method public final getValue()J
    .registers 3

    .line 375
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->value:J

    return-wide v0
.end method

.method public hashCode()I
    .registers 3

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->value:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 5

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/model/SecurityCaps;->value:J

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "SecurityCaps(value="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
