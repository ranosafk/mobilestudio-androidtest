###### Class com.exampletest.mobilestudiotest.model.CFrame (com.exampletest.mobilestudiotest.model.CFrame)
.class public final Lcom/exampletest/mobilestudiotest/model/CFrame;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u001b\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u0008\n\u0002\u0008\u0010\n\u0002\u0010\u0014\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0002\u0018\u0000 H2\u00020\u0001:\u0001HBy\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\t\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\n\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u000b\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u000c\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\r\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u000e\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u000f\u0010\u0010J\u000e\u0010*\u001a\u00020\u001f2\u0006\u0010+\u001a\u00020,J\u0011\u0010-\u001a\u00020\u00002\u0006\u0010.\u001a\u00020\u0000H\u0086\u0002J\u0011\u0010-\u001a\u00020\u001f2\u0006\u0010/\u001a\u00020\u001fH\u0086\u0002J\u0011\u00100\u001a\u00020\u00002\u0006\u0010/\u001a\u00020\u001fH\u0086\u0002J\u0011\u00101\u001a\u00020\u00002\u0006\u0010/\u001a\u00020\u001fH\u0086\u0002J\u000e\u00102\u001a\u00020\u001f2\u0006\u0010/\u001a\u00020\u001fJ\u000e\u00103\u001a\u00020\u001f2\u0006\u0010/\u001a\u00020\u001fJ\u000e\u00104\u001a\u00020\u001f2\u0006\u0010/\u001a\u00020\u001fJ\u000e\u00105\u001a\u00020\u001f2\u0006\u0010/\u001a\u00020\u001fJ\u0006\u00106\u001a\u00020\u0000J\u0006\u00107\u001a\u00020\u0000J\u000e\u00108\u001a\u00020\u00002\u0006\u00109\u001a\u00020\u001fJ\u0006\u0010:\u001a\u00020\u001fJ\u0006\u0010;\u001a\u00020\u001fJ\u0006\u0010<\u001a\u00020=J\u0016\u0010>\u001a\u00020\u00002\u0006\u0010.\u001a\u00020\u00002\u0006\u0010?\u001a\u00020\u0003J\u0006\u0010@\u001a\u00020\u0000J\u0006\u0010A\u001a\u00020=J\u0013\u0010B\u001a\u00020C2\u0008\u0010D\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\u0008\u0010E\u001a\u00020,H\u0016J\u0008\u0010F\u001a\u00020GH\u0016R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0012R\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0015\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0012R\u0011\u0010\u0008\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0017\u0010\u0012R\u0011\u0010\t\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0018\u0010\u0012R\u0011\u0010\n\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0019\u0010\u0012R\u0011\u0010\u000b\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001a\u0010\u0012R\u0011\u0010\u000c\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001b\u0010\u0012R\u0011\u0010\r\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001c\u0010\u0012R\u0011\u0010\u000e\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u0012R\u0011\u0010\u001e\u001a\u00020\u001f8F\u00a2\u0006\u0006\u001a\u0004\u0008 \u0010!R\u0011\u0010\"\u001a\u00020\u001f8F\u00a2\u0006\u0006\u001a\u0004\u0008#\u0010!R\u0011\u0010$\u001a\u00020\u001f8F\u00a2\u0006\u0006\u001a\u0004\u0008%\u0010!R\u0011\u0010&\u001a\u00020\u001f8F\u00a2\u0006\u0006\u001a\u0004\u0008\'\u0010!R\u0011\u0010(\u001a\u00020\u001f8F\u00a2\u0006\u0006\u001a\u0004\u0008)\u0010!\u00a8\u0006I"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "",
        "x",
        "",
        "y",
        "z",
        "r00",
        "r01",
        "r02",
        "r10",
        "r11",
        "r12",
        "r20",
        "r21",
        "r22",
        "<init>",
        "(FFFFFFFFFFFF)V",
        "getX",
        "()F",
        "getY",
        "getZ",
        "getR00",
        "getR01",
        "getR02",
        "getR10",
        "getR11",
        "getR12",
        "getR20",
        "getR21",
        "getR22",
        "position",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "getPosition",
        "()Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "rightVector",
        "getRightVector",
        "upVector",
        "getUpVector",
        "backVector",
        "getBackVector",
        "lookVector",
        "getLookVector",
        "column",
        "i",
        "",
        "times",
        "o",
        "v",
        "plus",
        "minus",
        "vectorToWorld",
        "vectorToObject",
        "pointToObject",
        "pointToWorld",
        "inverse",
        "rotationOnly",
        "withPosition",
        "p",
        "toEulerXYZ",
        "toOrientation",
        "toQuaternion",
        "",
        "lerp",
        "t",
        "orthonormalize",
        "components",
        "equals",
        "",
        "other",
        "hashCode",
        "toString",
        "",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

.field private static final IDENTITY:Lcom/exampletest/mobilestudiotest/model/CFrame;


# instance fields
.field private final r00:F

.field private final r01:F

.field private final r02:F

.field private final r10:F

.field private final r11:F

.field private final r12:F

.field private final r20:F

.field private final r21:F

.field private final r22:F

.field private final x:F

.field private final y:F

.field private final z:F


# direct methods
.method static constructor <clinit>()V
    .registers 17

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    .line 206
    new-instance v2, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const/16 v15, 0xff8

    const/16 v16, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-direct/range {v2 .. v16}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v2, Lcom/exampletest/mobilestudiotest/model/CFrame;->IDENTITY:Lcom/exampletest/mobilestudiotest/model/CFrame;

    return-void
.end method

.method public constructor <init>(FFFFFFFFFFFF)V
    .registers 13
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "r00"    # F
    .param p5, "r01"    # F
    .param p6, "r02"    # F
    .param p7, "r10"    # F
    .param p8, "r11"    # F
    .param p9, "r12"    # F
    .param p10, "r20"    # F
    .param p11, "r21"    # F
    .param p12, "r22"    # F

    .line 71
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 72
    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->x:F

    iput p2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->y:F

    iput p3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->z:F

    .line 73
    iput p4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iput p5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iput p6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    .line 74
    iput p7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iput p8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iput p9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    .line 75
    iput p10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iput p11, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iput p12, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    .line 71
    return-void
.end method

.method public synthetic constructor <init>(FFFFFFFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 31

    .line 71
    move/from16 v0, p13

    and-int/lit8 v1, v0, 0x8

    const/high16 v2, 0x3f800000    # 1.0f

    if-eqz v1, :cond_a

    .line 73
    move v7, v2

    goto :goto_c

    .line 71
    :cond_a
    move/from16 v7, p4

    :goto_c
    and-int/lit8 v1, v0, 0x10

    const/4 v3, 0x0

    if-eqz v1, :cond_13

    .line 73
    move v8, v3

    goto :goto_15

    .line 71
    :cond_13
    move/from16 v8, p5

    :goto_15
    and-int/lit8 v1, v0, 0x20

    if-eqz v1, :cond_1b

    .line 73
    move v9, v3

    goto :goto_1d

    .line 71
    :cond_1b
    move/from16 v9, p6

    :goto_1d
    and-int/lit8 v1, v0, 0x40

    if-eqz v1, :cond_23

    .line 74
    move v10, v3

    goto :goto_25

    .line 71
    :cond_23
    move/from16 v10, p7

    :goto_25
    and-int/lit16 v1, v0, 0x80

    if-eqz v1, :cond_2b

    .line 74
    move v11, v2

    goto :goto_2d

    .line 71
    :cond_2b
    move/from16 v11, p8

    :goto_2d
    and-int/lit16 v1, v0, 0x100

    if-eqz v1, :cond_33

    .line 74
    move v12, v3

    goto :goto_35

    .line 71
    :cond_33
    move/from16 v12, p9

    :goto_35
    and-int/lit16 v1, v0, 0x200

    if-eqz v1, :cond_3b

    .line 75
    move v13, v3

    goto :goto_3d

    .line 71
    :cond_3b
    move/from16 v13, p10

    :goto_3d
    and-int/lit16 v1, v0, 0x400

    if-eqz v1, :cond_43

    .line 75
    move v14, v3

    goto :goto_45

    .line 71
    :cond_43
    move/from16 v14, p11

    :goto_45
    and-int/lit16 v0, v0, 0x800

    if-eqz v0, :cond_4b

    .line 75
    move v15, v2

    goto :goto_4d

    .line 71
    :cond_4b
    move/from16 v15, p12

    :goto_4d
    move-object/from16 v3, p0

    move/from16 v4, p1

    move/from16 v5, p2

    move/from16 v6, p3

    invoke-direct/range {v3 .. v15}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    .line 76
    return-void
.end method

.method public static final synthetic access$getIDENTITY$cp()Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 1

    .line 71
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->IDENTITY:Lcom/exampletest/mobilestudiotest/model/CFrame;

    return-object v0
.end method

.method static final toString$lambda$0(F)Ljava/lang/CharSequence;
    .registers 2
    .param p0, "it"    # F

    .line 203
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/model/DataTypesKt;->fmtNum(F)Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method


# virtual methods
.method public final column(I)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 3
    .param p1, "i"    # I

    .line 83
    packed-switch p1, :pswitch_data_12

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getBackVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    goto :goto_11

    :pswitch_8
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getUpVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    goto :goto_11

    :pswitch_d
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getRightVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    :goto_11
    return-object v0

    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_d
        :pswitch_8
    .end packed-switch
.end method

.method public final components()[F
    .registers 15

    .line 199
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->x:F

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->y:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->z:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v11, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    const/16 v12, 0xc

    new-array v12, v12, [F

    const/4 v13, 0x0

    aput v0, v12, v13

    const/4 v0, 0x1

    aput v1, v12, v0

    const/4 v0, 0x2

    aput v2, v12, v0

    const/4 v0, 0x3

    aput v3, v12, v0

    const/4 v0, 0x4

    aput v4, v12, v0

    const/4 v0, 0x5

    aput v5, v12, v0

    const/4 v0, 0x6

    aput v6, v12, v0

    const/4 v0, 0x7

    aput v7, v12, v0

    const/16 v0, 0x8

    aput v8, v12, v0

    const/16 v0, 0x9

    aput v9, v12, v0

    const/16 v0, 0xa

    aput v10, v12, v0

    const/16 v0, 0xb

    aput v11, v12, v0

    return-object v12
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 4
    .param p1, "other"    # Ljava/lang/Object;

    .line 201
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v0, :cond_17

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->components()[F

    move-result-object v0

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->components()[F

    move-result-object v1

    invoke-static {v0, v1}, Ljava/util/Arrays;->equals([F[F)Z

    move-result v0

    if-eqz v0, :cond_17

    const/4 v0, 0x1

    goto :goto_18

    :cond_17
    const/4 v0, 0x0

    :goto_18
    return v0
.end method

.method public final getBackVector()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 5

    .line 80
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final getLookVector()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 5

    .line 81
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    neg-float v1, v1

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    neg-float v2, v2

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    neg-float v3, v3

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 5

    .line 77
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->x:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->y:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->z:F

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final getR00()F
    .registers 2

    .line 73
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    return v0
.end method

.method public final getR01()F
    .registers 2

    .line 73
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    return v0
.end method

.method public final getR02()F
    .registers 2

    .line 73
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    return v0
.end method

.method public final getR10()F
    .registers 2

    .line 74
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    return v0
.end method

.method public final getR11()F
    .registers 2

    .line 74
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    return v0
.end method

.method public final getR12()F
    .registers 2

    .line 74
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    return v0
.end method

.method public final getR20()F
    .registers 2

    .line 75
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    return v0
.end method

.method public final getR21()F
    .registers 2

    .line 75
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    return v0
.end method

.method public final getR22()F
    .registers 2

    .line 75
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    return v0
.end method

.method public final getRightVector()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 5

    .line 78
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final getUpVector()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 5

    .line 79
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v0
.end method

.method public final getX()F
    .registers 2

    .line 72
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->x:F

    return v0
.end method

.method public final getY()F
    .registers 2

    .line 72
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->y:F

    return v0
.end method

.method public final getZ()F
    .registers 2

    .line 72
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->z:F

    return v0
.end method

.method public hashCode()I
    .registers 2

    .line 202
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->components()[F

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([F)I

    move-result v0

    return v0
.end method

.method public final inverse()Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 15

    .line 119
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->vectorToObject(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .line 120
    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v11, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v12, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v13, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    invoke-direct/range {v1 .. v13}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v1
.end method

.method public final lerp(Lcom/exampletest/mobilestudiotest/model/CFrame;F)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 21
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/CFrame;
    .param p2, "t"    # F

    move/from16 v0, p2

    const-string v1, "o"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 176
    invoke-virtual/range {p0 .. p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toQuaternion()[F

    move-result-object v1

    .local v1, "a":[F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toQuaternion()[F

    move-result-object v3

    .line 177
    .local v3, "b":[F
    const/4 v4, 0x0

    aget v5, v1, v4

    aget v6, v3, v4

    mul-float/2addr v5, v6

    const/4 v6, 0x1

    aget v7, v1, v6

    aget v8, v3, v6

    mul-float/2addr v7, v8

    add-float/2addr v5, v7

    const/4 v7, 0x2

    aget v8, v1, v7

    aget v9, v3, v7

    mul-float/2addr v8, v9

    add-float/2addr v5, v8

    const/4 v8, 0x3

    aget v9, v1, v8

    aget v10, v3, v8

    mul-float/2addr v9, v10

    add-float/2addr v5, v9

    .line 178
    .local v5, "d":F
    const/4 v9, 0x0

    cmpg-float v9, v5, v9

    const/4 v10, 0x4

    if-gez v9, :cond_3e

    const/4 v9, 0x0

    .local v9, "i":I
    :goto_33
    if-ge v9, v10, :cond_3d

    aget v11, v3, v9

    neg-float v11, v11

    aput v11, v3, v9

    add-int/lit8 v9, v9, 0x1

    goto :goto_33

    .end local v9    # "i":I
    :cond_3d
    neg-float v5, v5

    .line 179
    :cond_3e
    new-array v9, v10, [F

    .line 180
    .local v9, "q":[F
    const v11, 0x3f7fdf3b    # 0.9995f

    cmpl-float v11, v5, v11

    if-lez v11, :cond_58

    .line 181
    const/4 v11, 0x0

    .local v11, "i":I
    :goto_48
    if-ge v11, v10, :cond_90

    aget v12, v1, v11

    aget v13, v3, v11

    aget v14, v1, v11

    sub-float/2addr v13, v14

    mul-float/2addr v13, v0

    add-float/2addr v12, v13

    aput v12, v9, v11

    add-int/lit8 v11, v11, 0x1

    goto :goto_48

    .line 183
    .end local v11    # "i":I
    :cond_58
    const/high16 v11, -0x40800000    # -1.0f

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-static {v5, v11, v12}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v11

    float-to-double v13, v11

    invoke-static {v13, v14}, Ljava/lang/Math;->acos(D)D

    move-result-wide v13

    double-to-float v11, v13

    .local v11, "th":F
    float-to-double v13, v11

    invoke-static {v13, v14}, Ljava/lang/Math;->sin(D)D

    move-result-wide v13

    double-to-float v13, v13

    .line 184
    .local v13, "s":F
    sub-float/2addr v12, v0

    mul-float/2addr v12, v11

    float-to-double v14, v12

    invoke-static {v14, v15}, Ljava/lang/Math;->sin(D)D

    move-result-wide v14

    double-to-float v12, v14

    div-float/2addr v12, v13

    .local v12, "wa":F
    mul-float v14, v0, v11

    float-to-double v14, v14

    invoke-static {v14, v15}, Ljava/lang/Math;->sin(D)D

    move-result-wide v14

    double-to-float v14, v14

    div-float/2addr v14, v13

    .line 185
    .local v14, "wb":F
    const/4 v15, 0x0

    .local v15, "i":I
    :goto_7f
    if-ge v15, v10, :cond_90

    aget v16, v1, v15

    mul-float v16, v16, v12

    aget v17, v3, v15

    mul-float v17, v17, v14

    add-float v16, v16, v17

    aput v16, v9, v15

    add-int/lit8 v15, v15, 0x1

    goto :goto_7f

    .line 187
    .end local v11    # "th":F
    .end local v12    # "wa":F
    .end local v13    # "s":F
    .end local v14    # "wb":F
    .end local v15    # "i":I
    :cond_90
    invoke-virtual/range {p0 .. p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-virtual {v10, v11, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->lerp(Lcom/exampletest/mobilestudiotest/model/Vector3;F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v13

    .line 188
    .local v13, "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v12, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    aget v14, v9, v4

    aget v15, v9, v6

    aget v16, v9, v7

    aget v17, v9, v8

    invoke-virtual/range {v12 .. v17}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromQuaternion(Lcom/exampletest/mobilestudiotest/model/Vector3;FFFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    return-object v4
.end method

.method public final minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 16
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->x:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    sub-float v2, v0, v2

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->y:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    sub-float v3, v0, v3

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->z:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    sub-float v4, v0, v4

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v11, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v12, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v13, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    invoke-direct/range {v1 .. v13}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v1
.end method

.method public final orthonormalize()Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 6

    .line 192
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getRightVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .line 193
    .local v0, "r":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getUpVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .line 194
    .local v1, "u":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .line 195
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->cross(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    .line 196
    .local v2, "b":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v3, v4, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromColumns(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    return-object v3
.end method

.method public final plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 16
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->x:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    add-float/2addr v2, v0

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->y:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    add-float/2addr v3, v0

    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->z:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    add-float/2addr v4, v0

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v11, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v12, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v13, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    invoke-direct/range {v1 .. v13}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v1
.end method

.method public final pointToObject(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 3
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 115
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->vectorToObject(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0
.end method

.method public final pointToWorld(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 3
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0
.end method

.method public final rotationOnly()Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 14

    .line 123
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/CFrame;

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v11, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v12, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct/range {v0 .. v12}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v0
.end method

.method public final times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 19
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "o"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    mul-float/2addr v3, v4

    add-float v8, v2, v3

    .line 87
    .local v8, "n00":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    mul-float/2addr v3, v4

    add-float v9, v2, v3

    .line 88
    .local v9, "n01":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    mul-float/2addr v3, v4

    add-float v10, v2, v3

    .line 89
    .local v10, "n02":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    mul-float/2addr v3, v4

    add-float v11, v2, v3

    .line 90
    .local v11, "n10":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    mul-float/2addr v3, v4

    add-float v12, v2, v3

    .line 91
    .local v12, "n11":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    mul-float/2addr v3, v4

    add-float v13, v2, v3

    .line 92
    .local v13, "n12":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    mul-float/2addr v3, v4

    add-float v14, v2, v3

    .line 93
    .local v14, "n20":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    mul-float/2addr v3, v4

    add-float v15, v2, v3

    .line 94
    .local v15, "n21":F
    iget v2, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    mul-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    iget v4, v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    mul-float/2addr v3, v4

    add-float v16, v2, v3

    .line 95
    .local v16, "n22":F
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    .line 96
    .local v2, "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v6

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v7

    invoke-direct/range {v4 .. v16}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v4
.end method

.method public final times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 4
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->vectorToWorld(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0
.end method

.method public final toEulerXYZ()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 8

    .line 128
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    const/high16 v1, -0x40800000    # -1.0f

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->asin(D)D

    move-result-wide v0

    double-to-float v0, v0

    .line 129
    .local v0, "ry":F
    const/4 v1, 0x0

    .line 130
    .local v1, "rx":F
    const/4 v2, 0x0

    .line 131
    .local v2, "rz":F
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    const v4, 0x3f7fff58    # 0.99999f

    cmpg-float v3, v3, v4

    if-gez v3, :cond_38

    .line 132
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    neg-float v3, v3

    float-to-double v3, v3

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    float-to-double v5, v5

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v3

    double-to-float v1, v3

    .line 133
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    neg-float v3, v3

    float-to-double v3, v3

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    float-to-double v5, v5

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v3

    double-to-float v2, v3

    goto :goto_44

    .line 135
    :cond_38
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    float-to-double v3, v3

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    float-to-double v5, v5

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v3

    double-to-float v1, v3

    .line 136
    const/4 v2, 0x0

    .line 138
    :goto_44
    new-instance v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v3, v1, v0, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v3
.end method

.method public final toOrientation()Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 8

    .line 143
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    neg-float v0, v0

    const/high16 v1, -0x40800000    # -1.0f

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->asin(D)D

    move-result-wide v0

    double-to-float v0, v0

    .line 144
    .local v0, "rx":F
    const/4 v1, 0x0

    .line 145
    .local v1, "ry":F
    const/4 v2, 0x0

    .line 146
    .local v2, "rz":F
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    const v4, 0x3f7fff58    # 0.99999f

    cmpg-float v3, v3, v4

    if-gez v3, :cond_37

    .line 147
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    float-to-double v3, v3

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    float-to-double v5, v5

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v3

    double-to-float v1, v3

    .line 148
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    float-to-double v3, v3

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    float-to-double v5, v5

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v3

    double-to-float v2, v3

    goto :goto_44

    .line 150
    :cond_37
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    neg-float v3, v3

    float-to-double v3, v3

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    float-to-double v5, v5

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->atan2(DD)D

    move-result-wide v3

    double-to-float v1, v3

    .line 151
    const/4 v2, 0x0

    .line 153
    :goto_44
    new-instance v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-direct {v3, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    return-object v3
.end method

.method public final toQuaternion()[F
    .registers 12

    .line 157
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    add-float/2addr v0, v1

    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    add-float/2addr v0, v1

    .line 158
    .local v0, "trace":F
    const/4 v1, 0x4

    new-array v1, v1, [F

    .line 159
    .local v1, "q":[F
    const/4 v2, 0x0

    cmpl-float v2, v0, v2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/high16 v6, 0x3e800000    # 0.25f

    const/4 v7, 0x3

    const/high16 v8, 0x40000000    # 2.0f

    const/high16 v9, 0x3f800000    # 1.0f

    if-lez v2, :cond_3f

    .line 160
    add-float/2addr v9, v0

    float-to-double v9, v9

    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v9

    double-to-float v2, v9

    mul-float/2addr v2, v8

    .line 161
    .local v2, "s":F
    mul-float/2addr v6, v2

    aput v6, v1, v7

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    sub-float/2addr v6, v7

    div-float/2addr v6, v2

    aput v6, v1, v5

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    sub-float/2addr v5, v6

    div-float/2addr v5, v2

    aput v5, v1, v4

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    sub-float/2addr v4, v5

    div-float/2addr v4, v2

    aput v4, v1, v3

    .end local v2    # "s":F
    goto/16 :goto_da

    .line 162
    :cond_3f
    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    cmpl-float v2, v2, v10

    if-lez v2, :cond_7b

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    cmpl-float v2, v2, v10

    if-lez v2, :cond_7b

    .line 163
    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    add-float/2addr v2, v9

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    sub-float/2addr v2, v9

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    sub-float/2addr v2, v9

    float-to-double v9, v2

    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v9

    double-to-float v2, v9

    mul-float/2addr v2, v8

    .line 164
    .restart local v2    # "s":F
    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    sub-float/2addr v8, v9

    div-float/2addr v8, v2

    aput v8, v1, v7

    mul-float/2addr v6, v2

    aput v6, v1, v5

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    add-float/2addr v5, v6

    div-float/2addr v5, v2

    aput v5, v1, v4

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    add-float/2addr v4, v5

    div-float/2addr v4, v2

    aput v4, v1, v3

    .end local v2    # "s":F
    goto :goto_da

    .line 165
    :cond_7b
    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    cmpl-float v2, v2, v10

    if-lez v2, :cond_af

    .line 166
    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    add-float/2addr v2, v9

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    sub-float/2addr v2, v9

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    sub-float/2addr v2, v9

    float-to-double v9, v2

    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v9

    double-to-float v2, v9

    mul-float/2addr v2, v8

    .line 167
    .restart local v2    # "s":F
    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    sub-float/2addr v8, v9

    div-float/2addr v8, v2

    aput v8, v1, v7

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    add-float/2addr v7, v8

    div-float/2addr v7, v2

    aput v7, v1, v5

    mul-float/2addr v6, v2

    aput v6, v1, v4

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    add-float/2addr v4, v5

    div-float/2addr v4, v2

    aput v4, v1, v3

    .end local v2    # "s":F
    goto :goto_da

    .line 169
    :cond_af
    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    add-float/2addr v2, v9

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    sub-float/2addr v2, v9

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    sub-float/2addr v2, v9

    float-to-double v9, v2

    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v9

    double-to-float v2, v9

    mul-float/2addr v2, v8

    .line 170
    .restart local v2    # "s":F
    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    sub-float/2addr v8, v9

    div-float/2addr v8, v2

    aput v8, v1, v7

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    add-float/2addr v7, v8

    div-float/2addr v7, v2

    aput v7, v1, v5

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    add-float/2addr v5, v7

    div-float/2addr v5, v2

    aput v5, v1, v4

    mul-float/2addr v6, v2

    aput v6, v1, v3

    .line 172
    .end local v2    # "s":F
    :goto_da
    return-object v1
.end method

.method public toString()Ljava/lang/String;
    .registers 10

    .line 203
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->components()[F

    move-result-object v0

    const-string v1, ", "

    check-cast v1, Ljava/lang/CharSequence;

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/CFrame$$ExternalSyntheticLambda0;

    invoke-direct {v6}, Lcom/exampletest/mobilestudiotest/model/CFrame$$ExternalSyntheticLambda0;-><init>()V

    const/16 v7, 0x1e

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v8}, Lkotlin/collections/ArraysKt;->joinToString$default([FLjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final vectorToObject(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 8
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 110
    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    mul-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    mul-float/2addr v2, v3

    add-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    mul-float/2addr v2, v3

    add-float/2addr v1, v2

    .line 111
    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    mul-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    .line 112
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    mul-float/2addr v3, v4

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    .line 109
    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 113
    return-object v0
.end method

.method public final vectorToWorld(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 8
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 103
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 104
    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    mul-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    mul-float/2addr v2, v3

    add-float/2addr v1, v2

    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    mul-float/2addr v2, v3

    add-float/2addr v1, v2

    .line 105
    iget v2, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    mul-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    mul-float/2addr v3, v4

    add-float/2addr v2, v3

    .line 106
    iget v3, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    mul-float/2addr v3, v4

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    iget v4, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    .line 103
    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    .line 107
    return-object v0
.end method

.method public final withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 16
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "p"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 124
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    iget v5, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r00:F

    iget v6, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r01:F

    iget v7, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r02:F

    iget v8, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r10:F

    iget v9, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r11:F

    iget v10, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r12:F

    iget v11, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r20:F

    iget v12, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r21:F

    iget v13, p0, Lcom/exampletest/mobilestudiotest/model/CFrame;->r22:F

    invoke-direct/range {v1 .. v13}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v1
.end method

###### Class com.exampletest.mobilestudiotest.model.CFrame.Companion (com.exampletest.mobilestudiotest.model.CFrame$Companion)
.class public final Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;
.super Ljava/lang/Object;
.source "DataTypes.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/model/CFrame;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDataTypes.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DataTypes.kt\ncom/exampletest/mobilestudiotest/model/CFrame$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,423:1\n1#2:424\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0010\u0007\n\u0002\u0008\u0014\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\u0008\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nJ&\u0010\u000b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000c\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\nJ\u000e\u0010\u000f\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0011J\u000e\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0011J\u000e\u0010\u0013\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0011J\u001e\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u00112\u0006\u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u0011J\u001e\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u00112\u0006\u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u0011J\u0016\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u001a\u001a\u00020\n2\u0006\u0010\u001b\u001a\u00020\u0011J.\u0010\u001c\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u001d\u001a\u00020\u00112\u0006\u0010\u001e\u001a\u00020\u00112\u0006\u0010\u001f\u001a\u00020\u00112\u0006\u0010 \u001a\u00020\u0011J \u0010!\u001a\u00020\u00052\u0006\u0010\"\u001a\u00020\n2\u0006\u0010#\u001a\u00020\n2\u0008\u0008\u0002\u0010$\u001a\u00020\nR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\u00a8\u0006%"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;",
        "",
        "<init>",
        "()V",
        "IDENTITY",
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "getIDENTITY",
        "()Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "at",
        "p",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "fromColumns",
        "r",
        "u",
        "b",
        "rx",
        "a",
        "",
        "ry",
        "rz",
        "angles",
        "x",
        "y",
        "z",
        "fromOrientation",
        "fromAxisAngle",
        "axis",
        "angle",
        "fromQuaternion",
        "qx",
        "qy",
        "qz",
        "qw",
        "lookAt",
        "eye",
        "target",
        "up",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 205
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;-><init>()V

    return-void
.end method

.method public static synthetic lookAt$default(Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 6

    .line 235
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_a

    sget-object p3, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getY()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object p3

    :cond_a
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->lookAt(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final angles(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 6
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 214
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->rx(F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {p0, p2}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->ry(F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {p0, p3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->rz(F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    return-object v0
.end method

.method public final at(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 19
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "p"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 207
    new-instance v2, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    const/16 v15, 0xff8

    const/16 v16, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-direct/range {v2 .. v16}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v2
.end method

.method public final fromAxisAngle(Lcom/exampletest/mobilestudiotest/model/Vector3;F)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 13
    .param p1, "axis"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "angle"    # F

    const-string v0, "axis"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 218
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .line 219
    .local v0, "a":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/high16 v1, 0x40000000    # 2.0f

    div-float v1, p2, v1

    .line 220
    .local v1, "h":F
    float-to-double v2, v1

    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v2

    double-to-float v2, v2

    .line 221
    .local v2, "s":F
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    mul-float v6, v3, v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    mul-float v7, v3, v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    mul-float v8, v3, v2

    float-to-double v3, v1

    invoke-static {v3, v4}, Ljava/lang/Math;->cos(D)D

    move-result-wide v3

    double-to-float v9, v3

    move-object v4, p0

    invoke-virtual/range {v4 .. v9}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromQuaternion(Lcom/exampletest/mobilestudiotest/model/Vector3;FFFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    return-object v3
.end method

.method public final fromColumns(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 23
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "r"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "u"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p4, "b"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "p"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "r"

    move-object/from16 v2, p2

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "u"

    move-object/from16 v3, p3

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    move-object/from16 v4, p4

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 209
    new-instance v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v6

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v7

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v8

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v9

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v10

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v11

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v12

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v13

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v14

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v15

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v16

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v17

    invoke-direct/range {v5 .. v17}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v5
.end method

.method public final fromOrientation(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 6
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 215
    invoke-virtual {p0, p2}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->ry(F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->rx(F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {p0, p3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->rz(F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    return-object v0
.end method

.method public final fromQuaternion(Lcom/exampletest/mobilestudiotest/model/Vector3;FFFF)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 28
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "qx"    # F
    .param p3, "qy"    # F
    .param p4, "qz"    # F
    .param p5, "qw"    # F

    const-string v0, "p"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 225
    mul-float v0, p2, p2

    mul-float v2, p3, p3

    add-float/2addr v0, v2

    mul-float v2, p4, p4

    add-float/2addr v0, v2

    mul-float v2, p5, p5

    add-float/2addr v0, v2

    float-to-double v2, v0

    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v2

    double-to-float v0, v2

    .line 424
    .local v0, "it\\1":F
    const/4 v2, 0x0

    .line 225
    .local v2, "$i$a$-let-CFrame$Companion$fromQuaternion$n$1\\1\\225\\0":I
    const v3, 0x3089705f    # 1.0E-9f

    cmpg-float v3, v0, v3

    const/high16 v4, 0x3f800000    # 1.0f

    if-gez v3, :cond_23

    move v0, v4

    .line 226
    .end local v2    # "$i$a$-let-CFrame$Companion$fromQuaternion$n$1\\1\\225\\0":I
    .local v0, "n":F
    :cond_23
    div-float v2, p2, v0

    .local v2, "x":F
    div-float v3, p3, v0

    .local v3, "y":F
    div-float v5, p4, v0

    .local v5, "z":F
    div-float v6, p5, v0

    .line 227
    .local v6, "w":F
    new-instance v7, Lcom/exampletest/mobilestudiotest/model/CFrame;

    .line 228
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v8

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v9

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v10

    .line 229
    mul-float v11, v3, v3

    mul-float v12, v5, v5

    add-float/2addr v11, v12

    const/high16 v12, 0x40000000    # 2.0f

    mul-float/2addr v11, v12

    sub-float v11, v4, v11

    mul-float v13, v2, v3

    mul-float v14, v5, v6

    sub-float/2addr v13, v14

    mul-float/2addr v13, v12

    mul-float v14, v2, v5

    mul-float v15, v3, v6

    add-float/2addr v14, v15

    mul-float/2addr v14, v12

    .line 230
    mul-float v15, v2, v3

    mul-float v16, v5, v6

    add-float v15, v15, v16

    mul-float/2addr v15, v12

    mul-float v16, v2, v2

    mul-float v17, v5, v5

    add-float v16, v16, v17

    mul-float v16, v16, v12

    sub-float v16, v4, v16

    mul-float v17, v3, v5

    mul-float v18, v2, v6

    sub-float v17, v17, v18

    mul-float v17, v17, v12

    .line 231
    mul-float v18, v2, v5

    mul-float v19, v3, v6

    sub-float v18, v18, v19

    mul-float v18, v18, v12

    mul-float v19, v3, v5

    mul-float v20, v2, v6

    add-float v19, v19, v20

    mul-float v19, v19, v12

    mul-float v20, v2, v2

    mul-float v21, v3, v3

    add-float v20, v20, v21

    mul-float v12, v12, v20

    sub-float/2addr v4, v12

    .line 227
    move v12, v13

    move v13, v14

    move v14, v15

    move/from16 v15, v16

    move/from16 v16, v17

    move/from16 v17, v18

    move/from16 v18, v19

    move/from16 v19, v4

    invoke-direct/range {v7 .. v19}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v7
.end method

.method public final getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 2

    .line 206
    invoke-static {}, Lcom/exampletest/mobilestudiotest/model/CFrame;->access$getIDENTITY$cp()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    return-object v0
.end method

.method public final lookAt(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 9
    .param p1, "eye"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "target"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "up"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "eye"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "target"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "up"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 236
    invoke-virtual {p2, p1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .line 237
    .local v0, "look":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v1

    const v2, 0x358637bd    # 1.0E-6f

    cmpg-float v1, v1, v2

    if-gez v1, :cond_27

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->at(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    return-object v1

    .line 238
    :cond_27
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .line 239
    .local v1, "back":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p3, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->cross(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    .line 240
    .local v3, "right":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v4

    cmpg-float v2, v4, v2

    if-gez v2, :cond_41

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getX()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    .line 241
    :cond_41
    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->cross(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    .line 242
    .local v2, "u":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p0, p1, v3, v2, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromColumns(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    return-object v4
.end method

.method public final rx(F)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 18
    .param p1, "a"    # F

    .line 211
    move/from16 v0, p1

    float-to-double v1, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->cos(D)D

    move-result-wide v1

    double-to-float v11, v1

    .local v11, "c":F
    float-to-double v1, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v14, v1

    .local v14, "s":F
    new-instance v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    neg-float v12, v14

    const/4 v13, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move v15, v11

    invoke-direct/range {v3 .. v15}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v3
.end method

.method public final ry(F)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 18
    .param p1, "a"    # F

    .line 212
    move/from16 v0, p1

    float-to-double v1, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->cos(D)D

    move-result-wide v1

    double-to-float v7, v1

    .local v7, "c":F
    float-to-double v1, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v9, v1

    .local v9, "s":F
    new-instance v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    neg-float v13, v9

    const/4 v14, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/high16 v11, 0x3f800000    # 1.0f

    const/4 v12, 0x0

    move v15, v7

    invoke-direct/range {v3 .. v15}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v3
.end method

.method public final rz(F)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 18
    .param p1, "a"    # F

    .line 213
    move/from16 v0, p1

    float-to-double v1, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->cos(D)D

    move-result-wide v1

    double-to-float v7, v1

    .local v7, "c":F
    float-to-double v1, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v10, v1

    .local v10, "s":F
    new-instance v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    neg-float v8, v10

    const/4 v14, 0x0

    const/high16 v15, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v9, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    move v11, v7

    invoke-direct/range {v3 .. v15}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    return-object v3
.end method

###### Class com.exampletest.mobilestudiotest.model.CFrame$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.model.CFrame$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/model/CFrame$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/model/CFrame;"
    method = "toString$lambda$0"
    proto = "(F)Ljava/lang/CharSequence;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toString$lambda$0(F)Ljava/lang/CharSequence;

    move-result-object p1

    return-object p1
.end method
