###### Class com.exampletest.mobilestudiotest.model.Instance (com.exampletest.mobilestudiotest.model.Instance)
.class public Lcom/exampletest/mobilestudiotest/model/Instance;
.super Ljava/lang/Object;
.source "Instance.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/model/Instance$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInstance.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Instance.kt\ncom/exampletest/mobilestudiotest/model/Instance\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,715:1\n1#2:716\n295#3,2:717\n*S KotlinDebug\n*F\n+ 1 Instance.kt\ncom/exampletest/mobilestudiotest/model/Instance\n*L\n125#1:717,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0008\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0011\n\u0002\u0010\u0007\n\u0002\u0008\u0015\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0011\n\u0002\u0010!\n\u0002\u0008\u0006\u0008\u0016\u0018\u0000 c2\u00020\u0001:\u0001cB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0013\u0010F\u001a\u0004\u0018\u00010\u00012\u0006\u0010C\u001a\u00020\u0003H\u0086\u0002J\"\u0010G\u001a\u00020H2\u0006\u0010C\u001a\u00020\u00032\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u00012\u0008\u0008\u0002\u0010I\u001a\u00020 J\u0008\u0010J\u001a\u00020 H\u0002J\u0008\u0010K\u001a\u0004\u0018\u00010LJ\u000e\u0010M\u001a\u00020 2\u0006\u0010N\u001a\u00020\u0000J\u001a\u0010O\u001a\u00020H2\u0008\u0010P\u001a\u0004\u0018\u00010\u00002\u0008\u0008\u0002\u0010Q\u001a\u00020\u0010J\u000e\u0010R\u001a\u00020H2\u0006\u0010S\u001a\u00020\u0000J\u0006\u0010T\u001a\u00020HJ\u0008\u0010U\u001a\u00020HH\u0002J\u000e\u0010V\u001a\u00020 2\u0006\u0010W\u001a\u00020\u0003J\u001a\u0010X\u001a\u0004\u0018\u00010\u00002\u0006\u0010Y\u001a\u00020\u00032\u0008\u0008\u0002\u0010Z\u001a\u00020 J\u0010\u0010[\u001a\u0004\u0018\u00010\u00002\u0006\u0010W\u001a\u00020\u0003J\u001a\u0010\\\u001a\u0004\u0018\u00010\u00002\u0006\u0010W\u001a\u00020\u00032\u0008\u0008\u0002\u0010Z\u001a\u00020 J\u001c\u0010]\u001a\u0008\u0012\u0004\u0012\u00020\u00000^2\u000e\u0008\u0002\u0010_\u001a\u0008\u0012\u0004\u0012\u00020\u00000^J\u0006\u0010`\u001a\u00020\u0003J\u0006\u0010a\u001a\u00020\u0000J\u0008\u0010b\u001a\u00020\u0003H\u0016R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\"\u0004\u0008\u0008\u0010\u0005R1\u0010\t\u001a\"\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00010\nj\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u0001`\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR-\u0010\u000e\u001a\u001e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00100\u000fj\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0010`\u0011\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0013R(\u0010\u0015\u001a\u0004\u0018\u00010\u00002\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u0000@@X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0016\u0010\u0017\"\u0004\u0008\u0018\u0010\u0019R!\u0010\u001a\u001a\u0012\u0012\u0004\u0012\u00020\u00000\u001bj\u0008\u0012\u0004\u0012\u00020\u0000`\u001c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u001eR\u001a\u0010\u001f\u001a\u00020 X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001f\u0010!\"\u0004\u0008\"\u0010#R\u001a\u0010$\u001a\u00020 X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008%\u0010!\"\u0004\u0008&\u0010#R\u001a\u0010\'\u001a\u00020 X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008(\u0010!\"\u0004\u0008)\u0010#R\u001a\u0010*\u001a\u00020\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008+\u0010,\"\u0004\u0008-\u0010.R1\u0010/\u001a\"\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00010\nj\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u0001`\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u00080\u0010\rR\u001a\u00101\u001a\u000202X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00083\u00104\"\u0004\u00085\u00106R\u001a\u00107\u001a\u000202X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u00088\u00104\"\u0004\u00089\u00106R\u001a\u0010:\u001a\u000202X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008;\u00104\"\u0004\u0008<\u00106R\u001a\u0010=\u001a\u000202X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008>\u00104\"\u0004\u0008?\u00106R\u0012\u0010@\u001a\u00020\u00108\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010A\u001a\u0004\u0018\u00010\u00018\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R$\u0010C\u001a\u00020\u00032\u0006\u0010B\u001a\u00020\u00038F@FX\u0086\u000e\u00a2\u0006\u000c\u001a\u0004\u0008D\u0010\u0007\"\u0004\u0008E\u0010\u0005\u00a8\u0006d"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "",
        "className",
        "",
        "<init>",
        "(Ljava/lang/String;)V",
        "getClassName",
        "()Ljava/lang/String;",
        "setClassName",
        "props",
        "Ljava/util/LinkedHashMap;",
        "Lkotlin/collections/LinkedHashMap;",
        "getProps",
        "()Ljava/util/LinkedHashMap;",
        "propTypes",
        "Ljava/util/HashMap;",
        "",
        "Lkotlin/collections/HashMap;",
        "getPropTypes",
        "()Ljava/util/HashMap;",
        "value",
        "parent",
        "getParent",
        "()Lcom/exampletest/mobilestudiotest/model/Instance;",
        "setParent$app",
        "(Lcom/exampletest/mobilestudiotest/model/Instance;)V",
        "children",
        "Ljava/util/ArrayList;",
        "Lkotlin/collections/ArrayList;",
        "getChildren",
        "()Ljava/util/ArrayList;",
        "isService",
        "",
        "()Z",
        "setService",
        "(Z)V",
        "archivable",
        "getArchivable",
        "setArchivable",
        "destroyed",
        "getDestroyed",
        "setDestroyed",
        "loadedRef",
        "getLoadedRef",
        "()I",
        "setLoadedRef",
        "(I)V",
        "attributes",
        "getAttributes",
        "absX",
        "",
        "getAbsX",
        "()F",
        "setAbsX",
        "(F)V",
        "absY",
        "getAbsY",
        "setAbsY",
        "absW",
        "getAbsW",
        "setAbsW",
        "absH",
        "getAbsH",
        "setAbsH",
        "version",
        "renderRec",
        "v",
        "name",
        "getName",
        "setName",
        "get",
        "set",
        "",
        "notify",
        "affectsParentShape",
        "root",
        "Lcom/exampletest/mobilestudiotest/model/DataModel;",
        "isDescendantOf",
        "other",
        "setParent",
        "newParent",
        "index",
        "attachRaw",
        "p",
        "destroy",
        "markDestroyed",
        "isA",
        "cls",
        "findFirstChild",
        "n",
        "recursive",
        "findFirstChildOfClass",
        "findFirstChildWhichIsA",
        "descendants",
        "",
        "out",
        "fullName",
        "cloneTree",
        "toString",
        "Companion",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/exampletest/mobilestudiotest/model/Instance$Companion;

.field public static volatile changeCount:J


# instance fields
.field private absH:F

.field private absW:F

.field private absX:F

.field private absY:F

.field private archivable:Z

.field private final attributes:Ljava/util/LinkedHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private final children:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation
.end field

.field private className:Ljava/lang/String;

.field private destroyed:Z

.field private isService:Z

.field private loadedRef:I

.field private parent:Lcom/exampletest/mobilestudiotest/model/Instance;

.field private final propTypes:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final props:Ljava/util/LinkedHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field public renderRec:Ljava/lang/Object;

.field public version:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Instance$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Instance$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/model/Instance;->Companion:Lcom/exampletest/mobilestudiotest/model/Instance$Companion;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 3
    .param p1, "className"    # Ljava/lang/String;

    const-string v0, "className"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->className:Ljava/lang/String;

    .line 13
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->props:Ljava/util/LinkedHashMap;

    .line 14
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->propTypes:Ljava/util/HashMap;

    .line 17
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    .line 19
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->archivable:Z

    .line 22
    const/4 v0, -0x1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->loadedRef:I

    .line 24
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->attributes:Ljava/util/LinkedHashMap;

    .line 12
    return-void
.end method

.method private final affectsParentShape()Z
    .registers 5

    .line 58
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->className:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, 0x1

    sparse-switch v1, :sswitch_data_60

    goto :goto_40

    :sswitch_b
    const-string v1, "BevelMesh"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_40

    goto :goto_41

    :sswitch_14
    const-string v1, "CylinderMesh"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41

    goto :goto_40

    :sswitch_1d
    const-string v1, "SurfaceAppearance"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41

    goto :goto_40

    :sswitch_26
    const-string v1, "SpecialMesh"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41

    goto :goto_40

    :sswitch_2f
    const-string v1, "FileMesh"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41

    goto :goto_40

    :sswitch_38
    const-string v1, "BlockMesh"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41

    :cond_40
    :goto_40
    goto :goto_42

    .line 59
    :cond_41
    :goto_41
    goto :goto_5e

    .line 60
    :goto_42
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    const/4 v1, 0x0

    if-eqz v0, :cond_51

    const-string v3, "PartOperation"

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-ne v0, v2, :cond_51

    move v0, v2

    goto :goto_52

    :cond_51
    move v0, v1

    :goto_52
    if-eqz v0, :cond_5d

    const-string v0, "BasePart"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5d

    goto :goto_5e

    :cond_5d
    move v2, v1

    .line 61
    :goto_5e
    return v2

    nop

    :sswitch_data_60
    .sparse-switch
        -0x5490a006 -> :sswitch_38
        -0x28003a57 -> :sswitch_2f
        0x2f666e26 -> :sswitch_26
        0x3a4d90d1 -> :sswitch_1d
        0x4218eb03 -> :sswitch_14
        0x4a0a8d67 -> :sswitch_b
    .end sparse-switch
.end method

.method public static synthetic descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;
    .registers 4

    .line 132
    if-nez p3, :cond_12

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_d

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    check-cast p1, Ljava/util/List;

    :cond_d
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_12
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Super calls with default arguments not supported in this target, function: descendants"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static synthetic findFirstChild$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ZILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 5

    .line 119
    if-nez p4, :cond_c

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_7

    const/4 p2, 0x0

    :cond_7
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object p0

    return-object p0

    :cond_c
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Super calls with default arguments not supported in this target, function: findFirstChild"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static synthetic findFirstChildWhichIsA$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ZILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 5

    .line 126
    if-nez p4, :cond_c

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_7

    const/4 p2, 0x0

    :cond_7
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildWhichIsA(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object p0

    return-object p0

    :cond_c
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Super calls with default arguments not supported in this target, function: findFirstChildWhichIsA"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private final markDestroyed()V
    .registers 3

    .line 113
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->destroyed:Z

    .line 114
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1f

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v1, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->markDestroyed()V

    .end local v1    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_f

    .line 115
    :cond_1f
    return-void
.end method

.method public static synthetic set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V
    .registers 6

    .line 41
    if-nez p5, :cond_b

    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_7

    const/4 p3, 0x1

    :cond_7
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    return-void

    :cond_b
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Super calls with default arguments not supported in this target, function: set"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static synthetic setParent$default(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;IILjava/lang/Object;)V
    .registers 5

    .line 78
    if-nez p4, :cond_b

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_7

    const/4 p2, -0x1

    :cond_7
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->setParent(Lcom/exampletest/mobilestudiotest/model/Instance;I)V

    return-void

    :cond_b
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Super calls with default arguments not supported in this target, function: setParent"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 3
    .param p1, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "p"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 103
    iget-object v0, p1, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 104
    return-void
.end method

.method public final cloneTree()Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 5

    .line 146
    new-instance v0, Ljava/util/IdentityHashMap;

    invoke-direct {v0}, Ljava/util/IdentityHashMap;-><init>()V

    .line 147
    .local v0, "map":Ljava/util/IdentityHashMap;
    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Instance;->Companion:Lcom/exampletest/mobilestudiotest/model/Instance$Companion;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->className:Ljava/lang/String;

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0, v0, v2}, Lcom/exampletest/mobilestudiotest/model/Instance$Companion;->copyInto$app(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/IdentityHashMap;Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    .line 148
    .local v1, "r":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v2, Lcom/exampletest/mobilestudiotest/model/Instance;->Companion:Lcom/exampletest/mobilestudiotest/model/Instance$Companion;

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance$Companion;->remapRefs$app(Ljava/util/IdentityHashMap;)V

    .line 149
    return-object v1
.end method

.method public final descendants(Ljava/util/List;)Ljava/util/List;
    .registers 4
    .param p1, "out"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    const-string v0, "out"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v1, "iterator(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_23

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v1, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants(Ljava/util/List;)Ljava/util/List;

    goto :goto_10

    .line 134
    .end local v1    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_23
    return-object p1
.end method

.method public final destroy()V
    .registers 4

    .line 107
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->destroyed:Z

    if-eqz v0, :cond_5

    return-void

    .line 108
    :cond_5
    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->setParent$default(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;IILjava/lang/Object;)V

    .line 109
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->markDestroyed()V

    .line 110
    return-void
.end method

.method public final findFirstChild(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 7
    .param p1, "n"    # Ljava/lang/String;
    .param p2, "recursive"    # Z

    const-string v0, "n"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 120
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v1, "iterator(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_27

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v2, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_10

    return-object v2

    .line 121
    .end local v2    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_27
    if-eqz p2, :cond_47

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_32
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_47

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v1, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x1

    invoke-virtual {v1, p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    if-eqz v2, :cond_32

    .line 716
    .local v2, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v0, 0x0

    .line 121
    .local v0, "$i$a$-let-Instance$findFirstChild$1\\1\\121\\0":I
    return-object v2

    .line 122
    .end local v0    # "$i$a$-let-Instance$findFirstChild$1\\1\\121\\0":I
    .end local v1    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_47
    const/4 v0, 0x0

    return-object v0
.end method

.method public final findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 9
    .param p1, "cls"    # Ljava/lang/String;

    const-string v0, "cls"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 717
    .local v1, "$i$f$firstOrNull\\1\\125":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_25

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v4, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v5, 0x0

    .line 125
    .local v5, "$i$a$-firstOrNull-Instance$findFirstChildOfClass$1\\2\\717\\0":I
    iget-object v6, v4, Lcom/exampletest/mobilestudiotest/model/Instance;->className:Ljava/lang/String;

    invoke-static {v6, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    .line 717
    .end local v4    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v5    # "$i$a$-firstOrNull-Instance$findFirstChildOfClass$1\\2\\717\\0":I
    if-eqz v4, :cond_e

    goto :goto_26

    .line 718
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_25
    const/4 v3, 0x0

    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\125":I
    :goto_26
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 125
    return-object v3
.end method

.method public final findFirstChildWhichIsA(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 7
    .param p1, "cls"    # Ljava/lang/String;
    .param p2, "recursive"    # Z

    const-string v0, "cls"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 127
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v1, "iterator(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_23

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v2, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v2, p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_10

    return-object v2

    .line 128
    .end local v2    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_23
    if-eqz p2, :cond_43

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_2e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_43

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v1, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x1

    invoke-virtual {v1, p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildWhichIsA(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    if-eqz v2, :cond_2e

    .line 716
    .local v2, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v0, 0x0

    .line 128
    .local v0, "$i$a$-let-Instance$findFirstChildWhichIsA$1\\1\\128\\0":I
    return-object v2

    .line 129
    .end local v0    # "$i$a$-let-Instance$findFirstChildWhichIsA$1\\1\\128\\0":I
    .end local v1    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_43
    const/4 v0, 0x0

    return-object v0
.end method

.method public final fullName()Ljava/lang/String;
    .registers 13

    .line 138
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 139
    .local v0, "parts":Ljava/util/ArrayList;
    move-object v1, p0

    .line 140
    .local v1, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_6
    if-eqz v1, :cond_16

    instance-of v2, v1, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-nez v2, :cond_16

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v1, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_6

    .line 141
    :cond_16
    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->reversed(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Ljava/lang/Iterable;

    const-string v2, "."

    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    const/16 v10, 0x3e

    const/4 v11, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v3 .. v11}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method public final get(Ljava/lang/String;)Ljava/lang/Object;
    .registers 3
    .param p1, "name"    # Ljava/lang/String;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->props:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final getAbsH()F
    .registers 2

    .line 26
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->absH:F

    return v0
.end method

.method public final getAbsW()F
    .registers 2

    .line 26
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->absW:F

    return v0
.end method

.method public final getAbsX()F
    .registers 2

    .line 26
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->absX:F

    return v0
.end method

.method public final getAbsY()F
    .registers 2

    .line 26
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->absY:F

    return v0
.end method

.method public final getArchivable()Z
    .registers 2

    .line 19
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->archivable:Z

    return v0
.end method

.method public final getAttributes()Ljava/util/LinkedHashMap;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .line 24
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->attributes:Ljava/util/LinkedHashMap;

    return-object v0
.end method

.method public final getChildren()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 17
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final getClassName()Ljava/lang/String;
    .registers 2

    .line 12
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->className:Ljava/lang/String;

    return-object v0
.end method

.method public final getDestroyed()Z
    .registers 2

    .line 20
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->destroyed:Z

    return v0
.end method

.method public final getLoadedRef()I
    .registers 2

    .line 22
    iget v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->loadedRef:I

    return v0
.end method

.method public final getName()Ljava/lang/String;
    .registers 3

    .line 36
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->props:Ljava/util/LinkedHashMap;

    const-string v1, "Name"

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_f

    check-cast v0, Ljava/lang/String;

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    :goto_10
    if-nez v0, :cond_14

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->className:Ljava/lang/String;

    :cond_14
    return-object v0
.end method

.method public final getParent()Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 2

    .line 15
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-object v0
.end method

.method public final getPropTypes()Ljava/util/HashMap;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 14
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->propTypes:Ljava/util/HashMap;

    return-object v0
.end method

.method public final getProps()Ljava/util/LinkedHashMap;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .line 13
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->props:Ljava/util/LinkedHashMap;

    return-object v0
.end method

.method public final isA(Ljava/lang/String;)Z
    .registers 4
    .param p1, "cls"    # Ljava/lang/String;

    const-string v0, "cls"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 117
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->className:Ljava/lang/String;

    invoke-virtual {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isA(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method public final isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 4
    .param p1, "other"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "other"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 74
    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_7
    if-eqz v0, :cond_10

    if-ne v0, p1, :cond_d

    const/4 v1, 0x1

    return v1

    :cond_d
    iget-object v0, v0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_7

    .line 75
    :cond_10
    const/4 v1, 0x0

    return v1
.end method

.method public final isService()Z
    .registers 2

    .line 18
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->isService:Z

    return v0
.end method

.method public final root()Lcom/exampletest/mobilestudiotest/model/DataModel;
    .registers 3

    .line 64
    move-object v0, p0

    .line 65
    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_1
    if-eqz v0, :cond_e

    .line 66
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-eqz v1, :cond_b

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/DataModel;

    return-object v1

    .line 67
    :cond_b
    iget-object v0, v0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_1

    .line 69
    :cond_e
    const/4 v1, 0x0

    return-object v1
.end method

.method public final set(Ljava/lang/String;Ljava/lang/Object;Z)V
    .registers 9
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/Object;
    .param p3, "notify"    # Z

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->props:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 43
    .local v0, "old":Ljava/lang/Object;
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->props:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1a

    invoke-static {v0, p2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1a

    return-void

    .line 44
    :cond_1a
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->props:Ljava/util/LinkedHashMap;

    check-cast v1, Ljava/util/Map;

    invoke-interface {v1, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    .line 48
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->affectsParentShape()Z

    move-result v1

    if-eqz v1, :cond_38

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v1, :cond_38

    .line 716
    .local v1, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x0

    .line 48
    .local v2, "$i$a$-let-Instance$set$1\\1\\48\\0":I
    iget v3, v1, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    add-int/lit8 v3, v3, 0x1

    iput v3, v1, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    .line 49
    .end local v1    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "$i$a$-let-Instance$set$1\\1\\48\\0":I
    :cond_38
    sget-wide v1, Lcom/exampletest/mobilestudiotest/model/Instance;->changeCount:J

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Instance;->Companion:Lcom/exampletest/mobilestudiotest/model/Instance$Companion;

    const-wide/16 v3, 0x1

    add-long/2addr v1, v3

    sput-wide v1, Lcom/exampletest/mobilestudiotest/model/Instance;->changeCount:J

    .line 50
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->propTypes:Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5a

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->propTypes:Ljava/util/HashMap;

    check-cast v1, Ljava/util/Map;

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/PropType;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropType;

    invoke-virtual {v2, p2}, Lcom/exampletest/mobilestudiotest/model/PropType;->infer(Ljava/lang/Object;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    :cond_5a
    if-eqz p3, :cond_65

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->root()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v1

    if-eqz v1, :cond_65

    invoke-virtual {v1, p0, p1}, Lcom/exampletest/mobilestudiotest/model/DataModel;->firePropChanged(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)V

    .line 52
    :cond_65
    return-void
.end method

.method public final setAbsH(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 26
    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->absH:F

    return-void
.end method

.method public final setAbsW(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 26
    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->absW:F

    return-void
.end method

.method public final setAbsX(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 26
    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->absX:F

    return-void
.end method

.method public final setAbsY(F)V
    .registers 2
    .param p1, "<set-?>"    # F

    .line 26
    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->absY:F

    return-void
.end method

.method public final setArchivable(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 19
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->archivable:Z

    return-void
.end method

.method public final setClassName(Ljava/lang/String;)V
    .registers 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->className:Ljava/lang/String;

    return-void
.end method

.method public final setDestroyed(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 20
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->destroyed:Z

    return-void
.end method

.method public final setLoadedRef(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 22
    iput p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->loadedRef:I

    return-void
.end method

.method public final setName(Ljava/lang/String;)V
    .registers 9
    .param p1, "v"    # Ljava/lang/String;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 37
    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v2, "Name"

    const/4 v4, 0x0

    move-object v1, p0

    move-object v3, p1

    .end local p1    # "v":Ljava/lang/String;
    .local v3, "v":Ljava/lang/String;
    invoke-static/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    return-void
.end method

.method public final setParent(Lcom/exampletest/mobilestudiotest/model/Instance;I)V
    .registers 10
    .param p1, "newParent"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "index"    # I

    .line 79
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    if-ne p1, v0, :cond_5

    return-void

    .line 80
    :cond_5
    if-eqz p1, :cond_40

    if-eq p1, p0, :cond_f

    invoke-virtual {p1, p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    if-eqz v0, :cond_40

    .line 81
    :cond_f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Attempt to set parent of "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " to "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " would result in circular reference"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 82
    :cond_40
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 83
    .local v0, "old":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    const/4 v2, 0x1

    add-int/2addr v1, v2

    iput v1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    .line 84
    sget-wide v3, Lcom/exampletest/mobilestudiotest/model/Instance;->changeCount:J

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Instance;->Companion:Lcom/exampletest/mobilestudiotest/model/Instance$Companion;

    const-wide/16 v5, 0x1

    add-long/2addr v3, v5

    sput-wide v3, Lcom/exampletest/mobilestudiotest/model/Instance;->changeCount:J

    .line 85
    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->affectsParentShape()Z

    move-result v1

    .line 86
    .local v1, "shape":Z
    if-eqz v0, :cond_6f

    .line 87
    if-eqz v1, :cond_5e

    iget v3, v0, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    add-int/2addr v3, v2

    iput v3, v0, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    .line 88
    :cond_5e
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v3, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 89
    const/4 v3, 0x0

    iput-object v3, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 90
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->root()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v3

    if-eqz v3, :cond_6f

    invoke-virtual {v3, v0, p0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->fireChildRemoved(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 92
    :cond_6f
    if-eqz p1, :cond_9d

    .line 93
    if-eqz v1, :cond_78

    iget v3, p1, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    add-int/2addr v3, v2

    iput v3, p1, Lcom/exampletest/mobilestudiotest/model/Instance;->version:I

    .line 94
    :cond_78
    const/4 v3, 0x0

    if-ltz p2, :cond_84

    iget-object v4, p1, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-gt p2, v4, :cond_84

    goto :goto_85

    :cond_84
    move v2, v3

    :goto_85
    if-eqz v2, :cond_8d

    iget-object v2, p1, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v2, p2, p0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    goto :goto_92

    :cond_8d
    iget-object v2, p1, Lcom/exampletest/mobilestudiotest/model/Instance;->children:Ljava/util/ArrayList;

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 95
    :goto_92
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 96
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->root()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v2

    if-eqz v2, :cond_9d

    invoke-virtual {v2, p1, p0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->fireChildAdded(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 98
    :cond_9d
    return-void
.end method

.method public final setParent$app(Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 2
    .param p1, "<set-?>"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 16
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->parent:Lcom/exampletest/mobilestudiotest/model/Instance;

    return-void
.end method

.method public final setService(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 18
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/model/Instance;->isService:Z

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 152
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.model.Instance.Companion (com.exampletest.mobilestudiotest.model.Instance$Companion)
.class public final Lcom/exampletest/mobilestudiotest/model/Instance$Companion;
.super Ljava/lang/Object;
.source "Instance.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/model/Instance;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInstance.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Instance.kt\ncom/exampletest/mobilestudiotest/model/Instance$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,715:1\n1#2:716\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0002\u0008\u0002\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J1\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\u00072\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00070\n2\u0006\u0010\u000b\u001a\u00020\u0007H\u0000\u00a2\u0006\u0002\u0008\u000cJ!\u0010\r\u001a\u00020\u000e2\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00070\nH\u0000\u00a2\u0006\u0002\u0008\u000fR\u0012\u0010\u0004\u001a\u00020\u00058\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/model/Instance$Companion;",
        "",
        "<init>",
        "()V",
        "changeCount",
        "",
        "copyInto",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "src",
        "map",
        "Ljava/util/IdentityHashMap;",
        "dst",
        "copyInto$app",
        "remapRefs",
        "",
        "remapRefs$app",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 154
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/model/Instance$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final copyInto$app(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/IdentityHashMap;Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 8
    .param p1, "src"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "map"    # Ljava/util/IdentityHashMap;
    .param p3, "dst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Ljava/util/IdentityHashMap<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ")",
            "Lcom/exampletest/mobilestudiotest/model/Instance;"
        }
    .end annotation

    const-string v0, "src"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "map"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "dst"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 159
    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->putAll(Ljava/util/Map;)V

    .line 160
    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 161
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v0

    invoke-virtual {p3, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->setService(Z)V

    .line 162
    invoke-virtual {p3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->putAll(Ljava/util/Map;)V

    .line 163
    move-object v0, p2

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 164
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v1, "iterator(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_50
    :goto_50
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_73

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 165
    .local v1, "ch":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getArchivable()Z

    move-result v2

    if-eqz v2, :cond_50

    .line 166
    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1, p2, v2}, Lcom/exampletest/mobilestudiotest/model/Instance$Companion;->copyInto$app(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/IdentityHashMap;Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    .line 167
    .local v2, "cc":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v2, p3}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v1    # "ch":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "cc":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_50

    .line 169
    :cond_73
    return-object p3
.end method

.method public final remapRefs$app(Ljava/util/IdentityHashMap;)V
    .registers 14
    .param p1, "map"    # Ljava/util/IdentityHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/IdentityHashMap<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;)V"
        }
    .end annotation

    const-string v0, "map"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 173
    invoke-virtual {p1}, Ljava/util/IdentityHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_74

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 174
    .local v1, "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_25
    :goto_25
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_d

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    .line 175
    .local v3, "e":Ljava/util/Map$Entry;
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    .line 176
    .local v4, "v":Ljava/lang/Object;
    instance-of v5, v4, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v5, :cond_46

    invoke-virtual {p1, v4}, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v5, :cond_25

    .line 716
    .local v5, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v6, 0x0

    .line 176
    .local v6, "$i$a$-let-Instance$Companion$remapRefs$1\\1\\176\\0":I
    invoke-interface {v3, v5}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;

    .end local v5    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v6    # "$i$a$-let-Instance$Companion$remapRefs$1\\1\\176\\0":I
    goto :goto_25

    .line 177
    :cond_46
    instance-of v5, v4, Lcom/exampletest/mobilestudiotest/model/ContentValue;

    if-eqz v5, :cond_25

    move-object v5, v4

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/ContentValue;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/ContentValue;->getObj()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    if-eqz v5, :cond_25

    move-object v5, v4

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/ContentValue;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/ContentValue;->getObj()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    invoke-virtual {p1, v5}, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v5, :cond_73

    move-object v9, v5

    .line 716
    .local v9, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v5, 0x0

    .line 177
    .local v5, "$i$a$-let-Instance$Companion$remapRefs$2\\2\\177\\0":I
    move-object v6, v4

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/ContentValue;

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v6 .. v11}, Lcom/exampletest/mobilestudiotest/model/ContentValue;->copy$default(Lcom/exampletest/mobilestudiotest/model/ContentValue;ILjava/lang/String;Lcom/exampletest/mobilestudiotest/model/Instance;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/ContentValue;

    move-result-object v6

    invoke-interface {v3, v6}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;

    .end local v5    # "$i$a$-let-Instance$Companion$remapRefs$2\\2\\177\\0":I
    .end local v9    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_25

    .end local v3    # "e":Ljava/util/Map$Entry;
    .end local v4    # "v":Ljava/lang/Object;
    :cond_73
    goto :goto_25

    .line 180
    .end local v1    # "c":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_74
    return-void
.end method
