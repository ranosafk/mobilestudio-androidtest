###### Class com.exampletest.mobilestudiotest.core.PlaceFactory (com.exampletest.mobilestudiotest.core.PlaceFactory)
.class public final Lcom/exampletest/mobilestudiotest/core/PlaceFactory;
.super Ljava/lang/Object;
.source "PlaceFactory.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPlaceFactory.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlaceFactory.kt\ncom/exampletest/mobilestudiotest/core/PlaceFactory\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,106:1\n1#2:107\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0003\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0001\u0015B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0007\u001a\u00020\u00082\u0008\u0008\u0002\u0010\t\u001a\u00020\nJ\u0018\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u0006H\u0002J\u000e\u0010\u000f\u001a\u00020\u00082\u0006\u0010\u0010\u001a\u00020\u0011J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u000cH\u0002R\u0014\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/core/PlaceFactory;",
        "",
        "<init>",
        "()V",
        "required",
        "",
        "",
        "newPlace",
        "Lcom/exampletest/mobilestudiotest/model/DataModel;",
        "template",
        "Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;",
        "service",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "dm",
        "cls",
        "fromDocument",
        "doc",
        "Lcom/exampletest/mobilestudiotest/format/RbxDocument;",
        "ensureTerrain",
        "",
        "ws",
        "Template",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/core/PlaceFactory;

.field private static final required:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/PlaceFactory;

    .line 7
    nop

    .line 8
    const/16 v0, 0xe

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "Workspace"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "Players"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "Lighting"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "MaterialService"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "ReplicatedFirst"

    aput-object v2, v0, v1

    const/4 v1, 0x5

    const-string v2, "ReplicatedStorage"

    aput-object v2, v0, v1

    const/4 v1, 0x6

    const-string v2, "ServerScriptService"

    aput-object v2, v0, v1

    .line 9
    const-string v1, "ServerStorage"

    const/4 v2, 0x7

    aput-object v1, v0, v2

    .line 8
    nop

    .line 9
    const-string v1, "StarterGui"

    const/16 v2, 0x8

    aput-object v1, v0, v2

    .line 8
    nop

    .line 9
    const-string v1, "StarterPack"

    const/16 v2, 0x9

    aput-object v1, v0, v2

    .line 8
    nop

    .line 9
    const-string v1, "StarterPlayer"

    const/16 v2, 0xa

    aput-object v1, v0, v2

    .line 8
    nop

    .line 9
    const-string v1, "Teams"

    const/16 v2, 0xb

    aput-object v1, v0, v2

    .line 8
    nop

    .line 9
    const-string v1, "SoundService"

    const/16 v2, 0xc

    aput-object v1, v0, v2

    .line 8
    nop

    .line 9
    const-string v1, "TextChatService"

    const/16 v2, 0xd

    aput-object v1, v0, v2

    .line 8
    nop

    .line 7
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->required:Ljava/util/List;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final ensureTerrain(Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 8
    .param p1, "ws"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 95
    const-string v0, "Terrain"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-eqz v1, :cond_9

    return-void

    .line 96
    :cond_9
    sget-object v1, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    .line 97
    .local v1, "t":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->setName(Ljava/lang/String;)V

    .line 98
    const-string v0, "Anchored"

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v1, v0, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    const-string v0, "Locked"

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v1, v0, v2, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 99
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/16 v2, 0x54

    const/16 v3, 0x5c

    const/16 v5, 0xc

    invoke-virtual {v0, v5, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v0

    const-string v2, "WaterColor"

    invoke-virtual {v1, v2, v0, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 100
    const v0, 0x3e99999a    # 0.3f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const-string v2, "WaterTransparency"

    invoke-virtual {v1, v2, v0, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const-string v2, "WaterReflectance"

    invoke-virtual {v1, v2, v0, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 101
    const v0, 0x3e19999a    # 0.15f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const-string v2, "WaterWaveSize"

    invoke-virtual {v1, v2, v0, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    const/high16 v0, 0x41200000    # 10.0f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const-string v2, "WaterWaveSpeed"

    invoke-virtual {v1, v2, v0, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 102
    invoke-virtual {v1, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->setService(Z)V

    .line 103
    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 104
    return-void
.end method

.method public static synthetic newPlace$default(Lcom/exampletest/mobilestudiotest/core/PlaceFactory;Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/DataModel;
    .registers 4

    .line 19
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    sget-object p1, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->BASEPLATE:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    :cond_6
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->newPlace(Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;)Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object p0

    return-object p0
.end method

.method private final service(Lcom/exampletest/mobilestudiotest/model/DataModel;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 5
    .param p1, "dm"    # Lcom/exampletest/mobilestudiotest/model/DataModel;
    .param p2, "cls"    # Ljava/lang/String;

    .line 69
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    if-eqz v0, :cond_8

    .line 107
    .local v0, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v1, 0x0

    .line 69
    .local v1, "$i$a$-let-PlaceFactory$service$1\\1\\69\\0":I
    return-object v0

    .line 70
    .end local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v1    # "$i$a$-let-PlaceFactory$service$1\\1\\69\\0":I
    :cond_8
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    invoke-virtual {v0, p2}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    .line 71
    .local v0, "s":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->setService(Z)V

    .line 72
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 73
    return-object v0
.end method


# virtual methods
.method public final fromDocument(Lcom/exampletest/mobilestudiotest/format/RbxDocument;)Lcom/exampletest/mobilestudiotest/model/DataModel;
    .registers 8
    .param p1, "doc"    # Lcom/exampletest/mobilestudiotest/format/RbxDocument;

    const-string v0, "doc"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/DataModel;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;-><init>()V

    .line 78
    .local v0, "dm":Lcom/exampletest/mobilestudiotest/model/DataModel;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getMeta()Ljava/util/LinkedHashMap;

    move-result-object v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/format/RbxDocument;->getMeta()Ljava/util/Map;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/LinkedHashMap;->putAll(Ljava/util/Map;)V

    .line 79
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/format/RbxDocument;->getRoots()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_40

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 80
    .local v2, "r":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->isServiceName(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_39

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->setService(Z)V

    .line 81
    :cond_39
    move-object v3, v0

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v2    # "r":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_1d

    .line 83
    :cond_40
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->required:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_46
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_56

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .local v2, "s":Ljava/lang/String;
    invoke-direct {p0, v0, v2}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->service(Lcom/exampletest/mobilestudiotest/model/DataModel;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_46

    .line 84
    .end local v2    # "s":Ljava/lang/String;
    :cond_56
    const-string v1, "Workspace"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 85
    .local v1, "ws":Lcom/exampletest/mobilestudiotest/model/Instance;
    const-string v2, "CurrentCamera"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    if-nez v3, :cond_7e

    .line 86
    const-string v3, "Camera"

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    if-nez v4, :cond_7a

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    invoke-virtual {v4, v3}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    move-object v3, v4

    .line 107
    .local v3, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v5, 0x0

    .line 86
    .local v5, "$i$a$-also-PlaceFactory$fromDocument$cam$1\\1\\86\\0":I
    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 87
    .end local v3    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v5    # "$i$a$-also-PlaceFactory$fromDocument$cam$1\\1\\86\\0":I
    .local v4, "cam":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_7a
    const/4 v3, 0x0

    invoke-virtual {v1, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 89
    .end local v4    # "cam":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_7e
    invoke-direct {p0, v1}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->ensureTerrain(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 90
    return-object v0
.end method

.method public final newPlace(Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;)Lcom/exampletest/mobilestudiotest/model/DataModel;
    .registers 31
    .param p1, "template"    # Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "template"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    new-instance v2, Lcom/exampletest/mobilestudiotest/model/DataModel;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/model/DataModel;-><init>()V

    .line 21
    .local v2, "dm":Lcom/exampletest/mobilestudiotest/model/DataModel;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getMeta()Ljava/util/LinkedHashMap;

    move-result-object v3

    check-cast v3, Ljava/util/Map;

    const-string v4, "ExplicitAutoJoints"

    const-string v5, "true"

    invoke-interface {v3, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    sget-object v3, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->required:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_21
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_31

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .local v4, "s":Ljava/lang/String;
    invoke-direct {v0, v2, v4}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->service(Lcom/exampletest/mobilestudiotest/model/DataModel;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_21

    .line 23
    .end local v4    # "s":Ljava/lang/String;
    :cond_31
    const-string v3, "Workspace"

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 24
    .local v3, "ws":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v4, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v5, "Camera"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    .line 25
    .local v4, "cam":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v5, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/4 v7, 0x0

    const/high16 v8, 0x42200000    # 40.0f

    const/high16 v11, 0x41a00000    # 20.0f

    invoke-direct {v6, v7, v11, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    sget-object v7, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    const/4 v9, 0x4

    const/4 v10, 0x0

    const/4 v8, 0x0

    invoke-static/range {v5 .. v10}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->lookAt$default(Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v5

    const-string v6, "CFrame"

    const/4 v7, 0x0

    invoke-virtual {v4, v6, v5, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 26
    invoke-virtual {v4, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 27
    const-string v5, "CurrentCamera"

    invoke-virtual {v3, v5, v4, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 28
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory;->ensureTerrain(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 30
    sget-object v5, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->EMPTY:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    const-string v8, "Color3uint8"

    if-eq v1, v5, :cond_163

    .line 31
    sget-object v5, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v9, "Part"

    invoke-virtual {v5, v9}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    .line 32
    .local v5, "base":Lcom/exampletest/mobilestudiotest/model/Instance;
    const-string v9, "Baseplate"

    invoke-virtual {v5, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->setName(Ljava/lang/String;)V

    .line 33
    const-string v9, "Anchored"

    const/4 v10, 0x1

    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    invoke-virtual {v5, v9, v12, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 34
    const-string v9, "Locked"

    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    invoke-virtual {v5, v9, v12, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 35
    sget-object v9, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->CLASSIC:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    const-string v12, "size"

    if-ne v1, v9, :cond_e1

    .line 36
    new-instance v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/high16 v10, 0x44000000    # 512.0f

    invoke-direct {v9, v10, v11, v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v5, v12, v9, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 37
    new-instance v13, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const/16 v26, 0xff8

    const/16 v27, 0x0

    const/4 v14, 0x0

    const/high16 v15, -0x3ee00000    # -10.0f

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    invoke-direct/range {v13 .. v27}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v5, v6, v13, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 38
    sget-object v9, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/16 v10, 0x5f

    const/16 v11, 0x62

    const/16 v12, 0x63

    invoke-virtual {v9, v12, v10, v11}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v9

    invoke-virtual {v5, v8, v9, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 39
    new-instance v9, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    const/4 v10, 0x3

    invoke-direct {v9, v10}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    const-string v10, "TopSurface"

    invoke-virtual {v5, v10, v9, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    goto/16 :goto_160

    .line 41
    :cond_e1
    new-instance v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/high16 v11, 0x41800000    # 16.0f

    const/high16 v13, 0x45000000    # 2048.0f

    invoke-direct {v9, v13, v11, v13}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v5, v12, v9, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 42
    new-instance v14, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const/16 v27, 0xff8

    const/16 v28, 0x0

    const/4 v15, 0x0

    const/high16 v16, -0x3f000000    # -8.0f

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    invoke-direct/range {v14 .. v28}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v5, v6, v14, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 43
    sget-object v9, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/16 v11, 0x5d

    const/16 v12, 0x69

    const/16 v13, 0x5b

    invoke-virtual {v9, v13, v11, v12}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v9

    invoke-virtual {v5, v8, v9, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 45
    sget-object v9, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v11, "Texture"

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v9

    move-object v12, v9

    .local v12, "$this$newPlace_u24lambda_u240\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v13, 0x0

    .line 46
    .local v13, "$i$a$-apply-PlaceFactory$newPlace$1\\1\\45\\0":I
    invoke-virtual {v12, v11}, Lcom/exampletest/mobilestudiotest/model/Instance;->setName(Ljava/lang/String;)V

    .line 47
    const-string v14, "rbxassetid://6372755229"

    invoke-virtual {v12, v11, v14, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 48
    new-instance v11, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-direct {v11, v10}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    const-string v10, "Face"

    invoke-virtual {v12, v10, v11, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 49
    const-string v10, "StudsPerTileU"

    const/high16 v11, 0x41000000    # 8.0f

    invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v14

    invoke-virtual {v12, v10, v14, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 50
    const-string v10, "StudsPerTileV"

    invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v11

    invoke-virtual {v12, v10, v11, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 51
    const v10, 0x3f4ccccd    # 0.8f

    invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v10

    const-string v11, "Transparency"

    invoke-virtual {v12, v11, v10, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 52
    nop

    .line 45
    .end local v12    # "$this$newPlace_u24lambda_u240\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v13    # "$i$a$-apply-PlaceFactory$newPlace$1\\1\\45\\0":I
    nop

    .line 52
    invoke-virtual {v9, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 54
    :goto_160
    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 57
    .end local v5    # "base":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_163
    sget-object v5, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v9, "SpawnLocation"

    invoke-virtual {v5, v9}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    .line 58
    .local v5, "spawn":Lcom/exampletest/mobilestudiotest/model/Instance;
    new-instance v9, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const/16 v22, 0xff8

    const/16 v23, 0x0

    const/4 v10, 0x0

    const/high16 v11, 0x3f000000    # 0.5f

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    invoke-direct/range {v9 .. v23}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v5, v6, v9, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 59
    sget-object v6, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/16 v9, 0xa2

    const/16 v10, 0xa5

    const/16 v11, 0xa3

    invoke-virtual {v6, v11, v9, v10}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v6

    invoke-virtual {v5, v8, v6, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set(Ljava/lang/String;Ljava/lang/Object;Z)V

    .line 60
    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 62
    const-string v6, "StarterPlayer"

    invoke-virtual {v2, v6}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v6

    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 63
    .local v6, "sp":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v7, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v8, "StarterPlayerScripts"

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    .line 107
    .local v7, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 63
    .local v8, "$i$a$-also-PlaceFactory$newPlace$2\\2\\63\\0":I
    invoke-virtual {v7, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 64
    .end local v7    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-also-PlaceFactory$newPlace$2\\2\\63\\0":I
    sget-object v7, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/InstanceFactory;

    const-string v8, "StarterCharacterScripts"

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/model/InstanceFactory;->create(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    .line 107
    .local v7, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 64
    .local v8, "$i$a$-also-PlaceFactory$newPlace$3\\3\\64\\0":I
    invoke-virtual {v7, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->attachRaw(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 65
    .end local v7    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-also-PlaceFactory$newPlace$3\\3\\64\\0":I
    return-object v2
.end method

###### Class com.exampletest.mobilestudiotest.core.PlaceFactory.Template (com.exampletest.mobilestudiotest.core.PlaceFactory$Template)
.class public final enum Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;
.super Ljava/lang/Enum;
.source "PlaceFactory.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/core/PlaceFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "Template"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\n\u0008\u0086\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0019\u0008\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0005\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008R\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\u0008j\u0002\u0008\nj\u0002\u0008\u000bj\u0002\u0008\u000c\u00a8\u0006\r"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;",
        "",
        "title",
        "",
        "subtitle",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V",
        "getTitle",
        "()Ljava/lang/String;",
        "getSubtitle",
        "BASEPLATE",
        "CLASSIC",
        "EMPTY",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

.field public static final enum BASEPLATE:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

.field public static final enum CLASSIC:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

.field public static final enum EMPTY:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;


# instance fields
.field private final subtitle:Ljava/lang/String;

.field private final title:Ljava/lang/String;


# direct methods
.method private static final synthetic $values()[Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;
    .registers 3

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->BASEPLATE:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    sget-object v1, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->CLASSIC:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    sget-object v2, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->EMPTY:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    filled-new-array {v0, v1, v2}, [Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 5

    .line 14
    new-instance v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    const-string v1, "Baseplate"

    const-string v2, "A large grey baseplate and a spawn"

    const-string v3, "BASEPLATE"

    const/4 v4, 0x0

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->BASEPLATE:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    .line 15
    new-instance v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    const-string v1, "Classic Baseplate"

    const-string v2, "The classic studded baseplate"

    const-string v3, "CLASSIC"

    const/4 v4, 0x1

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->CLASSIC:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    .line 16
    new-instance v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    const-string v1, "Empty Place"

    const-string v2, "Just a spawn location, no ground"

    const-string v3, "EMPTY"

    const/4 v4, 0x2

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->EMPTY:Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    invoke-static {}, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->$values()[Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->$VALUES:[Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->$VALUES:[Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .param p3, "title"    # Ljava/lang/String;
    .param p4, "subtitle"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 13
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->title:Ljava/lang/String;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->subtitle:Ljava/lang/String;

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;
    .registers 2

    const-class v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    return-object v0
.end method

.method public static values()[Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;
    .registers 1

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->$VALUES:[Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;

    return-object v0
.end method


# virtual methods
.method public final getSubtitle()Ljava/lang/String;
    .registers 2

    .line 13
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->subtitle:Ljava/lang/String;

    return-object v0
.end method

.method public final getTitle()Ljava/lang/String;
    .registers 2

    .line 13
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/core/PlaceFactory$Template;->title:Ljava/lang/String;

    return-object v0
.end method
