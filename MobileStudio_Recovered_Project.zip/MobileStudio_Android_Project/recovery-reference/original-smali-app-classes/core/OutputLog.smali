###### Class com.exampletest.mobilestudiotest.core.OutputLog (com.exampletest.mobilestudiotest.core.OutputLog)
.class public final Lcom/exampletest/mobilestudiotest/core/OutputLog;
.super Ljava/lang/Object;
.source "OutputLog.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;,
        Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nOutputLog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OutputLog.kt\ncom/exampletest/mobilestudiotest/core/OutputLog\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,34:1\n1#2:35\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\t\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0002\u001b\u001cB\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000c\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u000fJ\u0016\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014J\u0006\u0010\u0015\u001a\u00020\u000bJ\u000e\u0010\u0016\u001a\u00020\u000b2\u0006\u0010\u0017\u001a\u00020\u0014J\u000e\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\u0017\u001a\u00020\u0014J\u000e\u0010\u0019\u001a\u00020\u000b2\u0006\u0010\u0017\u001a\u00020\u0014J\u000e\u0010\u001a\u001a\u00020\u000b2\u0006\u0010\u0017\u001a\u00020\u0014R\u001e\u0010\u0004\u001a\u0012\u0012\u0004\u0012\u00020\u00060\u0005j\u0008\u0012\u0004\u0012\u00020\u0006`\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R%\u0010\u0008\u001a\u0016\u0012\u0012\u0012\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0006\u0012\u0004\u0012\u00020\u000b0\n0\t\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\r\u00a8\u0006\u001d"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/core/OutputLog;",
        "",
        "<init>",
        "()V",
        "entries",
        "Ljava/util/ArrayList;",
        "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
        "Lkotlin/collections/ArrayList;",
        "listeners",
        "Ljava/util/concurrent/CopyOnWriteArrayList;",
        "Lkotlin/Function1;",
        "",
        "getListeners",
        "()Ljava/util/concurrent/CopyOnWriteArrayList;",
        "snapshot",
        "",
        "add",
        "level",
        "Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;",
        "text",
        "",
        "clear",
        "print",
        "s",
        "info",
        "warn",
        "error",
        "Level",
        "Entry",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

.field private static final entries:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private static final listeners:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lkotlin/jvm/functions/Function1<",
            "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/core/OutputLog;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    .line 9
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    .line 10
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final add(Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;Ljava/lang/String;)V
    .registers 9
    .param p1, "level"    # Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;
    .param p2, "text"    # Ljava/lang/String;

    const-string v0, "level"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "text"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    new-instance v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-direct {v0, v1, v2, p1, p2}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;-><init>(JLcom/exampletest/mobilestudiotest/core/OutputLog$Level;Ljava/lang/String;)V

    .line 16
    .local v0, "e":Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    monitor-enter v1

    const/4 v2, 0x0

    .line 17
    .local v2, "$i$a$-synchronized-OutputLog$add$1\\1\\16\\0":I
    :try_start_17
    sget-object v3, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 18
    sget-object v3, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v4, 0xbb8

    if-le v3, v4, :cond_32

    sget-object v3, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/16 v5, 0x1f4

    invoke-virtual {v3, v4, v5}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->clear()V

    .line 19
    :cond_32
    nop

    .end local v2    # "$i$a$-synchronized-OutputLog$add$1\\1\\16\\0":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_35
    .catchall {:try_start_17 .. :try_end_35} :catchall_76

    .line 16
    monitor-exit v1

    .line 20
    :try_start_36
    const-string v1, "MobileStudio"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "["

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "] "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_58
    .catchall {:try_start_36 .. :try_end_58} :catchall_59

    goto :goto_5a

    :catchall_59
    move-exception v1

    .line 21
    :goto_5a
    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const-string v2, "iterator(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_65
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_75

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lkotlin/jvm/functions/Function1;

    .local v2, "l":Lkotlin/jvm/functions/Function1;
    invoke-interface {v2, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_65

    .line 22
    .end local v2    # "l":Lkotlin/jvm/functions/Function1;
    :cond_75
    return-void

    .line 16
    :catchall_76
    move-exception v2

    monitor-exit v1

    throw v2
.end method

.method public final clear()V
    .registers 4

    .line 25
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    monitor-enter v0

    .line 35
    const/4 v1, 0x0

    .line 25
    .local v1, "$i$a$-synchronized-OutputLog$clear$1\\1\\25\\0":I
    :try_start_4
    sget-object v2, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .end local v1    # "$i$a$-synchronized-OutputLog$clear$1\\1\\25\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_b
    .catchall {:try_start_4 .. :try_end_b} :catchall_29

    monitor-exit v0

    .line 26
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v1, "iterator(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_17
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_28

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function1;

    .local v1, "l":Lkotlin/jvm/functions/Function1;
    const/4 v2, 0x0

    invoke-interface {v1, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_17

    .line 27
    .end local v1    # "l":Lkotlin/jvm/functions/Function1;
    :cond_28
    return-void

    .line 25
    :catchall_29
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final error(Ljava/lang/String;)V
    .registers 3
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ERROR:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {p0, v0, p1}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->add(Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;Ljava/lang/String;)V

    return-void
.end method

.method public final getListeners()Ljava/util/concurrent/CopyOnWriteArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Lkotlin/jvm/functions/Function1<",
            "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
            "Lkotlin/Unit;",
            ">;>;"
        }
    .end annotation

    .line 10
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->listeners:Ljava/util/concurrent/CopyOnWriteArrayList;

    return-object v0
.end method

.method public final info(Ljava/lang/String;)V
    .registers 3
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->INFO:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {p0, v0, p1}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->add(Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;Ljava/lang/String;)V

    return-void
.end method

.method public final print(Ljava/lang/String;)V
    .registers 3
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->PRINT:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {p0, v0, p1}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->add(Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;Ljava/lang/String;)V

    return-void
.end method

.method public final snapshot()Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
            ">;"
        }
    .end annotation

    .line 12
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    monitor-enter v0

    .line 35
    const/4 v1, 0x0

    .line 12
    .local v1, "$i$a$-synchronized-OutputLog$snapshot$1\\1\\12\\0":I
    :try_start_4
    sget-object v2, Lcom/exampletest/mobilestudiotest/core/OutputLog;->entries:Ljava/util/ArrayList;

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2
    :try_end_c
    .catchall {:try_start_4 .. :try_end_c} :catchall_e

    .end local v1    # "$i$a$-synchronized-OutputLog$snapshot$1\\1\\12\\0":I
    monitor-exit v0

    return-object v2

    :catchall_e
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final warn(Ljava/lang/String;)V
    .registers 3
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->WARN:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {p0, v0, p1}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->add(Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;Ljava/lang/String;)V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.core.OutputLog.Entry (com.exampletest.mobilestudiotest.core.OutputLog$Entry)
.class public final Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;
.super Ljava/lang/Object;
.source "OutputLog.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/core/OutputLog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Entry"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\t\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0004\u0008\u0008\u0010\tR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u000f\u00a8\u0006\u0010"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;",
        "",
        "time",
        "",
        "level",
        "Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;",
        "text",
        "",
        "<init>",
        "(JLcom/exampletest/mobilestudiotest/core/OutputLog$Level;Ljava/lang/String;)V",
        "getTime",
        "()J",
        "getLevel",
        "()Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;",
        "getText",
        "()Ljava/lang/String;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final level:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

.field private final text:Ljava/lang/String;

.field private final time:J


# direct methods
.method public constructor <init>(JLcom/exampletest/mobilestudiotest/core/OutputLog$Level;Ljava/lang/String;)V
    .registers 6
    .param p1, "time"    # J
    .param p3, "level"    # Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;
    .param p4, "text"    # Ljava/lang/String;

    const-string v0, "level"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "text"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->time:J

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->level:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->text:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final getLevel()Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;
    .registers 2

    .line 7
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->level:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    return-object v0
.end method

.method public final getText()Ljava/lang/String;
    .registers 2

    .line 7
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->text:Ljava/lang/String;

    return-object v0
.end method

.method public final getTime()J
    .registers 3

    .line 7
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Entry;->time:J

    return-wide v0
.end method

###### Class com.exampletest.mobilestudiotest.core.OutputLog.Level (com.exampletest.mobilestudiotest.core.OutputLog$Level)
.class public final enum Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;
.super Ljava/lang/Enum;
.source "OutputLog.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/core/OutputLog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "Level"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0008\u0007\u0008\u0086\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003j\u0002\u0008\u0004j\u0002\u0008\u0005j\u0002\u0008\u0006j\u0002\u0008\u0007\u00a8\u0006\u0008"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;",
        "",
        "<init>",
        "(Ljava/lang/String;I)V",
        "PRINT",
        "INFO",
        "WARN",
        "ERROR",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

.field public static final enum ERROR:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

.field public static final enum INFO:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

.field public static final enum PRINT:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

.field public static final enum WARN:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;


# direct methods
.method private static final synthetic $values()[Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;
    .registers 4

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->PRINT:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->INFO:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    sget-object v2, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->WARN:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    sget-object v3, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ERROR:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    filled-new-array {v0, v1, v2, v3}, [Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 3

    .line 6
    new-instance v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    const-string v1, "PRINT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->PRINT:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    new-instance v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    const-string v1, "INFO"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->INFO:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    new-instance v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    const-string v1, "WARN"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->WARN:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    new-instance v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    const-string v1, "ERROR"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->ERROR:Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-static {}, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->$values()[Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->$VALUES:[Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->$VALUES:[Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 6
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;
    .registers 2

    const-class v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    return-object v0
.end method

.method public static values()[Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;
    .registers 1

    sget-object v0, Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;->$VALUES:[Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/exampletest/mobilestudiotest/core/OutputLog$Level;

    return-object v0
.end method
