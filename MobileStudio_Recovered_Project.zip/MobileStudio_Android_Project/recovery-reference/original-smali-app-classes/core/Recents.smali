###### Class com.exampletest.mobilestudiotest.core.Recents (com.exampletest.mobilestudiotest.core.Recents)
.class public final Lcom/exampletest/mobilestudiotest/core/Recents;
.super Ljava/lang/Object;
.source "Recents.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nRecents.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Recents.kt\ncom/exampletest/mobilestudiotest/core/Recents\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,55:1\n1563#2:56\n1634#2,2:57\n1636#2:60\n774#2:61\n865#2,2:62\n774#2:64\n865#2,2:65\n1#3:59\n*S KotlinDebug\n*F\n+ 1 Recents.kt\ncom/exampletest/mobilestudiotest/core/Recents\n*L\n31#1:56\n31#1:57,2\n31#1:60\n39#1:61\n39#1:62,2\n48#1:64\n48#1:65,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0004\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0001\u0010B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\n \u0006*\u0004\u0018\u00010\u00050\u00052\u0006\u0010\u0007\u001a\u00020\u0008H\u0002J\u0014\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\n2\u0006\u0010\u0007\u001a\u00020\u0008J\u0016\u0010\u000c\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u000bJ\u0016\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u000b\u00a8\u0006\u0011"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/core/Recents;",
        "",
        "<init>",
        "()V",
        "prefs",
        "Landroid/content/SharedPreferences;",
        "kotlin.jvm.PlatformType",
        "ctx",
        "Landroid/content/Context;",
        "list",
        "",
        "Lcom/exampletest/mobilestudiotest/core/Recents$Entry;",
        "add",
        "",
        "e",
        "remove",
        "Entry",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/core/Recents;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/exampletest/mobilestudiotest/core/Recents;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/core/Recents;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/core/Recents;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/Recents;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .registers 5
    .param p1, "ctx"    # Landroid/content/Context;

    .line 25
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "recents"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final add(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Recents$Entry;)V
    .registers 14
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "e"    # Lcom/exampletest/mobilestudiotest/core/Recents$Entry;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "e"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/core/Recents;->list(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 61
    .local v1, "$i$f$filter\\1\\39":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 62
    .local v4, "$i$f$filterTo\\2\\61":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_1e
    :goto_1e
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3e

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;

    .local v7, "it\\3":Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    const/4 v8, 0x0

    .line 39
    .local v8, "$i$a$-filter-Recents$add$l$1\\3\\62\\0":I
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->key()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->key()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    .line 62
    .end local v7    # "it\\3":Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    .end local v8    # "$i$a$-filter-Recents$add$l$1\\3\\62\\0":I
    if-nez v9, :cond_1e

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1e

    .line 63
    .end local v6    # "element\\2":Ljava/lang/Object;
    :cond_3e
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterTo\\2\\61":I
    check-cast v2, Ljava/util/List;

    .line 61
    nop

    .end local v0    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter\\1\\39":I
    check-cast v2, Ljava/util/Collection;

    .line 39
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->toMutableList(Ljava/util/Collection;)Ljava/util/List;

    move-result-object v0

    .line 40
    .local v0, "l":Ljava/util/List;
    const/4 v1, 0x0

    invoke-interface {v0, v1, p2}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 41
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    .line 42
    .local v1, "a":Lorg/json/JSONArray;
    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    const/16 v3, 0x28

    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_5e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_b3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;

    .local v3, "x":Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    const-string v5, "name"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "placeId"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getPlaceId()J

    move-result-wide v6

    invoke-virtual {v4, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "universeId"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getUniverseId()J

    move-result-wide v6

    invoke-virtual {v4, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v4

    .line 43
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getUri()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_95

    const-string v5, ""

    :cond_95
    const-string v6, "uri"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "time"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getTime()J

    move-result-wide v6

    invoke-virtual {v4, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "userId"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getUserId()J

    move-result-wide v6

    invoke-virtual {v4, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v4

    .line 42
    invoke-virtual {v1, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_5e

    .line 44
    .end local v3    # "x":Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    :cond_b3
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/core/Recents;->prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "list"

    invoke-virtual {v1}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 45
    return-void
.end method

.method public final list(Landroid/content/Context;)Ljava/util/List;
    .registers 29
    .param p1, "ctx"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/core/Recents$Entry;",
            ">;"
        }
    .end annotation

    const-string v0, "ctx"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/core/Recents;->prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "list"

    const/4 v3, 0x0

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_19

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0

    :cond_19
    move-object v2, v0

    .line 29
    .local v2, "raw":Ljava/lang/String;
    nop

    .line 30
    :try_start_1b
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0, v2}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 31
    .local v0, "a":Lorg/json/JSONArray;
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v4

    const/4 v5, 0x0

    invoke-static {v5, v4}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 56
    .local v6, "$i$f$map\\1\\31":I
    new-instance v7, Ljava/util/ArrayList;

    const/16 v8, 0xa

    invoke-static {v4, v8}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\2":Ljava/util/Collection;
    move-object v8, v4

    .local v8, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 57
    .local v9, "$i$f$mapTo\\2\\56":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_3f
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_9e

    move-object v11, v10

    check-cast v11, Lkotlin/collections/IntIterator;

    invoke-virtual {v11}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v11

    .line 58
    .local v11, "item\\2":I
    move v12, v11

    .local v12, "i\\3":I
    const/4 v13, 0x0

    .line 32
    .local v13, "$i$a$-map-Recents$list$1\\3\\58\\0":I
    invoke-virtual {v0, v12}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v14

    .line 33
    .local v14, "o\\3":Lorg/json/JSONObject;
    const-string v15, "name"

    invoke-virtual {v14, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const-string v3, "optString(...)"

    invoke-static {v15, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "placeId"

    invoke-virtual {v14, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v18

    const-string v3, "universeId"

    invoke-virtual {v14, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v20

    const-string v3, "uri"

    invoke-virtual {v14, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v16

    if-nez v16, :cond_7a

    const/16 v16, 0x1

    goto :goto_7c

    :cond_7a
    move/from16 v16, v5

    :goto_7c
    if-eqz v16, :cond_80

    .line 59
    const/4 v3, 0x0

    .line 33
    .local v3, "$i$a$-ifEmpty-Recents$list$1$1\\4\\33\\3":I
    const/4 v3, 0x0

    .end local v3    # "$i$a$-ifEmpty-Recents$list$1$1\\4\\33\\3":I
    :cond_80
    move-object/from16 v22, v3

    check-cast v22, Ljava/lang/String;

    const-string v3, "time"

    invoke-virtual {v14, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v23

    const-string v3, "userId"

    invoke-virtual {v14, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v25

    new-instance v16, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;

    move-object/from16 v17, v15

    invoke-direct/range {v16 .. v26}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;-><init>(Ljava/lang/String;JJLjava/lang/String;JJ)V

    move-object/from16 v3, v16

    .line 58
    .end local v12    # "i\\3":I
    .end local v13    # "$i$a$-map-Recents$list$1\\3\\58\\0":I
    .end local v14    # "o\\3":Lorg/json/JSONObject;
    invoke-interface {v7, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    goto :goto_3f

    .line 60
    .end local v11    # "item\\2":I
    :cond_9e
    nop

    .end local v7    # "destination\\2":Ljava/util/Collection;
    .end local v8    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapTo\\2\\56":I
    move-object v3, v7

    check-cast v3, Ljava/util/List;
    :try_end_a2
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_a2} :catch_a4

    .line 56
    nop

    .end local v0    # "a":Lorg/json/JSONArray;
    .end local v4    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v6    # "$i$f$map\\1\\31":I
    goto :goto_a9

    .line 35
    :catch_a4
    move-exception v0

    .local v0, "<unused var>":Ljava/lang/Exception;
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v3

    .line 29
    .end local v0    # "<unused var>":Ljava/lang/Exception;
    :goto_a9
    return-object v3
.end method

.method public final remove(Landroid/content/Context;Lcom/exampletest/mobilestudiotest/core/Recents$Entry;)V
    .registers 14
    .param p1, "ctx"    # Landroid/content/Context;
    .param p2, "e"    # Lcom/exampletest/mobilestudiotest/core/Recents$Entry;

    const-string v0, "ctx"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "e"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/core/Recents;->list(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 64
    .local v1, "$i$f$filter\\1\\48":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 65
    .local v4, "$i$f$filterTo\\2\\64":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_1e
    :goto_1e
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3e

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;

    .local v7, "it\\3":Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    const/4 v8, 0x0

    .line 48
    .local v8, "$i$a$-filter-Recents$remove$l$1\\3\\65\\0":I
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->key()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->key()Ljava/lang/String;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    .line 65
    .end local v7    # "it\\3":Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    .end local v8    # "$i$a$-filter-Recents$remove$l$1\\3\\65\\0":I
    if-nez v9, :cond_1e

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1e

    .line 66
    .end local v6    # "element\\2":Ljava/lang/Object;
    :cond_3e
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterTo\\2\\64":I
    check-cast v2, Ljava/util/List;

    .line 64
    nop

    .line 48
    .end local v0    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter\\1\\48":I
    nop

    .line 49
    .local v2, "l":Ljava/util/List;
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 50
    .local v0, "a":Lorg/json/JSONArray;
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_4c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_a1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;

    .local v3, "x":Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    new-instance v4, Lorg/json/JSONObject;

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    const-string v5, "name"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "placeId"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getPlaceId()J

    move-result-wide v6

    invoke-virtual {v4, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "universeId"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getUniverseId()J

    move-result-wide v6

    invoke-virtual {v4, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v4

    .line 51
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getUri()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_83

    const-string v5, ""

    :cond_83
    const-string v6, "uri"

    invoke-virtual {v4, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "time"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getTime()J

    move-result-wide v6

    invoke-virtual {v4, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "userId"

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->getUserId()J

    move-result-wide v6

    invoke-virtual {v4, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v4

    .line 50
    invoke-virtual {v0, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_4c

    .line 52
    .end local v3    # "x":Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
    :cond_a1
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/core/Recents;->prefs(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "list"

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v1, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 53
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.core.Recents.Entry (com.exampletest.mobilestudiotest.core.Recents$Entry)
.class public final Lcom/exampletest/mobilestudiotest/core/Recents$Entry;
.super Ljava/lang/Object;
.source "Recents.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/core/Recents;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Entry"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u000f\n\u0002\u0010\u000b\n\u0002\u0008\u0003\u0018\u00002\u00020\u0001BC\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0005\u0012\n\u0008\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u0012\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u0005\u0012\u0008\u0008\u0002\u0010\t\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\n\u0010\u000bJ\u0006\u0010\u0017\u001a\u00020\u0003R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0010\u0010\u000fR\u0013\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\rR\u0011\u0010\u0008\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u000fR\u0011\u0010\t\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u000fR\u0011\u0010\u0014\u001a\u00020\u00158F\u00a2\u0006\u0006\u001a\u0004\u0008\u0014\u0010\u0016\u00a8\u0006\u0018"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/core/Recents$Entry;",
        "",
        "name",
        "",
        "placeId",
        "",
        "universeId",
        "uri",
        "time",
        "userId",
        "<init>",
        "(Ljava/lang/String;JJLjava/lang/String;JJ)V",
        "getName",
        "()Ljava/lang/String;",
        "getPlaceId",
        "()J",
        "getUniverseId",
        "getUri",
        "getTime",
        "getUserId",
        "isCloud",
        "",
        "()Z",
        "key",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final name:Ljava/lang/String;

.field private final placeId:J

.field private final time:J

.field private final universeId:J

.field private final uri:Ljava/lang/String;

.field private final userId:J


# direct methods
.method public constructor <init>(Ljava/lang/String;JJLjava/lang/String;JJ)V
    .registers 12
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "placeId"    # J
    .param p4, "universeId"    # J
    .param p6, "uri"    # Ljava/lang/String;
    .param p7, "time"    # J
    .param p9, "userId"    # J

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->name:Ljava/lang/String;

    .line 14
    iput-wide p2, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->placeId:J

    .line 15
    iput-wide p4, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->universeId:J

    .line 16
    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->uri:Ljava/lang/String;

    .line 17
    iput-wide p7, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->time:J

    .line 19
    iput-wide p9, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->userId:J

    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;JJLjava/lang/String;JJILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 15

    .line 12
    and-int/lit8 p12, p11, 0x2

    const-wide/16 v0, 0x0

    if-eqz p12, :cond_7

    .line 14
    move-wide p2, v0

    .line 12
    :cond_7
    and-int/lit8 p12, p11, 0x4

    if-eqz p12, :cond_c

    .line 15
    move-wide p4, v0

    .line 12
    :cond_c
    and-int/lit8 p12, p11, 0x8

    if-eqz p12, :cond_11

    .line 16
    const/4 p6, 0x0

    .line 12
    :cond_11
    and-int/lit8 p12, p11, 0x10

    if-eqz p12, :cond_19

    .line 17
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p7

    .line 12
    :cond_19
    and-int/lit8 p11, p11, 0x20

    if-eqz p11, :cond_1f

    .line 19
    move-wide p10, v0

    goto :goto_20

    .line 12
    :cond_1f
    move-wide p10, p9

    :goto_20
    move-wide p8, p7

    move-object p7, p6

    move-wide p5, p4

    move-wide p3, p2

    move-object p2, p1

    move-object p1, p0

    invoke-direct/range {p1 .. p11}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;-><init>(Ljava/lang/String;JJLjava/lang/String;JJ)V

    .line 20
    return-void
.end method


# virtual methods
.method public final getName()Ljava/lang/String;
    .registers 2

    .line 13
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final getPlaceId()J
    .registers 3

    .line 14
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->placeId:J

    return-wide v0
.end method

.method public final getTime()J
    .registers 3

    .line 17
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->time:J

    return-wide v0
.end method

.method public final getUniverseId()J
    .registers 3

    .line 15
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->universeId:J

    return-wide v0
.end method

.method public final getUri()Ljava/lang/String;
    .registers 2

    .line 16
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->uri:Ljava/lang/String;

    return-object v0
.end method

.method public final getUserId()J
    .registers 3

    .line 19
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->userId:J

    return-wide v0
.end method

.method public final isCloud()Z
    .registers 5

    .line 21
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->placeId:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-eqz v0, :cond_a

    const/4 v0, 0x1

    goto :goto_b

    :cond_a
    const/4 v0, 0x0

    :goto_b
    return v0
.end method

.method public final key()Ljava/lang/String;
    .registers 5

    .line 22
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->isCloud()Z

    move-result v0

    if-eqz v0, :cond_18

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->placeId:J

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "p:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    goto :goto_29

    :cond_18
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/core/Recents$Entry;->uri:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "f:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    :goto_29
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
