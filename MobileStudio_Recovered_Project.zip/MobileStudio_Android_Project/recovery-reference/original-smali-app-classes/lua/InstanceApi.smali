###### Class com.exampletest.mobilestudiotest.lua.InstanceApi (com.exampletest.mobilestudiotest.lua.InstanceApi)
.class public final Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
.super Ljava/lang/Object;
.source "InstanceApi.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInstanceApi.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InstanceApi.kt\ncom/exampletest/mobilestudiotest/lua/InstanceApi\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 5 LuaTypes.kt\ncom/exampletest/mobilestudiotest/lua/LuaTypesKt\n*L\n1#1,1016:1\n1#2:1017\n382#3,7:1018\n382#3,7:1028\n2746#4,3:1025\n774#4:1035\n865#4,2:1036\n295#4,2:1040\n1869#4,2:1045\n295#4,2:1047\n1869#4,2:1049\n774#4:1051\n865#4,2:1052\n1869#4,2:1055\n774#4:1063\n865#4,2:1064\n774#4:1067\n865#4,2:1068\n774#4:1071\n865#4,2:1072\n1761#4,3:1076\n774#4:1080\n865#4,2:1081\n1761#4,3:1083\n1878#4,3:1095\n774#4:1099\n865#4,2:1100\n1761#4,3:1102\n1761#4,3:1105\n41#5:1038\n41#5:1039\n41#5:1042\n41#5:1043\n41#5:1044\n41#5:1054\n40#5:1057\n40#5:1058\n40#5:1059\n40#5:1060\n41#5:1061\n40#5:1062\n40#5:1066\n40#5:1070\n40#5:1074\n41#5:1075\n41#5:1079\n40#5:1086\n40#5:1087\n40#5:1088\n40#5:1089\n40#5:1090\n40#5:1091\n40#5:1092\n41#5:1093\n41#5:1094\n41#5:1098\n*S KotlinDebug\n*F\n+ 1 InstanceApi.kt\ncom/exampletest/mobilestudiotest/lua/InstanceApi\n*L\n453#1:1018,7\n483#1:1028,7\n473#1:1025,3\n554#1:1035\n554#1:1036,2\n649#1:1040,2\n741#1:1045,2\n765#1:1047,2\n770#1:1049,2\n781#1:1051\n781#1:1052,2\n788#1:1055,2\n821#1:1063\n821#1:1064,2\n826#1:1067\n826#1:1068,2\n837#1:1071\n837#1:1072,2\n851#1:1076,3\n875#1:1080\n875#1:1081,2\n876#1:1083,3\n963#1:1095,3\n970#1:1099\n970#1:1100,2\n586#1:1102,3\n810#1:1105,3\n571#1:1038\n583#1:1039\n715#1:1042\n733#1:1043\n734#1:1044\n783#1:1054\n795#1:1057\n797#1:1058\n798#1:1059\n801#1:1060\n804#1:1061\n818#1:1062\n824#1:1066\n834#1:1070\n840#1:1074\n844#1:1075\n866#1:1079\n883#1:1086\n891#1:1087\n893#1:1088\n898#1:1089\n924#1:1090\n950#1:1091\n951#1:1092\n953#1:1093\n962#1:1094\n964#1:1098\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00a6\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\"\n\u0000\n\u0002\u0010$\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0007\n\u0002\u0010 \n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010!\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0016\u0010\u001e\u001a\u00020\u000b2\u0006\u0010\u001f\u001a\u00020\u00012\u0006\u0010 \u001a\u00020\nJ\u0010\u0010!\u001a\u00020\u000b2\u0006\u0010\"\u001a\u00020#H\u0002J\u0018\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020\'2\u0006\u0010 \u001a\u00020\nH\u0002J\u0010\u0010(\u001a\u00020%2\u0006\u0010)\u001a\u00020\'H\u0002J\u0018\u0010*\u001a\u0004\u0018\u00010\u00012\u0006\u0010&\u001a\u00020\'2\u0006\u0010 \u001a\u00020\nJ\u0016\u0010+\u001a\u00020%2\u0006\u0010&\u001a\u00020\'2\u0006\u0010 \u001a\u00020\nJ \u00100\u001a\u0002012\u0006\u0010&\u001a\u00020\'2\u0006\u0010 \u001a\u00020\n2\u0008\u00102\u001a\u0004\u0018\u00010\u0001J\u001f\u00103\u001a\u0004\u0018\u0001042\u0006\u0010&\u001a\u00020\'2\u0006\u0010 \u001a\u00020\nH\u0002\u00a2\u0006\u0002\u00105J\u0016\u00106\u001a\u00020\u000b2\u0006\u0010&\u001a\u00020\'2\u0006\u00107\u001a\u00020\nJ\u001e\u00108\u001a\u0002012\u0006\u0010&\u001a\u00020\'2\u0006\u00109\u001a\u00020\n2\u0006\u0010:\u001a\u00020\u000bJ\u0014\u0010;\u001a\u0008\u0012\u0004\u0012\u00020\'0<2\u0006\u0010)\u001a\u00020\'J\u001a\u0010=\u001a\u0004\u0018\u00010\n2\u0006\u0010&\u001a\u00020\'2\u0006\u00109\u001a\u00020\nH\u0002J\u000e\u0010>\u001a\u00020?2\u0006\u0010@\u001a\u00020\'J\u0016\u0010A\u001a\u0002012\u0006\u0010B\u001a\u00020\'2\u0006\u0010C\u001a\u00020?J\u0016\u0010D\u001a\u0008\u0012\u0004\u0012\u00020\n0E2\u0006\u0010)\u001a\u00020\'H\u0002J\u001e\u0010F\u001a\u0002012\u0006\u0010)\u001a\u00020\'2\u000c\u0010G\u001a\u0008\u0012\u0004\u0012\u00020\n0<H\u0002J\u0016\u0010H\u001a\u00020\u00112\u000c\u0010I\u001a\u0008\u0012\u0004\u0012\u00020\'0<H\u0002J\u0016\u0010J\u001a\u0008\u0012\u0004\u0012\u00020\'0<2\u0006\u0010:\u001a\u00020\u000bH\u0002J\u000e\u0010K\u001a\u0008\u0012\u0004\u0012\u00020\'0<H\u0002J\u001c\u0010L\u001a\u000e\u0012\u0004\u0012\u00020\'\u0012\u0004\u0012\u00020%0M2\u0006\u0010N\u001a\u00020\u000bH\u0002J,\u0010O\u001a\u00020\u000b2\u0006\u0010P\u001a\u00020Q2\u0006\u0010R\u001a\u00020Q2\u0012\u0010S\u001a\u000e\u0012\u0004\u0012\u00020\'\u0012\u0004\u0012\u00020%0MH\u0002J\u0010\u0010U\u001a\u00020%2\u0006\u0010V\u001a\u00020\'H\u0002J\u0010\u0010Y\u001a\u00020Z2\u0006\u0010:\u001a\u000204H\u0002J\u001a\u0010[\u001a\u00020\u00112\u0006\u0010\u001f\u001a\u00020\'2\u0008\u0010\\\u001a\u0004\u0018\u00010\'H\u0002J\u0018\u0010]\u001a\u00020\'2\u0006\u0010^\u001a\u00020_2\u0006\u0010 \u001a\u00020\nH\u0002J\u0016\u0010`\u001a\u00020_2\u0006\u0010 \u001a\u00020\n2\u0006\u0010^\u001a\u00020_J\u0016\u0010a\u001a\u00020_2\u0006\u0010 \u001a\u00020\n2\u0006\u0010^\u001a\u00020_J\u0016\u0010b\u001a\u00020_2\u0006\u0010 \u001a\u00020\n2\u0006\u0010^\u001a\u00020_J\u001e\u0010c\u001a\u00020_2\u0006\u0010&\u001a\u00020\'2\u0006\u0010 \u001a\u00020\n2\u0006\u0010^\u001a\u00020_J\u001e\u0010d\u001a\u00020_2\u0006\u0010&\u001a\u00020\'2\u0006\u0010 \u001a\u00020\n2\u0006\u0010^\u001a\u00020_J\u001e\u0010e\u001a\u00020_2\u0006\u0010&\u001a\u00020\'2\u0006\u0010 \u001a\u00020\n2\u0006\u0010^\u001a\u00020_R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007R*\u0010\u0008\u001a\u001e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\tj\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b`\u000cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\n0\u000ej\u0008\u0012\u0004\u0012\u00020\n`\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0010\u001a\u00020\u0011\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0013R\u000e\u0010\u0014\u001a\u00020\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0015\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010\u0017\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\n0\u00160\u0018X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001a\u0010\u001bR\u0014\u0010\u001c\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001d\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010,\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010-\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010.\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010/\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\n0\u00160\u0018X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010T\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\n0<0\u0018X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010W\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u0002040X0<X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006f"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;",
        "",
        "rt",
        "Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;)V",
        "getRt",
        "()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;",
        "methodCache",
        "Ljava/util/HashMap;",
        "",
        "Lorg/luaj/vm2/LuaValue;",
        "Lkotlin/collections/HashMap;",
        "warnedMissing",
        "Ljava/util/HashSet;",
        "Lkotlin/collections/HashSet;",
        "signalMeta",
        "Lorg/luaj/vm2/LuaTable;",
        "getSignalMeta",
        "()Lorg/luaj/vm2/LuaTable;",
        "connMeta",
        "commonMethods",
        "",
        "classMethods",
        "",
        "events",
        "getEvents",
        "()Ljava/util/Set;",
        "sequenceClasses",
        "universalEvents",
        "signal",
        "owner",
        "name",
        "connectionValue",
        "c",
        "Lcom/exampletest/mobilestudiotest/lua/Connection;",
        "methodAllowed",
        "",
        "inst",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "isPart",
        "i",
        "getK",
        "hasK",
        "CONSTRAINT_READOUTS",
        "BASE_PROPS",
        "PART_PROPS",
        "SPECIAL_PROPS",
        "setK",
        "",
        "value",
        "typeHint",
        "",
        "(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Integer;",
        "index",
        "key0",
        "newIndex",
        "key",
        "v",
        "partsIn",
        "",
        "contentAlias",
        "modelPivot",
        "Lcom/exampletest/mobilestudiotest/model/CFrame;",
        "m",
        "pivotTo",
        "target",
        "cf",
        "tags",
        "",
        "setTags",
        "t",
        "listToLua",
        "l",
        "instList",
        "workspaceParts",
        "filterFrom",
        "Lkotlin/Function1;",
        "params",
        "raycastResult",
        "o",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "d",
        "filter",
        "MEMBER_OWNERS",
        "isEditCamera",
        "cam",
        "PRIORITIES",
        "Lkotlin/Pair;",
        "priorityItem",
        "Lcom/exampletest/mobilestudiotest/lua/EnumItemV;",
        "animationTrack",
        "anim",
        "self",
        "a",
        "Lorg/luaj/vm2/Varargs;",
        "callMethod",
        "collectionCall",
        "workspaceCall",
        "modelCall",
        "partCall",
        "humanoidCall",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final BASE_PROPS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final CONSTRAINT_READOUTS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final MEMBER_OWNERS:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private final PART_PROPS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final PRIORITIES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;>;"
        }
    .end annotation
.end field

.field private final SPECIAL_PROPS:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private final classMethods:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private final commonMethods:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final connMeta:Lorg/luaj/vm2/LuaTable;

.field private final events:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final methodCache:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lorg/luaj/vm2/LuaValue;",
            ">;"
        }
    .end annotation
.end field

.field private final rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

.field private final sequenceClasses:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final signalMeta:Lorg/luaj/vm2/LuaTable;

.field private final universalEvents:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final warnedMissing:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;)V
    .registers 34
    .param p1, "rt"    # Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "rt"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    .line 17
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->methodCache:Ljava/util/HashMap;

    .line 18
    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->warnedMissing:Ljava/util/HashSet;

    .line 19
    new-instance v2, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v2}, Lorg/luaj/vm2/LuaTable;-><init>()V

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signalMeta:Lorg/luaj/vm2/LuaTable;

    .line 20
    new-instance v2, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v2}, Lorg/luaj/vm2/LuaTable;-><init>()V

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->connMeta:Lorg/luaj/vm2/LuaTable;

    .line 22
    nop

    .line 23
    const/16 v2, 0x21

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "FindFirstChild"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-string v3, "FindFirstChildOfClass"

    const/4 v5, 0x1

    aput-object v3, v2, v5

    const-string v3, "FindFirstChildWhichIsA"

    const/4 v6, 0x2

    aput-object v3, v2, v6

    const-string v3, "FindFirstAncestor"

    const/4 v7, 0x3

    aput-object v3, v2, v7

    const-string v3, "FindFirstAncestorOfClass"

    const/4 v8, 0x4

    aput-object v3, v2, v8

    .line 24
    const-string v3, "FindFirstAncestorWhichIsA"

    const/4 v9, 0x5

    aput-object v3, v2, v9

    .line 23
    nop

    .line 24
    const-string v3, "FindFirstDescendant"

    const/4 v10, 0x6

    aput-object v3, v2, v10

    .line 23
    nop

    .line 24
    const-string v3, "WaitForChild"

    const/4 v11, 0x7

    aput-object v3, v2, v11

    .line 23
    nop

    .line 24
    const-string v3, "GetChildren"

    const/16 v12, 0x8

    aput-object v3, v2, v12

    .line 23
    nop

    .line 24
    const-string v3, "GetDescendants"

    const/16 v13, 0x9

    aput-object v3, v2, v13

    .line 23
    nop

    .line 24
    const-string v3, "IsA"

    const/16 v14, 0xa

    aput-object v3, v2, v14

    .line 23
    nop

    .line 24
    const-string v3, "IsDescendantOf"

    const/16 v15, 0xb

    aput-object v3, v2, v15

    .line 23
    nop

    .line 25
    const-string v3, "IsAncestorOf"

    move/from16 v16, v4

    const/16 v4, 0xc

    aput-object v3, v2, v4

    .line 23
    nop

    .line 25
    const-string v3, "Destroy"

    const/16 v17, 0xd

    aput-object v3, v2, v17

    .line 23
    nop

    .line 25
    const-string v3, "Remove"

    move/from16 v18, v5

    const/16 v5, 0xe

    aput-object v3, v2, v5

    .line 23
    nop

    .line 25
    const-string v3, "Clone"

    move/from16 v19, v14

    const/16 v14, 0xf

    aput-object v3, v2, v14

    .line 23
    nop

    .line 25
    const-string v3, "ClearAllChildren"

    const/16 v20, 0x10

    aput-object v3, v2, v20

    .line 23
    nop

    .line 25
    const-string v3, "GetFullName"

    move/from16 v21, v15

    const/16 v15, 0x11

    aput-object v3, v2, v15

    .line 23
    nop

    .line 25
    const-string v3, "GetAttribute"

    const/16 v22, 0x12

    aput-object v3, v2, v22

    .line 23
    nop

    .line 25
    const-string v3, "SetAttribute"

    move/from16 v23, v9

    const/16 v9, 0x13

    aput-object v3, v2, v9

    .line 23
    nop

    .line 25
    const-string v3, "GetAttributes"

    const/16 v24, 0x14

    aput-object v3, v2, v24

    .line 23
    nop

    .line 26
    const-string v3, "GetAttributeChangedSignal"

    move/from16 v25, v9

    const/16 v9, 0x15

    aput-object v3, v2, v9

    .line 23
    nop

    .line 26
    const-string v3, "GetPropertyChangedSignal"

    const/16 v26, 0x16

    aput-object v3, v2, v26

    .line 23
    nop

    .line 26
    const-string v3, "GetService"

    const/16 v26, 0x17

    aput-object v3, v2, v26

    .line 23
    nop

    .line 26
    const-string v3, "FindService"

    const/16 v26, 0x18

    aput-object v3, v2, v26

    .line 23
    nop

    .line 26
    const-string v3, "GetTags"

    const/16 v26, 0x19

    aput-object v3, v2, v26

    .line 23
    nop

    .line 26
    const-string v3, "HasTag"

    const/16 v26, 0x1a

    aput-object v3, v2, v26

    .line 23
    nop

    .line 26
    const-string v3, "AddTag"

    const/16 v26, 0x1b

    aput-object v3, v2, v26

    .line 23
    nop

    .line 26
    const-string v3, "RemoveTag"

    const/16 v26, 0x1c

    aput-object v3, v2, v26

    .line 23
    nop

    .line 27
    const-string v3, "GetActor"

    const/16 v26, 0x1d

    aput-object v3, v2, v26

    .line 23
    nop

    .line 27
    const-string v3, "GetDebugId"

    const/16 v26, 0x1e

    aput-object v3, v2, v26

    .line 23
    nop

    .line 27
    const-string v3, "IsPropertyModified"

    const/16 v26, 0x1f

    aput-object v3, v2, v26

    .line 23
    nop

    .line 27
    const-string v3, "ResetPropertyToDefault"

    const/16 v26, 0x20

    aput-object v3, v2, v26

    .line 23
    nop

    .line 22
    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->commonMethods:Ljava/util/Set;

    .line 30
    nop

    .line 31
    const/16 v2, 0x38

    new-array v2, v2, [Lkotlin/Pair;

    new-array v3, v15, [Ljava/lang/String;

    const-string v26, "GetMass"

    aput-object v26, v3, v16

    const-string v26, "ApplyImpulse"

    aput-object v26, v3, v18

    const-string v26, "ApplyAngularImpulse"

    aput-object v26, v3, v6

    const-string v26, "GetConnectedParts"

    aput-object v26, v3, v7

    const-string v26, "GetTouchingParts"

    aput-object v26, v3, v8

    const-string v26, "GetRootPart"

    aput-object v26, v3, v23

    .line 32
    const-string v26, "SetNetworkOwner"

    aput-object v26, v3, v10

    .line 31
    nop

    .line 32
    const-string v26, "GetNetworkOwner"

    aput-object v26, v3, v11

    .line 31
    nop

    .line 32
    const-string v26, "CanSetNetworkOwnership"

    aput-object v26, v3, v12

    .line 31
    nop

    .line 32
    const-string v26, "BreakJoints"

    aput-object v26, v3, v13

    .line 31
    nop

    .line 32
    const-string v26, "MakeJoints"

    aput-object v26, v3, v19

    .line 31
    nop

    .line 32
    const-string v26, "Resize"

    aput-object v26, v3, v21

    .line 31
    nop

    .line 32
    const-string v26, "GetVelocityAtPosition"

    aput-object v26, v3, v4

    .line 31
    nop

    .line 33
    const-string v26, "GetPivot"

    aput-object v26, v3, v17

    .line 31
    nop

    .line 33
    const-string v26, "PivotTo"

    aput-object v26, v3, v5

    .line 31
    nop

    .line 33
    const-string v26, "IsGrounded"

    aput-object v26, v3, v14

    .line 31
    nop

    .line 33
    const-string v26, "GetJoints"

    aput-object v26, v3, v20

    .line 31
    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    move/from16 v26, v15

    const-string v15, "BasePart"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v16

    .line 34
    new-array v3, v5, [Ljava/lang/String;

    const-string v15, "GetPivot"

    aput-object v15, v3, v16

    const-string v15, "PivotTo"

    aput-object v15, v3, v18

    const-string v15, "MoveTo"

    aput-object v15, v3, v6

    const-string v15, "SetPrimaryPartCFrame"

    aput-object v15, v3, v7

    const-string v15, "GetPrimaryPartCFrame"

    aput-object v15, v3, v8

    const-string v15, "GetBoundingBox"

    aput-object v15, v3, v23

    const-string v15, "GetExtentsSize"

    aput-object v15, v3, v10

    .line 35
    const-string v15, "BreakJoints"

    aput-object v15, v3, v11

    .line 34
    nop

    .line 35
    const-string v15, "MakeJoints"

    aput-object v15, v3, v12

    .line 34
    nop

    .line 35
    const-string v15, "TranslateBy"

    aput-object v15, v3, v13

    .line 34
    nop

    .line 35
    const-string v15, "GetModelCFrame"

    aput-object v15, v3, v19

    .line 34
    nop

    .line 35
    const-string v15, "GetModelSize"

    aput-object v15, v3, v21

    .line 34
    nop

    .line 35
    const-string v15, "ScaleTo"

    aput-object v15, v3, v4

    .line 34
    nop

    .line 35
    const-string v15, "GetScale"

    aput-object v15, v3, v17

    .line 34
    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Model"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v18

    .line 31
    nop

    .line 36
    new-array v3, v14, [Ljava/lang/String;

    const-string v15, "TakeDamage"

    aput-object v15, v3, v16

    const-string v15, "MoveTo"

    aput-object v15, v3, v18

    const-string v15, "ChangeState"

    aput-object v15, v3, v6

    const-string v15, "GetState"

    aput-object v15, v3, v7

    const-string v15, "LoadAnimation"

    aput-object v15, v3, v8

    const-string v15, "EquipTool"

    aput-object v15, v3, v23

    const-string v15, "UnequipTools"

    aput-object v15, v3, v10

    .line 37
    const-string v15, "GetPlayingAnimationTracks"

    aput-object v15, v3, v11

    .line 36
    nop

    .line 37
    const-string v15, "SetStateEnabled"

    aput-object v15, v3, v12

    .line 36
    nop

    .line 37
    const-string v15, "GetStateEnabled"

    aput-object v15, v3, v13

    .line 36
    nop

    .line 37
    const-string v15, "Move"

    aput-object v15, v3, v19

    .line 36
    nop

    .line 37
    const-string v15, "ApplyDescription"

    aput-object v15, v3, v21

    .line 36
    nop

    .line 37
    const-string v15, "GetAppliedDescription"

    aput-object v15, v3, v4

    .line 36
    nop

    .line 37
    const-string v15, "AddAccessory"

    aput-object v15, v3, v17

    .line 36
    nop

    .line 37
    const-string v15, "GetAccessories"

    aput-object v15, v3, v5

    .line 36
    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Humanoid"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v6

    .line 31
    nop

    .line 38
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "LoadAnimation"

    aput-object v15, v3, v16

    const-string v15, "GetPlayingAnimationTracks"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Animator"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v7

    .line 31
    nop

    .line 39
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "LoadAnimation"

    aput-object v15, v3, v16

    const-string v15, "GetPlayingAnimationTracks"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "AnimationController"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v8

    .line 31
    nop

    .line 40
    const/16 v3, 0x1c

    new-array v3, v3, [Ljava/lang/String;

    const-string v15, "Raycast"

    aput-object v15, v3, v16

    const-string v15, "FindPartOnRay"

    aput-object v15, v3, v18

    const-string v15, "FindPartOnRayWithIgnoreList"

    aput-object v15, v3, v6

    const-string v15, "FindPartOnRayWithWhitelist"

    aput-object v15, v3, v7

    const-string v15, "GetPartBoundsInBox"

    aput-object v15, v3, v8

    .line 41
    const-string v15, "GetPartBoundsInRadius"

    aput-object v15, v3, v23

    .line 40
    nop

    .line 41
    const-string v15, "GetPartsInPart"

    aput-object v15, v3, v10

    .line 40
    nop

    .line 41
    const-string v15, "GetServerTimeNow"

    aput-object v15, v3, v11

    .line 40
    nop

    .line 41
    const-string v15, "GetRealPhysicsFPS"

    aput-object v15, v3, v12

    .line 40
    nop

    .line 41
    const-string v15, "Spherecast"

    aput-object v15, v3, v13

    .line 40
    nop

    .line 41
    const-string v15, "Blockcast"

    aput-object v15, v3, v19

    .line 40
    nop

    .line 41
    const-string v15, "FindPartsInRegion3"

    aput-object v15, v3, v21

    .line 40
    nop

    .line 42
    const-string v15, "FindPartsInRegion3WithIgnoreList"

    aput-object v15, v3, v4

    .line 40
    nop

    .line 42
    const-string v15, "FindPartsInRegion3WithWhiteList"

    aput-object v15, v3, v17

    .line 40
    nop

    .line 42
    const-string v15, "IsRegion3Empty"

    aput-object v15, v3, v5

    .line 40
    nop

    .line 42
    const-string v15, "IsRegion3EmptyWithIgnoreList"

    aput-object v15, v3, v14

    .line 40
    nop

    .line 43
    const-string v15, "JoinToOutsiders"

    aput-object v15, v3, v20

    .line 40
    nop

    .line 43
    const-string v15, "UnjoinFromOutsiders"

    aput-object v15, v3, v26

    .line 40
    nop

    .line 43
    const-string v15, "BulkMoveTo"

    aput-object v15, v3, v22

    .line 40
    nop

    .line 43
    const-string v15, "ArePartsTouchingOthers"

    aput-object v15, v3, v25

    .line 40
    nop

    .line 43
    const-string v15, "GetNumAwakeParts"

    aput-object v15, v3, v24

    .line 40
    nop

    .line 43
    const-string v15, "PGSIsEnabled"

    aput-object v15, v3, v9

    .line 40
    nop

    .line 44
    const-string v15, "SetInsertPoint"

    const/16 v27, 0x16

    aput-object v15, v3, v27

    .line 40
    nop

    .line 44
    const-string v15, "ZoomToExtents"

    const/16 v27, 0x17

    aput-object v15, v3, v27

    .line 40
    nop

    .line 44
    const-string v15, "CalculateJumpPower"

    const/16 v27, 0x18

    aput-object v15, v3, v27

    .line 40
    nop

    .line 44
    const-string v15, "CalculateJumpHeight"

    const/16 v27, 0x19

    aput-object v15, v3, v27

    .line 40
    nop

    .line 44
    const-string v15, "GetPhysicsThrottling"

    const/16 v27, 0x1a

    aput-object v15, v3, v27

    .line 40
    nop

    .line 44
    const-string v15, "Shapecast"

    const/16 v27, 0x1b

    aput-object v15, v3, v27

    .line 40
    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Workspace"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v23

    .line 31
    nop

    .line 45
    new-array v3, v11, [Ljava/lang/String;

    const-string v15, "GetPlayers"

    aput-object v15, v3, v16

    const-string v15, "GetPlayerFromCharacter"

    aput-object v15, v3, v18

    const-string v15, "GetPlayerByUserId"

    aput-object v15, v3, v6

    const-string v15, "GetUserIdFromNameAsync"

    aput-object v15, v3, v7

    const-string v15, "GetNameFromUserIdAsync"

    aput-object v15, v3, v8

    .line 46
    const-string v15, "GetUserThumbnailAsync"

    aput-object v15, v3, v23

    .line 45
    nop

    .line 46
    const-string v15, "GetHumanoidDescriptionFromUserId"

    aput-object v15, v3, v10

    .line 45
    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Players"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v10

    .line 31
    nop

    .line 47
    new-array v3, v4, [Ljava/lang/String;

    const-string v15, "Kick"

    aput-object v15, v3, v16

    const-string v15, "LoadCharacter"

    aput-object v15, v3, v18

    const-string v15, "GetMouse"

    aput-object v15, v3, v6

    const-string v15, "IsInGroup"

    aput-object v15, v3, v7

    const-string v15, "GetRankInGroup"

    aput-object v15, v3, v8

    const-string v15, "GetRoleInGroup"

    aput-object v15, v3, v23

    const-string v15, "DistanceFromCharacter"

    aput-object v15, v3, v10

    .line 48
    const-string v15, "IsFriendsWith"

    aput-object v15, v3, v11

    .line 47
    nop

    .line 48
    const-string v15, "HasAppearanceLoaded"

    aput-object v15, v3, v12

    .line 47
    nop

    .line 48
    const-string v15, "GetJoinData"

    aput-object v15, v3, v13

    .line 47
    nop

    .line 48
    const-string v15, "ClearCharacterAppearance"

    aput-object v15, v3, v19

    .line 47
    nop

    .line 48
    const-string v15, "GetNetworkPing"

    aput-object v15, v3, v21

    .line 47
    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Player"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v11

    .line 31
    nop

    .line 49
    new-array v3, v12, [Ljava/lang/String;

    const-string v15, "IsStudio"

    aput-object v15, v3, v16

    const-string v15, "IsRunning"

    aput-object v15, v3, v18

    const-string v15, "IsServer"

    aput-object v15, v3, v6

    const-string v15, "IsClient"

    aput-object v15, v3, v7

    const-string v15, "IsEdit"

    aput-object v15, v3, v8

    const-string v15, "IsRunMode"

    aput-object v15, v3, v23

    const-string v15, "BindToRenderStep"

    aput-object v15, v3, v10

    const-string v15, "UnbindFromRenderStep"

    aput-object v15, v3, v11

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "RunService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v12

    .line 31
    nop

    .line 50
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "Create"

    aput-object v15, v3, v16

    const-string v15, "GetValue"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "TweenService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v13

    .line 31
    nop

    .line 51
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "AddItem"

    aput-object v15, v3, v16

    const-string v15, "addItem"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Debris"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v19

    .line 31
    nop

    .line 52
    new-array v3, v11, [Ljava/lang/String;

    const-string v15, "JSONEncode"

    aput-object v15, v3, v16

    const-string v15, "JSONDecode"

    aput-object v15, v3, v18

    const-string v15, "GenerateGUID"

    aput-object v15, v3, v6

    const-string v15, "UrlEncode"

    aput-object v15, v3, v7

    const-string v15, "GetAsync"

    aput-object v15, v3, v8

    const-string v15, "PostAsync"

    aput-object v15, v3, v23

    const-string v15, "RequestAsync"

    aput-object v15, v3, v10

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "HttpService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v21

    .line 31
    nop

    .line 53
    new-array v3, v12, [Ljava/lang/String;

    const-string v15, "GetTagged"

    aput-object v15, v3, v16

    const-string v15, "AddTag"

    aput-object v15, v3, v18

    const-string v15, "RemoveTag"

    aput-object v15, v3, v6

    const-string v15, "HasTag"

    aput-object v15, v3, v7

    const-string v15, "GetTags"

    aput-object v15, v3, v8

    const-string v15, "GetInstanceAddedSignal"

    aput-object v15, v3, v23

    const-string v15, "GetInstanceRemovedSignal"

    aput-object v15, v3, v10

    const-string v15, "GetAllTags"

    aput-object v15, v3, v11

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "CollectionService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v4

    .line 31
    nop

    .line 54
    new-array v3, v8, [Ljava/lang/String;

    const-string v15, "Get"

    aput-object v15, v3, v16

    const-string v15, "Set"

    aput-object v15, v3, v18

    const-string v15, "Add"

    aput-object v15, v3, v6

    const-string v15, "Remove"

    aput-object v15, v3, v7

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Selection"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v17

    .line 31
    nop

    .line 55
    new-array v3, v13, [Ljava/lang/String;

    const-string v15, "SetWaypoint"

    aput-object v15, v3, v16

    const-string v15, "TryBeginRecording"

    aput-object v15, v3, v18

    const-string v15, "FinishRecording"

    aput-object v15, v3, v6

    const-string v15, "Undo"

    aput-object v15, v3, v7

    const-string v15, "Redo"

    aput-object v15, v3, v8

    const-string v15, "ResetWaypoints"

    aput-object v15, v3, v23

    const-string v15, "SetEnabled"

    aput-object v15, v3, v10

    const-string v15, "GetCanUndo"

    aput-object v15, v3, v11

    const-string v15, "GetCanRedo"

    aput-object v15, v3, v12

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "ChangeHistoryService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v5

    .line 31
    nop

    .line 56
    new-array v3, v7, [Ljava/lang/String;

    const-string v15, "GetDataStore"

    aput-object v15, v3, v16

    const-string v15, "GetGlobalDataStore"

    aput-object v15, v3, v18

    const-string v15, "GetOrderedDataStore"

    aput-object v15, v3, v6

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "DataStoreService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v14

    .line 31
    nop

    .line 57
    new-array v3, v10, [Ljava/lang/String;

    const-string v15, "PromptPurchase"

    aput-object v15, v3, v16

    const-string v15, "PromptGamePassPurchase"

    aput-object v15, v3, v18

    const-string v15, "PromptProductPurchase"

    aput-object v15, v3, v6

    const-string v15, "UserOwnsGamePassAsync"

    aput-object v15, v3, v7

    const-string v15, "GetProductInfo"

    aput-object v15, v3, v8

    const-string v15, "PlayerOwnsAsset"

    aput-object v15, v3, v23

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "MarketplaceService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v20

    .line 31
    nop

    .line 58
    new-array v3, v11, [Ljava/lang/String;

    const-string v15, "GetMouseLocation"

    aput-object v15, v3, v16

    const-string v15, "IsKeyDown"

    aput-object v15, v3, v18

    const-string v15, "GetFocusedTextBox"

    aput-object v15, v3, v6

    const-string v15, "IsMouseButtonPressed"

    aput-object v15, v3, v7

    const-string v15, "GetKeysPressed"

    aput-object v15, v3, v8

    const-string v15, "GetLastInputType"

    aput-object v15, v3, v23

    const-string v15, "GetConnectedGamepads"

    aput-object v15, v3, v10

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "UserInputService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v26

    .line 31
    nop

    .line 59
    new-array v3, v13, [Ljava/lang/String;

    const-string v15, "BindAction"

    aput-object v15, v3, v16

    const-string v15, "UnbindAction"

    aput-object v15, v3, v18

    const-string v15, "BindActionAtPriority"

    aput-object v15, v3, v6

    const-string v15, "SetTitle"

    aput-object v15, v3, v7

    const-string v15, "SetImage"

    aput-object v15, v3, v8

    const-string v15, "SetPosition"

    aput-object v15, v3, v23

    const-string v15, "SetDescription"

    aput-object v15, v3, v10

    const-string v15, "GetButton"

    aput-object v15, v3, v11

    const-string v15, "UnbindAllActions"

    aput-object v15, v3, v12

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "ContextActionService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v22

    .line 31
    nop

    .line 60
    new-array v3, v8, [Ljava/lang/String;

    const-string v15, "SetCore"

    aput-object v15, v3, v16

    const-string v15, "GetCore"

    aput-object v15, v3, v18

    const-string v15, "SetCoreGuiEnabled"

    aput-object v15, v3, v6

    const-string v15, "GetCoreGuiEnabled"

    aput-object v15, v3, v7

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "StarterGui"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v25

    .line 31
    nop

    .line 61
    const-string v3, "Fire"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "BindableEvent"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v24

    .line 31
    nop

    .line 62
    const-string v3, "Invoke"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "BindableFunction"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v9

    .line 31
    nop

    .line 63
    new-array v3, v7, [Ljava/lang/String;

    const-string v15, "FireServer"

    aput-object v15, v3, v16

    const-string v15, "FireClient"

    aput-object v15, v3, v18

    const-string v15, "FireAllClients"

    aput-object v15, v3, v6

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "RemoteEvent"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x16

    aput-object v3, v2, v15

    .line 31
    nop

    .line 64
    new-array v3, v7, [Ljava/lang/String;

    const-string v15, "FireServer"

    aput-object v15, v3, v16

    const-string v15, "FireClient"

    aput-object v15, v3, v18

    const-string v15, "FireAllClients"

    aput-object v15, v3, v6

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "UnreliableRemoteEvent"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x17

    aput-object v3, v2, v15

    .line 31
    nop

    .line 65
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "InvokeServer"

    aput-object v15, v3, v16

    const-string v15, "InvokeClient"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "RemoteFunction"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x18

    aput-object v3, v2, v15

    .line 31
    nop

    .line 66
    new-array v3, v8, [Ljava/lang/String;

    const-string v15, "Play"

    aput-object v15, v3, v16

    const-string v15, "Stop"

    aput-object v15, v3, v18

    const-string v15, "Pause"

    aput-object v15, v3, v6

    const-string v15, "Resume"

    aput-object v15, v3, v7

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Sound"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x19

    aput-object v3, v2, v15

    .line 31
    nop

    .line 67
    new-array v3, v7, [Ljava/lang/String;

    const-string v15, "TweenPosition"

    aput-object v15, v3, v16

    const-string v15, "TweenSize"

    aput-object v15, v3, v18

    const-string v15, "TweenSizeAndPosition"

    aput-object v15, v3, v6

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "GuiObject"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x1a

    aput-object v3, v2, v15

    .line 31
    nop

    .line 68
    new-array v3, v7, [Ljava/lang/String;

    const-string v15, "CaptureFocus"

    aput-object v15, v3, v16

    const-string v15, "ReleaseFocus"

    aput-object v15, v3, v18

    const-string v15, "IsFocused"

    aput-object v15, v3, v6

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "TextBox"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x1b

    aput-object v3, v2, v15

    .line 31
    nop

    .line 69
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "GetTextSize"

    aput-object v15, v3, v16

    const-string v15, "FilterStringAsync"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "TextService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x1c

    aput-object v3, v2, v15

    .line 31
    nop

    .line 70
    const/16 v3, 0x20

    new-array v3, v3, [Ljava/lang/String;

    const-string v15, "CreateToolbar"

    aput-object v15, v3, v16

    const-string v15, "GetSetting"

    aput-object v15, v3, v18

    const-string v15, "SetSetting"

    aput-object v15, v3, v6

    const-string v15, "CreateDockWidgetPluginGui"

    aput-object v15, v3, v7

    const-string v15, "CreateDockWidgetPluginGuiAsync"

    aput-object v15, v3, v8

    const-string v15, "CreateQWidgetPluginGui"

    aput-object v15, v3, v23

    .line 71
    const-string v15, "OpenScript"

    aput-object v15, v3, v10

    .line 70
    nop

    .line 71
    const-string v15, "GetMouse"

    aput-object v15, v3, v11

    .line 70
    nop

    .line 71
    const-string v15, "Activate"

    aput-object v15, v3, v12

    .line 70
    nop

    .line 72
    const-string v15, "Deactivate"

    aput-object v15, v3, v13

    .line 70
    nop

    .line 72
    const-string v15, "IsActivated"

    aput-object v15, v3, v19

    .line 70
    nop

    .line 72
    const-string v15, "IsActivatedWithExclusiveMouse"

    aput-object v15, v3, v21

    .line 70
    nop

    .line 72
    const-string v15, "GetStudioUserId"

    aput-object v15, v3, v4

    .line 70
    nop

    .line 72
    const-string v15, "CreatePluginAction"

    aput-object v15, v3, v17

    .line 70
    nop

    .line 72
    const-string v15, "CreatePluginMenu"

    aput-object v15, v3, v5

    .line 70
    nop

    .line 73
    const-string v15, "SelectRibbonTool"

    aput-object v15, v3, v14

    .line 70
    nop

    .line 73
    const-string v15, "GetSelectedRibbonTool"

    aput-object v15, v3, v20

    .line 70
    nop

    .line 73
    const-string v15, "Union"

    aput-object v15, v3, v26

    .line 70
    nop

    .line 73
    const-string v15, "Negate"

    aput-object v15, v3, v22

    .line 70
    nop

    .line 73
    const-string v15, "Separate"

    aput-object v15, v3, v25

    .line 70
    nop

    .line 73
    const-string v15, "Intersect"

    aput-object v15, v3, v24

    .line 70
    nop

    .line 73
    const-string v15, "StartDrag"

    aput-object v15, v3, v9

    .line 70
    nop

    .line 73
    const-string v15, "OpenWikiPage"

    const/16 v27, 0x16

    aput-object v15, v3, v27

    .line 70
    nop

    .line 74
    const-string v15, "SaveSelectedToRoblox"

    const/16 v27, 0x17

    aput-object v15, v3, v27

    .line 70
    nop

    .line 74
    const-string v15, "GetJoinMode"

    const/16 v27, 0x18

    aput-object v15, v3, v27

    .line 70
    nop

    .line 74
    const-string v15, "PromptForExistingAssetId"

    const/16 v27, 0x19

    aput-object v15, v3, v27

    .line 70
    nop

    .line 74
    const-string v15, "ImportFbxRig"

    const/16 v27, 0x1a

    aput-object v15, v3, v27

    .line 70
    nop

    .line 74
    const-string v15, "GetItem"

    const/16 v27, 0x1b

    aput-object v15, v3, v27

    .line 70
    nop

    .line 74
    const-string v15, "SetItem"

    const/16 v27, 0x1c

    aput-object v15, v3, v27

    .line 70
    nop

    .line 75
    const-string v15, "GetGridSize"

    const/16 v27, 0x1d

    aput-object v15, v3, v27

    .line 70
    nop

    .line 75
    const-string v15, "IsLoaded"

    const/16 v27, 0x1e

    aput-object v15, v3, v27

    .line 70
    nop

    .line 75
    const-string v15, "PromptSaveSelection"

    const/16 v27, 0x1f

    aput-object v15, v3, v27

    .line 70
    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Plugin"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x1d

    aput-object v3, v2, v15

    .line 31
    nop

    .line 76
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "BindToClose"

    aput-object v15, v3, v16

    const-string v15, "GetRelativeMousePosition"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "PluginGui"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x1e

    aput-object v3, v2, v15

    .line 31
    nop

    .line 77
    const-string v3, "CreateButton"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "PluginToolbar"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x1f

    aput-object v3, v2, v15

    .line 31
    nop

    .line 78
    const-string v3, "SetActive"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "PluginToolbarButton"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x20

    aput-object v3, v2, v15

    .line 31
    nop

    .line 79
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "Emit"

    aput-object v15, v3, v16

    const-string v15, "Clear"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "ParticleEmitter"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x21

    aput-object v3, v2, v15

    .line 31
    nop

    .line 80
    move/from16 v3, v23

    new-array v15, v3, [Ljava/lang/String;

    const-string v3, "WorldToScreenPoint"

    aput-object v3, v15, v16

    const-string v3, "WorldToViewportPoint"

    aput-object v3, v15, v18

    const-string v3, "ScreenPointToRay"

    aput-object v3, v15, v6

    const-string v3, "ViewportPointToRay"

    aput-object v3, v15, v7

    const-string v3, "GetPartsObscuringTarget"

    aput-object v3, v15, v8

    invoke-static {v15}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Camera"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x22

    aput-object v3, v2, v15

    .line 31
    nop

    .line 81
    new-array v3, v8, [Ljava/lang/String;

    const-string v15, "GetMinutesAfterMidnight"

    aput-object v15, v3, v16

    const-string v15, "SetMinutesAfterMidnight"

    aput-object v15, v3, v18

    const-string v15, "GetSunDirection"

    aput-object v15, v3, v6

    const-string v15, "GetMoonDirection"

    aput-object v15, v3, v7

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Lighting"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x23

    aput-object v3, v2, v15

    .line 31
    nop

    .line 82
    const-string v3, "PlayLocalSound"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "SoundService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x24

    aput-object v3, v2, v15

    .line 31
    nop

    .line 83
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "CreatePath"

    aput-object v15, v3, v16

    const-string v15, "FindPathAsync"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "PathfindingService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x25

    aput-object v3, v2, v15

    .line 31
    nop

    .line 84
    new-array v3, v7, [Ljava/lang/String;

    const-string v15, "AwardBadge"

    aput-object v15, v3, v16

    const-string v15, "UserHasBadgeAsync"

    aput-object v15, v3, v18

    const-string v15, "GetBadgeInfoAsync"

    aput-object v15, v3, v6

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "BadgeService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x26

    aput-object v3, v2, v15

    .line 31
    nop

    .line 85
    new-array v3, v7, [Ljava/lang/String;

    const-string v15, "Teleport"

    aput-object v15, v3, v16

    const-string v15, "TeleportAsync"

    aput-object v15, v3, v18

    const-string v15, "TeleportToPlaceInstance"

    aput-object v15, v3, v6

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "TeleportService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x27

    aput-object v3, v2, v15

    .line 31
    nop

    .line 86
    const-string v3, "LoadAsset"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "InsertService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x28

    aput-object v3, v2, v15

    .line 31
    nop

    .line 87
    const-string v3, "GetTeams"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Teams"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x29

    aput-object v3, v2, v15

    .line 31
    nop

    .line 88
    const-string v3, "GetPlayers"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Team"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x2a

    aput-object v3, v2, v15

    .line 31
    nop

    .line 89
    new-array v3, v10, [Ljava/lang/String;

    const-string v15, "RegisterCollisionGroup"

    aput-object v15, v3, v16

    const-string v15, "CollisionGroupSetCollidable"

    aput-object v15, v3, v18

    const-string v15, "SetPartCollisionGroup"

    aput-object v15, v3, v6

    const-string v15, "CreateCollisionGroup"

    aput-object v15, v3, v7

    const-string v15, "CollisionGroupsAreCollidable"

    aput-object v15, v3, v8

    const-string v15, "GetRegisteredCollisionGroups"

    const/16 v23, 0x5

    aput-object v15, v3, v23

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "PhysicsService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x2b

    aput-object v3, v2, v15

    .line 31
    nop

    .line 90
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "Activate"

    aput-object v15, v3, v16

    const-string v15, "Deactivate"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Tool"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x2c

    aput-object v3, v2, v15

    .line 31
    nop

    .line 91
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "InputHoldBegin"

    aput-object v15, v3, v16

    const-string v15, "InputHoldEnd"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "ProximityPrompt"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x2d

    aput-object v3, v2, v15

    .line 31
    nop

    .line 92
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "SetTopbarTransparency"

    aput-object v15, v3, v16

    const-string v15, "GetGuiObjectsAtPosition"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "PlayerGui"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x2e

    aput-object v3, v2, v15

    .line 31
    nop

    .line 93
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "PublishAsync"

    aput-object v15, v3, v16

    const-string v15, "SubscribeAsync"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "MessagingService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x2f

    aput-object v3, v2, v15

    .line 31
    nop

    .line 94
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "Chat"

    aput-object v15, v3, v16

    const-string v15, "FilterStringForBroadcast"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "Chat"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x30

    aput-object v3, v2, v15

    .line 31
    nop

    .line 95
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "SendAsync"

    aput-object v15, v3, v16

    const-string v15, "DisplaySystemMessage"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "TextChannel"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x31

    aput-object v3, v2, v15

    .line 31
    nop

    .line 96
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "GetGuiInset"

    aput-object v15, v3, v16

    const-string v15, "IsTenFootInterface"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "GuiService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x32

    aput-object v3, v2, v15

    .line 31
    nop

    .line 97
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "GetTranslatorForPlayerAsync"

    aput-object v15, v3, v16

    const-string v15, "GetCountryRegionForPlayerAsync"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "LocalizationService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x33

    aput-object v3, v2, v15

    .line 31
    nop

    .line 98
    const-string v3, "GetPolicyInfoForPlayerAsync"

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "PolicyService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x34

    aput-object v3, v2, v15

    .line 31
    nop

    .line 99
    new-array v3, v6, [Ljava/lang/String;

    const-string v15, "GetUserId"

    aput-object v15, v3, v16

    const-string v15, "PromptImportFile"

    aput-object v15, v3, v18

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "StudioService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x35

    aput-object v3, v2, v15

    .line 31
    nop

    .line 100
    move/from16 v3, v21

    new-array v15, v3, [Ljava/lang/String;

    const-string v3, "GetSessionId"

    aput-object v3, v15, v16

    const-string v3, "GetClientId"

    aput-object v3, v15, v18

    const-string v3, "GetPlaySessionId"

    aput-object v3, v15, v6

    const-string v3, "ReportStats"

    aput-object v3, v15, v7

    const-string v3, "SendEventDeferred"

    aput-object v3, v15, v8

    const-string v3, "SendEventImmediately"

    const/16 v23, 0x5

    aput-object v3, v15, v23

    .line 101
    const-string v3, "ReportCounter"

    aput-object v3, v15, v10

    .line 100
    nop

    .line 101
    const-string v3, "ReportInfluxSeries"

    aput-object v3, v15, v11

    .line 100
    nop

    .line 101
    const-string v3, "TrackEvent"

    aput-object v3, v15, v12

    .line 100
    nop

    .line 101
    const-string v3, "FireLogEvent"

    aput-object v3, v15, v13

    .line 100
    nop

    .line 101
    const-string v3, "SetRBXEvent"

    aput-object v3, v15, v19

    .line 100
    invoke-static {v15}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "RbxAnalyticsService"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x36

    aput-object v3, v2, v15

    .line 31
    nop

    .line 102
    const/4 v3, 0x5

    new-array v15, v3, [Ljava/lang/String;

    const-string v3, "BindToClose"

    aput-object v3, v15, v16

    const-string v3, "IsLoaded"

    aput-object v3, v15, v18

    const-string v3, "GetJobsInfo"

    aput-object v3, v15, v6

    const-string v3, "SetPlaceId"

    aput-object v3, v15, v7

    const-string v3, "GetObjects"

    aput-object v3, v15, v8

    invoke-static {v15}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const-string v15, "DataModel"

    invoke-static {v15, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/16 v15, 0x37

    aput-object v3, v2, v15

    .line 31
    nop

    .line 30
    invoke-static {v2}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->classMethods:Ljava/util/Map;

    .line 105
    nop

    .line 106
    const/16 v2, 0x82

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Touched"

    aput-object v3, v2, v16

    const-string v3, "TouchEnded"

    aput-object v3, v2, v18

    const-string v3, "ChildAdded"

    aput-object v3, v2, v6

    const-string v3, "ChildRemoved"

    aput-object v3, v2, v7

    const-string v3, "DescendantAdded"

    aput-object v3, v2, v8

    const-string v3, "DescendantRemoving"

    const/16 v23, 0x5

    aput-object v3, v2, v23

    const-string v3, "Changed"

    aput-object v3, v2, v10

    const-string v3, "AncestryChanged"

    aput-object v3, v2, v11

    .line 107
    const-string v3, "Destroying"

    aput-object v3, v2, v12

    .line 106
    nop

    .line 107
    const-string v3, "AttributeChanged"

    aput-object v3, v2, v13

    .line 106
    nop

    .line 107
    const-string v3, "Heartbeat"

    aput-object v3, v2, v19

    .line 106
    nop

    .line 107
    const-string v3, "RenderStepped"

    const/16 v21, 0xb

    aput-object v3, v2, v21

    .line 106
    nop

    .line 107
    const-string v3, "Stepped"

    aput-object v3, v2, v4

    .line 106
    nop

    .line 107
    const-string v3, "PreSimulation"

    aput-object v3, v2, v17

    .line 106
    nop

    .line 107
    const-string v3, "PostSimulation"

    aput-object v3, v2, v5

    .line 106
    nop

    .line 107
    const-string v3, "PreRender"

    aput-object v3, v2, v14

    .line 106
    nop

    .line 108
    const-string v3, "PlayerAdded"

    aput-object v3, v2, v20

    .line 106
    nop

    .line 108
    const-string v3, "PlayerRemoving"

    aput-object v3, v2, v26

    .line 106
    nop

    .line 108
    const-string v3, "CharacterAdded"

    aput-object v3, v2, v22

    .line 106
    nop

    .line 108
    const-string v3, "CharacterRemoving"

    aput-object v3, v2, v25

    .line 106
    nop

    .line 108
    const-string v3, "CharacterAppearanceLoaded"

    aput-object v3, v2, v24

    .line 106
    nop

    .line 108
    const-string v3, "Died"

    aput-object v3, v2, v9

    .line 106
    nop

    .line 108
    const-string v3, "HealthChanged"

    const/16 v15, 0x16

    aput-object v3, v2, v15

    .line 106
    nop

    .line 108
    const-string v3, "Running"

    const/16 v15, 0x17

    aput-object v3, v2, v15

    .line 106
    nop

    .line 108
    const-string v3, "Jumping"

    const/16 v15, 0x18

    aput-object v3, v2, v15

    .line 106
    nop

    .line 109
    const-string v3, "StateChanged"

    const/16 v15, 0x19

    aput-object v3, v2, v15

    .line 106
    nop

    .line 109
    const-string v3, "MoveToFinished"

    const/16 v15, 0x1a

    aput-object v3, v2, v15

    .line 106
    nop

    .line 109
    const-string v3, "FreeFalling"

    const/16 v15, 0x1b

    aput-object v3, v2, v15

    .line 106
    nop

    .line 109
    const-string v3, "Seated"

    const/16 v15, 0x1c

    aput-object v3, v2, v15

    .line 106
    nop

    .line 109
    const-string v3, "MouseButton1Click"

    const/16 v15, 0x1d

    aput-object v3, v2, v15

    .line 106
    nop

    .line 109
    const-string v3, "MouseButton1Down"

    const/16 v15, 0x1e

    aput-object v3, v2, v15

    .line 106
    nop

    .line 109
    const-string v3, "MouseButton1Up"

    const/16 v15, 0x1f

    aput-object v3, v2, v15

    .line 106
    nop

    .line 109
    const-string v3, "MouseButton2Click"

    const/16 v15, 0x20

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "Activated"

    const/16 v15, 0x21

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "MouseEnter"

    const/16 v15, 0x22

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "MouseLeave"

    const/16 v15, 0x23

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "FocusLost"

    const/16 v15, 0x24

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "Focused"

    const/16 v15, 0x25

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "Event"

    const/16 v15, 0x26

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "OnServerEvent"

    const/16 v15, 0x27

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "OnClientEvent"

    const/16 v15, 0x28

    aput-object v3, v2, v15

    .line 106
    nop

    .line 110
    const-string v3, "MouseClick"

    const/16 v15, 0x29

    aput-object v3, v2, v15

    .line 106
    nop

    .line 111
    const-string v3, "RightMouseClick"

    const/16 v15, 0x2a

    aput-object v3, v2, v15

    .line 106
    nop

    .line 111
    const-string v3, "MouseHoverEnter"

    const/16 v15, 0x2b

    aput-object v3, v2, v15

    .line 106
    nop

    .line 111
    const-string v3, "MouseHoverLeave"

    const/16 v15, 0x2c

    aput-object v3, v2, v15

    .line 106
    nop

    .line 111
    const-string v3, "Triggered"

    const/16 v15, 0x2d

    aput-object v3, v2, v15

    .line 106
    nop

    .line 111
    const-string v3, "TriggerEnded"

    const/16 v15, 0x2e

    aput-object v3, v2, v15

    .line 106
    nop

    .line 111
    const-string v3, "PromptShown"

    const/16 v15, 0x2f

    aput-object v3, v2, v15

    .line 106
    nop

    .line 111
    const-string v3, "PromptHidden"

    const/16 v15, 0x30

    aput-object v3, v2, v15

    .line 106
    nop

    .line 111
    const-string v3, "PromptTriggered"

    const/16 v15, 0x31

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "Completed"

    const/16 v15, 0x32

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "Click"

    const/16 v15, 0x33

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "SelectionChanged"

    const/16 v15, 0x34

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "InputBegan"

    const/16 v15, 0x35

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "InputEnded"

    const/16 v15, 0x36

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "InputChanged"

    const/16 v15, 0x37

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "TouchTapInWorld"

    const/16 v15, 0x38

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "TouchTap"

    const/16 v15, 0x39

    aput-object v3, v2, v15

    .line 106
    nop

    .line 112
    const-string v3, "TouchStarted"

    const/16 v15, 0x3a

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "TouchEnded"

    const/16 v15, 0x3b

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "TouchMoved"

    const/16 v15, 0x3c

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Equipped"

    const/16 v15, 0x3d

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Unequipped"

    const/16 v15, 0x3e

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Deactivated"

    const/16 v15, 0x3f

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Played"

    const/16 v15, 0x40

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Ended"

    const/16 v15, 0x41

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Paused"

    const/16 v15, 0x42

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Resumed"

    const/16 v15, 0x43

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Loaded"

    const/16 v15, 0x44

    aput-object v3, v2, v15

    .line 106
    nop

    .line 113
    const-string v3, "Chatted"

    const/16 v15, 0x45

    aput-object v3, v2, v15

    .line 106
    nop

    .line 114
    const-string v3, "Idled"

    const/16 v15, 0x46

    aput-object v3, v2, v15

    .line 106
    nop

    .line 114
    const-string v3, "Button1Down"

    const/16 v15, 0x47

    aput-object v3, v2, v15

    .line 106
    nop

    .line 114
    const-string v3, "Button1Up"

    const/16 v15, 0x48

    aput-object v3, v2, v15

    .line 106
    nop

    .line 114
    const-string v3, "Move"

    const/16 v15, 0x49

    aput-object v3, v2, v15

    .line 106
    nop

    .line 114
    const-string v3, "Blocked"

    const/16 v15, 0x4a

    aput-object v3, v2, v15

    .line 106
    nop

    .line 114
    const-string v3, "PromptPurchaseFinished"

    const/16 v15, 0x4b

    aput-object v3, v2, v15

    .line 106
    nop

    .line 114
    const-string v3, "PromptGamePassPurchaseFinished"

    const/16 v15, 0x4c

    aput-object v3, v2, v15

    .line 106
    nop

    .line 115
    const-string v3, "ServerScriptServiceChanged"

    const/16 v15, 0x4d

    aput-object v3, v2, v15

    .line 106
    nop

    .line 115
    const-string v3, "WindowFocused"

    const/16 v15, 0x4e

    aput-object v3, v2, v15

    .line 106
    nop

    .line 115
    const-string v3, "WindowFocusReleased"

    const/16 v15, 0x4f

    aput-object v3, v2, v15

    .line 106
    nop

    .line 115
    const-string v3, "Unloading"

    const/16 v15, 0x50

    aput-object v3, v2, v15

    .line 106
    nop

    .line 115
    const-string v3, "Close"

    const/16 v15, 0x51

    aput-object v3, v2, v15

    .line 106
    nop

    .line 115
    const-string v3, "BindToClose"

    const/16 v15, 0x52

    aput-object v3, v2, v15

    .line 106
    nop

    .line 115
    const-string v3, "Deactivation"

    const/16 v15, 0x53

    aput-object v3, v2, v15

    .line 106
    nop

    .line 116
    const-string v3, "ChildAddedToCharacter"

    const/16 v15, 0x54

    aput-object v3, v2, v15

    .line 106
    nop

    .line 116
    const-string v3, "ReturnPressedFromOnScreenKeyboard"

    const/16 v15, 0x55

    aput-object v3, v2, v15

    .line 106
    nop

    .line 116
    const-string v3, "TextChanged"

    const/16 v15, 0x56

    aput-object v3, v2, v15

    .line 106
    nop

    .line 116
    const-string v3, "MessageReceived"

    const/16 v15, 0x57

    aput-object v3, v2, v15

    .line 106
    nop

    .line 116
    const-string v3, "OnIncomingMessage"

    const/16 v15, 0x58

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "LastInputTypeChanged"

    const/16 v15, 0x59

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "JumpRequest"

    const/16 v15, 0x5a

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "MouseDrag"

    const/16 v15, 0x5b

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "Unloading"

    const/16 v15, 0x5c

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "Deactivation"

    const/16 v15, 0x5d

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "Loaded"

    const/16 v15, 0x5e

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "PromptProductPurchaseFinished"

    const/16 v15, 0x5f

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "PromptPurchaseFinished"

    const/16 v15, 0x60

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "PromptGamePassPurchaseFinished"

    const/16 v15, 0x61

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "PromptBundlePurchaseFinished"

    const/16 v15, 0x62

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "Loaded"

    const/16 v15, 0x63

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "GraphicsQualityChangeRequest"

    const/16 v15, 0x64

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "OnTeleport"

    const/16 v15, 0x65

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "ChildRemoving"

    const/16 v15, 0x66

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "ClockTimeChanged"

    const/16 v15, 0x67

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "PlaybackStateChanged"

    const/16 v15, 0x68

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "DidLoop"

    const/16 v15, 0x69

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "Stopped"

    const/16 v15, 0x6a

    aput-object v3, v2, v15

    .line 106
    nop

    .line 117
    const-string v3, "KeyframeReached"

    const/16 v15, 0x6b

    aput-object v3, v2, v15

    .line 106
    nop

    .line 119
    const-string v3, "OnUndo"

    const/16 v15, 0x6c

    aput-object v3, v2, v15

    .line 106
    nop

    .line 119
    const-string v3, "OnRedo"

    const/16 v15, 0x6d

    aput-object v3, v2, v15

    .line 106
    nop

    .line 119
    const-string v3, "OnRecordingStarted"

    const/16 v15, 0x6e

    aput-object v3, v2, v15

    .line 106
    nop

    .line 119
    const-string v3, "OnRecordingFinished"

    const/16 v15, 0x6f

    aput-object v3, v2, v15

    .line 106
    nop

    .line 119
    const-string v3, "WaypointSet"

    const/16 v15, 0x70

    aput-object v3, v2, v15

    .line 106
    nop

    .line 119
    const-string v3, "Activated"

    const/16 v15, 0x71

    aput-object v3, v2, v15

    .line 106
    nop

    .line 119
    const-string v3, "PromptDismissed"

    const/16 v15, 0x72

    aput-object v3, v2, v15

    .line 106
    nop

    .line 120
    const-string v3, "DragBegin"

    const/16 v15, 0x73

    aput-object v3, v2, v15

    .line 106
    nop

    .line 120
    const-string v3, "DragContinue"

    const/16 v15, 0x74

    aput-object v3, v2, v15

    .line 106
    nop

    .line 120
    const-string v3, "DragEnd"

    const/16 v15, 0x75

    aput-object v3, v2, v15

    .line 106
    nop

    .line 120
    const-string v3, "MouseButton2Down"

    const/16 v15, 0x76

    aput-object v3, v2, v15

    .line 106
    nop

    .line 120
    const-string v3, "MouseButton2Up"

    const/16 v15, 0x77

    aput-object v3, v2, v15

    .line 106
    nop

    .line 120
    const-string v3, "MouseWheelForward"

    const/16 v15, 0x78

    aput-object v3, v2, v15

    .line 106
    nop

    .line 120
    const-string v3, "MouseWheelBackward"

    const/16 v15, 0x79

    aput-object v3, v2, v15

    .line 106
    nop

    .line 121
    const-string v3, "WheelBackward"

    const/16 v15, 0x7a

    aput-object v3, v2, v15

    .line 106
    nop

    .line 121
    const-string v3, "WheelForward"

    const/16 v15, 0x7b

    aput-object v3, v2, v15

    .line 106
    nop

    .line 121
    const-string v3, "Button2Down"

    const/16 v15, 0x7c

    aput-object v3, v2, v15

    .line 106
    nop

    .line 121
    const-string v3, "Button2Up"

    const/16 v15, 0x7d

    aput-object v3, v2, v15

    .line 106
    nop

    .line 121
    const-string v3, "KeyDown"

    const/16 v15, 0x7e

    aput-object v3, v2, v15

    .line 106
    nop

    .line 121
    const-string v3, "KeyUp"

    const/16 v15, 0x7f

    aput-object v3, v2, v15

    .line 106
    nop

    .line 121
    const-string v3, "SelectionGained"

    const/16 v15, 0x80

    aput-object v3, v2, v15

    .line 106
    nop

    .line 121
    const-string v3, "SelectionLost"

    const/16 v15, 0x81

    aput-object v3, v2, v15

    .line 106
    nop

    .line 105
    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->events:Ljava/util/Set;

    .line 124
    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "UIGradient"

    aput-object v3, v2, v16

    const-string v3, "ParticleEmitter"

    aput-object v3, v2, v18

    const-string v3, "Beam"

    aput-object v3, v2, v6

    const-string v3, "Trail"

    aput-object v3, v2, v7

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->sequenceClasses:Ljava/util/Set;

    .line 127
    new-array v2, v12, [Ljava/lang/String;

    const-string v3, "ChildAdded"

    aput-object v3, v2, v16

    const-string v3, "ChildRemoved"

    aput-object v3, v2, v18

    const-string v3, "DescendantAdded"

    aput-object v3, v2, v6

    const-string v3, "DescendantRemoving"

    aput-object v3, v2, v7

    const-string v3, "Changed"

    aput-object v3, v2, v8

    const-string v3, "AncestryChanged"

    const/16 v23, 0x5

    aput-object v3, v2, v23

    const-string v3, "Destroying"

    aput-object v3, v2, v10

    const-string v3, "AttributeChanged"

    aput-object v3, v2, v11

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->universalEvents:Ljava/util/Set;

    .line 129
    nop

    .line 130
    iget-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getInstanceMeta()Lorg/luaj/vm2/LuaTable;

    move-result-object v2

    .line 131
    .local v2, "m":Lorg/luaj/vm2/LuaTable;
    const-string v3, "__type"

    const-string v15, "Instance"

    invoke-virtual {v2, v3, v15}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Ljava/lang/String;)V

    .line 132
    sget-object v3, Lorg/luaj/vm2/LuaValue;->INDEX:Lorg/luaj/vm2/LuaString;

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    new-instance v15, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda15;

    invoke-direct {v15, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda15;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;)V

    invoke-static {v15}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v15

    check-cast v15, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v2, v3, v15}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 133
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NEWINDEX:Lorg/luaj/vm2/LuaString;

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    new-instance v15, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$2;

    invoke-direct {v15, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$2;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;)V

    check-cast v15, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v2, v3, v15}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 138
    sget-object v3, Lorg/luaj/vm2/LuaValue;->TOSTRING:Lorg/luaj/vm2/LuaString;

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    new-instance v15, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda16;

    invoke-direct {v15}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda16;-><init>()V

    invoke-static {v15}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v15

    check-cast v15, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v2, v3, v15}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 140
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signalMeta:Lorg/luaj/vm2/LuaTable;

    const-string v15, "__type"

    move/from16 v27, v11

    const-string v11, "RBXScriptSignal"

    invoke-virtual {v3, v15, v11}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Ljava/lang/String;)V

    .line 141
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signalMeta:Lorg/luaj/vm2/LuaTable;

    sget-object v11, Lorg/luaj/vm2/LuaValue;->INDEX:Lorg/luaj/vm2/LuaString;

    check-cast v11, Lorg/luaj/vm2/LuaValue;

    new-instance v15, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda17;

    invoke-direct {v15, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda17;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;)V

    invoke-static {v15}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v15

    check-cast v15, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v3, v11, v15}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 150
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signalMeta:Lorg/luaj/vm2/LuaTable;

    sget-object v11, Lorg/luaj/vm2/LuaValue;->TOSTRING:Lorg/luaj/vm2/LuaString;

    check-cast v11, Lorg/luaj/vm2/LuaValue;

    new-instance v15, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda18;

    invoke-direct {v15}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda18;-><init>()V

    invoke-static {v15}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v15

    check-cast v15, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v3, v11, v15}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 152
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->connMeta:Lorg/luaj/vm2/LuaTable;

    const-string v11, "__type"

    const-string v15, "RBXScriptConnection"

    invoke-virtual {v3, v11, v15}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Ljava/lang/String;)V

    .line 153
    iget-object v3, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->connMeta:Lorg/luaj/vm2/LuaTable;

    sget-object v11, Lorg/luaj/vm2/LuaValue;->INDEX:Lorg/luaj/vm2/LuaString;

    check-cast v11, Lorg/luaj/vm2/LuaValue;

    new-instance v15, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda19;

    invoke-direct {v15, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda19;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;)V

    invoke-static {v15}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v15

    check-cast v15, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v3, v11, v15}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 161
    .end local v2    # "m":Lorg/luaj/vm2/LuaTable;
    nop

    .line 314
    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "CurrentPosition"

    aput-object v3, v2, v16

    const-string v3, "CurrentAngle"

    aput-object v3, v2, v18

    const-string v3, "CurrentDistance"

    aput-object v3, v2, v6

    const-string v3, "CurrentLength"

    aput-object v3, v2, v7

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->CONSTRAINT_READOUTS:Ljava/util/Set;

    .line 315
    new-array v2, v8, [Ljava/lang/String;

    const-string v3, "Name"

    aput-object v3, v2, v16

    const-string v3, "ClassName"

    aput-object v3, v2, v18

    const-string v3, "Parent"

    aput-object v3, v2, v6

    const-string v3, "Archivable"

    aput-object v3, v2, v7

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->BASE_PROPS:Ljava/util/Set;

    .line 316
    const/16 v2, 0x1a

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "Position"

    aput-object v3, v2, v16

    const-string v3, "Orientation"

    aput-object v3, v2, v18

    const-string v3, "Rotation"

    aput-object v3, v2, v6

    const-string v3, "Size"

    aput-object v3, v2, v7

    const-string v3, "Color"

    aput-object v3, v2, v8

    const-string v3, "BrickColor"

    const/16 v23, 0x5

    aput-object v3, v2, v23

    const-string v3, "CFrame"

    aput-object v3, v2, v10

    const-string v3, "AssemblyLinearVelocity"

    aput-object v3, v2, v27

    .line 317
    const-string v3, "Velocity"

    aput-object v3, v2, v12

    .line 316
    nop

    .line 317
    const-string v3, "AssemblyAngularVelocity"

    aput-object v3, v2, v13

    .line 316
    nop

    .line 317
    const-string v3, "RotVelocity"

    aput-object v3, v2, v19

    .line 316
    nop

    .line 317
    const-string v3, "Mass"

    const/16 v21, 0xb

    aput-object v3, v2, v21

    .line 316
    nop

    .line 317
    const-string v3, "AssemblyMass"

    aput-object v3, v2, v4

    .line 316
    nop

    .line 317
    const-string v3, "PivotOffset"

    aput-object v3, v2, v17

    .line 316
    nop

    .line 317
    const-string v3, "AssemblyRootPart"

    aput-object v3, v2, v5

    .line 316
    nop

    .line 317
    const-string v3, "Anchored"

    aput-object v3, v2, v14

    .line 316
    nop

    .line 317
    const-string v3, "CanCollide"

    aput-object v3, v2, v20

    .line 316
    nop

    .line 318
    const-string v3, "Transparency"

    aput-object v3, v2, v26

    .line 316
    nop

    .line 318
    const-string v3, "Material"

    aput-object v3, v2, v22

    .line 316
    nop

    .line 318
    const-string v3, "Shape"

    aput-object v3, v2, v25

    .line 316
    nop

    .line 318
    const-string v3, "CanTouch"

    aput-object v3, v2, v24

    .line 316
    nop

    .line 318
    const-string v3, "CanQuery"

    aput-object v3, v2, v9

    .line 316
    nop

    .line 318
    const-string v3, "Locked"

    const/16 v11, 0x16

    aput-object v3, v2, v11

    .line 316
    nop

    .line 318
    const-string v3, "Massless"

    const/16 v11, 0x17

    aput-object v3, v2, v11

    .line 316
    nop

    .line 318
    const-string v3, "Reflectance"

    const/16 v11, 0x18

    aput-object v3, v2, v11

    .line 316
    nop

    .line 318
    const-string v3, "CastShadow"

    const/16 v11, 0x19

    aput-object v3, v2, v11

    .line 316
    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->PART_PROPS:Ljava/util/Set;

    .line 321
    nop

    .line 322
    move/from16 v2, v25

    new-array v3, v2, [Lkotlin/Pair;

    new-array v2, v12, [Ljava/lang/String;

    const-string v11, "PlaceId"

    aput-object v11, v2, v16

    const-string v11, "GameId"

    aput-object v11, v2, v18

    const-string v11, "CreatorId"

    aput-object v11, v2, v6

    const-string v11, "CreatorType"

    aput-object v11, v2, v7

    const-string v11, "PlaceVersion"

    aput-object v11, v2, v8

    const-string v11, "JobId"

    const/16 v23, 0x5

    aput-object v11, v2, v23

    const-string v11, "PrivateServerId"

    aput-object v11, v2, v10

    const-string v11, "PrivateServerOwnerId"

    aput-object v11, v2, v27

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "DataModel"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v16

    .line 323
    const-string v2, "IsLoaded"

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "ImageLabel"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v18

    .line 322
    nop

    .line 323
    const-string v2, "IsLoaded"

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "ImageButton"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v6

    .line 322
    nop

    .line 324
    new-array v2, v12, [Ljava/lang/String;

    const-string v11, "GridSize"

    aput-object v11, v2, v16

    const-string v11, "RotateIncrement"

    aput-object v11, v2, v18

    const-string v11, "UseLocalSpace"

    aput-object v11, v2, v6

    const-string v11, "DraggerSolveConstraints"

    aput-object v11, v2, v7

    const-string v11, "ShowConstraintDetails"

    aput-object v11, v2, v8

    const-string v11, "ActiveScript"

    const/16 v23, 0x5

    aput-object v11, v2, v23

    const-string v11, "StudioLocaleId"

    aput-object v11, v2, v10

    const-string v11, "Theme"

    aput-object v11, v2, v27

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "StudioService"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v7

    .line 322
    nop

    .line 325
    new-array v2, v5, [Ljava/lang/String;

    const-string v11, "HoverThickness"

    aput-object v11, v2, v16

    const-string v11, "AlignDraggedObjects"

    aput-object v11, v2, v18

    const-string v11, "ShowHover"

    aput-object v11, v2, v6

    const-string v11, "AnimateHover"

    aput-object v11, v2, v7

    const-string v11, "PivotSnapToGeometry"

    aput-object v11, v2, v8

    const-string v11, "ShowPivotIndicator"

    const/16 v23, 0x5

    aput-object v11, v2, v23

    const-string v11, "JointsEnabled"

    aput-object v11, v2, v10

    .line 326
    const-string v11, "CollisionsEnabled"

    aput-object v11, v2, v27

    .line 325
    nop

    .line 326
    const-string v11, "AngleSnapEnabled"

    aput-object v11, v2, v12

    .line 325
    nop

    .line 326
    const-string v11, "AngleSnapIncrement"

    aput-object v11, v2, v13

    .line 325
    nop

    .line 326
    const-string v11, "LinearSnapEnabled"

    aput-object v11, v2, v19

    .line 325
    nop

    .line 326
    const-string v11, "LinearSnapIncrement"

    const/16 v21, 0xb

    aput-object v11, v2, v21

    .line 325
    nop

    .line 326
    const-string v11, "HoverAnimateFrequency"

    aput-object v11, v2, v4

    .line 325
    nop

    .line 326
    const-string v11, "GeometrySnapColor"

    aput-object v11, v2, v17

    .line 325
    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "DraggerService"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v8

    .line 322
    nop

    .line 327
    new-array v2, v6, [Ljava/lang/String;

    const-string v11, "LocalPlayer"

    aput-object v11, v2, v16

    const-string v11, "MaxPlayers"

    aput-object v11, v2, v18

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "Players"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/16 v23, 0x5

    aput-object v2, v3, v23

    .line 322
    nop

    .line 328
    new-array v2, v4, [Ljava/lang/String;

    const-string v11, "Health"

    aput-object v11, v2, v16

    const-string v11, "RootPart"

    aput-object v11, v2, v18

    const-string v11, "MoveDirection"

    aput-object v11, v2, v6

    const-string v11, "FloorMaterial"

    aput-object v11, v2, v7

    const-string v11, "Jump"

    aput-object v11, v2, v8

    const-string v11, "SeatPart"

    const/16 v23, 0x5

    aput-object v11, v2, v23

    const-string v11, "Sit"

    aput-object v11, v2, v10

    const-string v11, "PlatformStand"

    aput-object v11, v2, v27

    const-string v11, "AutoRotate"

    aput-object v11, v2, v12

    const-string v11, "UseJumpPower"

    aput-object v11, v2, v13

    const-string v11, "JumpHeight"

    aput-object v11, v2, v19

    const-string v11, "RigType"

    const/16 v21, 0xb

    aput-object v11, v2, v21

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "Humanoid"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v10

    .line 322
    nop

    .line 329
    new-array v2, v8, [Ljava/lang/String;

    const-string v11, "DistributedGameTime"

    aput-object v11, v2, v16

    const-string v11, "CurrentCamera"

    aput-object v11, v2, v18

    const-string v11, "Gravity"

    aput-object v11, v2, v6

    const-string v11, "StreamingEnabled"

    aput-object v11, v2, v7

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "Workspace"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v27

    .line 322
    nop

    .line 330
    new-array v2, v10, [Ljava/lang/String;

    const-string v11, "ViewportSize"

    aput-object v11, v2, v16

    const-string v11, "CFrame"

    aput-object v11, v2, v18

    const-string v11, "Focus"

    aput-object v11, v2, v6

    const-string v11, "CameraSubject"

    aput-object v11, v2, v7

    const-string v11, "CameraType"

    aput-object v11, v2, v8

    const-string v11, "FieldOfView"

    const/16 v23, 0x5

    aput-object v11, v2, v23

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "Camera"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v12

    .line 322
    nop

    .line 331
    new-array v2, v13, [Ljava/lang/String;

    const-string v11, "TimeOfDay"

    aput-object v11, v2, v16

    const-string v11, "ClockTime"

    aput-object v11, v2, v18

    const-string v11, "Brightness"

    aput-object v11, v2, v6

    const-string v11, "Ambient"

    aput-object v11, v2, v7

    const-string v11, "OutdoorAmbient"

    aput-object v11, v2, v8

    const-string v11, "FogEnd"

    const/16 v23, 0x5

    aput-object v11, v2, v23

    const-string v11, "FogStart"

    aput-object v11, v2, v10

    const-string v11, "FogColor"

    aput-object v11, v2, v27

    const-string v11, "GlobalShadows"

    aput-object v11, v2, v12

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "Lighting"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v13

    .line 322
    nop

    .line 332
    move/from16 v2, v19

    new-array v11, v2, [Ljava/lang/String;

    const-string v2, "TouchEnabled"

    aput-object v2, v11, v16

    const-string v2, "KeyboardEnabled"

    aput-object v2, v11, v18

    const-string v2, "MouseEnabled"

    aput-object v2, v11, v6

    const-string v2, "GamepadEnabled"

    aput-object v2, v11, v7

    const-string v2, "VREnabled"

    aput-object v2, v11, v8

    const-string v2, "MouseBehavior"

    const/16 v23, 0x5

    aput-object v2, v11, v23

    const-string v2, "MouseIconEnabled"

    aput-object v2, v11, v10

    const-string v2, "AccelerometerEnabled"

    aput-object v2, v11, v27

    const-string v2, "GyroscopeEnabled"

    aput-object v2, v11, v12

    const-string v2, "ModalEnabled"

    aput-object v2, v11, v13

    invoke-static {v11}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "UserInputService"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/16 v19, 0xa

    aput-object v2, v3, v19

    .line 322
    nop

    .line 333
    const-string v2, "HttpEnabled"

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "HttpService"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/16 v21, 0xb

    aput-object v2, v3, v21

    .line 322
    nop

    .line 334
    const-string v2, "ClientGitHash"

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "RunService"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v4

    .line 322
    nop

    .line 335
    new-array v2, v14, [Ljava/lang/String;

    const-string v11, "PlayerGui"

    aput-object v11, v2, v16

    const-string v11, "Backpack"

    aput-object v11, v2, v18

    const-string v11, "Character"

    aput-object v11, v2, v6

    const-string v11, "UserId"

    aput-object v11, v2, v7

    const-string v11, "DisplayName"

    aput-object v11, v2, v8

    const-string v11, "Team"

    const/16 v23, 0x5

    aput-object v11, v2, v23

    const-string v11, "TeamColor"

    aput-object v11, v2, v10

    const-string v11, "Neutral"

    aput-object v11, v2, v27

    const-string v11, "AccountAge"

    aput-object v11, v2, v12

    const-string v11, "MembershipType"

    aput-object v11, v2, v13

    const-string v11, "RespawnLocation"

    const/16 v19, 0xa

    aput-object v11, v2, v19

    const-string v11, "CameraMode"

    const/16 v21, 0xb

    aput-object v11, v2, v21

    const-string v11, "CameraMaxZoomDistance"

    aput-object v11, v2, v4

    const-string v11, "CameraMinZoomDistance"

    aput-object v11, v2, v17

    const-string v11, "DevTouchMovementMode"

    aput-object v11, v2, v5

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "Player"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v17

    .line 322
    nop

    .line 336
    new-array v2, v7, [Ljava/lang/String;

    const-string v11, "TextBounds"

    aput-object v11, v2, v16

    const-string v11, "ContentText"

    aput-object v11, v2, v18

    const-string v11, "TextFits"

    aput-object v11, v2, v6

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "TextBox"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v5

    .line 322
    nop

    .line 336
    new-array v2, v7, [Ljava/lang/String;

    const-string v11, "TextBounds"

    aput-object v11, v2, v16

    const-string v11, "ContentText"

    aput-object v11, v2, v18

    const-string v11, "TextFits"

    aput-object v11, v2, v6

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "TextLabel"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v14

    .line 322
    nop

    .line 336
    new-array v2, v7, [Ljava/lang/String;

    const-string v11, "TextBounds"

    aput-object v11, v2, v16

    const-string v11, "ContentText"

    aput-object v11, v2, v18

    const-string v11, "TextFits"

    aput-object v11, v2, v6

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "TextButton"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v20

    .line 322
    nop

    .line 337
    new-array v2, v6, [Ljava/lang/String;

    const-string v11, "ShowDevelopmentGui"

    aput-object v11, v2, v16

    const-string v11, "ResetPlayerGuiOnSpawn"

    aput-object v11, v2, v18

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "StarterGui"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v26

    .line 322
    nop

    .line 338
    new-array v2, v10, [Ljava/lang/String;

    const-string v11, "TimePosition"

    aput-object v11, v2, v16

    const-string v11, "TimeLength"

    aput-object v11, v2, v18

    const-string v11, "IsPlaying"

    aput-object v11, v2, v6

    const-string v11, "IsLoaded"

    aput-object v11, v2, v7

    const-string v11, "PlaybackSpeed"

    aput-object v11, v2, v8

    const-string v11, "PlaybackLoudness"

    const/16 v23, 0x5

    aput-object v11, v2, v23

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    const-string v11, "Sound"

    invoke-static {v11, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v3, v22

    .line 322
    nop

    .line 321
    invoke-static {v3}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->SPECIAL_PROPS:Ljava/util/Map;

    .line 609
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    move-object v3, v2

    .local v3, "$this$MEMBER_OWNERS_u24lambda_u2428\\1":Ljava/util/HashMap;
    const/4 v11, 0x0

    .line 610
    .local v11, "$i$a$-apply-InstanceApi$MEMBER_OWNERS$1\\1\\609\\0":I
    move/from16 v28, v5

    const/4 v15, 0x5

    new-array v5, v15, [Ljava/lang/String;

    const-string v15, "TextLabel"

    aput-object v15, v5, v16

    const-string v15, "TextButton"

    aput-object v15, v5, v18

    const-string v15, "TextBox"

    aput-object v15, v5, v6

    const-string v15, "Message"

    aput-object v15, v5, v7

    const-string v15, "Hint"

    aput-object v15, v5, v8

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    .line 611
    .local v5, "text\\1":Ljava/util/List;
    new-array v15, v9, [Ljava/lang/String;

    const-string v29, "Text"

    aput-object v29, v15, v16

    const-string v29, "TextScaled"

    aput-object v29, v15, v18

    const-string v29, "TextSize"

    aput-object v29, v15, v6

    const-string v29, "TextBounds"

    aput-object v29, v15, v7

    const-string v29, "TextColor3"

    aput-object v29, v15, v8

    const-string v29, "TextWrapped"

    const/16 v23, 0x5

    aput-object v29, v15, v23

    const-string v29, "TextXAlignment"

    aput-object v29, v15, v10

    const-string v29, "TextYAlignment"

    aput-object v29, v15, v27

    .line 612
    const-string v29, "Font"

    aput-object v29, v15, v12

    .line 611
    nop

    .line 612
    const-string v29, "FontFace"

    aput-object v29, v15, v13

    .line 611
    nop

    .line 612
    const-string v29, "TextTransparency"

    const/16 v19, 0xa

    aput-object v29, v15, v19

    .line 611
    nop

    .line 612
    const-string v29, "TextStrokeTransparency"

    const/16 v21, 0xb

    aput-object v29, v15, v21

    .line 611
    nop

    .line 612
    const-string v29, "TextStrokeColor3"

    aput-object v29, v15, v4

    .line 611
    nop

    .line 612
    const-string v29, "RichText"

    aput-object v29, v15, v17

    .line 611
    nop

    .line 612
    const-string v29, "LineHeight"

    aput-object v29, v15, v28

    .line 611
    nop

    .line 613
    const-string v29, "MaxVisibleGraphemes"

    aput-object v29, v15, v14

    .line 611
    nop

    .line 613
    const-string v29, "TextFits"

    aput-object v29, v15, v20

    .line 611
    nop

    .line 613
    const-string v29, "ContentText"

    aput-object v29, v15, v26

    .line 611
    nop

    .line 613
    const-string v29, "TextTruncate"

    aput-object v29, v15, v22

    .line 611
    nop

    .line 613
    const-string v29, "TextDirection"

    const/16 v25, 0x13

    aput-object v29, v15, v25

    .line 611
    nop

    .line 613
    const-string v29, "TextWrap"

    aput-object v29, v15, v24

    .line 611
    invoke-static {v15}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v15

    invoke-interface {v15}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_120f
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v29

    if-eqz v29, :cond_1225

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v29

    move/from16 v30, v9

    move-object/from16 v9, v29

    check-cast v9, Ljava/lang/String;

    .line 613
    .local v9, "k\\1":Ljava/lang/String;
    invoke-virtual {v3, v9, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move/from16 v9, v30

    goto :goto_120f

    .line 614
    .end local v9    # "k\\1":Ljava/lang/String;
    :cond_1225
    move/from16 v30, v9

    new-array v9, v12, [Ljava/lang/String;

    const-string v15, "PlaceholderText"

    aput-object v15, v9, v16

    const-string v15, "PlaceholderColor3"

    aput-object v15, v9, v18

    const-string v15, "ClearTextOnFocus"

    aput-object v15, v9, v6

    const-string v15, "MultiLine"

    aput-object v15, v9, v7

    const-string v15, "CursorPosition"

    aput-object v15, v9, v8

    const-string v15, "SelectionStart"

    const/16 v23, 0x5

    aput-object v15, v9, v23

    const-string v15, "TextEditable"

    aput-object v15, v9, v10

    const-string v15, "ShowNativeInput"

    aput-object v15, v9, v27

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_1253
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_126d

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    .line 615
    .local v15, "k\\1":Ljava/lang/String;
    const-string v29, "TextBox"

    move/from16 v31, v10

    invoke-static/range {v29 .. v29}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    invoke-virtual {v3, v15, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move/from16 v10, v31

    goto :goto_1253

    .line 616
    .end local v15    # "k\\1":Ljava/lang/String;
    :cond_126d
    move/from16 v31, v10

    move/from16 v9, v27

    new-array v10, v9, [Ljava/lang/String;

    const-string v9, "ScaleType"

    aput-object v9, v10, v16

    const-string v9, "SliceCenter"

    aput-object v9, v10, v18

    const-string v9, "SliceScale"

    aput-object v9, v10, v6

    const-string v9, "ImageRectOffset"

    aput-object v9, v10, v7

    const-string v9, "ImageRectSize"

    aput-object v9, v10, v8

    const-string v9, "TileSize"

    const/16 v23, 0x5

    aput-object v9, v10, v23

    const-string v9, "ResampleMode"

    aput-object v9, v10, v31

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_1299
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_12b7

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 617
    .local v10, "k\\1":Ljava/lang/String;
    new-array v15, v6, [Ljava/lang/String;

    const-string v29, "ImageLabel"

    aput-object v29, v15, v16

    const-string v29, "ImageButton"

    aput-object v29, v15, v18

    invoke-static {v15}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v15

    invoke-virtual {v3, v10, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1299

    .line 618
    .end local v10    # "k\\1":Ljava/lang/String;
    :cond_12b7
    new-array v9, v7, [Ljava/lang/String;

    const-string v10, "ImageLabel"

    aput-object v10, v9, v16

    const-string v10, "ImageButton"

    aput-object v10, v9, v18

    const-string v10, "ImageHandleAdornment"

    aput-object v10, v9, v6

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    const-string v10, "Image"

    invoke-virtual {v3, v10, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 619
    new-array v9, v6, [Ljava/lang/String;

    const-string v10, "ImageColor3"

    aput-object v10, v9, v16

    const-string v10, "ImageTransparency"

    aput-object v10, v9, v18

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_12e0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_1302

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .restart local v10    # "k\\1":Ljava/lang/String;
    new-array v15, v7, [Ljava/lang/String;

    const-string v29, "ImageLabel"

    aput-object v29, v15, v16

    const-string v29, "ImageButton"

    aput-object v29, v15, v18

    const-string v29, "ViewportFrame"

    aput-object v29, v15, v6

    invoke-static {v15}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v15

    invoke-virtual {v3, v10, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_12e0

    .line 620
    .end local v10    # "k\\1":Ljava/lang/String;
    :cond_1302
    new-array v9, v4, [Ljava/lang/String;

    const-string v10, "BackgroundColor3"

    aput-object v10, v9, v16

    const-string v10, "BackgroundTransparency"

    aput-object v10, v9, v18

    const-string v10, "BorderColor3"

    aput-object v10, v9, v6

    const-string v10, "BorderSizePixel"

    aput-object v10, v9, v7

    const-string v10, "BorderMode"

    aput-object v10, v9, v8

    const-string v10, "AnchorPoint"

    const/16 v23, 0x5

    aput-object v10, v9, v23

    const-string v10, "AutomaticSize"

    aput-object v10, v9, v31

    .line 621
    const-string v10, "ClipsDescendants"

    const/16 v27, 0x7

    aput-object v10, v9, v27

    .line 620
    nop

    .line 621
    const-string v10, "LayoutOrder"

    aput-object v10, v9, v12

    .line 620
    nop

    .line 621
    const-string v10, "SizeConstraint"

    aput-object v10, v9, v13

    .line 620
    nop

    .line 621
    const-string v10, "Selectable"

    const/16 v19, 0xa

    aput-object v10, v9, v19

    .line 620
    nop

    .line 621
    const-string v10, "Interactable"

    const/16 v21, 0xb

    aput-object v10, v9, v21

    .line 620
    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_1348
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_135e

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 621
    .restart local v10    # "k\\1":Ljava/lang/String;
    const-string v15, "GuiObject"

    invoke-static {v15}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v15

    invoke-virtual {v3, v10, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1348

    .line 622
    .end local v10    # "k\\1":Ljava/lang/String;
    :cond_135e
    new-array v9, v7, [Ljava/lang/String;

    const-string v10, "AutoButtonColor"

    aput-object v10, v9, v16

    const-string v10, "Modal"

    aput-object v10, v9, v18

    const-string v10, "Selected"

    aput-object v10, v9, v6

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_1374
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_138a

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .restart local v10    # "k\\1":Ljava/lang/String;
    const-string v15, "GuiButton"

    invoke-static {v15}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v15

    invoke-virtual {v3, v10, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1374

    .line 623
    .end local v10    # "k\\1":Ljava/lang/String;
    :cond_138a
    const/16 v9, 0x18

    new-array v9, v9, [Ljava/lang/String;

    const-string v10, "Anchored"

    aput-object v10, v9, v16

    const-string v10, "CanCollide"

    aput-object v10, v9, v18

    const-string v10, "CanTouch"

    aput-object v10, v9, v6

    const-string v10, "CanQuery"

    aput-object v10, v9, v7

    const-string v10, "CastShadow"

    aput-object v10, v9, v8

    const-string v10, "Massless"

    const/16 v23, 0x5

    aput-object v10, v9, v23

    const-string v10, "Reflectance"

    aput-object v10, v9, v31

    const-string v10, "Material"

    const/16 v27, 0x7

    aput-object v10, v9, v27

    const-string v10, "MaterialVariant"

    aput-object v10, v9, v12

    .line 624
    const-string v10, "AssemblyLinearVelocity"

    aput-object v10, v9, v13

    .line 623
    nop

    .line 624
    const-string v10, "AssemblyAngularVelocity"

    const/16 v19, 0xa

    aput-object v10, v9, v19

    .line 623
    nop

    .line 624
    const-string v10, "AssemblyMass"

    const/16 v21, 0xb

    aput-object v10, v9, v21

    .line 623
    nop

    .line 624
    const-string v10, "AssemblyRootPart"

    aput-object v10, v9, v4

    .line 623
    nop

    .line 624
    const-string v4, "CollisionGroup"

    aput-object v4, v9, v17

    .line 623
    nop

    .line 624
    const-string v4, "CustomPhysicalProperties"

    aput-object v4, v9, v28

    .line 623
    nop

    .line 625
    const-string v4, "TopSurface"

    aput-object v4, v9, v14

    .line 623
    nop

    .line 625
    const-string v4, "BottomSurface"

    aput-object v4, v9, v20

    .line 623
    nop

    .line 625
    const-string v4, "FrontSurface"

    aput-object v4, v9, v26

    .line 623
    nop

    .line 625
    const-string v4, "BackSurface"

    aput-object v4, v9, v22

    .line 623
    nop

    .line 625
    const-string v4, "LeftSurface"

    const/16 v25, 0x13

    aput-object v4, v9, v25

    .line 623
    nop

    .line 625
    const-string v4, "RightSurface"

    aput-object v4, v9, v24

    .line 623
    nop

    .line 625
    const-string v4, "BrickColor"

    aput-object v4, v9, v30

    .line 623
    nop

    .line 625
    const-string v4, "Locked"

    const/16 v10, 0x16

    aput-object v4, v9, v10

    .line 623
    nop

    .line 625
    const-string v4, "RootPriority"

    const/16 v10, 0x17

    aput-object v4, v9, v10

    .line 623
    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1412
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_1428

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .line 626
    .restart local v9    # "k\\1":Ljava/lang/String;
    const-string v10, "BasePart"

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    invoke-virtual {v3, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1412

    .line 627
    .end local v9    # "k\\1":Ljava/lang/String;
    :cond_1428
    new-array v4, v7, [Ljava/lang/String;

    const-string v9, "ValueBase"

    aput-object v9, v4, v16

    const-string v9, "IntConstrainedValue"

    aput-object v9, v4, v18

    const-string v9, "DoubleConstrainedValue"

    aput-object v9, v4, v6

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "Value"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 628
    const-string v4, "Model"

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "PrimaryPart"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 629
    const-string v4, "PVInstance"

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "WorldPivot"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 630
    const-string v4, "LuaSourceContainer"

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "Source"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 631
    const-string v4, "BaseScript"

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "Disabled"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 632
    new-array v4, v8, [Ljava/lang/String;

    const-string v9, "SoundId"

    aput-object v9, v4, v16

    const-string v9, "IsPaused"

    aput-object v9, v4, v18

    const-string v9, "RollOffMode"

    aput-object v9, v4, v6

    const-string v9, "SoundGroup"

    aput-object v9, v4, v7

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1485
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_149b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .restart local v9    # "k\\1":Ljava/lang/String;
    const-string v10, "Sound"

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    invoke-virtual {v3, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1485

    .line 633
    .end local v9    # "k\\1":Ljava/lang/String;
    :cond_149b
    const/4 v15, 0x5

    new-array v4, v15, [Ljava/lang/String;

    const-string v9, "Sound"

    aput-object v9, v4, v16

    const-string v9, "SoundGroup"

    aput-object v9, v4, v18

    const-string v9, "AudioPlayer"

    aput-object v9, v4, v6

    const-string v9, "AudioFader"

    aput-object v9, v4, v7

    const-string v9, "VideoFrame"

    aput-object v9, v4, v8

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "Volume"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 634
    new-array v4, v7, [Ljava/lang/String;

    const-string v9, "TimePosition"

    aput-object v9, v4, v16

    const-string v9, "TimeLength"

    aput-object v9, v4, v18

    const-string v9, "IsPlaying"

    aput-object v9, v4, v6

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_14d1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_14f3

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .restart local v9    # "k\\1":Ljava/lang/String;
    new-array v10, v7, [Ljava/lang/String;

    const-string v13, "Sound"

    aput-object v13, v10, v16

    const-string v13, "AudioPlayer"

    aput-object v13, v10, v18

    const-string v13, "VideoFrame"

    aput-object v13, v10, v6

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    invoke-virtual {v3, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_14d1

    .line 635
    .end local v9    # "k\\1":Ljava/lang/String;
    :cond_14f3
    new-array v4, v6, [Ljava/lang/String;

    const-string v9, "Sound"

    aput-object v9, v4, v16

    const-string v9, "VideoFrame"

    aput-object v9, v4, v18

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "Looped"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 636
    new-array v4, v6, [Ljava/lang/String;

    const-string v9, "Sound"

    aput-object v9, v4, v16

    const-string v9, "AudioPlayer"

    aput-object v9, v4, v18

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "PlaybackSpeed"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 637
    new-array v4, v12, [Ljava/lang/String;

    const-string v9, "WalkSpeed"

    aput-object v9, v4, v16

    const-string v9, "JumpPower"

    aput-object v9, v4, v18

    const-string v9, "JumpHeight"

    aput-object v9, v4, v6

    const-string v9, "Health"

    aput-object v9, v4, v7

    const-string v9, "MaxHealth"

    aput-object v9, v4, v8

    const-string v9, "HipHeight"

    const/16 v23, 0x5

    aput-object v9, v4, v23

    const-string v9, "RigType"

    aput-object v9, v4, v31

    const-string v9, "UseJumpPower"

    const/16 v27, 0x7

    aput-object v9, v4, v27

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1547
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_155d

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .restart local v9    # "k\\1":Ljava/lang/String;
    const-string v10, "Humanoid"

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    invoke-virtual {v3, v9, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1547

    .line 638
    .end local v9    # "k\\1":Ljava/lang/String;
    :cond_155d
    new-array v4, v6, [Ljava/lang/String;

    const-string v9, "Humanoid"

    aput-object v9, v4, v16

    const-string v9, "Player"

    aput-object v9, v4, v18

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v9, "DisplayName"

    invoke-virtual {v3, v9, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 639
    nop

    .line 609
    .end local v3    # "$this$MEMBER_OWNERS_u24lambda_u2428\\1":Ljava/util/HashMap;
    .end local v5    # "text\\1":Ljava/util/List;
    .end local v11    # "$i$a$-apply-InstanceApi$MEMBER_OWNERS$1\\1\\609\\0":I
    check-cast v2, Ljava/util/Map;

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->MEMBER_OWNERS:Ljava/util/Map;

    .line 647
    const/4 v9, 0x7

    new-array v2, v9, [Lkotlin/Pair;

    const-string v3, "Idle"

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v16

    const-string v3, "Movement"

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v18

    const-string v3, "Action"

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v6

    const-string v3, "Action2"

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v7

    const-string v3, "Action3"

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v8

    const-string v3, "Action4"

    const/16 v23, 0x5

    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v23

    const/16 v3, 0x3e8

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v4, "Core"

    invoke-static {v4, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v31

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    iput-object v2, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->PRIORITIES:Ljava/util/List;

    .line 16
    return-void
.end method

.method static final _init_$lambda$0(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "self"    # Lorg/luaj/vm2/LuaValue;
    .param p2, "key"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "self"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Instance"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v1

    const-string v2, "tojstring(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->index(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0
.end method

.method static final _init_$lambda$1(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 3
    .param p0, "it"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Instance"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method static final _init_$lambda$5(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 7
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "self"    # Lorg/luaj/vm2/LuaValue;
    .param p2, "key"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "self"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.lua.SignalRef"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    .line 143
    .local v0, "s":Lcom/exampletest/mobilestudiotest/lua/SignalRef;
    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_7a

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    sparse-switch v2, :sswitch_data_98

    goto :goto_7a

    :sswitch_23
    const-string v2, "connect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    goto :goto_6e

    :sswitch_2c
    const-string v2, "wait"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    goto :goto_3d

    :sswitch_35
    const-string v2, "Wait"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    .line 146
    :goto_3d
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_79

    .line 143
    :sswitch_49
    const-string v2, "Once"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    .line 145
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_79

    .line 143
    :sswitch_5d
    const-string v2, "ConnectParallel"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    goto :goto_6e

    :sswitch_66
    const-string v2, "Connect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7a

    .line 144
    :goto_6e
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    .line 148
    :goto_79
    return-object v1

    .line 147
    :cond_7a
    :goto_7a
    new-instance v1, Lorg/luaj/vm2/LuaError;

    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " is not a valid member of RBXScriptSignal"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    nop

    :sswitch_data_98
    .sparse-switch
        -0x6412ef36 -> :sswitch_66
        -0x1276c70f -> :sswitch_5d
        0x2592a1 -> :sswitch_49
        0x290595 -> :sswitch_35
        0x379175 -> :sswitch_2c
        0x38b478ea -> :sswitch_23
    .end sparse-switch
.end method

.method static final _init_$lambda$6(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 4
    .param p0, "it"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 150
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.lua.SignalRef"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/SignalRef;->getName()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Signal "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method static final _init_$lambda$8(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "self"    # Lorg/luaj/vm2/LuaValue;
    .param p2, "key"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "self"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 154
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.lua.Connection"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/Connection;

    .line 155
    .local v0, "c":Lcom/exampletest/mobilestudiotest/lua/Connection;
    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_58

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    sparse-switch v2, :sswitch_data_60

    goto :goto_58

    :sswitch_23
    const-string v2, "Connected"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_58

    .line 157
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/Connection;->getConnected()Z

    move-result v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v1

    const-string v2, "valueOf(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_5f

    .line 155
    :sswitch_3b
    const-string v2, "disconnect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4c

    goto :goto_58

    :sswitch_44
    const-string v2, "Disconnect"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_58

    .line 156
    :cond_4c
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/Connection;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_5f

    .line 158
    :cond_58
    :goto_58
    sget-object v1, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v2, "NIL"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 159
    :goto_5f
    return-object v1

    :sswitch_data_60
    .sparse-switch
        -0x6990cb44 -> :sswitch_44
        0x1f9d589c -> :sswitch_3b
        0x54ec12e9 -> :sswitch_23
    .end sparse-switch
.end method

.method private final animationTrack(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaTable;
    .registers 16
    .param p1, "owner"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "anim"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 657
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v6, v0

    .line 658
    .local v6, "t":Lorg/luaj/vm2/LuaTable;
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v3

    .line 659
    .local v3, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    if-eqz v3, :cond_13

    invoke-virtual {v3, p1, p2, v6}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->loadTrack(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;Lorg/luaj/vm2/LuaTable;)Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    move-result-object v0

    goto :goto_14

    :cond_13
    const/4 v0, 0x0

    :goto_14
    move-object v2, v0

    .line 660
    .local v2, "st":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    new-instance v4, Lkotlin/jvm/internal/Ref$BooleanRef;

    invoke-direct {v4}, Lkotlin/jvm/internal/Ref$BooleanRef;-><init>()V

    .line 661
    .local v4, "playing":Lkotlin/jvm/internal/Ref$BooleanRef;
    new-instance v0, Lkotlin/jvm/internal/Ref$FloatRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$FloatRef;-><init>()V

    .local v0, "speed":Lkotlin/jvm/internal/Ref$FloatRef;
    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, v0, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    .line 662
    new-instance v5, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v5}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    move-object v7, v5

    .line 663
    .local v7, "looped":Lkotlin/jvm/internal/Ref$ObjectRef;
    new-instance v1, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v1}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    move-object v8, v1

    .line 664
    .local v8, "priority":Lkotlin/jvm/internal/Ref$ObjectRef;
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;

    invoke-direct {v1, v0, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    const-string v5, "Play"

    invoke-virtual {v6, v5, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 670
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;

    move-object v5, p0

    invoke-direct/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;-><init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;)V

    move-object v10, v3

    move-object v3, v4

    .end local v4    # "playing":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v3, "playing":Lkotlin/jvm/internal/Ref$BooleanRef;
    .local v10, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    const-string v4, "Stop"

    invoke-virtual {v6, v4, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 675
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;

    invoke-direct {v1, v0, v2, v10}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;-><init>(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    const-string v4, "AdjustSpeed"

    invoke-virtual {v6, v4, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 676
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda6;

    invoke-direct {v1, v2, v10}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda6;-><init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    const-string v4, "AdjustWeight"

    invoke-virtual {v6, v4, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 677
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, v6}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda7;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    const-string v4, "GetMarkerReachedSignal"

    invoke-virtual {v6, v4, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 678
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda8;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda8;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    const-string v4, "GetTimeOfKeyframe"

    invoke-virtual {v6, v4, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 679
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda9;

    invoke-direct {v1, v2, v10}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda9;-><init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    const-string v4, "Destroy"

    invoke-virtual {v6, v4, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 680
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v4, "Animation"

    invoke-virtual {v6, v4, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 681
    new-instance v1, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v1}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v11, v1

    .line 682
    .local v11, "mt":Lorg/luaj/vm2/LuaTable;
    sget-object v1, Lorg/luaj/vm2/LuaValue;->INDEX:Lorg/luaj/vm2/LuaString;

    move-object v12, v1

    check-cast v12, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;

    move-object v4, v0

    move-object v9, v6

    move-object v5, v7

    move-object v7, v8

    move-object v6, p0

    move-object v8, p2

    .end local v0    # "speed":Lkotlin/jvm/internal/Ref$FloatRef;
    .end local v6    # "t":Lorg/luaj/vm2/LuaTable;
    .end local p2    # "anim":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v4, "speed":Lkotlin/jvm/internal/Ref$FloatRef;
    .local v5, "looped":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v7, "priority":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v8, "anim":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v9, "t":Lorg/luaj/vm2/LuaTable;
    invoke-direct/range {v1 .. v9}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;-><init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/model/Instance;Lorg/luaj/vm2/LuaTable;)V

    move-object v6, v9

    .end local v9    # "t":Lorg/luaj/vm2/LuaTable;
    .restart local v6    # "t":Lorg/luaj/vm2/LuaTable;
    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object p2

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v11, v12, p2}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 697
    sget-object p2, Lorg/luaj/vm2/LuaValue;->NEWINDEX:Lorg/luaj/vm2/LuaString;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;

    invoke-direct {v0, v5, v2, v7, v10}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;-><init>(Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v11, p2, v0}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 708
    move-object p2, v11

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v6, p2}, Lorg/luaj/vm2/LuaTable;->setmetatable(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    .line 709
    return-object v6
.end method

.method static final animationTrack$lambda$30(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "$speed"    # Lkotlin/jvm/internal/Ref$FloatRef;
    .param p1, "$st"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .param p2, "$play"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .param p3, "$playing"    # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p4, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 665
    const/4 v0, 0x2

    invoke-virtual {p4, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-wide v1, 0x3fb999999999999aL    # 0.1

    invoke-virtual {v0, v1, v2}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v0

    double-to-float v0, v0

    .local v0, "fade":F
    const/4 v1, 0x3

    invoke-virtual {p4, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    invoke-virtual {v1, v2, v3}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v1

    double-to-float v1, v1

    .local v1, "w":F
    const/4 v2, 0x4

    invoke-virtual {p4, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    iget v3, p0, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    float-to-double v3, v3

    invoke-virtual {v2, v3, v4}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v2

    double-to-float v2, v2

    .line 666
    .local v2, "sp":F
    iput v2, p0, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    .line 667
    if-eqz p1, :cond_37

    if-eqz p2, :cond_3a

    invoke-virtual {p2, p1, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->playTrack(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;FFF)V

    goto :goto_3a

    :cond_37
    const/4 v3, 0x1

    iput-boolean v3, p3, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 668
    :cond_3a
    :goto_3a
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v4, "NONE"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    return-object v3
.end method

.method static final animationTrack$lambda$31(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p0, "$st"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .param p1, "$play"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .param p2, "$playing"    # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p3, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p4, "$t"    # Lorg/luaj/vm2/LuaTable;
    .param p5, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 671
    const/4 v0, 0x2

    invoke-virtual {p5, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-wide v1, 0x3fb999999999999aL    # 0.1

    invoke-virtual {v0, v1, v2}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v0

    double-to-float v0, v0

    .line 672
    .local v0, "fade":F
    if-eqz p0, :cond_1c

    if-eqz p1, :cond_35

    invoke-virtual {p1, p0, v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->stopTrack(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;F)V

    goto :goto_35

    :cond_1c
    iget-boolean v1, p2, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-eqz v1, :cond_35

    const/4 v1, 0x0

    iput-boolean v1, p2, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    iget-object v2, p3, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    const-string v3, "Stopped"

    new-array v4, v1, [Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v2, p4, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    iget-object v2, p3, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    const-string v3, "Ended"

    new-array v1, v1, [Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v2, p4, v3, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .line 673
    :cond_35
    :goto_35
    sget-object v1, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v2, "NONE"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lorg/luaj/vm2/Varargs;

    return-object v1
.end method

.method static final animationTrack$lambda$33(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 15
    .param p0, "$speed"    # Lkotlin/jvm/internal/Ref$FloatRef;
    .param p1, "$st"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .param p2, "$play"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .param p3, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 675
    const/4 v0, 0x2

    invoke-virtual {p3, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    invoke-virtual {v0, v1, v2}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v0

    double-to-float v0, v0

    iput v0, p0, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    if-eqz p1, :cond_2e

    move-object v2, p1

    .line 1017
    .local v2, "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    const/4 v0, 0x0

    .line 675
    .local v0, "$i$a$-let-InstanceApi$animationTrack$3$1\\1\\675\\0":I
    if-eqz p2, :cond_2c

    iget v1, p0, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    const/16 v9, 0x7c

    const/4 v10, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v1, p2

    .end local p2    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .local v1, "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    invoke-static/range {v1 .. v10}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->adjustTrack$default(Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Float;ILjava/lang/Object;)V

    goto :goto_2f

    .end local v1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local p2    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :cond_2c
    move-object v1, p2

    .end local p2    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    goto :goto_2f

    .end local v0    # "$i$a$-let-InstanceApi$animationTrack$3$1\\1\\675\\0":I
    .end local v1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v2    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .restart local p2    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :cond_2e
    move-object v1, p2

    .end local p2    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :goto_2f
    sget-object p2, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v0, "NONE"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Lorg/luaj/vm2/Varargs;

    return-object p2
.end method

.method static final animationTrack$lambda$35(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 14
    .param p0, "$st"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .param p1, "$play"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 676
    if-eqz p0, :cond_3c

    move-object v2, p0

    .line 1017
    .local v2, "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    const/4 v0, 0x0

    .line 676
    .local v0, "$i$a$-let-InstanceApi$animationTrack$4$1\\1\\676\\0":I
    if-eqz p1, :cond_3a

    const/4 v1, 0x2

    invoke-virtual {p2, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    invoke-virtual {v1, v3, v4}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v3

    double-to-float v1, v3

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    const/4 v1, 0x3

    invoke-virtual {p2, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-wide v5, 0x3fb999999999999aL    # 0.1

    invoke-virtual {v1, v5, v6}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v5

    double-to-float v1, v5

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    const/16 v9, 0x72

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v1, p1

    .end local p1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .local v1, "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    invoke-static/range {v1 .. v10}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->adjustTrack$default(Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Float;ILjava/lang/Object;)V

    goto :goto_3d

    .end local v1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local p1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :cond_3a
    move-object v1, p1

    .end local p1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    goto :goto_3d

    .end local v0    # "$i$a$-let-InstanceApi$animationTrack$4$1\\1\\676\\0":I
    .end local v1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v2    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .restart local p1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :cond_3c
    move-object v1, p1

    .end local p1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .restart local v1    # "$play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    :goto_3d
    sget-object p1, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v0, "NONE"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p1, Lorg/luaj/vm2/Varargs;

    return-object p1
.end method

.method static final animationTrack$lambda$36(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 6
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "$t"    # Lorg/luaj/vm2/LuaTable;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 677
    const/4 v0, 0x2

    invoke-virtual {p2, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Marker:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final animationTrack$lambda$37(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 3
    .param p0, "it"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 678
    const/4 v0, 0x0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final animationTrack$lambda$39(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 5
    .param p0, "$st"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .param p1, "$play"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    const-string v0, "<unused var>"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 679
    if-eqz p0, :cond_f

    move-object p2, p0

    .line 1017
    .local p2, "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    const/4 v0, 0x0

    .line 679
    .local v0, "$i$a$-let-InstanceApi$animationTrack$7$1\\1\\679\\0":I
    if-eqz p1, :cond_f

    const/4 v1, 0x0

    invoke-virtual {p1, p2, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->stopTrack(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;F)V

    .end local v0    # "$i$a$-let-InstanceApi$animationTrack$7$1\\1\\679\\0":I
    .end local p2    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    :cond_f
    sget-object p2, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v0, "NONE"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Lorg/luaj/vm2/Varargs;

    return-object p2
.end method

.method static final animationTrack$lambda$40(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/model/Instance;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 14
    .param p0, "$st"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .param p1, "$playing"    # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p2, "$speed"    # Lkotlin/jvm/internal/Ref$FloatRef;
    .param p3, "$looped"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p4, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p5, "$priority"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p6, "$anim"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p7, "$t"    # Lorg/luaj/vm2/LuaTable;
    .param p9, "k"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "<unused var>"

    invoke-static {p8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p8, "k"

    invoke-static {p9, p8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 683
    invoke-virtual {p9}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object p8

    .local p8, "ks":Ljava/lang/String;
    if-eqz p8, :cond_164

    invoke-virtual {p8}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v2, 0x0

    const-string v3, "valueOf(...)"

    sparse-switch v0, :sswitch_data_16c

    goto/16 :goto_164

    :sswitch_1e
    const-string v0, "WeightCurrent"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 690
    if-eqz p0, :cond_2d

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getWeightNow()F

    move-result v1

    goto :goto_32

    :cond_2d
    iget-boolean v0, p1, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-nez v0, :cond_32

    move v1, v2

    :cond_32
    :goto_32
    float-to-double v0, v1

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_3e
    const-string v0, "TimePosition"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 686
    if-eqz p0, :cond_4c

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getTime()F

    move-result v2

    :cond_4c
    float-to-double v0, v2

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_58
    const-string v0, "IsPlaying"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 684
    if-eqz p0, :cond_67

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->isPlaying()Z

    move-result v0

    goto :goto_69

    :cond_67
    iget-boolean v0, p1, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    :goto_69
    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_74
    const-string v0, "Speed"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 687
    iget v0, p2, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    float-to-double v0, v0

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_8a
    const-string v0, "Ended"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_120

    goto/16 :goto_164

    :sswitch_94
    const-string v0, "Name"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 692
    if-eqz p6, :cond_a5

    invoke-virtual {p6}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_a5

    goto :goto_a7

    :cond_a5
    const-string v0, "Animation"

    :goto_a7
    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_b2
    const-string v0, "WeightTarget"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 691
    if-eqz p0, :cond_c1

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getWeightTarget()F

    move-result v1

    goto :goto_c6

    :cond_c1
    iget-boolean v0, p1, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-nez v0, :cond_c6

    move v1, v2

    :cond_c6
    :goto_c6
    float-to-double v0, v1

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto/16 :goto_16b

    .line 683
    :sswitch_d2
    const-string v0, "Stopped"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_120

    goto/16 :goto_164

    :sswitch_dc
    const-string v0, "KeyframeReached"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_120

    goto/16 :goto_164

    :sswitch_e6
    const-string v0, "DidLoop"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_120

    goto/16 :goto_164

    :sswitch_f0
    const-string v0, "Priority"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 689
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    if-eqz p0, :cond_102

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getPriority()Ljava/lang/Integer;

    move-result-object v1

    if-nez v1, :cond_108

    :cond_102
    iget-object v1, p5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    if-eqz v1, :cond_10d

    :cond_108
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    goto :goto_10f

    :cond_10d
    const/16 v1, 0x3e8

    :goto_10f
    invoke-direct {p4, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->priorityItem(I)Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_16b

    .line 683
    :sswitch_118
    const-string v0, "Played"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 693
    :cond_120
    invoke-virtual {p4, p7, p8}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_16b

    .line 683
    :sswitch_125
    const-string v0, "Looped"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 688
    if-eqz p0, :cond_135

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getLooped()Ljava/lang/Boolean;

    move-result-object v0

    if-nez v0, :cond_13b

    :cond_135
    iget-object v0, p3, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    if-eqz v0, :cond_140

    :cond_13b
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    goto :goto_141

    :cond_140
    const/4 v0, 0x0

    :goto_141
    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto :goto_16b

    .line 683
    :sswitch_14b
    const-string v0, "Length"

    invoke-virtual {p8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_164

    .line 685
    if-eqz p0, :cond_159

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;->getLength()F

    move-result v2

    :cond_159
    float-to-double v0, v2

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    goto :goto_16b

    .line 694
    :cond_164
    :goto_164
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NIL"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 695
    .end local p8    # "ks":Ljava/lang/String;
    :goto_16b
    return-object v0

    :sswitch_data_16c
    .sparse-switch
        -0x788cd8fa -> :sswitch_14b
        -0x77ff599d -> :sswitch_125
        -0x715c790d -> :sswitch_118
        -0x419d223c -> :sswitch_f0
        -0x3a06005d -> :sswitch_e6
        -0x253e011c -> :sswitch_dc
        -0xd17d653 -> :sswitch_d2
        -0xa0dc5b7 -> :sswitch_b2
        0x24eeab -> :sswitch_94
        0x3ffda9a -> :sswitch_8a
        0x4c61027 -> :sswitch_74
        0x37783784 -> :sswitch_58
        0x4ac98736 -> :sswitch_3e
        0x67310bc1 -> :sswitch_1e
    .end sparse-switch
.end method

.method private final connectionValue(Lcom/exampletest/mobilestudiotest/lua/Connection;)Lorg/luaj/vm2/LuaValue;
    .registers 4
    .param p1, "c"    # Lcom/exampletest/mobilestudiotest/lua/Connection;

    .line 164
    new-instance v0, Lorg/luaj/vm2/LuaUserdata;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->connMeta:Lorg/luaj/vm2/LuaTable;

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-direct {v0, p1, v1}, Lorg/luaj/vm2/LuaUserdata;-><init>(Ljava/lang/Object;Lorg/luaj/vm2/LuaValue;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method private final contentAlias(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;
    .registers 6
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "key"    # Ljava/lang/String;

    .line 519
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_c

    return-object v1

    .line 520
    :cond_c
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_66

    goto :goto_48

    :sswitch_14
    const-string v0, "ColorMapContent"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_48

    .line 524
    const-string v1, "ColorMap"

    goto :goto_64

    .line 520
    :sswitch_1f
    const-string v0, "ImageContent"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_48

    .line 521
    const-string v1, "Image"

    goto :goto_64

    .line 520
    :sswitch_2a
    const-string v0, "NormalMapContent"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_48

    .line 525
    const-string v1, "NormalMap"

    goto :goto_64

    .line 520
    :sswitch_35
    const-string v0, "MeshContent"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_48

    .line 523
    const-string v1, "MeshId"

    goto :goto_64

    .line 520
    :sswitch_40
    const-string v0, "TextureContent"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_49

    :cond_48
    :goto_48
    goto :goto_63

    .line 522
    :cond_49
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "MeshPart"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_58

    const-string v1, "TextureID"

    goto :goto_64

    :cond_58
    const-string v0, "Decal"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_64

    const-string v1, "Texture"

    goto :goto_64

    .line 526
    :goto_63
    nop

    .line 520
    :cond_64
    :goto_64
    return-object v1

    nop

    :sswitch_data_66
    .sparse-switch
        -0x72d12102 -> :sswitch_40
        -0x6c14b654 -> :sswitch_35
        0x4465cfe4 -> :sswitch_2a
        0x662b4abe -> :sswitch_1f
        0x6d34cb20 -> :sswitch_14
    .end sparse-switch
.end method

.method private final filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;
    .registers 8
    .param p1, "params"    # Lorg/luaj/vm2/LuaValue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/luaj/vm2/LuaValue;",
            ")",
            "Lkotlin/jvm/functions/Function1<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .line 581
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v0

    if-nez v0, :cond_c

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda0;-><init>()V

    return-object v0

    .line 582
    :cond_c
    const-string v0, "FilterDescendantsInstances"

    invoke-virtual {p1, v0}, Lorg/luaj/vm2/LuaValue;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "get(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v0

    .line 583
    .local v0, "list":Ljava/util/List;
    const-string v2, "FilterType"

    invoke-virtual {p1, v2}, Lorg/luaj/vm2/LuaValue;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v2, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v1, 0x0

    .line 1039
    .local v1, "$i$f$udOrNull\\1\\583":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_31

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_32

    :cond_31
    move-object v3, v4

    :goto_32
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v5, :cond_37

    move-object v4, v3

    :cond_37
    check-cast v4, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 583
    .end local v1    # "$i$f$udOrNull\\1\\583":I
    .end local v2    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v1, 0x0

    if-eqz v4, :cond_44

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_44

    move v1, v3

    .line 584
    .local v1, "include":Z
    :cond_44
    const-string v2, "RespectCanCollide"

    invoke-virtual {p1, v2}, Lorg/luaj/vm2/LuaValue;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v2

    .line 585
    .local v2, "respectCollide":Z
    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;

    invoke-direct {v3, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;-><init>(Ljava/util/List;ZZ)V

    return-object v3
.end method

.method static final filterFrom$lambda$25(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 3
    .param p0, "it"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 581
    const-string v0, "CanQuery"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method static final filterFrom$lambda$27(Ljava/util/List;ZZLcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 14
    .param p0, "$list"    # Ljava/util/List;
    .param p1, "$include"    # Z
    .param p2, "$respectCollide"    # Z
    .param p3, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "p"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 586
    move-object v0, p0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1102
    .local v1, "$i$f$any\\1\\586":I
    instance-of v2, v0, Ljava/util/Collection;

    const/4 v3, 0x1

    const/4 v4, 0x0

    .line 587
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    .line 1102
    if-eqz v2, :cond_1e

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1e

    move v0, v4

    goto :goto_40

    .line 1103
    :cond_1e
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_22
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\1":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "f\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 586
    .local v8, "$i$a$-any-InstanceApi$filterFrom$2$inList$1\\2\\1103\\0":I
    if-eq p3, v7, :cond_3a

    invoke-virtual {p3, v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v9

    if-nez v9, :cond_3a

    move v7, v4

    goto :goto_3b

    :cond_3a
    move v7, v3

    .line 1103
    .end local v7    # "f\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-any-InstanceApi$filterFrom$2$inList$1\\2\\1103\\0":I
    :goto_3b
    if-eqz v7, :cond_22

    move v0, v3

    goto :goto_40

    .line 1104
    .end local v6    # "element\\1":Ljava/lang/Object;
    :cond_3f
    move v0, v4

    .line 586
    .end local v0    # "$this$any\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$any\\1\\586":I
    :goto_40
    nop

    .line 587
    .local v0, "inList":Z
    if-eqz p1, :cond_45

    move v1, v0

    goto :goto_4a

    :cond_45
    if-nez v0, :cond_49

    move v1, v3

    goto :goto_4a

    :cond_49
    move v1, v4

    :goto_4a
    if-eqz v1, :cond_67

    const-string v1, "CanQuery"

    invoke-virtual {p3, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_67

    if-eqz p2, :cond_66

    const-string v1, "CanCollide"

    invoke-virtual {p3, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_67

    :cond_66
    goto :goto_68

    :cond_67
    move v3, v4

    :goto_68
    return v3
.end method

.method static final index$lambda$12$lambda$11(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "$k"    # Ljava/lang/String;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 453
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->callMethod(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    return-object v0
.end method

.method private final instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;
    .registers 10
    .param p1, "v"    # Lorg/luaj/vm2/LuaValue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/luaj/vm2/LuaValue;",
            ")",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 569
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v0

    if-nez v0, :cond_b

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 570
    :cond_b
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 571
    .local v0, "out":Ljava/util/ArrayList;
    const/4 v1, 0x1

    .local v1, "k":I
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->length()I

    move-result v2

    if-gt v1, v2, :cond_40

    :goto_17
    invoke-virtual {p1, v1}, Lorg/luaj/vm2/LuaValue;->get(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-string v4, "get(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v3, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v4, 0x0

    .line 1038
    .local v4, "$i$f$udOrNull\\1\\571":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_2d

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_2e

    :cond_2d
    move-object v5, v6

    :goto_2e
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v7, :cond_33

    move-object v6, v5

    :cond_33
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 571
    .end local v3    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "$i$f$udOrNull\\1\\571":I
    if-eqz v6, :cond_3b

    .line 1017
    .local v6, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v3, 0x0

    .line 571
    .local v3, "$i$a$-let-InstanceApi$instList$1\\2\\571\\0":I
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .end local v3    # "$i$a$-let-InstanceApi$instList$1\\2\\571\\0":I
    .end local v6    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_3b
    if-eq v1, v2, :cond_40

    add-int/lit8 v1, v1, 0x1

    goto :goto_17

    .line 572
    .end local v1    # "k":I
    :cond_40
    move-object v1, v0

    check-cast v1, Ljava/util/List;

    return-object v1
.end method

.method private final isEditCamera(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 5
    .param p1, "cam"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 643
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getEditModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getWorkspace()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    .line 644
    .local v0, "ws":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-ne v1, v0, :cond_24

    const-string v1, "CurrentCamera"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    if-eq v2, p1, :cond_22

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_24

    :cond_22
    const/4 v1, 0x1

    goto :goto_25

    :cond_24
    const/4 v1, 0x0

    :goto_25
    return v1
.end method

.method private final isPart(Lcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 3
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 174
    const-string v0, "BasePart"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method static final lambda$5$lambda$2(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "$s"    # Lcom/exampletest/mobilestudiotest/lua/SignalRef;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 144
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/SignalRef;->getOwner()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/SignalRef;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x2

    invoke-virtual {p2, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->checkfunction()Lorg/luaj/vm2/LuaFunction;

    move-result-object v3

    const-string v4, "checkfunction(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->connect(Ljava/lang/Object;Ljava/lang/String;Lorg/luaj/vm2/LuaValue;Z)Lcom/exampletest/mobilestudiotest/lua/Connection;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->connectionValue(Lcom/exampletest/mobilestudiotest/lua/Connection;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$5$lambda$3(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "$s"    # Lcom/exampletest/mobilestudiotest/lua/SignalRef;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 145
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/SignalRef;->getOwner()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/SignalRef;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x2

    invoke-virtual {p2, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->checkfunction()Lorg/luaj/vm2/LuaFunction;

    move-result-object v3

    const-string v4, "checkfunction(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->connect(Ljava/lang/Object;Ljava/lang/String;Lorg/luaj/vm2/LuaValue;Z)Lcom/exampletest/mobilestudiotest/lua/Connection;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->connectionValue(Lcom/exampletest/mobilestudiotest/lua/Connection;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$5$lambda$4(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 5
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "$s"    # Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    const-string v0, "<unused var>"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/SignalRef;->getOwner()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/SignalRef;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->waitSignal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/Varargs;

    move-result-object p2

    return-object p2
.end method

.method static final lambda$8$lambda$7(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/Connection;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 4
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;
    .param p1, "$c"    # Lcom/exampletest/mobilestudiotest/lua/Connection;

    const-string v0, "<unused var>"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 156
    iget-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {p2, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->disconnect(Lcom/exampletest/mobilestudiotest/lua/Connection;)V

    sget-object p2, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v0, "NONE"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Lorg/luaj/vm2/Varargs;

    return-object p2
.end method

.method private final listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;
    .registers 7
    .param p1, "l"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;)",
            "Lorg/luaj/vm2/LuaTable;"
        }
    .end annotation

    .line 563
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .line 564
    .local v0, "t":Lorg/luaj/vm2/LuaTable;
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_20

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v2, "x":Lcom/exampletest/mobilestudiotest/model/Instance;
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v3, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v0, v4, v3}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .end local v2    # "x":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_9

    .line 565
    :cond_20
    return-object v0
.end method

.method private final methodAllowed(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Z
    .registers 8
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;

    .line 167
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->commonMethods:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_a

    return v1

    .line 168
    :cond_a
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->classMethods:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_14
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_39

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .local v3, "cls":Ljava/lang/String;
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Set;

    .local v2, "set":Ljava/util/Set;
    invoke-interface {v2, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_14

    invoke-virtual {p1, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_14

    return v1

    .line 169
    .end local v2    # "set":Ljava/util/Set;
    .end local v3    # "cls":Ljava/lang/String;
    :cond_39
    const/4 v0, 0x0

    return v0
.end method

.method private final priorityItem(I)Lcom/exampletest/mobilestudiotest/lua/EnumItemV;
    .registers 9
    .param p1, "v"    # I

    .line 649
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->PRIORITIES:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1040
    .local v1, "$i$f$firstOrNull\\1\\649":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_29

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lkotlin/Pair;

    .local v4, "it\\2":Lkotlin/Pair;
    const/4 v5, 0x0

    .line 649
    .local v5, "$i$a$-firstOrNull-InstanceApi$priorityItem$1\\2\\1040\\0":I
    invoke-virtual {v4}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    if-ne v6, p1, :cond_25

    const/4 v6, 0x1

    goto :goto_26

    :cond_25
    const/4 v6, 0x0

    .line 1040
    .end local v4    # "it\\2":Lkotlin/Pair;
    .end local v5    # "$i$a$-firstOrNull-InstanceApi$priorityItem$1\\2\\1040\\0":I
    :goto_26
    if-eqz v6, :cond_9

    goto :goto_2a

    .line 1041
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_29
    const/4 v3, 0x0

    .line 649
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\649":I
    :goto_2a
    check-cast v3, Lkotlin/Pair;

    if-eqz v3, :cond_37

    invoke-virtual {v3}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_37

    goto :goto_39

    :cond_37
    const-string v0, "Core"

    :goto_39
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    const-string v2, "AnimationPriority"

    invoke-direct {v1, v2, v0, p1}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    return-object v1
.end method

.method private final raycastResult(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;
    .registers 12
    .param p1, "o"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p2, "d"    # Lcom/exampletest/mobilestudiotest/model/Vector3;
    .param p3, "filter"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lcom/exampletest/mobilestudiotest/model/Vector3;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Lorg/luaj/vm2/LuaValue;"
        }
    .end annotation

    .line 592
    invoke-virtual {p2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v4

    .line 593
    .local v4, "len":F
    const v0, 0x358637bd    # 1.0E-6f

    cmpg-float v0, v4, v0

    const-string v6, "NIL"

    if-gez v0, :cond_13

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    .line 594
    :cond_13
    sget-object v0, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-direct {p0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v1

    invoke-virtual {p2, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    move-object v2, p1

    move-object v5, p3

    .end local p1    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local p3    # "filter":Lkotlin/jvm/functions/Function1;
    .local v2, "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v5, "filter":Lkotlin/jvm/functions/Function1;
    invoke-virtual/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->raycast(Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FLkotlin/jvm/functions/Function1;)Lcom/exampletest/mobilestudiotest/engine/RayHit;

    move-result-object p1

    if-nez p1, :cond_2b

    sget-object p1, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1

    .line 595
    .local p1, "hit":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    :cond_2b
    new-instance p3, Lorg/luaj/vm2/LuaTable;

    invoke-direct {p3}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .line 596
    .local p3, "t":Lorg/luaj/vm2/LuaTable;
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "Instance"

    invoke-virtual {p3, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 597
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "Position"

    invoke-virtual {p3, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 598
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getNormal()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "Normal"

    invoke-virtual {p3, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 599
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getT()F

    move-result v0

    float-to-double v0, v0

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "Distance"

    invoke-virtual {p3, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 600
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/PartData;->material(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v0

    .line 601
    .local v0, "mat":I
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    sget-object v6, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    const-string v7, "Material"

    invoke-virtual {v6, v7, v0}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_87

    const-string v6, "Plastic"

    :cond_87
    invoke-direct {v3, v7, v6, v0}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-virtual {p3, v7, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 602
    move-object v1, p3

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    return-object v1
.end method

.method private final self(Lorg/luaj/vm2/Varargs;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;
    .registers 8
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;
    .param p2, "name"    # Ljava/lang/String;

    .line 715
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v0, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v1, 0x0

    .line 1042
    .local v1, "$i$f$udOrNull\\1\\715":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v2

    goto :goto_18

    :cond_17
    move-object v2, v3

    :goto_18
    instance-of v4, v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v4, :cond_1d

    move-object v3, v2

    :cond_1d
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 715
    .end local v0    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "$i$f$udOrNull\\1\\715":I
    if-eqz v3, :cond_22

    return-object v3

    :cond_22
    new-instance v0, Lorg/luaj/vm2/LuaError;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Expected \':\' not \'.\' calling member function "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private final setTags(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;)V
    .registers 15
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "t"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 558
    new-instance v2, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    move-object v3, p2

    check-cast v3, Ljava/lang/Iterable;

    const-string v0, "\u0000"

    move-object v4, v0

    check-cast v4, Ljava/lang/CharSequence;

    const/16 v10, 0x3e

    const/4 v11, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v3 .. v11}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v1, "getBytes(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/model/BinaryString;-><init>([B)V

    const/4 v4, 0x4

    const-string v1, "Tags"

    const/4 v3, 0x0

    move-object v0, p1

    .end local p1    # "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v0, "i":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 559
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object p1

    check-cast p1, Ljava/util/Map;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "Tags"

    invoke-interface {p1, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 560
    return-void
.end method

.method private final tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;
    .registers 15
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 549
    const-string v0, "Tags"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    .line 550
    .local v0, "t":Ljava/lang/Object;
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    if-eqz v1, :cond_19

    new-instance v1, Ljava/lang/String;

    move-object v2, v0

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/BinaryString;->getBytes()[B

    move-result-object v2

    sget-object v3, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v1, v2, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    goto :goto_23

    .line 551
    :cond_19
    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_21

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    goto :goto_23

    .line 552
    :cond_21
    const-string v1, ""

    .line 549
    .end local v0    # "t":Ljava/lang/Object;
    :goto_23
    nop

    .line 554
    .local v1, "raw":Ljava/lang/String;
    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    const/4 v0, 0x1

    new-array v3, v0, [C

    const/4 v8, 0x0

    aput-char v8, v3, v8

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1035
    .local v3, "$i$f$filter\\1\\554":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1036
    .local v6, "$i$f$filterTo\\2\\1035":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_45
    :goto_45
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_65

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\2":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Ljava/lang/String;

    .local v10, "it\\3":Ljava/lang/String;
    const/4 v11, 0x0

    .line 554
    .local v11, "$i$a$-filter-InstanceApi$tags$1\\3\\1036\\0":I
    move-object v12, v10

    check-cast v12, Ljava/lang/CharSequence;

    invoke-interface {v12}, Ljava/lang/CharSequence;->length()I

    move-result v12

    if-lez v12, :cond_5e

    move v12, v0

    goto :goto_5f

    :cond_5e
    move v12, v8

    .line 1036
    .end local v10    # "it\\3":Ljava/lang/String;
    .end local v11    # "$i$a$-filter-InstanceApi$tags$1\\3\\1036\\0":I
    :goto_5f
    if-eqz v12, :cond_45

    invoke-interface {v4, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_45

    .line 1037
    .end local v9    # "element\\2":Ljava/lang/Object;
    :cond_65
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo\\2\\1035":I
    move-object v0, v4

    check-cast v0, Ljava/util/List;

    .line 1035
    nop

    .end local v2    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filter\\1\\554":I
    check-cast v0, Ljava/util/Collection;

    .line 554
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toMutableList(Ljava/util/Collection;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method private final typeHint(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Integer;
    .registers 20
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;

    .line 402
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, 0x2

    .line 405
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    .line 402
    const/4 v4, 0x1

    .line 403
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    .line 402
    const/16 v5, 0x13

    .line 404
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    .line 402
    sparse-switch v2, :sswitch_data_4d4

    goto :goto_3f

    :sswitch_1c
    const-string v2, "Archivable"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2d

    goto :goto_3f

    :sswitch_25
    const-string v2, "Enabled"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3f

    .line 405
    :cond_2d
    return-object v3

    .line 402
    :sswitch_2e
    const-string v2, "Name"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3f

    .line 403
    return-object v4

    .line 402
    :sswitch_37
    const-string v2, "Parent"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_40

    :cond_3f
    :goto_3f
    goto :goto_41

    .line 404
    :cond_40
    return-object v5

    .line 407
    :goto_41
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isPart(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v2

    const/16 v6, 0xc

    const-string v7, "Position"

    const-string v8, "Color"

    const-string v9, "Rotation"

    const/16 v10, 0x10

    const-string v11, "Size"

    if-eqz v2, :cond_cb

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v2

    sparse-switch v2, :sswitch_data_4e6

    goto/16 :goto_cb

    :sswitch_5c
    const-string v2, "CFrame"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 411
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 407
    :sswitch_69
    const-string v2, "RotVelocity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_72
    const-string v2, "AssemblyLinearVelocity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_7b
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_82
    const-string v2, "Orientation"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_8b
    const-string v2, "AssemblyAngularVelocity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_94
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 409
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 407
    :sswitch_9f
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_a6
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c4

    goto :goto_cb

    :sswitch_ad
    const-string v2, "BrickColor"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 410
    const/16 v2, 0xb

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 407
    :sswitch_bc
    const-string v2, "Velocity"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_cb

    .line 408
    :cond_c4
    const/16 v2, 0xe

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 413
    :cond_cb
    :goto_cb
    const-string v2, "WorldPivot"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d8

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 414
    :cond_d8
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    const-string v10, "Humanoid"

    invoke-static {v2, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v10, 0x4

    if-eqz v2, :cond_f2

    const-string v2, "Health"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_f2

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    return-object v2

    .line 415
    :cond_f2
    sget-object v2, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v2, v0, v1}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 416
    .local v2, "key":Ljava/lang/String;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v12

    invoke-virtual {v12, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    if-eqz v12, :cond_110

    check-cast v12, Ljava/lang/Number;

    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    move-result v3

    .line 1017
    .local v3, "it\\1":I
    const/4 v4, 0x0

    .line 416
    .local v4, "$i$a$-let-InstanceApi$typeHint$1\\1\\416\\0":I
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    return-object v5

    .line 418
    .end local v3    # "it\\1":I
    .end local v4    # "$i$a$-let-InstanceApi$typeHint$1\\1\\416\\0":I
    :cond_110
    move-object/from16 v12, p0

    iget-object v13, v12, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->sequenceClasses:Ljava/util/Set;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v14

    invoke-interface {v13, v14}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v13

    const/16 v14, 0xd

    const-string v15, "Transparency"

    if-eqz v13, :cond_16d

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v13

    sparse-switch v13, :sswitch_data_514

    goto :goto_16d

    :sswitch_12a
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_16d

    .line 420
    const/16 v3, 0x16

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    return-object v3

    .line 418
    :sswitch_137
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_14d

    goto :goto_16d

    :sswitch_13e
    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_14d

    goto :goto_16d

    :sswitch_145
    const-string v8, "Squash"

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_16d

    .line 419
    :cond_14d
    const/16 v3, 0x15

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    return-object v3

    .line 418
    :sswitch_154
    const-string v8, "Offset"

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_16d

    .line 421
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v8

    const-string v13, "UIGradient"

    invoke-static {v8, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_16d

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    return-object v3

    .line 423
    :cond_16d
    :goto_16d
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v8

    const-string v13, "Value"

    const/16 v16, 0x0

    sparse-switch v8, :sswitch_data_52a

    goto/16 :goto_4ca

    :sswitch_17a
    const-string v4, "Visible"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_184
    const-string v3, "FogEnd"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_18e
    const-string v3, "FillDirection"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_198
    const-string v3, "SortOrder"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_1a2
    const-string v4, "Active"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_1ac
    const-string v3, "CameraSubject"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_1b6
    const-string v3, "FieldOfView"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_1c0
    const-string v4, "AutoButtonColor"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_1ca
    const-string v3, "BorderSizePixel"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_475

    goto/16 :goto_4ca

    :sswitch_1d4
    const-string v3, "DisplayOrder"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_475

    goto/16 :goto_4ca

    :sswitch_1de
    const-string v4, "CanCollide"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_1e8
    const-string v4, "Playing"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_1f2
    const-string v3, "MaxHealth"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_1fc
    const-string v3, "BorderColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_206
    const-string v3, "JumpHeight"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_210
    const-string v3, "ClockTime"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_21a
    const-string v3, "Thickness"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_224
    const-string v3, "TextureID"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_22e
    const-string v4, "IgnoreGuiInset"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_238
    const-string v3, "TextStrokeColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_242
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_36b

    goto/16 :goto_4ca

    :sswitch_24a
    const-string v3, "PrimaryPart"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_254
    const-string v3, "Ambient"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_25e
    const-string v3, "PlaceholderText"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_268
    const-string v3, "TextXAlignment"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_272
    const-string v3, "Adornee"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_27c
    const-string v3, "BackgroundColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_286
    const-string v3, "TextYAlignment"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_290
    const-string v3, "Material"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_29a
    const-string v4, "Massless"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_2a4
    const-string v4, "Disabled"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_2ae
    const-string v3, "Texture"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_2b8
    const-string v3, "FogStart"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_2c2
    const-string v3, "FogColor"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_2cc
    const-string v3, "ScaleType"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_2d6
    const-string v3, "AnchorPoint"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 434
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_4d2

    .line 423
    :sswitch_2e4
    invoke-virtual {v1, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_2ec
    const-string v3, "Title"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_2f6
    const-string v3, "Shape"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_300
    const-string v3, "Range"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_30a
    const-string v3, "Part1"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_31c

    goto/16 :goto_4ca

    :sswitch_314
    const-string v3, "Part0"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 435
    :cond_31c
    invoke-static {v1, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_332

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "ObjectValue"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_332

    move-object/from16 v3, v16

    goto/16 :goto_4d2

    :cond_332
    move-object v3, v5

    goto/16 :goto_4d2

    .line 423
    :sswitch_335
    const-string v3, "Image"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_33f
    const-string v3, "Angle"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_349
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_351
    const-string v3, "OutdoorAmbient"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_35b
    const-string v3, "Text"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_365
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 433
    :cond_36b
    const-string v3, "GuiObject"

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_37a

    const/4 v3, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_4d2

    :cond_37a
    move-object/from16 v3, v16

    goto/16 :goto_4d2

    .line 423
    :sswitch_37e
    const-string v3, "Font"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_388
    const-string v3, "TextTransparency"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_392
    const-string v3, "CameraType"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_45c

    goto/16 :goto_4ca

    :sswitch_39c
    const-string v4, "CanTouch"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_3a6
    const-string v4, "CanQuery"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_3b0
    const-string v3, "PlaybackSpeed"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_3ba
    const-string v3, "HipHeight"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_3c4
    const-string v3, "SoundId"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_3ce
    const-string v4, "TextScaled"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_3d8
    const-string v3, "LayoutOrder"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_475

    goto/16 :goto_4ca

    :sswitch_3e2
    const-string v3, "WalkSpeed"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_3ec
    const-string v4, "Anchored"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_3f6
    const-string v3, "TextColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_408

    goto/16 :goto_4ca

    :sswitch_400
    const-string v3, "ImageColor3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 432
    :cond_408
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_4d2

    .line 423
    :sswitch_40e
    const-string v3, "TextSize"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_418
    const-string v4, "ClipsDescendants"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_422
    const-string v3, "BackgroundTransparency"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_42c
    const-string v3, "TextStrokeTransparency"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_436
    const-string v3, "AnimationId"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4ae

    goto/16 :goto_4ca

    :sswitch_440
    const-string v4, "RichText"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto/16 :goto_4ca

    :sswitch_44a
    const-string v3, "ImageTransparency"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto/16 :goto_4ca

    :sswitch_454
    const-string v3, "AutomaticSize"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 431
    :cond_45c
    const/16 v3, 0x12

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_4d2

    .line 423
    :sswitch_464
    const-string v3, "JumpPower"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto :goto_4ca

    :sswitch_46d
    const-string v3, "ZIndex"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 429
    :cond_475
    const/4 v3, 0x3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_4d2

    .line 423
    :sswitch_47b
    const-string v3, "Brightness"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto :goto_4ca

    :sswitch_484
    const-string v3, "Volume"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto :goto_4ca

    :sswitch_48d
    const-string v4, "ResetOnSpawn"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto :goto_4ca

    :sswitch_496
    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    goto :goto_4ca

    :sswitch_49d
    const-string v4, "TextWrapped"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto :goto_4ca

    :sswitch_4a6
    const-string v3, "MeshId"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4ca

    .line 430
    :cond_4ae
    move-object v3, v4

    goto :goto_4d2

    .line 423
    :sswitch_4b0
    const-string v4, "Looped"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4c1

    goto :goto_4ca

    :sswitch_4b9
    const-string v4, "Locked"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4ca

    .line 425
    :cond_4c1
    goto :goto_4d2

    .line 423
    :sswitch_4c2
    const-string v3, "Reflectance"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4cb

    :cond_4ca
    :goto_4ca
    goto :goto_4d0

    .line 428
    :cond_4cb
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_4d2

    .line 436
    :goto_4d0
    move-object/from16 v3, v16

    .line 423
    :goto_4d2
    return-object v3

    nop

    :sswitch_data_4d4
    .sparse-switch
        -0x71f00b36 -> :sswitch_37
        0x24eeab -> :sswitch_2e
        0x3482321 -> :sswitch_25
        0x7094d7fd -> :sswitch_1c
    .end sparse-switch

    :sswitch_data_4e6
    .sparse-switch
        -0x7cef5f03 -> :sswitch_bc
        -0x33b84c3e -> :sswitch_ad
        0x275421 -> :sswitch_a6
        0x173739e -> :sswitch_9f
        0x3e43f43 -> :sswitch_94
        0x9fe75f9 -> :sswitch_8b
        0xd9c9db0 -> :sswitch_82
        0x306cfd49 -> :sswitch_7b
        0x3f7ca6c8 -> :sswitch_72
        0x4f2c3bb4 -> :sswitch_69
        0x76646aea -> :sswitch_5c
    .end sparse-switch

    :sswitch_data_514
    .sparse-switch
        -0x7363af4d -> :sswitch_154
        -0x6beebaa1 -> :sswitch_145
        -0x6bc56088 -> :sswitch_13e
        0x275421 -> :sswitch_137
        0x3e43f43 -> :sswitch_12a
    .end sparse-switch

    :sswitch_data_52a
    .sparse-switch
        -0x792c6694 -> :sswitch_4c2
        -0x7804e0d6 -> :sswitch_4b9
        -0x77ff599d -> :sswitch_4b0
        -0x76d5bbf8 -> :sswitch_4a6
        -0x6f8d3d88 -> :sswitch_49d
        -0x6bc56088 -> :sswitch_496
        -0x69512f53 -> :sswitch_48d
        -0x66f02cc6 -> :sswitch_484
        -0x628bf78f -> :sswitch_47b
        -0x62339f68 -> :sswitch_46d
        -0x608ccea9 -> :sswitch_464
        -0x5a825754 -> :sswitch_454
        -0x5a28a7cd -> :sswitch_44a
        -0x58a047b7 -> :sswitch_440
        -0x58440461 -> :sswitch_436
        -0x57b8e223 -> :sswitch_42c
        -0x5330b43a -> :sswitch_422
        -0x47658bed -> :sswitch_418
        -0x37f86112 -> :sswitch_40e
        -0x3683b5b5 -> :sswitch_400
        -0x36638b23 -> :sswitch_3f6
        -0x3608a5cc -> :sswitch_3ec
        -0x33eeac22 -> :sswitch_3e2
        -0x259251dc -> :sswitch_3d8
        -0x1bc427f9 -> :sswitch_3ce
        -0x154c9d96 -> :sswitch_3c4
        -0xc0df68a -> :sswitch_3ba
        -0x7d3fd34 -> :sswitch_3b0
        -0x4739108 -> :sswitch_3a6
        -0x44bca91 -> :sswitch_39c
        -0x11c77e1 -> :sswitch_392
        -0x10232bb -> :sswitch_388
        0x21806f -> :sswitch_37e
        0x275421 -> :sswitch_365
        0x27b94d -> :sswitch_35b
        0xfda71c -> :sswitch_351
        0x173739e -> :sswitch_349
        0x3c788b3 -> :sswitch_33f
        0x437b93b -> :sswitch_335
        0x4952a7d -> :sswitch_314
        0x4952a7e -> :sswitch_30a
        0x4b1491d -> :sswitch_300
        0x4c25f81 -> :sswitch_2f6
        0x4d13238 -> :sswitch_2ec
        0x4e9a151 -> :sswitch_2e4
        0x688b3bb -> :sswitch_2d6
        0x7837784 -> :sswitch_2cc
        0xb0d5d65 -> :sswitch_2c2
        0xbf0f264 -> :sswitch_2b8
        0xeb66cfb -> :sswitch_2ae
        0x14009e9c -> :sswitch_2a4
        0x14bb72ad -> :sswitch_29a
        0x15adc947 -> :sswitch_290
        0x17b85297 -> :sswitch_286
        0x180b281e -> :sswitch_27c
        0x1f6b5668 -> :sswitch_272
        0x236ee178 -> :sswitch_268
        0x2ced0520 -> :sswitch_25e
        0x2e0b8a78 -> :sswitch_254
        0x2fb1bcf5 -> :sswitch_24a
        0x306cfd49 -> :sswitch_242
        0x35f41775 -> :sswitch_238
        0x383aa8b4 -> :sswitch_22e
        0x3acf2356 -> :sswitch_224
        0x3b641754 -> :sswitch_21a
        0x3fb70bdb -> :sswitch_210
        0x40b8f315 -> :sswitch_206
        0x4166a09c -> :sswitch_1fc
        0x416d18c0 -> :sswitch_1f2
        0x45cd680e -> :sswitch_1e8
        0x5bb7fa6e -> :sswitch_1de
        0x692ffbcc -> :sswitch_1d4
        0x6c9e3019 -> :sswitch_1ca
        0x6d773602 -> :sswitch_1c0
        0x712b0a96 -> :sswitch_1b6
        0x73a27627 -> :sswitch_1ac
        0x74946b26 -> :sswitch_1a2
        0x75d99430 -> :sswitch_198
        0x7d39e51c -> :sswitch_18e
        0x7dbf4f5d -> :sswitch_184
        0x7f0a8852 -> :sswitch_17a
    .end sparse-switch
.end method

.method static final workspaceCall$lambda$52(Ljava/util/List;ZLcom/exampletest/mobilestudiotest/model/Instance;)Z
    .registers 12
    .param p0, "$list"    # Ljava/util/List;
    .param p1, "$white"    # Z
    .param p2, "p"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "p"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 810
    move-object v0, p0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1105
    .local v1, "$i$f$any\\1\\810":I
    instance-of v2, v0, Ljava/util/Collection;

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1a

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1a

    move v0, v4

    goto :goto_3c

    .line 1106
    :cond_1a
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\1":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v6, "f\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v7, 0x0

    .line 810
    .local v7, "$i$a$-any-InstanceApi$workspaceCall$hit$1$inList$1\\2\\1106\\0":I
    if-eq p2, v6, :cond_36

    invoke-virtual {p2, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v8

    if-nez v8, :cond_36

    move v6, v4

    goto :goto_37

    :cond_36
    move v6, v3

    .line 1106
    .end local v6    # "f\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "$i$a$-any-InstanceApi$workspaceCall$hit$1$inList$1\\2\\1106\\0":I
    :goto_37
    if-eqz v6, :cond_1e

    move v0, v3

    goto :goto_3c

    .line 1107
    .end local v5    # "element\\1":Ljava/lang/Object;
    :cond_3b
    move v0, v4

    .line 810
    .end local v0    # "$this$any\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$any\\1\\810":I
    :goto_3c
    nop

    .line 811
    .local v0, "inList":Z
    if-eqz p1, :cond_41

    move v3, v0

    goto :goto_44

    :cond_41
    if-eqz v0, :cond_44

    move v3, v4

    :cond_44
    :goto_44
    return v3
.end method

.method private final workspaceParts()Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    .line 576
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    const-string v1, "Workspace"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    if-nez v0, :cond_13

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 577
    .local v0, "ws":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_13
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v1

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/core/Studio;->getModel()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v2

    if-ne v1, v2, :cond_30

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/core/Studio;->renderParts()Ljava/util/List;

    move-result-object v1

    goto :goto_34

    :cond_30
    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v1

    :goto_34
    return-object v1
.end method


# virtual methods
.method public final callMethod(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 22
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v1, p0

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    const-string v0, "name"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "a"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 718
    invoke-direct {v1, v5, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->self(Lorg/luaj/vm2/Varargs;Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    .line 719
    .local v3, "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v0, 0x2

    invoke-virtual {v5, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    .line 720
    .local v6, "a2":Lorg/luaj/vm2/LuaValue;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    const-string v7, "CollectionService"

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const-string v8, "GetTags"

    const-string v9, "HasTag"

    const-string v10, "RemoveTag"

    const-string v11, "AddTag"

    const/4 v12, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x0

    if-eqz v2, :cond_4a

    const/4 v2, 0x4

    new-array v2, v2, [Ljava/lang/String;

    aput-object v11, v2, v14

    aput-object v10, v2, v13

    aput-object v9, v2, v0

    aput-object v8, v2, v12

    invoke-static {v2}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4a

    invoke-virtual/range {p0 .. p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->collectionCall(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    return-object v0

    .line 721
    :cond_4a
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    move-result v2

    const-string v15, "NIL"

    const-string v0, "Attr:"

    move/from16 v16, v14

    const-string v14, "FindService"

    const-string v13, "Destroy"

    const-string v12, "checkjstring(...)"

    move/from16 v17, v2

    const-string v2, "valueOf(...)"

    move-object/from16 v18, v6

    .end local v6    # "a2":Lorg/luaj/vm2/LuaValue;
    .local v18, "a2":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    sparse-switch v17, :sswitch_data_656

    goto/16 :goto_636

    :sswitch_66
    const-string v0, "FindFirstChild"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 722
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    invoke-virtual {v5, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v6

    invoke-virtual {v3, v2, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_8c
    const-string v0, "GetActor"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 744
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_9d
    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 772
    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0

    .local v0, "t":Ljava/util/List;
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    .local v2, "tg":Ljava/lang/String;
    invoke-interface {v0, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_e7

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-direct {v1, v3, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setTags(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;)V

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v8

    invoke-virtual {v8, v7}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "TagAdded:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x1

    new-array v9, v9, [Lorg/luaj/vm2/LuaValue;

    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v10, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v10

    aput-object v10, v9, v16

    invoke-virtual {v6, v7, v8, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    :cond_e7
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .end local v0    # "t":Ljava/util/List;
    .end local v2    # "tg":Ljava/lang/String;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_f0
    const-string v6, "SetAttribute"

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_636

    .line 753
    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/Attributes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 754
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v6

    .line 755
    .local v6, "k":Ljava/lang/String;
    const/4 v7, 0x3

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    .line 756
    .local v9, "v":Lorg/luaj/vm2/LuaValue;
    invoke-virtual {v9}, Lorg/luaj/vm2/LuaValue;->isnil()Z

    move-result v7

    if-eqz v7, :cond_114

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_12c

    :cond_114
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v7

    check-cast v7, Ljava/util/Map;

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v13, 0xc

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fromLua$default(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lorg/luaj/vm2/LuaValue;Ljava/lang/Integer;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v7, v6, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 757
    :goto_12c
    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    const/4 v8, 0x1

    new-array v8, v8, [Lorg/luaj/vm2/LuaValue;

    invoke-static {v6}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v10

    invoke-static {v10, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    aput-object v10, v8, v16

    const-string v2, "AttributeChanged"

    invoke-virtual {v7, v3, v2, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .line 758
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move/from16 v7, v16

    new-array v7, v7, [Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v2, v3, v0, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    .line 759
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 752
    .end local v6    # "k":Ljava/lang/String;
    .end local v9    # "v":Lorg/luaj/vm2/LuaValue;
    nop

    .line 757
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_163
    const-string v0, "children"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1d0

    goto/16 :goto_636

    :sswitch_16d
    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 770
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .local v0, "t":Lorg/luaj/vm2/LuaTable;
    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$forEach\\10":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1049
    .local v6, "$i$f$forEach\\10\\770":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_183
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_19d

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\10":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Ljava/lang/String;

    .local v9, "it\\11":Ljava/lang/String;
    const/4 v10, 0x0

    .line 770
    .local v10, "$i$a$-forEach-InstanceApi$callMethod$6\\11\\1049\\0":I
    invoke-static {v9}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v11

    check-cast v11, Lorg/luaj/vm2/LuaValue;

    const/4 v12, 0x0

    invoke-virtual {v0, v12, v11}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 1049
    .end local v9    # "it\\11":Ljava/lang/String;
    .end local v10    # "$i$a$-forEach-InstanceApi$callMethod$6\\11\\1049\\0":I
    nop

    .end local v8    # "element\\10":Ljava/lang/Object;
    goto :goto_183

    .line 1050
    :cond_19d
    nop

    .line 770
    .end local v2    # "$this$forEach\\10":Ljava/lang/Iterable;
    .end local v6    # "$i$f$forEach\\10\\770":I
    nop

    .end local v0    # "t":Lorg/luaj/vm2/LuaTable;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_1a3
    const-string v2, "GetAttributeChangedSignal"

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_636

    .line 761
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v3, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_1c8
    const-string v0, "GetChildren"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 730
    :cond_1d0
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_1e2
    const-string v0, "GetAttributes"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 749
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/Attributes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 750
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .restart local v0    # "t":Lorg/luaj/vm2/LuaTable;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_202
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_226

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map$Entry;

    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .local v7, "k":Ljava/lang/String;
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "v":Ljava/lang/Object;
    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    const/4 v12, 0x6

    const/4 v13, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v8 .. v13}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->toLua$default(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Ljava/lang/Object;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ILjava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v0, v7, v6}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .end local v7    # "k":Ljava/lang/String;
    .end local v9    # "v":Ljava/lang/Object;
    goto :goto_202

    .end local v0    # "t":Lorg/luaj/vm2/LuaTable;
    :cond_226
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_22a
    const-string v0, "FindFirstDescendant"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 725
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v8, 0x1

    invoke-virtual {v3, v2, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_248
    const-string v0, "GetFullName"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 742
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->fullName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_25f
    const-string v0, "GetService"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_29d

    goto/16 :goto_636

    :sswitch_269
    const-string v0, "GetDebugId"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 743
    invoke-static {v3}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_284
    const-string v0, "IsPropertyModified"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 745
    sget-object v0, Lorg/luaj/vm2/LuaValue;->FALSE:Lorg/luaj/vm2/LuaBoolean;

    const-string v2, "FALSE"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_297
    invoke-virtual {v4, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 764
    :cond_29d
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v0

    .line 765
    .local v0, "n":Ljava/lang/String;
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    const-string v7, "UserSettings"

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2f8

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$firstOrNull\\6":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1047
    .local v7, "$i$f$firstOrNull\\6\\765":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_2b8
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_2e1

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\6":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v10, "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v11, 0x0

    .line 765
    .local v11, "$i$a$-firstOrNull-InstanceApi$callMethod$3\\7\\1047\\0":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_2dc

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_2dc

    const/4 v10, 0x0

    goto :goto_2dd

    :cond_2dc
    const/4 v10, 0x1

    .line 1047
    .end local v10    # "it\\7":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v11    # "$i$a$-firstOrNull-InstanceApi$callMethod$3\\7\\1047\\0":I
    :goto_2dd
    if-eqz v10, :cond_2b8

    move-object v6, v9

    goto :goto_2e2

    .line 1048
    .end local v9    # "element\\6":Ljava/lang/Object;
    :cond_2e1
    nop

    .line 765
    .end local v2    # "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .end local v7    # "$i$f$firstOrNull\\6\\765":I
    :goto_2e2
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v6, :cond_2f0

    .line 1017
    .local v6, "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x0

    .line 765
    .local v2, "$i$a$-let-InstanceApi$callMethod$4\\8\\765\\0":I
    iget-object v7, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v7, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    .end local v2    # "$i$a$-let-InstanceApi$callMethod$4\\8\\765\\0":I
    .end local v6    # "it\\8":Lcom/exampletest/mobilestudiotest/model/Instance;
    if-eqz v2, :cond_2f0

    goto :goto_2f5

    :cond_2f0
    sget-object v2, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    invoke-static {v2, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_2f5
    check-cast v2, Lorg/luaj/vm2/Varargs;

    return-object v2

    .line 766
    :cond_2f8
    instance-of v2, v3, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-eqz v2, :cond_2ff

    move-object v6, v3

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/DataModel;

    :cond_2ff
    if-nez v6, :cond_307

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v6

    .line 767
    .local v6, "dm":Lcom/exampletest/mobilestudiotest/model/DataModel;
    :cond_307
    invoke-static {v4, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_31b

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v6, v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    invoke-virtual {v2, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    goto :goto_340

    .line 768
    :cond_31b
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v6, v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->findService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    if-nez v7, :cond_33c

    invoke-virtual {v6, v0}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    .line 1017
    move-object v8, v7

    .local v8, "it\\9":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 768
    .local v9, "$i$a$-also-InstanceApi$callMethod$5\\9\\768\\0":I
    sget-object v10, Lcom/exampletest/mobilestudiotest/model/ClassDb;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/ClassDb;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/ClassDb;->getServiceNames()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_33c

    const/4 v12, 0x0

    invoke-virtual {v8, v12}, Lcom/exampletest/mobilestudiotest/model/Instance;->setArchivable(Z)V

    .end local v8    # "it\\9":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-also-InstanceApi$callMethod$5\\9\\768\\0":I
    :cond_33c
    invoke-virtual {v2, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    .end local v0    # "n":Ljava/lang/String;
    .end local v6    # "dm":Lcom/exampletest/mobilestudiotest/model/DataModel;
    :goto_340
    move-object v0, v2

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_345
    const-string v0, "GetAttribute"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 747
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/Attributes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v6 .. v11}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->toLua$default(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Ljava/lang/Object;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ILjava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_36c
    const-string v0, "FindFirstAncestorOfClass"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 727
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_378
    if-eqz v0, :cond_38d

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_38d

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    goto :goto_378

    :cond_38d
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_397
    const-string v0, "Clone"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 740
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getArchivable()Z

    move-result v0

    if-nez v0, :cond_3a8

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    goto :goto_3b2

    :cond_3a8
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->cloneTree()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    :goto_3b2
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_3b9
    const-string v0, "IsA"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 732
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_3d7
    const-string v0, "GetPropertyChangedSignal"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 762
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Changed:"

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v3, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_3fe
    const-string v0, "FindFirstChildWhichIsA"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 724
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x3

    invoke-virtual {v5, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v6

    invoke-virtual {v3, v2, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildWhichIsA(Ljava/lang/String;Z)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_424
    const-string v0, "IsDescendantOf"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 733
    invoke-static/range {v18 .. v18}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v0, v18

    .local v0, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 1043
    .local v7, "$i$f$udOrNull\\1\\733":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_43d

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_43e

    :cond_43d
    move-object v8, v6

    :goto_43e
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v9, :cond_443

    move-object v6, v8

    :cond_443
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 733
    .end local v0    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\1\\733":I
    if-eqz v6, :cond_44d

    .line 1017
    .local v6, "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v0, 0x0

    .line 733
    .local v0, "$i$a$-let-InstanceApi$callMethod$1\\2\\733\\0":I
    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v14

    .end local v0    # "$i$a$-let-InstanceApi$callMethod$1\\2\\733\\0":I
    .end local v6    # "it\\2":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_44e

    :cond_44d
    const/4 v14, 0x0

    :goto_44e
    invoke-static {v14}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_459
    const-string v0, "FindFirstAncestor"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 726
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_465
    if-eqz v0, :cond_47a

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_47a

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    goto :goto_465

    :cond_47a
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_484
    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 773
    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0

    .local v0, "t":Ljava/util/List;
    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    .local v2, "tg":Ljava/lang/String;
    invoke-interface {v0, v2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4ca

    invoke-direct {v1, v3, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setTags(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;)V

    iget-object v6, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    iget-object v8, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v8

    invoke-virtual {v8, v7}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "TagRemoved:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x1

    new-array v9, v9, [Lorg/luaj/vm2/LuaValue;

    iget-object v10, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v10, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v10

    const/16 v16, 0x0

    aput-object v10, v9, v16

    invoke-virtual {v6, v7, v8, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    :cond_4ca
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .end local v0    # "t":Ljava/util/List;
    .end local v2    # "tg":Ljava/lang/String;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_4d3
    invoke-virtual {v4, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_583

    goto/16 :goto_636

    :sswitch_4db
    const-string v0, "ClearAllChildren"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 741
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEach\\4":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1045
    .local v2, "$i$f$forEach\\4\\741":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_4f4
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_50d

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\4":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 741
    .local v9, "$i$a$-forEach-InstanceApi$callMethod$2\\5\\1045\\0":I
    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v10

    if-nez v10, :cond_50b

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->destroy()V

    .line 1045
    .end local v8    # "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-forEach-InstanceApi$callMethod$2\\5\\1045\\0":I
    :cond_50b
    nop

    .end local v7    # "element\\4":Ljava/lang/Object;
    goto :goto_4f4

    .line 1046
    :cond_50d
    nop

    .line 741
    .end local v0    # "$this$forEach\\4":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\4\\741":I
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_517
    const-string v0, "ResetPropertyToDefault"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 746
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v2, "NONE"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_52a
    const-string v0, "IsAncestorOf"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 734
    invoke-static/range {v18 .. v18}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v0, v18

    .local v0, "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 1044
    .local v7, "$i$f$udOrNull\\3\\734":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_543

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_544

    :cond_543
    move-object v8, v6

    :goto_544
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v9, :cond_549

    move-object v6, v8

    :cond_549
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 734
    .end local v0    # "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\3\\734":I
    if-eqz v6, :cond_552

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v14

    goto :goto_553

    :cond_552
    const/4 v14, 0x0

    :goto_553
    invoke-static {v14}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_55e
    const-string v0, "FindFirstChildOfClass"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 723
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_57b
    const-string v0, "Remove"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 736
    :cond_583
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v0

    if-nez v0, :cond_5a6

    instance-of v0, v3, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-nez v0, :cond_5a6

    .line 737
    invoke-static {v4, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_597

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->destroy()V

    goto :goto_59c

    :cond_597
    const/4 v0, 0x2

    const/4 v12, 0x0

    invoke-static {v3, v6, v12, v0, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->setParent$default(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;IILjava/lang/Object;)V

    .line 738
    :goto_59c
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 735
    nop

    .line 736
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    :cond_5a6
    new-instance v0, Lorg/luaj/vm2/LuaError;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Cannot destroy "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 721
    :sswitch_5c3
    const-string v0, "GetDescendants"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 731
    const/4 v8, 0x1

    invoke-static {v3, v6, v8, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_655

    .line 721
    :sswitch_5d8
    const-string v0, "FindFirstAncestorWhichIsA"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 728
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_5e4
    if-eqz v0, :cond_5fa

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    const-string v6, "tojstring(...)"

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_5fa

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    goto :goto_5e4

    :cond_5fa
    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_655

    .line 721
    :sswitch_603
    const-string v0, "WaitForChild"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_636

    .line 729
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x3

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v8

    invoke-virtual {v8}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v8

    if-eqz v8, :cond_62b

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->todouble()D

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    :cond_62b
    invoke-virtual {v0, v3, v2, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->waitForChild(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Double;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    goto :goto_655

    .line 721
    :sswitch_630
    invoke-virtual {v4, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_637

    :cond_636
    :goto_636
    goto :goto_64d

    .line 771
    :cond_637
    invoke-direct {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0

    invoke-virtual/range {v18 .. v18}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v0, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_655

    .line 774
    :goto_64d
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/RobloxServices;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/RobloxServices;

    iget-object v2, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/lua/RobloxServices;->call(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    .line 721
    :goto_655
    return-object v0

    :sswitch_data_656
    .sparse-switch
        -0x7f969d40 -> :sswitch_630
        -0x7907ed78 -> :sswitch_603
        -0x759fe19c -> :sswitch_5d8
        -0x7087da00 -> :sswitch_5c3
        -0x6e501b5c -> :sswitch_57b
        -0x6b4518e4 -> :sswitch_55e
        -0x59d0440c -> :sswitch_52a
        -0x580d987e -> :sswitch_517
        -0x544fc1ad -> :sswitch_4db
        -0x3ff3c826 -> :sswitch_4d3
        -0x3c1e8faa -> :sswitch_484
        -0x3277a0b6 -> :sswitch_459
        -0x2f12f5e2 -> :sswitch_424
        -0x142c40e1 -> :sswitch_3fe
        -0x1006eeef -> :sswitch_3d7
        0x12037 -> :sswitch_3b9
        0x3e2ed3d -> :sswitch_397
        0x5330b37 -> :sswitch_36c
        0xa007006 -> :sswitch_345
        0xb81de9c -> :sswitch_297
        0xf681928 -> :sswitch_284
        0x10836eb8 -> :sswitch_269
        0x2ae2de9f -> :sswitch_25f
        0x2e971710 -> :sswitch_248
        0x2f6ae0b4 -> :sswitch_22a
        0x360d912d -> :sswitch_1e2
        0x422e4355 -> :sswitch_1c8
        0x58fd6016 -> :sswitch_1a3
        0x5ebe346f -> :sswitch_16d
        0x62ea5dff -> :sswitch_163
        0x6654307a -> :sswitch_f0
        0x749aeb59 -> :sswitch_9d
        0x77fdb45f -> :sswitch_8c
        0x79b9eb05 -> :sswitch_66
    .end sparse-switch
.end method

.method public final collectionCall(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 16
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "a"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 779
    const/4 v0, 0x2

    invoke-virtual {p2, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    .line 780
    .local v1, "a2":Lorg/luaj/vm2/LuaValue;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, 0x0

    const-string v4, "CollectionService"

    const/4 v5, 0x1

    const/4 v6, 0x0

    sparse-switch v2, :sswitch_data_1ac

    goto/16 :goto_15f

    :sswitch_1d
    const-string v0, "GetAllTags"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15f

    .line 788
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .local v0, "s":Ljava/util/LinkedHashSet;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v2, v6, v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$forEach\\5":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1055
    .local v4, "$i$f$forEach\\5\\788":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3d
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_56

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\5":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v7, "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v8, 0x0

    .line 788
    .local v8, "$i$a$-forEach-InstanceApi$collectionCall$2\\6\\1055\\0":I
    invoke-direct {p0, v7}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v9

    check-cast v9, Ljava/util/Collection;

    invoke-virtual {v0, v9}, Ljava/util/LinkedHashSet;->addAll(Ljava/util/Collection;)Z

    .line 1055
    .end local v7    # "it\\6":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v8    # "$i$a$-forEach-InstanceApi$collectionCall$2\\6\\1055\\0":I
    nop

    .end local v6    # "element\\5":Ljava/lang/Object;
    goto :goto_3d

    .line 1056
    :cond_56
    nop

    .line 788
    .end local v2    # "$this$forEach\\5":Ljava/lang/Iterable;
    .end local v4    # "$i$f$forEach\\5\\788":I
    new-instance v2, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v2}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v4, v2

    .line 1017
    .local v4, "t\\7":Lorg/luaj/vm2/LuaTable;
    const/4 v5, 0x0

    .line 788
    .local v5, "$i$a$-also-InstanceApi$collectionCall$3\\7\\788\\0":I
    move-object v6, v0

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$forEach\\8":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1055
    .local v7, "$i$f$forEach\\8\\788":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_66
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_7f

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\8":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Ljava/lang/String;

    .local v10, "it\\9":Ljava/lang/String;
    const/4 v11, 0x0

    .line 788
    .local v11, "$i$a$-forEach-InstanceApi$collectionCall$3$1\\9\\1055\\7":I
    invoke-static {v10}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v12

    check-cast v12, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v4, v3, v12}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 1055
    .end local v10    # "it\\9":Ljava/lang/String;
    .end local v11    # "$i$a$-forEach-InstanceApi$collectionCall$3$1\\9\\1055\\7":I
    nop

    .end local v9    # "element\\8":Ljava/lang/Object;
    goto :goto_66

    .line 1056
    :cond_7f
    nop

    .line 788
    .end local v6    # "$this$forEach\\8":Ljava/lang/Iterable;
    .end local v7    # "$i$f$forEach\\8\\788":I
    nop

    .end local v0    # "s":Ljava/util/LinkedHashSet;
    .end local v4    # "t\\7":Lorg/luaj/vm2/LuaTable;
    .end local v5    # "$i$a$-also-InstanceApi$collectionCall$3\\7\\788\\0":I
    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1ab

    .line 780
    :sswitch_85
    const-string v2, "AddTag"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_160

    goto/16 :goto_15f

    :sswitch_8f
    const-string v2, "GetTags"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_160

    goto/16 :goto_15f

    :sswitch_99
    const-string v0, "GetInstanceRemovedSignal"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15f

    .line 787
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "TagRemoved:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v0, v2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1ab

    .line 780
    :sswitch_cb
    const-string v2, "RemoveTag"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_160

    goto/16 :goto_15f

    :sswitch_d5
    const-string v0, "GetTagged"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15f

    .line 781
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v6, v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1051
    .local v2, "$i$f$filter\\1\\781":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v4, v0

    .local v4, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1052
    .local v5, "$i$f$filterTo\\2\\1051":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_f9
    :goto_f9
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_119

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\2":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v9, 0x0

    .line 781
    .local v9, "$i$a$-filter-InstanceApi$collectionCall$1\\3\\1052\\0":I
    invoke-direct {p0, v8}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->tags(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v10

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v10, v11}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    .line 1052
    .end local v8    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v9    # "$i$a$-filter-InstanceApi$collectionCall$1\\3\\1052\\0":I
    if-eqz v8, :cond_f9

    invoke-interface {v3, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_f9

    .line 1053
    .end local v7    # "element\\2":Ljava/lang/Object;
    :cond_119
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v4    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filterTo\\2\\1051":I
    check-cast v3, Ljava/util/List;

    .line 1051
    nop

    .line 781
    .end local v0    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\1\\781":I
    invoke-direct {p0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1ab

    .line 780
    :sswitch_126
    const-string v0, "GetInstanceAddedSignal"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15f

    .line 786
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getDm()Lcom/exampletest/mobilestudiotest/model/DataModel;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/exampletest/mobilestudiotest/model/DataModel;->getService(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->checkjstring()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "TagAdded:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v0, v2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto :goto_1ab

    .line 780
    :sswitch_157
    const-string v2, "HasTag"

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_160

    :cond_15f
    :goto_15f
    goto :goto_1a1

    .line 783
    :cond_160
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v2, v1

    .local v2, "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v4, 0x0

    .line 1054
    .local v4, "$i$f$udOrNull\\4\\783":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_170

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_171

    :cond_170
    move-object v7, v6

    :goto_171
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v8, :cond_176

    move-object v6, v7

    :cond_176
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 783
    .end local v2    # "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "$i$f$udOrNull\\4\\783":I
    if-eqz v6, :cond_199

    .line 784
    .local v6, "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    new-array v0, v0, [Lorg/luaj/vm2/LuaValue;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    aput-object v2, v0, v3

    const/4 v2, 0x3

    invoke-virtual {p2, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    aput-object v2, v0, v5

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    const-string v2, "varargsOf(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->callMethod(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v2

    .end local v6    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_1ab

    .line 783
    :cond_199
    new-instance v0, Lorg/luaj/vm2/LuaError;

    const-string v2, "Instance expected"

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 789
    :goto_1a1
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v2, "NONE"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/Varargs;

    .line 780
    :goto_1ab
    return-object v2

    :sswitch_data_1ac
    .sparse-switch
        -0x7f969d40 -> :sswitch_157
        -0x76802723 -> :sswitch_126
        -0x57fd4bbe -> :sswitch_d5
        -0x3c1e8faa -> :sswitch_cb
        0x5dfc16fd -> :sswitch_99
        0x5ebe346f -> :sswitch_8f
        0x749aeb59 -> :sswitch_85
        0x7e408144 -> :sswitch_1d
    .end sparse-switch
.end method

.method public final getEvents()Ljava/util/Set;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 105
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->events:Ljava/util/Set;

    return-object v0
.end method

.method public final getK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Object;
    .registers 13
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 177
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_8a0

    goto :goto_45

    :sswitch_12
    const-string v0, "ClassName"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_45

    .line 179
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 177
    :sswitch_1f
    const-string v0, "Archivable"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_45

    .line 181
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getArchivable()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 177
    :sswitch_30
    const-string v0, "Name"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_45

    .line 178
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 177
    :sswitch_3d
    const-string v0, "Parent"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_46

    :cond_45
    :goto_45
    goto :goto_4b

    .line 180
    :cond_46
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    return-object v0

    .line 183
    :goto_4b
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isPart(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    const-string v1, "CFrame"

    if-eqz v0, :cond_179

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v2, 0x42652ee1

    sparse-switch v0, :sswitch_data_8b2

    goto/16 :goto_179

    :sswitch_5f
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 190
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_6c
    const-string v0, "RotVelocity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_bc

    goto/16 :goto_179

    :sswitch_76
    const-string v0, "AssemblyMass"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_100

    goto/16 :goto_179

    :sswitch_80
    const-string v0, "AssemblyLinearVelocity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_163

    goto/16 :goto_179

    :sswitch_8a
    const-string v0, "Position"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 184
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_9d
    const-string v0, "Orientation"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 185
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toOrientation()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_b4
    const-string v0, "AssemblyAngularVelocity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 192
    :cond_bc
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_c3
    const-string v0, "Color"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 188
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->color(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_d2
    const-string v0, "Rotation"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 186
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toEulerXYZ()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_e9
    const-string v0, "Size"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 187
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    return-object v0

    .line 183
    :sswitch_f8
    const-string v0, "Mass"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 193
    :cond_100
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "s":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v1

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v2

    mul-float/2addr v1, v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v2

    mul-float/2addr v1, v2

    const v2, 0x3f333333    # 0.7f

    mul-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    return-object v1

    .line 183
    .end local v0    # "s":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :sswitch_11d
    const-string v0, "BrickColor"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_179

    .line 189
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_13c

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v2, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->color(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->closest(Lcom/exampletest/mobilestudiotest/model/Color3;)I

    move-result v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    :cond_13c
    return-object v0

    .line 183
    :sswitch_13d
    const-string v0, "PivotOffset"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_179

    .line 194
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_151

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    :cond_151
    return-object v0

    .line 183
    :sswitch_152
    const-string v0, "AssemblyRootPart"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 195
    return-object p1

    .line 183
    :sswitch_15b
    const-string v0, "Velocity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_179

    .line 191
    :cond_163
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_172

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->velocityOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    if-eqz v0, :cond_172

    goto :goto_178

    :cond_172
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    :goto_178
    return-object v0

    .line 197
    :cond_179
    :goto_179
    const-string v0, "Model"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18e

    .line 198
    const-string v0, "WorldPivot"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_18e

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    return-object v0

    .line 200
    :cond_18e
    const-string v0, "GuiBase2d"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_1d8

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_8f0

    goto :goto_1d8

    :sswitch_19f
    const-string v0, "AbsolutePosition"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d8

    .line 201
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsX()F

    move-result v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsY()F

    move-result v2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    return-object v0

    .line 200
    :sswitch_1b5
    const-string v0, "AbsoluteRotation"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d8

    .line 203
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 200
    :sswitch_1c2
    const-string v0, "AbsoluteSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d8

    .line 202
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsW()F

    move-result v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsH()F

    move-result v2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    return-object v0

    .line 206
    :cond_1d8
    :goto_1d8
    const-string v0, "UIGridStyleLayout"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f6

    const-string v0, "AbsoluteContentSize"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1f6

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsW()F

    move-result v1

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAbsH()F

    move-result v2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    return-object v0

    .line 207
    :cond_1f6
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "UIGridLayout"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/high16 v3, 0x42c80000    # 100.0f

    const/4 v4, 0x0

    if-eqz v0, :cond_233

    const-string v0, "AbsoluteCellSize"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_233

    const-string v0, "CellSize"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v1, :cond_21a

    move-object v4, v0

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/UDim2;

    :cond_21a
    if-eqz v4, :cond_22d

    .line 1017
    .local v4, "it\\1":Lcom/exampletest/mobilestudiotest/model/UDim2;
    const/4 v0, 0x0

    .line 207
    .local v0, "$i$a$-let-InstanceApi$getK$1\\1\\207\\0":I
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v3

    int-to-float v3, v3

    invoke-direct {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    .end local v0    # "$i$a$-let-InstanceApi$getK$1\\1\\207\\0":I
    .end local v4    # "it\\1":Lcom/exampletest/mobilestudiotest/model/UDim2;
    goto :goto_232

    :cond_22d
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-direct {v1, v3, v3}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    :goto_232
    return-object v1

    .line 208
    :cond_233
    const-string v0, "BaseScript"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    if-eqz v0, :cond_258

    .line 209
    const-string v0, "Enabled"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_258

    const-string v0, "Disabled"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    xor-int/2addr v0, v5

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 211
    :cond_258
    const-string v0, "Constraint"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_296

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_8fe

    goto :goto_296

    :sswitch_268
    const-string v0, "CurrentPosition"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_28b

    goto :goto_296

    :sswitch_271
    const-string v0, "CurrentAngle"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_28b

    goto :goto_296

    :sswitch_27a
    const-string v0, "CurrentDistance"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_296

    goto :goto_28b

    :sswitch_283
    const-string v0, "CurrentLength"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_296

    .line 212
    :cond_28b
    :goto_28b
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_295

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    :cond_295
    return-object v0

    .line 214
    :cond_296
    :goto_296
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v6

    const-string v7, "IsLoaded"

    const-string v8, "Camera"

    const/4 v9, 0x0

    sparse-switch v6, :sswitch_data_910

    goto/16 :goto_875

    :sswitch_2a8
    const-string v1, "RunService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 279
    const-string v0, "ClientGitHash"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_891

    const-string v0, "mobile"

    return-object v0

    .line 214
    :sswitch_2bb
    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 264
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_95a

    .line 268
    goto/16 :goto_891

    .line 264
    :sswitch_2ca
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_315

    .line 267
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-nez v0, :cond_2ed

    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isEditCamera(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    if-eqz v0, :cond_2ed

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCamera()Lcom/exampletest/mobilestudiotest/render/FlyCamera;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->cframe()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    goto :goto_2f9

    :cond_2ed
    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2f9

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    :cond_2f9
    :goto_2f9
    return-object v0

    .line 264
    :sswitch_2fa
    const-string v0, "ViewportSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_315

    .line 265
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->viewportSizeDp()Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v0

    return-object v0

    .line 264
    :sswitch_30d
    const-string v0, "Focus"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_317

    :cond_315
    goto/16 :goto_891

    .line 268
    :cond_317
    const-string v0, "Focus"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_325

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    :cond_325
    return-object v0

    .line 214
    :sswitch_326
    const-string v1, "DataModel"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 233
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const-wide/16 v1, 0x0

    sparse-switch v0, :sswitch_data_968

    .line 240
    goto/16 :goto_891

    .line 233
    :sswitch_339
    const-string v0, "GameId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 235
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCloud()Lcom/exampletest/mobilestudiotest/net/CloudPlace;

    move-result-object v0

    if-eqz v0, :cond_356

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->getUniverseId()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    goto :goto_35a

    :cond_356
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :goto_35a
    return-object v0

    .line 233
    :sswitch_35b
    const-string v0, "CreatorType"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 237
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    return-object v0

    .line 233
    :sswitch_369
    const-string v0, "PlaceId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 234
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCloud()Lcom/exampletest/mobilestudiotest/net/CloudPlace;

    move-result-object v0

    if-eqz v0, :cond_386

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->getPlaceId()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    goto :goto_38a

    :cond_386
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :goto_38a
    return-object v0

    .line 233
    :sswitch_38b
    const-string v0, "PrivateServerOwnerId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 240
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    return-object v0

    .line 233
    :sswitch_398
    const-string v0, "JobId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3a9

    goto :goto_3c1

    :sswitch_3a1
    const-string v0, "PrivateServerId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 239
    :cond_3a9
    const-string v0, ""

    return-object v0

    .line 233
    :sswitch_3ac
    const-string v0, "CreatorId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c1

    .line 236
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    return-object v0

    .line 233
    :sswitch_3b9
    const-string v0, "PlaceVersion"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3c3

    :cond_3c1
    :goto_3c1
    goto/16 :goto_891

    .line 238
    :cond_3c3
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_3c8
    const-string v1, "UserInputService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 273
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_98a

    .line 276
    goto/16 :goto_891

    .line 273
    :sswitch_3d9
    const-string v0, "TouchEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_438

    .line 274
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 273
    :sswitch_3e6
    const-string v0, "AccelerometerEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_3ef
    const-string v0, "MouseEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_3f8
    const-string v0, "VREnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_401
    const-string v0, "MouseIconEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_424

    goto :goto_438

    :sswitch_40a
    const-string v0, "KeyboardEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_413
    const-string v0, "GyroscopeEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    goto :goto_438

    :sswitch_41c
    const-string v0, "MouseBehavior"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_438

    .line 276
    :cond_424
    invoke-virtual {p1, p2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_42f

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    invoke-direct {v0, v9}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    :cond_42f
    return-object v0

    .line 273
    :sswitch_430
    const-string v0, "GamepadEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43a

    :cond_438
    :goto_438
    goto/16 :goto_891

    .line 275
    :cond_43a
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_43f
    const-string v1, "Players"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 215
    nop

    .line 216
    const-string v0, "LocalPlayer"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_45d

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_45c

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getPlayer()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    :cond_45c
    return-object v4

    .line 217
    :cond_45d
    const-string v0, "MaxPlayers"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_891

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_46a
    const-string v1, "Lighting"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 270
    nop

    .line 271
    const-string v0, "TimeOfDay"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_891

    const-string v0, "ClockTime"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_488

    move-object v4, v0

    check-cast v4, Ljava/lang/Number;

    :cond_488
    if-eqz v4, :cond_48f

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto :goto_491

    :cond_48f
    const/high16 v0, 0x41600000    # 14.0f

    .local v0, "ct":F
    :goto_491
    float-to-int v1, v0

    .local v1, "h":I
    int-to-float v2, v1

    sub-float v2, v0, v2

    const/high16 v3, 0x42700000    # 60.0f

    mul-float/2addr v2, v3

    float-to-int v2, v2

    .local v2, "m":I
    sget-object v3, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v3, v4}, [Ljava/lang/Object;

    move-result-object v3

    const/4 v4, 0x2

    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%02d:%02d:00"

    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "format(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v3

    .line 214
    .end local v0    # "ct":F
    .end local v1    # "h":I
    .end local v2    # "m":I
    :sswitch_4b8
    const-string v1, "TextLabel"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7aa

    goto/16 :goto_875

    :sswitch_4c2
    const-string v1, "Humanoid"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 219
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_9b0

    .line 225
    goto/16 :goto_891

    .line 219
    :sswitch_4d3
    const-string v0, "MoveDirection"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 222
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_4ea

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->moveDirection(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    if-eqz v0, :cond_4ea

    goto :goto_4f0

    :cond_4ea
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    :goto_4f0
    return-object v0

    .line 219
    :sswitch_4f1
    const-string v0, "SeatPart"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 225
    return-object v4

    .line 219
    :sswitch_4fa
    const-string v0, "FloorMaterial"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 223
    new-instance v0, Lcom/exampletest/mobilestudiotest/model/EnumValue;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v1

    if-eqz v1, :cond_513

    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->isGrounded(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v1

    if-ne v1, v5, :cond_513

    goto :goto_514

    :cond_513
    move v5, v9

    :goto_514
    if-eqz v5, :cond_519

    const/16 v1, 0x100

    goto :goto_51b

    :cond_519
    const/16 v1, 0x700

    :goto_51b
    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/EnumValue;-><init>(I)V

    return-object v0

    .line 219
    :sswitch_51f
    const-string v0, "Jump"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 224
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 219
    :sswitch_52c
    const-string v0, "RootPart"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_54a

    .line 221
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    if-eqz v0, :cond_541

    const-string v1, "HumanoidRootPart"

    const/4 v2, 0x2

    invoke-static {v0, v1, v9, v2, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ZILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v4

    :cond_541
    return-object v4

    .line 219
    :sswitch_542
    const-string v0, "Health"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_54c

    :cond_54a
    goto/16 :goto_891

    .line 220
    :cond_54c
    const-string v1, "Health_XML"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_55e

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_55e

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    :cond_55e
    return-object v1

    .line 214
    :sswitch_55f
    const-string v1, "ImageLabel"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_815

    goto/16 :goto_875

    :sswitch_569
    const-string v1, "TextBox"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7aa

    goto/16 :goto_875

    :sswitch_573
    const-string v1, "HttpService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 278
    const-string v0, "HttpEnabled"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_891

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_58d

    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    :cond_58d
    return-object v0

    .line 214
    :sswitch_58e
    const-string v1, "Sound"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 280
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const-wide/16 v1, 0x0

    sparse-switch v0, :sswitch_data_9ca

    .line 286
    goto/16 :goto_891

    .line 280
    :sswitch_5a1
    const-string v0, "TimePosition"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_604

    .line 282
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_5b3

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    :cond_5b3
    return-object v0

    .line 280
    :sswitch_5b4
    const-string v0, "IsPlaying"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_604

    .line 283
    const-string v0, "Playing"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 280
    :sswitch_5cf
    const-string v0, "PlaybackLoudness"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_604

    .line 285
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    return-object v0

    .line 280
    :sswitch_5dc
    const-string v0, "PlaybackSpeed"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_604

    .line 286
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_5f0

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    :cond_5f0
    return-object v0

    .line 280
    :sswitch_5f1
    invoke-virtual {p2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_604

    .line 284
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 280
    :sswitch_5fc
    const-string v0, "TimeLength"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_606

    :cond_604
    goto/16 :goto_891

    .line 281
    :cond_606
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_610

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    :cond_610
    return-object v0

    .line 214
    :sswitch_611
    const-string v1, "StudioService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 243
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_9e4

    .line 250
    goto/16 :goto_891

    .line 243
    :sswitch_622
    const-string v0, "ShowConstraintDetails"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_63c

    goto :goto_68d

    :sswitch_62b
    const-string v0, "ActiveScript"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 248
    return-object v4

    .line 243
    :sswitch_634
    const-string v0, "DraggerSolveConstraints"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 247
    :cond_63c
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 243
    :sswitch_641
    const-string v0, "UseLocalSpace"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 246
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 243
    :sswitch_64e
    const-string v0, "GridSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 244
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSnapEnabled()Z

    move-result v0

    if-eqz v0, :cond_66c

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v2

    :cond_66c
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 243
    :sswitch_671
    const-string v0, "Theme"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 250
    return-object v4

    .line 243
    :sswitch_67a
    const-string v0, "StudioLocaleId"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_68d

    .line 249
    const-string v0, "en-us"

    return-object v0

    .line 243
    :sswitch_685
    const-string v0, "RotateIncrement"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_68f

    :cond_68d
    :goto_68d
    goto/16 :goto_891

    .line 245
    :cond_68f
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnapEnabled()Z

    move-result v0

    if-eqz v0, :cond_6a5

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnap()F

    move-result v2

    :cond_6a5
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_6aa
    const-string v1, "DraggerService"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 252
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_a06

    .line 262
    goto/16 :goto_891

    .line 252
    :sswitch_6bb
    const-string v0, "AngleSnapIncrement"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 258
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnap()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_6d2
    const-string v0, "GeometrySnapColor"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 262
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/16 v1, 0xff

    const/16 v2, 0xa5

    invoke-virtual {v0, v1, v2, v9}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_6e5
    const-string v0, "AngleSnapEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 257
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getRotSnapEnabled()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_6fc
    const-string v0, "AnimateHover"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_78c

    goto/16 :goto_799

    :sswitch_706
    const-string v0, "PivotSnapToGeometry"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_78c

    goto/16 :goto_799

    :sswitch_710
    const-string v0, "HoverThickness"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 253
    const v0, 0x3d23d70a    # 0.04f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_720
    const-string v0, "JointsEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 255
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_72d
    const-string v0, "LinearSnapIncrement"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 260
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getMoveSnap()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_744
    const-string v0, "ShowHover"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_78c

    goto :goto_799

    :sswitch_74d
    const-string v0, "AlignDraggedObjects"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_78c

    goto :goto_799

    :sswitch_756
    const-string v0, "LinearSnapEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 259
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getSnapEnabled()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_76d
    const-string v0, "CollisionsEnabled"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 256
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCollisionsEnabled()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_784
    const-string v0, "ShowPivotIndicator"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_799

    .line 254
    :cond_78c
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 252
    :sswitch_791
    const-string v0, "HoverAnimateFrequency"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_79b

    :cond_799
    :goto_799
    goto/16 :goto_891

    .line 261
    :cond_79b
    const/high16 v0, 0x3e800000    # 0.25f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_7a2
    const-string v1, "TextButton"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 292
    :cond_7aa
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_a40

    goto :goto_7d6

    :sswitch_7b2
    const-string v0, "ContentText"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7d6

    .line 294
    const-string v0, "Text"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 292
    :sswitch_7c1
    const-string v0, "TextFits"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7d6

    .line 295
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 292
    :sswitch_7ce
    const-string v0, "TextBounds"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7d8

    :cond_7d6
    :goto_7d6
    goto/16 :goto_891

    .line 293
    :cond_7d8
    const-string v0, "TextSize"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_7e5

    check-cast v0, Ljava/lang/Number;

    goto :goto_7e6

    :cond_7e5
    move-object v0, v4

    :goto_7e6
    if-eqz v0, :cond_7ed

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto :goto_7ef

    :cond_7ed
    const/high16 v0, 0x41600000    # 14.0f

    .local v0, "s":F
    :goto_7ef
    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const-string v2, "Text"

    invoke-virtual {p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v3, v2, Ljava/lang/String;

    if-eqz v3, :cond_7fe

    move-object v4, v2

    check-cast v4, Ljava/lang/String;

    :cond_7fe
    if-eqz v4, :cond_804

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v9

    :cond_804
    int-to-float v2, v9

    mul-float/2addr v2, v0

    const/high16 v3, 0x3f000000    # 0.5f

    mul-float/2addr v2, v3

    invoke-direct {v1, v2, v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    return-object v1

    .line 214
    .end local v0    # "s":F
    :sswitch_80d
    const-string v1, "ImageButton"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 232
    :cond_815
    invoke-static {p2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_891

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_820
    const-string v1, "Workspace"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_875

    .line 227
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_a4e

    .line 230
    goto :goto_891

    .line 227
    :sswitch_830
    const-string v0, "Gravity"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_861

    .line 230
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_845

    const v0, 0x43443333    # 196.2f

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    :cond_845
    return-object v0

    .line 227
    :sswitch_846
    const-string v0, "CurrentCamera"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_861

    .line 229
    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_858

    invoke-virtual {p1, v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    :cond_858
    return-object v0

    .line 227
    :sswitch_859
    const-string v0, "DistributedGameTime"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_862

    :cond_861
    goto :goto_891

    .line 228
    :cond_862
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getTime()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    return-object v0

    .line 214
    :sswitch_86d
    const-string v1, "Player"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_876

    :cond_875
    :goto_875
    goto :goto_891

    .line 288
    :cond_876
    nop

    .line 289
    const-string v0, "PlayerGui"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_884

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    return-object v0

    .line 290
    :cond_884
    const-string v0, "Backpack"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_891

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v0

    return-object v0

    .line 298
    :cond_891
    :goto_891
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 299
    .local v0, "key":Ljava/lang/String;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    return-object v1

    :sswitch_data_8a0
    .sparse-switch
        -0x71f00b36 -> :sswitch_3d
        0x24eeab -> :sswitch_30
        0x7094d7fd -> :sswitch_1f
        0x76db3c03 -> :sswitch_12
    .end sparse-switch

    :sswitch_data_8b2
    .sparse-switch
        -0x7cef5f03 -> :sswitch_15b
        -0x68a847e5 -> :sswitch_152
        -0x5f4bf4ab -> :sswitch_13d
        -0x33b84c3e -> :sswitch_11d
        0x247b14 -> :sswitch_f8
        0x275421 -> :sswitch_e9
        0x173739e -> :sswitch_d2
        0x3e43f43 -> :sswitch_c3
        0x9fe75f9 -> :sswitch_b4
        0xd9c9db0 -> :sswitch_9d
        0x306cfd49 -> :sswitch_8a
        0x3f7ca6c8 -> :sswitch_80
        0x4cf0aa1a -> :sswitch_76
        0x4f2c3bb4 -> :sswitch_6c
        0x76646aea -> :sswitch_5f
    .end sparse-switch

    :sswitch_data_8f0
    .sparse-switch
        -0x39cdddc8 -> :sswitch_1c2
        0xaab5e35 -> :sswitch_1b5
        0x39a4e7e0 -> :sswitch_19f
    .end sparse-switch

    :sswitch_data_8fe
    .sparse-switch
        -0x5771aa61 -> :sswitch_283
        0x5c15dc6e -> :sswitch_27a
        0x5fafa2fa -> :sswitch_271
        0x7776e9a2 -> :sswitch_268
    .end sparse-switch

    :sswitch_data_910
    .sparse-switch
        -0x715c78ff -> :sswitch_86d
        -0x4675f38b -> :sswitch_820
        -0x37e04bb3 -> :sswitch_80d
        -0x37c02121 -> :sswitch_7a2
        -0x141b4eeb -> :sswitch_6aa
        -0x19fb821 -> :sswitch_611
        0x4c5d8ef -> :sswitch_58e
        0xc9bd4ed -> :sswitch_573
        0xeb5ad3e -> :sswitch_569
        0x1fbe6279 -> :sswitch_55f
        0x2418859d -> :sswitch_4c2
        0x38859da7 -> :sswitch_4b8
        0x3efaa72c -> :sswitch_46a
        0x45cd5992 -> :sswitch_43f
        0x50b2bb16 -> :sswitch_3c8
        0x60c9757f -> :sswitch_326
        0x77deaf45 -> :sswitch_2bb
        0x7f0a9dca -> :sswitch_2a8
    .end sparse-switch

    :sswitch_data_95a
    .sparse-switch
        0x40e64b8 -> :sswitch_30d
        0x1faddde7 -> :sswitch_2fa
        0x76646aea -> :sswitch_2ca
    .end sparse-switch

    :sswitch_data_968
    .sparse-switch
        -0x6db1b60f -> :sswitch_3b9
        -0x64deb1b9 -> :sswitch_3ac
        -0x60e7dbf -> :sswitch_3a1
        0x446b998 -> :sswitch_398
        0x3da9edc8 -> :sswitch_38b
        0x45c35462 -> :sswitch_369
        0x580c3566 -> :sswitch_35b
        0x7eb20ccd -> :sswitch_339
    .end sparse-switch

    :sswitch_data_98a
    .sparse-switch
        -0x51ac7740 -> :sswitch_430
        -0x4623f209 -> :sswitch_41c
        -0x261cc564 -> :sswitch_413
        -0x25937ac6 -> :sswitch_40a
        0x14a562c3 -> :sswitch_401
        0x1865cce5 -> :sswitch_3f8
        0x1f05a6fc -> :sswitch_3ef
        0x47cb8012 -> :sswitch_3e6
        0x483dc322 -> :sswitch_3d9
    .end sparse-switch

    :sswitch_data_9b0
    .sparse-switch
        -0x7f661184 -> :sswitch_542
        -0x61983eb -> :sswitch_52c
        0x23684e -> :sswitch_51f
        0xdee5133 -> :sswitch_4fa
        0x38e57fb8 -> :sswitch_4f1
        0x53e5d68e -> :sswitch_4d3
    .end sparse-switch

    :sswitch_data_9ca
    .sparse-switch
        -0x66acb7cd -> :sswitch_5fc
        -0x15637a11 -> :sswitch_5f1
        -0x7d3fd34 -> :sswitch_5dc
        0x18d08c04 -> :sswitch_5cf
        0x37783784 -> :sswitch_5b4
        0x4ac98736 -> :sswitch_5a1
    .end sparse-switch

    :sswitch_data_9e4
    .sparse-switch
        -0x4aaba3cc -> :sswitch_685
        -0x134072d5 -> :sswitch_67a
        0x4d085a9 -> :sswitch_671
        0x16cf3087 -> :sswitch_64e
        0x2864e122 -> :sswitch_641
        0x2cac1a17 -> :sswitch_634
        0x5dcfb391 -> :sswitch_62b
        0x5e680008 -> :sswitch_622
    .end sparse-switch

    :sswitch_data_a06
    .sparse-switch
        -0x75d07b49 -> :sswitch_791
        -0x6a125f96 -> :sswitch_784
        -0x3a227fa0 -> :sswitch_76d
        -0x21c6646e -> :sswitch_756
        -0x2299299 -> :sswitch_74d
        0x4b9741f -> :sswitch_744
        0xc0dcb80 -> :sswitch_72d
        0x2db419b8 -> :sswitch_720
        0x3f65bdb8 -> :sswitch_710
        0x4246ac39 -> :sswitch_706
        0x46cb9efb -> :sswitch_6fc
        0x4c587d64 -> :sswitch_6e5
        0x5d2a5547 -> :sswitch_6d2
        0x6dfb80d2 -> :sswitch_6bb
    .end sparse-switch

    :sswitch_data_a40
    .sparse-switch
        -0x3814519e -> :sswitch_7ce
        -0x37fe4a91 -> :sswitch_7c1
        0x4c37b126 -> :sswitch_7b2
    .end sparse-switch

    :sswitch_data_a4e
    .sparse-switch
        -0x74bdc67e -> :sswitch_859
        -0x67062222 -> :sswitch_846
        0x73f10a2e -> :sswitch_830
    .end sparse-switch
.end method

.method public final getRt()Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;
    .registers 2

    .line 16
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    return-object v0
.end method

.method public final getSignalMeta()Lorg/luaj/vm2/LuaTable;
    .registers 2

    .line 19
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signalMeta:Lorg/luaj/vm2/LuaTable;

    return-object v0
.end method

.method public final hasK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Z
    .registers 8
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 303
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->BASE_PROPS:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_14

    return v1

    .line 304
    :cond_14
    invoke-direct {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isPart(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    if-eqz v0, :cond_23

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->PART_PROPS:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_23

    return v1

    .line 305
    :cond_23
    const-string v0, "Model"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_34

    const-string v0, "WorldPivot"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_34

    return v1

    .line 306
    :cond_34
    const-string v0, "GuiBase2d"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_48

    const/4 v0, 0x2

    const/4 v3, 0x0

    const-string v4, "Absolute"

    invoke-static {p2, v4, v2, v0, v3}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_48

    return v1

    .line 307
    :cond_48
    const-string v0, "UIGridStyleLayout"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6d

    const-string v0, "AbsoluteContentSize"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6c

    const-string v0, "AbsoluteCellSize"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6d

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "UIGridLayout"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6d

    :cond_6c
    return v1

    .line 308
    :cond_6d
    const-string v0, "BaseScript"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7e

    const-string v0, "Enabled"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7e

    return v1

    .line 309
    :cond_7e
    const-string v0, "Constraint"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8f

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->CONSTRAINT_READOUTS:Ljava/util/Set;

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8f

    return v1

    .line 310
    :cond_8f
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->SPECIAL_PROPS:Ljava/util/Map;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    if-eqz v0, :cond_a4

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-ne v0, v1, :cond_a4

    move v2, v1

    :cond_a4
    if-eqz v2, :cond_a7

    return v1

    .line 311
    :cond_a7
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v1, p1, p2}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public final humanoidCall(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 24
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    const-string v4, "inst"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "name"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "a"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 943
    iget-object v4, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v4

    .line 944
    .local v4, "play":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v5

    const-string v6, " expected, got "

    const/16 v7, 0x8

    const-string v8, "Health"

    const-string v9, "NONE"

    const/4 v10, 0x1

    const-string v11, "arg(...)"

    const/4 v12, 0x2

    const/4 v13, 0x0

    sparse-switch v5, :sswitch_data_320

    goto/16 :goto_30e

    :sswitch_33
    const-string v5, "GetState"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 959
    if-eqz v4, :cond_41

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->isGrounded(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v10

    .line 960
    .local v10, "g":Z
    :cond_41
    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v6, "HumanoidStateType"

    new-instance v8, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v10, :cond_4f

    const-string v9, "Running"

    invoke-direct {v8, v6, v9, v7}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    goto :goto_55

    :cond_4f
    const-string v7, "Freefall"

    const/4 v9, 0x5

    invoke-direct {v8, v6, v7, v9}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    :goto_55
    invoke-virtual {v5, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    .end local v10    # "g":Z
    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_5d
    const-string v5, "GetAccessories"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 970
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    if-eqz v5, :cond_a0

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->getChildren()Ljava/util/ArrayList;

    move-result-object v5

    if-eqz v5, :cond_a0

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$filter\\11":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1099
    .local v6, "$i$f$filter\\11\\970":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\12":Ljava/util/Collection;
    move-object v8, v5

    .local v8, "$this$filterTo\\12":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1100
    .local v9, "$i$f$filterTo\\12\\1099":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_81
    :goto_81
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_9b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\12":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v12, "it\\13":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v13, 0x0

    .line 970
    .local v13, "$i$a$-filter-InstanceApi$humanoidCall$3\\13\\1100\\0":I
    const-string v14, "Accessory"

    invoke-virtual {v12, v14}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v12

    .line 1100
    .end local v12    # "it\\13":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v13    # "$i$a$-filter-InstanceApi$humanoidCall$3\\13\\1100\\0":I
    if-eqz v12, :cond_81

    invoke-interface {v7, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_81

    .line 1101
    .end local v11    # "element\\12":Ljava/lang/Object;
    :cond_9b
    nop

    .end local v7    # "destination\\12":Ljava/util/Collection;
    .end local v8    # "$this$filterTo\\12":Ljava/lang/Iterable;
    .end local v9    # "$i$f$filterTo\\12\\1099":I
    check-cast v7, Ljava/util/List;

    .line 1099
    nop

    .line 970
    .end local v5    # "$this$filter\\11":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filter\\11\\970":I
    goto :goto_a4

    :cond_a0
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v7

    :goto_a4
    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v5

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_ac
    const-string v5, "GetPlayingAnimationTracks"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 963
    if-eqz v4, :cond_fd

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->playingTrackTables(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v5

    if-eqz v5, :cond_fd

    .line 1017
    .local v5, "l\\5":Ljava/util/List;
    const/4 v6, 0x0

    .line 963
    .local v6, "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    new-instance v7, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v7}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v8, v7

    .line 1017
    .local v8, "tb\\6":Lorg/luaj/vm2/LuaTable;
    const/4 v9, 0x0

    .line 963
    .local v9, "$i$a$-also-InstanceApi$humanoidCall$1$1\\6\\963\\5":I
    move-object v10, v5

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 1095
    .local v11, "$i$f$forEachIndexed\\7\\963":I
    const/4 v12, 0x0

    .line 1096
    .local v12, "index\\7":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_cd
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_f7

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "item\\7":Ljava/lang/Object;
    add-int/lit8 v15, v12, 0x1

    .end local v12    # "index\\7":I
    .local v15, "index\\7":I
    if-gez v12, :cond_de

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_de
    move-object/from16 v16, v14

    check-cast v16, Lorg/luaj/vm2/LuaTable;

    .local v12, "i\\8":I
    .local v16, "x\\8":Lorg/luaj/vm2/LuaTable;
    const/16 v17, 0x0

    .line 963
    .local v17, "$i$a$-forEachIndexed-InstanceApi$humanoidCall$1$1$1\\8\\1096\\6":I
    move-object/from16 v18, v5

    .end local v5    # "l\\5":Ljava/util/List;
    .local v18, "l\\5":Ljava/util/List;
    add-int/lit8 v5, v12, 0x1

    move/from16 v19, v6

    .end local v6    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    .local v19, "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    move-object/from16 v6, v16

    check-cast v6, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v8, v5, v6}, Lorg/luaj/vm2/LuaTable;->set(ILorg/luaj/vm2/LuaValue;)V

    .line 1096
    .end local v12    # "i\\8":I
    .end local v16    # "x\\8":Lorg/luaj/vm2/LuaTable;
    .end local v17    # "$i$a$-forEachIndexed-InstanceApi$humanoidCall$1$1$1\\8\\1096\\6":I
    move v12, v15

    move-object/from16 v5, v18

    move/from16 v6, v19

    .end local v14    # "item\\7":Ljava/lang/Object;
    goto :goto_cd

    .line 1097
    .end local v15    # "index\\7":I
    .end local v18    # "l\\5":Ljava/util/List;
    .end local v19    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    .restart local v5    # "l\\5":Ljava/util/List;
    .restart local v6    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    .local v12, "index\\7":I
    :cond_f7
    move-object/from16 v18, v5

    move/from16 v19, v6

    .line 963
    .end local v5    # "l\\5":Ljava/util/List;
    .end local v6    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    .end local v10    # "$this$forEachIndexed\\7":Ljava/lang/Iterable;
    .end local v11    # "$i$f$forEachIndexed\\7\\963":I
    .end local v12    # "index\\7":I
    .restart local v18    # "l\\5":Ljava/util/List;
    .restart local v19    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    nop

    .end local v8    # "tb\\6":Lorg/luaj/vm2/LuaTable;
    .end local v9    # "$i$a$-also-InstanceApi$humanoidCall$1$1\\6\\963\\5":I
    .end local v18    # "l\\5":Ljava/util/List;
    .end local v19    # "$i$a$-let-InstanceApi$humanoidCall$1\\5\\963\\0":I
    goto :goto_102

    :cond_fd
    new-instance v7, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v7}, Lorg/luaj/vm2/LuaTable;-><init>()V

    :goto_102
    move-object v5, v7

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_107
    const-string v5, "UnequipTools"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 965
    if-eqz v4, :cond_114

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->unequip()V

    :cond_114
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_11d
    const-string v5, "TakeDamage"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 946
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    if-eqz v5, :cond_132

    const-string v6, "ForceField"

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChildOfClass(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v5

    goto :goto_133

    :cond_132
    move-object v5, v13

    :goto_133
    if-nez v5, :cond_136

    const/4 v10, 0x0

    .line 947
    .local v10, "hasFF":Z
    :cond_136
    if-nez v10, :cond_15f

    invoke-virtual {v0, v1, v8}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->getK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Ljava/lang/Number;

    if-eqz v6, :cond_143

    move-object v13, v5

    check-cast v13, Ljava/lang/Number;

    :cond_143
    if-eqz v13, :cond_14a

    invoke-virtual {v13}, Ljava/lang/Number;->floatValue()F

    move-result v5

    goto :goto_14c

    :cond_14a
    const/high16 v5, 0x42c80000    # 100.0f

    :goto_14c
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v6

    sub-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-virtual {v0, v1, v8, v5}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .line 948
    :cond_15f
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 945
    .end local v10    # "hasFF":Z
    nop

    .line 947
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_169
    const-string v5, "SetStateEnabled"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 966
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_17a
    const-string v5, "Move"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 951
    if-eqz v4, :cond_1c8

    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Vector3"

    .local v5, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\2":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1092
    .local v8, "$i$f$ud\\2\\951":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_199

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_19a

    :cond_199
    move-object v9, v13

    :goto_19a
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v10, :cond_19f

    move-object v13, v9

    :cond_19f
    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v13, :cond_1a7

    .line 951
    .end local v5    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\2":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\2\\951":I
    invoke-virtual {v4, v1, v13}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->scriptMove(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    goto :goto_1c8

    .line 1092
    .restart local v5    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v7    # "what\\2":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\2\\951":I
    :cond_1a7
    new-instance v9, Lorg/luaj/vm2/LuaError;

    sget-object v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v10, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v9, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v9

    .line 951
    .end local v5    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\2":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\2\\951":I
    :cond_1c8
    :goto_1c8
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_1d1
    const-string v5, "ChangeState"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 953
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    .line 1093
    .local v6, "$i$f$udOrNull\\3\\953":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_1ec

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_1ed

    :cond_1ec
    move-object v9, v13

    :goto_1ed
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v10, :cond_1f2

    move-object v13, v9

    :cond_1f2
    check-cast v13, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 953
    .end local v5    # "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$udOrNull\\3\\953":I
    if-eqz v13, :cond_1fb

    invoke-virtual {v13}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v5

    goto :goto_203

    :cond_1fb
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v5

    .line 954
    .local v5, "st":I
    :goto_203
    const/4 v6, 0x3

    if-ne v5, v6, :cond_20b

    if-eqz v4, :cond_20b

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->jump(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .line 955
    :cond_20b
    const/16 v6, 0xf

    if-ne v5, v6, :cond_217

    const/4 v6, 0x0

    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v6

    invoke-virtual {v0, v1, v8, v6}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .line 956
    :cond_217
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 952
    .end local v5    # "st":I
    nop

    .line 954
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_221
    const-string v5, "GetStateEnabled"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 967
    sget-object v5, Lorg/luaj/vm2/LuaValue;->TRUE:Lorg/luaj/vm2/LuaBoolean;

    const-string v6, "TRUE"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_234
    const-string v5, "EquipTool"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 964
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\9":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    .line 1098
    .local v6, "$i$f$udOrNull\\9\\964":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_24f

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_250

    :cond_24f
    move-object v7, v13

    :goto_250
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v8, :cond_255

    move-object v13, v7

    :cond_255
    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 964
    .end local v5    # "$this$udOrNull\\9":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$udOrNull\\9\\964":I
    if-eqz v13, :cond_25f

    .line 1017
    .local v13, "it\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v5, 0x0

    .line 964
    .local v5, "$i$a$-let-InstanceApi$humanoidCall$2\\10\\964\\0":I
    if-eqz v4, :cond_25f

    invoke-virtual {v4, v13}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->equip(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    .end local v5    # "$i$a$-let-InstanceApi$humanoidCall$2\\10\\964\\0":I
    .end local v13    # "it\\10":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_25f
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_268
    const-string v5, "LoadAnimation"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 962
    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    .line 1094
    .local v6, "$i$f$udOrNull\\4\\962":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_283

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_284

    :cond_283
    move-object v7, v13

    :goto_284
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v8, :cond_289

    move-object v13, v7

    :cond_289
    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 962
    .end local v5    # "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$udOrNull\\4\\962":I
    invoke-direct {v0, v1, v13}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaTable;

    move-result-object v5

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_293
    const-string v5, "ApplyDescription"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_30f

    goto/16 :goto_30e

    :sswitch_29d
    const-string v5, "GetAppliedDescription"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 969
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v6, "NIL"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_31e

    .line 944
    :sswitch_2b0
    const-string v5, "MoveTo"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_30e

    .line 950
    if-eqz v4, :cond_2fe

    invoke-virtual {v3, v12}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Vector3"

    .local v5, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\1":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1091
    .local v8, "$i$f$ud\\1\\950":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_2cf

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_2d0

    :cond_2cf
    move-object v9, v13

    :goto_2d0
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v10, :cond_2d5

    move-object v13, v9

    :cond_2d5
    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v13, :cond_2dd

    .line 950
    .end local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\1":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\1\\950":I
    invoke-virtual {v4, v1, v13}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->moveTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    goto :goto_2fe

    .line 1091
    .restart local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v7    # "what\\1":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\1\\950":I
    :cond_2dd
    new-instance v9, Lorg/luaj/vm2/LuaError;

    sget-object v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v10, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v9, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v9

    .line 950
    .end local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\1":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\1\\950":I
    :cond_2fe
    :goto_2fe
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto :goto_31e

    .line 944
    :sswitch_306
    const-string v5, "AddAccessory"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_30f

    :cond_30e
    :goto_30e
    goto :goto_317

    .line 968
    :cond_30f
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    goto :goto_31e

    .line 971
    :goto_317
    sget-object v5, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v5, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Lorg/luaj/vm2/Varargs;

    .line 944
    :goto_31e
    return-object v5

    nop

    :sswitch_data_320
    .sparse-switch
        -0x7c7d906f -> :sswitch_306
        -0x76477db4 -> :sswitch_2b0
        -0x661b92eb -> :sswitch_29d
        -0x5a12e432 -> :sswitch_293
        -0x499e36e2 -> :sswitch_268
        -0x48713238 -> :sswitch_234
        -0x30176c3a -> :sswitch_221
        0x2336a1 -> :sswitch_1d1
        0x24aff1 -> :sswitch_17a
        0x6318ed2 -> :sswitch_169
        0x198dc6f6 -> :sswitch_11d
        0x4bb9c704 -> :sswitch_107
        0x52eb29f4 -> :sswitch_ac
        0x6174b61a -> :sswitch_5d
        0x7902cefb -> :sswitch_33
    .end sparse-switch
.end method

.method public final index(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 14
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "key0"    # Ljava/lang/String;

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key0"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 443
    const/4 v0, 0x0

    .local v0, "key":Ljava/lang/Object;
    move-object v0, p2

    .line 444
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lez v1, :cond_19

    move v1, v2

    goto :goto_1a

    :cond_19
    move v1, v3

    :goto_1a
    if-eqz v1, :cond_4f

    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-static {v1}, Ljava/lang/Character;->isLowerCase(C)Z

    move-result v1

    if-eqz v1, :cond_4f

    .line 445
    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-static {v1}, Ljava/lang/Character;->toUpperCase(C)C

    move-result v1

    invoke-virtual {v0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    const-string v5, "substring(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 446
    .local v1, "cap":Ljava/lang/String;
    invoke-direct {p0, p1, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->methodAllowed(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_4f

    move-object v0, v1

    .line 448
    .end local v1    # "cap":Ljava/lang/String;
    :cond_4f
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const-string v4, "valueOf(...)"

    sparse-switch v1, :sswitch_data_23c

    goto :goto_8d

    :sswitch_59
    const-string v1, "ClassName"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8d

    .line 450
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v1

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    return-object v1

    .line 448
    :sswitch_6f
    const-string v1, "Name"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8d

    .line 449
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v1

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    return-object v1

    .line 448
    :sswitch_85
    const-string v1, "Parent"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8e

    :cond_8d
    :goto_8d
    goto :goto_99

    .line 451
    :cond_8e
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getParent()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    return-object v1

    .line 453
    :goto_99
    invoke-direct {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->methodAllowed(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_c3

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->methodCache:Ljava/util/HashMap;

    check-cast v1, Ljava/util/Map;

    .local v1, "$this$getOrPut\\1":Ljava/util/Map;
    move-object v2, v0

    .local v2, "key\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1018
    .local v3, "$i$f$getOrPut\\1\\453":I
    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 1019
    .local v4, "value\\1":Ljava/lang/Object;
    if-nez v4, :cond_be

    .line 1020
    const/4 v5, 0x0

    .line 453
    .local v5, "$i$a$-getOrPut-InstanceApi$index$1\\2\\1020\\0":I
    move-object v6, v0

    .local v6, "k\\2":Ljava/lang/String;
    new-instance v7, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda20;

    invoke-direct {v7, p0, v6}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda20;-><init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Ljava/lang/String;)V

    invoke-static {v7}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v7

    check-cast v7, Lorg/luaj/vm2/LuaValue;

    .line 1020
    .end local v5    # "$i$a$-getOrPut-InstanceApi$index$1\\2\\1020\\0":I
    .end local v6    # "k\\2":Ljava/lang/String;
    nop

    .line 1021
    .local v7, "answer\\1":Ljava/lang/Object;
    invoke-interface {v1, v2, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1022
    nop

    .end local v7    # "answer\\1":Ljava/lang/Object;
    goto :goto_bf

    .line 1024
    :cond_be
    move-object v7, v4

    .line 1019
    :goto_bf
    nop

    .end local v1    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v2    # "key\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$getOrPut\\1\\453":I
    .end local v4    # "value\\1":Ljava/lang/Object;
    check-cast v7, Lorg/luaj/vm2/LuaValue;

    .line 453
    return-object v7

    .line 454
    :cond_c3
    const-string v1, "BaseScript"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    const-string v5, ""

    const/4 v6, 0x0

    if-nez v1, :cond_d7

    const-string v1, "ModuleScript"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_d7

    goto :goto_f7

    .line 455
    :cond_d7
    const-string v1, "Source"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_f7

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Ljava/lang/String;

    if-eqz v2, :cond_ea

    move-object v6, v1

    check-cast v6, Ljava/lang/String;

    :cond_ea
    if-eqz v6, :cond_ed

    move-object v5, v6

    :cond_ed
    invoke-static {v5}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v1

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    return-object v1

    .line 457
    :cond_f7
    :goto_f7
    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->hasK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_10e

    .line 458
    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->getK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    .line 459
    .local v1, "v":Ljava/lang/Object;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v3, p1, v0}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v1, p1, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->toLua(Ljava/lang/Object;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    return-object v2

    .line 461
    .end local v1    # "v":Ljava/lang/Object;
    :cond_10e
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->events:Ljava/util/Set;

    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x2

    if-eqz v1, :cond_132

    .line 464
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->universalEvents:Ljava/util/Set;

    invoke-interface {v1, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12d

    invoke-static {p1, v0, v3, v7, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ZILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-eqz v1, :cond_12d

    .line 1017
    .local v1, "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x0

    .line 464
    .local v2, "$i$a$-let-InstanceApi$index$2\\3\\464\\0":I
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    return-object v3

    .line 465
    .end local v1    # "it\\3":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "$i$a$-let-InstanceApi$index$2\\3\\464\\0":I
    :cond_12d
    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    return-object v1

    .line 467
    :cond_132
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getCallbacks()Ljava/util/IdentityHashMap;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/HashMap;

    if-eqz v1, :cond_14a

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    if-eqz v1, :cond_14a

    .line 1017
    .local v1, "it\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 467
    .local v2, "$i$a$-let-InstanceApi$index$3\\4\\467\\0":I
    return-object v1

    .line 468
    .end local v1    # "it\\4":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$a$-let-InstanceApi$index$3\\4\\467\\0":I
    :cond_14a
    invoke-static {p1, v0, v3, v7, v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->findFirstChild$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;ZILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v1

    if-eqz v1, :cond_158

    .line 1017
    .local v1, "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v2, 0x0

    .line 468
    .local v2, "$i$a$-let-InstanceApi$index$4\\5\\468\\0":I
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    return-object v3

    .line 469
    .end local v1    # "it\\5":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v2    # "$i$a$-let-InstanceApi$index$4\\5\\468\\0":I
    :cond_158
    invoke-direct {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->contentAlias(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_17a

    .line 1017
    .local v1, "a\\6":Ljava/lang/String;
    const/4 v2, 0x0

    .line 469
    .local v2, "$i$a$-let-InstanceApi$index$5\\6\\469\\0":I
    invoke-virtual {p0, p1, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->hasK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_170

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {p0, p1, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->getK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4, p1, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->toLua(Ljava/lang/Object;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    goto :goto_179

    :cond_170
    invoke-static {v5}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    :goto_179
    return-object v3

    .line 473
    .end local v1    # "a\\6":Ljava/lang/String;
    .end local v2    # "$i$a$-let-InstanceApi$index$5\\6\\469\\0":I
    :cond_17a
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->MEMBER_OWNERS:Ljava/util/Map;

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    if-eqz v1, :cond_1ea

    .line 1017
    .local v1, "owners\\7":Ljava/util/List;
    const/4 v4, 0x0

    .line 473
    .local v4, "$i$a$-let-InstanceApi$index$6\\7\\473\\0":I
    move-object v5, v1

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$none\\8":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1025
    .local v6, "$i$f$none\\8\\473":I
    instance-of v7, v5, Ljava/util/Collection;

    if-eqz v7, :cond_197

    move-object v7, v5

    check-cast v7, Ljava/util/Collection;

    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_197

    goto :goto_1b2

    .line 1026
    :cond_197
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_19b
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_1b1

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\8":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Ljava/lang/String;

    .local v9, "it\\9":Ljava/lang/String;
    const/4 v10, 0x0

    .line 473
    .local v10, "$i$a$-none-InstanceApi$index$6$1\\9\\1026\\7":I
    invoke-virtual {p1, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v9

    .line 1026
    .end local v9    # "it\\9":Ljava/lang/String;
    .end local v10    # "$i$a$-none-InstanceApi$index$6$1\\9\\1026\\7":I
    if-eqz v9, :cond_19b

    move v2, v3

    goto :goto_1b2

    .line 1027
    .end local v8    # "element\\8":Ljava/lang/Object;
    :cond_1b1
    nop

    .line 473
    .end local v5    # "$this$none\\8":Ljava/lang/Iterable;
    .end local v6    # "$i$f$none\\8\\473":I
    :goto_1b2
    if-nez v2, :cond_1b5

    .end local v1    # "owners\\7":Ljava/util/List;
    .end local v4    # "$i$a$-let-InstanceApi$index$6\\7\\473\\0":I
    goto :goto_1ea

    .restart local v1    # "owners\\7":Ljava/util/List;
    .restart local v4    # "$i$a$-let-InstanceApi$index$6\\7\\473\\0":I
    :cond_1b5
    new-instance v2, Lorg/luaj/vm2/LuaError;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->fullName()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " is not a valid member of "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, " \""

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, "\""

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v2

    .line 475
    .end local v1    # "owners\\7":Ljava/util/List;
    .end local v4    # "$i$a$-let-InstanceApi$index$6\\7\\473\\0":I
    :cond_1ea
    :goto_1ea
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->warnedMissing:Ljava/util/HashSet;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_233

    sget-object v1, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " is not a known member of "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " (treated as nil)"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->warn(Ljava/lang/String;)V

    .line 476
    :cond_233
    sget-object v1, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v2, "NIL"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v1

    nop

    :sswitch_data_23c
    .sparse-switch
        -0x71f00b36 -> :sswitch_85
        0x24eeab -> :sswitch_6f
        0x76db3c03 -> :sswitch_59
    .end sparse-switch
.end method

.method public final modelCall(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 16
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "a"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 889
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const-string v1, " expected, got "

    const-string v2, "__scale"

    const-string v3, "arg(...)"

    const/4 v4, 0x2

    const/4 v5, 0x0

    sparse-switch v0, :sswitch_data_2ea

    goto/16 :goto_2c3

    :sswitch_20
    const-string v0, "GetScale"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 915
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_37

    move-object v5, v0

    check-cast v5, Ljava/lang/Number;

    :cond_37
    if-eqz v5, :cond_3e

    invoke-virtual {v5}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    goto :goto_40

    :cond_3e
    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    :goto_40
    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 889
    :sswitch_4d
    const-string v0, "GetPivot"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2c4

    goto/16 :goto_2c3

    :sswitch_57
    const-string v0, "SetPrimaryPartCFrame"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_d0

    goto/16 :goto_2c3

    :sswitch_61
    const-string v0, "GetBoundingBox"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 900
    sget-object v0, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->boundsOf(Ljava/util/List;)Lkotlin/Pair;

    move-result-object v0

    if-nez v0, :cond_85

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    .line 901
    .local v0, "b":Lkotlin/Pair;
    :cond_85
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/high16 v4, 0x40000000    # 2.0f

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->at(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    invoke-static {v1, v2}, Lorg/luaj/vm2/LuaValue;->varargsOf(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    .line 899
    .end local v0    # "b":Lkotlin/Pair;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    goto/16 :goto_2e9

    .line 889
    :sswitch_c8
    const-string v0, "PivotTo"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 891
    :cond_d0
    invoke-virtual {p3, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 1087
    .local v3, "$i$f$ud\\1\\891":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_e5

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_e6

    :cond_e5
    move-object v4, v5

    :goto_e6
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_eb

    move-object v5, v4

    :cond_eb
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_fb

    .line 891
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\891":I
    invoke-virtual {p0, p1, v5}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 1087
    .restart local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\1":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\1\\891":I
    :cond_fb
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 889
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\891":I
    :sswitch_11c
    const-string v0, "TranslateBy"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 898
    invoke-virtual {p3, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\3":Ljava/lang/String;
    const/4 v3, 0x0

    .line 1089
    .local v3, "$i$f$ud\\3\\898":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_139

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_13a

    :cond_139
    move-object v4, v5

    :goto_13a
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_13f

    move-object v5, v4

    :cond_13f
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_158

    .line 898
    .end local v0    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\3":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\3\\898":I
    nop

    .local v5, "d":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {v0, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .end local v5    # "d":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 1089
    .restart local v0    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\3":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\3\\898":I
    :cond_158
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 889
    .end local v0    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\3":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\3\\898":I
    :sswitch_179
    const-string v0, "ScaleTo"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 905
    invoke-virtual {p3, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v0

    .local v0, "s":F
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    instance-of v3, v1, Ljava/lang/Number;

    if-eqz v3, :cond_19b

    move-object v5, v1

    check-cast v5, Ljava/lang/Number;

    :cond_19b
    if-eqz v5, :cond_1a2

    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    move-result v1

    goto :goto_1a4

    :cond_1a2
    const/high16 v1, 0x3f800000    # 1.0f

    .line 906
    .local v1, "old":F
    :goto_1a4
    div-float v3, v0, v1

    .local v3, "f":F
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    .line 907
    .local v4, "piv":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1b2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1f5

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 908
    .local v6, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v7, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v7, v6}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v7

    .line 909
    .local v7, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    sget-object v8, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v9, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v9, v6}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v9, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v8, v6, v9}, Lcom/exampletest/mobilestudiotest/model/PartData;->setSize(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    .line 910
    sget-object v8, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-virtual {v10, v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v10, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v7, v9}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v9

    invoke-virtual {v8, v6, v9}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    .end local v6    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v7    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    goto :goto_1b2

    .line 912
    :cond_1f5
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v5

    check-cast v5, Ljava/util/Map;

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v6

    invoke-interface {v5, v2, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 913
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 904
    .end local v0    # "s":F
    .end local v1    # "old":F
    .end local v3    # "f":F
    .end local v4    # "piv":Lcom/exampletest/mobilestudiotest/model/CFrame;
    nop

    .line 905
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 889
    :sswitch_20c
    const-string v0, "GetModelCFrame"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2c4

    goto/16 :goto_2c3

    :sswitch_216
    const-string v0, "GetModelSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_228

    goto/16 :goto_2c3

    :sswitch_220
    const-string v0, "GetExtentsSize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 903
    :cond_228
    sget-object v0, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->boundsOf(Ljava/util/List;)Lkotlin/Pair;

    move-result-object v0

    if-nez v0, :cond_244

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    .local v0, "b":Lkotlin/Pair;
    :cond_244
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "b":Lkotlin/Pair;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_2e9

    .line 889
    :sswitch_25e
    const-string v0, "MoveTo"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c3

    .line 893
    invoke-virtual {p3, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 1088
    .local v3, "$i$f$ud\\2\\893":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_27b

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_27c

    :cond_27b
    move-object v4, v5

    :goto_27c
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_281

    move-object v5, v4

    :cond_281
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_29a

    .line 893
    .end local v0    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\893":I
    nop

    .line 894
    .local v5, "target":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    .line 895
    .local v0, "piv":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {v0, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {p0, p1, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    .line 896
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 892
    .end local v0    # "piv":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v5    # "target":Lcom/exampletest/mobilestudiotest/model/Vector3;
    nop

    .line 893
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_2e9

    .line 1088
    .local v0, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\2\\893":I
    :cond_29a
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v4, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 889
    .end local v0    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\893":I
    :sswitch_2bb
    const-string v0, "GetPrimaryPartCFrame"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2c4

    :cond_2c3
    :goto_2c3
    goto :goto_2e0

    .line 890
    :cond_2c4
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "BasePart"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2d5

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    goto :goto_2d9

    :cond_2d5
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    :goto_2d9
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_2e9

    .line 916
    :goto_2e0
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NONE"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    .line 889
    :goto_2e9
    return-object v0

    :sswitch_data_2ea
    .sparse-switch
        -0x7a9aa857 -> :sswitch_2bb
        -0x76477db4 -> :sswitch_25e
        -0x6f06deec -> :sswitch_220
        -0x6e9fa7cc -> :sswitch_216
        -0x629349c3 -> :sswitch_20c
        -0x2ae17ebb -> :sswitch_179
        -0xa4c79db -> :sswitch_11c
        0x41d2663d -> :sswitch_c8
        0x52e38071 -> :sswitch_61
        0x60fb641d -> :sswitch_57
        0x78d3d6ac -> :sswitch_4d
        0x78fb13b4 -> :sswitch_20
    .end sparse-switch
.end method

.method public final modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;
    .registers 6
    .param p1, "m"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "m"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 531
    const-string v0, "PrimaryPart"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    const/4 v2, 0x0

    if-eqz v1, :cond_13

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_14

    :cond_13
    move-object v0, v2

    :goto_14
    if-eqz v0, :cond_1e

    .line 1017
    .local v0, "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v1, 0x0

    .line 531
    .local v1, "$i$a$-let-InstanceApi$modelPivot$1\\1\\531\\0":I
    sget-object v2, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    return-object v2

    .line 532
    .end local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v1    # "$i$a$-let-InstanceApi$modelPivot$1\\1\\531\\0":I
    :cond_1e
    const-string v0, "WorldPivotData"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    if-eqz v1, :cond_2b

    move-object v2, v0

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    :cond_2b
    if-eqz v2, :cond_35

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;->getCframe()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    if-eqz v0, :cond_35

    .line 1017
    .local v0, "it\\2":Lcom/exampletest/mobilestudiotest/model/CFrame;
    const/4 v1, 0x0

    .line 532
    .local v1, "$i$a$-let-InstanceApi$modelPivot$2\\2\\532\\0":I
    return-object v0

    .line 533
    .end local v0    # "it\\2":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v1    # "$i$a$-let-InstanceApi$modelPivot$2\\2\\532\\0":I
    :cond_35
    sget-object v0, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->boundsOf(Ljava/util/List;)Lkotlin/Pair;

    move-result-object v0

    if-nez v0, :cond_48

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    return-object v0

    .line 534
    .local v0, "b":Lkotlin/Pair;
    :cond_48
    sget-object v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    const/high16 v3, 0x40000000    # 2.0f

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->at(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    return-object v1
.end method

.method public final newIndex(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V
    .registers 13
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "key"    # Ljava/lang/String;
    .param p3, "v"    # Lorg/luaj/vm2/LuaValue;

    const-string v1, ". "

    const-string v2, "Unable to assign property "

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "v"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 481
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->contentAlias(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v3, ""

    if-eqz v0, :cond_3e

    .line 1017
    .local v0, "alias\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 481
    .local v4, "$i$a$-let-InstanceApi$newIndex$1\\1\\481\\0":I
    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->isstring()Z

    move-result v5

    if-nez v5, :cond_29

    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->isnil()Z

    move-result v5

    if-nez v5, :cond_29

    .end local v0    # "alias\\1":Ljava/lang/String;
    .end local v4    # "$i$a$-let-InstanceApi$newIndex$1\\1\\481\\0":I
    goto :goto_3e

    .restart local v0    # "alias\\1":Ljava/lang/String;
    .restart local v4    # "$i$a$-let-InstanceApi$newIndex$1\\1\\481\\0":I
    :cond_29
    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->isnil()Z

    move-result v1

    if-eqz v1, :cond_36

    invoke-static {v3}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_37

    :cond_36
    move-object v1, p3

    :goto_37
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {p0, p1, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->newIndex(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    return-void

    .line 482
    .end local v0    # "alias\\1":Ljava/lang/String;
    .end local v4    # "$i$a$-let-InstanceApi$newIndex$1\\1\\481\\0":I
    :cond_3e
    :goto_3e
    const-string v0, "OnServerInvoke"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_16e

    const-string v0, "OnClientInvoke"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_16e

    const-string v0, "OnInvoke"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_16e

    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->isfunction()Z

    move-result v0

    if-eqz v0, :cond_66

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_16e

    .line 486
    :cond_66
    const-string v0, "Source"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_94

    const-string v0, "LuaSourceContainer"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_94

    .line 487
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->isPlay()Z

    move-result v0

    if-nez v0, :cond_8c

    .line 488
    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v2, "Source"

    const/4 v4, 0x0

    move-object v1, p1

    .end local p1    # "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v1, "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-static/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .end local v1    # "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local p1    # "inst":Lcom/exampletest/mobilestudiotest/model/Instance;
    return-void

    .line 487
    :cond_8c
    new-instance v0, Lorg/luaj/vm2/LuaError;

    const-string v1, "The current thread cannot write \'Source\' (lacking capability PluginOrOpenCloud)"

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 490
    :cond_94
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->typeHint(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v4

    .line 491
    .local v4, "type":Ljava/lang/Integer;
    nop

    .line 492
    :try_start_99
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v5, p1, p2}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, p3, v4, p1, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fromLua(Lorg/luaj/vm2/LuaValue;Ljava/lang/Integer;Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0
    :try_end_a5
    .catch Lorg/luaj/vm2/LuaError; {:try_start_99 .. :try_end_a5} :catch_d7

    .line 491
    move-object v3, v0

    .line 501
    .local v3, "kv":Ljava/lang/Object;
    nop

    .line 502
    :try_start_a7
    invoke-virtual {p0, p1, p2, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_aa
    .catch Ljava/lang/ClassCastException; {:try_start_a7 .. :try_end_aa} :catch_ab

    .line 506
    return-void

    .line 503
    :catch_ab
    move-exception v0

    .line 504
    .local v0, "e":Ljava/lang/ClassCastException;
    new-instance v5, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, p3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " is not the correct type"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v5, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v5

    .line 493
    .end local v0    # "e":Ljava/lang/ClassCastException;
    .end local v3    # "kv":Ljava/lang/Object;
    :catch_d7
    move-exception v0

    .line 494
    .local v0, "e":Lorg/luaj/vm2/LuaError;
    nop

    .line 495
    if-eqz v4, :cond_e2

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v6, 0x4

    if-eq v5, v6, :cond_125

    :cond_e2
    if-eqz v4, :cond_eb

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v6, 0x5

    if-eq v5, v6, :cond_125

    :cond_eb
    if-eqz v4, :cond_f4

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v6, 0x3

    if-eq v5, v6, :cond_125

    :cond_f4
    if-eqz v4, :cond_fe

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/16 v6, 0x1b

    if-eq v5, v6, :cond_125

    .line 496
    :cond_fe
    if-eqz v4, :cond_10a

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v6, 0x2

    if-ne v5, v6, :cond_10a

    const-string v5, "boolean"

    goto :goto_127

    :cond_10a
    if-eqz v4, :cond_116

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v6, 0x1

    if-ne v5, v6, :cond_116

    const-string v5, "string"

    goto :goto_127

    :cond_116
    if-eqz v4, :cond_123

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/16 v6, 0x12

    if-ne v5, v6, :cond_123

    const-string v5, "EnumItem"

    goto :goto_127

    .line 497
    :cond_123
    const/4 v5, 0x0

    goto :goto_127

    .line 495
    :cond_125
    const-string v5, "number"

    .line 494
    :goto_127
    nop

    .line 499
    .local v5, "want":Ljava/lang/String;
    new-instance v6, Lorg/luaj/vm2/LuaError;

    if-nez v5, :cond_134

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaError;->getMessage()Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_151

    move-object v3, v7

    goto :goto_151

    :cond_134
    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v3, p3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v3

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " expected, got "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :cond_151
    :goto_151
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v6, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .line 483
    .end local v0    # "e":Lorg/luaj/vm2/LuaError;
    .end local v4    # "type":Ljava/lang/Integer;
    .end local v5    # "want":Ljava/lang/String;
    :cond_16e
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getCallbacks()Ljava/util/IdentityHashMap;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    .local v0, "$this$getOrPut\\2":Ljava/util/Map;
    move-object v1, p1

    .local v1, "key\\2":Ljava/lang/Object;
    const/4 v2, 0x0

    .line 1028
    .local v2, "$i$f$getOrPut\\2\\483":I
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .line 1029
    .local v3, "value\\2":Ljava/lang/Object;
    if-nez v3, :cond_18a

    .line 1030
    const/4 v4, 0x0

    .line 483
    .local v4, "$i$a$-getOrPut-InstanceApi$newIndex$2\\3\\1030\\0":I
    new-instance v5, Ljava/util/HashMap;

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    .line 1030
    .end local v4    # "$i$a$-getOrPut-InstanceApi$newIndex$2\\3\\1030\\0":I
    nop

    .line 1031
    .local v5, "answer\\2":Ljava/lang/Object;
    invoke-interface {v0, v1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1032
    nop

    .end local v5    # "answer\\2":Ljava/lang/Object;
    goto :goto_18b

    .line 1034
    :cond_18a
    move-object v5, v3

    .line 1029
    :goto_18b
    nop

    .line 483
    .end local v0    # "$this$getOrPut\\2":Ljava/util/Map;
    .end local v1    # "key\\2":Ljava/lang/Object;
    .end local v2    # "$i$f$getOrPut\\2\\483":I
    .end local v3    # "value\\2":Ljava/lang/Object;
    check-cast v5, Ljava/util/Map;

    invoke-interface {v5, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 484
    return-void
.end method

.method public final partCall(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "inst"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "a"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 921
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v1, 0x3f333333    # 0.7f

    const-string v2, "TRUE"

    const/4 v3, 0x0

    sparse-switch v0, :sswitch_data_1de

    goto/16 :goto_1cb

    :sswitch_1e
    const-string v0, "GetVelocityAtPosition"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 935
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v1

    if-eqz v1, :cond_37

    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->velocityOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    if-eqz v1, :cond_37

    goto :goto_3d

    :cond_37
    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    :goto_3d
    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1dd

    .line 921
    :sswitch_45
    const-string v0, "GetPivot"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_138

    goto/16 :goto_1cb

    :sswitch_4f
    const-string v0, "ApplyImpulse"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 924
    const/4 v0, 0x2

    invoke-virtual {p3, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v2, "arg(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 1090
    .local v4, "$i$f$ud\\1\\924":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    if-eqz v5, :cond_6f

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_70

    :cond_6f
    move-object v5, v3

    :goto_70
    instance-of v6, v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_75

    move-object v3, v5

    :cond_75
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v3, :cond_c0

    .line 924
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\924":I
    nop

    .local v3, "imp":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "s":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    mul-float/2addr v2, v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v4

    mul-float/2addr v2, v4

    mul-float/2addr v2, v1

    const v1, 0x3c23d70a    # 0.01f

    invoke-static {v2, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v1

    .line 925
    .local v1, "mass":F
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v2

    if-eqz v2, :cond_b6

    .line 1017
    .local v2, "it\\2":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    const/4 v4, 0x0

    .line 925
    .local v4, "$i$a$-let-InstanceApi$partCall$1\\2\\925\\0":I
    invoke-virtual {v2, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->velocityOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    if-nez v5, :cond_ab

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    :cond_ab
    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v2, p1, v5}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->setVelocity(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    .line 926
    .end local v2    # "it\\2":Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .end local v4    # "$i$a$-let-InstanceApi$partCall$1\\2\\925\\0":I
    :cond_b6
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 923
    .end local v0    # "s":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v1    # "mass":F
    .end local v3    # "imp":Lcom/exampletest/mobilestudiotest/model/Vector3;
    nop

    .line 925
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1dd

    .line 1090
    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    .local v4, "$i$f$ud\\1\\924":I
    :cond_c0
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 921
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\924":I
    :sswitch_e3
    const-string v0, "IsGrounded"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 934
    const-string v0, "Anchored"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1dd

    .line 921
    :sswitch_107
    const-string v0, "GetMass"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 922
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/model/PartData;->size(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "s":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v3

    mul-float/2addr v2, v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    mul-float/2addr v2, v3

    mul-float/2addr v2, v1

    float-to-double v1, v2

    invoke-static {v1, v2}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    .end local v0    # "s":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1dd

    .line 921
    :sswitch_130
    const-string v0, "PivotTo"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 937
    :cond_138
    invoke-virtual {p0, p1, p2, p3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelCall(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    goto/16 :goto_1dd

    .line 921
    :sswitch_13e
    const-string v0, "GetConnectedParts"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 929
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1dd

    .line 921
    :sswitch_152
    const-string v0, "GetNetworkOwner"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 932
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v1

    if-eqz v1, :cond_168

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->getPlayer()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v3

    :cond_168
    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1dd

    .line 921
    :sswitch_170
    const-string v0, "CanSetNetworkOwnership"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 933
    sget-object v0, Lorg/luaj/vm2/LuaValue;->TRUE:Lorg/luaj/vm2/LuaBoolean;

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_1dd

    .line 921
    :sswitch_180
    const-string v0, "GetRootPart"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 931
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_1dd

    .line 921
    :sswitch_191
    const-string v0, "GetTouchingParts"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 928
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_1a8

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->touchingParts(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_1a8

    goto :goto_1ac

    :cond_1a8
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    :goto_1ac
    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_1dd

    .line 921
    :sswitch_1b3
    const-string v0, "GetJoints"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1cb

    .line 930
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_1dd

    .line 921
    :sswitch_1c3
    const-string v0, "Resize"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1cc

    :cond_1cb
    :goto_1cb
    goto :goto_1d4

    .line 936
    :cond_1cc
    sget-object v0, Lorg/luaj/vm2/LuaValue;->TRUE:Lorg/luaj/vm2/LuaBoolean;

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_1dd

    .line 938
    :goto_1d4
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NONE"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    .line 921
    :goto_1dd
    return-object v0

    :sswitch_data_1de
    .sparse-switch
        -0x6e4d772c -> :sswitch_1c3
        -0x68477401 -> :sswitch_1b3
        -0x401b9f39 -> :sswitch_191
        -0x2ab002b5 -> :sswitch_180
        -0x1834ac6d -> :sswitch_170
        0x237c1f7b -> :sswitch_152
        0x3d12c22d -> :sswitch_13e
        0x41d2663d -> :sswitch_130
        0x5ebb074a -> :sswitch_107
        0x65b723d0 -> :sswitch_e3
        0x749ff5c7 -> :sswitch_4f
        0x78d3d6ac -> :sswitch_45
        0x7d5c410f -> :sswitch_1e
    .end sparse-switch
.end method

.method public final partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;
    .registers 7
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ")",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation

    const-string v0, "i"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 511
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 512
    .local v0, "out":Ljava/util/ArrayList;
    const-string v1, "BasePart"

    invoke-virtual {p1, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_15

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 513
    :cond_15
    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p1, v3, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->descendants$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/util/List;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1f
    :goto_1f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_35

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v3, "d":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-virtual {v3, v1}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1f

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1f

    .line 514
    .end local v3    # "d":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_35
    move-object v1, v0

    check-cast v1, Ljava/util/List;

    return-object v1
.end method

.method public final pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V
    .registers 12
    .param p1, "target"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "cf"    # Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v0, "target"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cf"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 538
    const-string v0, "BasePart"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18

    .line 539
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    .line 540
    return-void

    .line 542
    :cond_18
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->modelPivot(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    .line 543
    .local v0, "old":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->inverse()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {p2, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    .line 544
    .local v1, "delta":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->partsIn(Lcom/exampletest/mobilestudiotest/model/Instance;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_48

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v3, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v4, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v5

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v5

    invoke-virtual {v4, v3, v5}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    .end local v3    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    goto :goto_2c

    .line 545
    :cond_48
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v2

    const-string v3, "WorldPivotData"

    invoke-virtual {v2, v3}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6b

    const-string v2, "PrimaryPart"

    invoke-virtual {p1, v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    if-nez v2, :cond_6b

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;

    invoke-direct {v5, p2}, Lcom/exampletest/mobilestudiotest/model/OptionalCFrame;-><init>(Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v4, "WorldPivotData"

    const/4 v6, 0x0

    move-object v3, p1

    .end local p1    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v3, "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    invoke-static/range {v3 .. v8}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    goto :goto_6c

    .end local v3    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local p1    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_6b
    move-object v3, p1

    .line 546
    .end local p1    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v3    # "target":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_6c
    return-void
.end method

.method public final setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V
    .registers 22
    .param p1, "inst"    # Lcom/exampletest/mobilestudiotest/model/Instance;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "value"    # Ljava/lang/Object;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v8, p2

    move-object/from16 v9, p3

    const-string v0, "inst"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 342
    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v11, 0x1

    .line 350
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    .line 342
    sparse-switch v0, :sswitch_data_488

    goto :goto_60

    :sswitch_21
    const-string v0, "ClassName"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_60

    .line 351
    new-instance v0, Lorg/luaj/vm2/LuaError;

    const-string v3, "Unable to assign property ClassName. Property is read only"

    invoke-direct {v0, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 342
    :sswitch_31
    const-string v0, "Archivable"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_60

    .line 350
    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->setArchivable(Z)V

    return-void

    .line 342
    :sswitch_41
    const-string v0, "Name"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_60

    .line 343
    if-eqz v9, :cond_52

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_52

    goto :goto_54

    :cond_52
    const-string v0, "nil"

    :goto_54
    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->setName(Ljava/lang/String;)V

    return-void

    .line 342
    :sswitch_58
    const-string v0, "Parent"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_62

    :cond_60
    :goto_60
    goto/16 :goto_dc

    .line 345
    :cond_62
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getDestroyed()Z

    move-result v0

    const-string v4, "The Parent property of "

    if-eqz v0, :cond_9e

    new-instance v0, Lorg/luaj/vm2/LuaError;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v5

    instance-of v6, v9, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v6, :cond_78

    move-object v6, v9

    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    goto :goto_79

    :cond_78
    move-object v6, v3

    :goto_79
    if-eqz v6, :cond_7f

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v3

    :cond_7f
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " is locked, current parent: NULL, new parent "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 346
    :cond_9e
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->isService()Z

    move-result v0

    if-nez v0, :cond_bb

    instance-of v0, v2, Lcom/exampletest/mobilestudiotest/model/DataModel;

    if-nez v0, :cond_bb

    .line 347
    :try_start_a8
    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Instance;

    const/4 v4, 0x2

    invoke-static {v2, v0, v10, v4, v3}, Lcom/exampletest/mobilestudiotest/model/Instance;->setParent$default(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;IILjava/lang/Object;)V
    :try_end_af
    .catch Ljava/lang/IllegalArgumentException; {:try_start_a8 .. :try_end_af} :catch_b0

    .line 348
    return-void

    .line 347
    :catch_b0
    move-exception v0

    .local v0, "e":Ljava/lang/IllegalArgumentException;
    new-instance v3, Lorg/luaj/vm2/LuaError;

    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .line 346
    .end local v0    # "e":Ljava/lang/IllegalArgumentException;
    :cond_bb
    new-instance v0, Lorg/luaj/vm2/LuaError;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getName()Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " is locked"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 353
    :goto_dc
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isPart(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    const-string v4, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.CFrame"

    const-string v5, "CFrame"

    if-eqz v0, :cond_241

    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v6, 0x3c8efa35

    const-string v7, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Vector3"

    sparse-switch v0, :sswitch_data_49a

    goto/16 :goto_241

    :sswitch_f4
    invoke-virtual {v8, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 367
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-static {v9, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v3, v9

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0, v2, v3}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 353
    :sswitch_106
    const-string v0, "RotVelocity"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_178

    goto/16 :goto_241

    :sswitch_110
    const-string v0, "AssemblyLinearVelocity"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_22f

    goto/16 :goto_241

    :sswitch_11a
    const-string v0, "Position"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 354
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v3, v2}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v4, v9

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 353
    :sswitch_138
    const-string v0, "Orientation"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 355
    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v6

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v7

    invoke-virtual {v4, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromOrientation(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v5, v2}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 353
    .end local v0    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :sswitch_170
    const-string v0, "AssemblyAngularVelocity"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 366
    :cond_178
    return-void

    .line 353
    :sswitch_179
    const-string v0, "Color"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 358
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    const-string v3, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Color3"

    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v3, v9

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v0, v2, v3}, Lcom/exampletest/mobilestudiotest/model/PartData;->setColor(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Color3;)V

    return-void

    .line 353
    :sswitch_18f
    const-string v0, "Rotation"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 356
    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .restart local v0    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v6

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v7

    invoke-virtual {v4, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->angles(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v5, v2}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->withPosition(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->setCFrame(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 353
    .end local v0    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :sswitch_1c7
    const-string v0, "Size"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 357
    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v0, "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    const v6, 0x3a83126f    # 0.001f

    invoke-static {v5, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v5

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v7

    invoke-static {v7, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v7

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v10

    invoke-static {v10, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v6

    invoke-direct {v4, v5, v7, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v3, v2, v4}, Lcom/exampletest/mobilestudiotest/model/PartData;->setSize(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    return-void

    .line 353
    .end local v0    # "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :sswitch_1fb
    const-string v0, "BrickColor"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_241

    .line 360
    const-string v3, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.BrickColorV"

    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v4, v9

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    .line 361
    .local v4, "b":Lcom/exampletest/mobilestudiotest/model/BrickColorV;
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v5

    invoke-virtual {v3, v2, v5}, Lcom/exampletest/mobilestudiotest/model/PartData;->setColor(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Color3;)V

    .line 362
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_226

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "BrickColor"

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 363
    :cond_226
    return-void

    .line 353
    .end local v4    # "b":Lcom/exampletest/mobilestudiotest/model/BrickColorV;
    :sswitch_227
    const-string v0, "Velocity"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_241

    .line 365
    :cond_22f
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_240

    invoke-static {v9, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v3, v9

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0, v2, v3}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->setVelocity(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    :cond_240
    return-void

    .line 369
    :cond_241
    :goto_241
    const-string v0, "Model"

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_25b

    const-string v0, "WorldPivot"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_25b

    invoke-static {v9, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v1, v2, v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->pivotTo(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    return-void

    .line 370
    :cond_25b
    const-string v0, "BaseScript"

    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_27d

    const-string v0, "Enabled"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_27d

    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    xor-int/2addr v0, v11

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "Disabled"

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    return-void

    .line 371
    :cond_27d
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v4, "Humanoid"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    if-eqz v0, :cond_30d

    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_4c8

    goto/16 :goto_30d

    :sswitch_293
    const-string v0, "Jump"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_30d

    .line 377
    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2ac

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-eqz v0, :cond_2ac

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->jump(Lcom/exampletest/mobilestudiotest/model/Instance;)V

    :cond_2ac
    return-void

    .line 371
    :sswitch_2ad
    const-string v0, "Sit"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_30d

    .line 378
    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "Sit"

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    return-void

    .line 371
    :sswitch_2c6
    const-string v0, "Health"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_30d

    .line 373
    const-string v5, "MaxHealth"

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Ljava/lang/Number;

    if-eqz v6, :cond_2db

    move-object v3, v5

    check-cast v3, Ljava/lang/Number;

    :cond_2db
    if-eqz v3, :cond_2e2

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v3

    goto :goto_2e4

    :cond_2e2
    const/high16 v3, 0x42c80000    # 100.0f

    :goto_2e4
    move v10, v3

    .line 374
    .local v10, "max":F
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getProps()Ljava/util/LinkedHashMap;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2f1

    const-string v0, "Health_XML"

    :cond_2f1
    move-object v3, v0

    const-string v0, "null cannot be cast to non-null type kotlin.Number"

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v0, v9

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    invoke-static {v0, v4, v10}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 375
    return-void

    .line 380
    .end local v10    # "max":F
    :cond_30d
    :goto_30d
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "Camera"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_34d

    invoke-static {v8, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_34d

    .line 381
    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "CFrame"

    const/4 v5, 0x0

    move-object/from16 v2, p1

    move-object v4, v9

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 383
    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getPlay()Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-result-object v0

    if-nez v0, :cond_34c

    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->isEditCamera(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v0

    if-eqz v0, :cond_34c

    instance-of v0, v9, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v0, :cond_34c

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->getStudio()Lcom/exampletest/mobilestudiotest/core/Studio;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/core/Studio;->getCamera()Lcom/exampletest/mobilestudiotest/render/FlyCamera;

    move-result-object v0

    move-object v2, v9

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/render/FlyCamera;->setFromCFrame(Lcom/exampletest/mobilestudiotest/model/CFrame;)V

    .line 384
    :cond_34c
    return-void

    .line 386
    :cond_34d
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "Lighting"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3b5

    const-string v0, "TimeOfDay"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3b5

    .line 387
    invoke-static {v9}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Ljava/lang/CharSequence;

    new-array v13, v11, [Ljava/lang/String;

    const-string v0, ":"

    aput-object v0, v13, v10

    const/16 v16, 0x6

    const/16 v17, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static/range {v12 .. v17}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .local v0, "p":Ljava/util/List;
    invoke-static {v0, v10}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_38b

    invoke-static {v2}, Lkotlin/text/StringsKt;->toFloatOrNull(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v2

    if-eqz v2, :cond_38b

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    goto :goto_38d

    :cond_38b
    const/high16 v2, 0x41600000    # 14.0f

    :goto_38d
    move v10, v2

    .local v10, "h":F
    invoke-static {v0, v11}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_3a0

    invoke-static {v2}, Lkotlin/text/StringsKt;->toFloatOrNull(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v2

    if-eqz v2, :cond_3a0

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v4

    :cond_3a0
    move v11, v4

    .line 388
    .local v11, "m":F
    const/high16 v2, 0x42700000    # 60.0f

    div-float v2, v11, v2

    add-float/2addr v2, v10

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "ClockTime"

    const/4 v5, 0x0

    move-object/from16 v2, p1

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    return-void

    .line 390
    .end local v0    # "p":Ljava/util/List;
    .end local v10    # "h":F
    .end local v11    # "m":F
    :cond_3b5
    invoke-virtual/range {p1 .. p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "Sound"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_407

    const-string v0, "Playing"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_407

    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, "Playing"

    const/4 v5, 0x0

    move-object/from16 v2, p1

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_406

    iget-object v0, v1, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    new-array v3, v11, [Lorg/luaj/vm2/LuaValue;

    const-string v4, "SoundId"

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_3f4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_3f4

    goto :goto_3f6

    :cond_3f4
    const-string v4, ""

    :goto_3f6
    invoke-static {v4}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v4

    const-string v5, "valueOf(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    aput-object v4, v3, v10

    const-string v4, "Played"

    invoke-virtual {v0, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->fire(Ljava/lang/Object;Ljava/lang/String;[Lorg/luaj/vm2/LuaValue;)V

    :cond_406
    return-void

    :cond_407
    move-object/from16 v2, p1

    .line 391
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/PropNames;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PropNames;

    invoke-virtual {v0, v2, v8}, Lcom/exampletest/mobilestudiotest/model/PropNames;->resolve(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 392
    .local v3, "key":Ljava/lang/String;
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Instance;->getPropTypes()Ljava/util/HashMap;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    .line 393
    .local v0, "type":Ljava/lang/Integer;
    if-eqz v0, :cond_432

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v5, 0x4

    if-ne v4, v5, :cond_432

    instance-of v4, v9, Ljava/lang/Number;

    if-eqz v4, :cond_432

    move-object v4, v9

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    goto :goto_47f

    .line 394
    :cond_432
    if-eqz v0, :cond_44b

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v5, 0x5

    if-ne v4, v5, :cond_44b

    instance-of v4, v9, Ljava/lang/Number;

    if-eqz v4, :cond_44b

    move-object v4, v9

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    goto :goto_47f

    .line 395
    :cond_44b
    if-eqz v0, :cond_464

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v5, 0x3

    if-ne v4, v5, :cond_464

    instance-of v4, v9, Ljava/lang/Number;

    if-eqz v4, :cond_464

    move-object v4, v9

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    goto :goto_47f

    .line 396
    :cond_464
    if-eqz v0, :cond_47e

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/16 v5, 0x1b

    if-ne v4, v5, :cond_47e

    instance-of v4, v9, Ljava/lang/Number;

    if-eqz v4, :cond_47e

    move-object v4, v9

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    goto :goto_47f

    .line 397
    :cond_47e
    move-object v4, v9

    .line 393
    :goto_47f
    nop

    .line 398
    .local v4, "v":Ljava/lang/Object;
    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lcom/exampletest/mobilestudiotest/model/Instance;->set$default(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;ZILjava/lang/Object;)V

    .line 399
    return-void

    nop

    :sswitch_data_488
    .sparse-switch
        -0x71f00b36 -> :sswitch_58
        0x24eeab -> :sswitch_41
        0x7094d7fd -> :sswitch_31
        0x76db3c03 -> :sswitch_21
    .end sparse-switch

    :sswitch_data_49a
    .sparse-switch
        -0x7cef5f03 -> :sswitch_227
        -0x33b84c3e -> :sswitch_1fb
        0x275421 -> :sswitch_1c7
        0x173739e -> :sswitch_18f
        0x3e43f43 -> :sswitch_179
        0x9fe75f9 -> :sswitch_170
        0xd9c9db0 -> :sswitch_138
        0x306cfd49 -> :sswitch_11a
        0x3f7ca6c8 -> :sswitch_110
        0x4f2c3bb4 -> :sswitch_106
        0x76646aea -> :sswitch_f4
    .end sparse-switch

    :sswitch_data_4c8
    .sparse-switch
        -0x7f661184 -> :sswitch_2c6
        0x144be -> :sswitch_2ad
        0x23684e -> :sswitch_293
    .end sparse-switch
.end method

.method public final signal(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 6
    .param p1, "owner"    # Ljava/lang/Object;
    .param p2, "name"    # Ljava/lang/String;

    const-string v0, "owner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    new-instance v0, Lorg/luaj/vm2/LuaUserdata;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    invoke-direct {v1, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/SignalRef;-><init>(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->signalMeta:Lorg/luaj/vm2/LuaTable;

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-direct {v0, v1, v2}, Lorg/luaj/vm2/LuaUserdata;-><init>(Ljava/lang/Object;Lorg/luaj/vm2/LuaValue;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method public final workspaceCall(Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 32
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-string v3, "name"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "a"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 794
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v3

    const-string v8, "Blockcast"

    const-string v9, "FindPartOnRayWithWhitelist"

    const-string v10, "FindPartsInRegion3WithWhiteList"

    const-string v11, "NONE"

    const-string v12, "valueOf(...)"

    const/4 v13, 0x4

    const-string v14, " expected, got "

    const-wide/high16 v16, 0x4000000000000000L    # 2.0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/16 v18, 0x1

    const/16 v19, 0x0

    const-string v15, "arg(...)"

    const/4 v6, 0x0

    sparse-switch v3, :sswitch_data_ab4

    goto/16 :goto_94c

    :sswitch_31
    const-string v3, "GetServerTimeNow"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 858
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    long-to-double v3, v3

    const-wide v5, 0x408f400000000000L    # 1000.0

    div-double/2addr v3, v5

    invoke-static {v3, v4}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_4f
    const-string v3, "GetRealPhysicsFPS"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 859
    const/16 v3, 0x3c

    invoke-static {v3}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_64
    const-string v3, "FindPartOnRayWithIgnoreList"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_80e

    goto/16 :goto_94c

    :sswitch_6e
    const-string v3, "GetPartBoundsInRadius"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 824
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v3, "$this$ud\\14":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\14":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1066
    .local v7, "$i$f$ud\\14\\824":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_8b

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_8c

    :cond_8b
    move-object v8, v6

    :goto_8c
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_91

    move-object v6, v8

    :cond_91
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_12c

    .line 824
    .end local v3    # "$this$ud\\14":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\14":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\14\\824":I
    nop

    .local v6, "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v3

    .line 825
    .local v3, "r":F
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v4

    .line 826
    .local v4, "f":Lkotlin/jvm/functions/Function1;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$filter\\15":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1067
    .local v7, "$i$f$filter\\15\\826":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\16":Ljava/util/Collection;
    move-object v9, v5

    .local v9, "$this$filterTo\\16":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1068
    .local v10, "$i$f$filterTo\\16\\1067":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_c0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_11c

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\16":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v13, "p\\17":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v14, 0x0

    .line 827
    .local v14, "$i$a$-filter-InstanceApi$workspaceCall$2\\17\\1068\\0":I
    invoke-interface {v4, v13}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/Boolean;

    invoke-virtual {v15}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v15

    if-nez v15, :cond_e1

    move/from16 v17, v3

    move-object/from16 v16, v4

    move/from16 v3, v19

    goto :goto_112

    .line 828
    :cond_e1
    sget-object v15, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v15, v13}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v15

    invoke-virtual {v15}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v16

    move/from16 v17, v3

    .end local v3    # "r":F
    .local v17, "r":F
    move-object/from16 v3, v16

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v3, "x0\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v15}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 829
    .local v15, "x1\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object/from16 v16, v4

    .end local v4    # "f":Lkotlin/jvm/functions/Function1;
    .local v16, "f":Lkotlin/jvm/functions/Function1;
    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->max(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4, v15}, Lcom/exampletest/mobilestudiotest/model/Vector3;->min(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    .line 830
    .local v4, "cl\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v4, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v20

    cmpg-float v20, v20, v17

    if-gtz v20, :cond_110

    move/from16 v3, v18

    goto :goto_112

    :cond_110
    move/from16 v3, v19

    .line 1068
    .end local v3    # "x0\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v4    # "cl\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v13    # "p\\17":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "$i$a$-filter-InstanceApi$workspaceCall$2\\17\\1068\\0":I
    .end local v15    # "x1\\17":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :goto_112
    if-eqz v3, :cond_117

    invoke-interface {v8, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_117
    move-object/from16 v4, v16

    move/from16 v3, v17

    goto :goto_c0

    .line 1069
    .end local v12    # "element\\16":Ljava/lang/Object;
    .end local v16    # "f":Lkotlin/jvm/functions/Function1;
    .end local v17    # "r":F
    .local v3, "r":F
    .local v4, "f":Lkotlin/jvm/functions/Function1;
    :cond_11c
    move/from16 v17, v3

    move-object/from16 v16, v4

    .end local v3    # "r":F
    .end local v4    # "f":Lkotlin/jvm/functions/Function1;
    .end local v8    # "destination\\16":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\16":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\16\\1067":I
    .restart local v16    # "f":Lkotlin/jvm/functions/Function1;
    .restart local v17    # "r":F
    move-object v3, v8

    check-cast v3, Ljava/util/List;

    .line 1067
    nop

    .line 826
    .end local v5    # "$this$filter\\15":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filter\\15\\826":I
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v3

    .end local v6    # "c":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v16    # "f":Lkotlin/jvm/functions/Function1;
    .end local v17    # "r":F
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1066
    .local v3, "$this$ud\\14":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\14":Ljava/lang/String;
    .local v7, "$i$f$ud\\14\\824":I
    :cond_12c
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\14":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\14":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\14\\824":I
    :sswitch_14d
    const-string v3, "GetPhysicsThrottling"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 880
    const/16 v3, 0x64

    invoke-static {v3}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_162
    const-string v3, "BulkMoveTo"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 863
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v3

    .line 864
    .local v3, "parts":Ljava/util/List;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->checktable()Lorg/luaj/vm2/LuaTable;

    move-result-object v4

    .line 865
    .local v4, "cfs":Lorg/luaj/vm2/LuaTable;
    move-object v5, v3

    check-cast v5, Ljava/lang/Iterable;

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    move/from16 v15, v19

    :cond_186
    :goto_186
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1c4

    move v7, v15

    .local v7, "i":I
    add-int/lit8 v15, v15, 0x1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 866
    .local v8, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    add-int/lit8 v9, v7, 0x1

    invoke-virtual {v4, v9}, Lorg/luaj/vm2/LuaTable;->get(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    const-string v10, "get(...)"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v9, "$this$udOrNull\\27":Lorg/luaj/vm2/LuaValue;
    const/4 v10, 0x0

    .line 1079
    .local v10, "$i$f$udOrNull\\27\\866":I
    invoke-virtual {v9}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v11

    if-eqz v11, :cond_1ac

    invoke-virtual {v9}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v11

    goto :goto_1ad

    :cond_1ac
    move-object v11, v6

    :goto_1ad
    instance-of v12, v11, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v12, :cond_1b2

    move-object v11, v6

    :cond_1b2
    check-cast v11, Lcom/exampletest/mobilestudiotest/model/CFrame;

    .line 866
    .end local v9    # "$this$udOrNull\\27":Lorg/luaj/vm2/LuaValue;
    .end local v10    # "$i$f$udOrNull\\27\\866":I
    if-eqz v11, :cond_186

    .line 867
    .local v11, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    const-string v9, "BasePart"

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/model/Instance;->isA(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_186

    const-string v9, "CFrame"

    invoke-virtual {v0, v8, v9, v11}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->setK(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Ljava/lang/Object;)V

    .end local v11    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    goto :goto_186

    .line 869
    .end local v7    # "i":I
    .end local v8    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_1c4
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    .line 862
    .end local v3    # "parts":Ljava/util/List;
    .end local v4    # "cfs":Lorg/luaj/vm2/LuaTable;
    nop

    .line 866
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_1ce
    const-string v3, "IsRegion3EmptyWithIgnoreList"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    goto/16 :goto_94c

    :sswitch_1d8
    const-string v3, "SetInsertPoint"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7ff

    goto/16 :goto_94c

    :sswitch_1e2
    const-string v3, "CalculateJumpPower"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 881
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-wide v5, 0x4068866666666666L    # 196.2

    invoke-virtual {v3, v5, v6}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v5

    mul-double v5, v5, v16

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-wide v7, 0x401ccccccccccccdL    # 7.2

    invoke-virtual {v3, v7, v8}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v3

    mul-double/2addr v5, v3

    invoke-static {v5, v6}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v3

    invoke-static {v3, v4}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_216
    const-string v3, "Shapecast"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 883
    sget-object v3, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Instance"

    .local v5, "$this$ud\\37":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\37":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1086
    .local v8, "$i$f$ud\\37\\883":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_235

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_236

    :cond_235
    move-object v9, v6

    :goto_236
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v10, :cond_23b

    move-object v9, v6

    :cond_23b
    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v9, :cond_29a

    .line 883
    .end local v5    # "$this$ud\\37":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\37":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\37\\883":I
    invoke-virtual {v3, v9}, Lcom/exampletest/mobilestudiotest/model/PartData;->cframe(Lcom/exampletest/mobilestudiotest/model/Instance;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v4, "$this$ud\\38":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\38":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1086
    .local v7, "$i$f$ud\\38\\883":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_25c

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_25d

    :cond_25c
    move-object v8, v6

    :goto_25d
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_262

    move-object v6, v8

    :cond_262
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_279

    .line 883
    .end local v4    # "$this$ud\\38":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\38":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\38\\883":I
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v4

    invoke-direct {v0, v3, v6, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->raycastResult(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1086
    .restart local v4    # "$this$ud\\38":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "what\\38":Ljava/lang/String;
    .restart local v7    # "$i$f$ud\\38\\883":I
    :cond_279
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v3, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .end local v4    # "$this$ud\\38":Lorg/luaj/vm2/LuaValue;
    .local v5, "$this$ud\\37":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\37":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\37\\883":I
    :cond_29a
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .line 794
    .end local v5    # "$this$ud\\37":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\37":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\37\\883":I
    :sswitch_2bb
    const-string v3, "UnjoinFromOutsiders"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7ff

    goto/16 :goto_94c

    :sswitch_2c5
    const-string v3, "GetPartBoundsInBox"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 818
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "CFrame"

    .local v3, "$this$ud\\8":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\8":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1062
    .local v7, "$i$f$ud\\8\\818":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_2e2

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_2e3

    :cond_2e2
    move-object v8, v6

    :goto_2e3
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v9, :cond_2e8

    move-object v8, v6

    :cond_2e8
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v8, :cond_3ba

    .line 818
    .end local v3    # "$this$ud\\8":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\8":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\8\\818":I
    nop

    .local v8, "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v3, "$this$ud\\9":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\9":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1062
    .local v5, "$i$f$ud\\9\\818":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_302

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_303

    :cond_302
    move-object v7, v6

    :goto_303
    instance-of v9, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_308

    move-object v6, v7

    :cond_308
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_399

    .line 818
    .end local v3    # "$this$ud\\9":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\9":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\9\\818":I
    nop

    .line 819
    .local v6, "size":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v3, v8, v6}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->worldAabb(Lcom/exampletest/mobilestudiotest/model/CFrame;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lkotlin/Pair;

    move-result-object v3

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v23, v4

    check-cast v23, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v23, "b0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v24, v3

    check-cast v24, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 820
    .local v24, "b1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v3

    .line 821
    .local v3, "f":Lkotlin/jvm/functions/Function1;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\10":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1063
    .local v5, "$i$f$filter\\10\\821":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\11":Ljava/util/Collection;
    move-object v9, v4

    .local v9, "$this$filterTo\\11":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1064
    .local v10, "$i$f$filterTo\\11\\1063":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_342
    :goto_342
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_38d

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\11":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v13, "it\\12":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v14, 0x0

    .line 821
    .local v14, "$i$a$-filter-InstanceApi$workspaceCall$1\\12\\1064\\0":I
    invoke-interface {v3, v13}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/Boolean;

    invoke-virtual {v15}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v15

    if-eqz v15, :cond_385

    sget-object v15, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v15, v13}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v15

    .line 1017
    const/16 v16, 0x0

    .local v16, "$i$a$-let-InstanceApi$workspaceCall$1$1\\13\\821\\12":I
    invoke-virtual {v15}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v21, v17

    check-cast v21, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v21, "x0\\13":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v15}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v22, v15

    check-cast v22, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 821
    .local v22, "x1\\13":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v20, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    const/16 v26, 0x10

    const/16 v27, 0x0

    const/16 v25, 0x0

    invoke-static/range {v20 .. v27}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap$default(Lcom/exampletest/mobilestudiotest/engine/Geometry;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FILjava/lang/Object;)Z

    move-result v15

    .end local v16    # "$i$a$-let-InstanceApi$workspaceCall$1$1\\13\\821\\12":I
    .end local v21    # "x0\\13":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v22    # "x1\\13":Lcom/exampletest/mobilestudiotest/model/Vector3;
    if-eqz v15, :cond_385

    move/from16 v13, v18

    goto :goto_387

    :cond_385
    move/from16 v13, v19

    .line 1064
    .end local v13    # "it\\12":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "$i$a$-filter-InstanceApi$workspaceCall$1\\12\\1064\\0":I
    :goto_387
    if-eqz v13, :cond_342

    invoke-interface {v7, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_342

    .line 1065
    .end local v12    # "element\\11":Ljava/lang/Object;
    :cond_38d
    nop

    .end local v7    # "destination\\11":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\11":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\11\\1063":I
    check-cast v7, Ljava/util/List;

    .line 1063
    nop

    .line 821
    .end local v4    # "$this$filter\\10":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\10\\821":I
    invoke-direct {v0, v7}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v3

    .end local v3    # "f":Lkotlin/jvm/functions/Function1;
    .end local v6    # "size":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .end local v23    # "b0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v24    # "b1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1062
    .local v3, "$this$ud\\9":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\9":Ljava/lang/String;
    .local v5, "$i$f$ud\\9\\818":I
    .restart local v8    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    :cond_399
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .end local v4    # "what\\9":Ljava/lang/String;
    .end local v8    # "cf":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v3, "$this$ud\\8":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\8":Ljava/lang/String;
    .local v7, "$i$f$ud\\8\\818":I
    :cond_3ba
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\8":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\8":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\8\\818":I
    :sswitch_3db
    const-string v3, "GetNumAwakeParts"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 878
    invoke-static/range {v19 .. v19}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v3

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_3ee
    const-string v3, "FindPartsInRegion3"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    goto/16 :goto_94c

    :sswitch_3f8
    const-string v3, "IsRegion3Empty"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    goto/16 :goto_94c

    :sswitch_402
    const-string v3, "FindPartsInRegion3WithIgnoreList"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    goto/16 :goto_94c

    :sswitch_40c
    const-string v3, "Spherecast"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_559

    goto/16 :goto_94c

    :sswitch_416
    const-string v3, "PGSIsEnabled"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 879
    sget-object v3, Lorg/luaj/vm2/LuaValue;->TRUE:Lorg/luaj/vm2/LuaBoolean;

    const-string v4, "TRUE"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_429
    const-string v3, "FindPartOnRay"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_80e

    goto/16 :goto_94c

    :sswitch_433
    const-string v3, "JoinToOutsiders"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7ff

    goto/16 :goto_94c

    :sswitch_43d
    const-string v3, "CalculateJumpHeight"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 882
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-wide v5, 0x4068866666666666L    # 196.2

    invoke-virtual {v3, v5, v6}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v5

    .local v5, "g":D
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-wide/high16 v7, 0x4049000000000000L    # 50.0

    invoke-virtual {v3, v7, v8}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v3

    .local v3, "jp":D
    mul-double v7, v3, v3

    mul-double v9, v5, v16

    div-double/2addr v7, v9

    invoke-static {v7, v8}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v3

    .end local v3    # "jp":D
    .end local v5    # "g":D
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_46c
    const-string v3, "GetPartsInPart"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 834
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Instance"

    .local v3, "$this$ud\\18":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\18":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1070
    .local v7, "$i$f$ud\\18\\834":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_489

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_48a

    :cond_489
    move-object v8, v6

    :goto_48a
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v9, :cond_48f

    move-object v6, v8

    :cond_48f
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-eqz v6, :cond_532

    .line 834
    .end local v3    # "$this$ud\\18":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\18":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\18\\834":I
    nop

    .line 835
    .local v6, "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    sget-object v3, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v3

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v5

    move-object v10, v5

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v10, "b0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    move-object v11, v3

    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 836
    .local v11, "b1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v3

    .line 837
    .local v3, "f":Lkotlin/jvm/functions/Function1;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\19":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1071
    .local v5, "$i$f$filter\\19\\837":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    move-object v15, v7

    check-cast v15, Ljava/util/Collection;

    .local v15, "destination\\20":Ljava/util/Collection;
    move-object/from16 v16, v4

    .local v16, "$this$filterTo\\20":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 1072
    .local v17, "$i$f$filterTo\\20\\1071":I
    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v20

    :goto_4ca
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_524

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\20":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v8, "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v21, 0x0

    .line 837
    .local v21, "$i$a$-filter-InstanceApi$workspaceCall$3\\21\\1072\\0":I
    if-eq v8, v6, :cond_515

    invoke-interface {v3, v8}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Boolean;

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-eqz v9, :cond_515

    sget-object v9, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v9, v8}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v9

    .line 1017
    const/16 v22, 0x0

    .local v22, "$i$a$-let-InstanceApi$workspaceCall$3$1\\22\\837\\21":I
    invoke-virtual {v9}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v12, "x0\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v9}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 837
    .local v9, "x1\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object v13, v7

    .end local v7    # "element\\20":Ljava/lang/Object;
    .local v13, "element\\20":Ljava/lang/Object;
    sget-object v7, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    move-object v14, v13

    .end local v13    # "element\\20":Ljava/lang/Object;
    .local v14, "element\\20":Ljava/lang/Object;
    const/16 v13, 0x10

    move-object/from16 v23, v14

    .end local v14    # "element\\20":Ljava/lang/Object;
    .local v23, "element\\20":Ljava/lang/Object;
    const/4 v14, 0x0

    move-object/from16 v24, v8

    move-object v8, v12

    .end local v12    # "x0\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v8, "x0\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v24, "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v12, 0x0

    move-object/from16 v25, v3

    move-object/from16 v3, v23

    .end local v23    # "element\\20":Ljava/lang/Object;
    .local v3, "element\\20":Ljava/lang/Object;
    .local v25, "f":Lkotlin/jvm/functions/Function1;
    invoke-static/range {v7 .. v14}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap$default(Lcom/exampletest/mobilestudiotest/engine/Geometry;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FILjava/lang/Object;)Z

    move-result v7

    .end local v8    # "x0\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v9    # "x1\\22":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v22    # "$i$a$-let-InstanceApi$workspaceCall$3$1\\22\\837\\21":I
    if-eqz v7, :cond_51a

    move/from16 v7, v18

    goto :goto_51c

    .end local v24    # "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v25    # "f":Lkotlin/jvm/functions/Function1;
    .local v3, "f":Lkotlin/jvm/functions/Function1;
    .restart local v7    # "element\\20":Ljava/lang/Object;
    .local v8, "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_515
    move-object/from16 v25, v3

    move-object v3, v7

    move-object/from16 v24, v8

    .end local v7    # "element\\20":Ljava/lang/Object;
    .end local v8    # "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    .local v3, "element\\20":Ljava/lang/Object;
    .restart local v24    # "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    .restart local v25    # "f":Lkotlin/jvm/functions/Function1;
    :cond_51a
    move/from16 v7, v19

    .line 1072
    .end local v21    # "$i$a$-filter-InstanceApi$workspaceCall$3\\21\\1072\\0":I
    .end local v24    # "it\\21":Lcom/exampletest/mobilestudiotest/model/Instance;
    :goto_51c
    if-eqz v7, :cond_521

    invoke-interface {v15, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_521
    move-object/from16 v3, v25

    goto :goto_4ca

    .line 1073
    .end local v25    # "f":Lkotlin/jvm/functions/Function1;
    .local v3, "f":Lkotlin/jvm/functions/Function1;
    :cond_524
    move-object/from16 v25, v3

    .end local v3    # "f":Lkotlin/jvm/functions/Function1;
    .end local v15    # "destination\\20":Ljava/util/Collection;
    .end local v16    # "$this$filterTo\\20":Ljava/lang/Iterable;
    .end local v17    # "$i$f$filterTo\\20\\1071":I
    .restart local v25    # "f":Lkotlin/jvm/functions/Function1;
    move-object v3, v15

    check-cast v3, Ljava/util/List;

    .line 1071
    nop

    .line 837
    .end local v4    # "$this$filter\\19":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\19\\837":I
    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v3

    .end local v6    # "part":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v10    # "b0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v11    # "b1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v25    # "f":Lkotlin/jvm/functions/Function1;
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1070
    .local v3, "$this$ud\\18":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\18":Ljava/lang/String;
    .local v7, "$i$f$ud\\18\\834":I
    :cond_532
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\18":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\18":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\18\\834":I
    :sswitch_553
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 797
    :cond_559
    invoke-static {v1, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5a4

    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "CFrame"

    .local v3, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\3":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1058
    .local v5, "$i$f$ud\\3\\797":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_574

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_575

    :cond_574
    move-object v7, v6

    :goto_575
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v8, :cond_57a

    move-object v7, v6

    :cond_57a
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v7, :cond_583

    .line 797
    .end local v3    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\3":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\3\\797":I
    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    goto :goto_5c4

    .line 1058
    .restart local v3    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .restart local v4    # "what\\3":Ljava/lang/String;
    .restart local v5    # "$i$f$ud\\3\\797":I
    :cond_583
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .line 797
    .end local v3    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\3":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\3\\797":I
    :cond_5a4
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v3, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\4":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1058
    .local v5, "$i$f$ud\\4\\797":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_5b9

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_5ba

    :cond_5b9
    move-object v7, v6

    :goto_5ba
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v8, :cond_5bf

    move-object v7, v6

    :cond_5bf
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v7, :cond_619

    move-object v3, v7

    .line 797
    .end local v3    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\4":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\4\\797":I
    :goto_5c4
    nop

    .line 798
    .local v3, "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v4, "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\5":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1059
    .local v7, "$i$f$ud\\5\\798":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_5da

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_5db

    :cond_5da
    move-object v8, v6

    :goto_5db
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_5e0

    move-object v6, v8

    :cond_5e0
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_5f8

    .line 798
    .end local v4    # "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\5":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\5\\798":I
    const/4 v4, 0x5

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v4

    invoke-direct {v0, v3, v6, v4}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->raycastResult(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    .end local v3    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1059
    .restart local v3    # "o":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .restart local v4    # "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "what\\5":Ljava/lang/String;
    .restart local v7    # "$i$f$ud\\5\\798":I
    :cond_5f8
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v8, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v8, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v6, v8}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .line 1058
    .end local v7    # "$i$f$ud\\5\\798":I
    .local v3, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\4":Ljava/lang/String;
    .local v5, "$i$f$ud\\4\\797":I
    :cond_619
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .line 794
    .end local v3    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\4":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\4\\797":I
    :sswitch_63a
    const-string v3, "Raycast"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 795
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v3, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\1":Ljava/lang/String;
    const/4 v7, 0x0

    .line 1057
    .local v7, "$i$f$ud\\1\\795":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_657

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_658

    :cond_657
    move-object v8, v6

    :goto_658
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v9, :cond_65d

    move-object v8, v6

    :cond_65d
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_6b4

    .line 795
    .end local v3    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\1":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\1\\795":I
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v3, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\2":Ljava/lang/String;
    const/4 v5, 0x0

    .line 1057
    .local v5, "$i$f$ud\\2\\795":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_676

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_677

    :cond_676
    move-object v7, v6

    :goto_677
    instance-of v9, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_67c

    move-object v6, v7

    :cond_67c
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_693

    .line 795
    .end local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\2":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\2\\795":I
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom(Lorg/luaj/vm2/LuaValue;)Lkotlin/jvm/functions/Function1;

    move-result-object v3

    invoke-direct {v0, v8, v6, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->raycastResult(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 1057
    .restart local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v4    # "what\\2":Ljava/lang/String;
    .restart local v5    # "$i$f$ud\\2\\795":I
    :cond_693
    new-instance v6, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v6

    .end local v4    # "what\\2":Ljava/lang/String;
    .local v3, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\1":Ljava/lang/String;
    .restart local v7    # "$i$f$ud\\1\\795":I
    :cond_6b4
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\1":Ljava/lang/String;
    .end local v7    # "$i$f$ud\\1\\795":I
    :sswitch_6d5
    const-string v3, "ArePartsTouchingOthers"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 872
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v3

    .line 873
    .local v3, "parts":Ljava/util/List;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    const-wide/16 v5, 0x0

    invoke-virtual {v4, v5, v6}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v4

    double-to-float v4, v4

    .line 874
    .local v4, "pad":F
    new-instance v5, Ljava/util/IdentityHashMap;

    invoke-direct {v5}, Ljava/util/IdentityHashMap;-><init>()V

    check-cast v5, Ljava/util/Map;

    invoke-static {v5}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v5

    move-object v6, v5

    .line 1017
    .local v6, "it\\28":Ljava/util/Set;
    const/4 v7, 0x0

    .line 874
    .local v7, "$i$a$-also-InstanceApi$workspaceCall$set$1\\28\\874\\0":I
    move-object v8, v3

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v6, v8}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 875
    .end local v6    # "it\\28":Ljava/util/Set;
    .end local v7    # "$i$a$-also-InstanceApi$workspaceCall$set$1\\28\\874\\0":I
    .local v5, "set":Ljava/util/Set;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$filter\\29":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1080
    .local v7, "$i$f$filter\\29\\875":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\30":Ljava/util/Collection;
    move-object v9, v6

    .local v9, "$this$filterTo\\30":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1081
    .local v10, "$i$f$filterTo\\30\\1080":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_71a
    :goto_71a
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_732

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\30":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v13, "it\\31":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v14, 0x0

    .line 875
    .local v14, "$i$a$-filter-InstanceApi$workspaceCall$others$1\\31\\1081\\0":I
    invoke-interface {v5, v13}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v15

    .line 1081
    .end local v13    # "it\\31":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v14    # "$i$a$-filter-InstanceApi$workspaceCall$others$1\\31\\1081\\0":I
    if-nez v15, :cond_71a

    invoke-interface {v8, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_71a

    .line 1082
    .end local v12    # "element\\30":Ljava/lang/Object;
    :cond_732
    nop

    .end local v8    # "destination\\30":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\30":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\30\\1080":I
    check-cast v8, Ljava/util/List;

    .line 1080
    nop

    .line 875
    .end local v6    # "$this$filter\\29":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filter\\29\\875":I
    nop

    .line 876
    .local v8, "others":Ljava/util/List;
    move-object v6, v3

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$any\\32":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1083
    .local v7, "$i$f$any\\32\\876":I
    instance-of v9, v6, Ljava/util/Collection;

    if-eqz v9, :cond_750

    move-object v9, v6

    check-cast v9, Ljava/util/Collection;

    invoke-interface {v9}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_750

    move-object/from16 v17, v3

    move-object/from16 v27, v5

    move/from16 v15, v19

    goto/16 :goto_7eb

    .line 1084
    :cond_750
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_754
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_7e5

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\32":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v11, "p\\33":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/4 v12, 0x0

    .line 876
    .local v12, "$i$a$-any-InstanceApi$workspaceCall$4\\33\\1084\\0":I
    sget-object v13, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v13, v11}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v13

    invoke-virtual {v13}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v14

    move-object/from16 v21, v14

    check-cast v21, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v21, "a0\\33":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v13}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v13

    move-object/from16 v22, v13

    check-cast v22, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v22, "a1\\33":Lcom/exampletest/mobilestudiotest/model/Vector3;
    move-object v13, v8

    check-cast v13, Ljava/lang/Iterable;

    .local v13, "$this$any\\34":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 1083
    .local v14, "$i$f$any\\34\\876":I
    instance-of v15, v13, Ljava/util/Collection;

    if-eqz v15, :cond_790

    move-object v15, v13

    check-cast v15, Ljava/util/Collection;

    invoke-interface {v15}, Ljava/util/Collection;->isEmpty()Z

    move-result v15

    if-eqz v15, :cond_790

    move-object/from16 v17, v3

    move-object/from16 v27, v5

    move/from16 v3, v19

    goto :goto_7d9

    .line 1084
    :cond_790
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_794
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_7d3

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v17, v3

    .end local v3    # "parts":Ljava/util/List;
    .local v16, "element\\34":Ljava/lang/Object;
    .local v17, "parts":Ljava/util/List;
    move-object/from16 v3, v16

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v3, "o\\35":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v26, 0x0

    .line 876
    .local v26, "$i$a$-any-InstanceApi$workspaceCall$4$1\\35\\1084\\33":I
    move-object/from16 v27, v5

    .end local v5    # "set":Ljava/util/Set;
    .local v27, "set":Ljava/util/Set;
    sget-object v5, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v5

    .line 1017
    const/16 v28, 0x0

    .local v28, "$i$a$-let-InstanceApi$workspaceCall$4$1$1\\36\\876\\35":I
    invoke-virtual {v5}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v20

    move-object/from16 v23, v20

    check-cast v23, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v23, "b0\\36":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v5}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v24, v5

    check-cast v24, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 876
    .local v24, "b1\\36":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v20, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    neg-float v5, v4

    move/from16 v25, v5

    invoke-virtual/range {v20 .. v25}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;F)Z

    move-result v5

    .line 1084
    .end local v3    # "o\\35":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v23    # "b0\\36":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v24    # "b1\\36":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v26    # "$i$a$-any-InstanceApi$workspaceCall$4$1\\35\\1084\\33":I
    .end local v28    # "$i$a$-let-InstanceApi$workspaceCall$4$1$1\\36\\876\\35":I
    if-eqz v5, :cond_7ce

    move/from16 v3, v18

    goto :goto_7d9

    :cond_7ce
    move-object/from16 v3, v17

    move-object/from16 v5, v27

    goto :goto_794

    .line 1085
    .end local v16    # "element\\34":Ljava/lang/Object;
    .end local v17    # "parts":Ljava/util/List;
    .end local v27    # "set":Ljava/util/Set;
    .local v3, "parts":Ljava/util/List;
    .restart local v5    # "set":Ljava/util/Set;
    :cond_7d3
    move-object/from16 v17, v3

    move-object/from16 v27, v5

    .end local v3    # "parts":Ljava/util/List;
    .end local v5    # "set":Ljava/util/Set;
    .restart local v17    # "parts":Ljava/util/List;
    .restart local v27    # "set":Ljava/util/Set;
    move/from16 v3, v19

    .line 876
    .end local v13    # "$this$any\\34":Ljava/lang/Iterable;
    .end local v14    # "$i$f$any\\34\\876":I
    :goto_7d9
    nop

    .line 1084
    .end local v11    # "p\\33":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v12    # "$i$a$-any-InstanceApi$workspaceCall$4\\33\\1084\\0":I
    .end local v21    # "a0\\33":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v22    # "a1\\33":Lcom/exampletest/mobilestudiotest/model/Vector3;
    if-eqz v3, :cond_7df

    move/from16 v15, v18

    goto :goto_7eb

    :cond_7df
    move-object/from16 v3, v17

    move-object/from16 v5, v27

    goto/16 :goto_754

    .line 1085
    .end local v10    # "element\\32":Ljava/lang/Object;
    .end local v17    # "parts":Ljava/util/List;
    .end local v27    # "set":Ljava/util/Set;
    .restart local v3    # "parts":Ljava/util/List;
    .restart local v5    # "set":Ljava/util/Set;
    :cond_7e5
    move-object/from16 v17, v3

    move-object/from16 v27, v5

    .end local v3    # "parts":Ljava/util/List;
    .end local v5    # "set":Ljava/util/Set;
    .restart local v17    # "parts":Ljava/util/List;
    .restart local v27    # "set":Ljava/util/Set;
    move/from16 v15, v19

    .line 876
    .end local v6    # "$this$any\\32":Ljava/lang/Iterable;
    .end local v7    # "$i$f$any\\32\\876":I
    :goto_7eb
    invoke-static {v15}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v3

    .line 871
    .end local v4    # "pad":F
    .end local v8    # "others":Ljava/util/List;
    .end local v17    # "parts":Ljava/util/List;
    .end local v27    # "set":Ljava/util/Set;
    nop

    .line 872
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_7f7
    const-string v3, "ZoomToExtents"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 861
    :cond_7ff
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v3, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_ab2

    .line 794
    :sswitch_808
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_94c

    .line 801
    :cond_80e
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Ray"

    .local v3, "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\6":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1060
    .local v8, "$i$f$ud\\6\\801":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v10

    if-eqz v10, :cond_823

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v10

    goto :goto_824

    :cond_823
    move-object v10, v6

    :goto_824
    instance-of v11, v10, Lcom/exampletest/mobilestudiotest/model/Ray;

    if-nez v11, :cond_829

    move-object v10, v6

    :cond_829
    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Ray;

    if-eqz v10, :cond_925

    .line 801
    .end local v3    # "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\6":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\6\\801":I
    nop

    .line 802
    .local v10, "ray":Lcom/exampletest/mobilestudiotest/model/Ray;
    nop

    .line 803
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v3

    if-eqz v3, :cond_845

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v3

    goto :goto_873

    .line 804
    :cond_845
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    if-eqz v3, :cond_86f

    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v3, "$this$udOrNull\\7":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 1061
    .local v7, "$i$f$udOrNull\\7\\804":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_862

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_863

    :cond_862
    move-object v8, v6

    :goto_863
    instance-of v11, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v11, :cond_868

    move-object v8, v6

    :cond_868
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 804
    .end local v3    # "$this$udOrNull\\7":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\7\\804":I
    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOfNotNull(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    goto :goto_873

    .line 805
    :cond_86f
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v3

    .line 802
    :goto_873
    nop

    .line 807
    .local v3, "list":Ljava/util/List;
    invoke-static {v1, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    .line 808
    .local v7, "white":Z
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v8

    .line 809
    .local v8, "len":F
    const v9, 0x358637bd    # 1.0E-6f

    cmpg-float v9, v8, v9

    if-gez v9, :cond_88a

    move/from16 v24, v8

    goto :goto_8a9

    :cond_88a
    sget-object v20, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v21

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getOrigin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v22

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v23

    new-instance v6, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;

    invoke-direct {v6, v3, v7}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;-><init>(Ljava/util/List;Z)V

    move-object/from16 v25, v6

    move/from16 v24, v8

    .end local v8    # "len":F
    .local v24, "len":F
    invoke-virtual/range {v20 .. v25}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->raycast(Ljava/util/List;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FLkotlin/jvm/functions/Function1;)Lcom/exampletest/mobilestudiotest/engine/RayHit;

    move-result-object v6

    .line 813
    .local v6, "hit":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    :goto_8a9
    if-nez v6, :cond_8c7

    sget-object v4, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getOrigin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v9

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v8

    invoke-virtual {v5, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    check-cast v5, Lorg/luaj/vm2/Varargs;

    invoke-static {v4, v5}, Lorg/luaj/vm2/LuaValue;->varargsOf(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v4

    move-object v3, v4

    goto :goto_91f

    .line 814
    :cond_8c7
    new-array v8, v13, [Lorg/luaj/vm2/LuaValue;

    iget-object v9, v0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->rt:Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;->wrap(Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    aput-object v9, v8, v19

    sget-object v9, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    aput-object v9, v8, v18

    sget-object v9, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getNormal()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v11

    invoke-virtual {v9, v11}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    aput-object v9, v8, v5

    .line 815
    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v9, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    sget-object v11, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    sget-object v12, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v13

    invoke-virtual {v12, v13}, Lcom/exampletest/mobilestudiotest/model/PartData;->material(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v12

    const-string v13, "Material"

    invoke-virtual {v11, v13, v12}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_907

    const-string v11, "Plastic"

    :cond_907
    sget-object v12, Lcom/exampletest/mobilestudiotest/model/PartData;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/PartData;

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/engine/RayHit;->getPart()Lcom/exampletest/mobilestudiotest/model/Instance;

    move-result-object v14

    invoke-virtual {v12, v14}, Lcom/exampletest/mobilestudiotest/model/PartData;->material(Lcom/exampletest/mobilestudiotest/model/Instance;)I

    move-result v12

    invoke-direct {v9, v13, v11, v12}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v5, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    aput-object v5, v8, v4

    .line 814
    invoke-static {v8}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v4

    move-object v3, v4

    .line 800
    .end local v3    # "list":Ljava/util/List;
    .end local v6    # "hit":Lcom/exampletest/mobilestudiotest/engine/RayHit;
    .end local v7    # "white":Z
    .end local v10    # "ray":Lcom/exampletest/mobilestudiotest/model/Ray;
    .end local v24    # "len":F
    :goto_91f
    nop

    .line 804
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    goto/16 :goto_ab2

    .line 1060
    .local v3, "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\6":Ljava/lang/String;
    .local v8, "$i$f$ud\\6\\801":I
    :cond_925
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 794
    .end local v3    # "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\6":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\6\\801":I
    :sswitch_946
    invoke-virtual {v1, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_94e

    :cond_94c
    :goto_94c
    goto/16 :goto_aab

    .line 840
    :cond_94e
    invoke-virtual {v2, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Region3"

    .local v3, "$this$ud\\23":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\23":Ljava/lang/String;
    const/4 v8, 0x0

    .line 1074
    .local v8, "$i$f$ud\\23\\840":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_963

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_964

    :cond_963
    move-object v9, v6

    :goto_964
    instance-of v11, v9, Lcom/exampletest/mobilestudiotest/lua/Region3V;

    if-nez v11, :cond_969

    move-object v9, v6

    :cond_969
    check-cast v9, Lcom/exampletest/mobilestudiotest/lua/Region3V;

    if-eqz v9, :cond_a8a

    .line 840
    .end local v3    # "$this$ud\\23":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\23":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\23\\840":I
    nop

    .line 841
    .local v9, "r":Lcom/exampletest/mobilestudiotest/lua/Region3V;
    invoke-virtual {v2, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    .line 842
    .local v3, "listArg":Lorg/luaj/vm2/LuaValue;
    nop

    .line 843
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v4

    if-eqz v4, :cond_981

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->instList(Lorg/luaj/vm2/LuaValue;)Ljava/util/List;

    move-result-object v4

    goto :goto_9a8

    .line 844
    :cond_981
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_9a4

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v4, v3

    .local v4, "$this$udOrNull\\24":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 1075
    .local v7, "$i$f$udOrNull\\24\\844":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_997

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_998

    :cond_997
    move-object v8, v6

    :goto_998
    instance-of v11, v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    if-nez v11, :cond_99d

    move-object v8, v6

    :cond_99d
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 844
    .end local v4    # "$this$udOrNull\\24":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\24\\844":I
    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOfNotNull(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    goto :goto_9a8

    .line 845
    :cond_9a4
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v4

    .line 842
    :goto_9a8
    nop

    .line 847
    .local v4, "list":Ljava/util/List;
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    .line 848
    .local v7, "white":Z
    const-string v8, "Is"

    move/from16 v10, v19

    invoke-static {v1, v8, v10, v5, v6}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_9bb

    move/from16 v10, v18

    move v11, v10

    goto :goto_9cb

    :cond_9bb
    invoke-virtual {v2, v13}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v10

    const/16 v11, 0x14

    invoke-virtual {v10, v11}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v10

    move/from16 v11, v18

    invoke-static {v10, v11}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v10

    .line 849
    .local v10, "max":I
    :goto_9cb
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 850
    .local v12, "out":Ljava/util/ArrayList;
    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceParts()Ljava/util/List;

    move-result-object v13

    invoke-interface {v13}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_9d8
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_a68

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lcom/exampletest/mobilestudiotest/model/Instance;

    .line 851
    .local v14, "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    move-object v15, v4

    check-cast v15, Ljava/lang/Iterable;

    .local v15, "$this$any\\25":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 1076
    .local v16, "$i$f$any\\25\\851":I
    instance-of v11, v15, Ljava/util/Collection;

    if-eqz v11, :cond_9f8

    move-object v11, v15

    check-cast v11, Ljava/util/Collection;

    invoke-interface {v11}, Ljava/util/Collection;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_9f8

    const/4 v5, 0x0

    goto :goto_a1e

    .line 1077
    :cond_9f8
    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_9fc
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_a1d

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    .local v17, "element\\25":Ljava/lang/Object;
    move-object/from16 v5, v17

    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Instance;

    .local v5, "f\\26":Lcom/exampletest/mobilestudiotest/model/Instance;
    const/16 v21, 0x0

    .line 851
    .local v21, "$i$a$-any-InstanceApi$workspaceCall$inList$1\\26\\1077\\0":I
    if-eq v14, v5, :cond_a16

    invoke-virtual {v14, v5}, Lcom/exampletest/mobilestudiotest/model/Instance;->isDescendantOf(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result v22

    if-nez v22, :cond_a16

    const/4 v5, 0x0

    goto :goto_a17

    :cond_a16
    const/4 v5, 0x1

    .line 1077
    .end local v5    # "f\\26":Lcom/exampletest/mobilestudiotest/model/Instance;
    .end local v21    # "$i$a$-any-InstanceApi$workspaceCall$inList$1\\26\\1077\\0":I
    :goto_a17
    if-eqz v5, :cond_a1b

    const/4 v5, 0x1

    goto :goto_a1e

    :cond_a1b
    const/4 v5, 0x2

    goto :goto_9fc

    .line 1078
    .end local v17    # "element\\25":Ljava/lang/Object;
    :cond_a1d
    const/4 v5, 0x0

    .line 851
    .end local v15    # "$this$any\\25":Ljava/lang/Iterable;
    .end local v16    # "$i$f$any\\25\\851":I
    :goto_a1e
    nop

    .line 852
    .local v5, "inList":Z
    if-eqz v7, :cond_a27

    if-nez v5, :cond_a25

    const/4 v11, 0x1

    goto :goto_a28

    :cond_a25
    const/4 v11, 0x0

    goto :goto_a28

    :cond_a27
    move v11, v5

    :goto_a28
    if-nez v11, :cond_a64

    .line 853
    sget-object v11, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v11, v14}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->partAabb(Lcom/exampletest/mobilestudiotest/model/Instance;)Lkotlin/Pair;

    move-result-object v11

    invoke-virtual {v11}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v22, v15

    check-cast v22, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .local v22, "x0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {v11}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v11

    move-object/from16 v23, v11

    check-cast v23, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 854
    .local v23, "x1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v21, Lcom/exampletest/mobilestudiotest/engine/Geometry;->INSTANCE:Lcom/exampletest/mobilestudiotest/engine/Geometry;

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v24

    invoke-virtual {v9}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v25

    const/16 v27, 0x10

    const/16 v28, 0x0

    const/16 v26, 0x0

    invoke-static/range {v21 .. v28}, Lcom/exampletest/mobilestudiotest/engine/Geometry;->aabbOverlap$default(Lcom/exampletest/mobilestudiotest/engine/Geometry;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;FILjava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_a60

    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-lt v11, v10, :cond_a60

    goto :goto_a68

    :cond_a60
    const/4 v5, 0x2

    const/4 v11, 0x1

    goto/16 :goto_9d8

    .line 852
    .end local v22    # "x0":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v23    # "x1":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_a64
    const/4 v5, 0x2

    const/4 v11, 0x1

    goto/16 :goto_9d8

    .line 856
    .end local v5    # "inList":Z
    .end local v14    # "p":Lcom/exampletest/mobilestudiotest/model/Instance;
    :cond_a68
    :goto_a68
    const/4 v5, 0x2

    const/4 v11, 0x0

    invoke-static {v1, v8, v11, v5, v6}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_a79

    invoke-virtual {v12}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    invoke-static {v5}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v5

    goto :goto_a80

    :cond_a79
    move-object v5, v12

    check-cast v5, Ljava/util/List;

    invoke-direct {v0, v5}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->listToLua(Ljava/util/List;)Lorg/luaj/vm2/LuaTable;

    move-result-object v5

    :goto_a80
    check-cast v5, Lorg/luaj/vm2/LuaValue;

    .line 839
    .end local v3    # "listArg":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "list":Ljava/util/List;
    .end local v7    # "white":Z
    .end local v9    # "r":Lcom/exampletest/mobilestudiotest/lua/Region3V;
    .end local v10    # "max":I
    .end local v12    # "out":Ljava/util/ArrayList;
    nop

    .line 854
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v3, v5

    check-cast v3, Lorg/luaj/vm2/Varargs;

    goto :goto_ab2

    .line 1074
    .local v3, "$this$ud\\23":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\23":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\23\\840":I
    :cond_a8a
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 884
    .end local v3    # "$this$ud\\23":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\23":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\23\\840":I
    :goto_aab
    sget-object v3, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    invoke-static {v3, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Lorg/luaj/vm2/Varargs;

    .line 794
    :goto_ab2
    return-object v3

    nop

    :sswitch_data_ab4
    .sparse-switch
        -0x7db55d12 -> :sswitch_946
        -0x7a472b5e -> :sswitch_808
        -0x76fdb725 -> :sswitch_7f7
        -0x725cc24e -> :sswitch_6d5
        -0x61e359b7 -> :sswitch_63a
        -0x5486aed4 -> :sswitch_553
        -0x4f4cc35e -> :sswitch_46c
        -0x381ec925 -> :sswitch_43d
        -0x30e4e13f -> :sswitch_433
        -0x2ea0a841 -> :sswitch_429
        -0x244c1f25 -> :sswitch_416
        -0x13a9ef54 -> :sswitch_40c
        -0x12d63417 -> :sswitch_402
        -0x38f64c8 -> :sswitch_3f8
        0xdbe613 -> :sswitch_3ee
        0xcf234eb -> :sswitch_3db
        0x113f98a8 -> :sswitch_2c5
        0x120e9b79 -> :sswitch_2bb
        0x15c33240 -> :sswitch_216
        0x27f05cd1 -> :sswitch_1e2
        0x2d86f4b5 -> :sswitch_1d8
        0x34941c4e -> :sswitch_1ce
        0x372819fe -> :sswitch_162
        0x4e981678 -> :sswitch_14d
        0x52468895 -> :sswitch_6e
        0x55bee095 -> :sswitch_64
        0x6b0d0636 -> :sswitch_4f
        0x76f51870 -> :sswitch_31
    .end sparse-switch
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi.AnonymousClass2 (com.exampletest.mobilestudiotest.lua.InstanceApi$2)
.class public final Lcom/exampletest/mobilestudiotest/lua/InstanceApi$2;
.super Lorg/luaj/vm2/lib/ThreeArgFunction;
.source "InstanceApi.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/lua/InstanceApi;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuaRuntime;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0003H\u0016\u00a8\u0006\u0007"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/lua/InstanceApi$2",
        "Lorg/luaj/vm2/lib/ThreeArgFunction;",
        "call",
        "Lorg/luaj/vm2/LuaValue;",
        "self",
        "key",
        "v",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;


# direct methods
.method constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;)V
    .registers 2
    .param p1, "$receiver"    # Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$2;->this$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    .line 133
    invoke-direct {p0}, Lorg/luaj/vm2/lib/ThreeArgFunction;-><init>()V

    return-void
.end method


# virtual methods
.method public call(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p1, "self"    # Lorg/luaj/vm2/LuaValue;
    .param p2, "key"    # Lorg/luaj/vm2/LuaValue;
    .param p3, "v"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "self"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "v"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 135
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$2;->this$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.model.Instance"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    const-string v3, "tojstring(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1, v2, p3}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->newIndex(Lcom/exampletest/mobilestudiotest/model/Instance;Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NONE"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi.AnonymousClass9 (com.exampletest.mobilestudiotest.lua.InstanceApi$animationTrack$9)
.class public final Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;
.super Lorg/luaj/vm2/lib/ThreeArgFunction;
.source "InstanceApi.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack(Lcom/exampletest/mobilestudiotest/model/Instance;Lcom/exampletest/mobilestudiotest/model/Instance;)Lorg/luaj/vm2/LuaTable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInstanceApi.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InstanceApi.kt\ncom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 LuaTypes.kt\ncom/exampletest/mobilestudiotest/lua/LuaTypesKt\n*L\n1#1,1016:1\n1#2:1017\n41#3:1018\n*S KotlinDebug\n*F\n+ 1 InstanceApi.kt\ncom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9\n*L\n701#1:1018\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0003H\u0016\u00a8\u0006\u0007"
    }
    d2 = {
        "com/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9",
        "Lorg/luaj/vm2/lib/ThreeArgFunction;",
        "call",
        "Lorg/luaj/vm2/LuaValue;",
        "self",
        "k",
        "v",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $looped:Lkotlin/jvm/internal/Ref$ObjectRef;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $play:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

.field final synthetic $priority:Lkotlin/jvm/internal/Ref$ObjectRef;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $st:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V
    .registers 5
    .param p1, "$looped"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p2, "$st"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .param p3, "$priority"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p4, "$play"    # Lcom/exampletest/mobilestudiotest/engine/PlaySession;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Ljava/lang/Integer;",
            ">;",
            "Lcom/exampletest/mobilestudiotest/engine/PlaySession;",
            ")V"
        }
    .end annotation

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$looped:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$st:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$priority:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$play:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    .line 697
    invoke-direct {p0}, Lorg/luaj/vm2/lib/ThreeArgFunction;-><init>()V

    return-void
.end method


# virtual methods
.method public call(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 16
    .param p1, "self"    # Lorg/luaj/vm2/LuaValue;
    .param p2, "k"    # Lorg/luaj/vm2/LuaValue;
    .param p3, "v"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "self"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "v"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 699
    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_cd

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_dc

    goto/16 :goto_cd

    :sswitch_1e
    const-string v1, "TimePosition"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_cd

    .line 702
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$st:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    if-eqz v0, :cond_d3

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$play:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    move-object v2, v0

    .line 1017
    .local v2, "it\\4":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    const/4 v0, 0x0

    .line 702
    .local v0, "$i$a$-let-InstanceApi$animationTrack$9$call$3\\4\\702\\0":I
    if-eqz v1, :cond_d3

    const-wide/16 v3, 0x0

    invoke-virtual {p3, v3, v4}, Lorg/luaj/vm2/LuaValue;->optdouble(D)D

    move-result-wide v3

    double-to-float v3, v3

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v8

    const/16 v9, 0x3e

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v1 .. v10}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->adjustTrack$default(Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Float;ILjava/lang/Object;)V

    goto/16 :goto_d3

    .line 699
    .end local v0    # "$i$a$-let-InstanceApi$animationTrack$9$call$3\\4\\702\\0":I
    .end local v2    # "it\\4":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    :sswitch_48
    const-string v1, "Priority"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_cd

    .line 701
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$priority:Lkotlin/jvm/internal/Ref$ObjectRef;

    move-object v1, p3

    .local v1, "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 1018
    .local v2, "$i$f$udOrNull\\2\\701":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_60

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_61

    :cond_60
    move-object v3, v4

    :goto_61
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v5, :cond_66

    move-object v4, v3

    :cond_66
    check-cast v4, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 701
    .end local v1    # "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$udOrNull\\2\\701":I
    if-eqz v4, :cond_6f

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v1

    goto :goto_75

    :cond_6f
    const/16 v1, 0x3e8

    invoke-virtual {p3, v1}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v1

    :goto_75
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$st:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    if-eqz v0, :cond_d3

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$play:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$priority:Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 1017
    .local v0, "it\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    const/4 v11, 0x0

    .line 701
    .local v11, "$i$a$-let-InstanceApi$animationTrack$9$call$2\\3\\701\\0":I
    if-eqz v1, :cond_98

    iget-object v2, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    move-object v7, v2

    check-cast v7, Ljava/lang/Integer;

    const/16 v9, 0x5e

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x0

    move-object v2, v0

    .end local v0    # "it\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .local v2, "it\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    invoke-static/range {v1 .. v10}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->adjustTrack$default(Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Float;ILjava/lang/Object;)V

    goto :goto_d3

    .end local v2    # "it\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .restart local v0    # "it\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    :cond_98
    move-object v2, v0

    .end local v0    # "it\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .restart local v2    # "it\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    goto :goto_d3

    .line 699
    .end local v2    # "it\\3":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .end local v11    # "$i$a$-let-InstanceApi$animationTrack$9$call$2\\3\\701\\0":I
    :sswitch_9a
    const-string v1, "Looped"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_cd

    .line 700
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$looped:Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->toboolean()Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iput-object v1, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$st:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    if-eqz v0, :cond_d3

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$play:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$animationTrack$9;->$looped:Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 1017
    .local v0, "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    const/4 v11, 0x0

    .line 700
    .local v11, "$i$a$-let-InstanceApi$animationTrack$9$call$1\\1\\700\\0":I
    if-eqz v1, :cond_cb

    iget-object v2, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    move-object v6, v2

    check-cast v6, Ljava/lang/Boolean;

    const/16 v9, 0x6e

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v2, v0

    .end local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .local v2, "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    invoke-static/range {v1 .. v10}, Lcom/exampletest/mobilestudiotest/engine/PlaySession;->adjustTrack$default(Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Float;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Float;ILjava/lang/Object;)V

    goto :goto_d3

    .end local v2    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .restart local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    :cond_cb
    move-object v2, v0

    .end local v0    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .restart local v2    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    goto :goto_d3

    .line 703
    .end local v2    # "it\\1":Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;
    .end local v11    # "$i$a$-let-InstanceApi$animationTrack$9$call$1\\1\\700\\0":I
    :cond_cd
    :goto_cd
    move-object v0, p1

    check-cast v0, Lorg/luaj/vm2/LuaTable;

    invoke-virtual {v0, p2, p3}, Lorg/luaj/vm2/LuaTable;->rawset(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 705
    :cond_d3
    :goto_d3
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NONE:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NONE"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    nop

    :sswitch_data_dc
    .sparse-switch
        -0x77ff599d -> :sswitch_9a
        -0x419d223c -> :sswitch_48
        0x4ac98736 -> :sswitch_1e
    .end sparse-switch
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "filterFrom$lambda$25"
    proto = "(Lcom/exampletest/mobilestudiotest/model/Instance;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom$lambda$25(Lcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "filterFrom$lambda$27"
    proto = "(Ljava/util/List;ZZLcom/exampletest/mobilestudiotest/model/Instance;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Z

.field public final synthetic f$2:Z


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;ZZ)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;->f$0:Ljava/util/List;

    iput-boolean p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;->f$1:Z

    iput-boolean p3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;->f$2:Z

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;->f$0:Ljava/util/List;

    iget-boolean v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;->f$1:Z

    iget-boolean v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda1;->f$2:Z

    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1, v2, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->filterFrom$lambda$27(Ljava/util/List;ZZLcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda10 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda10)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "animationTrack$lambda$40"
    proto = "(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/model/Instance;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

.field public final synthetic f$1:Lkotlin/jvm/internal/Ref$BooleanRef;

.field public final synthetic f$2:Lkotlin/jvm/internal/Ref$FloatRef;

.field public final synthetic f$3:Lkotlin/jvm/internal/Ref$ObjectRef;

.field public final synthetic f$4:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

.field public final synthetic f$5:Lkotlin/jvm/internal/Ref$ObjectRef;

.field public final synthetic f$6:Lcom/exampletest/mobilestudiotest/model/Instance;

.field public final synthetic f$7:Lorg/luaj/vm2/LuaTable;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/model/Instance;Lorg/luaj/vm2/LuaTable;)V
    .registers 9

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$1:Lkotlin/jvm/internal/Ref$BooleanRef;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$2:Lkotlin/jvm/internal/Ref$FloatRef;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$3:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$4:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p6, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$5:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p7, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$6:Lcom/exampletest/mobilestudiotest/model/Instance;

    iput-object p8, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$7:Lorg/luaj/vm2/LuaTable;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$1:Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$2:Lkotlin/jvm/internal/Ref$FloatRef;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$3:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$4:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$5:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v6, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$6:Lcom/exampletest/mobilestudiotest/model/Instance;

    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda10;->f$7:Lorg/luaj/vm2/LuaTable;

    move-object v8, p1

    check-cast v8, Lorg/luaj/vm2/LuaValue;

    move-object v9, p2

    check-cast v9, Lorg/luaj/vm2/LuaValue;

    invoke-static/range {v0 .. v9}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack$lambda$40(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/exampletest/mobilestudiotest/model/Instance;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda11 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda11)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "lambda$5$lambda$2"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;->f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda11;->f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->lambda$5$lambda$2(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda12 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda12)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "lambda$5$lambda$3"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;->f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda12;->f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->lambda$5$lambda$3(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda13 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda13)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "lambda$5$lambda$4"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;->f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda13;->f$1:Lcom/exampletest/mobilestudiotest/lua/SignalRef;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->lambda$5$lambda$4(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/SignalRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda14 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda14)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "workspaceCall$lambda$52"
    proto = "(Ljava/util/List;ZLcom/exampletest/mobilestudiotest/model/Instance;)Z"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Z)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;->f$0:Ljava/util/List;

    iput-boolean p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;->f$1:Z

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;->f$0:Ljava/util/List;

    iget-boolean v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda14;->f$1:Z

    check-cast p1, Lcom/exampletest/mobilestudiotest/model/Instance;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->workspaceCall$lambda$52(Ljava/util/List;ZLcom/exampletest/mobilestudiotest/model/Instance;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda15 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda15)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "_init_$lambda$0"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda15;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda15;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->_init_$lambda$0(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda16 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda16)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "_init_$lambda$1"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->_init_$lambda$1(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda17 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda17)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "_init_$lambda$5"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda17;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda17;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->_init_$lambda$5(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda18 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda18)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "_init_$lambda$6"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->_init_$lambda$6(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda19 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda19)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "_init_$lambda$8"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda19;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda19;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {v0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->_init_$lambda$8(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "lambda$8$lambda$7"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/Connection;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/lua/Connection;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/Connection;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;->f$1:Lcom/exampletest/mobilestudiotest/lua/Connection;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda2;->f$1:Lcom/exampletest/mobilestudiotest/lua/Connection;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->lambda$8$lambda$7(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lcom/exampletest/mobilestudiotest/lua/Connection;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda20 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda20)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "index$lambda$12$lambda$11"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Ljava/lang/String;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda20;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda20;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda20;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda20;->f$1:Ljava/lang/String;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->index$lambda$12$lambda$11(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Ljava/lang/String;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "animationTrack$lambda$30"
    proto = "(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/internal/Ref$FloatRef;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

.field public final synthetic f$2:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

.field public final synthetic f$3:Lkotlin/jvm/internal/Ref$BooleanRef;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;->f$0:Lkotlin/jvm/internal/Ref$FloatRef;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;->f$2:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;->f$3:Lkotlin/jvm/internal/Ref$BooleanRef;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;->f$0:Lkotlin/jvm/internal/Ref$FloatRef;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;->f$2:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda3;->f$3:Lkotlin/jvm/internal/Ref$BooleanRef;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, v2, v3, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack$lambda$30(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "animationTrack$lambda$31"
    proto = "(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

.field public final synthetic f$2:Lkotlin/jvm/internal/Ref$BooleanRef;

.field public final synthetic f$3:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

.field public final synthetic f$4:Lorg/luaj/vm2/LuaTable;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$2:Lkotlin/jvm/internal/Ref$BooleanRef;

    iput-object p4, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$3:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$4:Lorg/luaj/vm2/LuaTable;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$2:Lkotlin/jvm/internal/Ref$BooleanRef;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$3:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda4;->f$4:Lorg/luaj/vm2/LuaTable;

    move-object v5, p1

    check-cast v5, Lorg/luaj/vm2/Varargs;

    invoke-static/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack$lambda$31(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lkotlin/jvm/internal/Ref$BooleanRef;Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "animationTrack$lambda$33"
    proto = "(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/internal/Ref$FloatRef;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

.field public final synthetic f$2:Lcom/exampletest/mobilestudiotest/engine/PlaySession;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;->f$0:Lkotlin/jvm/internal/Ref$FloatRef;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;->f$2:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;->f$0:Lkotlin/jvm/internal/Ref$FloatRef;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda5;->f$2:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, v2, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack$lambda$33(Lkotlin/jvm/internal/Ref$FloatRef;Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "animationTrack$lambda$35"
    proto = "(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda6;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda6;->f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda6;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack$lambda$35(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "animationTrack$lambda$36"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

.field public final synthetic f$1:Lorg/luaj/vm2/LuaTable;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda7;->f$1:Lorg/luaj/vm2/LuaTable;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda7;->f$0:Lcom/exampletest/mobilestudiotest/lua/InstanceApi;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda7;->f$1:Lorg/luaj/vm2/LuaTable;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack$lambda$36(Lcom/exampletest/mobilestudiotest/lua/InstanceApi;Lorg/luaj/vm2/LuaTable;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda8 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "animationTrack$lambda$37"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack$lambda$37(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda9 (com.exampletest.mobilestudiotest.lua.InstanceApi$$ExternalSyntheticLambda9)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/InstanceApi;"
    method = "animationTrack$lambda$39"
    proto = "(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

.field public final synthetic f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda9;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda9;->f$0:Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/InstanceApi$$ExternalSyntheticLambda9;->f$1:Lcom/exampletest/mobilestudiotest/engine/PlaySession;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, v1, p1}, Lcom/exampletest/mobilestudiotest/lua/InstanceApi;->animationTrack$lambda$39(Lcom/exampletest/mobilestudiotest/engine/PlaySession$ScriptTrack;Lcom/exampletest/mobilestudiotest/engine/PlaySession;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method
