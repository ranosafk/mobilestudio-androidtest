###### Class com.exampletest.mobilestudiotest.lua.LuauTranspiler (com.exampletest.mobilestudiotest.lua.LuauTranspiler)
.class public final Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;
.super Ljava/lang/Object;
.source "LuauTranspiler.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;,
        Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;,
        Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;,
        Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;,
        Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLuauTranspiler.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LuauTranspiler.kt\ncom/exampletest/mobilestudiotest/lua/LuauTranspiler\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,593:1\n1#2:594\n1104#3,3:595\n295#4,2:598\n*S KotlinDebug\n*F\n+ 1 LuauTranspiler.kt\ncom/exampletest/mobilestudiotest/lua/LuauTranspiler\n*L\n59#1:595,3\n156#1:598,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0008\u0008\n\u0002\u0010\u000b\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0008\n\u0002\u0008\t\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0005 !\"#$B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0018\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u00062\u0008\u0008\u0002\u0010\u0010\u001a\u00020\u0011J\u0018\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\u0014\u001a\u00020\u0006H\u0002J \u0010\u0015\u001a\u0012\u0012\u0004\u0012\u00020\u00170\u0016j\u0008\u0012\u0004\u0012\u00020\u0017`\u00182\u0006\u0010\u0019\u001a\u00020\u0006H\u0002J$\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u00060\u001b2\u0006\u0010\u0019\u001a\u00020\u00062\u0006\u0010\u001d\u001a\u00020\u001cH\u0002J\u0010\u0010\u001e\u001a\u00020\u00062\u0006\u0010\u001f\u001a\u00020\u0006H\u0002R\u0014\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\u0004\u0018\u00010\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\n\u0010\u000b\"\u0004\u0008\u000c\u0010\r\u00a8\u0006%"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;",
        "",
        "<init>",
        "()V",
        "keywords",
        "",
        "",
        "ops",
        "",
        "lastFailure",
        "getLastFailure",
        "()Ljava/lang/String;",
        "setLastFailure",
        "(Ljava/lang/String;)V",
        "transpile",
        "src",
        "hoistTopLocals",
        "",
        "relevel",
        "text",
        "prefix",
        "lex",
        "Ljava/util/ArrayList;",
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;",
        "Lkotlin/collections/ArrayList;",
        "s",
        "interpolated",
        "Lkotlin/Pair;",
        "",
        "start",
        "transpileExpr",
        "e",
        "K",
        "Tok",
        "ParseError",
        "LoopCtx",
        "Parser",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;

.field private static final keywords:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile lastFailure:Ljava/lang/String;

.field private static final ops:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 25

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;

    .line 23
    nop

    .line 24
    const/16 v0, 0x16

    new-array v1, v0, [Ljava/lang/String;

    const-string v2, "and"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "break"

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const-string v2, "do"

    const/4 v5, 0x2

    aput-object v2, v1, v5

    const-string v2, "else"

    const/4 v6, 0x3

    aput-object v2, v1, v6

    const-string v2, "elseif"

    const/4 v7, 0x4

    aput-object v2, v1, v7

    const-string v2, "end"

    const/4 v8, 0x5

    aput-object v2, v1, v8

    const-string v2, "false"

    const/4 v9, 0x6

    aput-object v2, v1, v9

    const-string v2, "for"

    const/4 v10, 0x7

    aput-object v2, v1, v10

    const-string v2, "function"

    const/16 v11, 0x8

    aput-object v2, v1, v11

    const-string v2, "goto"

    const/16 v12, 0x9

    aput-object v2, v1, v12

    const-string v2, "if"

    const/16 v13, 0xa

    aput-object v2, v1, v13

    const-string v2, "in"

    const/16 v14, 0xb

    aput-object v2, v1, v14

    const-string v2, "local"

    const/16 v15, 0xc

    aput-object v2, v1, v15

    const-string v2, "nil"

    const/16 v16, 0xd

    aput-object v2, v1, v16

    .line 25
    const-string v2, "not"

    const/16 v17, 0xe

    aput-object v2, v1, v17

    .line 24
    nop

    .line 25
    const-string v2, "or"

    const/16 v18, 0xf

    aput-object v2, v1, v18

    .line 24
    nop

    .line 25
    const-string v2, "repeat"

    const/16 v19, 0x10

    aput-object v2, v1, v19

    .line 24
    nop

    .line 25
    const-string v2, "return"

    const/16 v20, 0x11

    aput-object v2, v1, v20

    .line 24
    nop

    .line 25
    const-string v2, "then"

    const/16 v21, 0x12

    aput-object v2, v1, v21

    .line 24
    nop

    .line 25
    const-string v2, "true"

    const/16 v22, 0x13

    aput-object v2, v1, v22

    .line 24
    nop

    .line 25
    const-string v2, "until"

    const/16 v23, 0x14

    aput-object v2, v1, v23

    .line 24
    nop

    .line 25
    const-string v2, "while"

    const/16 v24, 0x15

    aput-object v2, v1, v24

    .line 24
    nop

    .line 23
    invoke-static {v1}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    sput-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->keywords:Ljava/util/Set;

    .line 27
    nop

    .line 28
    const/16 v1, 0x2b

    new-array v1, v1, [Ljava/lang/String;

    const-string v2, "..."

    aput-object v2, v1, v3

    const-string v2, "..="

    aput-object v2, v1, v4

    const-string v2, "//="

    aput-object v2, v1, v5

    const-string v2, ".."

    aput-object v2, v1, v6

    const-string v2, "=="

    aput-object v2, v1, v7

    const-string v2, "~="

    aput-object v2, v1, v8

    const-string v2, "<="

    aput-object v2, v1, v9

    const-string v2, ">="

    aput-object v2, v1, v10

    const-string v2, "//"

    aput-object v2, v1, v11

    const-string v2, "::"

    aput-object v2, v1, v12

    const-string v2, "->"

    aput-object v2, v1, v13

    const-string v2, "+="

    aput-object v2, v1, v14

    const-string v2, "-="

    aput-object v2, v1, v15

    const-string v2, "*="

    aput-object v2, v1, v16

    const-string v2, "/="

    aput-object v2, v1, v17

    const-string v2, "%="

    aput-object v2, v1, v18

    const-string v2, "^="

    aput-object v2, v1, v19

    .line 29
    const-string v2, "+"

    aput-object v2, v1, v20

    .line 28
    nop

    .line 29
    const-string v2, "-"

    aput-object v2, v1, v21

    .line 28
    nop

    .line 29
    const-string v2, "*"

    aput-object v2, v1, v22

    .line 28
    nop

    .line 29
    const-string v2, "/"

    aput-object v2, v1, v23

    .line 28
    nop

    .line 29
    const-string v2, "%"

    const/16 v3, 0x15

    aput-object v2, v1, v3

    .line 28
    nop

    .line 29
    const-string v2, "^"

    aput-object v2, v1, v0

    .line 28
    nop

    .line 29
    const-string v0, "#"

    const/16 v2, 0x17

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "&"

    const/16 v2, 0x18

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "|"

    const/16 v2, 0x19

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "~"

    const/16 v2, 0x1a

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "<"

    const/16 v2, 0x1b

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, ">"

    const/16 v2, 0x1c

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "="

    const/16 v2, 0x1d

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "("

    const/16 v2, 0x1e

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, ")"

    const/16 v2, 0x1f

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "{"

    const/16 v2, 0x20

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "}"

    const/16 v2, 0x21

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "["

    const/16 v2, 0x22

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "]"

    const/16 v2, 0x23

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, ";"

    const/16 v2, 0x24

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, ":"

    const/16 v2, 0x25

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, ","

    const/16 v2, 0x26

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "."

    const/16 v2, 0x27

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "?"

    const/16 v2, 0x28

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "@"

    const/16 v2, 0x29

    aput-object v0, v1, v2

    .line 28
    nop

    .line 29
    const-string v0, "!"

    const/16 v2, 0x2a

    aput-object v0, v1, v2

    .line 28
    nop

    .line 27
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->ops:Ljava/util/List;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final interpolated(Ljava/lang/String;I)Lkotlin/Pair;
    .registers 22
    .param p1, "s"    # Ljava/lang/String;
    .param p2, "start"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 165
    move-object/from16 v0, p1

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 166
    .local v1, "parts":Ljava/util/ArrayList;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 167
    .local v2, "lit":Ljava/lang/StringBuilder;
    add-int/lit8 v3, p2, 0x1

    .line 171
    .local v3, "i":I
    :goto_e
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    const-string v5, ")"

    if-ge v3, v4, :cond_e3

    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/16 v6, 0x60

    if-eq v4, v6, :cond_e3

    .line 172
    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    .line 173
    .local v4, "c":C
    nop

    .line 174
    const-string v6, "\\n"

    const/16 v7, 0x5c

    if-ne v4, v7, :cond_4b

    add-int/lit8 v8, v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v9

    if-ge v8, v9, :cond_4b

    .line 175
    add-int/lit8 v5, v3, 0x1

    invoke-virtual {v0, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    .line 176
    .local v5, "nx":C
    sparse-switch v5, :sswitch_data_132

    .line 179
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_48

    .line 177
    :sswitch_41
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_48

    .line 178
    :sswitch_45
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    :goto_48
    add-int/lit8 v3, v3, 0x2

    .end local v5    # "nx":C
    goto :goto_e

    .line 183
    :cond_4b
    const/16 v8, 0x7b

    if-ne v4, v8, :cond_c2

    .line 184
    invoke-static {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->interpolated$flush(Ljava/lang/StringBuilder;Ljava/util/ArrayList;)V

    .line 185
    const/4 v6, 0x1

    .local v6, "depth":I
    add-int/lit8 v8, v3, 0x1

    .line 186
    .local v8, "j":I
    :cond_55
    :goto_55
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v9

    if-ge v8, v9, :cond_8b

    if-lez v6, :cond_8b

    .line 187
    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v9

    sparse-switch v9, :sswitch_data_144

    goto :goto_86

    :sswitch_65
    add-int/lit8 v6, v6, -0x1

    goto :goto_86

    :sswitch_68
    add-int/lit8 v6, v6, 0x1

    goto :goto_86

    :sswitch_6b
    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v9

    .local v9, "q":C
    :cond_6f
    :goto_6f
    add-int/lit8 v8, v8, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v10

    if-ge v8, v10, :cond_86

    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-eq v10, v9, :cond_86

    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v10

    if-ne v10, v7, :cond_6f

    add-int/lit8 v8, v8, 0x1

    goto :goto_6f

    .line 188
    .end local v9    # "q":C
    :cond_86
    :goto_86
    if-lez v6, :cond_55

    add-int/lit8 v8, v8, 0x1

    goto :goto_55

    .line 190
    :cond_8b
    add-int/lit8 v7, v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v9

    invoke-static {v8, v9}, Ljava/lang/Math;->min(II)I

    move-result v9

    invoke-virtual {v0, v7, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    const-string v9, "substring(...)"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 191
    .local v7, "expr":Ljava/lang/String;
    move-object/from16 v9, p0

    invoke-direct {v9, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->transpileExpr(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "tostring("

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 192
    add-int/lit8 v3, v8, 0x1

    .end local v6    # "depth":I
    .end local v7    # "expr":Ljava/lang/String;
    .end local v8    # "j":I
    goto/16 :goto_e

    .line 194
    :cond_c2
    move-object/from16 v9, p0

    const/16 v5, 0x22

    if-ne v4, v5, :cond_d1

    const-string v5, "\\\""

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_e

    .line 195
    :cond_d1
    const/16 v5, 0xa

    if-ne v4, v5, :cond_dc

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_e

    .line 196
    :cond_dc
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_e

    .line 171
    .end local v4    # "c":C
    :cond_e3
    move-object/from16 v9, p0

    .line 199
    invoke-static {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->interpolated$flush(Ljava/lang/StringBuilder;Ljava/util/ArrayList;)V

    .line 200
    add-int/lit8 v4, v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v6

    invoke-static {v4, v6}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 201
    .local v4, "end":I
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_fb

    const-string v6, "\"\""

    goto :goto_111

    :cond_fb
    move-object v10, v1

    check-cast v10, Ljava/lang/Iterable;

    const-string v6, " .. "

    move-object v11, v6

    check-cast v11, Ljava/lang/CharSequence;

    const/16 v17, 0x3e

    const/16 v18, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    invoke-static/range {v10 .. v18}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 202
    .local v6, "body":Ljava/lang/String;
    :goto_111
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "("

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v7, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    return-object v5

    nop

    :sswitch_data_132
    .sparse-switch
        0xa -> :sswitch_45
        0x60 -> :sswitch_41
        0x7b -> :sswitch_41
        0x7d -> :sswitch_41
    .end sparse-switch

    :sswitch_data_144
    .sparse-switch
        0x22 -> :sswitch_6b
        0x27 -> :sswitch_6b
        0x7b -> :sswitch_68
        0x7d -> :sswitch_65
    .end sparse-switch
.end method

.method private static final interpolated$flush(Ljava/lang/StringBuilder;Ljava/util/ArrayList;)V
    .registers 5
    .param p0, "lit"    # Ljava/lang/StringBuilder;
    .param p1, "parts"    # Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/StringBuilder;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 169
    move-object v0, p0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    move v0, v1

    :goto_d
    if-eqz v0, :cond_2c

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\""

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 170
    :cond_2c
    return-void
.end method

.method private final lex(Ljava/lang/String;)Ljava/util/ArrayList;
    .registers 25
    .param p1, "s"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;",
            ">;"
        }
    .end annotation

    .line 81
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    move-object v7, v2

    .line 82
    .local v7, "out":Ljava/util/ArrayList;
    const/4 v2, 0x0

    .line 83
    .local v2, "i":I
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v8

    .line 84
    .local v8, "n":I
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    move-object v9, v3

    .line 96
    .local v9, "triv":Ljava/lang/StringBuilder;
    :goto_15
    move v3, v2

    .line 98
    .end local v2    # "i":I
    .local v3, "i":I
    :goto_16
    const/16 v2, 0x2d

    const-string v4, "substring(...)"

    if-ge v3, v8, :cond_73

    .line 99
    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    .line 100
    .local v5, "c":C
    sparse-switch v5, :sswitch_data_2d4

    .line 101
    if-ne v5, v2, :cond_71

    add-int/lit8 v6, v3, 0x1

    if-ge v6, v8, :cond_71

    add-int/lit8 v6, v3, 0x1

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v6

    if-ne v6, v2, :cond_71

    .line 102
    add-int/lit8 v2, v3, 0x2

    invoke-static {v8, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lex$longBracketLevel(ILjava/lang/String;I)I

    move-result v2

    .line 103
    .local v2, "lvl":I
    if-ltz v2, :cond_47

    add-int/lit8 v6, v3, 0x2

    invoke-static {v1, v8, v6, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lex$skipLong(Ljava/lang/String;III)I

    move-result v6

    move v12, v3

    goto :goto_5a

    .line 100
    .end local v2    # "lvl":I
    :sswitch_41
    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_16

    .line 103
    .restart local v2    # "lvl":I
    :cond_47
    move-object v10, v1

    check-cast v10, Ljava/lang/CharSequence;

    const/4 v14, 0x4

    const/4 v15, 0x0

    const/16 v11, 0xa

    const/4 v13, 0x0

    move v12, v3

    .end local v3    # "i":I
    .local v12, "i":I
    invoke-static/range {v10 .. v15}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v3

    .line 594
    .local v3, "it\\1":I
    const/4 v6, 0x0

    .line 103
    .local v6, "$i$a$-let-LuauTranspiler$lex$e$1\\1\\103\\0":I
    if-gez v3, :cond_59

    move v6, v8

    goto :goto_5a

    :cond_59
    move v6, v3

    .line 104
    .end local v3    # "it\\1":I
    .local v6, "e":I
    :goto_5a
    invoke-virtual {v1, v12, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 105
    .local v3, "comment":Ljava/lang/String;
    if-nez v2, :cond_6a

    const-string v4, "--"

    invoke-direct {v0, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->relevel(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_6b

    :cond_6a
    move-object v4, v3

    :goto_6b
    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move v4, v6

    move v3, v4

    .end local v12    # "i":I
    .local v4, "i":I
    goto :goto_16

    .line 101
    .end local v2    # "lvl":I
    .end local v4    # "i":I
    .end local v6    # "e":I
    .local v3, "i":I
    :cond_71
    move v12, v3

    .line 107
    .end local v3    # "i":I
    .restart local v12    # "i":I
    goto :goto_74

    .line 98
    .end local v5    # "c":C
    .end local v12    # "i":I
    .restart local v3    # "i":I
    :cond_73
    move v12, v3

    .line 109
    .end local v3    # "i":I
    .restart local v12    # "i":I
    :goto_74
    const-string v3, ""

    const-string v5, "toString(...)"

    if-lt v12, v8, :cond_8c

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->EOF:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v2, v4, v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v7

    .line 110
    :cond_8c
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v10, v6

    .local v10, "tr":Ljava/lang/String;
    const/4 v5, 0x0

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 111
    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    move-result v11

    .line 112
    .local v11, "c":C
    nop

    .line 113
    invoke-static {v11}, Ljava/lang/Character;->isLetter(C)Z

    move-result v6

    const/16 v13, 0x5f

    if-nez v6, :cond_2a0

    if-eq v11, v13, :cond_2a0

    .line 119
    invoke-static {v11}, Ljava/lang/Character;->isDigit(C)Z

    move-result v6

    const/16 v14, 0x2e

    const/4 v15, 0x0

    if-nez v6, :cond_1af

    if-ne v11, v14, :cond_c2

    add-int/lit8 v6, v12, 0x1

    if-ge v6, v8, :cond_c2

    add-int/lit8 v6, v12, 0x1

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v6

    invoke-static {v6}, Ljava/lang/Character;->isDigit(C)Z

    move-result v6

    if-nez v6, :cond_1af

    .line 137
    :cond_c2
    const/16 v2, 0x22

    if-eq v11, v2, :cond_16d

    const/16 v2, 0x27

    if-eq v11, v2, :cond_16d

    .line 143
    const/16 v2, 0x5b

    if-ne v11, v2, :cond_fd

    invoke-static {v8, v1, v12}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lex$longBracketLevel(ILjava/lang/String;I)I

    move-result v2

    if-ltz v2, :cond_fd

    .line 144
    invoke-static {v8, v1, v12}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lex$longBracketLevel(ILjava/lang/String;I)I

    move-result v2

    .line 145
    .restart local v2    # "lvl":I
    invoke-static {v1, v8, v12, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lex$skipLong(Ljava/lang/String;III)I

    move-result v5

    .line 146
    .local v5, "e":I
    new-instance v6, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    sget-object v13, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-virtual {v1, v12, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v6, v13, v14, v10}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V

    .line 147
    .local v6, "t":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    if-nez v2, :cond_f7

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->relevel(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 148
    :cond_f7
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v2, v5

    .end local v5    # "e":I
    .end local v6    # "t":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v12    # "i":I
    .local v2, "i":I
    goto/16 :goto_15

    .line 150
    .end local v2    # "i":I
    .restart local v12    # "i":I
    :cond_fd
    const/16 v2, 0x60

    if-ne v11, v2, :cond_12c

    .line 151
    invoke-direct {v0, v1, v12}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->interpolated(Ljava/lang/String;I)Lkotlin/Pair;

    move-result-object v2

    invoke-virtual {v2}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    .local v3, "e":I
    invoke-virtual {v2}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 152
    .local v2, "converted":Ljava/lang/String;
    new-instance v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-virtual {v1, v12, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v5, v6, v13, v10}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V

    .local v5, "t":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v5, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 153
    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v2, v3

    .end local v3    # "e":I
    .end local v5    # "t":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v12    # "i":I
    .local v2, "i":I
    goto/16 :goto_15

    .line 156
    .end local v2    # "i":I
    .restart local v12    # "i":I
    :cond_12c
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->ops:Ljava/util/List;

    move-object v13, v2

    check-cast v13, Ljava/lang/Iterable;

    .local v13, "$this$firstOrNull\\2":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 598
    .local v14, "$i$f$firstOrNull\\2\\156":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :cond_136
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_153

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    .local v17, "element\\2":Ljava/lang/Object;
    move-object/from16 v2, v17

    check-cast v2, Ljava/lang/String;

    .local v2, "it\\3":Ljava/lang/String;
    const/16 v18, 0x0

    .line 156
    .local v18, "$i$a$-firstOrNull-LuauTranspiler$lex$op$1\\3\\598\\0":I
    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    move v3, v12

    .end local v12    # "i":I
    .local v3, "i":I
    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;IZILjava/lang/Object;)Z

    move-result v2

    .line 598
    .end local v2    # "it\\3":Ljava/lang/String;
    .end local v3    # "i":I
    .end local v18    # "$i$a$-firstOrNull-LuauTranspiler$lex$op$1\\3\\598\\0":I
    .restart local v12    # "i":I
    if-eqz v2, :cond_136

    move-object/from16 v15, v17

    goto :goto_154

    .line 599
    .end local v17    # "element\\2":Ljava/lang/Object;
    :cond_153
    nop

    .line 156
    .end local v13    # "$this$firstOrNull\\2":Ljava/lang/Iterable;
    .end local v14    # "$i$f$firstOrNull\\2\\156":I
    :goto_154
    check-cast v15, Ljava/lang/String;

    if-nez v15, :cond_15c

    invoke-static {v11}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v15

    .line 157
    .local v15, "op":Ljava/lang/String;
    :cond_15c
    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->OP:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-direct {v2, v3, v15, v10}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v15}, Ljava/lang/String;->length()I

    move-result v2

    add-int/2addr v2, v12

    .end local v10    # "tr":Ljava/lang/String;
    .end local v11    # "c":C
    .end local v12    # "i":I
    .end local v15    # "op":Ljava/lang/String;
    .local v2, "i":I
    goto/16 :goto_15

    .line 138
    .end local v2    # "i":I
    .restart local v10    # "tr":Ljava/lang/String;
    .restart local v11    # "c":C
    .restart local v12    # "i":I
    :cond_16d
    add-int/lit8 v3, v12, 0x1

    .line 139
    .local v3, "j":I
    :goto_16f
    if-ge v3, v8, :cond_196

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-eq v2, v11, :cond_196

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/16 v5, 0x5c

    if-ne v2, v5, :cond_181

    add-int/lit8 v3, v3, 0x1

    :cond_181
    if-ge v3, v8, :cond_193

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/16 v6, 0xa

    if-ne v2, v6, :cond_193

    add-int/lit8 v2, v3, -0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-ne v2, v5, :cond_196

    :cond_193
    add-int/lit8 v3, v3, 0x1

    goto :goto_16f

    .line 140
    :cond_196
    add-int/lit8 v2, v3, 0x1

    invoke-static {v2, v8}, Ljava/lang/Math;->min(II)I

    move-result v2

    .line 141
    .end local v3    # "j":I
    .local v2, "j":I
    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-virtual {v1, v12, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v3, v5, v6, v10}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .end local v12    # "i":I
    .local v2, "i":I
    goto/16 :goto_15

    .line 120
    .end local v2    # "i":I
    .restart local v12    # "i":I
    :cond_1af
    move v3, v12

    .line 121
    .restart local v3    # "j":I
    const/16 v6, 0x30

    if-ne v11, v6, :cond_1f7

    add-int/lit8 v6, v12, 0x1

    if-ge v6, v8, :cond_1f7

    add-int/lit8 v6, v12, 0x1

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/16 v5, 0x78

    if-eq v6, v5, :cond_1e0

    add-int/lit8 v5, v12, 0x1

    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x58

    if-eq v5, v6, :cond_1e0

    add-int/lit8 v5, v12, 0x1

    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x62

    if-eq v5, v6, :cond_1e0

    add-int/lit8 v5, v12, 0x1

    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x42

    if-ne v5, v6, :cond_1f7

    .line 122
    :cond_1e0
    add-int/lit8 v3, v3, 0x2

    .line 123
    :goto_1e2
    if-ge v3, v8, :cond_247

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v2

    if-nez v2, :cond_1f4

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-ne v2, v13, :cond_247

    :cond_1f4
    add-int/lit8 v3, v3, 0x1

    goto :goto_1e2

    .line 125
    :cond_1f7
    :goto_1f7
    if-ge v3, v8, :cond_212

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    invoke-static {v5}, Ljava/lang/Character;->isDigit(C)Z

    move-result v5

    if-nez v5, :cond_20f

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-eq v5, v14, :cond_20f

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-ne v5, v13, :cond_212

    :cond_20f
    add-int/lit8 v3, v3, 0x1

    goto :goto_1f7

    .line 126
    :cond_212
    if-ge v3, v8, :cond_247

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x65

    if-eq v5, v6, :cond_224

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x45

    if-ne v5, v6, :cond_247

    .line 127
    :cond_224
    add-int/lit8 v3, v3, 0x1

    .line 128
    if-ge v3, v8, :cond_238

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x2b

    if-eq v5, v6, :cond_236

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-ne v5, v2, :cond_238

    :cond_236
    add-int/lit8 v3, v3, 0x1

    .line 129
    :cond_238
    :goto_238
    if-ge v3, v8, :cond_247

    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->isDigit(C)Z

    move-result v2

    if-eqz v2, :cond_247

    add-int/lit8 v3, v3, 0x1

    goto :goto_238

    .line 132
    :cond_247
    invoke-virtual {v1, v12, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v21, 0x4

    const/16 v22, 0x0

    const-string v18, "_"

    const-string v19, ""

    const/16 v20, 0x0

    move-object/from16 v17, v2

    invoke-static/range {v17 .. v22}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    .line 133
    .local v2, "num":Ljava/lang/String;
    const-string v5, "0b"

    const/4 v6, 0x2

    const/4 v13, 0x0

    invoke-static {v2, v5, v13, v6, v15}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_271

    const-string v5, "0B"

    invoke-static {v2, v5, v13, v6, v15}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_271

    goto :goto_289

    :cond_271
    invoke-virtual {v2, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v6}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;I)Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_283

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    goto :goto_285

    :cond_283
    const-wide/16 v5, 0x0

    :goto_285
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    .line 134
    :goto_289
    new-instance v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NUMBER:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-virtual {v1, v12, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v5, v6, v13, v10}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V

    .restart local v5    # "t":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v5, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 135
    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v2, v3

    .end local v3    # "j":I
    .end local v5    # "t":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v12    # "i":I
    .local v2, "i":I
    goto/16 :goto_15

    .line 114
    .end local v2    # "i":I
    .restart local v12    # "i":I
    :cond_2a0
    move v2, v12

    .line 115
    .local v2, "j":I
    :goto_2a1
    if-ge v2, v8, :cond_2b6

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v3

    if-nez v3, :cond_2b3

    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    if-ne v3, v13, :cond_2b6

    :cond_2b3
    add-int/lit8 v2, v2, 0x1

    goto :goto_2a1

    .line 116
    :cond_2b6
    invoke-virtual {v1, v12, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 117
    .local v3, "w":Ljava/lang/String;
    new-instance v4, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->keywords:Ljava/util/Set;

    invoke-interface {v5, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2ca

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->KEYWORD:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    goto :goto_2cc

    :cond_2ca
    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    :goto_2cc
    invoke-direct {v4, v5, v3, v10}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .end local v3    # "w":Ljava/lang/String;
    .end local v12    # "i":I
    .local v2, "i":I
    goto/16 :goto_15

    :sswitch_data_2d4
    .sparse-switch
        0x9 -> :sswitch_41
        0xa -> :sswitch_41
        0xc -> :sswitch_41
        0xd -> :sswitch_41
        0x20 -> :sswitch_41
    .end sparse-switch
.end method

.method private static final lex$longBracketLevel(ILjava/lang/String;I)I
    .registers 9
    .param p0, "n"    # I
    .param p1, "$s"    # Ljava/lang/String;
    .param p2, "at"    # I

    .line 86
    const/4 v0, -0x1

    if-ge p2, p0, :cond_27

    invoke-virtual {p1, p2}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x5b

    if-ne v1, v2, :cond_27

    .line 87
    add-int/lit8 v1, p2, 0x1

    .local v1, "j":I
    const/4 v3, 0x0

    .line 88
    .local v3, "lvl":I
    :goto_e
    if-ge v1, p0, :cond_1d

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/16 v5, 0x3d

    if-ne v4, v5, :cond_1d

    add-int/lit8 v3, v3, 0x1

    add-int/lit8 v1, v1, 0x1

    goto :goto_e

    .line 89
    :cond_1d
    if-ge v1, p0, :cond_26

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v4

    if-ne v4, v2, :cond_26

    move v0, v3

    :cond_26
    return v0

    .line 86
    .end local v1    # "j":I
    .end local v3    # "lvl":I
    :cond_27
    return v0
.end method

.method private static final lex$skipLong(Ljava/lang/String;III)I
    .registers 11
    .param p0, "$s"    # Ljava/lang/String;
    .param p1, "n"    # I
    .param p2, "at"    # I
    .param p3, "lvl"    # I

    .line 92
    const-string v0, "="

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0, p3}, Lkotlin/text/StringsKt;->repeat(Ljava/lang/CharSequence;I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 93
    .local v2, "close":Ljava/lang/String;
    move-object v1, p0

    check-cast v1, Ljava/lang/CharSequence;

    add-int v0, p2, p3

    add-int/lit8 v3, v0, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I

    move-result v0

    .line 94
    .local v0, "e":I
    if-gez v0, :cond_31

    move v1, p1

    goto :goto_36

    :cond_31
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v1

    add-int/2addr v1, v0

    :goto_36
    return v1
.end method

.method private final relevel(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 14
    .param p1, "text"    # Ljava/lang/String;
    .param p2, "prefix"    # Ljava/lang/String;

    .line 70
    move-object v0, p2

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {p1, v0}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 71
    .local v0, "body0":Ljava/lang/String;
    const-string v1, "[["

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0, v1, v2, v3, v4}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_95

    const-string v5, "]]"

    invoke-static {v0, v5, v2, v3, v4}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_95

    .line 72
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v5

    sub-int/2addr v5, v3

    invoke-virtual {v0, v3, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    const-string v6, "substring(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .local v5, "inner":Ljava/lang/String;
    move-object v6, v5

    check-cast v6, Ljava/lang/CharSequence;

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v6, v1, v2, v3, v4}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_34

    return-object p1

    .line 74
    :cond_34
    const/4 v1, 0x1

    .line 75
    .local v1, "lvl":I
    :goto_35
    move-object v6, v5

    check-cast v6, Ljava/lang/CharSequence;

    const-string v7, "="

    move-object v8, v7

    check-cast v8, Ljava/lang/CharSequence;

    invoke-static {v8, v1}, Lkotlin/text/StringsKt;->repeat(Ljava/lang/CharSequence;I)Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "]"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    check-cast v8, Ljava/lang/CharSequence;

    invoke-static {v6, v8, v2, v3, v4}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_63

    add-int/lit8 v1, v1, 0x1

    goto :goto_35

    .line 76
    :cond_63
    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7, v1}, Lkotlin/text/StringsKt;->repeat(Ljava/lang/CharSequence;I)Ljava/lang/String;

    move-result-object v2

    .line 77
    .local v2, "eq":Ljava/lang/String;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "["

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    return-object v3

    .line 71
    .end local v1    # "lvl":I
    .end local v2    # "eq":Ljava/lang/String;
    .end local v5    # "inner":Ljava/lang/String;
    :cond_95
    return-object p1
.end method

.method public static synthetic transpile$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;
    .registers 5

    .line 40
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_5

    const/4 p2, 0x0

    :cond_5
    invoke-virtual {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->transpile(Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static final transpile$lambda$3(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;)Ljava/lang/CharSequence;
    .registers 2
    .param p0, "it"    # Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method private final transpileExpr(Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    .param p1, "e"    # Ljava/lang/String;

    .line 206
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "return "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0, v0, v2, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->transpile$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 207
    .local v0, "r":Ljava/lang/String;
    invoke-static {v0, v1, v2, v3, v4}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2b

    const/4 v1, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "substring(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_2c

    :cond_2b
    move-object v1, p1

    :goto_2c
    return-object v1
.end method


# virtual methods
.method public final getLastFailure()Ljava/lang/String;
    .registers 2

    .line 33
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lastFailure:Ljava/lang/String;

    return-object v0
.end method

.method public final setLastFailure(Ljava/lang/String;)V
    .registers 2
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 33
    sput-object p1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lastFailure:Ljava/lang/String;

    return-void
.end method

.method public final transpile(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 30
    .param p1, "src"    # Ljava/lang/String;
    .param p2, "hoistTopLocals"    # Z

    const-string v0, "src"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    const/4 v2, 0x0

    .line 42
    .local v2, "parser":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;
    const/4 v3, 0x0

    .line 43
    .local v3, "toks":Ljava/util/ArrayList;
    nop

    .line 44
    :try_start_a
    invoke-direct/range {p0 .. p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lex(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    move-object v3, v0

    .line 45
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;

    move-object v4, v3

    check-cast v4, Ljava/util/List;
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_14} :catch_6b

    move/from16 v5, p2

    :try_start_16
    invoke-direct {v0, v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;-><init>(Ljava/util/List;Z)V

    move-object v2, v0

    .line 46
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->run()V

    .line 47
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4

    add-int/lit8 v4, v4, 0x40

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 48
    .local v0, "sb":Ljava/lang/StringBuilder;
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    const-string v6, "iterator(...)"

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_31
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_5f

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const-string v7, "next(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 49
    .local v6, "t":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getTrivia()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getPrefix()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getOut()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getSuffix()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_31

    .line 54
    .end local v6    # "t":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    :cond_5f
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 43
    .end local v0    # "sb":Ljava/lang/StringBuilder;
    nop

    .line 51
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V
    :try_end_67
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_67} :catch_69

    goto/16 :goto_167

    .line 55
    :catch_69
    move-exception v0

    goto :goto_6e

    :catch_6b
    move-exception v0

    move/from16 v5, p2

    .line 56
    .local v0, "e":Ljava/lang/Exception;
    :goto_6e
    instance-of v4, v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    if-nez v4, :cond_77

    instance-of v4, v0, Ljava/lang/IndexOutOfBoundsException;

    if-nez v4, :cond_77

    throw v0

    .line 57
    :cond_77
    move-object v4, v3

    .local v4, "tk":Ljava/util/ArrayList;
    if-eqz v2, :cond_7f

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->getP()I

    move-result v7

    goto :goto_80

    :cond_7f
    const/4 v7, 0x0

    .line 58
    .local v7, "pp":I
    :goto_80
    if-nez v4, :cond_87

    const/4 v6, 0x0

    move-object/from16 v17, v0

    goto/16 :goto_163

    .line 59
    :cond_87
    move-object v8, v4

    check-cast v8, Ljava/lang/Iterable;

    invoke-static {v8, v7}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v8

    check-cast v8, Ljava/lang/Iterable;

    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    const/4 v9, 0x0

    :goto_95
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_107

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 594
    nop

    .local v10, "t\\1":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    const/4 v12, 0x0

    .line 59
    .local v12, "$i$a$-sumOfInt-LuauTranspiler$transpile$line$1\\1\\59\\0":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getTrivia()Ljava/lang/String;

    move-result-object v13

    check-cast v13, Ljava/lang/CharSequence;

    .local v13, "$this$count\\2":Ljava/lang/CharSequence;
    const/4 v14, 0x0

    .line 595
    .local v14, "$i$f$count\\2\\59":I
    const/4 v15, 0x0

    .line 596
    .local v15, "count\\2":I
    const/4 v11, 0x0

    const/16 v16, 0x1

    :goto_ae
    invoke-interface {v13}, Ljava/lang/CharSequence;->length()I

    move-result v6

    move-object/from16 v17, v0

    .end local v0    # "e":Ljava/lang/Exception;
    .local v17, "e":Ljava/lang/Exception;
    const/16 v0, 0xa

    if-ge v11, v6, :cond_d3

    invoke-interface {v13, v11}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v6

    .local v6, "element\\2":C
    move/from16 v18, v6

    .local v18, "it\\3":C
    const/16 v19, 0x0

    .line 59
    .local v19, "$i$a$-count-LuauTranspiler$transpile$line$1$1\\3\\596\\1":I
    move/from16 v1, v18

    .end local v18    # "it\\3":C
    .local v1, "it\\3":C
    if-ne v1, v0, :cond_c7

    move/from16 v0, v16

    goto :goto_c8

    :cond_c7
    const/4 v0, 0x0

    .line 596
    .end local v1    # "it\\3":C
    .end local v19    # "$i$a$-count-LuauTranspiler$transpile$line$1$1\\3\\596\\1":I
    :goto_c8
    if-eqz v0, :cond_cc

    add-int/lit8 v15, v15, 0x1

    .end local v6    # "element\\2":C
    :cond_cc
    add-int/lit8 v11, v11, 0x1

    move-object/from16 v1, p1

    move-object/from16 v0, v17

    goto :goto_ae

    .line 597
    :cond_d3
    nop

    .line 59
    .end local v13    # "$this$count\\2":Ljava/lang/CharSequence;
    .end local v14    # "$i$f$count\\2\\59":I
    .end local v15    # "count\\2":I
    invoke-virtual {v10}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    .local v1, "$this$count\\4":Ljava/lang/CharSequence;
    const/4 v6, 0x0

    .line 595
    .local v6, "$i$f$count\\4\\59":I
    const/4 v11, 0x0

    .line 596
    .local v11, "count\\4":I
    const/4 v13, 0x0

    :goto_dd
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-ge v13, v14, :cond_fe

    invoke-interface {v1, v13}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v14

    .local v14, "element\\4":C
    move/from16 v18, v14

    .local v18, "it\\5":C
    const/16 v19, 0x0

    .line 59
    .local v19, "$i$a$-count-LuauTranspiler$transpile$line$1$2\\5\\596\\1":I
    move-object/from16 v20, v1

    move/from16 v1, v18

    .end local v18    # "it\\5":C
    .local v1, "it\\5":C
    .local v20, "$this$count\\4":Ljava/lang/CharSequence;
    if-ne v1, v0, :cond_f4

    move/from16 v1, v16

    goto :goto_f5

    :cond_f4
    const/4 v1, 0x0

    .line 596
    .end local v1    # "it\\5":C
    .end local v19    # "$i$a$-count-LuauTranspiler$transpile$line$1$2\\5\\596\\1":I
    :goto_f5
    if-eqz v1, :cond_f9

    add-int/lit8 v11, v11, 0x1

    .end local v14    # "element\\4":C
    :cond_f9
    add-int/lit8 v13, v13, 0x1

    move-object/from16 v1, v20

    goto :goto_dd

    .line 597
    .end local v20    # "$this$count\\4":Ljava/lang/CharSequence;
    .local v1, "$this$count\\4":Ljava/lang/CharSequence;
    :cond_fe
    move-object/from16 v20, v1

    .line 59
    .end local v1    # "$this$count\\4":Ljava/lang/CharSequence;
    .end local v6    # "$i$f$count\\4\\59":I
    .end local v11    # "count\\4":I
    add-int/2addr v15, v11

    .end local v10    # "t\\1":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v12    # "$i$a$-sumOfInt-LuauTranspiler$transpile$line$1\\1\\59\\0":I
    add-int/2addr v9, v15

    move-object/from16 v1, p1

    move-object/from16 v0, v17

    goto :goto_95

    .end local v17    # "e":Ljava/lang/Exception;
    .restart local v0    # "e":Ljava/lang/Exception;
    :cond_107
    move-object/from16 v17, v0

    const/16 v16, 0x1

    .end local v0    # "e":Ljava/lang/Exception;
    .restart local v17    # "e":Ljava/lang/Exception;
    add-int/lit8 v9, v9, 0x1

    .line 60
    .local v9, "line":I
    add-int/lit8 v0, v7, -0x6

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v0

    add-int/lit8 v1, v7, 0x4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v6

    invoke-static {v1, v6}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result v1

    invoke-virtual {v4, v0, v1}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v0

    const-string v1, "subList(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v18, v0

    check-cast v18, Ljava/lang/Iterable;

    const-string v0, " "

    move-object/from16 v19, v0

    check-cast v19, Ljava/lang/CharSequence;

    new-instance v24, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$$ExternalSyntheticLambda0;

    invoke-direct/range {v24 .. v24}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$$ExternalSyntheticLambda0;-><init>()V

    const/16 v25, 0x1e

    const/16 v26, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    invoke-static/range {v18 .. v26}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "line "

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v6, " near: "

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 58
    .end local v9    # "line":I
    :goto_163
    sput-object v6, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->lastFailure:Ljava/lang/String;

    .line 62
    move-object/from16 v4, p1

    .line 43
    .end local v4    # "tk":Ljava/util/ArrayList;
    .end local v7    # "pp":I
    .end local v17    # "e":Ljava/lang/Exception;
    :goto_167
    return-object v4
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuauTranspiler.K (com.exampletest.mobilestudiotest.lua.LuauTranspiler$K)
.class final enum Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;
.super Ljava/lang/Enum;
.source "LuauTranspiler.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "K"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0008\t\u0008\u0082\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003j\u0002\u0008\u0004j\u0002\u0008\u0005j\u0002\u0008\u0006j\u0002\u0008\u0007j\u0002\u0008\u0008j\u0002\u0008\t\u00a8\u0006\n"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;",
        "",
        "<init>",
        "(Ljava/lang/String;I)V",
        "NAME",
        "KEYWORD",
        "NUMBER",
        "STRING",
        "OP",
        "EOF",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

.field public static final enum EOF:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

.field public static final enum KEYWORD:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

.field public static final enum NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

.field public static final enum NUMBER:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

.field public static final enum OP:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

.field public static final enum STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;


# direct methods
.method private static final synthetic $values()[Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;
    .registers 6

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->KEYWORD:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NUMBER:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->OP:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->EOF:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    filled-new-array/range {v0 .. v5}, [Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .registers 3

    .line 10
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    const-string v1, "NAME"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    const-string v1, "KEYWORD"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->KEYWORD:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    const-string v1, "NUMBER"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NUMBER:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    const-string v1, "STRING"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    const-string v1, "OP"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->OP:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    const-string v1, "EOF"

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->EOF:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-static {}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->$values()[Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->$VALUES:[Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->$VALUES:[Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 10
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;
    .registers 2

    const-class v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    return-object v0
.end method

.method public static values()[Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;
    .registers 1

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->$VALUES:[Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    return-object v0
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuauTranspiler.LoopCtx (com.exampletest.mobilestudiotest.lua.LuauTranspiler$LoopCtx)
.class final Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;
.super Ljava/lang/Object;
.source "LuauTranspiler.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "LoopCtx"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0002\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007R\u001a\u0010\u0008\u001a\u00020\tX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\n\u0010\u000b\"\u0004\u0008\u000c\u0010\r\u00a8\u0006\u000e"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;",
        "",
        "id",
        "",
        "<init>",
        "(I)V",
        "getId",
        "()I",
        "usesContinue",
        "",
        "getUsesContinue",
        "()Z",
        "setUsesContinue",
        "(Z)V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final id:I

.field private usesContinue:Z


# direct methods
.method public constructor <init>(I)V
    .registers 2
    .param p1, "id"    # I

    .line 212
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->id:I

    return-void
.end method


# virtual methods
.method public final getId()I
    .registers 2

    .line 212
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->id:I

    return v0
.end method

.method public final getUsesContinue()Z
    .registers 2

    .line 212
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->usesContinue:Z

    return v0
.end method

.method public final setUsesContinue(Z)V
    .registers 2
    .param p1, "<set-?>"    # Z

    .line 212
    iput-boolean p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->usesContinue:Z

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuauTranspiler.ParseError (com.exampletest.mobilestudiotest.lua.LuauTranspiler$ParseError)
.class final Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;
.super Ljava/lang/Exception;
.source "LuauTranspiler.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "ParseError"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u0002\u0018\u00002\u00060\u0001j\u0002`\u0002B\u0007\u00a2\u0006\u0004\u0008\u0003\u0010\u0004\u00a8\u0006\u0005"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;",
        "Ljava/lang/Exception;",
        "Lkotlin/Exception;",
        "<init>",
        "()V",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 21
    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuauTranspiler.Parser (com.exampletest.mobilestudiotest.lua.LuauTranspiler$Parser)
.class final Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;
.super Ljava/lang/Object;
.source "LuauTranspiler.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Parser"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLuauTranspiler.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LuauTranspiler.kt\ncom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,593:1\n1#2:594\n434#3:595\n507#3,5:596\n*S KotlinDebug\n*F\n+ 1 LuauTranspiler.kt\ncom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser\n*L\n231#1:595\n231#1:596,5\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0007\n\u0002\u0010\u0008\n\u0002\u0008\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0002\u0008\u001e\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0008\u0002\u0018\u00002\u00020\u0001B\u001f\u0012\u000c\u0010\u0002\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u0010\u0010\u001f\u001a\u00020\u00042\u0008\u0008\u0002\u0010 \u001a\u00020\u000eJ\u0006\u0010!\u001a\u00020\u0004J\u0006\u0010\"\u001a\u00020\u0006J\u000e\u0010#\u001a\u00020\u00042\u0006\u0010$\u001a\u00020%J\u000e\u0010&\u001a\u00020\u00042\u0006\u0010$\u001a\u00020%J\u0006\u0010\'\u001a\u00020\u0004J\u0016\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020\u000e2\u0006\u0010+\u001a\u00020\u000eJ\u0006\u0010,\u001a\u00020)J\u0006\u0010-\u001a\u00020\u0006J\u0006\u0010.\u001a\u00020)J\u000e\u0010/\u001a\u00020\u00042\u0006\u00100\u001a\u00020%J\u0006\u00101\u001a\u00020)J\u0006\u00102\u001a\u00020\u0006J\u000e\u00103\u001a\u00020)2\u0006\u00104\u001a\u00020\u000eJ\u0006\u00105\u001a\u00020)J\u0006\u00106\u001a\u00020)J\u0006\u00107\u001a\u00020)J\u0006\u00108\u001a\u00020)J\u0016\u00109\u001a\u00020)2\u0006\u0010:\u001a\u00020%2\u0006\u0010;\u001a\u00020%J\u0006\u0010<\u001a\u00020)J\u0006\u0010=\u001a\u00020)J\u0006\u0010>\u001a\u00020)J\u0006\u0010?\u001a\u00020)J\u0006\u0010@\u001a\u00020)J\u0006\u0010A\u001a\u00020)J\u0006\u0010B\u001a\u00020)J\u0006\u0010C\u001a\u00020)J\u0006\u0010D\u001a\u00020)J\u0006\u0010E\u001a\u00020)J\u0006\u0010F\u001a\u00020)J\u001e\u0010G\u001a\u0010\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000e\u0018\u00010H2\u0006\u0010I\u001a\u00020\u0004H\u0002J\u0006\u0010J\u001a\u00020)J\u000e\u0010K\u001a\u00020)2\u0006\u0010L\u001a\u00020\u000eR\u0017\u0010\u0002\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u001a\u0010\r\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010\"\u0004\u0008\u0011\u0010\u0012R\u001a\u0010\u0013\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0014\u0010\u0010\"\u0004\u0008\u0015\u0010\u0012R\u001a\u0010\u0016\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0017\u0010\u0010\"\u0004\u0008\u0018\u0010\u0012R%\u0010\u0019\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u001aj\n\u0012\u0006\u0012\u0004\u0018\u00010\u001b`\u001c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u001e\u00a8\u0006M"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;",
        "",
        "t",
        "",
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;",
        "hoist",
        "",
        "<init>",
        "(Ljava/util/List;Z)V",
        "getT",
        "()Ljava/util/List;",
        "getHoist",
        "()Z",
        "p",
        "",
        "getP",
        "()I",
        "setP",
        "(I)V",
        "labelCounter",
        "getLabelCounter",
        "setLabelCounter",
        "depth",
        "getDepth",
        "setDepth",
        "loops",
        "Ljava/util/ArrayList;",
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;",
        "Lkotlin/collections/ArrayList;",
        "getLoops",
        "()Ljava/util/ArrayList;",
        "peek",
        "o",
        "next",
        "atEof",
        "expectOp",
        "s",
        "",
        "expectKw",
        "expectName",
        "drop",
        "",
        "from",
        "to",
        "run",
        "blockEnd",
        "block",
        "loopBody",
        "endKw",
        "statement",
        "isStatementWord",
        "typeDecl",
        "start",
        "nameWithType",
        "localName",
        "funcBody",
        "skipAngle",
        "skipBalanced",
        "open",
        "close",
        "returnType",
        "type",
        "simpleType",
        "exprList",
        "exprStatement",
        "primaryExpr",
        "suffixedExpr",
        "callArgs",
        "table",
        "simpleExpr",
        "ifExpr",
        "binPrio",
        "Lkotlin/Pair;",
        "k",
        "expr",
        "subExpr",
        "limit",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private depth:I

.field private final hoist:Z

.field private labelCounter:I

.field private final loops:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;",
            ">;"
        }
    .end annotation
.end field

.field private p:I

.field private final t:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;Z)V
    .registers 4
    .param p1, "t"    # Ljava/util/List;
    .param p2, "hoist"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;",
            ">;Z)V"
        }
    .end annotation

    const-string v0, "t"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 214
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    iput-boolean p2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->hoist:Z

    .line 219
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    .line 214
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;ZILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 5

    .line 214
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_5

    const/4 p2, 0x0

    :cond_5
    invoke-direct {p0, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;-><init>(Ljava/util/List;Z)V

    return-void
.end method

.method private final binPrio(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;)Lkotlin/Pair;
    .registers 5
    .param p1, "k"    # Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;",
            ")",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 560
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->KEYWORD:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    const/4 v2, 0x0

    if-ne v0, v1, :cond_2e

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v0

    const-string v1, "or"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_23

    const/4 v0, 0x1

    :goto_16
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v1, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    goto :goto_2d

    :cond_23
    const-string v1, "and"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2d

    const/4 v0, 0x2

    goto :goto_16

    :cond_2d
    :goto_2d
    return-object v2

    .line 561
    :cond_2e
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->OP:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v0, v1, :cond_37

    return-object v2

    .line 562
    :cond_37
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_116

    goto/16 :goto_103

    :sswitch_44
    const-string v1, "~="

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_103

    goto/16 :goto_bb

    :sswitch_4e
    const-string v1, ">="

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_bb

    goto/16 :goto_103

    :sswitch_58
    const-string v1, "=="

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_bb

    goto/16 :goto_103

    :sswitch_62
    const-string v1, "<="

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_bb

    goto/16 :goto_103

    :sswitch_6c
    const-string v1, "//"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_104

    goto/16 :goto_103

    :sswitch_76
    const-string v1, ".."

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_103

    .line 564
    const/16 v0, 0x9

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/16 v1, 0x8

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    goto/16 :goto_114

    .line 562
    :sswitch_90
    const-string v1, "^"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_103

    .line 567
    const/16 v0, 0xe

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/16 v1, 0xd

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    goto/16 :goto_114

    .line 562
    :sswitch_aa
    const-string v1, ">"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_bb

    goto :goto_103

    :sswitch_b3
    const-string v1, "<"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_103

    .line 563
    :cond_bb
    :goto_bb
    const/4 v0, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v1, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    goto :goto_114

    .line 562
    :sswitch_c9
    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_104

    goto :goto_103

    :sswitch_d2
    const-string v1, "-"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e3

    goto :goto_103

    :sswitch_db
    const-string v1, "+"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_103

    .line 565
    :cond_e3
    const/16 v0, 0xa

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v1, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    goto :goto_114

    .line 562
    :sswitch_f2
    const-string v1, "*"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_104

    goto :goto_103

    :sswitch_fb
    const-string v1, "%"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_104

    :cond_103
    :goto_103
    goto :goto_113

    .line 566
    :cond_104
    const/16 v0, 0xb

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v1, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    goto :goto_114

    .line 568
    :goto_113
    nop

    .line 562
    :goto_114
    return-object v2

    nop

    :sswitch_data_116
    .sparse-switch
        0x25 -> :sswitch_fb
        0x2a -> :sswitch_f2
        0x2b -> :sswitch_db
        0x2d -> :sswitch_d2
        0x2f -> :sswitch_c9
        0x3c -> :sswitch_b3
        0x3e -> :sswitch_aa
        0x5e -> :sswitch_90
        0x5c0 -> :sswitch_76
        0x5e0 -> :sswitch_6c
        0x781 -> :sswitch_62
        0x7a0 -> :sswitch_58
        0x7bf -> :sswitch_4e
        0xf7f -> :sswitch_44
    .end sparse-switch
.end method

.method static final exprStatement$lambda$2(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;I)Ljava/lang/CharSequence;
    .registers 3
    .param p0, "this$0"    # Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;
    .param p1, "it"    # I

    .line 466
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getOut()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method public static synthetic peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .registers 4

    .line 221
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_5

    const/4 p1, 0x0

    :cond_5
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek(I)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final atEof()Z
    .registers 5

    .line 223
    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0, v1, v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v0

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->EOF:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v0, v3, :cond_10

    move v1, v2

    :cond_10
    return v1
.end method

.method public final block()V
    .registers 6

    .line 247
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->depth:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->depth:I

    .line 248
    :goto_6
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->blockEnd()Z

    move-result v0

    if-nez v0, :cond_44

    .line 249
    const/4 v0, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "return"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_40

    .line 250
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 251
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->blockEnd()Z

    move-result v3

    const-string v4, ";"

    if-nez v3, :cond_32

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_32

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->exprList()V

    .line 252
    :cond_32
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    invoke-virtual {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3f

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 253
    :cond_3f
    goto :goto_6

    .line 255
    :cond_40
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->statement()V

    goto :goto_6

    .line 257
    :cond_44
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->depth:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->depth:I

    .line 258
    return-void
.end method

.method public final blockEnd()Z
    .registers 6

    .line 242
    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0, v1, v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    .line 243
    .local v0, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v3

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->EOF:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v3, v4, :cond_30

    const-string v3, "end"

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_30

    const-string v3, "else"

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_30

    const-string v3, "elseif"

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_30

    const-string v3, "until"

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_30

    goto :goto_31

    :cond_30
    move v1, v2

    :goto_31
    return v1
.end method

.method public final callArgs()V
    .registers 7

    .line 507
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    .line 508
    .local v3, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    nop

    .line 509
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v4, v5, :cond_14

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_3f

    .line 510
    :cond_14
    const-string v4, "{"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_22

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->table()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_3f

    .line 511
    :cond_22
    const-string v4, "("

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_40

    .line 512
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 513
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_3c

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->exprList()V

    .line 514
    :cond_3c
    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 518
    :goto_3f
    return-void

    .line 516
    :cond_40
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v0
.end method

.method public final drop(II)V
    .registers 16
    .param p1, "from"    # I
    .param p2, "to"    # I

    .line 229
    move v0, p1

    .local v0, "i":I
    :goto_1
    if-ge v0, p2, :cond_4d

    .line 230
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 231
    .local v1, "tk":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v2

    .local v2, "$this$filter\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 595
    .local v3, "$i$f$filter\\1\\231":I
    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    .local v4, "$this$filterTo\\2":Ljava/lang/CharSequence;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    check-cast v5, Ljava/lang/Appendable;

    .local v5, "destination\\2":Ljava/lang/Appendable;
    const/4 v6, 0x0

    .line 596
    .local v6, "$i$f$filterTo\\2\\595":I
    const/4 v7, 0x0

    .local v7, "index\\2":I
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v8

    :goto_20
    if-ge v7, v8, :cond_37

    .line 597
    invoke-interface {v4, v7}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v9

    .line 598
    .local v9, "element\\2":C
    move v10, v9

    .local v10, "it\\3":C
    const/4 v11, 0x0

    .line 231
    .local v11, "$i$a$-filter-LuauTranspiler$Parser$drop$1\\3\\598\\0":I
    const/16 v12, 0xa

    if-ne v10, v12, :cond_2e

    const/4 v12, 0x1

    goto :goto_2f

    :cond_2e
    const/4 v12, 0x0

    .line 598
    .end local v10    # "it\\3":C
    .end local v11    # "$i$a$-filter-LuauTranspiler$Parser$drop$1\\3\\598\\0":I
    :goto_2f
    if-eqz v12, :cond_34

    invoke-interface {v5, v9}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    .line 596
    .end local v9    # "element\\2":C
    :cond_34
    add-int/lit8 v7, v7, 0x1

    goto :goto_20

    .line 600
    .end local v7    # "index\\2":I
    :cond_37
    nop

    .end local v4    # "$this$filterTo\\2":Ljava/lang/CharSequence;
    .end local v5    # "destination\\2":Ljava/lang/Appendable;
    .end local v6    # "$i$f$filterTo\\2\\595":I
    move-object v4, v5

    check-cast v4, Ljava/lang/StringBuilder;

    .line 595
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 231
    .end local v2    # "$this$filter\\1":Ljava/lang/String;
    .end local v3    # "$i$f$filter\\1\\231":I
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 232
    const-string v2, ""

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setPrefix(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setSuffix(Ljava/lang/String;)V

    .line 229
    .end local v1    # "tk":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 234
    .end local v0    # "i":I
    :cond_4d
    return-void
.end method

.method public final expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .registers 5
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 225
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    return-object v0

    :cond_17
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v0
.end method

.method public final expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .registers 4

    .line 226
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v0, v1, :cond_14

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    return-object v0

    :cond_14
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v0
.end method

.method public final expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .registers 5
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 224
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    return-object v0

    :cond_17
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v0
.end method

.method public final expr()V
    .registers 2

    .line 572
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->subExpr(I)V

    return-void
.end method

.method public final exprList()V
    .registers 4

    .line 452
    nop

    :goto_1
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    const-string v1, ","

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_1

    :cond_17
    return-void
.end method

.method public final exprStatement()V
    .registers 16

    .line 455
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .line 456
    .local v0, "start":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->suffixedExpr()V

    .line 457
    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    .line 458
    .local v4, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    nop

    .line 459
    const-string v5, "="

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v6

    const-string v7, ","

    if-nez v6, :cond_11e

    invoke-virtual {v4, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_11e

    .line 463
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v6

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->OP:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v6, v7, :cond_135

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v7, 0x2

    if-lt v6, v7, :cond_135

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v5, v1, v7, v3}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_135

    const/4 v3, 0x4

    new-array v3, v3, [Ljava/lang/String;

    const-string v5, "=="

    aput-object v5, v3, v1

    const-string v1, "~="

    aput-object v1, v3, v2

    const-string v1, "<="

    aput-object v1, v3, v7

    const/4 v1, 0x3

    const-string v5, ">="

    aput-object v5, v3, v1

    invoke-static {v3}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_135

    .line 464
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v1

    .line 465
    .local v1, "opTok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getText()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/text/StringsKt;->dropLast(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    .line 466
    .local v3, "base":Ljava/lang/String;
    iget v5, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    sub-int/2addr v5, v2

    invoke-static {v0, v5}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v5

    move-object v6, v5

    check-cast v6, Ljava/lang/Iterable;

    const-string v5, " "

    move-object v7, v5

    check-cast v7, Ljava/lang/CharSequence;

    new-instance v12, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser$$ExternalSyntheticLambda0;

    invoke-direct {v12, p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser$$ExternalSyntheticLambda0;-><init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;)V

    const/16 v13, 0x1e

    const/4 v14, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v6 .. v14}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    .line 467
    .local v6, "lhs":Ljava/lang/String;
    iget v7, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .line 468
    .local v7, "rhsStart":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    .line 469
    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    iget v9, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    sub-int/2addr v9, v2

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 470
    .local v2, "last":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    const-string v8, "//"

    invoke-static {v3, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_d6

    .line 471
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "= math.floor("

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " / ("

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 472
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getSuffix()Ljava/lang/String;

    move-result-object v5

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "))"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setSuffix(Ljava/lang/String;)V

    goto :goto_114

    .line 474
    :cond_d6
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "= "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " ("

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 475
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getSuffix()Ljava/lang/String;

    move-result-object v5

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, ")"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setSuffix(Ljava/lang/String;)V

    .line 477
    :goto_114
    iget v5, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    if-ne v7, v5, :cond_135

    new-instance v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v5

    .line 460
    .end local v1    # "opTok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v2    # "last":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v3    # "base":Ljava/lang/String;
    .end local v6    # "lhs":Ljava/lang/String;
    .end local v7    # "rhsStart":I
    :cond_11e
    :goto_11e
    invoke-static {p0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v6

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_12f

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->suffixedExpr()V

    goto :goto_11e

    .line 461
    :cond_12f
    invoke-virtual {p0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->exprList()V

    .line 481
    :cond_135
    return-void
.end method

.method public final funcBody()V
    .registers 8

    .line 373
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "<"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_19

    iget v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .local v3, "s":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipAngle()V

    iget v4, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->drop(II)V

    .line 374
    .end local v3    # "s":I
    :cond_19
    const-string v3, "("

    invoke-virtual {p0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 375
    :goto_1e
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, ")"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    const-string v5, ":"

    if-nez v3, :cond_66

    .line 376
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v6, "..."

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_53

    .line 377
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 378
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_56

    iget v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .restart local v3    # "s":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->type()V

    iget v6, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->drop(II)V

    .end local v3    # "s":I
    goto :goto_56

    .line 379
    :cond_53
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->nameWithType()V

    .line 380
    :cond_56
    :goto_56
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v6, ","

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_66

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_1e

    .line 382
    :cond_66
    invoke-virtual {p0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 383
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    invoke-virtual {v0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_80

    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .local v0, "s":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->returnType()V

    iget v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->drop(II)V

    .line 384
    .end local v0    # "s":I
    :cond_80
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 385
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->block()V

    .line 386
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    sub-int/2addr v2, v1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 387
    const-string v0, "end"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 388
    return-void
.end method

.method public final getDepth()I
    .registers 2

    .line 218
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->depth:I

    return v0
.end method

.method public final getHoist()Z
    .registers 2

    .line 214
    iget-boolean v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->hoist:Z

    return v0
.end method

.method public final getLabelCounter()I
    .registers 2

    .line 216
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->labelCounter:I

    return v0
.end method

.method public final getLoops()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;",
            ">;"
        }
    .end annotation

    .line 219
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    return-object v0
.end method

.method public final getP()I
    .registers 2

    .line 215
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    return v0
.end method

.method public final getT()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;",
            ">;"
        }
    .end annotation

    .line 214
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    return-object v0
.end method

.method public final ifExpr()V
    .registers 7

    .line 544
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    .line 545
    .local v0, "ifTok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    const-string v1, "(function() if"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 546
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    .line 547
    const-string v1, "then"

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v2

    const-string v3, "then return"

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 548
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    .line 549
    :goto_1a
    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p0, v2, v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v2

    const-string v4, "elseif"

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_3a

    .line 550
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    .line 551
    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v2

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 552
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    goto :goto_1a

    .line 554
    :cond_3a
    const-string v1, "else"

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v1

    const-string v2, "else return"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 555
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    .line 556
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    sub-int/2addr v2, v5

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getSuffix()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " end end)()"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setSuffix(Ljava/lang/String;)V

    .line 557
    return-void
.end method

.method public final isStatementWord()Z
    .registers 5

    .line 346
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek(I)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v1

    .line 347
    .local v1, "n":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    const-string v2, "("

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    const-string v2, "="

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    const-string v2, "."

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    const-string v2, "["

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    const-string v2, ":"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    const-string v2, ","

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v2

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v2, v3, :cond_56

    const-string v2, "{"

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    .line 348
    const-string v2, "+="

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    const-string v2, "-="

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_56

    goto :goto_57

    :cond_56
    const/4 v0, 0x0

    .line 347
    :goto_57
    return v0
.end method

.method public final localName()V
    .registers 6

    .line 367
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 368
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "<"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1c

    iget v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .local v3, "s":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipAngle()V

    iget v4, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->drop(II)V

    .line 369
    .end local v3    # "s":I
    :cond_1c
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    const-string v1, ":"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_35

    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .local v0, "s":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->type()V

    iget v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->drop(II)V

    .line 370
    .end local v0    # "s":I
    :cond_35
    return-void
.end method

.method public final loopBody(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .registers 10
    .param p1, "endKw"    # Ljava/lang/String;

    const-string v0, "endKw"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 261
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->labelCounter:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->labelCounter:I

    iget v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->labelCounter:I

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;-><init>(I)V

    .line 262
    .local v0, "ctx":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;
    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 263
    iget v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .line 264
    .local v1, "bodyStart":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->block()V

    .line 265
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 266
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v2

    .line 267
    .local v2, "e":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->getUsesContinue()Z

    move-result v3

    if-eqz v3, :cond_ac

    .line 268
    const-string v3, "end"

    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const-string v4, ":: "

    if-eqz v3, :cond_8e

    .line 271
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    iget-object v5, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getPrefix()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "do "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setPrefix(Ljava/lang/String;)V

    .line 272
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getPrefix()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->getId()I

    move-result v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, " end ::__continue"

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setPrefix(Ljava/lang/String;)V

    goto :goto_ac

    .line 273
    :cond_8e
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->getId()I

    move-result v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "::__continue"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setPrefix(Ljava/lang/String;)V

    .line 275
    :cond_ac
    :goto_ac
    return-object v2
.end method

.method public final nameWithType()V
    .registers 4

    .line 362
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 363
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    const-string v1, ":"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f

    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .local v0, "s":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->type()V

    iget v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->drop(II)V

    .line 364
    .end local v0    # "s":I
    :cond_1f
    return-void
.end method

.method public final next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .registers 6

    .line 222
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 594
    .local v1, "it\\1":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    const/4 v2, 0x0

    .line 222
    .local v2, "$i$a$-also-LuauTranspiler$Parser$next$1\\1\\222\\0":I
    iget v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    add-int/lit8 v4, v4, -0x1

    if-ge v3, v4, :cond_1e

    iget v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    add-int/lit8 v3, v3, 0x1

    iput v3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .end local v1    # "it\\1":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v2    # "$i$a$-also-LuauTranspiler$Parser$next$1\\1\\222\\0":I
    :cond_1e
    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    return-object v0
.end method

.method public final peek(I)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .registers 5
    .param p1, "o"    # I

    .line 221
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    iget v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    add-int/2addr v1, p1

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    return-object v0
.end method

.method public final primaryExpr()V
    .registers 4

    .line 484
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    .line 485
    .local v0, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    nop

    .line 486
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v1, v2, :cond_14

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_27

    .line 487
    :cond_14
    const-string v1, "("

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_28

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    const-string v1, ")"

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 490
    :goto_27
    return-void

    .line 488
    :cond_28
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v1
.end method

.method public final returnType()V
    .registers 6

    .line 413
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "("

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_56

    .line 414
    const-string v3, ")"

    invoke-virtual {p0, v4, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipBalanced(Ljava/lang/String;Ljava/lang/String;)V

    .line 415
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "->"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_26

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->type()V

    .line 416
    :cond_26
    :goto_26
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "?"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_36

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_26

    .line 417
    :cond_36
    :goto_36
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "|"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_4f

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "&"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_4f

    goto :goto_59

    :cond_4f
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->simpleType()V

    goto :goto_36

    .line 418
    :cond_56
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->type()V

    .line 419
    :goto_59
    return-void
.end method

.method public final run()V
    .registers 2

    .line 237
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->block()V

    .line 238
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->atEof()Z

    move-result v0

    if-eqz v0, :cond_a

    .line 239
    return-void

    .line 238
    :cond_a
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v0
.end method

.method public final setDepth(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 218
    iput p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->depth:I

    return-void
.end method

.method public final setLabelCounter(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 216
    iput p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->labelCounter:I

    return-void
.end method

.method public final setP(I)V
    .registers 2
    .param p1, "<set-?>"    # I

    .line 215
    iput p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    return-void
.end method

.method public final simpleExpr()V
    .registers 7

    .line 532
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    .line 533
    .local v3, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    nop

    .line 534
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NUMBER:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v4, v5, :cond_63

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v4, v5, :cond_63

    const-string v4, "nil"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_63

    const-string v4, "true"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_63

    const-string v4, "false"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_63

    const-string v4, "..."

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_63

    .line 535
    const-string v4, "{"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_44

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->table()V

    goto :goto_66

    .line 536
    :cond_44
    const-string v4, "function"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_53

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->funcBody()V

    goto :goto_66

    .line 537
    :cond_53
    const-string v4, "if"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_5f

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->ifExpr()V

    goto :goto_66

    .line 538
    :cond_5f
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->suffixedExpr()V

    goto :goto_66

    .line 534
    :cond_63
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 540
    :goto_66
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    const-string v1, "::"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7f

    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .local v0, "s":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->type()V

    iget v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->drop(II)V

    .line 541
    .end local v0    # "s":I
    :cond_7f
    return-void
.end method

.method public final simpleType()V
    .registers 10

    .line 428
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    .line 429
    .local v3, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    nop

    .line 430
    const-string v4, "<"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_18

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipAngle()V

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->simpleType()V

    goto/16 :goto_c4

    .line 431
    :cond_18
    const-string v5, "("

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v6

    const-string v7, ")"

    if-eqz v6, :cond_39

    .line 432
    invoke-virtual {p0, v5, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipBalanced(Ljava/lang/String;Ljava/lang/String;)V

    .line 433
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    const-string v5, "->"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_c4

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->type()V

    goto/16 :goto_c4

    .line 435
    :cond_39
    const-string v6, "{"

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_48

    const-string v4, "}"

    invoke-virtual {p0, v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipBalanced(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_c4

    .line 436
    :cond_48
    const-string v6, "typeof"

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isName(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_57

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0, v5, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipBalanced(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_c4

    .line 437
    :cond_57
    const-string v5, "..."

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_66

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->simpleType()V

    goto :goto_c4

    .line 438
    :cond_66
    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v6

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v6, v7, :cond_94

    const-string v6, "nil"

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_94

    const-string v6, "true"

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_94

    const-string v6, "false"

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_94

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v6

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v6, v7, :cond_94

    .line 445
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v0

    .line 439
    :cond_94
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 440
    :goto_97
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v6

    const-string v7, "."

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_aa

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_97

    .line 441
    :cond_aa
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v6

    invoke-virtual {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_b7

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipAngle()V

    .line 443
    :cond_b7
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_c4

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 447
    :cond_c4
    :goto_c4
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    const-string v5, "?"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_d4

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_c4

    .line 448
    :cond_d4
    return-void
.end method

.method public final skipAngle()V
    .registers 5

    .line 393
    const-string v0, "<"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 394
    const/4 v1, 0x1

    .line 395
    .local v1, "depth":I
    :cond_6
    :goto_6
    if-lez v1, :cond_31

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->atEof()Z

    move-result v2

    if-nez v2, :cond_31

    .line 396
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v2

    .line 397
    .local v2, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1b

    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    .line 398
    :cond_1b
    const-string v3, ">"

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_26

    add-int/lit8 v1, v1, -0x1

    goto :goto_6

    .line 399
    :cond_26
    const-string v3, ">="

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_6

    .end local v2    # "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    add-int/lit8 v1, v1, -0x1

    goto :goto_6

    .line 401
    :cond_31
    return-void
.end method

.method public final skipBalanced(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6
    .param p1, "open"    # Ljava/lang/String;
    .param p2, "close"    # Ljava/lang/String;

    const-string v0, "open"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "close"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 404
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 405
    const/4 v0, 0x1

    .line 406
    .local v0, "depth":I
    :cond_e
    :goto_e
    if-lez v0, :cond_2c

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->atEof()Z

    move-result v1

    if-nez v1, :cond_2c

    .line 407
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v1

    .line 408
    .local v1, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-virtual {v1, p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_23

    add-int/lit8 v0, v0, 0x1

    goto :goto_e

    :cond_23
    invoke-virtual {v1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_e

    .end local v1    # "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    add-int/lit8 v0, v0, -0x1

    goto :goto_e

    .line 410
    :cond_2c
    return-void
.end method

.method public final statement()V
    .registers 11

    .line 279
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    .line 280
    .local v3, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    nop

    .line 281
    const-string v4, ";"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_15

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto/16 :goto_2ca

    .line 282
    :cond_15
    const-string v4, "if"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    const-string v5, "end"

    if-eqz v4, :cond_5d

    .line 283
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    const-string v4, "then"

    invoke-virtual {p0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->block()V

    .line 284
    :goto_2d
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v6

    const-string v7, "elseif"

    invoke-virtual {v6, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_46

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    invoke-virtual {p0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->block()V

    goto :goto_2d

    .line 285
    :cond_46
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    const-string v1, "else"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_58

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->block()V

    .line 286
    :cond_58
    invoke-virtual {p0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto/16 :goto_2ca

    .line 288
    :cond_5d
    const-string v4, "while"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    const-string v6, "do"

    if-eqz v4, :cond_75

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    invoke-virtual {p0, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loopBody(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto/16 :goto_2ca

    .line 289
    :cond_75
    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_86

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->block()V

    invoke-virtual {p0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto/16 :goto_2ca

    .line 290
    :cond_86
    const-string v4, "for"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    const-string v7, "="

    const-string v8, ","

    if-eqz v4, :cond_137

    .line 291
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 292
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->nameWithType()V

    .line 293
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    invoke-virtual {v4, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_aa

    .line 294
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->exprList()V

    goto/16 :goto_12f

    .line 296
    :cond_aa
    :goto_aa
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    invoke-virtual {v4, v8}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_bb

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->nameWithType()V

    goto :goto_aa

    .line 297
    :cond_bb
    const-string v4, "in"

    invoke-virtual {p0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 299
    iget v4, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .line 300
    .local v4, "first":I
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    .line 301
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v7

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_e0

    :goto_cf
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v7

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_12f

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    goto :goto_cf

    .line 302
    :cond_e0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getPrefix()Ljava/lang/String;

    move-result-object v2

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "__iter("

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setPrefix(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    sub-int/2addr v2, v1

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getSuffix()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setSuffix(Ljava/lang/String;)V

    .line 304
    .end local v4    # "first":I
    :cond_12f
    :goto_12f
    invoke-virtual {p0, v6}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectKw(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 305
    invoke-virtual {p0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loopBody(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto/16 :goto_2ca

    .line 307
    :cond_137
    const-string v4, "repeat"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_14e

    .line 308
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 309
    const-string v0, "until"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loopBody(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 310
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto/16 :goto_2ca

    .line 312
    :cond_14e
    const-string v4, "function"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_182

    .line 313
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 314
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 315
    :goto_15c
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    const-string v5, "."

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_17b

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    const-string v5, ":"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_17b

    .line 316
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->funcBody()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto/16 :goto_2ca

    .line 315
    :cond_17b
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_15c

    .line 318
    :cond_182
    const-string v5, "local"

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_204

    .line 319
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v5

    .line 320
    .local v5, "localTok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    iget-boolean v6, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->hoist:Z

    if-eqz v6, :cond_198

    iget v6, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->depth:I

    if-ne v6, v1, :cond_198

    move v6, v1

    goto :goto_199

    :cond_198
    move v6, v0

    .line 321
    .local v6, "hoistThis":Z
    :goto_199
    if-eqz v6, :cond_1a0

    const-string v9, ""

    invoke-virtual {v5, v9}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 322
    :cond_1a0
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v9

    invoke-virtual {v9, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1b4

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->funcBody()V

    goto :goto_200

    .line 324
    :cond_1b4
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->localName()V

    .line 325
    :goto_1b7
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    invoke-virtual {v4, v8}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1c8

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->localName()V

    goto :goto_1b7

    .line 326
    :cond_1c8
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    invoke-virtual {v0, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1d9

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->exprList()V

    goto :goto_200

    .line 327
    :cond_1d9
    if-eqz v6, :cond_200

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    iget v2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    sub-int/2addr v2, v1

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getSuffix()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " = nil"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setSuffix(Ljava/lang/String;)V

    .end local v5    # "localTok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v6    # "hoistThis":Z
    :cond_200
    :goto_200
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto/16 :goto_2ca

    .line 330
    :cond_204
    const-string v0, "break"

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_211

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto/16 :goto_2ca

    .line 331
    :cond_211
    const-string v0, "goto"

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_221

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto/16 :goto_2ca

    .line 332
    :cond_221
    const-string v0, "::"

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_234

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto/16 :goto_2ca

    .line 333
    :cond_234
    const-string v0, "continue"

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isName(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_278

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->isStatementWord()Z

    move-result v0

    if-eqz v0, :cond_278

    .line 334
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    .line 335
    .local v0, "tok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->loops:Ljava/util/ArrayList;

    check-cast v2, Ljava/util/List;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->lastOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;

    if-eqz v2, :cond_272

    .line 336
    .local v2, "ctx":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;
    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->setUsesContinue(Z)V

    .line 337
    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;->getId()I

    move-result v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "goto __continue"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .end local v0    # "tok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v2    # "ctx":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$LoopCtx;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_2ca

    .line 335
    .restart local v0    # "tok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    :cond_272
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v1

    .line 339
    .end local v0    # "tok":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    :cond_278
    const-string v0, "type"

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isName(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2ab

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek(I)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v2

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v2, v4, :cond_2ab

    const/4 v2, 0x2

    invoke-virtual {p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek(I)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    invoke-virtual {v4, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_2a3

    invoke-virtual {p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek(I)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v2

    const-string v4, "<"

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2ab

    :cond_2a3
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->typeDecl(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_2ca

    .line 340
    :cond_2ab
    const-string v2, "export"

    invoke-virtual {v3, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isName(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2c5

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek(I)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isName(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2c5

    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->typeDecl(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_2ca

    .line 341
    :cond_2c5
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->exprStatement()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 343
    :goto_2ca
    return-void
.end method

.method public final subExpr(I)V
    .registers 13
    .param p1, "limit"    # I

    .line 575
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    .line 576
    .local v0, "start":I
    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    .line 577
    .local v4, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    const-string v5, "not"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isKw(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_25

    const-string v5, "-"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_25

    const-string v5, "#"

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_25

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->simpleExpr()V

    goto :goto_2d

    :cond_25
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    const/16 v5, 0xc

    invoke-virtual {p0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->subExpr(I)V

    .line 578
    :cond_2d
    :goto_2d
    nop

    .line 579
    invoke-static {p0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v5

    .line 580
    .local v5, "op":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    invoke-direct {p0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->binPrio(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;)Lkotlin/Pair;

    move-result-object v6

    if-eqz v6, :cond_b2

    .line 581
    .local v6, "pr":Lkotlin/Pair;
    invoke-virtual {v6}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    if-le v7, p1, :cond_b2

    .line 582
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 583
    invoke-virtual {v6}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    invoke-virtual {p0, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->subExpr(I)V

    .line 584
    const-string v7, "//"

    invoke-virtual {v5, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_2d

    .line 585
    const-string v7, "/"

    invoke-virtual {v5, v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setOut(Ljava/lang/String;)V

    .line 586
    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v7, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    iget-object v8, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    invoke-interface {v8, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getPrefix()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "math.floor("

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setPrefix(Ljava/lang/String;)V

    .line 587
    iget-object v7, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->t:Ljava/util/List;

    iget v8, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    sub-int/2addr v8, v2

    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getSuffix()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ")"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->setSuffix(Ljava/lang/String;)V

    .end local v5    # "op":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    .end local v6    # "pr":Lkotlin/Pair;
    goto/16 :goto_2d

    .line 590
    :cond_b2
    return-void
.end method

.method public final suffixedExpr()V
    .registers 7

    .line 493
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->primaryExpr()V

    .line 494
    :goto_3
    nop

    .line 495
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    .line 496
    .local v3, "k":Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
    nop

    .line 497
    const-string v4, "."

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_39

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v4, v5, :cond_35

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->KEYWORD:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v0, v1, :cond_35

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$ParseError;-><init>()V

    throw v0

    :cond_35
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_3

    .line 498
    :cond_39
    const-string v0, "["

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4d

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    const-string v0, "]"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_3

    .line 499
    :cond_4d
    const-string v0, ":"

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_5f

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->callArgs()V

    goto :goto_3

    .line 500
    :cond_5f
    const-string v0, "("

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_78

    const-string v0, "{"

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_78

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v0

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->STRING:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-eq v0, v1, :cond_78

    .line 501
    return-void

    .line 500
    :cond_78
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->callArgs()V

    goto :goto_3
.end method

.method public final table()V
    .registers 8

    .line 521
    const-string v0, "{"

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 522
    :goto_5
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "}"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_74

    .line 523
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v5, "["

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    const-string v5, "="

    if-eqz v3, :cond_34

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    const-string v3, "]"

    invoke-virtual {p0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    goto :goto_57

    .line 524
    :cond_34
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    move-result-object v3

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v3, v6, :cond_54

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek(I)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_54

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    goto :goto_57

    .line 525
    :cond_54
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expr()V

    .line 526
    :goto_57
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v5, ","

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_70

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    const-string v1, ";"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_70

    goto :goto_74

    :cond_70
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    goto :goto_5

    .line 528
    :cond_74
    :goto_74
    invoke-virtual {p0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 529
    return-void
.end method

.method public final type()V
    .registers 7

    .line 422
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "|"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    const-string v5, "&"

    if-nez v3, :cond_1c

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1c

    goto :goto_1f

    :cond_1c
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 423
    :goto_1f
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->simpleType()V

    .line 424
    :goto_22
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_37

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    invoke-virtual {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_37

    .line 425
    return-void

    .line 424
    :cond_37
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->simpleType()V

    goto :goto_22
.end method

.method public final typeDecl(I)V
    .registers 7
    .param p1, "start"    # I

    .line 352
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v3

    const-string v4, "export"

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isName(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_12

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 353
    :cond_12
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->next()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 354
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectName()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 355
    invoke-static {p0, v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->peek$default(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;IILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    move-result-object v0

    const-string v1, "<"

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->isOp(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_27

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->skipAngle()V

    .line 356
    :cond_27
    const-string v0, "="

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->expectOp(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    .line 357
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->type()V

    .line 358
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->p:I

    invoke-virtual {p0, p1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->drop(II)V

    .line 359
    return-void
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuauTranspiler$Parser$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.lua.LuauTranspiler$Parser$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;"
    method = "exprStatement$lambda$2"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;I)Ljava/lang/CharSequence;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser$$ExternalSyntheticLambda0;->f$0:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;

    check-cast p1, Ljava/lang/Integer;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;->exprStatement$lambda$2(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Parser;I)Ljava/lang/CharSequence;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuauTranspiler.Tok (com.exampletest.mobilestudiotest.lua.LuauTranspiler$Tok)
.class final Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;
.super Ljava/lang/Object;
.source "LuauTranspiler.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Tok"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0013\n\u0002\u0010\u000b\n\u0002\u0008\u0004\u0008\u0002\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u000e\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0005J\u000e\u0010\u001b\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0005J\u000e\u0010\u001c\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0005R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000cR\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000cR\u001a\u0010\u000e\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u000f\u0010\u000c\"\u0004\u0008\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0013\u0010\u000c\"\u0004\u0008\u0014\u0010\u0011R\u001a\u0010\u0015\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0016\u0010\u000c\"\u0004\u0008\u0017\u0010\u0011\u00a8\u0006\u001d"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;",
        "",
        "k",
        "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;",
        "text",
        "",
        "trivia",
        "<init>",
        "(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V",
        "getK",
        "()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;",
        "getText",
        "()Ljava/lang/String;",
        "getTrivia",
        "out",
        "getOut",
        "setOut",
        "(Ljava/lang/String;)V",
        "prefix",
        "getPrefix",
        "setPrefix",
        "suffix",
        "getSuffix",
        "setSuffix",
        "isOp",
        "",
        "s",
        "isKw",
        "isName",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final k:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

.field private out:Ljava/lang/String;

.field private prefix:Ljava/lang/String;

.field private suffix:Ljava/lang/String;

.field private final text:Ljava/lang/String;

.field private final trivia:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "k"    # Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "trivia"    # Ljava/lang/String;

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "text"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "trivia"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->k:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->text:Ljava/lang/String;

    iput-object p3, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->trivia:Ljava/lang/String;

    .line 13
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->text:Ljava/lang/String;

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->out:Ljava/lang/String;

    .line 14
    const-string v0, ""

    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->prefix:Ljava/lang/String;

    .line 15
    iput-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->suffix:Ljava/lang/String;

    .line 12
    return-void
.end method


# virtual methods
.method public final getK()Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;
    .registers 2

    .line 12
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->k:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    return-object v0
.end method

.method public final getOut()Ljava/lang/String;
    .registers 2

    .line 13
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->out:Ljava/lang/String;

    return-object v0
.end method

.method public final getPrefix()Ljava/lang/String;
    .registers 2

    .line 14
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->prefix:Ljava/lang/String;

    return-object v0
.end method

.method public final getSuffix()Ljava/lang/String;
    .registers 2

    .line 15
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->suffix:Ljava/lang/String;

    return-object v0
.end method

.method public final getText()Ljava/lang/String;
    .registers 2

    .line 12
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->text:Ljava/lang/String;

    return-object v0
.end method

.method public final getTrivia()Ljava/lang/String;
    .registers 2

    .line 12
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->trivia:Ljava/lang/String;

    return-object v0
.end method

.method public final isKw(Ljava/lang/String;)Z
    .registers 4
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->k:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->KEYWORD:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v0, v1, :cond_15

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->text:Ljava/lang/String;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    const/4 v0, 0x1

    goto :goto_16

    :cond_15
    const/4 v0, 0x0

    :goto_16
    return v0
.end method

.method public final isName(Ljava/lang/String;)Z
    .registers 4
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->k:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->NAME:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v0, v1, :cond_15

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->text:Ljava/lang/String;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    const/4 v0, 0x1

    goto :goto_16

    :cond_15
    const/4 v0, 0x0

    :goto_16
    return v0
.end method

.method public final isOp(Ljava/lang/String;)Z
    .registers 4
    .param p1, "s"    # Ljava/lang/String;

    const-string v0, "s"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->k:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;->OP:Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$K;

    if-ne v0, v1, :cond_15

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->text:Ljava/lang/String;

    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    const/4 v0, 0x1

    goto :goto_16

    :cond_15
    const/4 v0, 0x0

    :goto_16
    return v0
.end method

.method public final setOut(Ljava/lang/String;)V
    .registers 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->out:Ljava/lang/String;

    return-void
.end method

.method public final setPrefix(Ljava/lang/String;)V
    .registers 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->prefix:Ljava/lang/String;

    return-void
.end method

.method public final setSuffix(Ljava/lang/String;)V
    .registers 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;->suffix:Ljava/lang/String;

    return-void
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuauTranspiler$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.lua.LuauTranspiler$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;"
    method = "transpile$lambda$3"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;)Ljava/lang/CharSequence;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler;->transpile$lambda$3(Lcom/exampletest/mobilestudiotest/lua/LuauTranspiler$Tok;)Ljava/lang/CharSequence;

    move-result-object p1

    return-object p1
.end method
