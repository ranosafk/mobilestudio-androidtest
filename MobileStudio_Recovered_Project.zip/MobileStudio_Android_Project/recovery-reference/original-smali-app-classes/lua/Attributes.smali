###### Class com.exampletest.mobilestudiotest.lua.Attributes (com.exampletest.mobilestudiotest.lua.Attributes)
.class public final Lcom/exampletest/mobilestudiotest/lua/Attributes;
.super Ljava/lang/Object;
.source "InstanceApi.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010#\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\u0008\u00c6\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0006R2\u0010\u0004\u001a&\u0012\u000c\u0012\n \u0007*\u0004\u0018\u00010\u00060\u0006 \u0007*\u0012\u0012\u000c\u0012\n \u0007*\u0004\u0018\u00010\u00060\u0006\u0018\u00010\u00080\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000c"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/Attributes;",
        "",
        "<init>",
        "()V",
        "loaded",
        "",
        "Lcom/exampletest/mobilestudiotest/model/Instance;",
        "kotlin.jvm.PlatformType",
        "",
        "load",
        "",
        "i",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

.field private static final loaded:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Lcom/exampletest/mobilestudiotest/model/Instance;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/Attributes;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/Attributes;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/Attributes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/Attributes;

    .line 978
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    check-cast v0, Ljava/util/Map;

    invoke-static {v0}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/Attributes;->loaded:Ljava/util/Set;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 977
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final load$str(Ljava/nio/ByteBuffer;)Ljava/lang/String;
    .registers 5
    .param p0, "bb"    # Ljava/nio/ByteBuffer;

    .line 990
    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v0

    .local v0, "n":I
    new-array v1, v0, [B

    .local v1, "b":[B
    invoke-virtual {p0, v1}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    new-instance v2, Ljava/lang/String;

    sget-object v3, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, v1, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    return-object v2
.end method


# virtual methods
.method public final load(Lcom/exampletest/mobilestudiotest/model/Instance;)V
    .registers 15
    .param p1, "i"    # Lcom/exampletest/mobilestudiotest/model/Instance;

    const-string v0, "i"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 981
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/Attributes;->loaded:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e

    return-void

    .line 982
    :cond_e
    const-string v0, "AttributesSerialize"

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/model/Instance;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    .line 983
    .local v0, "v":Ljava/lang/Object;
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    if-eqz v1, :cond_20

    move-object v1, v0

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/BinaryString;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/BinaryString;->getBytes()[B

    move-result-object v1

    goto :goto_32

    .line 984
    :cond_20
    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_13d

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    sget-object v2, Lkotlin/text/Charsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    invoke-virtual {v1, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    const-string v2, "getBytes(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 982
    .end local v0    # "v":Ljava/lang/Object;
    :goto_32
    nop

    .line 987
    .local v1, "blob":[B
    array-length v0, v1

    const/4 v2, 0x4

    if-ge v0, v2, :cond_38

    return-void

    .line 988
    :cond_38
    nop

    .line 989
    :try_start_39
    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    sget-object v2, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v0, v2}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v0

    .line 991
    .local v0, "bb":Ljava/nio/ByteBuffer;
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v2

    .line 992
    .local v2, "count":I
    const/4 v3, 0x0

    move v4, v3

    :goto_49
    if-ge v4, v2, :cond_13c

    move v5, v4

    .local v5, "it\\1":I
    const/4 v6, 0x0

    .line 993
    .local v6, "$i$a$-repeat-Attributes$load$1\\1\\992\\0":I
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load$str(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object v7

    .line 994
    .local v7, "key\\1":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->get()B

    move-result v8

    and-int/lit16 v8, v8, 0xff

    sparse-switch v8, :sswitch_data_13e

    .line 1007
    return-void

    .line 1006
    :sswitch_5b
    new-instance v8, Lcom/exampletest/mobilestudiotest/model/Rect;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v9

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v10

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v11

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v12

    invoke-direct {v8, v9, v10, v11, v12}, Lcom/exampletest/mobilestudiotest/model/Rect;-><init>(FFFF)V

    goto/16 :goto_106

    .line 1005
    :sswitch_72
    new-instance v8, Lcom/exampletest/mobilestudiotest/model/NumberRange;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v9

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v10

    invoke-direct {v8, v9, v10}, Lcom/exampletest/mobilestudiotest/model/NumberRange;-><init>(FF)V

    goto/16 :goto_106

    .line 1004
    :sswitch_81
    new-instance v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v9

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v10

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v11

    invoke-direct {v8, v9, v10, v11}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    goto/16 :goto_106

    .line 1003
    :sswitch_94
    new-instance v8, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v9

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v10

    invoke-direct {v8, v9, v10}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    goto :goto_106

    .line 1002
    :sswitch_a2
    new-instance v8, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v9

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v10

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v11

    invoke-direct {v8, v9, v10, v11}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    goto :goto_106

    .line 1001
    :sswitch_b4
    new-instance v8, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v9

    invoke-direct {v8, v9}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    goto :goto_106

    .line 1000
    :sswitch_be
    new-instance v8, Lcom/exampletest/mobilestudiotest/model/UDim2;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v9

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v10

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v11

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v12

    invoke-direct {v8, v9, v10, v11, v12}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    goto :goto_106

    .line 999
    :sswitch_d4
    new-instance v8, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v9

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result v10

    invoke-direct {v8, v9, v10}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    goto :goto_106

    .line 998
    :sswitch_e2
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getDouble()D

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v8

    goto :goto_106

    .line 997
    :sswitch_eb
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getFloat()F

    move-result v8

    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v8

    goto :goto_106

    .line 996
    :sswitch_f4
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->get()B

    move-result v8

    if-eqz v8, :cond_fc

    const/4 v8, 0x1

    goto :goto_fd

    :cond_fc
    move v8, v3

    :goto_fd
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    goto :goto_106

    .line 995
    :sswitch_102
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/Attributes;->load$str(Ljava/nio/ByteBuffer;)Ljava/lang/String;

    move-result-object v8

    .line 994
    :goto_106
    nop

    .line 1009
    .local v8, "v\\1":Ljava/lang/Object;
    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_11a

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->getAttributes()Ljava/util/LinkedHashMap;

    move-result-object v9

    check-cast v9, Ljava/util/Map;

    invoke-interface {v9, v7, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_11a
    .catch Ljava/lang/Exception; {:try_start_39 .. :try_end_11a} :catch_11f

    .line 1010
    :cond_11a
    nop

    .line 992
    .end local v5    # "it\\1":I
    .end local v6    # "$i$a$-repeat-Attributes$load$1\\1\\992\\0":I
    .end local v7    # "key\\1":Ljava/lang/String;
    .end local v8    # "v\\1":Ljava/lang/Object;
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_49

    .line 1011
    .end local v0    # "bb":Ljava/nio/ByteBuffer;
    .end local v2    # "count":I
    :catch_11f
    move-exception v0

    .line 1012
    .local v0, "e":Ljava/lang/Exception;
    sget-object v2, Lcom/exampletest/mobilestudiotest/core/OutputLog;->INSTANCE:Lcom/exampletest/mobilestudiotest/core/OutputLog;

    invoke-virtual {p1}, Lcom/exampletest/mobilestudiotest/model/Instance;->fullName()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Could not read attributes of "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/core/OutputLog;->warn(Ljava/lang/String;)V

    .line 1014
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_13c
    return-void

    .line 985
    .end local v1    # "blob":[B
    .local v0, "v":Ljava/lang/Object;
    :cond_13d
    return-void

    :sswitch_data_13e
    .sparse-switch
        0x2 -> :sswitch_102
        0x3 -> :sswitch_f4
        0x5 -> :sswitch_eb
        0x6 -> :sswitch_e2
        0x9 -> :sswitch_d4
        0xa -> :sswitch_be
        0xe -> :sswitch_b4
        0xf -> :sswitch_a2
        0x10 -> :sswitch_94
        0x11 -> :sswitch_81
        0x1b -> :sswitch_72
        0x1c -> :sswitch_5b
    .end sparse-switch
.end method
