###### Class com.exampletest.mobilestudiotest.lua.InstanceApiKt (com.exampletest.mobilestudiotest.lua.InstanceApiKt)
.class public final Lcom/exampletest/mobilestudiotest/lua/InstanceApiKt;
.super Ljava/lang/Object;
.source "InstanceApi.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0003"
    }
    d2 = {
        "DEG",
        "",
        "RAD",
        "app"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final DEG:F = 57.29578f

.field private static final RAD:F = 0.017453292f
