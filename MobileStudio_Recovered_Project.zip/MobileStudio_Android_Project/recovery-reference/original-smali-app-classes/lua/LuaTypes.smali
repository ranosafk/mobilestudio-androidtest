###### Class com.exampletest.mobilestudiotest.lua.LuaTypes (com.exampletest.mobilestudiotest.lua.LuaTypes)
.class public final Lcom/exampletest/mobilestudiotest/lua/LuaTypes;
.super Ljava/lang/Object;
.source "LuaTypes.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLuaTypes.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LuaTypes.kt\ncom/exampletest/mobilestudiotest/lua/LuaTypes\n+ 2 LuaTypes.kt\ncom/exampletest/mobilestudiotest/lua/LuaTypesKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 5 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 6 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 7 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,604:1\n40#2:605\n40#2:606\n40#2:607\n40#2:608\n40#2:609\n40#2:610\n40#2:611\n40#2:612\n40#2:613\n40#2:614\n40#2:615\n40#2:616\n40#2:617\n40#2:618\n40#2:619\n40#2:620\n40#2:621\n40#2:622\n40#2:623\n40#2:624\n40#2:625\n40#2:626\n40#2:627\n40#2:628\n40#2:629\n40#2:630\n40#2:631\n40#2:632\n40#2:633\n40#2:634\n40#2:643\n40#2:644\n40#2:645\n40#2:646\n40#2:647\n40#2:648\n40#2:649\n40#2:650\n40#2:651\n40#2:652\n40#2:653\n40#2:654\n40#2:655\n40#2:656\n40#2:660\n41#2:667\n41#2:668\n40#2:669\n40#2:670\n40#2,2:671\n40#2,2:673\n40#2:675\n40#2:676\n41#2:677\n40#2:678\n40#2:679\n40#2:680\n41#2:681\n40#2:682\n41#2:683\n41#2:684\n40#2:685\n40#2:689\n40#2:694\n40#2:696\n40#2:697\n41#2:698\n41#2:699\n11278#3:635\n11613#3,3:636\n37#4:639\n36#4,3:640\n216#5,2:657\n1#6:659\n1869#7,2:661\n1869#7,2:663\n1869#7,2:665\n1563#7:686\n1634#7,2:687\n1636#7:690\n1563#7:691\n1634#7,2:692\n1636#7:695\n*S KotlinDebug\n*F\n+ 1 LuaTypes.kt\ncom/exampletest/mobilestudiotest/lua/LuaTypes\n*L\n84#1:605\n107#1:606\n108#1:607\n111#1:608\n112#1:609\n113#1:610\n118#1:611\n119#1:612\n120#1:613\n123#1:614\n132#1:615\n133#1:616\n137#1:617\n138#1:618\n141#1:619\n142#1:620\n143#1:621\n146#1:622\n147#1:623\n160#1:624\n161#1:625\n162#1:626\n163#1:627\n164#1:628\n165#1:629\n166#1:630\n167#1:631\n168#1:632\n169#1:633\n170#1:634\n171#1:643\n173#1:644\n183#1:645\n191#1:646\n192#1:647\n199#1:648\n200#1:649\n201#1:650\n221#1:651\n222#1:652\n230#1:653\n234#1:654\n235#1:655\n236#1:656\n289#1:660\n411#1:667\n414#1:668\n435#1:669\n436#1:670\n449#1:671,2\n450#1:673,2\n451#1:675\n453#1:676\n454#1:677\n464#1:678\n473#1:679\n486#1:680\n496#1:681\n501#1:682\n504#1:683\n510#1:684\n515#1:685\n520#1:689\n530#1:694\n531#1:696\n532#1:697\n545#1:698\n546#1:699\n170#1:635\n170#1:636,3\n170#1:639\n170#1:640,3\n257#1:657,2\n341#1:661,2\n349#1:663,2\n396#1:665,2\n520#1:686\n520#1:687,2\n520#1:690\n530#1:691\n530#1:692,2\n530#1:695\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0010\u0008\u00c6\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u000cJ\u000e\u0010\r\u001a\u00020\u000c2\u0006\u0010\u000e\u001a\u00020\u0001J\u0010\u0010\u000f\u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020\nH\u0002JS\u0010\u0011\u001a\u00020\u00122\n\u0010\u0013\u001a\u0006\u0012\u0002\u0008\u00030\u00062\u0006\u0010\u0014\u001a\u00020\n2\u001a\u0010\u0015\u001a\u0016\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\n\u0012\u0006\u0012\u0004\u0018\u00010\u000c0\u00162\u0019\u0008\u0002\u0010\u0017\u001a\u0013\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00120\u0018\u00a2\u0006\u0002\u0008\u0019H\u0002J\u001c\u0010\u001a\u001a\u00020\u000c2\u0012\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u001c0\u0018H\u0002J\u0010\u0010\u001d\u001a\u00020\u000c2\u0006\u0010\u000b\u001a\u00020\u001eH\u0002J\u000e\u0010\u001f\u001a\u00020\u000c2\u0006\u0010\u000b\u001a\u00020 J\u0018\u0010!\u001a\u00020 2\u0006\u0010\"\u001a\u00020\u001c2\u0006\u0010#\u001a\u00020$H\u0002J\u0018\u0010%\u001a\u0004\u0018\u00010\u000c2\u0006\u0010&\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\nJ\u0006\u0010\'\u001a\u00020\u000cJ\u000e\u0010(\u001a\u00020\u00122\u0006\u0010)\u001a\u00020\u0007J\u001e\u0010*\u001a\u00020\u001e2\u0006\u0010+\u001a\u00020$2\u0006\u0010,\u001a\u00020$2\u0006\u0010-\u001a\u00020\u001eJ\u0010\u0010.\u001a\u00020\u001e2\u0006\u0010/\u001a\u00020\u001eH\u0002J$\u00100\u001a\u0004\u0018\u00010\u00012\u0008\u0010\"\u001a\u0004\u0018\u00010\u00012\u0008\u00101\u001a\u0004\u0018\u00010\u00012\u0006\u00102\u001a\u00020\u001eJ\u000e\u00103\u001a\u00020\u001e2\u0006\u0010/\u001a\u00020\u001eR2\u0010\u0004\u001a&\u0012\u0008\u0012\u0006\u0012\u0002\u0008\u00030\u0006\u0012\u0004\u0012\u00020\u00070\u0005j\u0012\u0012\u0008\u0012\u0006\u0012\u0002\u0008\u00030\u0006\u0012\u0004\u0012\u00020\u0007`\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u00064"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;",
        "",
        "<init>",
        "()V",
        "metas",
        "Ljava/util/HashMap;",
        "Ljava/lang/Class;",
        "Lorg/luaj/vm2/LuaTable;",
        "Lkotlin/collections/HashMap;",
        "typeOf",
        "",
        "v",
        "Lorg/luaj/vm2/LuaValue;",
        "wrap",
        "o",
        "generic",
        "name",
        "meta",
        "",
        "cls",
        "typeName",
        "index",
        "Lkotlin/Function2;",
        "extra",
        "Lkotlin/Function1;",
        "Lkotlin/ExtensionFunctionType;",
        "method",
        "f",
        "Lorg/luaj/vm2/Varargs;",
        "n",
        "",
        "v3",
        "Lcom/exampletest/mobilestudiotest/model/Vector3;",
        "arg3",
        "a",
        "i",
        "",
        "enumItem",
        "type",
        "enumLib",
        "install",
        "g",
        "ease",
        "style",
        "dir",
        "t0",
        "bounceOut",
        "x",
        "lerpValue",
        "b",
        "t",
        "absf",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

.field private static final metas:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Class<",
            "*>;",
            "Lorg/luaj/vm2/LuaTable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 19

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    .line 44
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->metas:Ljava/util/HashMap;

    .line 86
    nop

    .line 87
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda15;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda15;-><init>()V

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda26;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda26;-><init>()V

    const-string v4, "Vector3"

    invoke-direct {v0, v1, v4, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 126
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda37;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda37;-><init>()V

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda38;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda38;-><init>()V

    const-string v4, "Vector2"

    invoke-direct {v0, v1, v4, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 150
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda39;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda39;-><init>()V

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda40;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda40;-><init>()V

    const-string v4, "CFrame"

    invoke-direct {v0, v1, v4, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 195
    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v6, Lcom/exampletest/mobilestudiotest/model/Color3;

    new-instance v8, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda41;

    invoke-direct {v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda41;-><init>()V

    const/16 v10, 0x8

    const/4 v11, 0x0

    const-string v7, "Color3"

    const/4 v9, 0x0

    invoke-static/range {v5 .. v11}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 206
    sget-object v12, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v13, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    new-instance v15, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda42;

    invoke-direct {v15}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda42;-><init>()V

    const/16 v17, 0x8

    const/16 v18, 0x0

    const-string v14, "BrickColor"

    const/16 v16, 0x0

    invoke-static/range {v12 .. v18}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 217
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/UDim;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda43;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda43;-><init>()V

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda44;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda44;-><init>()V

    const-string v4, "UDim"

    invoke-direct {v0, v1, v4, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 225
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda16;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda16;-><init>()V

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda17;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda17;-><init>()V

    const-string v4, "UDim2"

    invoke-direct {v0, v1, v4, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 239
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda18;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda18;-><init>()V

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda19;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda19;-><init>()V

    const-string v4, "EnumItem"

    invoke-direct {v0, v1, v4, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 252
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda20;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda20;-><init>()V

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda21;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda21;-><init>()V

    const-string v4, "Enum"

    invoke-direct {v0, v1, v4, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 268
    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v6, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;

    new-instance v8, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda22;

    invoke-direct {v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda22;-><init>()V

    const-string v7, "TweenInfo"

    invoke-static/range {v5 .. v11}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 279
    sget-object v12, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v13, Lcom/exampletest/mobilestudiotest/model/NumberRange;

    new-instance v15, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda23;

    invoke-direct {v15}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda23;-><init>()V

    const-string v14, "NumberRange"

    invoke-static/range {v12 .. v18}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 284
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/Ray;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda24;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda24;-><init>()V

    const/16 v5, 0x8

    const/4 v6, 0x0

    const-string v2, "Ray"

    const/4 v4, 0x0

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 296
    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v8, Lcom/exampletest/mobilestudiotest/lua/Region3V;

    new-instance v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda25;

    invoke-direct {v10}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda25;-><init>()V

    const/16 v12, 0x8

    const/4 v13, 0x0

    const-string v9, "Region3"

    invoke-static/range {v7 .. v13}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 309
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/lua/Region3int16V;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda27;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda27;-><init>()V

    const-string v2, "Region3int16"

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 314
    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v8, Lcom/exampletest/mobilestudiotest/lua/RandomV;

    new-instance v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda28;

    invoke-direct {v10}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda28;-><init>()V

    const-string v9, "Random"

    invoke-static/range {v7 .. v13}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 330
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/lua/RaycastResultV;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda29;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda29;-><init>()V

    const-string v2, "RaycastResult"

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 339
    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v8, Lcom/exampletest/mobilestudiotest/model/NumberSequence;

    new-instance v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda30;

    invoke-direct {v10}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda30;-><init>()V

    const-string v9, "NumberSequence"

    invoke-static/range {v7 .. v13}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 343
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda31;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda31;-><init>()V

    const-string v2, "NumberSequenceKeypoint"

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 347
    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v8, Lcom/exampletest/mobilestudiotest/model/ColorSequence;

    new-instance v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda32;

    invoke-direct {v10}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda32;-><init>()V

    const-string v9, "ColorSequence"

    invoke-static/range {v7 .. v13}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 351
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda33;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda33;-><init>()V

    const-string v2, "ColorSequenceKeypoint"

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 355
    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v8, Lcom/exampletest/mobilestudiotest/model/FontValue;

    new-instance v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda34;

    invoke-direct {v10}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda34;-><init>()V

    const-string v9, "Font"

    invoke-static/range {v7 .. v13}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 365
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v1, Lcom/exampletest/mobilestudiotest/model/Rect;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda35;

    invoke-direct {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda35;-><init>()V

    const-string v2, "Rect"

    invoke-static/range {v0 .. v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 373
    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-class v8, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;

    new-instance v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda36;

    invoke-direct {v10}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda36;-><init>()V

    const-string v9, "PhysicalProperties"

    invoke-static/range {v7 .. v13}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V

    .line 381
    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 43
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static final _init_$lambda$100(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 7
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 366
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Rect;

    .line 367
    .local v0, "r":Lcom/exampletest/mobilestudiotest/model/Rect;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_78

    goto :goto_64

    :sswitch_15
    const-string v1, "Width"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_64

    .line 369
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Rect;->getMaxX()F

    move-result v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Rect;->getMinX()F

    move-result v3

    goto :goto_6f

    .line 367
    :sswitch_28
    const-string v1, "Min"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_64

    .line 368
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Rect;->getMinX()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Rect;->getMinY()F

    move-result v4

    invoke-direct {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    goto :goto_57

    .line 367
    :sswitch_40
    const-string v1, "Max"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_64

    .line 368
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Rect;->getMaxX()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Rect;->getMaxY()F

    move-result v4

    invoke-direct {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    :goto_57
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_76

    .line 367
    :sswitch_5c
    const-string v1, "Height"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_65

    :cond_64
    :goto_64
    goto :goto_75

    .line 369
    :cond_65
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Rect;->getMaxY()F

    move-result v2

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Rect;->getMinY()F

    move-result v3

    :goto_6f
    sub-float/2addr v2, v3

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_76

    .line 370
    :goto_75
    const/4 v1, 0x0

    .line 371
    :goto_76
    return-object v1

    nop

    :sswitch_data_78
    .sparse-switch
        -0x7f6282b9 -> :sswitch_5c
        0x12d44 -> :sswitch_40
        0x12e32 -> :sswitch_28
        0x4fb3da6 -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$101(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 374
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;

    .line 375
    .local v0, "p":Lcom/exampletest/mobilestudiotest/model/PhysicalProps;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_6c

    goto :goto_5d

    :sswitch_15
    const-string v1, "Elasticity"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5d

    .line 376
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;->getElasticity()F

    move-result v2

    goto :goto_50

    .line 375
    :sswitch_24
    const-string v1, "ElasticityWeight"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5d

    .line 377
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;->getElasticityWeight()F

    move-result v2

    goto :goto_64

    .line 375
    :sswitch_33
    const-string v1, "Density"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5d

    .line 376
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;->getDensity()F

    move-result v2

    goto :goto_50

    .line 375
    :sswitch_42
    const-string v1, "Friction"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5d

    .line 376
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;->getFriction()F

    move-result v2

    :goto_50
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_6a

    .line 375
    :sswitch_55
    const-string v1, "FrictionWeight"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5e

    :cond_5d
    :goto_5d
    goto :goto_69

    .line 377
    :cond_5e
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;->getFrictionWeight()F

    move-result v2

    :goto_64
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_6a

    .line 378
    :goto_69
    const/4 v1, 0x0

    .line 379
    :goto_6a
    return-object v1

    nop

    :sswitch_data_6c
    .sparse-switch
        -0x699521ce -> :sswitch_55
        -0x511114e6 -> :sswitch_42
        -0x403ad338 -> :sswitch_33
        -0xd64024f -> :sswitch_24
        0x505155d9 -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$17(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 89
    .local v0, "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_190

    goto/16 :goto_182

    :sswitch_16
    const-string v1, "FuzzyEq"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 103
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda152;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda152;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_2b
    const-string v1, "Floor"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 97
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda156;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda156;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_40
    const-string v1, "Cross"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 94
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda153;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda153;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_55
    const-string v1, "Angle"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 102
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda161;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda161;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_6a
    const-string v1, "unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_86

    goto/16 :goto_182

    :sswitch_74
    const-string v1, "lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_af

    goto/16 :goto_182

    :sswitch_7e
    const-string v1, "Unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 92
    :cond_86
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_92
    const-string v1, "Sign"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 99
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda158;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda158;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_a7
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 95
    :cond_af
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda154;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda154;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_bc
    const-string v1, "Ceil"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 98
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda157;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda157;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_d1
    const-string v1, "Min"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 100
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda159;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda159;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_e6
    const-string v1, "Max"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 101
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda160;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda160;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_fb
    const-string v1, "Dot"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 93
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda151;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda151;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_110
    const-string v1, "Abs"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 96
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda155;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda155;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_18f

    .line 89
    :sswitch_125
    const-string v1, "z"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_148

    goto :goto_182

    :sswitch_12e
    const-string v1, "y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_157

    goto :goto_182

    :sswitch_137
    const-string v1, "x"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_166

    goto :goto_182

    :sswitch_140
    const-string v1, "Z"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 90
    :cond_148
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v2

    goto :goto_16c

    .line 89
    :sswitch_14f
    const-string v1, "Y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 90
    :cond_157
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v2

    goto :goto_16c

    .line 89
    :sswitch_15e
    const-string v1, "X"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_182

    .line 90
    :cond_166
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v2

    :goto_16c
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_18f

    .line 89
    :sswitch_171
    const-string v1, "Magnitude"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_183

    goto :goto_182

    :sswitch_17a
    const-string v1, "magnitude"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_183

    :cond_182
    :goto_182
    goto :goto_18e

    .line 91
    :cond_183
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_18f

    .line 104
    :goto_18e
    const/4 v1, 0x0

    .line 105
    :goto_18f
    return-object v1

    :sswitch_data_190
    .sparse-switch
        -0x7835adf0 -> :sswitch_17a
        -0xc38e10 -> :sswitch_171
        0x58 -> :sswitch_15e
        0x59 -> :sswitch_14f
        0x5a -> :sswitch_140
        0x78 -> :sswitch_137
        0x79 -> :sswitch_12e
        0x7a -> :sswitch_125
        0x10052 -> :sswitch_110
        0x10d29 -> :sswitch_fb
        0x12d44 -> :sswitch_e6
        0x12e32 -> :sswitch_d1
        0x1ffd25 -> :sswitch_bc
        0x241597 -> :sswitch_a7
        0x2751dd -> :sswitch_92
        0x284da4 -> :sswitch_7e
        0x32a177 -> :sswitch_74
        0x36d984 -> :sswitch_6a
        0x3c788b3 -> :sswitch_55
        0x3e5a820 -> :sswitch_40
        0x40d33ec -> :sswitch_2b
        0x458bac36 -> :sswitch_16
    .end sparse-switch
.end method

.method static final _init_$lambda$23(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$meta"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$meta"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 107
    sget-object v0, Lorg/luaj/vm2/LuaValue;->ADD:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda70;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda70;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 108
    sget-object v0, Lorg/luaj/vm2/LuaValue;->SUB:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda71;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda71;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 109
    sget-object v0, Lorg/luaj/vm2/LuaValue;->MUL:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda72;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda72;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 116
    sget-object v0, Lorg/luaj/vm2/LuaValue;->DIV:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda73;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda73;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 123
    sget-object v0, Lorg/luaj/vm2/LuaValue;->UNM:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda74;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda74;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 124
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$26(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 127
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    .line 128
    .local v0, "v":Lcom/exampletest/mobilestudiotest/model/Vector2;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_b0

    goto/16 :goto_a2

    :sswitch_16
    const-string v1, "unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_28

    goto/16 :goto_a2

    :sswitch_20
    const-string v1, "Unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 131
    :cond_28
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_af

    .line 128
    :sswitch_34
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 133
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda53;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda53;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_af

    .line 128
    :sswitch_49
    const-string v1, "Dot"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 132
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda52;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda52;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_af

    .line 128
    :sswitch_5d
    const-string v1, "y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_77

    goto :goto_a2

    :sswitch_66
    const-string v1, "x"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_86

    goto :goto_a2

    :sswitch_6f
    const-string v1, "Y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 129
    :cond_77
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getY()F

    move-result v2

    goto :goto_8c

    .line 128
    :sswitch_7e
    const-string v1, "X"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    .line 129
    :cond_86
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getX()F

    move-result v2

    :goto_8c
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_af

    .line 128
    :sswitch_91
    const-string v1, "Magnitude"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a3

    goto :goto_a2

    :sswitch_9a
    const-string v1, "magnitude"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a3

    :cond_a2
    :goto_a2
    goto :goto_ae

    .line 130
    :cond_a3
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector2;->getMagnitude()F

    move-result v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_af

    .line 134
    :goto_ae
    const/4 v1, 0x0

    .line 135
    :goto_af
    return-object v1

    :sswitch_data_b0
    .sparse-switch
        -0x7835adf0 -> :sswitch_9a
        -0xc38e10 -> :sswitch_91
        0x58 -> :sswitch_7e
        0x59 -> :sswitch_6f
        0x78 -> :sswitch_66
        0x79 -> :sswitch_5d
        0x10d29 -> :sswitch_49
        0x241597 -> :sswitch_34
        0x284da4 -> :sswitch_20
        0x36d984 -> :sswitch_16
    .end sparse-switch
.end method

.method static final _init_$lambda$32(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$meta"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$meta"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    sget-object v0, Lorg/luaj/vm2/LuaValue;->ADD:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda57;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda57;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 138
    sget-object v0, Lorg/luaj/vm2/LuaValue;->SUB:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda58;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda58;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 139
    sget-object v0, Lorg/luaj/vm2/LuaValue;->MUL:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda59;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda59;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 146
    sget-object v0, Lorg/luaj/vm2/LuaValue;->DIV:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda60;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda60;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 147
    sget-object v0, Lorg/luaj/vm2/LuaValue;->UNM:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda61;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda61;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 148
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$47(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 151
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/CFrame;

    .line 152
    .local v0, "c":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_2d4

    goto/16 :goto_2c4

    :sswitch_16
    const-string v1, "inverse"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e3

    goto/16 :goto_2c4

    :sswitch_20
    const-string v1, "RightVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1a5

    goto/16 :goto_2c4

    :sswitch_2a
    const-string v1, "VectorToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_171

    goto/16 :goto_2c4

    :sswitch_34
    const-string v1, "UpVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_46

    goto/16 :goto_2c4

    :sswitch_3e
    const-string v1, "upVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 157
    :cond_46
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getUpVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_52
    const-string v1, "ZVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 158
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR02()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR12()F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR22()F

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    goto/16 :goto_20b

    .line 152
    :sswitch_6f
    const-string v1, "Position"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10e

    goto/16 :goto_2c4

    :sswitch_79
    const-string v1, "vectorToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_275

    goto/16 :goto_2c4

    :sswitch_83
    const-string v1, "toEulerAnglesYXZ"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_237

    goto/16 :goto_2c4

    :sswitch_8d
    const-string v1, "toEulerAnglesXYZ"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_190

    goto/16 :goto_2c4

    :sswitch_97
    const-string v1, "pointToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_29d

    goto/16 :goto_2c4

    :sswitch_a1
    const-string v1, "lookVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b1

    goto/16 :goto_2c4

    :sswitch_ab
    const-string v1, "GetComponents"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b9

    goto/16 :goto_2c4

    :sswitch_b5
    const-string v1, "Rotation"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 159
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->rotationOnly()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_c9
    const-string v1, "lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_db

    goto/16 :goto_2c4

    :sswitch_d3
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 161
    :cond_db
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda118;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda118;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_e8
    const-string v1, "z"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_122

    goto/16 :goto_2c4

    :sswitch_f2
    const-string v1, "y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_131

    goto/16 :goto_2c4

    :sswitch_fc
    const-string v1, "x"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_140

    goto/16 :goto_2c4

    :sswitch_106
    const-string v1, "p"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 153
    :cond_10e
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_11a
    const-string v1, "Z"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 154
    :cond_122
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getZ()F

    move-result v2

    goto :goto_146

    .line 152
    :sswitch_129
    const-string v1, "Y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 154
    :cond_131
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getY()F

    move-result v2

    goto :goto_146

    .line 152
    :sswitch_138
    const-string v1, "X"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 154
    :cond_140
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getX()F

    move-result v2

    :goto_146
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_14c
    const-string v1, "YVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 158
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR01()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR11()F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR21()F

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    goto/16 :goto_20b

    .line 152
    :sswitch_169
    const-string v1, "vectorToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 167
    :cond_171
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda124;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda124;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_17e
    const-string v1, "ToEulerAnglesYXZ"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_237

    goto/16 :goto_2c4

    :sswitch_188
    const-string v1, "ToEulerAnglesXYZ"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 168
    :cond_190
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda125;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda125;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_19d
    const-string v1, "rightVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 156
    :cond_1a5
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getRightVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_1b1
    const-string v1, "components"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 170
    :cond_1b9
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda115;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda115;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_1c6
    const-string v1, "Orthonormalize"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 171
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda116;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda116;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_1db
    const-string v1, "Inverse"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 160
    :cond_1e3
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda114;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda114;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_1f0
    const-string v1, "XVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 158
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR00()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR10()F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getR20()F

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    :goto_20b
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_211
    const-string v1, "pointToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_24c

    goto/16 :goto_2c4

    :sswitch_21b
    const-string v1, "ToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2c5

    goto/16 :goto_2c4

    :sswitch_225
    const-string v1, "ToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_261

    goto/16 :goto_2c4

    :sswitch_22f
    const-string v1, "ToOrientation"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 169
    :cond_237
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda126;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda126;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_244
    const-string v1, "PointToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 164
    :cond_24c
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda121;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda121;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_2d2

    .line 152
    :sswitch_259
    const-string v1, "toWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 162
    :cond_261
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda119;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda119;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_26d
    const-string v1, "VectorToWorldSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 166
    :cond_275
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda123;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda123;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_281
    const-string v1, "ToAxisAngle"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 172
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda117;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda117;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_295
    const-string v1, "PointToObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 165
    :cond_29d
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda122;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda122;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_2a9
    const-string v1, "LookVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c4

    .line 155
    :cond_2b1
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/CFrame;->getLookVector()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 152
    :sswitch_2bc
    const-string v1, "toObjectSpace"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2c5

    :cond_2c4
    :goto_2c4
    goto :goto_2d1

    .line 163
    :cond_2c5
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda120;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda120;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_2d2

    .line 179
    :goto_2d1
    const/4 v1, 0x0

    .line 180
    :goto_2d2
    return-object v1

    nop

    :sswitch_data_2d4
    .sparse-switch
        -0x7ffc2474 -> :sswitch_2bc
        -0x712a431e -> :sswitch_2a9
        -0x6f840404 -> :sswitch_295
        -0x67bceea9 -> :sswitch_281
        -0x64ba3d8e -> :sswitch_26d
        -0x62e46291 -> :sswitch_259
        -0x5a1a5101 -> :sswitch_244
        -0x595e8bcb -> :sswitch_22f
        -0x59190e71 -> :sswitch_225
        -0x505cf494 -> :sswitch_21b
        -0x44de90e1 -> :sswitch_211
        -0x385cd445 -> :sswitch_1f0
        -0x27f58cf0 -> :sswitch_1db
        -0x22dbe98b -> :sswitch_1c6
        -0x1aab7cea -> :sswitch_1b1
        -0x14347581 -> :sswitch_19d
        -0xea29275 -> :sswitch_188
        -0xea28ed3 -> :sswitch_17e
        -0x39570f7 -> :sswitch_169
        -0x3769904 -> :sswitch_14c
        0x58 -> :sswitch_138
        0x59 -> :sswitch_129
        0x5a -> :sswitch_11a
        0x70 -> :sswitch_106
        0x78 -> :sswitch_fc
        0x79 -> :sswitch_f2
        0x7a -> :sswitch_e8
        0x241597 -> :sswitch_d3
        0x32a177 -> :sswitch_c9
        0x173739e -> :sswitch_b5
        0x3346aec -> :sswitch_ab
        0x1803e0c2 -> :sswitch_a1
        0x22b83fdc -> :sswitch_97
        0x2399296b -> :sswitch_8d
        0x23992d0d -> :sswitch_83
        0x2d820652 -> :sswitch_79
        0x306cfd49 -> :sswitch_6f
        0x316fa23d -> :sswitch_52
        0x37223bbe -> :sswitch_3e
        0x3afc9fde -> :sswitch_34
        0x471e56e9 -> :sswitch_2a
        0x4f35325f -> :sswitch_20
        0x74d1db30 -> :sswitch_16
    .end sparse-switch
.end method

.method static final _init_$lambda$51(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$meta"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$meta"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 182
    sget-object v0, Lorg/luaj/vm2/LuaValue;->MUL:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda139;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda139;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 191
    sget-object v0, Lorg/luaj/vm2/LuaValue;->ADD:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda140;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda140;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 192
    sget-object v0, Lorg/luaj/vm2/LuaValue;->SUB:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda141;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda141;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 193
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$55(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 196
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Color3;

    .line 197
    .local v0, "c":Lcom/exampletest/mobilestudiotest/model/Color3;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_ac

    goto/16 :goto_9e

    :sswitch_16
    const-string v1, "ToHex"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 201
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda138;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda138;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_ab

    .line 197
    :sswitch_2b
    const-string v1, "ToHSV"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 200
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda137;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda137;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto/16 :goto_ab

    .line 197
    :sswitch_40
    const-string v1, "lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_51

    goto :goto_9e

    :sswitch_49
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 199
    :cond_51
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda136;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda136;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_ab

    .line 197
    :sswitch_5d
    const-string v1, "r"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_80

    goto :goto_9e

    :sswitch_66
    const-string v1, "g"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8f

    goto :goto_9e

    :sswitch_6f
    const-string v1, "b"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9f

    goto :goto_9e

    :sswitch_78
    const-string v1, "R"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 198
    :cond_80
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Color3;->getR()F

    move-result v2

    goto :goto_a5

    .line 197
    :sswitch_87
    const-string v1, "G"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9e

    .line 198
    :cond_8f
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Color3;->getG()F

    move-result v2

    goto :goto_a5

    .line 197
    :sswitch_96
    const-string v1, "B"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9f

    :cond_9e
    :goto_9e
    goto :goto_aa

    .line 198
    :cond_9f
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Color3;->getB()F

    move-result v2

    :goto_a5
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_ab

    .line 202
    :goto_aa
    const/4 v1, 0x0

    .line 203
    :goto_ab
    return-object v1

    :sswitch_data_ac
    .sparse-switch
        0x42 -> :sswitch_96
        0x47 -> :sswitch_87
        0x52 -> :sswitch_78
        0x62 -> :sswitch_6f
        0x67 -> :sswitch_66
        0x72 -> :sswitch_5d
        0x241597 -> :sswitch_49
        0x32a177 -> :sswitch_40
        0x4d34430 -> :sswitch_2b
        0x4d34680 -> :sswitch_16
    .end sparse-switch
.end method

.method static final _init_$lambda$56(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 207
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    .line 208
    .local v0, "b":Lcom/exampletest/mobilestudiotest/model/BrickColorV;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_8e

    goto :goto_80

    :sswitch_15
    const-string v1, "Color"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_80

    .line 211
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_8d

    .line 208
    :sswitch_28
    const-string v1, "Name"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_80

    .line 209
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_8d

    .line 208
    :sswitch_3b
    const-string v1, "r"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_80

    .line 212
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Color3;->getR()F

    move-result v2

    goto :goto_73

    .line 208
    :sswitch_4e
    const-string v1, "g"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_80

    .line 212
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Color3;->getG()F

    move-result v2

    goto :goto_73

    .line 208
    :sswitch_61
    const-string v1, "b"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_80

    .line 212
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Color3;->getB()F

    move-result v2

    :goto_73
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_8d

    .line 208
    :sswitch_78
    const-string v1, "Number"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_81

    :cond_80
    :goto_80
    goto :goto_8c

    .line 210
    :cond_81
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;->getNumber()I

    move-result v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_8d

    .line 213
    :goto_8c
    const/4 v1, 0x0

    .line 214
    :goto_8d
    return-object v1

    :sswitch_data_8e
    .sparse-switch
        -0x74423897 -> :sswitch_78
        0x62 -> :sswitch_61
        0x67 -> :sswitch_4e
        0x72 -> :sswitch_3b
        0x24eeab -> :sswitch_28
        0x3e43f43 -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$57(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 218
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/UDim;

    .line 219
    .local v0, "u":Lcom/exampletest/mobilestudiotest/model/UDim;
    const-string v1, "Scale"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_20

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_34

    :cond_20
    const-string v1, "Offset"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_33

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_34

    :cond_33
    const/4 v1, 0x0

    :goto_34
    return-object v1
.end method

.method static final _init_$lambda$60(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$meta"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$meta"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 221
    sget-object v0, Lorg/luaj/vm2/LuaValue;->ADD:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda46;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda46;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 222
    sget-object v0, Lorg/luaj/vm2/LuaValue;->SUB:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda47;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda47;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 223
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$62(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 7
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 226
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/UDim2;

    .line 227
    .local v0, "u":Lcom/exampletest/mobilestudiotest/model/UDim2;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_76

    goto :goto_5f

    :sswitch_15
    const-string v1, "Width"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5f

    goto :goto_43

    :sswitch_1e
    const-string v1, "Lerp"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5f

    .line 230
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda106;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda106;-><init>()V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_75

    .line 227
    :sswitch_32
    const-string v1, "Y"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_60

    goto :goto_5f

    :sswitch_3b
    const-string v1, "X"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5f

    .line 228
    :goto_43
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v4

    invoke-direct {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_75

    .line 227
    :sswitch_57
    const-string v1, "Height"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_60

    :cond_5f
    :goto_5f
    goto :goto_74

    .line 229
    :cond_60
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v4

    invoke-direct {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_75

    .line 231
    :goto_74
    const/4 v1, 0x0

    .line 232
    :goto_75
    return-object v1

    :sswitch_data_76
    .sparse-switch
        -0x7f6282b9 -> :sswitch_57
        0x58 -> :sswitch_3b
        0x59 -> :sswitch_32
        0x241597 -> :sswitch_1e
        0x4fb3da6 -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$66(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$meta"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$meta"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    sget-object v0, Lorg/luaj/vm2/LuaValue;->ADD:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda103;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda103;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 235
    sget-object v0, Lorg/luaj/vm2/LuaValue;->SUB:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda104;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda104;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 236
    sget-object v0, Lorg/luaj/vm2/LuaValue;->UNM:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda105;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda105;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 237
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$68(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 6
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 240
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 241
    .local v0, "e":Lcom/exampletest/mobilestudiotest/lua/EnumItemV;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_6a

    goto :goto_57

    :sswitch_15
    const-string v1, "Value"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_57

    .line 243
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_69

    .line 241
    :sswitch_28
    const-string v1, "Name"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_57

    .line 242
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_69

    .line 241
    :sswitch_3b
    const-string v1, "IsA"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_57

    .line 245
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda135;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda135;-><init>(Lcom/exampletest/mobilestudiotest/lua/EnumItemV;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_69

    .line 241
    :sswitch_4f
    const-string v1, "EnumType"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_58

    :cond_57
    :goto_57
    goto :goto_68

    .line 244
    :cond_58
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getType()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_69

    .line 246
    :goto_68
    const/4 v1, 0x0

    .line 247
    :goto_69
    return-object v1

    :sswitch_data_6a
    .sparse-switch
        -0x77926c05 -> :sswitch_4f
        0x12037 -> :sswitch_3b
        0x24eeab -> :sswitch_28
        0x4e9a151 -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$70(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$meta"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$meta"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 249
    sget-object v0, Lorg/luaj/vm2/LuaValue;->TOSTRING:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda133;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda133;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 250
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$76(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 253
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    .line 254
    .local v0, "t":Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_5e

    goto :goto_45

    :sswitch_15
    const-string v1, "FromValue"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_45

    .line 261
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda150;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda150;-><init>(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_5c

    .line 254
    :sswitch_29
    const-string v1, "GetEnumItems"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_45

    .line 255
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda148;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda148;-><init>(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_5c

    .line 254
    :sswitch_3d
    const-string v1, "FromName"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_46

    :cond_45
    :goto_45
    goto :goto_52

    .line 260
    :cond_46
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda149;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda149;-><init>(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_5c

    .line 262
    :goto_52
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->enumItem(Ljava/lang/String;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    .line 263
    :goto_5c
    return-object v1

    nop

    :sswitch_data_5e
    .sparse-switch
        -0x46587a8b -> :sswitch_3d
        0x166e20a9 -> :sswitch_29
        0x7bb9e3c7 -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$78(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$meta"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$meta"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 265
    sget-object v0, Lorg/luaj/vm2/LuaValue;->TOSTRING:Lorg/luaj/vm2/LuaString;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda102;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda102;-><init>()V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 266
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final _init_$lambda$79(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 269
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;

    .line 270
    .local v0, "t":Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_ae

    goto/16 :goto_8c

    :sswitch_16
    const-string v1, "DelayTime"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8c

    .line 271
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;->getDelay()F

    move-result v2

    goto :goto_59

    .line 270
    :sswitch_25
    const-string v1, "EasingStyle"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8c

    .line 273
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;->getStyle()I

    move-result v5

    invoke-virtual {v4, v1, v5}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_3f

    const-string v4, "Quad"

    :cond_3f
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;->getStyle()I

    move-result v5

    invoke-direct {v3, v1, v4, v5}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_ac

    .line 270
    :sswitch_4b
    const-string v1, "Time"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8c

    .line 271
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;->getTime()F

    move-result v2

    :goto_59
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_ac

    .line 270
    :sswitch_5e
    const-string v1, "Reverses"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8c

    .line 272
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;->getReverses()Z

    move-result v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_ac

    .line 270
    :sswitch_71
    const-string v1, "RepeatCount"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8c

    .line 271
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;->getRepeatCount()I

    move-result v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_ac

    .line 270
    :sswitch_84
    const-string v1, "EasingDirection"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_8d

    :cond_8c
    :goto_8c
    goto :goto_ab

    .line 274
    :cond_8d
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;->getDirection()I

    move-result v5

    invoke-virtual {v4, v1, v5}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_9f

    const-string v4, "Out"

    :cond_9f
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;->getDirection()I

    move-result v5

    invoke-direct {v3, v1, v4, v5}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_ac

    .line 275
    :goto_ab
    const/4 v1, 0x0

    .line 276
    :goto_ac
    return-object v1

    nop

    :sswitch_data_ae
    .sparse-switch
        -0x6436bd8c -> :sswitch_84
        -0x3eeadbec -> :sswitch_71
        -0xbe9920f -> :sswitch_5e
        0x27c6ed -> :sswitch_4b
        0x570a1b26 -> :sswitch_25
        0x5b7c26d0 -> :sswitch_16
    .end sparse-switch
.end method

.method static final _init_$lambda$80(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 280
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/NumberRange;

    .line 281
    .local v0, "r":Lcom/exampletest/mobilestudiotest/model/NumberRange;
    const-string v1, "Min"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_20

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/NumberRange;->getMin()F

    move-result v2

    :goto_1b
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_30

    :cond_20
    const-string v1, "Max"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2f

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/NumberRange;->getMax()F

    move-result v2

    goto :goto_1b

    :cond_2f
    const/4 v1, 0x0

    :goto_30
    return-object v1
.end method

.method static final _init_$lambda$82(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 7
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 285
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Ray;

    .line 286
    .local v0, "r":Lcom/exampletest/mobilestudiotest/model/Ray;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_6a

    goto :goto_5c

    :sswitch_15
    const-string v1, "Direction"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5c

    .line 287
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    goto :goto_63

    .line 286
    :sswitch_24
    const-string v1, "Unit"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5c

    .line 287
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Ray;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Ray;->getOrigin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/model/Ray;-><init>(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    goto :goto_63

    .line 286
    :sswitch_40
    const-string v1, "ClosestPoint"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5c

    .line 288
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda1;-><init>(Lcom/exampletest/mobilestudiotest/model/Ray;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_69

    .line 286
    :sswitch_54
    const-string v1, "Origin"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    :cond_5c
    :goto_5c
    goto :goto_68

    .line 287
    :cond_5d
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Ray;->getOrigin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    :goto_63
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_69

    .line 292
    :goto_68
    const/4 v1, 0x0

    .line 293
    :goto_69
    return-object v1

    :sswitch_data_6a
    .sparse-switch
        -0x72b964ba -> :sswitch_54
        -0x1b9f8529 -> :sswitch_40
        0x284da4 -> :sswitch_24
        0x3e12275f -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$84(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 297
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/Region3V;

    .line 298
    .local v0, "r":Lcom/exampletest/mobilestudiotest/lua/Region3V;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_4e

    goto :goto_3f

    :sswitch_15
    const-string v1, "CFrame"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3f

    .line 299
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getCframe()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    goto :goto_32

    .line 298
    :sswitch_24
    const-string v1, "Size"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3f

    .line 299
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getSize()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    :goto_32
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_4d

    .line 298
    :sswitch_37
    const-string v1, "ExpandToGrid"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_40

    :cond_3f
    :goto_3f
    goto :goto_4c

    .line 300
    :cond_40
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda134;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda134;-><init>(Lcom/exampletest/mobilestudiotest/lua/Region3V;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_4d

    .line 306
    :goto_4c
    const/4 v1, 0x0

    .line 307
    :goto_4d
    return-object v1

    :sswitch_data_4e
    .sparse-switch
        -0x31956445 -> :sswitch_37
        0x275421 -> :sswitch_24
        0x76646aea -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$85(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 310
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/Region3int16V;

    .line 311
    .local v0, "r":Lcom/exampletest/mobilestudiotest/lua/Region3int16V;
    const-string v1, "Min"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_20

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/Region3int16V;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    move-result-object v2

    :goto_1b
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_30

    :cond_20
    const-string v1, "Max"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2f

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/Region3int16V;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    move-result-object v2

    goto :goto_1b

    :cond_2f
    const/4 v1, 0x0

    :goto_30
    return-object v1
.end method

.method static final _init_$lambda$89(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 315
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/RandomV;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/RandomV;->getRng()Ljava/util/Random;

    move-result-object v0

    .line 316
    .local v0, "r":Ljava/util/Random;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_58

    goto :goto_49

    :sswitch_19
    const-string v1, "NextInteger"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_49

    .line 321
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda63;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda63;-><init>(Ljava/util/Random;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_57

    .line 316
    :sswitch_2d
    const-string v1, "NextNumber"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_49

    .line 317
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda62;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda62;-><init>(Ljava/util/Random;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_57

    .line 316
    :sswitch_41
    const-string v1, "NextUnitVector"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4a

    :cond_49
    :goto_49
    goto :goto_56

    .line 325
    :cond_4a
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda64;

    invoke-direct {v2, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda64;-><init>(Ljava/util/Random;)V

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_57

    .line 326
    :goto_56
    const/4 v1, 0x0

    .line 327
    :goto_57
    return-object v1

    :sswitch_data_58
    .sparse-switch
        -0x3dd2ca6 -> :sswitch_41
        0x22fdec3c -> :sswitch_2d
        0x28b28eab -> :sswitch_19
    .end sparse-switch
.end method

.method static final _init_$lambda$90(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 331
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/RaycastResultV;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/RaycastResultV;->getHit()Lcom/exampletest/mobilestudiotest/lua/RayHitInfo;

    move-result-object v0

    .line 332
    .local v0, "h":Lcom/exampletest/mobilestudiotest/lua/RayHitInfo;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_78

    goto :goto_69

    :sswitch_19
    const-string v1, "Position"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_69

    .line 333
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/RayHitInfo;->getPosition()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    goto :goto_70

    .line 332
    :sswitch_28
    const-string v1, "Material"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_69

    .line 334
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/RayHitInfo;->getMaterial()I

    move-result v5

    invoke-virtual {v4, v1, v5}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_42

    const-string v4, "Plastic"

    :cond_42
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/RayHitInfo;->getMaterial()I

    move-result v5

    invoke-direct {v3, v1, v4, v5}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_76

    .line 332
    :sswitch_4e
    const-string v1, "Distance"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_69

    .line 333
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/RayHitInfo;->getDistance()F

    move-result v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_76

    .line 332
    :sswitch_61
    const-string v1, "Normal"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6a

    :cond_69
    :goto_69
    goto :goto_75

    .line 333
    :cond_6a
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/RayHitInfo;->getNormal()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    :goto_70
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_76

    .line 335
    :goto_75
    const/4 v1, 0x0

    .line 336
    :goto_76
    return-object v1

    nop

    :sswitch_data_78
    .sparse-switch
        -0x749456f9 -> :sswitch_61
        0x150bf015 -> :sswitch_4e
        0x15adc947 -> :sswitch_28
        0x306cfd49 -> :sswitch_19
    .end sparse-switch
.end method

.method static final _init_$lambda$93(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 14
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 340
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/NumberSequence;

    .line 341
    .local v0, "s":Lcom/exampletest/mobilestudiotest/model/NumberSequence;
    const-string v1, "Keypoints"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_46

    new-instance v1, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v1}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v2, v1

    .line 659
    .local v2, "t\\1":Lorg/luaj/vm2/LuaTable;
    const/4 v3, 0x0

    .line 341
    .local v3, "$i$a$-also-LuaTypes$24$1\\1\\341\\0":I
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/NumberSequence;->getKeys()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$forEach\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 661
    .local v5, "$i$f$forEach\\2\\341":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_27
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_41

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\2":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    .local v8, "kp\\3":Lcom/exampletest/mobilestudiotest/model/NumberKey;
    const/4 v9, 0x0

    .line 341
    .local v9, "$i$a$-forEach-LuaTypes$24$1$1\\3\\661\\1":I
    sget-object v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v10, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v10

    const/4 v11, 0x0

    invoke-virtual {v2, v11, v10}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 661
    .end local v8    # "kp\\3":Lcom/exampletest/mobilestudiotest/model/NumberKey;
    .end local v9    # "$i$a$-forEach-LuaTypes$24$1$1\\3\\661\\1":I
    nop

    .end local v7    # "element\\2":Ljava/lang/Object;
    goto :goto_27

    .line 662
    :cond_41
    nop

    .line 341
    .end local v4    # "$this$forEach\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$forEach\\2\\341":I
    nop

    .end local v2    # "t\\1":Lorg/luaj/vm2/LuaTable;
    .end local v3    # "$i$a$-also-LuaTypes$24$1\\1\\341\\0":I
    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_47

    :cond_46
    const/4 v1, 0x0

    :goto_47
    return-object v1
.end method

.method static final _init_$lambda$94(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 344
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    .line 345
    .local v0, "kp":Lcom/exampletest/mobilestudiotest/model/NumberKey;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_4a

    goto :goto_3b

    :sswitch_15
    const-string v1, "Value"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3b

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/NumberKey;->getValue()F

    move-result v2

    goto :goto_42

    :sswitch_24
    const-string v1, "Time"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3b

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/NumberKey;->getTime()F

    move-result v2

    goto :goto_42

    :sswitch_33
    const-string v1, "Envelope"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3c

    :cond_3b
    :goto_3b
    goto :goto_47

    :cond_3c
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/NumberKey;->getEnvelope()F

    move-result v2

    :goto_42
    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_48

    :goto_47
    const/4 v1, 0x0

    :goto_48
    return-object v1

    nop

    :sswitch_data_4a
    .sparse-switch
        -0x76438c10 -> :sswitch_33
        0x27c6ed -> :sswitch_24
        0x4e9a151 -> :sswitch_15
    .end sparse-switch
.end method

.method static final _init_$lambda$97(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 14
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 348
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/ColorSequence;

    .line 349
    .local v0, "s":Lcom/exampletest/mobilestudiotest/model/ColorSequence;
    const-string v1, "Keypoints"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_46

    new-instance v1, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v1}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v2, v1

    .line 659
    .local v2, "t\\1":Lorg/luaj/vm2/LuaTable;
    const/4 v3, 0x0

    .line 349
    .local v3, "$i$a$-also-LuaTypes$26$1\\1\\349\\0":I
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/ColorSequence;->getKeys()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$forEach\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 663
    .local v5, "$i$f$forEach\\2\\349":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_27
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_41

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\2":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    .local v8, "kp\\3":Lcom/exampletest/mobilestudiotest/model/ColorKey;
    const/4 v9, 0x0

    .line 349
    .local v9, "$i$a$-forEach-LuaTypes$26$1$1\\3\\663\\1":I
    sget-object v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v10, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v10

    const/4 v11, 0x0

    invoke-virtual {v2, v11, v10}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 663
    .end local v8    # "kp\\3":Lcom/exampletest/mobilestudiotest/model/ColorKey;
    .end local v9    # "$i$a$-forEach-LuaTypes$26$1$1\\3\\663\\1":I
    nop

    .end local v7    # "element\\2":Ljava/lang/Object;
    goto :goto_27

    .line 664
    :cond_41
    nop

    .line 349
    .end local v4    # "$this$forEach\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$forEach\\2\\349":I
    nop

    .end local v2    # "t\\1":Lorg/luaj/vm2/LuaTable;
    .end local v3    # "$i$a$-also-LuaTypes$26$1\\1\\349\\0":I
    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_47

    :cond_46
    const/4 v1, 0x0

    :goto_47
    return-object v1
.end method

.method static final _init_$lambda$98(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 352
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    .line 353
    .local v0, "kp":Lcom/exampletest/mobilestudiotest/model/ColorKey;
    const-string v1, "Time"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_20

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/ColorKey;->getTime()F

    move-result v2

    invoke-direct {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_34

    :cond_20
    const-string v1, "Value"

    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_33

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/ColorKey;->getColor()Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_34

    :cond_33
    const/4 v1, 0x0

    :goto_34
    return-object v1
.end method

.method static final _init_$lambda$99(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "k"    # Ljava/lang/String;

    const-string v0, "o"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "k"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 356
    move-object v0, p0

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/FontValue;

    .line 357
    .local v0, "f":Lcom/exampletest/mobilestudiotest/model/FontValue;
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v2, 0x1

    sparse-switch v1, :sswitch_data_8c

    goto :goto_6e

    :sswitch_16
    const-string v1, "Family"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6e

    .line 358
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getFamily()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_8a

    .line 357
    :sswitch_29
    const-string v1, "Style"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6e

    .line 360
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getStyle()I

    move-result v4

    if-ne v4, v2, :cond_3e

    const-string v2, "Italic"

    goto :goto_40

    :cond_3e
    const-string v2, "Normal"

    :goto_40
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getStyle()I

    move-result v4

    const-string v5, "FontStyle"

    invoke-direct {v3, v5, v2, v4}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_8a

    .line 357
    :sswitch_4e
    const-string v1, "Bold"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6e

    .line 361
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getWeight()I

    move-result v1

    const/16 v3, 0x2bc

    if-ge v1, v3, :cond_5f

    const/4 v2, 0x0

    :cond_5f
    invoke-static {v2}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    goto :goto_8a

    .line 357
    :sswitch_66
    const-string v1, "Weight"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6f

    :cond_6e
    :goto_6e
    goto :goto_89

    .line 359
    :cond_6f
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getWeight()I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/FontValue;->getWeight()I

    move-result v4

    const-string v5, "FontWeight"

    invoke-direct {v2, v5, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_8a

    .line 362
    :goto_89
    const/4 v1, 0x0

    .line 363
    :goto_8a
    return-object v1

    nop

    :sswitch_data_8c
    .sparse-switch
        -0x65c9d168 -> :sswitch_66
        0x1faea5 -> :sswitch_4e
        0x4c82d91 -> :sswitch_29
        0x7cfd4784 -> :sswitch_16
    .end sparse-switch
.end method

.method private final arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;
    .registers 10
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;
    .param p2, "i"    # I

    .line 84
    invoke-virtual {p1, p2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "Vector3"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v1, "what\\1":Ljava/lang/String;
    const/4 v2, 0x0

    .line 605
    .local v2, "$i$f$ud\\1\\84":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_18

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_19

    :cond_18
    move-object v3, v4

    :goto_19
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_1e

    move-object v4, v3

    :cond_1e
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v4, :cond_23

    .line 84
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$i$f$ud\\1\\84":I
    return-object v4

    .line 605
    .restart local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v1    # "what\\1":Ljava/lang/String;
    .restart local v2    # "$i$f$ud\\1\\84":I
    :cond_23
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method private final bounceOut(F)F
    .registers 10
    .param p1, "x"    # F

    .line 578
    const/high16 v0, 0x40f20000    # 7.5625f

    .local v0, "n1":F
    const/high16 v1, 0x40300000    # 2.75f

    .line 579
    .local v1, "d1":F
    nop

    .line 580
    const/high16 v2, 0x3f800000    # 1.0f

    div-float/2addr v2, v1

    cmpg-float v2, p1, v2

    if-gez v2, :cond_10

    mul-float v2, v0, p1

    mul-float/2addr v2, p1

    goto :goto_46

    .line 581
    :cond_10
    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v2, v1

    cmpg-float v2, p1, v2

    if-gez v2, :cond_24

    const/high16 v2, 0x3fc00000    # 1.5f

    div-float/2addr v2, v1

    sub-float v2, p1, v2

    .local v2, "y":F
    mul-float v3, v0, v2

    mul-float/2addr v3, v2

    const/high16 v4, 0x3f400000    # 0.75f

    add-float v2, v3, v4

    .end local v2    # "y":F
    goto :goto_46

    .line 582
    :cond_24
    float-to-double v2, p1

    const-wide/high16 v4, 0x4004000000000000L    # 2.5

    float-to-double v6, v1

    div-double/2addr v4, v6

    cmpg-double v2, v2, v4

    if-gez v2, :cond_3a

    const/high16 v2, 0x40100000    # 2.25f

    div-float/2addr v2, v1

    sub-float v2, p1, v2

    .restart local v2    # "y":F
    mul-float v3, v0, v2

    mul-float/2addr v3, v2

    const/high16 v4, 0x3f700000    # 0.9375f

    add-float v2, v3, v4

    .end local v2    # "y":F
    goto :goto_46

    .line 583
    :cond_3a
    const/high16 v2, 0x40280000    # 2.625f

    div-float/2addr v2, v1

    sub-float v2, p1, v2

    .restart local v2    # "y":F
    mul-float v3, v0, v2

    mul-float/2addr v3, v2

    const/high16 v4, 0x3f7c0000    # 0.984375f

    add-float/2addr v3, v4

    move v2, v3

    .line 579
    .end local v2    # "y":F
    :goto_46
    return v2
.end method

.method private static final ease$easeIn(IF)F
    .registers 10
    .param p0, "$style"    # I
    .param p1, "x"    # F

    .line 556
    const-wide/high16 v0, 0x4000000000000000L    # 2.0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-wide/high16 v5, 0x4024000000000000L    # 10.0

    const/high16 v7, 0x3f800000    # 1.0f

    packed-switch p0, :pswitch_data_9a

    .line 568
    mul-float v4, p1, p1

    goto/16 :goto_99

    .line 567
    :pswitch_10
    mul-float v0, p1, p1

    mul-float v4, v0, p1

    goto/16 :goto_99

    .line 566
    :pswitch_16
    mul-float v0, p1, p1

    sub-float v0, v7, v0

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    double-to-float v0, v0

    sub-float v4, v7, v0

    goto/16 :goto_99

    .line 565
    :pswitch_24
    cmpg-float v7, p1, v4

    if-eqz v7, :cond_29

    move v2, v3

    :cond_29
    if-nez v2, :cond_99

    float-to-double v2, p1

    mul-double/2addr v2, v5

    sub-double/2addr v2, v5

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    double-to-float v4, v0

    goto/16 :goto_99

    .line 564
    :pswitch_35
    cmpg-float v4, p1, v4

    if-nez v4, :cond_3b

    move v4, v2

    goto :goto_3c

    :cond_3b
    move v4, v3

    :goto_3c
    if-nez v4, :cond_98

    cmpg-float v4, p1, v7

    if-eqz v4, :cond_43

    move v2, v3

    :cond_43
    if-nez v2, :cond_98

    float-to-double v2, p1

    mul-double/2addr v2, v5

    sub-double/2addr v2, v5

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    double-to-float v0, v0

    neg-float v0, v0

    const/high16 v1, 0x41200000    # 10.0f

    mul-float/2addr v1, p1

    const/high16 v2, 0x412c0000    # 10.75f

    sub-float/2addr v1, v2

    const v2, 0x40060a92

    mul-float/2addr v1, v2

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v1, v1

    mul-float v4, v0, v1

    goto :goto_99

    .line 563
    :pswitch_61
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sub-float v1, v7, p1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->bounceOut(F)F

    move-result v0

    sub-float v4, v7, v0

    goto :goto_99

    .line 562
    :pswitch_6c
    mul-float v0, p1, p1

    mul-float/2addr v0, p1

    mul-float/2addr v0, p1

    mul-float v4, v0, p1

    goto :goto_99

    .line 561
    :pswitch_73
    mul-float v0, p1, p1

    mul-float/2addr v0, p1

    mul-float v4, v0, p1

    goto :goto_99

    .line 560
    :pswitch_79
    mul-float v4, p1, p1

    goto :goto_99

    .line 559
    :pswitch_7c
    const v0, 0x3fd9cd60

    .local v0, "s":F
    mul-float v1, p1, p1

    add-float/2addr v7, v0

    mul-float/2addr v7, p1

    sub-float/2addr v7, v0

    mul-float v4, v1, v7

    .end local v0    # "s":F
    goto :goto_99

    .line 558
    :pswitch_87
    const v0, 0x40490fdb    # (float)Math.PI

    mul-float/2addr v0, p1

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->cos(D)D

    move-result-wide v0

    double-to-float v0, v0

    sub-float v4, v7, v0

    goto :goto_99

    .line 557
    :pswitch_97
    nop

    .line 569
    :cond_98
    move v4, p1

    :cond_99
    :goto_99
    return v4

    :pswitch_data_9a
    .packed-switch 0x0
        :pswitch_97
        :pswitch_87
        :pswitch_7c
        :pswitch_79
        :pswitch_73
        :pswitch_6c
        :pswitch_61
        :pswitch_35
        :pswitch_24
        :pswitch_16
        :pswitch_10
    .end packed-switch
.end method

.method static final enumLib$lambda$102(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p1, "k"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "<unused var>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "k"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 394
    sget-object p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v1

    const-string v2, "tojstring(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object p0

    return-object p0
.end method

.method static final enumLib$lambda$105(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11

    const-string v0, "<unused var>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 396
    new-instance p0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {p0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v0, p0

    .line 659
    .local v0, "tbl\\1":Lorg/luaj/vm2/LuaTable;
    const/4 v1, 0x0

    .line 396
    .local v1, "$i$a$-also-LuaTypes$enumLib$2$1\\1\\396\\0":I
    sget-object v2, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Enums;->getTypes()Ljava/util/Map;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$forEach\\2":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 665
    .local v3, "$i$f$forEach\\2\\396":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\2":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Ljava/lang/String;

    .local v6, "it\\3":Ljava/lang/String;
    const/4 v7, 0x0

    .line 396
    .local v7, "$i$a$-forEach-LuaTypes$enumLib$2$1$1\\3\\665\\1":I
    sget-object v8, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v9, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    invoke-direct {v9, v6}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v8

    const/4 v9, 0x0

    invoke-virtual {v0, v9, v8}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 665
    .end local v6    # "it\\3":Ljava/lang/String;
    .end local v7    # "$i$a$-forEach-LuaTypes$enumLib$2$1$1\\3\\665\\1":I
    nop

    .end local v5    # "element\\2":Ljava/lang/Object;
    goto :goto_1d

    .line 666
    :cond_3c
    nop

    .line 396
    .end local v2    # "$this$forEach\\2":Ljava/lang/Iterable;
    .end local v3    # "$i$f$forEach\\2\\396":I
    nop

    .end local v0    # "tbl\\1":Lorg/luaj/vm2/LuaTable;
    .end local v1    # "$i$a$-also-LuaTypes$enumLib$2$1\\1\\396\\0":I
    check-cast p0, Lorg/luaj/vm2/Varargs;

    return-object p0
.end method

.method private final generic(Ljava/lang/String;)Lorg/luaj/vm2/LuaTable;
    .registers 7
    .param p1, "name"    # Ljava/lang/String;

    .line 61
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    move-object v1, v0

    .local v1, "$this$generic_u24lambda_u241\\1":Lorg/luaj/vm2/LuaTable;
    const/4 v2, 0x0

    .line 62
    .local v2, "$i$a$-apply-LuaTypes$generic$1\\1\\61\\0":I
    const-string v3, "__type"

    invoke-virtual {v1, v3, p1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Ljava/lang/String;)V

    .line 63
    sget-object v3, Lorg/luaj/vm2/LuaValue;->TOSTRING:Lorg/luaj/vm2/LuaString;

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    new-instance v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda100;

    invoke-direct {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda100;-><init>()V

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v4

    check-cast v4, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v1, v3, v4}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 64
    nop

    .line 61
    .end local v1    # "$this$generic_u24lambda_u241\\1":Lorg/luaj/vm2/LuaTable;
    .end local v2    # "$i$a$-apply-LuaTypes$generic$1\\1\\61\\0":I
    nop

    .line 64
    return-object v0
.end method

.method static final generic$lambda$1$lambda$0(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 3
    .param p0, "it"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method static final install$lambda$109(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 407
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda66;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda66;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 408
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "zero"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getONE()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "one"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 409
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getX()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "xAxis"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getY()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "yAxis"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZ()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "zAxis"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 410
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda67;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda67;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "FromNormalId"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 414
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda68;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda68;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "FromAxis"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 415
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$109$lambda$106(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 407
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v5

    const/4 v6, 0x3

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    invoke-direct {v1, v2, v5, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$109$lambda$107(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 411
    move-object v0, p0

    .local v0, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v1, 0x0

    .line 667
    .local v1, "$i$f$udOrNull\\1\\411":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_13

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v2

    goto :goto_14

    :cond_13
    move-object v2, v3

    :goto_14
    instance-of v4, v2, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v4, :cond_19

    move-object v3, v2

    :cond_19
    check-cast v3, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 411
    .end local v0    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "$i$f$udOrNull\\1\\411":I
    if-eqz v3, :cond_22

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v0

    goto :goto_26

    :cond_22
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->toint()I

    move-result v0

    .line 412
    .local v0, "i":I
    :goto_26
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x6

    new-array v2, v2, [Lcom/exampletest/mobilestudiotest/model/Vector3;

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getX()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getY()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/4 v5, 0x1

    aput-object v3, v2, v5

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZ()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/4 v5, 0x2

    aput-object v3, v2, v5

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getX()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/4 v5, 0x3

    aput-object v3, v2, v5

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getY()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/4 v5, 0x4

    aput-object v3, v2, v5

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZ()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/4 v5, 0x5

    aput-object v3, v2, v5

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-static {v0, v4, v5}, Lkotlin/ranges/RangesKt;->coerceIn(III)I

    move-result v3

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    return-object v1
.end method

.method static final install$lambda$109$lambda$108(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 414
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    move-object v2, p0

    .local v2, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 668
    .local v3, "$i$f$udOrNull\\1\\414":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_17

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_18

    :cond_17
    move-object v4, v5

    :goto_18
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v6, :cond_1d

    move-object v5, v4

    :cond_1d
    check-cast v5, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 414
    .end local v2    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$udOrNull\\1\\414":I
    if-eqz v5, :cond_26

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v2

    goto :goto_2a

    :cond_26
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->toint()I

    move-result v2

    :goto_2a
    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->axis(I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0
.end method

.method static final install$lambda$111(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 5
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 417
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda69;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda69;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 418
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const/4 v2, 0x0

    invoke-direct {v1, v2, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "zero"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {v1, v3, v3}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "one"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 419
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-direct {v1, v3, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "xAxis"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-direct {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "yAxis"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 420
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$111$lambda$110(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 417
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    invoke-direct {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector2;-><init>(FF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$113(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 421
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda10;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda10;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$113$lambda$112(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 421
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v2

    const/4 v4, 0x2

    invoke-virtual {p0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-virtual {v4, v3}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v4

    const/4 v5, 0x3

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-virtual {v5, v3}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v3

    invoke-direct {v1, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3int16;-><init>(III)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$117(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 425
    const-string v0, ""

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "none"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 426
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda54;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda54;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromUri"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 427
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda55;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda55;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromAssetId"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 428
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda56;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda56;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromObject"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 429
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$117$lambda$114(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 3
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 426
    const-string v0, ""

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/LuaValue;->optjstring(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method static final install$lambda$117$lambda$115(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 427
    const-wide/16 v0, 0x0

    invoke-virtual {p0, v0, v1}, Lorg/luaj/vm2/LuaValue;->optlong(J)J

    move-result-wide v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "rbxassetid://"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method static final install$lambda$117$lambda$116(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 2
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 428
    return-object p0
.end method

.method static final install$lambda$126(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 5
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 431
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda2;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda2;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda3;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda3;-><init>()V

    .line 444
    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    .line 445
    .local v0, "angles":Lorg/luaj/vm2/lib/VarArgFunction;
    const-string v1, "Angles"

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v1, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    const-string v1, "fromEulerAnglesXYZ"

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v1, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda4;

    invoke-direct {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda4;-><init>()V

    .line 446
    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v1

    .line 447
    .local v1, "orient":Lorg/luaj/vm2/lib/VarArgFunction;
    const-string v2, "fromOrientation"

    move-object v3, v1

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v2, v3}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    const-string v2, "fromEulerAnglesYXZ"

    move-object v3, v1

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v2, v3}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 448
    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda5;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda5;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    const-string v3, "fromEulerAngles"

    invoke-virtual {p0, v3, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 449
    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda6;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda6;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    const-string v3, "lookAt"

    invoke-virtual {p0, v3, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 450
    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda7;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda7;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    const-string v3, "lookAlong"

    invoke-virtual {p0, v3, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 451
    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda8;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda8;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    const-string v3, "fromAxisAngle"

    invoke-virtual {p0, v3, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 452
    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda9;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda9;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    const-string v3, "fromMatrix"

    invoke-virtual {p0, v3, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 457
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "identity"

    invoke-virtual {p0, v3, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 458
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method static final install$lambda$126$lambda$118(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 26
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v0, p0

    const-string v1, "a"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 432
    invoke-virtual {v0}, Lorg/luaj/vm2/Varargs;->narg()I

    move-result v1

    .line 433
    .local v1, "n":I
    nop

    .line 434
    if-nez v1, :cond_1e

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->getIDENTITY()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_261

    .line 435
    :cond_1e
    const-string v2, " expected, got "

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v5, "arg(...)"

    if-ne v1, v4, :cond_76

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v7, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v4, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\1":Ljava/lang/String;
    const/4 v8, 0x0

    .line 669
    .local v8, "$i$f$ud\\1\\435":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_3f

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_40

    :cond_3f
    move-object v9, v3

    :goto_40
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v10, :cond_45

    move-object v3, v9

    :cond_45
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v3, :cond_55

    .line 435
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\1":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\1\\435":I
    invoke-virtual {v7, v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->at(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    invoke-virtual {v6, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_261

    .line 669
    .restart local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "what\\1":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\1\\435":I
    :cond_55
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .line 436
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\1":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\1\\435":I
    :cond_76
    const/4 v6, 0x2

    if-ne v1, v6, :cond_118

    invoke-virtual {v0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v7

    invoke-virtual {v7}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_118

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v8, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v9, "Vector3"

    .local v4, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v9, "what\\2":Ljava/lang/String;
    const/4 v10, 0x0

    .line 670
    .local v10, "$i$f$ud\\2\\436":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v11

    if-eqz v11, :cond_9c

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v11

    goto :goto_9d

    :cond_9c
    move-object v11, v3

    :goto_9d
    instance-of v12, v11, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v12, :cond_a2

    move-object v11, v3

    :cond_a2
    check-cast v11, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v11, :cond_f7

    .line 436
    .end local v4    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v9    # "what\\2":Ljava/lang/String;
    .end local v10    # "$i$f$ud\\2\\436":I
    invoke-virtual {v0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "Vector3"

    .local v4, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v5, "what\\3":Ljava/lang/String;
    const/4 v6, 0x0

    .line 670
    .local v6, "$i$f$ud\\3\\436":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_bb

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_bc

    :cond_bb
    move-object v9, v3

    :goto_bc
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v10, :cond_c1

    move-object v3, v9

    :cond_c1
    move-object v10, v3

    check-cast v10, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v10, :cond_d6

    .line 436
    .end local v4    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "what\\3":Ljava/lang/String;
    .end local v6    # "$i$f$ud\\3\\436":I
    const/4 v12, 0x4

    const/4 v13, 0x0

    move-object v9, v11

    const/4 v11, 0x0

    invoke-static/range {v8 .. v13}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->lookAt$default(Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    invoke-virtual {v7, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_261

    .line 670
    .restart local v4    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "what\\3":Ljava/lang/String;
    .restart local v6    # "$i$f$ud\\3\\436":I
    :cond_d6
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v7, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .end local v5    # "what\\3":Ljava/lang/String;
    .end local v6    # "$i$f$ud\\3\\436":I
    .local v4, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v9    # "what\\2":Ljava/lang/String;
    .restart local v10    # "$i$f$ud\\2\\436":I
    :cond_f7
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .line 437
    .end local v4    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v9    # "what\\2":Ljava/lang/String;
    .end local v10    # "$i$f$ud\\2\\436":I
    :cond_118
    const/4 v2, 0x3

    if-ne v1, v2, :cond_15c

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v7, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v8

    invoke-virtual {v0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v9

    invoke-virtual {v0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v10

    const/16 v20, 0xff8

    const/16 v21, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    invoke-direct/range {v7 .. v21}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v3, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_261

    .line 438
    :cond_15c
    const/4 v3, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-ne v1, v9, :cond_1c4

    sget-object v10, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v11, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    new-instance v12, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v4

    invoke-virtual {v0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v6

    invoke-virtual {v0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v2

    invoke-direct {v12, v4, v6, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v0, v8}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v13

    invoke-virtual {v0, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v14

    invoke-virtual {v0, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v15

    invoke-virtual {v0, v9}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v16

    invoke-virtual/range {v11 .. v16}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromQuaternion(Lcom/exampletest/mobilestudiotest/model/Vector3;FFFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    invoke-virtual {v10, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_261

    .line 439
    :cond_1c4
    const/16 v10, 0xc

    if-lt v1, v10, :cond_262

    sget-object v11, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v12, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v13

    invoke-virtual {v0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v14

    invoke-virtual {v0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v15

    invoke-virtual {v0, v8}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v16

    invoke-virtual {v0, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v17

    invoke-virtual {v0, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v18

    .line 440
    invoke-virtual {v0, v9}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v19

    const/16 v2, 0x8

    invoke-virtual {v0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v20

    const/16 v2, 0x9

    invoke-virtual {v0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v21

    const/16 v2, 0xa

    invoke-virtual {v0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v22

    const/16 v2, 0xb

    invoke-virtual {v0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v23

    invoke-virtual {v0, v10}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v24

    .line 439
    invoke-direct/range {v12 .. v24}, Lcom/exampletest/mobilestudiotest/model/CFrame;-><init>(FFFFFFFFFFFF)V

    invoke-virtual {v11, v12}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    .line 442
    :goto_261
    return-object v2

    .line 441
    :cond_262
    new-instance v2, Lorg/luaj/vm2/LuaError;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Invalid number of arguments: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method static final install$lambda$126$lambda$119(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 444
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v5

    const/4 v6, 0x3

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    invoke-virtual {v1, v2, v5, v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->angles(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$126$lambda$120(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 446
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v5

    const/4 v6, 0x3

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    invoke-virtual {v1, v2, v5, v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromOrientation(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$126$lambda$121(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 448
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v5

    const/4 v6, 0x3

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    invoke-virtual {v1, v2, v5, v3}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->angles(FFF)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$126$lambda$122(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 12
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 449
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\1":Ljava/lang/String;
    const/4 v5, 0x0

    .line 671
    .local v5, "$i$f$ud\\1\\449":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_22

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_23

    :cond_22
    move-object v6, v7

    :goto_23
    instance-of v8, v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v8, :cond_28

    move-object v6, v7

    :cond_28
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v8, " expected, got "

    if-eqz v6, :cond_9e

    .line 449
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\1":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\1\\449":I
    const/4 v2, 0x2

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\2":Ljava/lang/String;
    const/4 v5, 0x0

    .line 671
    .local v5, "$i$f$ud\\2\\449":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_44

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_45

    :cond_44
    move-object v9, v7

    :goto_45
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v10, :cond_4a

    move-object v9, v7

    :cond_4a
    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_7d

    .line 449
    .end local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\2":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\2\\449":I
    const/4 v2, 0x3

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v2, "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 672
    .local v3, "$i$f$udOrNull\\3\\449":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_62

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_63

    :cond_62
    move-object v4, v7

    :goto_63
    instance-of v5, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_68

    move-object v7, v4

    :cond_68
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 449
    .end local v2    # "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$udOrNull\\3\\449":I
    if-nez v7, :cond_72

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getY()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    :cond_72
    invoke-virtual {v1, v6, v9, v7}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->lookAt(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 671
    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v4    # "what\\2":Ljava/lang/String;
    .restart local v5    # "$i$f$ud\\2\\449":I
    :cond_7d
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\1":Ljava/lang/String;
    .local v5, "$i$f$ud\\1\\449":I
    :cond_9e
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final install$lambda$126$lambda$123(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 12
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 450
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 673
    .local v3, "$i$f$ud\\1\\450":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1e

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1f

    :cond_1e
    move-object v4, v5

    :goto_1f
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v6, :cond_24

    move-object v4, v5

    :cond_24
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v6, " expected, got "

    if-eqz v4, :cond_a3

    .line 450
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\450":I
    nop

    .local v4, "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v2, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    const/4 v3, 0x2

    invoke-virtual {p0, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Vector3"

    .local v3, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\2":Ljava/lang/String;
    const/4 v8, 0x0

    .line 673
    .local v8, "$i$f$ud\\2\\450":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_45

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_46

    :cond_45
    move-object v9, v5

    :goto_46
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v10, :cond_4b

    move-object v9, v5

    :cond_4b
    check-cast v9, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_82

    .line 450
    .end local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\2":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\2\\450":I
    invoke-virtual {v4, v9}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    const/4 v6, 0x3

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v6, "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v1, 0x0

    .line 674
    .local v1, "$i$f$udOrNull\\3\\450":I
    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_67

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_68

    :cond_67
    move-object v7, v5

    :goto_68
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_6d

    move-object v5, v7

    :cond_6d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 450
    .end local v1    # "$i$f$udOrNull\\3\\450":I
    .end local v6    # "$this$udOrNull\\3":Lorg/luaj/vm2/LuaValue;
    if-nez v5, :cond_77

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getY()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    :cond_77
    invoke-virtual {v2, v4, v3, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->lookAt(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 673
    .restart local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v7    # "what\\2":Ljava/lang/String;
    .restart local v8    # "$i$f$ud\\2\\450":I
    :cond_82
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v4    # "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v7    # "what\\2":Ljava/lang/String;
    .end local v8    # "$i$f$ud\\2\\450":I
    .restart local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\1":Ljava/lang/String;
    .local v3, "$i$f$ud\\1\\450":I
    :cond_a3
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method static final install$lambda$126$lambda$124(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 451
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\1":Ljava/lang/String;
    const/4 v5, 0x0

    .line 675
    .local v5, "$i$f$ud\\1\\451":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_22

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_23

    :cond_22
    move-object v6, v7

    :goto_23
    instance-of v8, v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_28

    move-object v7, v6

    :cond_28
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v7, :cond_43

    .line 451
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\1":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\1\\451":I
    const/4 v2, 0x2

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v2

    invoke-virtual {v1, v7, v2}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromAxisAngle(Lcom/exampletest/mobilestudiotest/model/Vector3;F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 675
    .restart local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v4    # "what\\1":Ljava/lang/String;
    .restart local v5    # "$i$f$ud\\1\\451":I
    :cond_43
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, " expected, got "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final install$lambda$126$lambda$125(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 453
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 676
    .local v3, "$i$f$ud\\1\\453":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1e

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1f

    :cond_1e
    move-object v4, v5

    :goto_1f
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v6, :cond_24

    move-object v4, v5

    :cond_24
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v6, " expected, got "

    if-eqz v4, :cond_e4

    .line 453
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\453":I
    nop

    .local v4, "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 676
    .local v3, "$i$f$ud\\2\\453":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_41

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_42

    :cond_41
    move-object v7, v5

    :goto_42
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v8, :cond_47

    move-object v7, v5

    :cond_47
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v7, :cond_c3

    .line 453
    .end local v0    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\453":I
    nop

    .local v7, "x":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v0, 0x3

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v0, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\3":Ljava/lang/String;
    const/4 v3, 0x0

    .line 676
    .local v3, "$i$f$ud\\3\\453":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_62

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_63

    :cond_62
    move-object v8, v5

    :goto_63
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v9, :cond_68

    move-object v8, v5

    :cond_68
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_a2

    .line 453
    .end local v0    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\3":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\3\\453":I
    nop

    .line 454
    .local v8, "y":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v0, "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v1, 0x0

    .line 677
    .local v1, "$i$f$udOrNull\\4\\454":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v2

    if-eqz v2, :cond_81

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v2

    goto :goto_82

    :cond_81
    move-object v2, v5

    :goto_82
    instance-of v3, v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v3, :cond_87

    move-object v5, v2

    :cond_87
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 454
    .end local v0    # "$this$udOrNull\\4":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "$i$f$udOrNull\\4\\454":I
    if-nez v5, :cond_93

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/model/Vector3;->cross(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    .line 455
    .local v5, "z":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_93
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/CFrame;->Companion:Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;

    invoke-virtual {v1, v4, v7, v8, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame$Companion;->fromColumns(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 676
    .end local v5    # "z":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .end local v8    # "y":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v0, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\3":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\3\\453":I
    :cond_a2
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v1, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    .end local v7    # "x":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v0, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    .local v3, "$i$f$ud\\2\\453":I
    :cond_c3
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v1, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    .end local v4    # "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    .local v3, "$i$f$ud\\1\\453":I
    :cond_e4
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method static final install$lambda$132(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 460
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda128;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda128;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 461
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda129;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda129;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromRGB"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 462
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda130;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda130;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromHSV"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 463
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda131;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda131;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromHex"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 464
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda132;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda132;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "toHSV"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 465
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$132$lambda$127(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 460
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Color3;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v5

    const/4 v6, 0x3

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    invoke-direct {v1, v2, v5, v3}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$132$lambda$128(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 461
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v2

    const/4 v4, 0x2

    invoke-virtual {p0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-virtual {v4, v3}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v4

    const/4 v5, 0x3

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-virtual {v5, v3}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v3

    invoke-virtual {v1, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromRGB(III)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$132$lambda$129(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 462
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v2

    const/4 v4, 0x2

    invoke-virtual {p0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v4

    const/4 v5, 0x3

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v3

    invoke-virtual {v1, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromHSV(FFF)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$132$lambda$130(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 463
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/Color3;->Companion:Lcom/exampletest/mobilestudiotest/model/Color3$Companion;

    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    const-string v3, "tojstring(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Color3$Companion;->fromHex(Ljava/lang/String;)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v1

    if-eqz v1, :cond_1d

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    :cond_1d
    new-instance v0, Lorg/luaj/vm2/LuaError;

    const-string v1, "Unable to convert characters to hex value"

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final install$lambda$132$lambda$131(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 464
    const-string v0, "Color3"

    .local v0, "what\\1":Ljava/lang/String;
    move-object v1, p0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 678
    .local v2, "$i$f$ud\\1\\464":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_15

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_16

    :cond_15
    move-object v3, v4

    :goto_16
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v5, :cond_1b

    move-object v4, v3

    :cond_1b
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v4, :cond_55

    .line 464
    .end local v0    # "what\\1":Ljava/lang/String;
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\1\\464":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Color3;->toHSV()[F

    move-result-object v0

    .local v0, "h":[F
    const/4 v1, 0x3

    new-array v1, v1, [Lorg/luaj/vm2/LuaValue;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x0

    aget v4, v0, v3

    invoke-direct {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    aput-object v2, v1, v3

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x1

    aget v4, v0, v3

    invoke-direct {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    aput-object v2, v1, v3

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x2

    aget v4, v0, v3

    invoke-direct {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v1

    invoke-virtual {v1}, Lorg/luaj/vm2/Varargs;->arg1()Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg1(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v1

    .line 678
    .local v0, "what\\1":Ljava/lang/String;
    .restart local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "$i$f$ud\\1\\464":I
    :cond_55
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final install$lambda$137(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 5
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 467
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda48;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda48;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 477
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda49;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda49;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "random"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 478
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda50;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda50;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "Random"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 479
    const/16 v0, 0x8

    new-array v0, v0, [Lkotlin/Pair;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "White"

    invoke-static {v3, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v0, v3

    const/16 v2, 0x1a

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "Black"

    invoke-static {v3, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v0, v1

    const/16 v1, 0x15

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "Red"

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x2

    aput-object v1, v0, v2

    const/16 v1, 0x17

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "Blue"

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x3

    aput-object v1, v0, v2

    const/16 v1, 0x1c

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "Green"

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x4

    aput-object v1, v0, v2

    const/16 v1, 0x18

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "Yellow"

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x5

    aput-object v1, v0, v2

    const/16 v1, 0xc2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "Gray"

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x6

    aput-object v1, v0, v2

    const/16 v1, 0xc7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "DarkGray"

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x7

    aput-object v1, v0, v2

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_bb
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_e6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .local v2, "k":Ljava/lang/String;
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    .line 480
    .local v1, "v":I
    new-instance v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda51;

    invoke-direct {v3, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda51;-><init>(I)V

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v3

    check-cast v3, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, v2, v3}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .end local v1    # "v":I
    .end local v2    # "k":Ljava/lang/String;
    goto :goto_bb

    .line 481
    :cond_e6
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$137$lambda$133(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 468
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    .line 469
    .local v1, "x":Lorg/luaj/vm2/LuaValue;
    nop

    .line 470
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v2

    if-eqz v2, :cond_56

    invoke-virtual {p0}, Lorg/luaj/vm2/Varargs;->narg()I

    move-result v2

    const/4 v3, 0x3

    if-lt v2, v3, :cond_56

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v4, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v5, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v7, "arg(...)"

    invoke-static {v0, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v0

    const/4 v8, 0x2

    invoke-virtual {p0, v8}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v8

    invoke-static {v8, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v8

    invoke-virtual {p0, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v3

    invoke-direct {v6, v0, v8, v3}, Lcom/exampletest/mobilestudiotest/model/Color3;-><init>(FFF)V

    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->closest(Lcom/exampletest/mobilestudiotest/model/Color3;)I

    move-result v0

    invoke-direct {v4, v0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_101

    .line 471
    :cond_56
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v0

    if-eqz v0, :cond_6f

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->toint()I

    move-result v3

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_101

    .line 472
    :cond_6f
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isstring()Z

    move-result v0

    const/16 v2, 0xc2

    if-eqz v0, :cond_9a

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v3, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v4, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v5

    const-string v6, "tojstring(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->byName(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v4

    if-eqz v4, :cond_90

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v2

    :cond_90
    invoke-direct {v3, v2}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_101

    .line 473
    :cond_9a
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v0

    if-eqz v0, :cond_f4

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v3, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const-string v4, "Color3"

    .local v4, "what\\1":Ljava/lang/String;
    move-object v5, v1

    .local v5, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    .line 679
    .local v6, "$i$f$ud\\1\\473":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    const/4 v8, 0x0

    if-eqz v7, :cond_b9

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_ba

    :cond_b9
    move-object v7, v8

    :goto_ba
    instance-of v9, v7, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v9, :cond_bf

    move-object v8, v7

    :cond_bf
    check-cast v8, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v8, :cond_d1

    .line 473
    .end local v4    # "what\\1":Ljava/lang/String;
    .end local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$ud\\1\\473":I
    invoke-virtual {v3, v8}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->closest(Lcom/exampletest/mobilestudiotest/model/Color3;)I

    move-result v3

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_101

    .line 679
    .restart local v4    # "what\\1":Ljava/lang/String;
    .restart local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v6    # "$i$f$ud\\1\\473":I
    :cond_d1
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v7, " expected, got "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 474
    .end local v4    # "what\\1":Ljava/lang/String;
    .end local v5    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$ud\\1\\473":I
    :cond_f4
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v3, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    invoke-direct {v3, v2}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    .line 475
    :goto_101
    return-object v0
.end method

.method static final install$lambda$137$lambda$134(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 4

    const-string v0, "<unused var>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 477
    sget-object p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->getAll()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    sget-object v2, Lkotlin/random/Random;->Default:Lkotlin/random/Random$Default;

    check-cast v2, Lkotlin/random/Random;

    invoke-static {v1, v2}, Lkotlin/collections/CollectionsKt;->random(Ljava/util/Collection;Lkotlin/random/Random;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object p0

    check-cast p0, Lorg/luaj/vm2/Varargs;

    return-object p0
.end method

.method static final install$lambda$137$lambda$135(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 4

    const-string v0, "<unused var>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 478
    sget-object p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    sget-object v1, Lcom/exampletest/mobilestudiotest/model/BrickColors;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/BrickColors;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/BrickColors;->getAll()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    sget-object v2, Lkotlin/random/Random;->Default:Lkotlin/random/Random$Default;

    check-cast v2, Lkotlin/random/Random;

    invoke-static {v1, v2}, Lkotlin/collections/CollectionsKt;->random(Ljava/util/Collection;Lkotlin/random/Random;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object p0

    check-cast p0, Lorg/luaj/vm2/Varargs;

    return-object p0
.end method

.method static final install$lambda$137$lambda$136(ILorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 3
    .param p0, "$v"    # I

    const-string v0, "<unused var>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 480
    sget-object p1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/BrickColorV;

    invoke-direct {v0, p0}, Lcom/exampletest/mobilestudiotest/model/BrickColorV;-><init>(I)V

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    check-cast p1, Lorg/luaj/vm2/Varargs;

    return-object p1
.end method

.method static final install$lambda$139(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 482
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda101;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda101;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$139$lambda$138(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 6
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 482
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    invoke-static {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v3, 0x2

    invoke-virtual {p0, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v3

    invoke-direct {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$143(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 484
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda111;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda111;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 490
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda112;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda112;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromScale"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 491
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda113;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda113;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromOffset"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 492
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$143$lambda$140(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 9
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 485
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v1

    const/4 v2, 0x2

    const-string v3, "arg(...)"

    if-eqz v1, :cond_b7

    .line 486
    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "UDim"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v1, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 680
    .local v4, "$i$f$ud\\1\\486":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_29

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_2a

    :cond_29
    move-object v5, v6

    :goto_2a
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-nez v7, :cond_2f

    move-object v5, v6

    :cond_2f
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/UDim;

    const-string v7, " expected, got "

    if-eqz v5, :cond_96

    .line 486
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\486":I
    nop

    .local v5, "x":Lcom/exampletest/mobilestudiotest/model/UDim;
    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "UDim"

    .local v0, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v1, "what\\2":Ljava/lang/String;
    const/4 v2, 0x0

    .line 680
    .local v2, "$i$f$ud\\2\\486":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    if-eqz v3, :cond_4b

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_4c

    :cond_4b
    move-object v3, v6

    :goto_4c
    instance-of v4, v3, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v4, :cond_51

    move-object v6, v3

    :cond_51
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v6, :cond_75

    .line 486
    .end local v0    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "what\\2":Ljava/lang/String;
    .end local v2    # "$i$f$ud\\2\\486":I
    nop

    .line 487
    .local v6, "y":Lcom/exampletest/mobilestudiotest/model/UDim;
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v2

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v3

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v4

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v7

    invoke-direct {v1, v2, v3, v4, v7}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v5    # "x":Lcom/exampletest/mobilestudiotest/model/UDim;
    .end local v6    # "y":Lcom/exampletest/mobilestudiotest/model/UDim;
    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_f5

    .line 680
    .restart local v0    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v1    # "what\\2":Ljava/lang/String;
    .restart local v2    # "$i$f$ud\\2\\486":I
    .restart local v5    # "x":Lcom/exampletest/mobilestudiotest/model/UDim;
    :cond_75
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3

    .end local v2    # "$i$f$ud\\2\\486":I
    .end local v5    # "x":Lcom/exampletest/mobilestudiotest/model/UDim;
    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v1, "what\\1":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\1\\486":I
    :cond_96
    new-instance v2, Lorg/luaj/vm2/LuaError;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v2

    .line 488
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\486":I
    :cond_b7
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v4, Lcom/exampletest/mobilestudiotest/model/UDim2;

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x0

    invoke-static {v0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v0

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    float-to-int v2, v2

    const/4 v6, 0x3

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v6

    const/4 v7, 0x4

    invoke-virtual {p0, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v7

    invoke-static {v7, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v7, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    float-to-int v3, v3

    invoke-direct {v4, v0, v2, v6, v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    invoke-virtual {v1, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    :goto_f5
    return-object v0
.end method

.method static final install$lambda$143$lambda$141(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 490
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    const/4 v4, 0x0

    invoke-direct {v1, v2, v4, v3, v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$143$lambda$142(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 491
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    float-to-int v2, v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    float-to-int v3, v3

    invoke-direct {v1, v4, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$145(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 494
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda147;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda147;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 500
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$145$lambda$144(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 13
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 495
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;

    .line 496
    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-string v4, "arg(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v6, 0x0

    .line 681
    .local v6, "$i$f$udOrNull\\1\\496":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    const/4 v8, 0x0

    if-eqz v7, :cond_2e

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_2f

    :cond_2e
    move-object v7, v8

    :goto_2f
    instance-of v9, v7, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-nez v9, :cond_34

    move-object v7, v8

    :cond_34
    check-cast v7, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 496
    .end local v5    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v6    # "$i$f$udOrNull\\1\\496":I
    const/4 v5, 0x3

    if-eqz v7, :cond_3e

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v6

    goto :goto_3f

    :cond_3e
    move v6, v5

    :goto_3f
    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v7, 0x0

    .line 681
    .local v7, "$i$f$udOrNull\\2\\496":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v9

    if-eqz v9, :cond_52

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v9

    goto :goto_53

    :cond_52
    move-object v9, v8

    :goto_53
    instance-of v10, v9, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v10, :cond_58

    move-object v8, v9

    :cond_58
    check-cast v8, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 496
    .end local v5    # "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "$i$f$udOrNull\\2\\496":I
    if-eqz v8, :cond_60

    invoke-virtual {v8}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v2

    .line 497
    :cond_60
    const/4 v5, 0x4

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    const/4 v7, 0x0

    invoke-virtual {v5, v7}, Lorg/luaj/vm2/LuaValue;->optint(I)I

    move-result v5

    const/4 v8, 0x5

    invoke-virtual {p0, v8}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v8

    invoke-virtual {v8, v7}, Lorg/luaj/vm2/LuaValue;->optboolean(Z)Z

    move-result v7

    const/4 v8, 0x6

    invoke-virtual {p0, v8}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v8

    invoke-static {v8, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v8, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v4

    .line 495
    move v11, v4

    move v4, v2

    move v2, v3

    move v3, v6

    move v6, v7

    move v7, v11

    invoke-direct/range {v1 .. v7}, Lcom/exampletest/mobilestudiotest/lua/TweenInfoV;-><init>(FIIIZF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    .line 498
    return-object v0
.end method

.method static final install$lambda$147(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 501
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda143;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda143;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$147$lambda$146(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 501
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Ray;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "Vector3"

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\1":Ljava/lang/String;
    const/4 v5, 0x0

    .line 682
    .local v5, "$i$f$ud\\1\\501":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_22

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_23

    :cond_22
    move-object v6, v7

    :goto_23
    instance-of v8, v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v8, :cond_28

    move-object v6, v7

    :cond_28
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v8, " expected, got "

    if-eqz v6, :cond_79

    .line 501
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "what\\1":Ljava/lang/String;
    .end local v5    # "$i$f$ud\\1\\501":I
    const/4 v2, 0x2

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "Vector3"

    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\2":Ljava/lang/String;
    const/4 v4, 0x0

    .line 682
    .local v4, "$i$f$ud\\2\\501":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    if-eqz v5, :cond_44

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_45

    :cond_44
    move-object v5, v7

    :goto_45
    instance-of v9, v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v9, :cond_4a

    move-object v7, v5

    :cond_4a
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v7, :cond_58

    .line 501
    .end local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\2\\501":I
    invoke-direct {v1, v6, v7}, Lcom/exampletest/mobilestudiotest/model/Ray;-><init>(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 682
    .restart local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "what\\2":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\2\\501":I
    :cond_58
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v1

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v3    # "what\\2":Ljava/lang/String;
    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v4, "what\\1":Ljava/lang/String;
    .restart local v5    # "$i$f$ud\\1\\501":I
    :cond_79
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final install$lambda$149(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 503
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda11;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda11;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 507
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$149$lambda$148(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 504
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v0, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 683
    .local v2, "$i$f$udOrNull\\1\\504":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1c

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1d

    :cond_1c
    move-object v3, v4

    :goto_1d
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v5, :cond_22

    move-object v3, v4

    :cond_22
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 504
    .end local v0    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$udOrNull\\1\\504":I
    if-nez v3, :cond_2c

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    .local v3, "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_2c
    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v0, "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v1, 0x0

    .line 683
    .local v1, "$i$f$udOrNull\\2\\504":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v2

    if-eqz v2, :cond_40

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v2

    goto :goto_41

    :cond_40
    move-object v2, v4

    :goto_41
    instance-of v5, v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_46

    move-object v4, v2

    :cond_46
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    .line 504
    .end local v0    # "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "$i$f$udOrNull\\2\\504":I
    if-nez v4, :cond_50

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getZERO()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    .line 505
    .local v4, "q":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :cond_50
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/Region3V;

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->min(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->max(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-direct {v1, v2, v5}, Lcom/exampletest/mobilestudiotest/lua/Region3V;-><init>(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$151(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 509
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda142;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda142;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 512
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$151$lambda$150(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 510
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/Region3int16V;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v2, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v4, 0x0

    .line 684
    .local v4, "$i$f$udOrNull\\1\\510":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    .line 510
    .end local v2    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "$i$f$udOrNull\\1\\510":I
    const/4 v2, 0x0

    if-nez v5, :cond_30

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    invoke-direct {v5, v2, v2, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3int16;-><init>(III)V

    :cond_30
    const/4 v4, 0x2

    invoke-virtual {p0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v4, "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 684
    .local v3, "$i$f$udOrNull\\2\\510":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_44

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_45

    :cond_44
    move-object v7, v6

    :goto_45
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    if-eqz v8, :cond_4a

    move-object v6, v7

    :cond_4a
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    .line 510
    .end local v3    # "$i$f$udOrNull\\2\\510":I
    .end local v4    # "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    if-nez v6, :cond_53

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/Vector3int16;

    invoke-direct {v6, v2, v2, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3int16;-><init>(III)V

    :cond_53
    invoke-direct {v1, v5, v6}, Lcom/exampletest/mobilestudiotest/lua/Region3int16V;-><init>(Lcom/exampletest/mobilestudiotest/model/Vector3int16;Lcom/exampletest/mobilestudiotest/model/Vector3int16;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$153(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 513
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda127;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda127;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$153$lambda$152(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 6
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 513
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v0

    .local v0, "mn":F
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v3, Lcom/exampletest/mobilestudiotest/model/NumberRange;

    const/4 v4, 0x2

    invoke-virtual {p0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v1

    invoke-direct {v3, v0, v1}, Lcom/exampletest/mobilestudiotest/model/NumberRange;-><init>(FF)V

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    return-object v1
.end method

.method static final install$lambda$155(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 514
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda146;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda146;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$155$lambda$154(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 514
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v2

    const/4 v4, 0x2

    invoke-virtual {p0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v4

    const/4 v5, 0x3

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    invoke-static {v5, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    invoke-direct {v1, v2, v4, v3}, Lcom/exampletest/mobilestudiotest/model/NumberKey;-><init>(FFF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$157(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 515
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda45;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda45;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$157$lambda$156(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 515
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v2

    const/4 v4, 0x2

    invoke-virtual {p0, v4}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "Color3"

    .local v3, "what\\1":Ljava/lang/String;
    .local v4, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 685
    .local v5, "$i$f$ud\\1\\515":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_2e

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_2f

    :cond_2e
    move-object v6, v7

    :goto_2f
    instance-of v8, v6, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v8, :cond_34

    move-object v7, v6

    :cond_34
    check-cast v7, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v7, :cond_43

    .line 515
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\1\\515":I
    const/4 v3, 0x0

    invoke-direct {v1, v2, v7, v3}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 685
    .restart local v3    # "what\\1":Ljava/lang/String;
    .restart local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\1\\515":I
    :cond_43
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v6, " expected, got "

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final install$lambda$160(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 517
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda145;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda145;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 525
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$160$lambda$159(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 19
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v0, p0

    const-string v1, "a"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 518
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    .line 519
    .local v2, "x":Lorg/luaj/vm2/LuaValue;
    nop

    .line 520
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v3

    if-eqz v3, :cond_a9

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v4, Lkotlin/ranges/IntRange;

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->length()I

    move-result v5

    invoke-direct {v4, v1, v5}, Lkotlin/ranges/IntRange;-><init>(II)V

    move-object v1, v4

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 686
    .local v4, "$i$f$map\\1\\520":I
    new-instance v5, Ljava/util/ArrayList;

    const/16 v6, 0xa

    invoke-static {v1, v6}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v6

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\2":Ljava/util/Collection;
    move-object v6, v1

    .local v6, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 687
    .local v7, "$i$f$mapTo\\2\\686":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_35
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_97

    move-object v9, v8

    check-cast v9, Lkotlin/collections/IntIterator;

    invoke-virtual {v9}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v9

    .line 688
    .local v9, "item\\2":I
    move v10, v9

    .local v10, "it\\3":I
    const/4 v11, 0x0

    .line 520
    .local v11, "$i$a$-map-LuaTypes$install$17$1$1\\3\\688\\0":I
    invoke-virtual {v2, v10}, Lorg/luaj/vm2/LuaValue;->get(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v12

    const-string v13, "get(...)"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v13, "NumberSequenceKeypoint"

    .local v12, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .local v13, "what\\4":Ljava/lang/String;
    const/4 v14, 0x0

    .line 689
    .local v14, "$i$f$ud\\4\\520":I
    invoke-virtual {v12}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v15

    const/16 v16, 0x0

    if-eqz v15, :cond_5d

    invoke-virtual {v12}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v15

    goto :goto_5f

    :cond_5d
    move-object/from16 v15, v16

    :goto_5f
    move-object/from16 v17, v1

    .end local v1    # "$this$map\\1":Ljava/lang/Iterable;
    .local v17, "$this$map\\1":Ljava/lang/Iterable;
    instance-of v1, v15, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    if-eqz v1, :cond_67

    move-object/from16 v16, v15

    :cond_67
    move-object/from16 v1, v16

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    if-eqz v1, :cond_74

    .line 520
    .end local v12    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v13    # "what\\4":Ljava/lang/String;
    .end local v14    # "$i$f$ud\\4\\520":I
    nop

    .line 688
    .end local v10    # "it\\3":I
    .end local v11    # "$i$a$-map-LuaTypes$install$17$1$1\\3\\688\\0":I
    invoke-interface {v5, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, v17

    goto :goto_35

    .line 689
    .restart local v10    # "it\\3":I
    .restart local v11    # "$i$a$-map-LuaTypes$install$17$1$1\\3\\688\\0":I
    .restart local v12    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .restart local v13    # "what\\4":Ljava/lang/String;
    .restart local v14    # "$i$f$ud\\4\\520":I
    :cond_74
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v3, v12}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v3

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v15, " expected, got "

    invoke-virtual {v8, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 690
    .end local v9    # "item\\2":I
    .end local v10    # "it\\3":I
    .end local v11    # "$i$a$-map-LuaTypes$install$17$1$1\\3\\688\\0":I
    .end local v12    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v13    # "what\\4":Ljava/lang/String;
    .end local v14    # "$i$f$ud\\4\\520":I
    .end local v17    # "$this$map\\1":Ljava/lang/Iterable;
    .restart local v1    # "$this$map\\1":Ljava/lang/Iterable;
    :cond_97
    move-object/from16 v17, v1

    .end local v1    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v5    # "destination\\2":Ljava/util/Collection;
    .end local v6    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v7    # "$i$f$mapTo\\2\\686":I
    .restart local v17    # "$this$map\\1":Ljava/lang/Iterable;
    move-object v1, v5

    check-cast v1, Ljava/util/List;

    .line 686
    nop

    .line 520
    .end local v4    # "$i$f$map\\1\\520":I
    .end local v17    # "$this$map\\1":Ljava/lang/Iterable;
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/NumberSequence;

    invoke-direct {v4, v1}, Lcom/exampletest/mobilestudiotest/model/NumberSequence;-><init>(Ljava/util/List;)V

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    goto :goto_116

    .line 521
    :cond_a9
    invoke-virtual {v0}, Lorg/luaj/vm2/Varargs;->narg()I

    move-result v3

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-lt v3, v6, :cond_ea

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v8, Lcom/exampletest/mobilestudiotest/model/NumberSequence;

    new-array v9, v6, [Lcom/exampletest/mobilestudiotest/model/NumberKey;

    new-instance v10, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v11

    invoke-direct {v10, v7, v11, v7}, Lcom/exampletest/mobilestudiotest/model/NumberKey;-><init>(FFF)V

    aput-object v10, v9, v5

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    invoke-virtual {v0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    const-string v10, "arg(...)"

    invoke-static {v6, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v6

    invoke-direct {v5, v4, v6, v7}, Lcom/exampletest/mobilestudiotest/model/NumberKey;-><init>(FFF)V

    aput-object v5, v9, v1

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v8, v1}, Lcom/exampletest/mobilestudiotest/model/NumberSequence;-><init>(Ljava/util/List;)V

    invoke-virtual {v3, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    goto :goto_116

    .line 522
    :cond_ea
    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v8, Lcom/exampletest/mobilestudiotest/model/NumberSequence;

    new-array v6, v6, [Lcom/exampletest/mobilestudiotest/model/NumberKey;

    new-instance v9, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v10

    invoke-direct {v9, v7, v10, v7}, Lcom/exampletest/mobilestudiotest/model/NumberKey;-><init>(FFF)V

    aput-object v9, v6, v5

    new-instance v5, Lcom/exampletest/mobilestudiotest/model/NumberKey;

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v9

    invoke-direct {v5, v4, v9, v7}, Lcom/exampletest/mobilestudiotest/model/NumberKey;-><init>(FFF)V

    aput-object v5, v6, v1

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v8, v1}, Lcom/exampletest/mobilestudiotest/model/NumberSequence;-><init>(Ljava/util/List;)V

    invoke-virtual {v3, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    .line 523
    :goto_116
    return-object v1
.end method

.method static final install$lambda$163(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 527
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda65;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda65;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 535
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$163$lambda$162(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 20
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    move-object/from16 v0, p0

    const-string v1, "a"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 528
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    .line 529
    .local v2, "x":Lorg/luaj/vm2/LuaValue;
    nop

    .line 530
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->istable()Z

    move-result v3

    const-string v4, " expected, got "

    if-eqz v3, :cond_a7

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v6, Lkotlin/ranges/IntRange;

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->length()I

    move-result v7

    invoke-direct {v6, v1, v7}, Lkotlin/ranges/IntRange;-><init>(II)V

    move-object v1, v6

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 691
    .local v6, "$i$f$map\\1\\530":I
    new-instance v7, Ljava/util/ArrayList;

    const/16 v8, 0xa

    invoke-static {v1, v8}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v7, v8}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\2":Ljava/util/Collection;
    move-object v8, v1

    .local v8, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 692
    .local v9, "$i$f$mapTo\\2\\691":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_37
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_94

    move-object v11, v10

    check-cast v11, Lkotlin/collections/IntIterator;

    invoke-virtual {v11}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v11

    .line 693
    .local v11, "item\\2":I
    move v12, v11

    .local v12, "it\\3":I
    const/4 v13, 0x0

    .line 530
    .local v13, "$i$a$-map-LuaTypes$install$18$1$1\\3\\693\\0":I
    invoke-virtual {v2, v12}, Lorg/luaj/vm2/LuaValue;->get(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v14

    const-string v15, "get(...)"

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "ColorSequenceKeypoint"

    .local v14, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .local v15, "what\\4":Ljava/lang/String;
    const/16 v16, 0x0

    .line 694
    .local v16, "$i$f$ud\\4\\530":I
    invoke-virtual {v14}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v17

    if-eqz v17, :cond_60

    invoke-virtual {v14}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v5, v17

    goto :goto_61

    :cond_60
    const/4 v5, 0x0

    :goto_61
    move-object/from16 v18, v1

    .end local v1    # "$this$map\\1":Ljava/lang/Iterable;
    .local v18, "$this$map\\1":Ljava/lang/Iterable;
    instance-of v1, v5, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    if-nez v1, :cond_68

    const/4 v5, 0x0

    :cond_68
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    if-eqz v5, :cond_73

    .line 530
    .end local v14    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v15    # "what\\4":Ljava/lang/String;
    .end local v16    # "$i$f$ud\\4\\530":I
    nop

    .line 693
    .end local v12    # "it\\3":I
    .end local v13    # "$i$a$-map-LuaTypes$install$18$1$1\\3\\693\\0":I
    invoke-interface {v7, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, v18

    goto :goto_37

    .line 694
    .restart local v12    # "it\\3":I
    .restart local v13    # "$i$a$-map-LuaTypes$install$18$1$1\\3\\693\\0":I
    .restart local v14    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .restart local v15    # "what\\4":Ljava/lang/String;
    .restart local v16    # "$i$f$ud\\4\\530":I
    :cond_73
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v3, v14}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 695
    .end local v11    # "item\\2":I
    .end local v12    # "it\\3":I
    .end local v13    # "$i$a$-map-LuaTypes$install$18$1$1\\3\\693\\0":I
    .end local v14    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v15    # "what\\4":Ljava/lang/String;
    .end local v16    # "$i$f$ud\\4\\530":I
    .end local v18    # "$this$map\\1":Ljava/lang/Iterable;
    .restart local v1    # "$this$map\\1":Ljava/lang/Iterable;
    :cond_94
    move-object/from16 v18, v1

    .end local v1    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v7    # "destination\\2":Ljava/util/Collection;
    .end local v8    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapTo\\2\\691":I
    .restart local v18    # "$this$map\\1":Ljava/lang/Iterable;
    move-object v1, v7

    check-cast v1, Ljava/util/List;

    .line 691
    nop

    .line 530
    .end local v6    # "$i$f$map\\1\\530":I
    .end local v18    # "$this$map\\1":Ljava/lang/Iterable;
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/ColorSequence;

    invoke-direct {v4, v1}, Lcom/exampletest/mobilestudiotest/model/ColorSequence;-><init>(Ljava/util/List;)V

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1a1

    .line 531
    :cond_a7
    invoke-virtual {v0}, Lorg/luaj/vm2/Varargs;->narg()I

    move-result v3

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-lt v3, v7, :cond_15c

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v9, Lcom/exampletest/mobilestudiotest/model/ColorSequence;

    new-array v10, v7, [Lcom/exampletest/mobilestudiotest/model/ColorKey;

    new-instance v11, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const-string v12, "Color3"

    .local v12, "what\\5":Ljava/lang/String;
    move-object v13, v2

    .local v13, "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    const/4 v14, 0x0

    .line 696
    .local v14, "$i$f$ud\\5\\531":I
    invoke-virtual {v13}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v15

    if-eqz v15, :cond_cc

    invoke-virtual {v13}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v15

    goto :goto_cd

    :cond_cc
    const/4 v15, 0x0

    :goto_cd
    move/from16 v16, v1

    instance-of v1, v15, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-nez v1, :cond_d4

    const/4 v15, 0x0

    :cond_d4
    check-cast v15, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v15, :cond_13b

    .line 531
    .end local v12    # "what\\5":Ljava/lang/String;
    .end local v13    # "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .end local v14    # "$i$f$ud\\5\\531":I
    invoke-direct {v11, v8, v15, v8}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    aput-object v11, v10, v6

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    invoke-virtual {v0, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    const-string v7, "arg(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "Color3"

    .local v6, "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .local v7, "what\\6":Ljava/lang/String;
    const/4 v11, 0x0

    .line 696
    .local v11, "$i$f$ud\\6\\531":I
    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v12

    if-eqz v12, :cond_f6

    invoke-virtual {v6}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v12

    goto :goto_f7

    :cond_f6
    const/4 v12, 0x0

    :goto_f7
    instance-of v13, v12, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-nez v13, :cond_fe

    const/16 v17, 0x0

    goto :goto_100

    :cond_fe
    move-object/from16 v17, v12

    :goto_100
    move-object/from16 v12, v17

    check-cast v12, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v12, :cond_11a

    .line 531
    .end local v6    # "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\6":Ljava/lang/String;
    .end local v11    # "$i$f$ud\\6\\531":I
    invoke-direct {v1, v5, v12, v8}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    aput-object v1, v10, v16

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v9, v1}, Lcom/exampletest/mobilestudiotest/model/ColorSequence;-><init>(Ljava/util/List;)V

    invoke-virtual {v3, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    goto/16 :goto_1a1

    .line 696
    .restart local v6    # "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .restart local v7    # "what\\6":Ljava/lang/String;
    .restart local v11    # "$i$f$ud\\6\\531":I
    :cond_11a
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v3, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    .end local v6    # "$this$ud\\6":Lorg/luaj/vm2/LuaValue;
    .end local v7    # "what\\6":Ljava/lang/String;
    .end local v11    # "$i$f$ud\\6\\531":I
    .restart local v12    # "what\\5":Ljava/lang/String;
    .restart local v13    # "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .restart local v14    # "$i$f$ud\\5\\531":I
    :cond_13b
    new-instance v1, Lorg/luaj/vm2/LuaError;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v3, v13}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 532
    .end local v12    # "what\\5":Ljava/lang/String;
    .end local v13    # "$this$ud\\5":Lorg/luaj/vm2/LuaValue;
    .end local v14    # "$i$f$ud\\5\\531":I
    :cond_15c
    move/from16 v16, v1

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const-string v1, "Color3"

    .local v1, "what\\7":Ljava/lang/String;
    move-object v3, v2

    .local v3, "$this$ud\\7":Lorg/luaj/vm2/LuaValue;
    const/4 v9, 0x0

    .line 697
    .local v9, "$i$f$ud\\7\\532":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v10

    if-eqz v10, :cond_170

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v10

    goto :goto_171

    :cond_170
    const/4 v10, 0x0

    :goto_171
    instance-of v11, v10, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-nez v11, :cond_178

    const/16 v17, 0x0

    goto :goto_17a

    :cond_178
    move-object/from16 v17, v10

    :goto_17a
    check-cast v17, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v17, :cond_1a2

    .line 532
    .end local v1    # "what\\7":Ljava/lang/String;
    .end local v3    # "$this$ud\\7":Lorg/luaj/vm2/LuaValue;
    .end local v9    # "$i$f$ud\\7\\532":I
    move-object/from16 v1, v17

    .local v1, "c":Lcom/exampletest/mobilestudiotest/model/Color3;
    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v4, Lcom/exampletest/mobilestudiotest/model/ColorSequence;

    new-array v7, v7, [Lcom/exampletest/mobilestudiotest/model/ColorKey;

    new-instance v9, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    invoke-direct {v9, v8, v1, v8}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    aput-object v9, v7, v6

    new-instance v6, Lcom/exampletest/mobilestudiotest/model/ColorKey;

    invoke-direct {v6, v5, v1, v8}, Lcom/exampletest/mobilestudiotest/model/ColorKey;-><init>(FLcom/exampletest/mobilestudiotest/model/Color3;F)V

    aput-object v6, v7, v16

    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-direct {v4, v5}, Lcom/exampletest/mobilestudiotest/model/ColorSequence;-><init>(Ljava/util/List;)V

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    .end local v1    # "c":Lcom/exampletest/mobilestudiotest/model/Color3;
    check-cast v1, Lorg/luaj/vm2/Varargs;

    .line 533
    :goto_1a1
    return-object v1

    .line 697
    .local v1, "what\\7":Ljava/lang/String;
    .restart local v3    # "$this$ud\\7":Lorg/luaj/vm2/LuaValue;
    .restart local v9    # "$i$f$ud\\7\\532":I
    :cond_1a2
    new-instance v5, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v5, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v5
.end method

.method static final install$lambda$165(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 536
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda0;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$165$lambda$164(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 5
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 536
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/RandomV;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isnil()Z

    move-result v3

    if-eqz v3, :cond_19

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    goto :goto_21

    :cond_19
    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->tolong()J

    move-result-wide v2

    :goto_21
    invoke-direct {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/lua/RandomV;-><init>(J)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$167(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 537
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda110;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda110;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$167$lambda$166(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 9
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 537
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Rect;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v2

    const/4 v5, 0x2

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v5, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v5

    const/4 v6, 0x3

    invoke-virtual {p0, v6}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v6

    const/4 v7, 0x4

    invoke-virtual {p0, v7}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v7

    invoke-static {v7, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v7, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v3

    invoke-direct {v1, v2, v5, v6, v3}, Lcom/exampletest/mobilestudiotest/model/Rect;-><init>(FFFF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$169(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 539
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda144;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda144;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 543
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$169$lambda$168(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 13
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 540
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v1

    if-eqz v1, :cond_28

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;

    const/16 v9, 0x7e

    const/4 v10, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct/range {v1 .. v10}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;-><init>(IFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    goto :goto_82

    .line 541
    :cond_28
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v3, "arg(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const v4, 0x3f333333    # 0.7f

    invoke-static {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v4

    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const v5, 0x3e99999a    # 0.3f

    invoke-static {v0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v5

    const/4 v0, 0x3

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v6, 0x3f000000    # 0.5f

    invoke-static {v0, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v6

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v0, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v0

    const/4 v8, 0x5

    invoke-virtual {p0, v8}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v8

    invoke-static {v8, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v8, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v8

    const/16 v10, 0x40

    const/4 v11, 0x0

    const/4 v3, 0x1

    const/4 v9, 0x0

    move v7, v0

    invoke-direct/range {v2 .. v11}, Lcom/exampletest/mobilestudiotest/model/PhysicalProps;-><init>(IFFFFFFILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    :goto_82
    return-object v0
.end method

.method static final install$lambda$173(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 3
    .param p0, "$this$lib"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "$this$lib"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 545
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda97;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda97;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "new"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 546
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda98;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda98;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromEnum"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 547
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda99;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda99;-><init>()V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    const-string v1, "fromName"

    invoke-virtual {p0, v1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 548
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final install$lambda$173$lambda$170(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 545
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/FontValue;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    const-string v3, "tojstring(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x2

    invoke-virtual {p0, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-string v4, "arg(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v3, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 698
    .local v5, "$i$f$udOrNull\\1\\545":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_2e

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_2f

    :cond_2e
    move-object v6, v7

    :goto_2f
    instance-of v8, v6, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-nez v8, :cond_34

    move-object v6, v7

    :cond_34
    check-cast v6, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 545
    .end local v3    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$udOrNull\\1\\545":I
    if-eqz v6, :cond_3d

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v3

    goto :goto_3f

    :cond_3d
    const/16 v3, 0x190

    :goto_3f
    const/4 v5, 0x3

    invoke-virtual {p0, v5}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v5, "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v4, 0x0

    .line 698
    .local v4, "$i$f$udOrNull\\2\\545":I
    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_53

    invoke-virtual {v5}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_54

    :cond_53
    move-object v6, v7

    :goto_54
    instance-of v8, v6, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v8, :cond_59

    move-object v7, v6

    :cond_59
    check-cast v7, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 545
    .end local v4    # "$i$f$udOrNull\\2\\545":I
    .end local v5    # "$this$udOrNull\\2":Lorg/luaj/vm2/LuaValue;
    if-eqz v7, :cond_62

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getValue()I

    move-result v4

    goto :goto_63

    :cond_62
    const/4 v4, 0x0

    :goto_63
    const-string v5, ""

    invoke-direct {v1, v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/FontValue;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$173$lambda$171(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 546
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/FontValue;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    const-string v3, "arg(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .local v2, "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 699
    .local v3, "$i$f$udOrNull\\1\\546":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_20

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_21

    :cond_20
    move-object v4, v5

    :goto_21
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    if-eqz v6, :cond_26

    move-object v5, v4

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .line 546
    .end local v2    # "$this$udOrNull\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$udOrNull\\1\\546":I
    if-eqz v5, :cond_31

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getName()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_31

    goto :goto_33

    :cond_31
    const-string v2, "SourceSansPro"

    :goto_33
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "rbxasset://fonts/families/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ".json"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    const-string v4, ""

    const/16 v5, 0x190

    invoke-direct {v1, v2, v5, v3, v4}, Lcom/exampletest/mobilestudiotest/model/FontValue;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final install$lambda$173$lambda$172(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 547
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/FontValue;

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "rbxasset://fonts/families/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ".json"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    const-string v4, ""

    const/16 v5, 0x190

    invoke-direct {v1, v2, v5, v3, v4}, Lcom/exampletest/mobilestudiotest/model/FontValue;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method private static final install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    .registers 4
    .param p0, "$g"    # Lorg/luaj/vm2/LuaTable;
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "build"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/luaj/vm2/LuaTable;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/luaj/vm2/LuaTable;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 404
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    invoke-interface {p2, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {p0, p1, v0}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    return-void
.end method

.method static final lambda$17$lambda$10(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 97
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "x":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-float v3, v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-float v4, v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-float v5, v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    return-object v1
.end method

.method static final lambda$17$lambda$11(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "x":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v3

    double-to-float v3, v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v4

    double-to-float v4, v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    double-to-float v5, v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    return-object v1
.end method

.method static final lambda$17$lambda$12(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "x":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->signum(F)F

    move-result v3

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Math;->signum(F)F

    move-result v4

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->signum(F)F

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    return-object v1
.end method

.method static final lambda$17$lambda$13(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 5
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->min(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$17$lambda$14(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 5
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->max(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$17$lambda$15(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .local v0, "x":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x2

    invoke-direct {v1, p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .local v1, "y":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v3

    const/high16 v4, -0x40800000    # -1.0f

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v3, v4, v5}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v3

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->acos(D)D

    move-result-wide v3

    double-to-float v3, v3

    invoke-direct {v2, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/Varargs;

    return-object v2
.end method

.method static final lambda$17$lambda$16(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 6
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 103
    const/4 v0, 0x3

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const v1, 0x3727c5ac    # 1.0E-5f

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v0

    .local v0, "e":F
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v4, 0x2

    invoke-direct {v3, p0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getMagnitude()F

    move-result v1

    cmpg-float v1, v1, v0

    if-lez v1, :cond_31

    const/4 v2, 0x0

    :cond_31
    invoke-static {v2}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v1

    const-string v2, "valueOf(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lorg/luaj/vm2/Varargs;

    return-object v1
.end method

.method static final lambda$17$lambda$6(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 5
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$17$lambda$7(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 5
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->cross(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$17$lambda$8(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 6
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 95
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    const/4 v3, 0x3

    invoke-virtual {p0, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const-string v4, "arg(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v3

    invoke-virtual {v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->lerp(Lcom/exampletest/mobilestudiotest/model/Vector3;F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$17$lambda$9(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 4
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->arg3(Lorg/luaj/vm2/Varargs;I)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->abs()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$23$lambda$18(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 107
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "Vector3"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 606
    .local v3, "$i$f$ud\\1\\107":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1c

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1d

    :cond_1c
    move-object v4, v5

    :goto_1d
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v6, :cond_22

    move-object v4, v5

    :cond_22
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v6, " expected, got "

    if-eqz v4, :cond_6b

    .line 107
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\107":I
    const-string v1, "Vector3"

    .local v1, "what\\2":Ljava/lang/String;
    move-object v2, p1

    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 606
    .local v3, "$i$f$ud\\2\\107":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_37

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_38

    :cond_37
    move-object v7, v5

    :goto_38
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_3d

    move-object v5, v7

    :cond_3d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_4a

    .line 107
    .end local v1    # "what\\2":Ljava/lang/String;
    .end local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\2\\107":I
    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 606
    .restart local v1    # "what\\2":Ljava/lang/String;
    .restart local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\2\\107":I
    :cond_4a
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "what\\1":Ljava/lang/String;
    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "$i$f$ud\\1\\107":I
    :cond_6b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$23$lambda$19(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "Vector3"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 607
    .local v3, "$i$f$ud\\1\\108":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1c

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1d

    :cond_1c
    move-object v4, v5

    :goto_1d
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v6, :cond_22

    move-object v4, v5

    :cond_22
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v6, " expected, got "

    if-eqz v4, :cond_6b

    .line 108
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\108":I
    const-string v1, "Vector3"

    .local v1, "what\\2":Ljava/lang/String;
    move-object v2, p1

    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 607
    .local v3, "$i$f$ud\\2\\108":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_37

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_38

    :cond_37
    move-object v7, v5

    :goto_38
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_3d

    move-object v5, v7

    :cond_3d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_4a

    .line 108
    .end local v1    # "what\\2":Ljava/lang/String;
    .end local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\2\\108":I
    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 607
    .restart local v1    # "what\\2":Ljava/lang/String;
    .restart local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\2\\108":I
    :cond_4a
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "what\\1":Ljava/lang/String;
    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "$i$f$ud\\1\\108":I
    :cond_6b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$23$lambda$20(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    nop

    .line 111
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v0

    const-string v1, " expected, got "

    const/4 v2, 0x0

    if-eqz v0, :cond_5e

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v3, "Vector3"

    .local v3, "what\\1":Ljava/lang/String;
    move-object v4, p1

    .local v4, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 608
    .local v5, "$i$f$ud\\1\\111":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_25

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_26

    :cond_25
    move-object v6, v2

    :goto_26
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v7, :cond_2b

    move-object v2, v6

    :cond_2b
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v2, :cond_3d

    .line 111
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\1\\111":I
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto/16 :goto_e9

    .line 608
    .restart local v3    # "what\\1":Ljava/lang/String;
    .restart local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\1\\111":I
    :cond_3d
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 112
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\1\\111":I
    :cond_5e
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v0

    if-eqz v0, :cond_ad

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v3, "Vector3"

    .local v3, "what\\2":Ljava/lang/String;
    move-object v4, p0

    .local v4, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 609
    .local v5, "$i$f$ud\\2\\112":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_75

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_76

    :cond_75
    move-object v6, v2

    :goto_76
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v7, :cond_7b

    move-object v2, v6

    :cond_7b
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v2, :cond_8c

    .line 112
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\2\\112":I
    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_e9

    .line 609
    .restart local v3    # "what\\2":Ljava/lang/String;
    .restart local v4    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\2\\112":I
    :cond_8c
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 113
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\2\\112":I
    :cond_ad
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v3, "Vector3"

    .local v3, "what\\3":Ljava/lang/String;
    move-object v4, p0

    .local v4, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 610
    .local v5, "$i$f$ud\\3\\113":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_be

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_bf

    :cond_be
    move-object v6, v2

    :goto_bf
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v7, :cond_c4

    move-object v6, v2

    :cond_c4
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_10b

    .line 113
    .end local v3    # "what\\3":Ljava/lang/String;
    .end local v4    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\3\\113":I
    const-string v3, "Vector3"

    .local v3, "what\\4":Ljava/lang/String;
    move-object v4, p1

    .local v4, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 610
    .local v5, "$i$f$ud\\4\\113":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_d7

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_d8

    :cond_d7
    move-object v7, v2

    :goto_d8
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_dd

    move-object v2, v7

    :cond_dd
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v2, :cond_ea

    .line 113
    .end local v3    # "what\\4":Ljava/lang/String;
    .end local v4    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\4\\113":I
    invoke-virtual {v6, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .line 114
    :goto_e9
    return-object v0

    .line 610
    .restart local v3    # "what\\4":Ljava/lang/String;
    .restart local v4    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\4\\113":I
    :cond_ea
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v3, "what\\3":Ljava/lang/String;
    .local v4, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v5, "$i$f$ud\\3\\113":I
    :cond_10b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$23$lambda$21(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 117
    nop

    .line 118
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v0

    const-string v1, " expected, got "

    const/4 v2, 0x0

    if-eqz v0, :cond_5e

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v3, "Vector3"

    .local v3, "what\\1":Ljava/lang/String;
    move-object v4, p0

    .local v4, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 611
    .local v5, "$i$f$ud\\1\\118":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_25

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_26

    :cond_25
    move-object v6, v2

    :goto_26
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v7, :cond_2b

    move-object v2, v6

    :cond_2b
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v2, :cond_3d

    .line 118
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\1\\118":I
    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto/16 :goto_102

    .line 611
    .restart local v3    # "what\\1":Ljava/lang/String;
    .restart local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\1\\118":I
    :cond_3d
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 119
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\1\\118":I
    :cond_5e
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v0

    if-eqz v0, :cond_c6

    const-string v0, "Vector3"

    .local v0, "what\\2":Ljava/lang/String;
    move-object v3, p1

    .local v3, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v4, 0x0

    .line 612
    .local v4, "$i$f$ud\\2\\119":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    if-eqz v5, :cond_73

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_74

    :cond_73
    move-object v5, v2

    :goto_74
    instance-of v6, v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_79

    move-object v2, v5

    :cond_79
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v2, :cond_a5

    .line 119
    .end local v0    # "what\\2":Ljava/lang/String;
    .end local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "$i$f$ud\\2\\119":I
    nop

    .local v2, "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v3

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    div-float/2addr v3, v4

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v4

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    div-float/2addr v4, v5

    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v5

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v6

    div-float/2addr v5, v6

    invoke-direct {v1, v3, v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v2    # "v":Lcom/exampletest/mobilestudiotest/model/Vector3;
    goto :goto_102

    .line 612
    .restart local v0    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v4    # "$i$f$ud\\2\\119":I
    :cond_a5
    new-instance v2, Lorg/luaj/vm2/LuaError;

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v5, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v2

    .line 120
    .end local v0    # "what\\2":Ljava/lang/String;
    .end local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "$i$f$ud\\2\\119":I
    :cond_c6
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v3, "Vector3"

    .local v3, "what\\3":Ljava/lang/String;
    move-object v4, p0

    .local v4, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 613
    .local v5, "$i$f$ud\\3\\120":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_d7

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_d8

    :cond_d7
    move-object v6, v2

    :goto_d8
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-nez v7, :cond_dd

    move-object v6, v2

    :cond_dd
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_124

    .line 120
    .end local v3    # "what\\3":Ljava/lang/String;
    .end local v4    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\3\\120":I
    const-string v3, "Vector3"

    .local v3, "what\\4":Ljava/lang/String;
    move-object v4, p1

    .local v4, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 613
    .local v5, "$i$f$ud\\4\\120":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_f0

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_f1

    :cond_f0
    move-object v7, v2

    :goto_f1
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_f6

    move-object v2, v7

    :cond_f6
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v2, :cond_103

    .line 120
    .end local v3    # "what\\4":Ljava/lang/String;
    .end local v4    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\4\\120":I
    invoke-virtual {v6, v2}, Lcom/exampletest/mobilestudiotest/model/Vector3;->div(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .line 121
    :goto_102
    return-object v0

    .line 613
    .restart local v3    # "what\\4":Ljava/lang/String;
    .restart local v4    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\4\\120":I
    :cond_103
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v3, "what\\3":Ljava/lang/String;
    .local v4, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v5, "$i$f$ud\\3\\120":I
    :cond_124
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$23$lambda$22(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 123
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "Vector3"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 614
    .local v3, "$i$f$ud\\1\\123":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_17

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_18

    :cond_17
    move-object v4, v5

    :goto_18
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_1d

    move-object v5, v4

    :cond_1d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_2a

    .line 123
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\123":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 614
    .restart local v1    # "what\\1":Ljava/lang/String;
    .restart local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\1\\123":I
    :cond_2a
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$26$lambda$24(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "Vector2"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 615
    .local v4, "$i$f$ud\\1\\132":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const-string v7, " expected, got "

    if-eqz v5, :cond_78

    .line 132
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\132":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector2"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 615
    .local v3, "$i$f$ud\\2\\132":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_43

    :cond_42
    move-object v4, v6

    :goto_43
    instance-of v8, v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v8, :cond_48

    move-object v6, v4

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v6, :cond_57

    .line 132
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\132":I
    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/Vector2;->dot(Lcom/exampletest/mobilestudiotest/model/Vector2;)F

    move-result v1

    invoke-direct {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 615
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\2\\132":I
    :cond_57
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v2    # "what\\2":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\1\\132":I
    :cond_78
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$26$lambda$25(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "Vector2"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 616
    .local v4, "$i$f$ud\\1\\133":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const-string v7, " expected, got "

    if-eqz v5, :cond_84

    .line 133
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\133":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "Vector2"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\2":Ljava/lang/String;
    const/4 v4, 0x0

    .line 616
    .local v4, "$i$f$ud\\2\\133":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_43

    :cond_42
    move-object v8, v6

    :goto_43
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v9, :cond_48

    move-object v6, v8

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v6, :cond_63

    .line 133
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\2\\133":I
    const/4 v1, 0x3

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v5, v6, v1}, Lcom/exampletest/mobilestudiotest/model/Vector2;->lerp(Lcom/exampletest/mobilestudiotest/model/Vector2;F)Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 616
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "what\\2":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\2\\133":I
    :cond_63
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .local v4, "$i$f$ud\\1\\133":I
    :cond_84
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$32$lambda$27(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "Vector2"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 617
    .local v3, "$i$f$ud\\1\\137":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1c

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1d

    :cond_1c
    move-object v4, v5

    :goto_1d
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-nez v6, :cond_22

    move-object v4, v5

    :cond_22
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const-string v6, " expected, got "

    if-eqz v4, :cond_6b

    .line 137
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\137":I
    const-string v1, "Vector2"

    .local v1, "what\\2":Ljava/lang/String;
    move-object v2, p1

    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 617
    .local v3, "$i$f$ud\\2\\137":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_37

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_38

    :cond_37
    move-object v7, v5

    :goto_38
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v8, :cond_3d

    move-object v5, v7

    :cond_3d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v5, :cond_4a

    .line 137
    .end local v1    # "what\\2":Ljava/lang/String;
    .end local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\2\\137":I
    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector2;->plus(Lcom/exampletest/mobilestudiotest/model/Vector2;)Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 617
    .restart local v1    # "what\\2":Ljava/lang/String;
    .restart local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\2\\137":I
    :cond_4a
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "what\\1":Ljava/lang/String;
    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "$i$f$ud\\1\\137":I
    :cond_6b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$32$lambda$28(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "Vector2"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 618
    .local v3, "$i$f$ud\\1\\138":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1c

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1d

    :cond_1c
    move-object v4, v5

    :goto_1d
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-nez v6, :cond_22

    move-object v4, v5

    :cond_22
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    const-string v6, " expected, got "

    if-eqz v4, :cond_6b

    .line 138
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\138":I
    const-string v1, "Vector2"

    .local v1, "what\\2":Ljava/lang/String;
    move-object v2, p1

    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 618
    .local v3, "$i$f$ud\\2\\138":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_37

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_38

    :cond_37
    move-object v7, v5

    :goto_38
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v8, :cond_3d

    move-object v5, v7

    :cond_3d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v5, :cond_4a

    .line 138
    .end local v1    # "what\\2":Ljava/lang/String;
    .end local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\2\\138":I
    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/Vector2;->minus(Lcom/exampletest/mobilestudiotest/model/Vector2;)Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 618
    .restart local v1    # "what\\2":Ljava/lang/String;
    .restart local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\2\\138":I
    :cond_4a
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "what\\1":Ljava/lang/String;
    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "$i$f$ud\\1\\138":I
    :cond_6b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$32$lambda$29(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    nop

    .line 141
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v0

    const-string v1, " expected, got "

    const/4 v2, 0x0

    if-eqz v0, :cond_5e

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v3, "Vector2"

    .local v3, "what\\1":Ljava/lang/String;
    move-object v4, p1

    .local v4, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 619
    .local v5, "$i$f$ud\\1\\141":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_25

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_26

    :cond_25
    move-object v6, v2

    :goto_26
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v7, :cond_2b

    move-object v2, v6

    :cond_2b
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v2, :cond_3d

    .line 141
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\1\\141":I
    invoke-static {p0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/model/Vector2;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto/16 :goto_e9

    .line 619
    .restart local v3    # "what\\1":Ljava/lang/String;
    .restart local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\1\\141":I
    :cond_3d
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 142
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\1\\141":I
    :cond_5e
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->isnumber()Z

    move-result v0

    if-eqz v0, :cond_ad

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v3, "Vector2"

    .local v3, "what\\2":Ljava/lang/String;
    move-object v4, p0

    .local v4, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 620
    .local v5, "$i$f$ud\\2\\142":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_75

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_76

    :cond_75
    move-object v6, v2

    :goto_76
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v7, :cond_7b

    move-object v2, v6

    :cond_7b
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v2, :cond_8c

    .line 142
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\2\\142":I
    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/model/Vector2;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    goto :goto_e9

    .line 620
    .restart local v3    # "what\\2":Ljava/lang/String;
    .restart local v4    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\2\\142":I
    :cond_8c
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 143
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\2\\142":I
    :cond_ad
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v3, "Vector2"

    .local v3, "what\\3":Ljava/lang/String;
    move-object v4, p0

    .local v4, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 621
    .local v5, "$i$f$ud\\3\\143":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_be

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_bf

    :cond_be
    move-object v6, v2

    :goto_bf
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-nez v7, :cond_c4

    move-object v6, v2

    :cond_c4
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v6, :cond_10b

    .line 143
    .end local v3    # "what\\3":Ljava/lang/String;
    .end local v4    # "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\3\\143":I
    const-string v3, "Vector2"

    .local v3, "what\\4":Ljava/lang/String;
    move-object v4, p1

    .local v4, "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    const/4 v5, 0x0

    .line 621
    .local v5, "$i$f$ud\\4\\143":I
    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_d7

    invoke-virtual {v4}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_d8

    :cond_d7
    move-object v7, v2

    :goto_d8
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v8, :cond_dd

    move-object v2, v7

    :cond_dd
    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v2, :cond_ea

    .line 143
    .end local v3    # "what\\4":Ljava/lang/String;
    .end local v4    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .end local v5    # "$i$f$ud\\4\\143":I
    invoke-virtual {v6, v2}, Lcom/exampletest/mobilestudiotest/model/Vector2;->times(Lcom/exampletest/mobilestudiotest/model/Vector2;)Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .line 144
    :goto_e9
    return-object v0

    .line 621
    .restart local v3    # "what\\4":Ljava/lang/String;
    .restart local v4    # "$this$ud\\4":Lorg/luaj/vm2/LuaValue;
    .restart local v5    # "$i$f$ud\\4\\143":I
    :cond_ea
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v3, "what\\3":Ljava/lang/String;
    .local v4, "$this$ud\\3":Lorg/luaj/vm2/LuaValue;
    .local v5, "$i$f$ud\\3\\143":I
    :cond_10b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$32$lambda$30(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 9
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "Vector2"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 622
    .local v3, "$i$f$ud\\1\\146":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1c

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1d

    :cond_1c
    move-object v4, v5

    :goto_1d
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v6, :cond_22

    move-object v5, v4

    :cond_22
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v5, :cond_33

    .line 146
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\146":I
    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v5, v1}, Lcom/exampletest/mobilestudiotest/model/Vector2;->div(F)Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 622
    .restart local v1    # "what\\1":Ljava/lang/String;
    .restart local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\1\\146":I
    :cond_33
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$32$lambda$31(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 147
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "Vector2"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 623
    .local v3, "$i$f$ud\\1\\147":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_17

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_18

    :cond_17
    move-object v4, v5

    :goto_18
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v6, :cond_1d

    move-object v5, v4

    :cond_1d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v5, :cond_2a

    .line 147
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\147":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector2;->unaryMinus()Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 623
    .restart local v1    # "what\\1":Ljava/lang/String;
    .restart local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\1\\147":I
    :cond_2a
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$33(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 160
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 624
    .local v3, "$i$f$ud\\1\\160":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_21

    :cond_20
    move-object v4, v5

    :goto_21
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_26

    move-object v5, v4

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_35

    .line 160
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\160":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->inverse()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 624
    .restart local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\1":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\1\\160":I
    :cond_35
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$34(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 161
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 625
    .local v4, "$i$f$ud\\1\\161":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v7, " expected, got "

    if-eqz v5, :cond_84

    .line 161
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\161":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CFrame"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\2":Ljava/lang/String;
    const/4 v4, 0x0

    .line 625
    .local v4, "$i$f$ud\\2\\161":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_43

    :cond_42
    move-object v8, v6

    :goto_43
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v9, :cond_48

    move-object v6, v8

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_63

    .line 161
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\2\\161":I
    const/4 v1, 0x3

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v5, v6, v1}, Lcom/exampletest/mobilestudiotest/model/CFrame;->lerp(Lcom/exampletest/mobilestudiotest/model/CFrame;F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 625
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "what\\2":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\2\\161":I
    :cond_63
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .local v4, "$i$f$ud\\1\\161":I
    :cond_84
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$35(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 162
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 626
    .local v4, "$i$f$ud\\1\\162":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v7, " expected, got "

    if-eqz v5, :cond_78

    .line 162
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\162":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 626
    .local v3, "$i$f$ud\\2\\162":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_43

    :cond_42
    move-object v4, v6

    :goto_43
    instance-of v8, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v8, :cond_48

    move-object v6, v4

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_57

    .line 162
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\162":I
    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 626
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\2\\162":I
    :cond_57
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v2    # "what\\2":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\1\\162":I
    :cond_78
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$36(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 627
    .local v4, "$i$f$ud\\1\\163":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v7, " expected, got "

    if-eqz v5, :cond_7c

    .line 163
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\163":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->inverse()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    const/4 v3, 0x2

    invoke-virtual {p0, v3}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v2, "what\\2":Ljava/lang/String;
    .local v3, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v4, 0x0

    .line 627
    .local v4, "$i$f$ud\\2\\163":I
    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_47

    :cond_46
    move-object v5, v6

    :goto_47
    instance-of v8, v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v8, :cond_4c

    move-object v6, v5

    :cond_4c
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_5b

    .line 163
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v4    # "$i$f$ud\\2\\163":I
    invoke-virtual {v1, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 627
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v4    # "$i$f$ud\\2\\163":I
    :cond_5b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v1

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v2    # "what\\2":Ljava/lang/String;
    .restart local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .local v4, "$i$f$ud\\1\\163":I
    :cond_7c
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$37(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 628
    .local v4, "$i$f$ud\\1\\164":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v7, " expected, got "

    if-eqz v5, :cond_78

    .line 164
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\164":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 628
    .local v3, "$i$f$ud\\2\\164":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_43

    :cond_42
    move-object v4, v6

    :goto_43
    instance-of v8, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_48

    move-object v6, v4

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_57

    .line 164
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\164":I
    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 628
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\2\\164":I
    :cond_57
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v2    # "what\\2":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\1\\164":I
    :cond_78
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$38(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 165
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 629
    .local v4, "$i$f$ud\\1\\165":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v7, " expected, got "

    if-eqz v5, :cond_78

    .line 165
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\165":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 629
    .local v3, "$i$f$ud\\2\\165":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_43

    :cond_42
    move-object v4, v6

    :goto_43
    instance-of v8, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_48

    move-object v6, v4

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_57

    .line 165
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\165":I
    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->pointToObject(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 629
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\2\\165":I
    :cond_57
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v2    # "what\\2":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\1\\165":I
    :cond_78
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$39(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 166
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 630
    .local v4, "$i$f$ud\\1\\166":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v7, " expected, got "

    if-eqz v5, :cond_78

    .line 166
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\166":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 630
    .local v3, "$i$f$ud\\2\\166":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_43

    :cond_42
    move-object v4, v6

    :goto_43
    instance-of v8, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_48

    move-object v6, v4

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_57

    .line 166
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\166":I
    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->vectorToWorld(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 630
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\2\\166":I
    :cond_57
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v2    # "what\\2":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\1\\166":I
    :cond_78
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$40(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 167
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 631
    .local v4, "$i$f$ud\\1\\167":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v7, " expected, got "

    if-eqz v5, :cond_78

    .line 167
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\167":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Vector3"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\2":Ljava/lang/String;
    const/4 v3, 0x0

    .line 631
    .local v3, "$i$f$ud\\2\\167":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    if-eqz v4, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_43

    :cond_42
    move-object v4, v6

    :goto_43
    instance-of v8, v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_48

    move-object v6, v4

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v6, :cond_57

    .line 167
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\2":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\2\\167":I
    invoke-virtual {v5, v6}, Lcom/exampletest/mobilestudiotest/model/CFrame;->vectorToObject(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 631
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\2":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\2\\167":I
    :cond_57
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .end local v2    # "what\\2":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\1\\167":I
    :cond_78
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$41(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 168
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 632
    .local v3, "$i$f$ud\\1\\168":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1e

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1f

    :cond_1e
    move-object v4, v5

    :goto_1f
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_24

    move-object v5, v4

    :cond_24
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_5f

    .line 168
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\168":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toEulerXYZ()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .local v1, "e":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v2, 0x3

    new-array v2, v2, [Lorg/luaj/vm2/LuaValue;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    invoke-direct {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    invoke-direct {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    aput-object v3, v2, v0

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const/4 v3, 0x2

    aput-object v0, v2, v3

    invoke-static {v2}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    const-string v2, "varargsOf(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    .line 632
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\1":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\1\\168":I
    :cond_5f
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$42(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 169
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 633
    .local v3, "$i$f$ud\\1\\169":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1e

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1f

    :cond_1e
    move-object v4, v5

    :goto_1f
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_24

    move-object v5, v4

    :cond_24
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_5f

    .line 169
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\169":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toOrientation()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v1

    .local v1, "e":Lcom/exampletest/mobilestudiotest/model/Vector3;
    const/4 v2, 0x3

    new-array v2, v2, [Lorg/luaj/vm2/LuaValue;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    invoke-direct {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v4

    invoke-direct {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    aput-object v3, v2, v0

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v3

    invoke-direct {v0, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const/4 v3, 0x2

    aput-object v0, v2, v3

    invoke-static {v2}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    const-string v2, "varargsOf(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    .line 633
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\1":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\1\\169":I
    :cond_5f
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$44(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 13
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "CFrame"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v1, "what\\1":Ljava/lang/String;
    const/4 v2, 0x0

    .line 634
    .local v2, "$i$f$ud\\1\\170":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1e

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1f

    :cond_1e
    move-object v3, v4

    :goto_1f
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_24

    move-object v4, v3

    :cond_24
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v4, :cond_68

    .line 170
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$i$f$ud\\1\\170":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/CFrame;->components()[F

    move-result-object v0

    .local v0, "$this$map\\2":[F
    const/4 v1, 0x0

    .line 635
    .local v1, "$i$f$map\\2\\170":I
    new-instance v2, Ljava/util/ArrayList;

    array-length v3, v0

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\3":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapTo\\3":[F
    const/4 v4, 0x0

    .line 636
    .local v4, "$i$f$mapTo\\3\\635":I
    array-length v5, v3

    const/4 v6, 0x0

    move v7, v6

    :goto_3a
    if-ge v7, v5, :cond_4c

    aget v8, v3, v7

    .line 637
    .local v8, "item\\3":F
    move v9, v8

    .local v9, "it\\4":F
    const/4 v10, 0x0

    .line 170
    .local v10, "$i$a$-map-LuaTypes$5$11$1\\4\\637\\0":I
    sget-object v11, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-direct {v11, v9}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v9

    .line 637
    .end local v9    # "it\\4":F
    .end local v10    # "$i$a$-map-LuaTypes$5$11$1\\4\\637\\0":I
    invoke-interface {v2, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 636
    .end local v8    # "item\\3":F
    add-int/lit8 v7, v7, 0x1

    goto :goto_3a

    .line 638
    :cond_4c
    nop

    .end local v2    # "destination\\3":Ljava/util/Collection;
    .end local v3    # "$this$mapTo\\3":[F
    .end local v4    # "$i$f$mapTo\\3\\635":I
    check-cast v2, Ljava/util/List;

    .line 635
    nop

    .end local v0    # "$this$map\\2":[F
    .end local v1    # "$i$f$map\\2\\170":I
    check-cast v2, Ljava/util/Collection;

    .line 170
    nop

    .local v2, "$this$toTypedArray\\5":Ljava/util/Collection;
    const/4 v0, 0x0

    .line 639
    .local v0, "$i$f$toTypedArray\\5\\170":I
    nop

    .line 640
    move-object v1, v2

    .line 642
    .local v1, "this_\\5":Ljava/util/Collection;
    new-array v3, v6, [Lorg/luaj/vm2/LuaValue;

    invoke-interface {v1, v3}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$i$f$toTypedArray\\5\\170":I
    .end local v1    # "this_\\5":Ljava/util/Collection;
    .end local v2    # "$this$toTypedArray\\5":Ljava/util/Collection;
    check-cast v0, [Lorg/luaj/vm2/LuaValue;

    .line 170
    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    const-string v1, "varargsOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    .line 634
    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v1, "what\\1":Ljava/lang/String;
    .local v2, "$i$f$ud\\1\\170":I
    :cond_68
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$47$lambda$45(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 171
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 643
    .local v3, "$i$f$ud\\1\\171":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_21

    :cond_20
    move-object v4, v5

    :goto_21
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_26

    move-object v5, v4

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_35

    .line 171
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\171":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->orthonormalize()Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 643
    .restart local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\1":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\1\\171":I
    :cond_35
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$47$lambda$46(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 173
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CFrame"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 644
    .local v3, "$i$f$ud\\1\\173":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1e

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1f

    :cond_1e
    move-object v4, v5

    :goto_1f
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v6, :cond_24

    move-object v5, v4

    :cond_24
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_88

    .line 173
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\173":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->toQuaternion()[F

    move-result-object v1

    .line 174
    .local v1, "q":[F
    const/4 v2, 0x3

    aget v3, v1, v2

    const/high16 v4, -0x40800000    # -1.0f

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v3, v4, v5}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v3

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->acos(D)D

    move-result-wide v3

    double-to-float v3, v3

    const/high16 v4, 0x40000000    # 2.0f

    mul-float/2addr v3, v4

    .line 175
    .local v3, "ang":F
    aget v4, v1, v2

    aget v2, v1, v2

    mul-float/2addr v4, v2

    sub-float/2addr v5, v4

    const/4 v2, 0x0

    invoke-static {v5, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v2

    float-to-double v4, v2

    invoke-static {v4, v5}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v4

    double-to-float v2, v4

    .line 176
    .local v2, "s":F
    const v4, 0x3727c5ac    # 1.0E-5f

    cmpg-float v4, v2, v4

    if-gez v4, :cond_5f

    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Vector3;->Companion:Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3$Companion;->getX()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    goto :goto_70

    :cond_5f
    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    const/4 v5, 0x0

    aget v5, v1, v5

    div-float/2addr v5, v2

    aget v0, v1, v0

    div-float/2addr v0, v2

    const/4 v6, 0x2

    aget v6, v1, v6

    div-float/2addr v6, v2

    invoke-direct {v4, v5, v0, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    move-object v0, v4

    .line 177
    .local v0, "axis":Lcom/exampletest/mobilestudiotest/model/Vector3;
    :goto_70
    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v4

    sget-object v5, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-direct {v5, v3}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v5

    check-cast v5, Lorg/luaj/vm2/Varargs;

    invoke-static {v4, v5}, Lorg/luaj/vm2/LuaValue;->varargsOf(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object v4

    const-string v5, "varargsOf(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v4

    .line 644
    .end local v0    # "axis":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    .local v3, "$i$f$ud\\1\\173":I
    :cond_88
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$51$lambda$48(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 9
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 183
    const-string v0, "CFrame"

    .local v0, "what\\1":Ljava/lang/String;
    move-object v1, p0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 645
    .local v2, "$i$f$ud\\1\\183":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1a

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1b

    :cond_1a
    move-object v3, v4

    :goto_1b
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v5, :cond_20

    move-object v4, v3

    :cond_20
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v4, :cond_56

    .line 183
    .end local v0    # "what\\1":Ljava/lang/String;
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\1\\183":I
    nop

    .line 184
    .local v4, "c":Lcom/exampletest/mobilestudiotest/model/CFrame;
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    .line 185
    .local v0, "o":Ljava/lang/Object;
    nop

    .line 186
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v1, :cond_3c

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    move-object v2, v0

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/CFrame;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_4d

    .line 187
    :cond_3c
    instance-of v1, v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v1, :cond_4e

    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    move-object v2, v0

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/model/CFrame;->times(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    .line 189
    :goto_4d
    return-object v1

    .line 188
    :cond_4e
    new-instance v1, Lorg/luaj/vm2/LuaError;

    const-string v2, "invalid argument to CFrame multiplication"

    invoke-direct {v1, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 645
    .end local v4    # "c":Lcom/exampletest/mobilestudiotest/model/CFrame;
    .local v0, "what\\1":Ljava/lang/String;
    .restart local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "$i$f$ud\\1\\183":I
    :cond_56
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$51$lambda$49(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 191
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "CFrame"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 646
    .local v3, "$i$f$ud\\1\\191":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1c

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1d

    :cond_1c
    move-object v4, v5

    :goto_1d
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v6, :cond_22

    move-object v4, v5

    :cond_22
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v6, " expected, got "

    if-eqz v4, :cond_6b

    .line 191
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\191":I
    const-string v1, "Vector3"

    .local v1, "what\\2":Ljava/lang/String;
    move-object v2, p1

    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 646
    .local v3, "$i$f$ud\\2\\191":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_37

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_38

    :cond_37
    move-object v7, v5

    :goto_38
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_3d

    move-object v5, v7

    :cond_3d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_4a

    .line 191
    .end local v1    # "what\\2":Ljava/lang/String;
    .end local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\2\\191":I
    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 646
    .restart local v1    # "what\\2":Ljava/lang/String;
    .restart local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\2\\191":I
    :cond_4a
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "what\\1":Ljava/lang/String;
    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "$i$f$ud\\1\\191":I
    :cond_6b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$51$lambda$50(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 192
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const-string v1, "CFrame"

    .local v1, "what\\1":Ljava/lang/String;
    move-object v2, p0

    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 647
    .local v3, "$i$f$ud\\1\\192":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1c

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1d

    :cond_1c
    move-object v4, v5

    :goto_1d
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-nez v6, :cond_22

    move-object v4, v5

    :cond_22
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/CFrame;

    const-string v6, " expected, got "

    if-eqz v4, :cond_6b

    .line 192
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\1\\192":I
    const-string v1, "Vector3"

    .local v1, "what\\2":Ljava/lang/String;
    move-object v2, p1

    .local v2, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v3, 0x0

    .line 647
    .local v3, "$i$f$ud\\2\\192":I
    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v7

    if-eqz v7, :cond_37

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v7

    goto :goto_38

    :cond_37
    move-object v7, v5

    :goto_38
    instance-of v8, v7, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v8, :cond_3d

    move-object v5, v7

    :cond_3d
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_4a

    .line 192
    .end local v1    # "what\\2":Ljava/lang/String;
    .end local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "$i$f$ud\\2\\192":I
    invoke-virtual {v4, v5}, Lcom/exampletest/mobilestudiotest/model/CFrame;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 647
    .restart local v1    # "what\\2":Ljava/lang/String;
    .restart local v2    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "$i$f$ud\\2\\192":I
    :cond_4a
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "what\\1":Ljava/lang/String;
    .local v2, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "$i$f$ud\\1\\192":I
    :cond_6b
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$55$lambda$52(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 199
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "Color3"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 648
    .local v4, "$i$f$ud\\1\\199":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    const-string v7, " expected, got "

    if-eqz v5, :cond_84

    .line 199
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\199":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "Color3"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\2":Ljava/lang/String;
    const/4 v4, 0x0

    .line 648
    .local v4, "$i$f$ud\\2\\199":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_43

    :cond_42
    move-object v8, v6

    :goto_43
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v9, :cond_48

    move-object v6, v8

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v6, :cond_63

    .line 199
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\2\\199":I
    const/4 v1, 0x3

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v5, v6, v1}, Lcom/exampletest/mobilestudiotest/model/Color3;->lerp(Lcom/exampletest/mobilestudiotest/model/Color3;F)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 648
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "what\\2":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\2\\199":I
    :cond_63
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .local v4, "$i$f$ud\\1\\199":I
    :cond_84
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$55$lambda$53(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 200
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "Color3"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "what\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 649
    .local v3, "$i$f$ud\\1\\200":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_1e

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v4

    goto :goto_1f

    :cond_1e
    move-object v4, v5

    :goto_1f
    instance-of v6, v4, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v6, :cond_24

    move-object v5, v4

    :cond_24
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v5, :cond_59

    .line 200
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "what\\1":Ljava/lang/String;
    .end local v3    # "$i$f$ud\\1\\200":I
    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Color3;->toHSV()[F

    move-result-object v1

    .local v1, "h":[F
    const/4 v2, 0x3

    new-array v2, v2, [Lorg/luaj/vm2/LuaValue;

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v4, 0x0

    aget v5, v1, v4

    invoke-direct {v3, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    aput-object v3, v2, v4

    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    aget v4, v1, v0

    invoke-direct {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    aput-object v3, v2, v0

    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v3, 0x2

    aget v4, v1, v3

    invoke-direct {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->n(F)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    aput-object v0, v2, v3

    invoke-static {v2}, Lorg/luaj/vm2/LuaValue;->varargsOf([Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/Varargs;

    move-result-object v0

    const-string v2, "varargsOf(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    .line 649
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "what\\1":Ljava/lang/String;
    .restart local v3    # "$i$f$ud\\1\\200":I
    :cond_59
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$55$lambda$54(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 201
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "Color3"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v1, "what\\1":Ljava/lang/String;
    const/4 v2, 0x0

    .line 650
    .local v2, "$i$f$ud\\1\\201":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1e

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1f

    :cond_1e
    move-object v3, v4

    :goto_1f
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v5, :cond_24

    move-object v4, v3

    :cond_24
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v4, :cond_43

    .line 201
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$i$f$ud\\1\\201":I
    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Color3;->toHex()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "toLowerCase(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 650
    .restart local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v1    # "what\\1":Ljava/lang/String;
    .restart local v2    # "$i$f$ud\\1\\201":I
    :cond_43
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$60$lambda$58(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 221
    const-string v0, "UDim"

    .local v0, "what\\1":Ljava/lang/String;
    move-object v1, p0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 651
    .local v2, "$i$f$ud\\1\\221":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1a

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1b

    :cond_1a
    move-object v3, v4

    :goto_1b
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-nez v5, :cond_20

    move-object v3, v4

    :cond_20
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/UDim;

    const-string v5, " expected, got "

    if-eqz v3, :cond_80

    .line 221
    .end local v0    # "what\\1":Ljava/lang/String;
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\1\\221":I
    nop

    .local v3, "x":Lcom/exampletest/mobilestudiotest/model/UDim;
    const-string v0, "UDim"

    .local v0, "what\\2":Ljava/lang/String;
    move-object v1, p1

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 651
    .local v2, "$i$f$ud\\2\\221":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_36

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_37

    :cond_36
    move-object v6, v4

    :goto_37
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v7, :cond_3c

    move-object v4, v6

    :cond_3c
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v4, :cond_5f

    .line 221
    .end local v0    # "what\\2":Ljava/lang/String;
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\2\\221":I
    nop

    .local v4, "y":Lcom/exampletest/mobilestudiotest/model/UDim;
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v5

    add-float/2addr v2, v5

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v5

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v6

    add-int/2addr v5, v6

    invoke-direct {v1, v2, v5}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 651
    .end local v4    # "y":Lcom/exampletest/mobilestudiotest/model/UDim;
    .restart local v0    # "what\\2":Ljava/lang/String;
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "$i$f$ud\\2\\221":I
    :cond_5f
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .end local v3    # "x":Lcom/exampletest/mobilestudiotest/model/UDim;
    .local v0, "what\\1":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "$i$f$ud\\1\\221":I
    :cond_80
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$60$lambda$59(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 10
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 222
    const-string v0, "UDim"

    .local v0, "what\\1":Ljava/lang/String;
    move-object v1, p0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 652
    .local v2, "$i$f$ud\\1\\222":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1a

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1b

    :cond_1a
    move-object v3, v4

    :goto_1b
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-nez v5, :cond_20

    move-object v3, v4

    :cond_20
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/UDim;

    const-string v5, " expected, got "

    if-eqz v3, :cond_80

    .line 222
    .end local v0    # "what\\1":Ljava/lang/String;
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\1\\222":I
    nop

    .local v3, "x":Lcom/exampletest/mobilestudiotest/model/UDim;
    const-string v0, "UDim"

    .local v0, "what\\2":Ljava/lang/String;
    move-object v1, p1

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 652
    .local v2, "$i$f$ud\\2\\222":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_36

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_37

    :cond_36
    move-object v6, v4

    :goto_37
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v7, :cond_3c

    move-object v4, v6

    :cond_3c
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v4, :cond_5f

    .line 222
    .end local v0    # "what\\2":Ljava/lang/String;
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\2\\222":I
    nop

    .local v4, "y":Lcom/exampletest/mobilestudiotest/model/UDim;
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v5

    sub-float/2addr v2, v5

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v5

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v6

    sub-int/2addr v5, v6

    invoke-direct {v1, v2, v5}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 652
    .end local v4    # "y":Lcom/exampletest/mobilestudiotest/model/UDim;
    .restart local v0    # "what\\2":Ljava/lang/String;
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "$i$f$ud\\2\\222":I
    :cond_5f
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .end local v3    # "x":Lcom/exampletest/mobilestudiotest/model/UDim;
    .local v0, "what\\1":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "$i$f$ud\\1\\222":I
    :cond_80
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$62$lambda$61(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 230
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    const-string v2, "arg(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "UDim2"

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 653
    .local v4, "$i$f$ud\\1\\230":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_20

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v5

    goto :goto_21

    :cond_20
    move-object v5, v6

    :goto_21
    instance-of v7, v5, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-nez v7, :cond_26

    move-object v5, v6

    :cond_26
    check-cast v5, Lcom/exampletest/mobilestudiotest/model/UDim2;

    const-string v7, " expected, got "

    if-eqz v5, :cond_84

    .line 230
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\1":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\1\\230":I
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "UDim2"

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\2":Ljava/lang/String;
    const/4 v4, 0x0

    .line 653
    .local v4, "$i$f$ud\\2\\230":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v8

    if-eqz v8, :cond_42

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v8

    goto :goto_43

    :cond_42
    move-object v8, v6

    :goto_43
    instance-of v9, v8, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v9, :cond_48

    move-object v6, v8

    :cond_48
    check-cast v6, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v6, :cond_63

    .line 230
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v3    # "what\\2":Ljava/lang/String;
    .end local v4    # "$i$f$ud\\2\\230":I
    const/4 v1, 0x3

    invoke-virtual {p0, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v1

    invoke-virtual {v5, v6, v1}, Lcom/exampletest/mobilestudiotest/model/UDim2;->lerp(Lcom/exampletest/mobilestudiotest/model/UDim2;F)Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0

    .line 653
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v3    # "what\\2":Ljava/lang/String;
    .restart local v4    # "$i$f$ud\\2\\230":I
    :cond_63
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v3, "what\\1":Ljava/lang/String;
    .local v4, "$i$f$ud\\1\\230":I
    :cond_84
    new-instance v0, Lorg/luaj/vm2/LuaError;

    sget-object v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v2, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static final lambda$66$lambda$63(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    const-string v0, "UDim2"

    .local v0, "what\\1":Ljava/lang/String;
    move-object v1, p0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 654
    .local v2, "$i$f$ud\\1\\234":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1a

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1b

    :cond_1a
    move-object v3, v4

    :goto_1b
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-nez v5, :cond_20

    move-object v3, v4

    :cond_20
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/UDim2;

    const-string v5, " expected, got "

    if-eqz v3, :cond_92

    .line 234
    .end local v0    # "what\\1":Ljava/lang/String;
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\1\\234":I
    nop

    .local v3, "x":Lcom/exampletest/mobilestudiotest/model/UDim2;
    const-string v0, "UDim2"

    .local v0, "what\\2":Ljava/lang/String;
    move-object v1, p1

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 654
    .local v2, "$i$f$ud\\2\\234":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_36

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_37

    :cond_36
    move-object v6, v4

    :goto_37
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v7, :cond_3c

    move-object v4, v6

    :cond_3c
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v4, :cond_71

    .line 234
    .end local v0    # "what\\2":Ljava/lang/String;
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\2\\234":I
    nop

    .local v4, "y":Lcom/exampletest/mobilestudiotest/model/UDim2;
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v5

    add-float/2addr v2, v5

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v5

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v6

    add-int/2addr v5, v6

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v6

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v7

    add-float/2addr v6, v7

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v7

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v8

    add-int/2addr v7, v8

    invoke-direct {v1, v2, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 654
    .end local v4    # "y":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .restart local v0    # "what\\2":Ljava/lang/String;
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "$i$f$ud\\2\\234":I
    :cond_71
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .end local v3    # "x":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .local v0, "what\\1":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "$i$f$ud\\1\\234":I
    :cond_92
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$66$lambda$64(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 11
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;
    .param p1, "b"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 235
    const-string v0, "UDim2"

    .local v0, "what\\1":Ljava/lang/String;
    move-object v1, p0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 655
    .local v2, "$i$f$ud\\1\\235":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1a

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1b

    :cond_1a
    move-object v3, v4

    :goto_1b
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-nez v5, :cond_20

    move-object v3, v4

    :cond_20
    check-cast v3, Lcom/exampletest/mobilestudiotest/model/UDim2;

    const-string v5, " expected, got "

    if-eqz v3, :cond_92

    .line 235
    .end local v0    # "what\\1":Ljava/lang/String;
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\1\\235":I
    nop

    .local v3, "x":Lcom/exampletest/mobilestudiotest/model/UDim2;
    const-string v0, "UDim2"

    .local v0, "what\\2":Ljava/lang/String;
    move-object v1, p1

    .local v1, "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 655
    .local v2, "$i$f$ud\\2\\235":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v6

    if-eqz v6, :cond_36

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v6

    goto :goto_37

    :cond_36
    move-object v6, v4

    :goto_37
    instance-of v7, v6, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v7, :cond_3c

    move-object v4, v6

    :cond_3c
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v4, :cond_71

    .line 235
    .end local v0    # "what\\2":Ljava/lang/String;
    .end local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\2\\235":I
    nop

    .local v4, "y":Lcom/exampletest/mobilestudiotest/model/UDim2;
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v5

    sub-float/2addr v2, v5

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v5

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v6

    sub-int/2addr v5, v6

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v6

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v7

    sub-float/2addr v6, v7

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v7

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v8

    sub-int/2addr v7, v8

    invoke-direct {v1, v2, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 655
    .end local v4    # "y":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .restart local v0    # "what\\2":Ljava/lang/String;
    .restart local v1    # "$this$ud\\2":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "$i$f$ud\\2\\235":I
    :cond_71
    new-instance v4, Lorg/luaj/vm2/LuaError;

    sget-object v6, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v6, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v4

    .end local v3    # "x":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .local v0, "what\\1":Ljava/lang/String;
    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v2, "$i$f$ud\\1\\235":I
    :cond_92
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$66$lambda$65(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "a"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "a"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 236
    const-string v0, "UDim2"

    .local v0, "what\\1":Ljava/lang/String;
    move-object v1, p0

    .local v1, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    const/4 v2, 0x0

    .line 656
    .local v2, "$i$f$ud\\1\\236":I
    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_15

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_16

    :cond_15
    move-object v3, v4

    :goto_16
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v5, :cond_1b

    move-object v4, v3

    :cond_1b
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v4, :cond_40

    .line 236
    .end local v0    # "what\\1":Ljava/lang/String;
    .end local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v2    # "$i$f$ud\\1\\236":I
    nop

    .local v4, "x":Lcom/exampletest/mobilestudiotest/model/UDim2;
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXs()F

    move-result v2

    neg-float v2, v2

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getXo()I

    move-result v3

    neg-int v3, v3

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYs()F

    move-result v5

    neg-float v5, v5

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim2;->getYo()I

    move-result v6

    neg-int v6, v6

    invoke-direct {v1, v2, v3, v5, v6}, Lcom/exampletest/mobilestudiotest/model/UDim2;-><init>(FIFI)V

    invoke-virtual {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0

    .line 656
    .end local v4    # "x":Lcom/exampletest/mobilestudiotest/model/UDim2;
    .restart local v0    # "what\\1":Ljava/lang/String;
    .restart local v1    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v2    # "$i$f$ud\\1\\236":I
    :cond_40
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$68$lambda$67(Lcom/exampletest/mobilestudiotest/lua/EnumItemV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 4
    .param p0, "$e"    # Lcom/exampletest/mobilestudiotest/lua/EnumItemV;
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 245
    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getType()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Z)Lorg/luaj/vm2/LuaBoolean;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$70$lambda$69(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 6
    .param p0, "it"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 249
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.lua.EnumItemV"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    .local v0, "e":Lcom/exampletest/mobilestudiotest/lua/EnumItemV;
    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getType()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Enum."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "."

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v1

    const-string v2, "valueOf(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    return-object v1
.end method

.method static final lambda$76$lambda$72(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 12
    .param p0, "$t"    # Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    const-string v0, "<unused var>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 256
    new-instance p1, Lorg/luaj/vm2/LuaTable;

    invoke-direct {p1}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .line 257
    .local p1, "tbl":Lorg/luaj/vm2/LuaTable;
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Enums;->getTypes()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/LinkedHashMap;

    if-eqz v0, :cond_5a

    check-cast v0, Ljava/util/Map;

    .local v0, "$this$forEach\\1":Ljava/util/Map;
    const/4 v1, 0x0

    .line 657
    .local v1, "$i$f$forEach\\1\\257":I
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_27
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_59

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    .local v3, "element\\1":Ljava/util/Map$Entry;
    const/4 v4, 0x0

    .local v4, "$i$a$-forEach-LuaTypes$15$1$1\\2\\657\\0":I
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .local v5, "nm\\2":Ljava/lang/String;
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    .line 257
    .local v6, "v\\2":I
    sget-object v7, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v8, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9, v5, v6}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v7, v8}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v7

    const/4 v8, 0x0

    invoke-virtual {p1, v8, v7}, Lorg/luaj/vm2/LuaTable;->insert(ILorg/luaj/vm2/LuaValue;)V

    .line 657
    .end local v4    # "$i$a$-forEach-LuaTypes$15$1$1\\2\\657\\0":I
    .end local v5    # "nm\\2":Ljava/lang/String;
    .end local v6    # "v\\2":I
    nop

    .end local v3    # "element\\1":Ljava/util/Map$Entry;
    goto :goto_27

    .line 658
    :cond_59
    nop

    .line 258
    .end local v0    # "$this$forEach\\1":Ljava/util/Map;
    .end local v1    # "$i$f$forEach\\1\\257":I
    :cond_5a
    move-object v0, p1

    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$76$lambda$73(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 6
    .param p0, "$t"    # Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 260
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    invoke-virtual {p1, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    const-string v3, "tojstring(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->enumItem(Ljava/lang/String;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    if-nez v0, :cond_26

    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NIL"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :cond_26
    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$76$lambda$75(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 8
    .param p0, "$t"    # Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 261
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    invoke-virtual {p1, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v3

    invoke-virtual {v3}, Lorg/luaj/vm2/LuaValue;->toint()I

    move-result v3

    invoke-virtual {v0, v1, v3}, Lcom/exampletest/mobilestudiotest/model/Enums;->itemName(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_35

    .line 659
    .local v0, "it\\1":Ljava/lang/String;
    const/4 v1, 0x0

    .line 261
    .local v1, "$i$a$-let-LuaTypes$15$3$1\\1\\261\\0":I
    sget-object v3, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v4, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v2}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v2

    invoke-virtual {v2}, Lorg/luaj/vm2/LuaValue;->toint()I

    move-result v2

    invoke-direct {v4, v5, v0, v2}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v3, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .end local v0    # "it\\1":Ljava/lang/String;
    .end local v1    # "$i$a$-let-LuaTypes$15$3$1\\1\\261\\0":I
    if-eqz v0, :cond_35

    goto :goto_3c

    :cond_35
    sget-object v0, Lorg/luaj/vm2/LuaValue;->NIL:Lorg/luaj/vm2/LuaValue;

    const-string v1, "NIL"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_3c
    check-cast v0, Lorg/luaj/vm2/Varargs;

    return-object v0
.end method

.method static final lambda$78$lambda$77(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 3
    .param p0, "it"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 265
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type com.exampletest.mobilestudiotest.lua.EnumTypeV"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method static final lambda$82$lambda$81(Lcom/exampletest/mobilestudiotest/model/Ray;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 9
    .param p0, "$r"    # Lcom/exampletest/mobilestudiotest/model/Ray;
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 289
    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "Vector3"

    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .local v1, "what\\1":Ljava/lang/String;
    const/4 v2, 0x0

    .line 660
    .local v2, "$i$f$ud\\1\\289":I
    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1e

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v3

    goto :goto_1f

    :cond_1e
    move-object v3, v4

    :goto_1f
    instance-of v5, v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v5, :cond_24

    move-object v4, v3

    :cond_24
    check-cast v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v4, :cond_57

    .line 289
    .end local v0    # "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "what\\1":Ljava/lang/String;
    .end local v2    # "$i$f$ud\\1\\289":I
    nop

    .local v4, "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Ray;->getDirection()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    .line 290
    .local v0, "d":Lcom/exampletest/mobilestudiotest/model/Vector3;
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Ray;->getOrigin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/model/Ray;->getOrigin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v4, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->minus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v3, v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->dot(Lcom/exampletest/mobilestudiotest/model/Vector3;)F

    move-result v3

    const/4 v5, 0x0

    invoke-static {v3, v5}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v3

    invoke-virtual {v0, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->times(F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->plus(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    return-object v1

    .line 660
    .end local v4    # "p":Lcom/exampletest/mobilestudiotest/model/Vector3;
    .local v0, "$this$ud\\1":Lorg/luaj/vm2/LuaValue;
    .restart local v1    # "what\\1":Ljava/lang/String;
    .restart local v2    # "$i$f$ud\\1\\289":I
    :cond_57
    new-instance v3, Lorg/luaj/vm2/LuaError;

    sget-object v4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    invoke-virtual {v4, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " expected, got "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method static final lambda$84$lambda$83(Lcom/exampletest/mobilestudiotest/lua/Region3V;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "$r"    # Lcom/exampletest/mobilestudiotest/lua/Region3V;
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 301
    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->num(Lorg/luaj/vm2/LuaValue;)F

    move-result v0

    const v1, 0x3a83126f    # 0.001f

    invoke-static {v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v0

    .line 304
    .local v0, "res":F
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/Region3V;

    new-instance v3, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v4

    invoke-static {v0, v4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$84$lambda$83$lo(FF)F

    move-result v4

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v5

    invoke-static {v0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$84$lambda$83$lo(FF)F

    move-result v5

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMin()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v6

    invoke-static {v0, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$84$lambda$83$lo(FF)F

    move-result v6

    invoke-direct {v3, v4, v5, v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    new-instance v4, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getX()F

    move-result v5

    invoke-static {v0, v5}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$84$lambda$83$hi(FF)F

    move-result v5

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getY()F

    move-result v6

    invoke-static {v0, v6}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$84$lambda$83$hi(FF)F

    move-result v6

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/Region3V;->getMax()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v7

    invoke-virtual {v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getZ()F

    move-result v7

    invoke-static {v0, v7}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$84$lambda$83$hi(FF)F

    move-result v7

    invoke-direct {v4, v5, v6, v7}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-direct {v2, v3, v4}, Lcom/exampletest/mobilestudiotest/lua/Region3V;-><init>(Lcom/exampletest/mobilestudiotest/model/Vector3;Lcom/exampletest/mobilestudiotest/model/Vector3;)V

    invoke-virtual {v1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/Varargs;

    return-object v1
.end method

.method private static final lambda$84$lambda$83$hi(FF)F
    .registers 4
    .param p0, "res"    # F
    .param p1, "x"    # F

    .line 303
    div-float v0, p1, p0

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v0

    double-to-float v0, v0

    mul-float/2addr v0, p0

    return v0
.end method

.method private static final lambda$84$lambda$83$lo(FF)F
    .registers 4
    .param p0, "res"    # F
    .param p1, "x"    # F

    .line 302
    div-float v0, p1, p0

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->floor(D)D

    move-result-wide v0

    double-to-float v0, v0

    mul-float/2addr v0, p0

    return v0
.end method

.method static final lambda$89$lambda$86(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 10
    .param p0, "$r"    # Ljava/util/Random;
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 318
    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    const-string v1, "arg(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    invoke-static {v0, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v0

    float-to-double v2, v0

    .local v2, "mn":D
    const/4 v0, 0x3

    invoke-virtual {p1, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->optNum(Lorg/luaj/vm2/LuaValue;F)F

    move-result v0

    float-to-double v0, v0

    .line 319
    .local v0, "mx":D
    invoke-virtual {p0}, Ljava/util/Random;->nextDouble()D

    move-result-wide v4

    sub-double v6, v0, v2

    mul-double/2addr v4, v6

    add-double/2addr v4, v2

    invoke-static {v4, v5}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v4

    const-string v5, "valueOf(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Lorg/luaj/vm2/Varargs;

    return-object v4
.end method

.method static final lambda$89$lambda$87(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 6
    .param p0, "$r"    # Ljava/util/Random;
    .param p1, "a"    # Lorg/luaj/vm2/Varargs;

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 322
    const/4 v0, 0x2

    invoke-virtual {p1, v0}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    invoke-virtual {v0}, Lorg/luaj/vm2/LuaValue;->checkint()I

    move-result v0

    .local v0, "mn":I
    const/4 v1, 0x3

    invoke-virtual {p1, v1}, Lorg/luaj/vm2/Varargs;->arg(I)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->checkint()I

    move-result v1

    .line 323
    .local v1, "mx":I
    sub-int v2, v1, v0

    const/4 v3, 0x1

    add-int/2addr v2, v3

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {p0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    add-int/2addr v2, v0

    invoke-static {v2}, Lorg/luaj/vm2/LuaValue;->valueOf(I)Lorg/luaj/vm2/LuaInteger;

    move-result-object v2

    const-string v3, "valueOf(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Lorg/luaj/vm2/Varargs;

    return-object v2
.end method

.method static final lambda$89$lambda$88(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;
    .registers 7
    .param p0, "$r"    # Ljava/util/Random;

    const-string v0, "<unused var>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 325
    sget-object p1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->INSTANCE:Lcom/exampletest/mobilestudiotest/lua/LuaTypes;

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {p0}, Ljava/util/Random;->nextGaussian()D

    move-result-wide v1

    double-to-float v1, v1

    invoke-virtual {p0}, Ljava/util/Random;->nextGaussian()D

    move-result-wide v2

    double-to-float v2, v2

    invoke-virtual {p0}, Ljava/util/Random;->nextGaussian()D

    move-result-wide v3

    double-to-float v3, v3

    invoke-direct {v0, v1, v2, v3}, Lcom/exampletest/mobilestudiotest/model/Vector3;-><init>(FFF)V

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Vector3;->getUnit()Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    check-cast p1, Lorg/luaj/vm2/Varargs;

    return-object p1
.end method

.method private final meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V
    .registers 8
    .param p1, "cls"    # Ljava/lang/Class;
    .param p2, "typeName"    # Ljava/lang/String;
    .param p3, "index"    # Lkotlin/jvm/functions/Function2;
    .param p4, "extra"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function2<",
            "Ljava/lang/Object;",
            "-",
            "Ljava/lang/String;",
            "+",
            "Lorg/luaj/vm2/LuaValue;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/luaj/vm2/LuaTable;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 67
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .line 68
    .local v0, "mt":Lorg/luaj/vm2/LuaTable;
    const-string v1, "__type"

    invoke-virtual {v0, v1, p2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    sget-object v1, Lorg/luaj/vm2/LuaValue;->INDEX:Lorg/luaj/vm2/LuaString;

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda12;

    invoke-direct {v2, p3, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda12;-><init>(Lkotlin/jvm/functions/Function2;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v0, v1, v2}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 73
    sget-object v1, Lorg/luaj/vm2/LuaValue;->NEWINDEX:Lorg/luaj/vm2/LuaString;

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda13;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda13;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v0, v1, v2}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 74
    sget-object v1, Lorg/luaj/vm2/LuaValue;->TOSTRING:Lorg/luaj/vm2/LuaString;

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda14;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda14;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn1(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/OneArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v0, v1, v2}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 75
    invoke-interface {p4, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    sget-object v1, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->metas:Ljava/util/HashMap;

    check-cast v1, Ljava/util/Map;

    invoke-interface {v1, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    return-void
.end method

.method static synthetic meta$default(Lcom/exampletest/mobilestudiotest/lua/LuaTypes;Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)V
    .registers 7

    .line 66
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_9

    new-instance p4, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda109;

    invoke-direct {p4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda109;-><init>()V

    :cond_9
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta(Ljava/lang/Class;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    return-void
.end method

.method static final meta$lambda$2(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;
    .registers 2
    .param p0, "<this>"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method static final meta$lambda$3(Lkotlin/jvm/functions/Function2;Ljava/lang/String;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p0, "$index"    # Lkotlin/jvm/functions/Function2;
    .param p1, "$typeName"    # Ljava/lang/String;
    .param p2, "self"    # Lorg/luaj/vm2/LuaValue;
    .param p3, "key"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "self"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    invoke-virtual {p3}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v0

    .line 71
    .local v0, "k":Ljava/lang/String;
    invoke-virtual {p2}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v1

    const-string v2, "touserdata(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-interface {p0, v1, v0}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    if-eqz v1, :cond_23

    return-object v1

    :cond_23
    new-instance v1, Lorg/luaj/vm2/LuaError;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " is not a valid member of "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method static final meta$lambda$4(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 4
    .param p1, "key"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "<unused var>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "key"

    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    new-instance p0, Lorg/luaj/vm2/LuaError;

    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " cannot be assigned to"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/luaj/vm2/LuaError;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static final meta$lambda$5(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;
    .registers 3
    .param p0, "it"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    invoke-virtual {p0}, Lorg/luaj/vm2/LuaValue;->touserdata()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/luaj/vm2/LuaValue;->valueOf(Ljava/lang/String;)Lorg/luaj/vm2/LuaString;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method private final method(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/LuaValue;
    .registers 3
    .param p1, "f"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/luaj/vm2/Varargs;",
            "+",
            "Lorg/luaj/vm2/Varargs;",
            ">;)",
            "Lorg/luaj/vm2/LuaValue;"
        }
    .end annotation

    .line 79
    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method

.method private final n(F)Lorg/luaj/vm2/LuaValue;
    .registers 4
    .param p1, "v"    # F

    .line 80
    float-to-double v0, p1

    invoke-static {v0, v1}, Lorg/luaj/vm2/LuaValue;->valueOf(D)Lorg/luaj/vm2/LuaNumber;

    move-result-object v0

    const-string v1, "valueOf(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/luaj/vm2/LuaValue;

    return-object v0
.end method


# virtual methods
.method public final absf(F)F
    .registers 3
    .param p1, "x"    # F

    .line 602
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v0

    return v0
.end method

.method public final ease(IIF)F
    .registers 8
    .param p1, "style"    # I
    .param p2, "dir"    # I
    .param p3, "t0"    # F

    .line 555
    const/4 v0, 0x0

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {p3, v0, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    .line 570
    .local v0, "t":F
    packed-switch p2, :pswitch_data_32

    .line 573
    const/high16 v2, 0x3f000000    # 0.5f

    cmpg-float v2, v0, v2

    const/high16 v3, 0x40000000    # 2.0f

    if-gez v2, :cond_27

    mul-float v1, v0, v3

    invoke-static {p1, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->ease$easeIn(IF)F

    move-result v1

    div-float/2addr v1, v3

    goto :goto_30

    .line 572
    :pswitch_1a
    sub-float v2, v1, v0

    invoke-static {p1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->ease$easeIn(IF)F

    move-result v2

    sub-float/2addr v1, v2

    goto :goto_30

    .line 571
    :pswitch_22
    invoke-static {p1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->ease$easeIn(IF)F

    move-result v1

    goto :goto_30

    .line 573
    :cond_27
    sub-float v2, v1, v0

    mul-float/2addr v2, v3

    invoke-static {p1, v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->ease$easeIn(IF)F

    move-result v2

    div-float/2addr v2, v3

    sub-float/2addr v1, v2

    .line 570
    :goto_30
    return v1

    nop

    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_22
        :pswitch_1a
    .end packed-switch
.end method

.method public final enumItem(Ljava/lang/String;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;
    .registers 8
    .param p1, "type"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;

    const-string v0, "type"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 384
    sget-object v0, Lcom/exampletest/mobilestudiotest/model/Enums;->INSTANCE:Lcom/exampletest/mobilestudiotest/model/Enums;

    invoke-virtual {v0}, Lcom/exampletest/mobilestudiotest/model/Enums;->getTypes()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/LinkedHashMap;

    .line 385
    .local v0, "t":Ljava/util/LinkedHashMap;
    const/4 v1, 0x0

    if-eqz v0, :cond_20

    invoke-virtual {v0, p2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    goto :goto_21

    :cond_20
    move-object v2, v1

    .line 386
    .local v2, "v":Ljava/lang/Integer;
    :goto_21
    if-eqz v2, :cond_31

    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-direct {v1, p1, p2, v3}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    return-object v1

    .line 388
    :cond_31
    move-object v3, p2

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const/4 v4, 0x0

    if-nez v3, :cond_3d

    const/4 v3, 0x1

    goto :goto_3e

    :cond_3d
    move v3, v4

    :goto_3e
    if-nez v3, :cond_5f

    invoke-virtual {p2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->isLetter(C)Z

    move-result v3

    if-eqz v3, :cond_5f

    .line 389
    new-instance v1, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v3

    const v4, 0xffff

    and-int/2addr v3, v4

    const/high16 v4, 0x10000

    or-int/2addr v3, v4

    invoke-direct {v1, p1, p2, v3}, Lcom/exampletest/mobilestudiotest/lua/EnumItemV;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {p0, v1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    return-object v1

    .line 388
    :cond_5f
    return-object v1
.end method

.method public final enumLib()Lorg/luaj/vm2/LuaValue;
    .registers 5

    .line 393
    new-instance v0, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v0}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .line 394
    .local v0, "mt":Lorg/luaj/vm2/LuaTable;
    sget-object v1, Lorg/luaj/vm2/LuaValue;->INDEX:Lorg/luaj/vm2/LuaString;

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda107;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda107;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fn2(Lkotlin/jvm/functions/Function2;)Lorg/luaj/vm2/lib/TwoArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v0, v1, v2}, Lorg/luaj/vm2/LuaTable;->set(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)V

    .line 395
    new-instance v1, Lorg/luaj/vm2/LuaTable;

    invoke-direct {v1}, Lorg/luaj/vm2/LuaTable;-><init>()V

    .line 396
    .local v1, "t":Lorg/luaj/vm2/LuaTable;
    new-instance v2, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda108;

    invoke-direct {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda108;-><init>()V

    invoke-static {v2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypesKt;->fnv(Lkotlin/jvm/functions/Function1;)Lorg/luaj/vm2/lib/VarArgFunction;

    move-result-object v2

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    const-string v3, "GetEnums"

    invoke-virtual {v1, v3, v2}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 397
    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-virtual {v1, v2}, Lorg/luaj/vm2/LuaTable;->setmetatable(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    .line 398
    move-object v2, v1

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    return-object v2
.end method

.method public final install(Lorg/luaj/vm2/LuaTable;)V
    .registers 4
    .param p1, "g"    # Lorg/luaj/vm2/LuaTable;

    const-string v0, "g"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 406
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda75;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda75;-><init>()V

    const-string v1, "Vector3"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 416
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda86;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda86;-><init>()V

    const-string v1, "Vector2"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 421
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda89;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda89;-><init>()V

    const-string v1, "Vector3int16"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 424
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda90;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda90;-><init>()V

    const-string v1, "Content"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 430
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda91;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda91;-><init>()V

    const-string v1, "CFrame"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 459
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda92;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda92;-><init>()V

    const-string v1, "Color3"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 466
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda93;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda93;-><init>()V

    const-string v1, "BrickColor"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 482
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda94;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda94;-><init>()V

    const-string v1, "UDim"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 483
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda95;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda95;-><init>()V

    const-string v1, "UDim2"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 493
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda96;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda96;-><init>()V

    const-string v1, "TweenInfo"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 501
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda76;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda76;-><init>()V

    const-string v1, "Ray"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 502
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda77;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda77;-><init>()V

    const-string v1, "Region3"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 508
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda78;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda78;-><init>()V

    const-string v1, "Region3int16"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 513
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda79;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda79;-><init>()V

    const-string v1, "NumberRange"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 514
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda80;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda80;-><init>()V

    const-string v1, "NumberSequenceKeypoint"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 515
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda81;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda81;-><init>()V

    const-string v1, "ColorSequenceKeypoint"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 516
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda82;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda82;-><init>()V

    const-string v1, "NumberSequence"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 526
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda83;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda83;-><init>()V

    const-string v1, "ColorSequence"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 536
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda84;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda84;-><init>()V

    const-string v1, "Random"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 537
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda85;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda85;-><init>()V

    const-string v1, "Rect"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 538
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda87;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda87;-><init>()V

    const-string v1, "PhysicalProperties"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 544
    new-instance v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda88;

    invoke-direct {v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda88;-><init>()V

    const-string v1, "Font"

    invoke-static {p1, v1, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lib(Lorg/luaj/vm2/LuaTable;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 549
    const-string v0, "Enum"

    invoke-virtual {p0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->enumLib()Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Lorg/luaj/vm2/LuaTable;->set(Ljava/lang/String;Lorg/luaj/vm2/LuaValue;)V

    .line 550
    return-void
.end method

.method public final lerpValue(Ljava/lang/Object;Ljava/lang/Object;F)Ljava/lang/Object;
    .registers 10
    .param p1, "a"    # Ljava/lang/Object;
    .param p2, "b"    # Ljava/lang/Object;
    .param p3, "t"    # F

    .line 587
    nop

    .line 588
    instance-of v0, p1, Ljava/lang/Float;

    if-eqz v0, :cond_27

    instance-of v0, p2, Ljava/lang/Number;

    if-eqz v0, :cond_27

    move-object v0, p1

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    move-object v2, p1

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    move-result v2

    sub-float/2addr v1, v2

    mul-float/2addr v1, p3

    add-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    goto/16 :goto_172

    .line 589
    :cond_27
    instance-of v0, p1, Ljava/lang/Double;

    if-eqz v0, :cond_4e

    instance-of v0, p2, Ljava/lang/Number;

    if-eqz v0, :cond_4e

    move-object v0, p1

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    move-object v2, p2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v2

    move-object v4, p1

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v4

    sub-double/2addr v2, v4

    float-to-double v4, p3

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    goto/16 :goto_172

    .line 590
    :cond_4e
    instance-of v0, p1, Ljava/lang/Integer;

    if-eqz v0, :cond_76

    instance-of v0, p2, Ljava/lang/Number;

    if-eqz v0, :cond_76

    move-object v0, p1

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    move-object v2, p2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v2

    move-object v4, p1

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v4

    sub-double/2addr v2, v4

    float-to-double v4, p3

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    double-to-int v0, v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    goto/16 :goto_172

    .line 591
    :cond_76
    instance-of v0, p1, Ljava/lang/Long;

    if-eqz v0, :cond_9e

    instance-of v0, p2, Ljava/lang/Number;

    if-eqz v0, :cond_9e

    move-object v0, p1

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    move-object v2, p2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v2

    move-object v4, p1

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v4

    sub-double/2addr v2, v4

    float-to-double v4, p3

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    double-to-long v0, v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    goto/16 :goto_172

    .line 592
    :cond_9e
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v0, :cond_b2

    instance-of v0, p2, Lcom/exampletest/mobilestudiotest/model/Vector3;

    if-eqz v0, :cond_b2

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-object v1, p2

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Vector3;

    invoke-virtual {v0, v1, p3}, Lcom/exampletest/mobilestudiotest/model/Vector3;->lerp(Lcom/exampletest/mobilestudiotest/model/Vector3;F)Lcom/exampletest/mobilestudiotest/model/Vector3;

    move-result-object v0

    goto/16 :goto_172

    .line 593
    :cond_b2
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v0, :cond_c6

    instance-of v0, p2, Lcom/exampletest/mobilestudiotest/model/Vector2;

    if-eqz v0, :cond_c6

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-object v1, p2

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Vector2;

    invoke-virtual {v0, v1, p3}, Lcom/exampletest/mobilestudiotest/model/Vector2;->lerp(Lcom/exampletest/mobilestudiotest/model/Vector2;F)Lcom/exampletest/mobilestudiotest/model/Vector2;

    move-result-object v0

    goto/16 :goto_172

    .line 594
    :cond_c6
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v0, :cond_da

    instance-of v0, p2, Lcom/exampletest/mobilestudiotest/model/CFrame;

    if-eqz v0, :cond_da

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-object v1, p2

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/CFrame;

    invoke-virtual {v0, v1, p3}, Lcom/exampletest/mobilestudiotest/model/CFrame;->lerp(Lcom/exampletest/mobilestudiotest/model/CFrame;F)Lcom/exampletest/mobilestudiotest/model/CFrame;

    move-result-object v0

    goto/16 :goto_172

    .line 595
    :cond_da
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v0, :cond_ee

    instance-of v0, p2, Lcom/exampletest/mobilestudiotest/model/Color3;

    if-eqz v0, :cond_ee

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/Color3;

    move-object v1, p2

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/Color3;

    invoke-virtual {v0, v1, p3}, Lcom/exampletest/mobilestudiotest/model/Color3;->lerp(Lcom/exampletest/mobilestudiotest/model/Color3;F)Lcom/exampletest/mobilestudiotest/model/Color3;

    move-result-object v0

    goto/16 :goto_172

    .line 596
    :cond_ee
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v0, :cond_102

    instance-of v0, p2, Lcom/exampletest/mobilestudiotest/model/UDim2;

    if-eqz v0, :cond_102

    move-object v0, p1

    check-cast v0, Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-object v1, p2

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/UDim2;

    invoke-virtual {v0, v1, p3}, Lcom/exampletest/mobilestudiotest/model/UDim2;->lerp(Lcom/exampletest/mobilestudiotest/model/UDim2;F)Lcom/exampletest/mobilestudiotest/model/UDim2;

    move-result-object v0

    goto/16 :goto_172

    .line 597
    :cond_102
    instance-of v0, p1, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v0, :cond_143

    instance-of v0, p2, Lcom/exampletest/mobilestudiotest/model/UDim;

    if-eqz v0, :cond_143

    new-instance v0, Lcom/exampletest/mobilestudiotest/model/UDim;

    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v1}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v1

    move-object v2, p2

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v2

    move-object v3, p1

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim;->getScale()F

    move-result v3

    sub-float/2addr v2, v3

    mul-float/2addr v2, p3

    add-float/2addr v1, v2

    move-object v2, p1

    check-cast v2, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v2}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v2

    int-to-float v2, v2

    move-object v3, p2

    check-cast v3, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v3}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v3

    move-object v4, p1

    check-cast v4, Lcom/exampletest/mobilestudiotest/model/UDim;

    invoke-virtual {v4}, Lcom/exampletest/mobilestudiotest/model/UDim;->getOffset()I

    move-result v4

    sub-int/2addr v3, v4

    int-to-float v3, v3

    mul-float/2addr v3, p3

    add-float/2addr v2, v3

    float-to-int v2, v2

    invoke-direct {v0, v1, v2}, Lcom/exampletest/mobilestudiotest/model/UDim;-><init>(FI)V

    goto :goto_172

    .line 598
    :cond_143
    instance-of v0, p1, Ljava/lang/Number;

    if-eqz v0, :cond_169

    instance-of v0, p2, Ljava/lang/Number;

    if-eqz v0, :cond_169

    move-object v0, p1

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    move-object v2, p2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v2

    move-object v4, p1

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v4

    sub-double/2addr v2, v4

    float-to-double v4, p3

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    goto :goto_172

    .line 599
    :cond_169
    const/high16 v0, 0x3f800000    # 1.0f

    cmpl-float v0, p3, v0

    if-ltz v0, :cond_171

    move-object v0, p2

    goto :goto_172

    :cond_171
    move-object v0, p1

    .line 600
    :goto_172
    return-object v0
.end method

.method public final typeOf(Lorg/luaj/vm2/LuaValue;)Ljava/lang/String;
    .registers 6
    .param p1, "v"    # Lorg/luaj/vm2/LuaValue;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->isuserdata()Z

    move-result v0

    if-eqz v0, :cond_2e

    .line 48
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->getmetatable()Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    .line 49
    .local v0, "mt":Lorg/luaj/vm2/LuaValue;
    if-eqz v0, :cond_18

    const-string v1, "__type"

    invoke-virtual {v0, v1}, Lorg/luaj/vm2/LuaValue;->get(Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object v1

    goto :goto_19

    :cond_18
    const/4 v1, 0x0

    .line 50
    .local v1, "t":Lorg/luaj/vm2/LuaValue;
    :goto_19
    if-eqz v1, :cond_2b

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->isstring()Z

    move-result v2

    if-eqz v2, :cond_2b

    invoke-virtual {v1}, Lorg/luaj/vm2/LuaValue;->tojstring()Ljava/lang/String;

    move-result-object v2

    const-string v3, "tojstring(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v2

    .line 51
    :cond_2b
    const-string v2, "userdata"

    return-object v2

    .line 53
    .end local v0    # "mt":Lorg/luaj/vm2/LuaValue;
    .end local v1    # "t":Lorg/luaj/vm2/LuaValue;
    :cond_2e
    invoke-virtual {p1}, Lorg/luaj/vm2/LuaValue;->typename()Ljava/lang/String;

    move-result-object v0

    const-string v1, "typename(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public final v3(Lcom/exampletest/mobilestudiotest/model/Vector3;)Lorg/luaj/vm2/LuaValue;
    .registers 3
    .param p1, "v"    # Lcom/exampletest/mobilestudiotest/model/Vector3;

    const-string v0, "v"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    invoke-virtual {p0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;

    move-result-object v0

    return-object v0
.end method

.method public final wrap(Ljava/lang/Object;)Lorg/luaj/vm2/LuaValue;
    .registers 5
    .param p1, "o"    # Ljava/lang/Object;

    const-string v0, "o"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    sget-object v0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->metas:Ljava/util/HashMap;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/luaj/vm2/LuaTable;

    if-nez v0, :cond_24

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "getSimpleName(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->generic(Ljava/lang/String;)Lorg/luaj/vm2/LuaTable;

    move-result-object v0

    .line 58
    .local v0, "mt":Lorg/luaj/vm2/LuaTable;
    :cond_24
    new-instance v1, Lorg/luaj/vm2/LuaUserdata;

    move-object v2, v0

    check-cast v2, Lorg/luaj/vm2/LuaValue;

    invoke-direct {v1, p1, v2}, Lorg/luaj/vm2/LuaUserdata;-><init>(Ljava/lang/Object;Lorg/luaj/vm2/LuaValue;)V

    check-cast v1, Lorg/luaj/vm2/LuaValue;

    return-object v1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda0 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$165$lambda$164"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$165$lambda$164(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda1 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda1)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$82$lambda$81"
    proto = "(Lcom/exampletest/mobilestudiotest/model/Ray;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/model/Ray;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/model/Ray;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/model/Ray;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda1;->f$0:Lcom/exampletest/mobilestudiotest/model/Ray;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$82$lambda$81(Lcom/exampletest/mobilestudiotest/model/Ray;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda10 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda10)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$113$lambda$112"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$113$lambda$112(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda100 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda100)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda100;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "generic$lambda$1$lambda$0"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->generic$lambda$1$lambda$0(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda101 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda101)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda101;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$139$lambda$138"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$139$lambda$138(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda102 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda102)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda102;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$78$lambda$77"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$78$lambda$77(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda103 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda103)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda103;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$66$lambda$63"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$66$lambda$63(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda104 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda104)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda104;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$66$lambda$64"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$66$lambda$64(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda105 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda105)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda105;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$66$lambda$65"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$66$lambda$65(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda106 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda106)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda106;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$62$lambda$61"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$62$lambda$61(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda107 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda107)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda107;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "enumLib$lambda$102"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->enumLib$lambda$102(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda108 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda108)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda108;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "enumLib$lambda$105"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->enumLib$lambda$105(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda109 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda109)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda109;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "meta$lambda$2"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$lambda$2(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda11 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda11)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$149$lambda$148"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$149$lambda$148(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda110 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda110)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda110;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$167$lambda$166"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$167$lambda$166(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda111 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda111)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda111;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$143$lambda$140"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$143$lambda$140(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda112 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda112)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda112;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$143$lambda$141"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$143$lambda$141(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda113 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda113)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda113;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$143$lambda$142"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$143$lambda$142(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda114 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda114)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda114;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$33"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$33(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda115 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda115)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda115;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$44"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$44(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda116 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda116)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda116;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$45"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$45(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda117 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda117)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda117;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$46"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$46(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda118 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda118)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda118;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$34"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$34(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda119 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda119)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda119;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$35"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$35(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda12 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda12)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "meta$lambda$3"
    proto = "(Lkotlin/jvm/functions/Function2;Ljava/lang/String;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function2;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function2;Ljava/lang/String;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda12;->f$0:Lkotlin/jvm/functions/Function2;

    iput-object p2, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda12;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda12;->f$0:Lkotlin/jvm/functions/Function2;

    iget-object v1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda12;->f$1:Ljava/lang/String;

    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {v0, v1, p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$lambda$3(Lkotlin/jvm/functions/Function2;Ljava/lang/String;Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda120 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda120)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda120;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$36"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$36(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda121 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda121)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda121;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$37"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$37(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda122 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda122)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda122;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$38"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$38(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda123 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda123)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda123;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$39"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$39(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda124 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda124)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda124;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$40"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$40(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda125 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda125)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda125;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$41"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$41(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda126 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda126)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda126;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$47$lambda$42"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$47$lambda$42(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda127 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda127)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda127;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$153$lambda$152"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$153$lambda$152(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda128 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda128)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda128;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$132$lambda$127"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$132$lambda$127(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda129 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda129)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda129;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$132$lambda$128"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$132$lambda$128(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda13 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda13)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "meta$lambda$4"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$lambda$4(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda130 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda130)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda130;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$132$lambda$129"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$132$lambda$129(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda131 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda131)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda131;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$132$lambda$130"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$132$lambda$130(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda132 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda132)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda132;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$132$lambda$131"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$132$lambda$131(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda133 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda133)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda133;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$70$lambda$69"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$70$lambda$69(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda134 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda134)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda134;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$84$lambda$83"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/Region3V;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/Region3V;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/Region3V;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda134;->f$0:Lcom/exampletest/mobilestudiotest/lua/Region3V;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda134;->f$0:Lcom/exampletest/mobilestudiotest/lua/Region3V;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$84$lambda$83(Lcom/exampletest/mobilestudiotest/lua/Region3V;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda135 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda135)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda135;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$68$lambda$67"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/EnumItemV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/EnumItemV;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/EnumItemV;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda135;->f$0:Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda135;->f$0:Lcom/exampletest/mobilestudiotest/lua/EnumItemV;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$68$lambda$67(Lcom/exampletest/mobilestudiotest/lua/EnumItemV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda136 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda136)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda136;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$55$lambda$52"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$55$lambda$52(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda137 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda137)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda137;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$55$lambda$53"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$55$lambda$53(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda138 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda138)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda138;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$55$lambda$54"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$55$lambda$54(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda139 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda139)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda139;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$51$lambda$48"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$51$lambda$48(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda14 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda14)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "meta$lambda$5"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->meta$lambda$5(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda140 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda140)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda140;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$51$lambda$49"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$51$lambda$49(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda141 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda141)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda141;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$51$lambda$50"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$51$lambda$50(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda142 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda142)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda142;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$151$lambda$150"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$151$lambda$150(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda143 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda143)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda143;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$147$lambda$146"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$147$lambda$146(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda144 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda144)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda144;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$169$lambda$168"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$169$lambda$168(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda145 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda145)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda145;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$160$lambda$159"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$160$lambda$159(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda146 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda146)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda146;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$155$lambda$154"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$155$lambda$154(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda147 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda147)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda147;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$145$lambda$144"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$145$lambda$144(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda148 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda148)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda148;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$76$lambda$72"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda148;->f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda148;->f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$76$lambda$72(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda149 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda149)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda149;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$76$lambda$73"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda149;->f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda149;->f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$76$lambda$73(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda15 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda15)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$17"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$17(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda150 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda150)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda150;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$76$lambda$75"
    proto = "(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;


# direct methods
.method public synthetic constructor <init>(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda150;->f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda150;->f$0:Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$76$lambda$75(Lcom/exampletest/mobilestudiotest/lua/EnumTypeV;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda151 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda151)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda151;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$6"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$6(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda152 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda152)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda152;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$16"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$16(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda153 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda153)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda153;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$7"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$7(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda154 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda154)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda154;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$8"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$8(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda155 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda155)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda155;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$9"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$9(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda156 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda156)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda156;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$10"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$10(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda157 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda157)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda157;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$11"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$11(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda158 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda158)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda158;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$12"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$12(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda159 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda159)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda159;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$13"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$13(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda16 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda16)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$62"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$62(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda160 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda160)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda160;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$14"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$14(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda161 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda161)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda161;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$17$lambda$15"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$17$lambda$15(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda17 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda17)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$66"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$66(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda18 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda18)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$68"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$68(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda19 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda19)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$70"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$70(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda2 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126$lambda$118"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126$lambda$118(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda20 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda20)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$76"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$76(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda21 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda21)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$78"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$78(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda22 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda22)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$79"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$79(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda23 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda23)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$80"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$80(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda24 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda24)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda24;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$82"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$82(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda25 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda25)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda25;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$84"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$84(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda26 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda26)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda26;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$23"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$23(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda27 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda27)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda27;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$85"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$85(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda28 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda28)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda28;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$89"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$89(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda29 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda29)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda29;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$90"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$90(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda3 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda3)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126$lambda$119"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126$lambda$119(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda30 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda30)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda30;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$93"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$93(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda31 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda31)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda31;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$94"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$94(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda32 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda32)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda32;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$97"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$97(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda33 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda33)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda33;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$98"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$98(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda34 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda34)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda34;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$99"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$99(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda35 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda35)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda35;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$100"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$100(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda36 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda36)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda36;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$101"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$101(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda37 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda37)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda37;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$26"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$26(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda38 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda38)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda38;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$32"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$32(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda39 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda39)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda39;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$47"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$47(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda4 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda4)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126$lambda$120"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126$lambda$120(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda40 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda40)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda40;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$51"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$51(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda41 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda41)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda41;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$55"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$55(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda42 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda42)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda42;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$56"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$56(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda43 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda43)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda43;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$57"
    proto = "(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p2, Ljava/lang/String;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$57(Ljava/lang/Object;Ljava/lang/String;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda44 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda44)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda44;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "_init_$lambda$60"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->_init_$lambda$60(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda45 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda45)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda45;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$157$lambda$156"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$157$lambda$156(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda46 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda46)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda46;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$60$lambda$58"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$60$lambda$58(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda47 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda47)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda47;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$60$lambda$59"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$60$lambda$59(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda48 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda48)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda48;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$137$lambda$133"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$137$lambda$133(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda49 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda49)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda49;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$137$lambda$134"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$137$lambda$134(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda5 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda5)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126$lambda$121"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126$lambda$121(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda50 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda50)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda50;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$137$lambda$135"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$137$lambda$135(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda51 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda51)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda51;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$137$lambda$136"
    proto = "(ILorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda51;->f$0:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda51;->f$0:I

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$137$lambda$136(ILorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda52 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda52)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda52;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$26$lambda$24"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$26$lambda$24(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda53 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda53)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda53;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$26$lambda$25"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$26$lambda$25(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda54 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda54)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda54;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$117$lambda$114"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$117$lambda$114(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda55 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda55)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda55;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$117$lambda$115"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$117$lambda$115(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda56 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda56)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda56;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$117$lambda$116"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$117$lambda$116(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda57 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda57)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda57;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$32$lambda$27"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$32$lambda$27(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda58 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda58)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda58;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$32$lambda$28"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$32$lambda$28(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda59 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda59)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda59;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$32$lambda$29"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$32$lambda$29(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda6 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda6)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126$lambda$122"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126$lambda$122(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda60 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda60)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda60;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$32$lambda$30"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$32$lambda$30(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda61 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda61)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda61;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$32$lambda$31"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$32$lambda$31(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda62 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda62)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda62;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$89$lambda$86"
    proto = "(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/util/Random;


# direct methods
.method public synthetic constructor <init>(Ljava/util/Random;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda62;->f$0:Ljava/util/Random;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda62;->f$0:Ljava/util/Random;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$89$lambda$86(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda63 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda63)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda63;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$89$lambda$87"
    proto = "(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/util/Random;


# direct methods
.method public synthetic constructor <init>(Ljava/util/Random;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda63;->f$0:Ljava/util/Random;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda63;->f$0:Ljava/util/Random;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$89$lambda$87(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda64 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda64)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda64;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$89$lambda$88"
    proto = "(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# instance fields
.field public final synthetic f$0:Ljava/util/Random;


# direct methods
.method public synthetic constructor <init>(Ljava/util/Random;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda64;->f$0:Ljava/util/Random;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda64;->f$0:Ljava/util/Random;

    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {v0, p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$89$lambda$88(Ljava/util/Random;Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda65 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda65)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda65;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$163$lambda$162"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$163$lambda$162(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda66 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda66)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda66;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$109$lambda$106"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$109$lambda$106(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda67 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda67)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda67;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$109$lambda$107"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$109$lambda$107(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda68 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda68)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda68;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$109$lambda$108"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$109$lambda$108(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda69 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda69)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda69;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$111$lambda$110"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$111$lambda$110(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda7 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda7)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126$lambda$123"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126$lambda$123(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda70 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda70)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda70;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$23$lambda$18"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$23$lambda$18(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda71 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda71)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda71;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$23$lambda$19"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$23$lambda$19(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda72 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda72)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda72;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$23$lambda$20"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$23$lambda$20(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda73 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda73)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda73;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$23$lambda$21"
    proto = "(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    check-cast p2, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1, p2}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$23$lambda$21(Lorg/luaj/vm2/LuaValue;Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda74 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda74)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda74;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "lambda$23$lambda$22"
    proto = "(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaValue;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->lambda$23$lambda$22(Lorg/luaj/vm2/LuaValue;)Lorg/luaj/vm2/LuaValue;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda75 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda75)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda75;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$109"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$109(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda76 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda76)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda76;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$147"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$147(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda77 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda77)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda77;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$149"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$149(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda78 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda78)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda78;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$151"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$151(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda79 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda79)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda79;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$153"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$153(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda8 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126$lambda$124"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126$lambda$124(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda80 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda80)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda80;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$155"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$155(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda81 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda81)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda81;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$157"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$157(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda82 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda82)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda82;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$160"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$160(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda83 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda83)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda83;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$163"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$163(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda84 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda84)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda84;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$165"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$165(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda85 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda85)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda85;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$167"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$167(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda86 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda86)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda86;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$111"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$111(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda87 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda87)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda87;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$169"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$169(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda88 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda88)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda88;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$173"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$173(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda89 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda89)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda89;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$113"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$113(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda9 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda9)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126$lambda$125"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126$lambda$125(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda90 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda90)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda90;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$117"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$117(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda91 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda91)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda91;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$126"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$126(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda92 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda92)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda92;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$132"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$132(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda93 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda93)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda93;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$137"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$137(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda94 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda94)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda94;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$139"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$139(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda95 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda95)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda95;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$143"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$143(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda96 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda96)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda96;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$145"
    proto = "(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/LuaTable;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$145(Lorg/luaj/vm2/LuaTable;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda97 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda97)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda97;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$173$lambda$170"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$173$lambda$170(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda98 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda98)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda98;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$173$lambda$171"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$173$lambda$171(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method

###### Class com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda99 (com.exampletest.mobilestudiotest.lua.LuaTypes$$ExternalSyntheticLambda99)
.class public final synthetic Lcom/exampletest/mobilestudiotest/lua/LuaTypes$$ExternalSyntheticLambda99;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/exampletest/mobilestudiotest/lua/LuaTypes;"
    method = "install$lambda$173$lambda$172"
    proto = "(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x1c
    versionHash = "64bbee9deb17f2433a2f464e7880a82f306bf117c38a5da5e35bd2560d29022a"
.end annotation


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lorg/luaj/vm2/Varargs;

    invoke-static {p1}, Lcom/exampletest/mobilestudiotest/lua/LuaTypes;->install$lambda$173$lambda$172(Lorg/luaj/vm2/Varargs;)Lorg/luaj/vm2/Varargs;

    move-result-object p1

    return-object p1
.end method
