###### Class com.exampletest.mobilestudiotest.net.CloudPlace (com.exampletest.mobilestudiotest.net.CloudPlace)
.class public final Lcom/exampletest/mobilestudiotest/net/CloudPlace;
.super Ljava/lang/Object;
.source "RobloxCloud.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u000c\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\t\u0010\u000e\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u000f\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0010\u001a\u00020\u0006H\u00c6\u0003J\'\u0010\u0011\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0006H\u00c6\u0001J\u0013\u0010\u0012\u001a\u00020\u00132\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0015\u001a\u00020\u0016H\u00d6\u0001J\t\u0010\u0017\u001a\u00020\u0006H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\r\u00a8\u0006\u0018"
    }
    d2 = {
        "Lcom/exampletest/mobilestudiotest/net/CloudPlace;",
        "",
        "universeId",
        "",
        "placeId",
        "name",
        "",
        "<init>",
        "(JJLjava/lang/String;)V",
        "getUniverseId",
        "()J",
        "getPlaceId",
        "getName",
        "()Ljava/lang/String;",
        "component1",
        "component2",
        "component3",
        "copy",
        "equals",
        "",
        "other",
        "hashCode",
        "",
        "toString",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final name:Ljava/lang/String;

.field private final placeId:J

.field private final universeId:J


# direct methods
.method public constructor <init>(JJLjava/lang/String;)V
    .registers 7
    .param p1, "universeId"    # J
    .param p3, "placeId"    # J
    .param p5, "name"    # Ljava/lang/String;

    const-string v0, "name"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->universeId:J

    iput-wide p3, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->placeId:J

    iput-object p5, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->name:Ljava/lang/String;

    return-void
.end method

.method public static synthetic copy$default(Lcom/exampletest/mobilestudiotest/net/CloudPlace;JJLjava/lang/String;ILjava/lang/Object;)Lcom/exampletest/mobilestudiotest/net/CloudPlace;
    .registers 14

    and-int/lit8 p7, p6, 0x1

    if-eqz p7, :cond_6

    iget-wide p1, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->universeId:J

    :cond_6
    move-wide v1, p1

    and-int/lit8 p1, p6, 0x2

    if-eqz p1, :cond_d

    iget-wide p3, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->placeId:J

    :cond_d
    move-wide v3, p3

    and-int/lit8 p6, p6, 0x4

    if-eqz p6, :cond_14

    iget-object p5, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->name:Ljava/lang/String;

    :cond_14
    move-object v0, p0

    move-object v5, p5

    invoke-virtual/range {v0 .. v5}, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->copy(JJLjava/lang/String;)Lcom/exampletest/mobilestudiotest/net/CloudPlace;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()J
    .registers 3

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->universeId:J

    return-wide v0
.end method

.method public final component2()J
    .registers 3

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->placeId:J

    return-wide v0
.end method

.method public final component3()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final copy(JJLjava/lang/String;)Lcom/exampletest/mobilestudiotest/net/CloudPlace;
    .registers 13

    const-string v0, "name"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lcom/exampletest/mobilestudiotest/net/CloudPlace;

    move-wide v2, p1

    move-wide v4, p3

    move-object v6, p5

    invoke-direct/range {v1 .. v6}, Lcom/exampletest/mobilestudiotest/net/CloudPlace;-><init>(JJLjava/lang/String;)V

    return-object v1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 9

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/exampletest/mobilestudiotest/net/CloudPlace;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    move-object v1, p1

    check-cast v1, Lcom/exampletest/mobilestudiotest/net/CloudPlace;

    iget-wide v3, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->universeId:J

    iget-wide v5, v1, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->universeId:J

    cmp-long v3, v3, v5

    if-eqz v3, :cond_16

    return v2

    :cond_16
    iget-wide v3, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->placeId:J

    iget-wide v5, v1, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->placeId:J

    cmp-long v3, v3, v5

    if-eqz v3, :cond_1f

    return v2

    :cond_1f
    iget-object v3, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->name:Ljava/lang/String;

    iget-object v1, v1, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->name:Ljava/lang/String;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2a

    return v2

    :cond_2a
    return v0
.end method

.method public final getName()Ljava/lang/String;
    .registers 2

    .line 10
    iget-object v0, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final getPlaceId()J
    .registers 3

    .line 10
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->placeId:J

    return-wide v0
.end method

.method public final getUniverseId()J
    .registers 3

    .line 10
    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->universeId:J

    return-wide v0
.end method

.method public hashCode()I
    .registers 5

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->universeId:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget-wide v2, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->placeId:J

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->name:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 8

    iget-wide v0, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->universeId:J

    iget-wide v2, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->placeId:J

    iget-object v4, p0, Lcom/exampletest/mobilestudiotest/net/CloudPlace;->name:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "CloudPlace(universeId="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", placeId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", name="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
