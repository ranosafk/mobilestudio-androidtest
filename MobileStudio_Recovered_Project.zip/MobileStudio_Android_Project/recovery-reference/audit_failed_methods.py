#!/usr/bin/env python3
"""Audit a JADX workspace against its Smali reference for failed app methods."""
import json,re,sys
from pathlib import Path
root=Path(sys.argv[1])
report=json.loads((root/'jadx-report.json').read_text())
failed=[m for m in report['methods'] if m.get('status')=='failed' and m.get('class','').startswith('com.exampletest.mobilestudiotest.')]
print(f'JADX failed app methods: {len(failed)}')
for m in failed: print(m['class']+'.'+m['method'])
